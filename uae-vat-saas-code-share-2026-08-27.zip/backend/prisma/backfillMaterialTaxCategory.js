require("dotenv").config();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

// One-off backfill (2026-08-03): populates the new Material.defaultTaxCategoryId
// from the old hardcoded Material.defaultVatCategory string, by matching it to
// the tenant's seeded TaxCategory name. See docs/features/17-invoice-generation.md §2.
const OLD_TO_SEEDED_NAME = {
  STANDARD_RATED: "Standard Rated",
  ZERO_RATED: "Zero Rated",
  EXEMPT: "Exempt",
  OUT_OF_SCOPE: "Out of Scope",
};

async function main() {
  const materials = await prisma.material.findMany({ where: { defaultTaxCategoryId: null } });
  console.log(`Found ${materials.length} material(s) without a defaultTaxCategoryId.`);

  let updated = 0;
  let skipped = 0;

  for (const material of materials) {
    const seededName = OLD_TO_SEEDED_NAME[material.defaultVatCategory];
    if (!seededName) {
      console.warn(`  Skipping ${material.id} ("${material.name}") - unrecognized defaultVatCategory "${material.defaultVatCategory}"`);
      skipped++;
      continue;
    }

    const category = await prisma.taxCategory.findFirst({
      where: { tenantId: material.tenantId, name: seededName },
    });

    if (!category) {
      console.warn(`  Skipping ${material.id} ("${material.name}") - no "${seededName}" TaxCategory found for tenant ${material.tenantId}`);
      skipped++;
      continue;
    }

    await prisma.material.update({
      where: { id: material.id },
      data: { defaultTaxCategoryId: category.id },
    });
    updated++;
  }

  console.log(`Backfill complete: ${updated} updated, ${skipped} skipped.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
