require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const { seedPermissionCatalog, seedSystemRolesForTenant } = require("../src/services/roleSeed.service");

const prisma = new PrismaClient();

// One-off backfill (2026-08-11): the new "sales_debit_notes" RBAC module was
// added to permissionCatalog.js/roleSeed.service.js's ROLE_DEFS, but
// seedSystemRolesForTenant() (which grants a role's *newly added* permission
// keys) only runs at tenant-creation time - it never re-runs for tenants
// that already existed before this change, same class of gap
// backfillMissingTaxCategories.js fixed for Tax Master. Both functions
// called here are idempotent/additive (upsert + "only create what's
// missing"), so this is safe to re-run.
async function main() {
  await seedPermissionCatalog(prisma);
  console.log("Permission catalog synced (sales_debit_notes.* keys now exist).");

  const tenants = await prisma.tenant.findMany({ select: { id: true, name: true } });
  console.log(`${tenants.length} tenant(s) - granting sales_debit_notes.* to each tenant's system roles per ROLE_DEFS.`);

  for (const tenant of tenants) {
    await seedSystemRolesForTenant(prisma, tenant.id);
    console.log(`  Synced roles for "${tenant.name}" (${tenant.id})`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
