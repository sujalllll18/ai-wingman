require("dotenv").config();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

// One-off backfill (Phase 2 Payments module, 2026-08-22): Payment was
// restructured from a strict 1-payment-to-1-invoice row into a real Customer
// Payment header + PaymentAllocation child rows (see schema.prisma comments
// on both models). tenantId/customerName/updatedAt were added as nullable
// (db push can't add required columns to a non-empty table in one step) -
// this backfills the pre-existing legacy rows so they conform to the new
// shape exactly like every new Payment does, and creates the one
// PaymentAllocation row each legacy row implies (it was always a single
// full-amount payment against its one invoiceId).
async function main() {
  const legacyPayments = await prisma.payment.findMany({
    where: { tenantId: null },
    include: { invoice: true },
  });
  console.log(`${legacyPayments.length} legacy Payment row(s) to backfill.`);

  for (const payment of legacyPayments) {
    if (!payment.invoice) {
      console.log(`  Skipping ${payment.id} - its invoice no longer exists.`);
      continue;
    }

    await prisma.$transaction(async (tx) => {
      const existingAllocation = await tx.paymentAllocation.findFirst({ where: { paymentId: payment.id } });

      await tx.payment.update({
        where: { id: payment.id },
        data: {
          tenantId: payment.invoice.tenantId,
          customerName: payment.invoice.customerName,
          updatedAt: payment.createdAt,
        },
      });

      if (!existingAllocation) {
        await tx.paymentAllocation.create({
          data: {
            paymentId: payment.id,
            invoiceId: payment.invoiceId,
            allocatedAmount: payment.amount,
          },
        });
      }
    });

    console.log(`  Backfilled ${payment.id} (invoice ${payment.invoice.invoiceNumberDisplay || payment.invoiceId}).`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
