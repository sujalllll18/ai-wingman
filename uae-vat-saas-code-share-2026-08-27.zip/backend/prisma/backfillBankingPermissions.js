require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const { seedPermissionCatalog, seedSystemRolesForTenant } = require("../src/services/roleSeed.service");

const prisma = new PrismaClient();

// One-off backfill (Banking module, Phase 3 2026-08-22): the new "banking"
// RBAC module was added to permissionCatalog.js/roleSeed.service.js's
// ROLE_DEFS, but seedSystemRolesForTenant() only grants a role's *newly
// added* permission keys at tenant-creation time - it never re-runs for
// tenants that already existed before this change. Same recurring gap
// backfillPaymentsPermissions.js/backfillSalesDebitNotePermissions.js fixed
// for their own modules; both functions here are idempotent/additive.
async function main() {
  await seedPermissionCatalog(prisma);
  console.log("Permission catalog synced (banking.* keys now exist).");

  const tenants = await prisma.tenant.findMany({ select: { id: true, name: true } });
  console.log(`${tenants.length} tenant(s) - granting banking.* to each tenant's system roles per ROLE_DEFS.`);

  for (const tenant of tenants) {
    await seedSystemRolesForTenant(prisma, tenant.id);
    console.log(`  Synced roles for "${tenant.name}" (${tenant.id})`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
