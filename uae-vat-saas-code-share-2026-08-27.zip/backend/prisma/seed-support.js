// Support Center (2026-08-07) - seeds TicketCategory and SlaPolicy starter
// data. No dedicated admin CRUD screen for either exists yet (deferred
// follow-up phase) - this is what makes the Raise Ticket form and SLA
// timers work correctly today. Idempotent - skips anything that already exists.
const prisma = require("../src/config/prisma");

const CATEGORIES = ["Bug Report", "Feature Request", "Data Issue", "Access / Login", "Billing", "How-To Question", "Performance", "Other"];

const SLA_POLICIES = [
  { priority: "LOW", responseTimeHours: 24, resolutionTimeHours: 120 },
  { priority: "MEDIUM", responseTimeHours: 12, resolutionTimeHours: 72 },
  { priority: "HIGH", responseTimeHours: 4, resolutionTimeHours: 24 },
  { priority: "CRITICAL", responseTimeHours: 1, resolutionTimeHours: 8 },
];

async function main() {
  for (const name of CATEGORIES) {
    const existing = await prisma.ticketCategory.findUnique({ where: { name } });
    if (existing) continue;
    await prisma.ticketCategory.create({ data: { name } });
    console.log(`Created ticket category: ${name}`);
  }

  for (const policy of SLA_POLICIES) {
    const existing = await prisma.slaPolicy.findUnique({ where: { priority: policy.priority } });
    if (existing) continue;
    await prisma.slaPolicy.create({ data: policy });
    console.log(`Created SLA policy: ${policy.priority}`);
  }
}

main()
  .then(() => prisma.$disconnect())
  .catch((err) => {
    console.error(err);
    prisma.$disconnect();
    process.exit(1);
  });
