require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const { seedPermissionCatalog, seedSystemRolesForTenant } = require("../src/services/roleSeed.service");

const prisma = new PrismaClient();

// One-off backfill (2026-08-22, migration-engine hardening): "pause",
// "resume", and "retry" were added to the existing "imports" RBAC module in
// permissionCatalog.js, and ROLE_DEFS' ACCOUNTANT/SALES_EXEC/PURCHASE_EXEC
// entries were updated to grant them - but seedSystemRolesForTenant() only
// grants a role's *newly added* permission keys at tenant-creation time, it
// never re-runs for tenants that already existed before this change. Same
// class of gap backfillSalesDebitNotePermissions.js and
// backfillMissingTaxCategories.js fixed before. Both functions called here
// are idempotent/additive, safe to re-run.
async function main() {
  await seedPermissionCatalog(prisma);
  console.log("Permission catalog synced (imports.pause / imports.resume / imports.retry now exist).");

  const tenants = await prisma.tenant.findMany({ select: { id: true, name: true } });
  console.log(`${tenants.length} tenant(s) - granting imports.pause/resume/retry to each tenant's system roles per ROLE_DEFS.`);

  for (const tenant of tenants) {
    await seedSystemRolesForTenant(prisma, tenant.id);
    console.log(`  Synced roles for "${tenant.name}" (${tenant.id})`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
