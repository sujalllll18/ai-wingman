// One-time RBAC seed/backfill (2026-08-06) for Tenants/Users that already
// existed before RBAC did. Safe to re-run - every write goes through
// src/services/roleSeed.service.js, which is exists-check/upsert based
// throughout. Going forward, new Tenants/Users get the same treatment
// automatically from platformAdmin.controller.js's createTenant/
// createStaffUser (same shared service, not a separate copy) - this script
// only needed to run once for the Tenants that predate RBAC.
require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const { PERMISSIONS } = require("../src/config/permissionCatalog");
const { seedPermissionCatalog, seedSystemRolesForTenant, assignDefaultUserRole } = require("../src/services/roleSeed.service");

const prisma = new PrismaClient();

async function main() {
  await seedPermissionCatalog(prisma);
  console.log(`Permission catalog seeded: ${PERMISSIONS.length} keys.`);

  const tenants = await prisma.tenant.findMany();
  let totalUserRolesCreated = 0;

  for (const tenant of tenants) {
    await seedSystemRolesForTenant(prisma, tenant.id);

    const users = await prisma.user.findMany({ where: { tenantId: tenant.id } });
    let created = 0;
    for (const user of users) {
      const before = await prisma.userRole.count({ where: { userId: user.id, isPrimary: true } });
      await assignDefaultUserRole(prisma, { userId: user.id, tenantId: tenant.id, legacyRole: user.role });
      const after = await prisma.userRole.count({ where: { userId: user.id, isPrimary: true } });
      if (after > before) created += 1;
    }

    totalUserRolesCreated += created;
    console.log(`Tenant "${tenant.name}": 8 system roles ready, ${created} UserRole row(s) backfilled.`);
  }

  console.log(`Done. ${tenants.length} tenant(s) processed, ${totalUserRolesCreated} UserRole row(s) created in total.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
