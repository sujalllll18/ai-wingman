require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const { seedPermissionCatalog, seedSystemRolesForTenant } = require("../src/services/roleSeed.service");

const prisma = new PrismaClient();

// One-off backfill (Phase 2 Payments module, 2026-08-22): the new "payments"
// and "purchase_payments" RBAC modules were added to permissionCatalog.js/
// roleSeed.service.js's ROLE_DEFS, but seedSystemRolesForTenant() only grants
// a role's *newly added* permission keys at tenant-creation time - it never
// re-runs for tenants that already existed before this change. Same class of
// gap backfillSalesDebitNotePermissions.js fixed for that module; both
// functions called here are idempotent/additive, safe to re-run.
async function main() {
  await seedPermissionCatalog(prisma);
  console.log("Permission catalog synced (payments.*/purchase_payments.* keys now exist).");

  const tenants = await prisma.tenant.findMany({ select: { id: true, name: true } });
  console.log(`${tenants.length} tenant(s) - granting payments.*/purchase_payments.* to each tenant's system roles per ROLE_DEFS.`);

  for (const tenant of tenants) {
    await seedSystemRolesForTenant(prisma, tenant.id);
    console.log(`  Synced roles for "${tenant.name}" (${tenant.id})`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
