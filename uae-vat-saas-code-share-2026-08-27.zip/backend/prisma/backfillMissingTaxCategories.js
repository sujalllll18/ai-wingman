require("dotenv").config();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

// One-off backfill (2026-08-03): Tax Master's default-category seeding was
// added to createTenant mid-project (2026-08-02) - Tenants created before
// that point have zero TaxCategory rows, which blocks both the Material
// defaultTaxCategoryId backfill and Invoice line-item VAT resolution for
// them. This retroactively applies the exact same seed logic
// platformAdmin.controller.js's createTenant already uses for new Tenants.
const SEED_CATEGORIES = [
  { name: "Standard Rated", rateName: "UAE Standard VAT", percentage: 5.0, classification: "STANDARD_RATED" },
  { name: "Zero Rated", rateName: "Zero Rated", percentage: 0, classification: "ZERO_RATED" },
  { name: "Exempt", rateName: "Exempt", percentage: 0, classification: "EXEMPT" },
  { name: "Out of Scope", rateName: "Out of Scope", percentage: 0, classification: "OUT_OF_SCOPE" },
];

async function main() {
  const tenants = await prisma.tenant.findMany({ include: { _count: { select: { taxCategories: true } } } });
  const missing = tenants.filter((t) => t._count.taxCategories === 0);
  console.log(`${tenants.length} tenant(s) total, ${missing.length} missing Tax Categories.`);

  for (const tenant of missing) {
    await prisma.$transaction(async (tx) => {
      for (const seed of SEED_CATEGORIES) {
        const rate = await tx.taxRate.create({
          data: {
            tenantId: tenant.id,
            name: seed.rateName,
            percentage: seed.percentage,
            calculationMethod: "EXCLUSIVE",
            effectiveFrom: new Date(),
          },
        });
        await tx.taxCategory.create({
          data: { tenantId: tenant.id, name: seed.name, taxRateId: rate.id, classification: seed.classification },
        });
      }
    });
    console.log(`  Seeded 4 default categories for "${tenant.name}" (${tenant.id})`);
  }

  console.log("Done.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
