require("dotenv").config();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

// One-off backfill (2026-08-03): TaxCategory.classification was added for
// VAT Return bucketing after Tax Master already existed, so every category
// created before this field existed defaulted to STANDARD_RATED at the
// schema level. This retroactively assigns the correct classification to
// the 4 known default names (case-insensitive exact match) - anything that
// doesn't match a known default name is left at STANDARD_RATED and logged,
// since that's the safest assumption for a custom category and it's cheap
// for the tenant to fix in Tax Master afterward.
const NAME_TO_CLASSIFICATION = {
  "standard rated": "STANDARD_RATED",
  "zero rated": "ZERO_RATED",
  exempt: "EXEMPT",
  "out of scope": "OUT_OF_SCOPE",
};

async function main() {
  const categories = await prisma.taxCategory.findMany();
  console.log(`${categories.length} tax categor(y/ies) total.`);

  let updated = 0;
  let unmatched = 0;
  for (const category of categories) {
    const classification = NAME_TO_CLASSIFICATION[category.name.trim().toLowerCase()];
    if (!classification) {
      unmatched += 1;
      console.log(`  Left "${category.name}" (${category.id}) at default STANDARD_RATED - not a recognized default name, review in Tax Master.`);
      continue;
    }
    if (category.classification === classification) continue;
    await prisma.taxCategory.update({ where: { id: category.id }, data: { classification } });
    updated += 1;
    console.log(`  "${category.name}" (tenant ${category.tenantId}) -> ${classification}`);
  }

  console.log(`Done. ${updated} updated, ${unmatched} left at default (unrecognized name).`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
