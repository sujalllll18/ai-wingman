// Platform Admin Phase 2 - seeds the Plan/PlanVersion tables (2026-08-07).
// Two groups of plans:
//  1. The 3 legacy plans (TRIAL/STANDARD/PREMIUM) - seeded with the EXACT
//     values that were previously hardcoded in src/config/plans.js, so
//     every existing tenant's actual limits/features are unchanged. Every
//     existing Tenant is also backfilled with a TenantPlanAssignment
//     pointing at the matching plan's v1, since that concept didn't exist
//     before this migration.
//  2. 5 new example plans (Starter/Growth/Business/Enterprise/Custom) per
//     the Phase 2 spec - published and available for admins to assign to
//     tenants going forward, seeded with representative example numbers
//     (clearly a starting catalog, not real historical billing data).
// Idempotent - skips any plan whose slug already exists.
const prisma = require("../src/config/prisma");

const ALL_MODULE_KEYS = [
  "dashboard", "business_profile", "team", "customers", "products", "tax_master",
  "invoices", "purchases", "vat_returns", "audit_logs", "reports", "tickets",
  "roles", "settings", "approvals", "ocr", "ai_assistant",
];

function moduleAccessAllEnabled(overrides = {}) {
  const access = {};
  for (const key of ALL_MODULE_KEYS) {
    access[key] = { enabled: overrides[key] !== undefined ? overrides[key] : true, features: {} };
  }
  return JSON.stringify(access);
}

async function upsertPlan({ slug, name, description, isDefault, version }) {
  const existing = await prisma.plan.findUnique({ where: { slug } });
  if (existing) {
    console.log(`Plan already exists, skipping: ${slug}`);
    return;
  }
  const plan = await prisma.plan.create({ data: { slug, name, description, isDefault: !!isDefault, status: "ACTIVE" } });
  await prisma.planVersion.create({
    data: { planId: plan.id, versionNumber: 1, status: "PUBLISHED", changeSummary: "Initial version", ...version },
  });
  console.log(`Created plan: ${slug}`);
  return plan;
}

async function backfillTenantAssignments() {
  const tenants = await prisma.tenant.findMany({ select: { id: true, plan: true } });
  for (const tenant of tenants) {
    const existing = await prisma.tenantPlanAssignment.findUnique({ where: { tenantId: tenant.id } });
    if (existing) continue;
    const plan = await prisma.plan.findUnique({ where: { slug: tenant.plan } });
    if (!plan) {
      console.log(`No matching Plan for tenant ${tenant.id}'s plan "${tenant.plan}" - skipping backfill`);
      continue;
    }
    const version = await prisma.planVersion.findFirst({ where: { planId: plan.id, status: "PUBLISHED" }, orderBy: { versionNumber: "desc" } });
    if (!version) continue;
    await prisma.tenantPlanAssignment.create({ data: { tenantId: tenant.id, planVersionId: version.id } });
    console.log(`Backfilled plan assignment for tenant ${tenant.id} -> ${tenant.plan}`);
  }
}

async function main() {
  // --- Legacy plans: EXACT same values as the old PLAN_LIMITS object ---
  await upsertPlan({
    slug: "TRIAL",
    name: "Trial",
    description: "Free 14-day trial.",
    isDefault: true,
    version: {
      monthlyPrice: 0, yearlyPrice: 0, trialDays: 14, gracePeriodDays: 0, autoRenewal: false,
      maxUsers: 2, maxCustomers: null, maxProducts: null, maxInvoicesPerMonth: 20, maxPurchasesPerMonth: null,
      ocrCredits: null, apiCallsPerMonth: null, storageGb: null, attachmentStorageGb: null, maxBranches: null, maxTeamMembers: null,
      moduleAccess: moduleAccessAllEnabled({ audit_logs: false, ocr: false, ai_assistant: false }),
    },
  });
  await upsertPlan({
    slug: "STANDARD",
    name: "Standard",
    description: "For growing businesses.",
    version: {
      monthlyPrice: 499, yearlyPrice: 4990, trialDays: 0, gracePeriodDays: 7, autoRenewal: true,
      maxUsers: 5, maxCustomers: null, maxProducts: null, maxInvoicesPerMonth: null, maxPurchasesPerMonth: null,
      ocrCredits: null, apiCallsPerMonth: null, storageGb: null, attachmentStorageGb: null, maxBranches: null, maxTeamMembers: null,
      moduleAccess: moduleAccessAllEnabled({ audit_logs: false, ocr: false, ai_assistant: false }),
    },
  });
  await upsertPlan({
    slug: "PREMIUM",
    name: "Premium",
    description: "Full platform access.",
    version: {
      monthlyPrice: 999, yearlyPrice: 9990, trialDays: 0, gracePeriodDays: 14, autoRenewal: true,
      maxUsers: null, maxCustomers: null, maxProducts: null, maxInvoicesPerMonth: null, maxPurchasesPerMonth: null,
      ocrCredits: null, apiCallsPerMonth: null, storageGb: null, attachmentStorageGb: null, maxBranches: null, maxTeamMembers: null,
      moduleAccess: moduleAccessAllEnabled({ ai_assistant: false }),
    },
  });

  // --- New example plan catalog per the Phase 2 spec ---
  await upsertPlan({
    slug: "STARTER",
    name: "Starter",
    description: "For solo founders and very small teams just getting started.",
    version: {
      monthlyPrice: 0, yearlyPrice: 0, trialDays: 14, gracePeriodDays: 0, autoRenewal: false,
      maxUsers: 3, maxCustomers: 50, maxProducts: 50, maxInvoicesPerMonth: 30, maxPurchasesPerMonth: 30,
      ocrCredits: 20, apiCallsPerMonth: 500, storageGb: 2, attachmentStorageGb: 1, maxBranches: 1, maxTeamMembers: 3,
      moduleAccess: moduleAccessAllEnabled({ team: false, vat_returns: false, reports: false, audit_logs: false, tickets: false, roles: false, approvals: false, ocr: false, ai_assistant: false }),
    },
  });
  await upsertPlan({
    slug: "GROWTH",
    name: "Growth",
    description: "For teams ready to scale their operations.",
    version: {
      monthlyPrice: 299, yearlyPrice: 2990, trialDays: 0, gracePeriodDays: 7, autoRenewal: true,
      maxUsers: 10, maxCustomers: 500, maxProducts: 500, maxInvoicesPerMonth: 200, maxPurchasesPerMonth: 200,
      ocrCredits: 200, apiCallsPerMonth: 5000, storageGb: 25, attachmentStorageGb: 10, maxBranches: 3, maxTeamMembers: 10,
      moduleAccess: moduleAccessAllEnabled({ audit_logs: false, roles: false, approvals: false, ai_assistant: false }),
    },
  });
  await upsertPlan({
    slug: "BUSINESS",
    name: "Business",
    description: "For established businesses with compliance and approval needs.",
    version: {
      monthlyPrice: 799, yearlyPrice: 7990, trialDays: 0, gracePeriodDays: 14, autoRenewal: true,
      maxUsers: 25, maxCustomers: 2000, maxProducts: 2000, maxInvoicesPerMonth: null, maxPurchasesPerMonth: null,
      ocrCredits: 1000, apiCallsPerMonth: 25000, storageGb: 100, attachmentStorageGb: 50, maxBranches: 10, maxTeamMembers: 25,
      moduleAccess: moduleAccessAllEnabled({ ai_assistant: false }),
    },
  });
  await upsertPlan({
    slug: "ENTERPRISE",
    name: "Enterprise",
    description: "Unlimited usage, every module, dedicated support.",
    version: {
      monthlyPrice: 1999, yearlyPrice: 19990, trialDays: 0, gracePeriodDays: 30, autoRenewal: true,
      maxUsers: null, maxCustomers: null, maxProducts: null, maxInvoicesPerMonth: null, maxPurchasesPerMonth: null,
      ocrCredits: null, apiCallsPerMonth: null, storageGb: null, attachmentStorageGb: null, maxBranches: null, maxTeamMembers: null,
      moduleAccess: moduleAccessAllEnabled(),
    },
  });
  await upsertPlan({
    slug: "CUSTOM",
    name: "Custom",
    description: "Negotiated pricing and limits - use the Plan Builder to tailor this plan per customer.",
    version: {
      monthlyPrice: 0, yearlyPrice: 0, trialDays: 0, gracePeriodDays: 30, autoRenewal: true,
      maxUsers: null, maxCustomers: null, maxProducts: null, maxInvoicesPerMonth: null, maxPurchasesPerMonth: null,
      ocrCredits: null, apiCallsPerMonth: null, storageGb: null, attachmentStorageGb: null, maxBranches: null, maxTeamMembers: null,
      moduleAccess: moduleAccessAllEnabled(),
    },
  });

  await backfillTenantAssignments();
}

main()
  .then(() => prisma.$disconnect())
  .catch((err) => {
    console.error(err);
    prisma.$disconnect();
    process.exit(1);
  });
