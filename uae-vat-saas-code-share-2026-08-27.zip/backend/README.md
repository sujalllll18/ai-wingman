# UAE VAT SaaS — Module 0: Platform & Tenant Management

Node.js + Express + Prisma (SQLite for local dev, swappable to Postgres later
with zero application-code changes). This is **Module 0 only** — the
foundation layer used to manage paying Tenants before anyone at a Tenant logs
in. Later modules (Tenant Foundation, Invoicing, VAT Position, Access
Control, Automation) will be built on top of this in order, per the delivery
plan, each fully working and tested before the next starts.

## Stack

- **Express** — HTTP API
- **Prisma + SQLite** — ORM + database (schema already models Module 1–4/5
  tables as stubs so later modules don't require re-migrating Module 0 data,
  but only Module 0 has working business logic right now)
- **JWT (two separate secrets)** — Platform Admin tokens and Tenant User
  tokens are signed with different secrets and different `aud` claims, so a
  Platform Admin token can never be replayed against a tenant-only route and
  vice versa
- **bcrypt** — password hashing

## Setup

```bash
cd uae-vat-saas
npm install
cp .env.example .env          # edit secrets if you like
npx prisma generate
npx prisma migrate dev --name init
npm run seed                  # creates the first Platform Admin account
npm run dev                   # starts on http://localhost:4000
```

The seed script prints the Platform Admin email/password it created
(defaults: `admin@platform.local` / `ChangeMe123!` — override via `.env`).

## Data model (this module's slice)

- `PlatformAdmin` — me
- `Tenant` — a paying business (`plan`: TRIAL / STANDARD / PREMIUM, `status`:
  ACTIVE / SUSPENDED)
- `User` — a Tenant's Owner or Staff member (`role`: OWNER / STAFF), always
  created by Platform Admin, never self-service

Plan limits (`src/config/plans.js`, single source of truth):

| Plan     | Max users (incl. Owner) | Max invoices/month | Audit Log | OCR |
|----------|--------------------------|---------------------|-----------|-----|
| TRIAL    | 2                        | 20                  | ✗         | ✗   |
| STANDARD | 5                        | unlimited           | ✗         | ✗   |
| PREMIUM  | unlimited                | unlimited           | ✓         | ✓   |

## Data isolation

- Every tenant-scoped query filters on `tenantId` taken from the **verified
  JWT** (`req.tenantId`), never from a request body/param — so one Tenant's
  user can never fetch another Tenant's data by guessing an ID.
- `requireTenantUser` middleware re-checks the Tenant's status on every
  request — a Tenant suspended mid-session is locked out on their very next
  call, not just at next login.
- Platform Admin's tenant list/usage endpoints intentionally return only
  plan/status/user-count/invoice-count — not financial detail — per spec.

## Endpoints

### Platform Admin (`/api/platform-admin`)

| Method | Path                       | Auth           | Purpose |
|--------|----------------------------|----------------|---------|
| POST   | `/login`                   | —              | Get a Platform Admin JWT |
| GET    | `/tenants`                 | Platform Admin | Dashboard: all Tenants + plan/status/counts |
| POST   | `/tenants`                 | Platform Admin | Create Tenant + mandatory Owner user |
| PATCH  | `/tenants/:id/plan`        | Platform Admin | Change subscription plan |
| PATCH  | `/tenants/:id/suspend`     | Platform Admin | Suspend a Tenant |
| PATCH  | `/tenants/:id/reactivate`  | Platform Admin | Reactivate a Tenant |
| POST   | `/tenants/:id/staff`       | Platform Admin | Create a Staff user for a Tenant |
| GET    | `/tenants/:id/usage`       | Platform Admin | Usage detail for one Tenant |

### Tenant (`/api/tenant`)

| Method | Path      | Auth        | Purpose |
|--------|-----------|-------------|---------|
| POST   | `/login`  | —           | Tenant Owner/Staff login |
| GET    | `/team`   | Tenant user | View-only list of this Tenant's users |

## Example walkthrough (curl)

```bash
# 1. Log in as Platform Admin
curl -s -X POST http://localhost:4000/api/platform-admin/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@platform.local","password":"ChangeMe123!"}'
# -> { "token": "<ADMIN_TOKEN>", ... }

# 2. Create a Tenant with its Owner
curl -s -X POST http://localhost:4000/api/platform-admin/tenants \
  -H "Authorization: Bearer <ADMIN_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
        "name": "Al Noor Trading LLC",
        "trn": "100123456700003",
        "plan": "TRIAL",
        "owner": { "name": "Fatima Al Noor", "email": "fatima@alnoor.ae", "password": "OwnerPass123!" }
      }'

# 3. List all Tenants (Platform Admin dashboard)
curl -s http://localhost:4000/api/platform-admin/tenants \
  -H "Authorization: Bearer <ADMIN_TOKEN>"

# 4. Add a Staff user to that Tenant
curl -s -X POST http://localhost:4000/api/platform-admin/tenants/<TENANT_ID>/staff \
  -H "Authorization: Bearer <ADMIN_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name":"Ahmed Ali","email":"ahmed@alnoor.ae","password":"StaffPass123!"}'

# 5. Tenant Owner logs in
curl -s -X POST http://localhost:4000/api/tenant/login \
  -H "Content-Type: application/json" \
  -d '{"email":"fatima@alnoor.ae","password":"OwnerPass123!"}'
# -> { "token": "<TENANT_TOKEN>", ... }

# 6. View team (Tenant-scoped, isolated from every other Tenant)
curl -s http://localhost:4000/api/tenant/team \
  -H "Authorization: Bearer <TENANT_TOKEN>"

# 7. Suspend the Tenant, then try step 6 again -> 403
curl -s -X PATCH http://localhost:4000/api/platform-admin/tenants/<TENANT_ID>/suspend \
  -H "Authorization: Bearer <ADMIN_TOKEN>"
```

## What's deliberately NOT here yet (future modules)

- Business Profile / Customers / Materials / VAT rate editing → Module 1
- Invoice creation, PDF generation, Credit Notes → Module 2
- Purchases Log, VAT Summary, carried-forward credit → Module 3
- Fine-grained Staff permissions, Audit Log → Module 4
- Supplier-invoice OCR upload/review → Module 5

The `Invoice`/`Purchase`/`Customer`/`Material`/`AuditLog`/`VatRateHistory`
tables already exist in `prisma/schema.prisma` (so Module 0's usage counts
are real, not placeholders) but their business logic is intentionally not
built until their module comes up in the delivery order.
