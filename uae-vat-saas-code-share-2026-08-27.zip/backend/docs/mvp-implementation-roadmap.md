# Ledger — MVP Implementation Roadmap

- **Status:** Version 1 — master execution plan
- **Date:** 2026-07-30
- **Role of this document:** planning only. It does not redesign or reinterpret the [Product Bible](product-bible.md), [ADR-0001](adr/0001-baseline-architecture.md), [MPS](master-product-specification.md), [PAS](platform-architecture-specification.md), [DDS](database-design-specification.md), [SDD](system-design-document.md), [HLD](high-level-design.md), or [UAE VAT Knowledge Base](knowledge-base/README.md) — every scope, module, and rule reference below points back to those documents rather than restating them. The [Business Profile feature spec](features/01-business-profile.md) is the completed precedent every later feature spec is expected to follow.
- **Audience:** the development team, sprint by sprint, from Sprint 1 onward.

---

## Table of Contents

1. [MVP Vision](#1-mvp-vision) · 2. [MVP Success Criteria](#2-mvp-success-criteria) · 3. [MVP Scope](#3-mvp-scope) · 4. [Release Plan](#4-release-plan) · 5. [Sprint Planning](#5-sprint-planning) · 6. [Epic Breakdown](#6-epic-breakdown) · 7. [Feature Dependency Map](#7-feature-dependency-map) · 8. [Feature Implementation Order](#8-feature-implementation-order) · 9. [Definition of Ready](#9-definition-of-ready) · 10. [Definition of Done](#10-definition-of-done) · 11. [Sprint Review Checklist](#11-sprint-review-checklist) · 12. [Sprint Retrospective Template](#12-sprint-retrospective-template) · 13. [Risks](#13-risks) · 14. [Out of Scope](#14-out-of-scope)

---

## 1. MVP Vision

The MVP proves Ledger's core thesis — [MPS §1]/[§2] Business Goal 1 and Goal 3 — for **one business at a time**: that a UAE SME can run its daily operations (Business Profile, Customers, Suppliers, Products/Services, Invoicing, Purchases) on Ledger, and that VAT compliance (correct invoices, an accurate VAT Return) falls out of that daily use rather than requiring separate effort.

The MVP is deliberately the **direct-SME segment only** — Firm/multi-Tenant management is V1, not MVP, per [MPS §7]'s own resolution, itself gated on an architecture decision that is still open ([PAS §25 Decision 1]). This roadmap does not revisit that scope call; it schedules the work MPS already decided belongs in the MVP.

**What the MVP must accomplish, concretely**: a single Tenant, onboarded by a Platform Admin, can complete its Business Profile, record its Customers/Suppliers/Products, issue compliant Sales Invoices and Credit/Debit Notes, log Purchases and Expenses, and generate an accurate VAT Return for a filing period — with multi-tenant isolation holding throughout, and every VAT rule from the Knowledge Base applied automatically, not manually.

---

## 2. MVP Success Criteria

Each criterion is measurable and traceable to the sprint that delivers it — this table is what "the MVP is done" is checked against, not a vibe.

| # | Success Criterion | Measurable as | Delivered by |
|---|---|---|---|
| 1 | A Tenant can be onboarded and its Owner can log in | Already true (Module 0, built) | Pre-Sprint 1 |
| 2 | An Owner can complete a compliant Business Profile | Profile Status reaches `Active` per [Business Profile spec §4] | Sprint 1 |
| 3 | An Owner can manage Customers, Suppliers, and Products/Services | CRUD operations succeed, tenant-scoped | Sprints 2–3 |
| 4 | An Owner can issue a Tax Invoice or Simplified Invoice that satisfies every [KB §5.1]/[§5.2] mandatory field | A generated invoice passes the field checklist in [KB §5.1] without manual correction | Sprint 4 |
| 5 | An Owner can correct an issued invoice via Credit/Debit Note without ever editing the original | Original document remains byte-for-byte unchanged; correction is a new, linked record | Sprint 5 |
| 6 | An Owner can log a Purchase/Expense with correct recoverability classification | A blocked-category expense (entertainment, personal-use vehicle) is automatically flagged, per [KB §4.4] | Sprint 5–6 |
| 7 | A VAT Return is generated entirely from real transactions for a given period | Every figure on the return is traceable to a source Invoice/Purchase — zero manually-entered totals | Sprint 6 |
| 8 | Filing-period deadlines are tracked and surfaced with the concrete penalty at stake | A Tenant approaching its filing deadline sees a reminder before it's late, per [KB §7.2]/[§7.3] | Sprint 7 |
| 9 | **Multi-tenant isolation holds under adversarial testing** | A deliberate attempt to access one Tenant's data using another Tenant's credentials fails, verified in a dedicated test pass, not assumed from code review alone | Sprint 8 |
| 10 | The platform has meaningful automated test coverage | Unit tests for every Service-layer business rule; integration tests for every Repository; E2E tests for authentication, RBAC denial, and tenant isolation — zero today, closed by MVP exit | Sprint 8 |

---

## 3. MVP Scope

Restated from [MPS §7], not redesigned — this section exists so the roadmap is self-contained for planning purposes, with every line pointing back to its source.

| Included (per [MPS §7] MVP row) | Not Included (per [MPS §7] V1/Future rows) |
|---|---|
| Platform Admin & Tenant management (built, Module 0) | Firm/multi-Tenant management ([PAS §25 Decision 1], blocked) |
| Business Profile, Customers, Suppliers, Products/Services, Settings cascade | Custom role definitions, Audit Log viewer, fine-grained permissions (Module 4) |
| Sales/Simplified Invoices, Credit/Debit Notes | UAE e-invoicing full compliance (Peppol/PINT AE) — V1, real 2027 deadline, tracked but not MVP-built |
| Purchases/Expenses with recoverability classification | Supplier-invoice OCR (Module 5) |
| VAT Return generation, filing-period tracking, operational reports | AI bookkeeping/insights, Analytics Dashboard |
| Basic invoice payment status tracking | Full payment reconciliation |
| RBAC-as-data, Configuration cascade, Feature Flags, Notifications (email), Audit write path, Numbering, File Storage — all as thin platform-service builds | Custom-fields engine, workflow engine, global search/command palette |

**Future Roadmap**: unchanged from [MPS §22] — this document does not re-sequence anything beyond the MVP boundary; V1 and Future work begins only after this roadmap's Sprint 8 exit.

---

## 4. Release Plan

**Release 1.0 = the full MVP**, delivered across 8 sprints (below), not one build.

**Why multiple sprints, not a single release**:

| Reason | Detail |
|---|---|
| Incremental risk reduction | Each sprint ships a demonstrable, testable increment — a failure mode is caught at sprint scale, not discovered after months of undemonstrated work. |
| Matches the module-ordered delivery discipline already decided | [ADR §1]/[PAS §2] — this roadmap applies that discipline, it doesn't invent it. |
| Regulatory timing | The UAE e-invoicing mandate and other 2026-era law changes ([KB README]) are actively evolving — periodic checkpoints let the team re-verify assumptions before they're load-bearing, rather than discovering drift at the end. |
| Stakeholder visibility | Incremental, demoable sprints give the project owner real progress signal — [§11]'s Sprint Review Checklist exists specifically to make that visibility concrete, not just a promise. |

---

## 5. Sprint Planning

Story points are **relative**, calibrated against the already-speced [Business Profile feature](features/01-business-profile.md) as the reference anchor (13 points). They size relative complexity for planning, not hours.

### Sprint 1 — Platform Foundations + Business Profile

| | |
|---|---|
| **Sprint Goal** | Stand up the cross-cutting platform services Business Profile itself depends on, then deliver Business Profile end to end. |
| **Business Objective** | Every Tenant can complete a compliant, correctly-gated Business Profile — the compliance foundation every later feature snapshots data from ([KB §1.3]). |
| **Features Included** | RBAC data model + permission middleware; Configuration cascade service; Audit Logging write path; File Storage service; Feature Flags service (bundled — cheap, closes an existing hardcoded-plan-check finding); Business Profile (full spec, [features/01-business-profile.md]). |
| **Business Value** | Unblocks every subsequent sprint — nothing in Module 1–3 can be honestly built without RBAC, Audit, and Business Profile existing first. |
| **Dependencies** | Module 0 (built): Authentication, Tenant Management. |
| **Deliverables** | Working RBAC checks on at least one real endpoint; Audit entries visible for Business Profile's defined sensitive actions; a Tenant can complete and activate its Business Profile end to end, including logo upload. |
| **Estimated Story Points** | **39** (RBAC 8, Configuration 5, Audit 5, File Storage 5, Feature Flags 3, Business Profile 13) — **larger than a typical sprint; if team velocity runs lower than ~30–35 points/sprint, split into Sprint 1a (platform services, 26 pts) and Sprint 1b (Business Profile, 13 pts) rather than compress the work.** |
| **Sprint Demo** | Onboard a test Tenant, complete its Business Profile from empty to `Active`, show the Audit trail recording the activation, show a Staff-role user correctly denied Edit access. |

### Sprint 2 — Customers & Suppliers

| | |
|---|---|
| **Sprint Goal** | A Tenant can maintain its own Customer and Supplier records. |
| **Business Objective** | Reusable counterparty records — the direct prerequisite for Invoicing (Customers) and Purchases (Suppliers). |
| **Features Included** | Customer CRUD; Supplier CRUD — both tenant-scoped, both following the RBAC/Audit/Configuration patterns established in Sprint 1. |
| **Business Value** | No new platform-service risk — proves Sprint 1's foundation is genuinely reusable, the first real test of that bet. |
| **Dependencies** | Sprint 1 (RBAC, Audit, Configuration). |
| **Deliverables** | A Tenant can create, view, edit, and (soft-)remove Customers and Suppliers, each with TRN validation reused from Business Profile's own rule ([KB §1.2]). |
| **Estimated Story Points** | **16** (Customers 8, Suppliers 8) |
| **Sprint Demo** | Create a Customer and a Supplier with valid and invalid TRNs, show correct acceptance/rejection. |

### Sprint 3 — Products/Services + Numbering + Notifications

| | |
|---|---|
| **Sprint Goal** | Complete Module 1's remaining domain entity; build the two platform services Invoicing needs next, just ahead of that need — not speculatively earlier. |
| **Business Objective** | Reusable Product/Service records for invoice line items; a numbering service ready for the first document type that needs it; a notification interface ready for the first event that needs it. |
| **Features Included** | Product/Service CRUD; Numbering service (atomic, tenant-scoped sequence allocation, [KB §8.1]); Notifications service (email-only interface). |
| **Business Value** | Closes out Module 1 entirely; de-risks Sprint 4 by ensuring Invoicing's two hard platform-service dependencies already exist and are tested in isolation first. |
| **Dependencies** | Sprint 1 (RBAC, Audit, Configuration, File Storage), Sprint 2 pattern reuse. |
| **Deliverables** | Product/Service CRUD; a numbering service that survives a concurrency test (two near-simultaneous allocation requests never collide or skip); a working email notification through the abstraction layer. |
| **Estimated Story Points** | **18** (Products/Services 8, Numbering 5, Notifications 5) |
| **Sprint Demo** | Create a Product/Service; demonstrate the Numbering service allocating sequential values under simulated concurrent requests; send a test notification end to end. |

### Sprint 4 — Sales & Simplified Invoicing

| | |
|---|---|
| **Sprint Goal** | A Tenant can issue a compliant Sales Invoice or Simplified Invoice. |
| **Business Objective** | The first genuinely revenue-facing capability — the moment Ledger produces a real, legally-usable document. |
| **Features Included** | Multi-line invoice creation with per-line VAT category ([KB §2.1]); automatic full-vs-simplified determination ([KB §5.2]); discounts ([KB §5.5]); numbering integration; email notification on issuance. |
| **Business Value** | The clearest, most demonstrable MVP milestone — everything before this sprint was foundation; this is the first feature a Tenant would actually pay for. |
| **Dependencies** | Sprints 1–3 in full (RBAC, Audit, Configuration, Customers, Products/Services, Numbering, Notifications). |
| **Deliverables** | An issued invoice satisfying every [KB §5.1] mandatory field; correct full/simplified determination; correct VAT calculation and rounding ([KB §8.4]); immutability enforced (no edit/delete path exists). |
| **Estimated Story Points** | **18** (core issuance 13, discounts 5) |
| **Sprint Demo** | Issue a Standard Rated invoice and a Zero Rated (export) invoice in the same session, show both render correctly, show an edit attempt on an issued invoice is rejected by design (no such control exists). |

### Sprint 5 — Invoice Corrections + Purchases Core

| | |
|---|---|
| **Sprint Goal** | Complete Module 2's correction mechanics; begin Module 3 with core Purchase/Expense recording. |
| **Business Objective** | A Tenant can correct a mistake without ever mutating a legal document, and can start recording the input side of its VAT position. |
| **Features Included** | Credit Notes and Debit Notes ([KB §5.3]/[§5.4]); Purchase/Expense entry with recoverability classification ([KB §4.2]–[§4.4]), including automatic blocked-category flagging. |
| **Business Value** | Closes the most common real-world need (a return, a pricing error) and opens Module 3, the platform's compliance core. |
| **Dependencies** | Sprint 4 (Invoicing, for Credit/Debit Note references); Sprint 2 (Suppliers). |
| **Deliverables** | A Credit Note correctly reducing a prior invoice's reported VAT; a blocked-category Purchase (e.g., client entertainment) automatically flagged non-recoverable rather than silently accepted. |
| **Estimated Story Points** | **21** (Credit/Debit Notes 8, Purchases/Expenses core 13) |
| **Sprint Demo** | Issue a Credit Note against a Sprint 4 invoice; log a Purchase that should be blocked and show the system catching it before the user does. |

### Sprint 6 — Reverse Charge/Imports + VAT Return Engine

| | |
|---|---|
| **Sprint Goal** | Complete Purchases' remaining complexity; deliver the VAT Return generation engine — the platform's single most important calculation. |
| **Business Objective** | The compliance payoff of every prior sprint becomes real: a correct, derived-not-entered VAT Return. |
| **Features Included** | Import/reverse-charge purchase handling ([KB §3.1]/[§3.3]); VAT Return generation, aggregating output VAT, recoverable input VAT, and adjustments by category ([KB §7.1]). |
| **Business Value** | This is the feature the entire MVP has been building toward — everything in Sprints 1–5 exists to make this sprint's output correct. |
| **Dependencies** | Sprints 4–5 in full (Invoicing and Purchases must both be real before a return can aggregate them). |
| **Deliverables** | A VAT Return for a test period whose every figure is traceable to a real transaction; correct self-accounted reverse-charge entries appearing as both output and input tax. |
| **Estimated Story Points** | **18** (reverse charge/imports 5, VAT Return engine 13) |
| **Sprint Demo** | Generate a full VAT Return for a period containing standard-rated sales, an import, and a Credit Note; walk through each figure back to its source transaction live. |

### Sprint 7 — Filing Support, Reporting, Payments

| | |
|---|---|
| **Sprint Goal** | Complete Module 3's remaining MVP scope — the features that make the VAT Return genuinely usable in practice, not just technically correct. |
| **Business Objective** | Turn a correct calculation into a usable compliance workflow: deadlines tracked, reports available, payments visible. |
| **Features Included** | Filing-period tracking and deadline reminders with penalty-at-stake messaging ([KB §7.2]/[§7.3]); operational reports (sales/purchase registers, statements); basic invoice payment status; bad debt relief ([KB §5.7]); carry-forward tranche tracking with expiry warnings ([KB §4.3]). |
| **Business Value** | This is where [MPS §2] Business Goal 3 ("zero avoidable FTA penalties") becomes a real, demonstrable product behavior, not just a design intention. |
| **Dependencies** | Sprint 6 (VAT Return engine). |
| **Deliverables** | A visible, correct countdown to the next filing deadline; a sales register report matching the underlying invoices exactly; a marked-paid invoice reflected correctly in reporting. |
| **Estimated Story Points** | **26** (filing reminders 5, reports 8, payment status 5, bad debt relief 3, carry-forward tracking 5) |
| **Sprint Demo** | Show the filing-deadline countdown with penalty messaging; generate a sales register and cross-check it manually against issued invoices; mark an invoice paid and show it reflected in a report. |

### Sprint 8 — Hardening & MVP Launch Readiness

| | |
|---|---|
| **Sprint Goal** | Close every remaining correctness, security, and quality gap before calling the MVP done — this sprint verifies the whole assembled system, it does not introduce new business features. |
| **Business Objective** | Confidence that Release 1.0 is genuinely production-appropriate, not just feature-complete. |
| **Features Included** | Closing test-coverage gaps not already met by each sprint's own Definition of Done ([§10]); a dedicated multi-tenant isolation adversarial test pass; a security review pass (rate limiting, Platform Admin MFA, session-revocation groundwork per [PAS §10]); a pagination/performance pass on any list endpoint that's grown data-heavy; backup/DR setup, contingent on the still-open deployment vendor decision ([ADR §12]); a full documentation sync across every doc in this set. |
| **Business Value** | This is the sprint that converts "it works in the demo" into "it's safe to put a real business's compliance data into." |
| **Dependencies** | All prior sprints. |
| **Deliverables** | A documented, executed multi-tenant isolation test with a clean result; meaningful automated test coverage across every module built so far; a closed list of known security gaps with each explicitly resolved or explicitly deferred with a reason. |
| **Estimated Story Points** | **36** (test coverage closure 13, security pass 8, isolation verification 5, performance pass 5, backup/DR 3, documentation sync 2) — **also larger than typical; note explicitly in [§13] that under-budgeting this sprint is the single most tempting place to cut corners, and the roadmap recommends against compressing it.** |
| **Sprint Demo** | Live-run the multi-tenant isolation adversarial test in front of stakeholders; walk through the closed security-gap list; show test coverage reporting. |

**Testing is not only Sprint 8's job** — every sprint's own Definition of Done ([§10]) already requires unit and integration tests for that sprint's features. Sprint 8 closes what's left and performs the *integrated, whole-system* verification no single earlier sprint could do alone.

---

## 6. Epic Breakdown

| Sprint | Epic | Features | Dependencies |
|---|---|---|---|
| 1 | Platform Services Foundation & Business Profile | RBAC, Configuration, Audit, File Storage, Feature Flags, Business Profile | Module 0 (built) |
| 2 | Tenant Counterparty Records | Customers, Suppliers | Sprint 1 |
| 3 | Products & Pre-Invoicing Platform Services | Products/Services, Numbering, Notifications | Sprints 1–2 |
| 4 | Sales Invoicing | Invoice/Simplified Invoice issuance, Discounts | Sprints 1–3 |
| 5 | Invoice Corrections & Purchases Foundation | Credit/Debit Notes, Purchases/Expenses core | Sprints 2, 4 |
| 6 | VAT Compliance Engine | Reverse charge/imports, VAT Return generation | Sprints 4–5 |
| 7 | Filing, Reporting & Payments | Filing reminders, Operational reports, Payment status, Bad debt relief, Carry-forward tracking | Sprint 6 |
| 8 | Launch Readiness | Test coverage, Security hardening, Isolation verification, Performance, Backup/DR, Documentation | All prior |

---

## 7. Feature Dependency Map

```mermaid
graph TD
    Login["Platform Login (built, Module 0)"]
    Tenant["Tenant Management (built, Module 0)"]
    PlatformSvcs["Platform Services:\nRBAC, Audit, Config, File Storage, Feature Flags"]
    BP["Business Profile"]
    CustSupp["Customers & Suppliers"]
    Products["Products/Services"]
    NumberNotify["Numbering + Notifications"]
    Invoicing["Sales & Simplified Invoicing"]
    Corrections["Credit/Debit Notes"]
    Purchases["Purchases & Expenses"]
    Reverse["Reverse Charge / Imports"]
    VATReturn["VAT Return Engine"]
    Filing["Filing, Reporting, Payments"]
    Hardening["Hardening & Launch Readiness"]

    Login --> Tenant --> PlatformSvcs --> BP
    BP --> CustSupp
    CustSupp --> Products
    Products --> NumberNotify
    NumberNotify --> Invoicing
    CustSupp --> Purchases
    Invoicing --> Corrections
    Corrections --> Purchases
    Purchases --> Reverse
    Invoicing --> VATReturn
    Reverse --> VATReturn
    VATReturn --> Filing
    Filing --> Hardening
    Corrections --> Hardening
```

**Why this order is required**:

| Dependency | Reason it can't be reordered |
|---|---|
| Platform Services before Business Profile | Business Profile's own spec ([features/01-business-profile.md §9]) names RBAC, Audit, File Storage, and Configuration as hard dependencies — it cannot be built first. |
| Business Profile before everything else | Every later document snapshots Business Profile fields ([KB §1.3]) — building Invoicing before Business Profile exists would have nothing correct to snapshot. |
| Customers/Suppliers before Invoicing/Purchases | An Invoice needs a Customer to reference; a Purchase needs a Supplier — [PAS §6]'s domain dependency graph already fixes this direction. |
| Numbering before Invoicing | [KB §8.1] requires every tax invoice to carry a sequential number *at issuance* — the service must exist before the first invoice can legally be issued. |
| Invoicing before Credit/Debit Notes | A correction document must reference an original ([KB §5.3]) — the original type must exist first. |
| Invoicing and Purchases before the VAT Return | The Return is derived, never entered ([KB §7.1]) — it has nothing to aggregate until both sides of the ledger exist. |
| Everything before Hardening | Isolation and security verification are only meaningful against the whole assembled system, not a partial one. |

---

## 8. Feature Implementation Order

The same pipeline, per feature, throughout the roadmap — matching [HLD]'s actual layering (Express, not the originally-requested NestJS, per the resolution already recorded in that document):

```mermaid
flowchart TD
    A["Feature Specification\n(per the Business Profile precedent)"] --> B["Data Model Design\n(per DDS standards — no schema written here)"]
    B --> C["Prisma Schema Update"]
    C --> D["Migration"]
    D --> E["Backend: Repository -> Service -> Controller\n(per HLD §6/§7/§8)"]
    E --> F["Route / API wiring\n(Express, per HLD §4)"]
    F --> G["Frontend: Next.js pages, components\n(per HLD §3)"]
    G --> H["Integration"]
    H --> I["Testing: Unit, Integration, E2E\n(per HLD §20)"]
    I --> J["Sprint Demo"]
```

Every feature in [§5]'s sprints follows this exact sequence — no feature skips a step, and no step happens out of order (e.g., a migration is never written before the data model design it implements has been reviewed against [DDS §21]'s checklist).

---

## 9. Definition of Ready

A feature may enter a sprint only when **all** of the following are true:

| Requirement | Detail |
|---|---|
| **Required documents** | A feature specification exists, following the [Business Profile precedent](features/01-business-profile.md) — Executive Summary through Future Consumers, including its own Review Board pass. No feature starts from a raw field list. |
| **Business approval** | The project owner has explicitly reviewed and accepted the feature spec — including any Review Board findings that changed the original scope, per the same discipline applied to Business Profile. |
| **Acceptance criteria defined** | Derived directly from the spec's Functional Requirements and Business Rules sections — not invented ad hoc during development. |
| **Dependencies completed** | Every upstream feature/platform service in [§7]'s map has already passed its own Sprint Demo — "in progress" is not "completed." |

---

## 10. Definition of Done

A feature is complete only when **all** of the following hold:

- **Backend complete** — Repository, Service, and Controller layers implemented per [HLD §6]/[§7]/[§8], with no business logic in the Controller layer ([ADR §13.1]).
- **Frontend complete** — fully functional on desktop, tablet, and mobile, per the Mobile First principle ([MPS §1]) — not desktop-only with mobile "to follow."
- **Integrated** — frontend and backend verified working end to end, not just independently passing their own tests.
- **Tested** — unit tests for Service-layer business rules, integration tests for the Repository layer, and (for the features named in [§2]'s success criteria) E2E coverage, per [HLD §20].
- **Security validated** — every mutating endpoint enforces RBAC via `requirePermission()` ([HLD §12]), every input is server-side validated ([HLD §10]), no endpoint trusts a client-supplied tenant identifier ([ADR §6]/[§7]).
- **Multi-tenant isolation verified** — a specific, executed test attempting cross-tenant access fails as expected; not inferred from code review alone.
- **Documentation updated** — the feature's own spec reflects what was actually built (not just what was planned), and any of the platform-level documents (Product Bible, MPS, PAS, DDS) that the feature's implementation genuinely affected are updated to match, per [ADR §13.3]'s discipline.

---

## 11. Sprint Review Checklist

Run at the end of every sprint, before calling it closed:

- [ ] Every feature in the sprint's scope meets the full [§10] Definition of Done — no partial credit.
- [ ] The Sprint Demo (as described in [§5]) was actually performed, live, not described secondhand.
- [ ] Every Sprint Success Criterion this sprint was responsible for ([§2]) is demonstrably met.
- [ ] No feature was descoped or simplified without the project owner's explicit sign-off.
- [ ] No architectural or business-rule deviation occurred without a corresponding documented decision, per [ADR §13.3].
- [ ] Any new open question or assumption surfaced during the sprint has been added to the appropriate register ([Product Bible §12] or [PAS §25]/[DDS §22] as applicable) — not left undocumented.
- [ ] Test coverage for this sprint's features is real and passing, not deferred to "later."
- [ ] The next sprint's Definition of Ready ([§9]) is confirmed satisfied before it starts.

---

## 12. Sprint Retrospective Template

**What went well?**
_(Specific, not generic — cite the feature/decision, not just "communication.")_

**What didn't go well?**
_(Same standard — a vague complaint is not actionable.)_

**Did we introduce any hardcoded business logic, role-string checks, or plan-string comparisons that should have gone through a platform service instead?**
_(A standing, project-specific retro question — this is the failure mode this whole document set exists to prevent; ask it every sprint, not just when something visibly breaks.)_

**Did we skip or defer any tests this sprint, and why?**
_(Tracked explicitly — a deferred test is a debt, not a decision to forget.)_

**Did any feature reveal a gap in an upstream document (Product Bible, MPS, PAS, DDS, SDD, HLD, Knowledge Base)?**
_(If yes: was it corrected in that document, per [ADR §13.3], or only patched in code? The former is required.)_

**Action items for next sprint**
_(Owner, and a real due date — not a running list that never closes.)_

---

## 13. Risks

| Risk | Category | Mitigation |
|---|---|---|
| Zero automated test coverage exists today (Module 0) | Technical | Every sprint's Definition of Done ([§10]) requires tests going forward; Sprint 8 closes the backlog — but the risk is real *now*, not hypothetical. |
| The Firm/multi-Tenant access architecture question is still unresolved | Architectural | Does not block this MVP roadmap (V1 scope), but a late resolution could still force rework in Business Profile's access patterns if decided badly — recommend resolving it during, not after, this roadmap's execution. |
| Row-Level Security (the second tenant-isolation layer) isn't active yet — isolation currently rests entirely on application-layer discipline | Architectural | Sprint 8's isolation verification is the load-bearing check until RLS lands post-migration ([PAS §25 Decision 4]) — treat that test as mandatory, not optional. |
| The deployment vendor is still undecided ([ADR §12]) | Technical/Product | Blocks quantified backup/DR targets and real staging verification — Sprint 8 can only do what's possible pre-vendor; flag remaining gaps explicitly rather than silently skipping them. |
| UAE VAT law is actively changing through 2026 (input VAT carry-forward cap, e-invoicing mandate) | Product | Re-verify [KB]-sourced rules immediately before the sprint that implements them ([KB README]'s own guidance) — don't assume this roadmap's understanding stays current by default. |
| Sprint 1 and Sprint 8 are both larger than typical | Product/Process | Flagged explicitly in [§5] with a stated fallback (split Sprint 1; don't compress Sprint 8) rather than discovered as a surprise mid-execution. |
| Scope pressure from the platform's own stated enterprise ambition ([MPS §1] Horizon 2) | Product | This roadmap is MVP-only by design ([§3]) — any pressure to pull V1/Future work forward should be checked against [§3]'s explicit boundary before being accepted. |

---

## 14. Out of Scope

Everything below is **not** part of this roadmap's 8 sprints — restated from [MPS §7]/[§13] for planning clarity, not redecided:

- Firm/multi-Tenant management (V1, blocked on [PAS §25 Decision 1])
- Module 4: custom role definitions, Audit Log viewer UI, fine-grained permissions beyond the RBAC data model itself
- Module 5: supplier-invoice OCR
- Full UAE e-invoicing (Peppol/PINT AE) compliance — tracked as a real 2027 deadline, but a V1 delivery, not an MVP one
- AI bookkeeping assistant, AI-generated reports/insights
- Analytics Dashboard (distinct from Sprint 7's operational reports)
- Full payment reconciliation (bank/gateway matching) — only basic payment status is in MVP
- Custom-fields engine, visual workflow builder, global search/command palette
- Capital Assets Scheme, Tax Group registration, full Designated Zone support
- Direct EmaraTax filing submission
- Arabic/bilingual UI
- Any third-party integration (payment gateways, banking, accounting software, government APIs) beyond the interfaces already built to accommodate them later

If any item above is pulled forward, it requires an explicit scope decision from the project owner and an update to this roadmap — never a quiet addition to a sprint already in flight.
