# Tenant Management — Implementation Phase 7: Frontend Specification

- **Status:** Proposed specification — **no React code generated yet**, per the explicit instruction to wait for approval before implementation
- **Date:** 2026-07-30
- **Consumes exactly**: the [Phase 5 API Layer](08-tenant-management-api-layer.md) and [Phase 6 Auth Layer](09-tenant-management-auth-layer.md) (both Approved) — no endpoint, route name, or response shape invented or altered.
- **Stack**: Next.js App Router, plain JavaScript ([ADR §2], TypeScript still an open, undecided item — no `types/` folder below, noted not omitted by accident), React state + `localStorage` (no external state library, [ADR §2]) — unchanged from the existing, shipped Module 0 frontend.
- **Four API-coverage gaps found and resolved for now, not silently**: see the note above this document. Each is designed around honestly below, with a Future Improvement flagged at [§11] rather than fabricated data or an invented endpoint.

---

## 1. Folder Structure

Extends the existing frontend layout — nothing renamed, nothing reorganized:

```
frontend/
  app/
    admin/
      dashboard/            existing - unchanged
      tenants/                NEW - Tenant Management pages
        page.js                 Tenant List (see note below on Dashboard)
        new/
          page.js                Create Tenant
        [id]/
          page.js                Tenant Details
  components/
    tenant-management/       NEW feature-grouped folder
      TenantStatusBadge.js
      tables/
        TenantTable.js
      dialogs/
        InviteOwnerDialog.js
        ResendInvitationDialog.js
        SuspendTenantDialog.js
        ActivateTenantDialog.js
        ArchiveTenantDialog.js
      hooks/
        useTenantList.js
        useTenantDetails.js
      constants/
        tenantStatus.js         labels, allowed-transition map, badge treatment
  lib/
    api.js                    EXTENDED (§4) - the existing "service" layer; no new services/ folder invented
  # types/  -- not created: no TypeScript adopted yet (ADR §2, still open)
  # utils/  -- not created: nothing in this feature needs a utility beyond what lib/ already provides
```

**On "pages"**: per [UX Blueprint §1], Tenant List *is* the Platform Dashboard for Sprint 1 — there is still no separate dashboard content to justify two screens. `app/admin/tenants/page.js` is what a future `app/admin/dashboard` redirect (or the existing dashboard route itself) would point to; this spec doesn't relocate the existing `dashboard/` route, only builds the List/Create/Details pages fresh.

---

## 2. Pages

### Tenant List (`app/admin/tenants/page.js`)

| Element | Behavior |
|---|---|
| Data source | `GET /tenants` (unparameterized, per approved API) — fetched once on mount via `useTenantList` |
| Columns | Company Name, Plan, Status (badge, [§7]), Created Date (`createdAt`), Created By (`tenant.createdByAdmin?.email ?? "—"` — see gap #1) |
| Search | **Client-side only** — filters the already-fetched array by Company Name substring, case-insensitive (gap #3) |
| Pagination | **Client-side only** — chunks the filtered array, page-number controls, matching [UX Blueprint §7]'s design; server-side is a [§11] Future Improvement |
| Row actions | Status-dependent, never a static set: `DRAFT` → Invite Owner; `INVITED` → Resend Invitation; `ACTIVE` → Suspend; `SUSPENDED` → Activate, Archive; `ARCHIVED` → none (view only) — every row always has "View" |
| Loading state | Skeleton table rows, not a spinner-only screen |
| Empty state | Existing Module 0 copy pattern, reused: "No Tenants yet — onboard your first business to get started," with the Create Tenant CTA inline |
| Error state | Inline error banner (existing pattern) + a Retry action that re-runs the fetch — never a silent failure |

### Create Tenant (`app/admin/tenants/new/page.js`)

| Element | Behavior |
|---|---|
| Fields | Company Name, Subscription Plan **only** — Owner Name/Email are not collected here, confirmed against [Phase 4's finding] |
| Buttons | "Save Draft" (primary), "Cancel" (secondary, returns to Tenant List without submitting) |
| On submit | `POST /tenants` → on success, navigate to the new Tenant's Details page |
| Duplicate-name warning | The API's `warnings` array ([Phase 4 §1]) is rendered as a **non-blocking** inline notice above the form after a successful create — the Tenant is still created and navigation still proceeds; the warning is informational, never a validation failure |

### Tenant Details (`app/admin/tenants/[id]/page.js`)

| Section | Behavior |
|---|---|
| Tenant Information | Company Name, Plan, Tenant ID |
| Current Status | Badge ([§7]) |
| Timeline | **Limited to what's actually available**: "Created [createdAt]" and, if `updatedAt ≠ createdAt`, "Last changed [updatedAt]" — not the multi-step history the UX Blueprint's wireframe sketched, since no Audit Log read endpoint exists yet. A one-line note: "Full history will be available once Audit Log viewing ships (Module 4)." |
| Invitation Information | Rendered **only** when `status === "INVITED"`: "An invitation has been sent and is pending acceptance," with a Resend Invitation action — no invented sent-date or expiry countdown, since `getTenantById` doesn't return that data (gap #2) |
| Audit History | Explicit placeholder block: "Audit history will be available in a future update." — never a fake or empty-looking table pretending to be functional |
| Available Actions | Same status-dependent set as the List row actions, rendered as primary buttons here rather than a menu |

---

## 3. Dialogs

All five build on the existing Confirmation Modal component ([UX Blueprint §5]) — no new dialog pattern introduced.

| Dialog | Fields | Validation | On confirm |
|---|---|---|---|
| **Invite Owner** | Owner Name, Owner Email | Client-side: name 1–100 chars, email format ([§5]) — mirrors [Phase 5]'s validation middleware exactly | `POST /tenants/:id/invite` — API errors (e.g., duplicate email, 409) shown inline in the dialog, not as a page-level banner, so the user doesn't lose their place |
| **Resend Invitation** | None | None | `POST /tenants/:id/resend-invitation` |
| **Suspend Tenant** | Optional "Reason" text field | None | `PATCH /tenants/:id/suspend` — **the Reason field is never sent**; the approved API takes no such parameter (see the note above this document). Local-only, discarded on submit. |
| **Activate Tenant** | None | None | `PATCH /tenants/:id/activate` |
| **Archive Tenant** | None | None | `PATCH /tenants/:id/archive` — copy and button treatment exactly as [UX Blueprint §8] specified (strong, permanent-framing wording, standard Primary/Secondary buttons). A stricter "type the tenant name to confirm" pattern was considered and **not implemented** — the UX Blueprint is an approved document this phase doesn't redesign; flagged as a [§11] Future Improvement instead of added unilaterally. |

---

## 4. API Integration

Extends `lib/api.js`'s existing pattern — every path matches [Phase 5] exactly, nothing invented:

```js
export const api = {
  // ...existing methods (adminLogin, tenantLogin, listTeam, etc.) unchanged...

  // Tenant Management (Sprint 1)
  listTenants: (token) =>
    request("/api/platform-admin/tenants", { token }),
  getTenantDetails: (token, id) =>
    request(`/api/platform-admin/tenants/${id}`, { token }),
  createTenant: (token, { name, plan }) =>
    request("/api/platform-admin/tenants", { method: "POST", token, body: { name, plan } }),
  inviteOwner: (token, id, { ownerName, ownerEmail }) =>
    request(`/api/platform-admin/tenants/${id}/invite`, { method: "POST", token, body: { ownerName, ownerEmail } }),
  resendInvitation: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/resend-invitation`, { method: "POST", token }),
  suspendTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/suspend`, { method: "PATCH", token }),
  activateTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/activate`, { method: "PATCH", token }),
  archiveTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/archive`, { method: "PATCH", token }),
};
```

No `/reactivate` alias is added for backward compatibility — the old path is gone per [Phase 5]'s deliberate rename; this frontend is written against the new one directly, consistent with the instruction to consume the approved APIs exactly as they are, not as they used to be.

---

## 5. Form Validation

Client-side rules are a **preview** of the server's, never an independent or stricter source of truth:

| Field | Client check | Matches |
|---|---|---|
| Company Name | 1–200 chars | [Phase 5]'s `validateCreateTenant` |
| Plan | Non-empty, one of the known plan values | Same |
| Owner Name | 1–100 chars | [Phase 5]'s `validateInviteOwner` |
| Owner Email | Basic email format | Same |

**Display**: inline, field-level errors for client-side failures (immediate, no round trip); a dialog- or page-level banner for API errors (duplicate email, invalid state transition, etc.) — since those can only be known after a server round trip, they're never conflated with instant client-side feedback. Duplicate-name warnings ([§2]) are visually distinct from both — a neutral notice, not an error color, since the action already succeeded.

---

## 6. State Management

- Plain `useState`/`useEffect` per page and custom hook, matching the existing codebase exactly — no Redux/Zustand/React Query introduced.
- `useTenantList()` — fetch on mount, exposes `{ tenants, loading, error, refetch }`.
- `useTenantDetails(id)` — same shape, scoped to one Tenant.
- **Optimistic updates: deliberately none in this feature.** Every mutation here (Suspend/Activate/Archive/Invite/Resend) is a deliberate, dialog-confirmed action the backend can still reject based on the state machine (e.g., archiving a Tenant that's since moved back to `ACTIVE` in another tab). These are infrequent, already-friction-gated actions where a brief loading state during the real request is safer and simpler than an optimistic update plus a rollback path — correctness over perceived speed, a deliberate choice, not an oversight.
- Success feedback: a toast ([UX Blueprint §5]/[§9]) on every successful mutation, plus the page/list re-fetching to reflect the new state — never a client-side guess at what the new state should look like.
- Retry: the List/Details error states both expose a Retry action calling the same fetch again — no automatic retry-with-backoff (that's a [§11] Future Improvement, not needed for a user-initiated page load).

---

## 7. Status Handling

Extends the Stamp/Tag distinction already established in [UX Blueprint §5] — not a new visual language:

| Status | Badge treatment | Tooltip | Allowed actions | Disabled actions (and why) |
|---|---|---|---|---|
| `DRAFT` | Tag | "Awaiting Owner invitation" | Invite Owner, Edit *(not built this phase)* | Suspend, Activate, Archive, Resend — disabled because none of these are reachable before an Owner has ever been invited ([Tenant Management spec §4]'s lifecycle) |
| `INVITED` | Tag | "Invitation sent, awaiting Owner response" | Resend Invitation | Suspend, Activate, Archive — disabled because the Tenant has no active Owner session yet to suspend/activate; Invite Owner — disabled because one is already pending (use Resend instead) |
| `ACTIVE` | Stamp | "In good standing" | Suspend | Activate — disabled, already active; Archive — disabled, "Archive requires suspending first" (directly surfaces [Tenant Management spec §4 Rule 4] in the UI, not just the API's 409) |
| `SUSPENDED` | Stamp | "Access temporarily blocked — reversible" | Activate, Archive | Suspend — disabled, already suspended; Invite/Resend — disabled, invitation lifecycle already completed |
| `ARCHIVED` | Stamp | "Permanently closed — historical data retained" | None | Every action disabled — "This Tenant has been archived and can no longer be modified" |

Every disabled action shows its reason in a tooltip on hover/focus, not just a grayed-out button with no explanation — directly addressing the instruction to explain, not just disable.

---

## 8. Permissions

No new permission logic — the entire `app/admin/tenants/*` surface sits inside the existing `AdminLayout`, which already redirects to `/admin/login` if no Platform Admin token is present ([Module 0], unchanged). Per [Phase 6 Auth Layer], Tenant Management has exactly one authorized role — Platform Admin — and no finer-grained permission exists to check beyond that. **Admin, Accountant, Viewer, and any custom role are not introduced here**, consistent with the explicit instruction and with every prior phase's resolution of the same question.

---

## 9. Responsive Design

No new responsive pattern — applies [UX Blueprint §9] to these specific components:

| Element | Desktop | Tablet/Mobile |
|---|---|---|
| Tenant List table | Full table | Stacks into cards — Company Name as title, Plan/Status/Created as labeled rows, Actions as a menu |
| Create Tenant form | Single column (already only 2 fields) | Unchanged — no layout difference needed at this field count |
| Tenant Details | Sectioned single column | Unchanged |
| All five dialogs | Centered modal | Full-screen sheet |

---

## 10. Accessibility

No new accessibility pattern — applies [UX Blueprint §10] concretely:

- Every dialog traps focus while open and returns it to the triggering button on close (most important here given how many status-dependent action buttons exist per row).
- Status badges are never color-only — every badge carries its status as visible text (`"Active"`, `"Suspended"`, etc.), satisfying color-independent status communication without a separate icon system.
- Disabled action buttons remain keyboard-focusable (not `display: none`) specifically so their tooltip's explanation ([§7]) is reachable via keyboard/screen reader, not just mouse hover.
- The duplicate-name warning and toast notifications use an ARIA live region, so they're announced without requiring the user to be visually looking at the right part of the screen at the right moment.

---

## 11. Frontend Review

| Area | Assessment |
|---|---|
| **UX consistency** | Holds — every new component reuses an existing pattern (Stamp/Tag, Confirmation Modal, error banner, toast) rather than introducing a new one; the one place a stronger pattern was considered (Archive's confirmation) was deliberately *not* added, to stay inside the approved UX Blueprint. |
| **API integration** | Clean 1:1 mapping to [Phase 5]'s approved routes, no invented endpoints — verified explicitly in [§4]. |
| **Loading experience** | Skeleton rows on List, standard loading state on Details/Create — consistent with the existing codebase's minimal-but-present loading treatment. |
| **Error handling** | Three distinct tiers (client validation / API error / duplicate-warning notice) never visually conflated — a genuine improvement in precision over Module 0's current single generic error-banner pattern. |
| **Responsiveness** | Fully specified per [§9], no gaps against the approved Mobile Behaviour table. |
| **Accessibility** | Fully specified per [§10]; the keyboard-focusable-disabled-button detail is a real, non-obvious requirement worth calling out to whoever implements this, since it's easy to accidentally use `disabled` HTML attribute (which removes focusability entirely) instead of an ARIA-disabled pattern that preserves it. |
| **Performance** | Client-side pagination/search (gaps #3) means the entire Tenant list downloads on every visit — acceptable at MVP volumes, a real limitation at Firm-scale. |

### Future UI Improvements (backend unchanged, flagged for later sprints)

1. Server-side pagination and search on `GET /tenants`, once Tenant volumes justify it (ties to [DDS §14]/[SDD §18]'s already-planned cursor pagination).
2. `listTenants`/`getTenantById` including the `createdByAdmin` relation, so "Created By" shows a name instead of falling back to "—".
3. A way to retrieve the current live Invitation's sent/expiry dates on page load — either an included relation or a dedicated endpoint — to complete the Invitation Information section as originally sketched.
4. An Audit Log read endpoint (Module 4/V1) to replace both the Timeline's limited view and the Audit History placeholder with real data.
5. A stronger, "type to confirm," Archive dialog pattern — a genuine UX improvement, deliberately not added this phase since it would exceed the approved UX Blueprint.
6. Automatic retry-with-backoff for transient network failures, beyond the current manual Retry action.

---

**STOP — awaiting approval before generating the React implementation.**
