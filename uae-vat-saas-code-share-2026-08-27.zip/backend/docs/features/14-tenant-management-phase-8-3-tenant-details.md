# Tenant Management — Phase 8.3: Tenant Details

- **Status:** Proposed — **not yet applied to `frontend/`**; awaiting approval before Phase 8.4
- **Date:** 2026-07-30
- **Consumes**: `GET /tenants/:id` only, via the approved `api.getTenantDetails()` ([Phase 5]/[Phase 8]) — see finding #1 above on the method name. Reuses `TenantStatusBadge` ([Phase 8.1]), `PlanTag` (existing), `Card`/`ErrorBanner`/`LoadingSkeleton`/`EmptyState` ([Phase 8]) — no shared component modified.
- **No mutations, no dialogs** — every action (Suspend/Activate/Archive/Invite/Resend) is Phase 8.4, not built here.

---

## `app/admin/tenants/[tenantId]/page.js`

```jsx
"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import EmptyState from "../../../../components/ui/EmptyState";
import TenantHeader from "../../../../components/tenant-management/TenantHeader";
import TenantOverviewCard from "../../../../components/tenant-management/TenantOverviewCard";
import TenantOwnerCard from "../../../../components/tenant-management/TenantOwnerCard";
import TenantActivityCard from "../../../../components/tenant-management/TenantActivityCard";

export default function TenantDetailsPage() {
  const { tenantId } = useParams();
  const router = useRouter();

  const [tenant, setTenant] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantId]);

  async function load() {
    setLoading(true);
    setError("");
    setNotFound(false);
    try {
      const token = adminAuth.get();
      const { tenant } = await api.getTenantDetails(token, tenantId);
      setTenant(tenant);
    } catch (err) {
      // The API returns a plain message string, not a structured error
      // code (Known Backend Gap below) - "not found" is detected by
      // matching Phase 5's exact controller message.
      if (err.message && err.message.toLowerCase().includes("not found")) {
        setNotFound(true);
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  }

  const backLink = (
    <button className="btn btn-outline" onClick={() => router.push("/admin/tenants")} style={{ marginBottom: 16 }}>
      ← Back to Tenants
    </button>
  );

  if (loading) {
    return <LoadingSkeleton rows={4} columns={2} />;
  }

  if (notFound) {
    return (
      <div>
        {backLink}
        <EmptyState>This Tenant could not be found. It may have been removed, or the link may be incorrect.</EmptyState>
      </div>
    );
  }

  if (error) {
    return (
      <div>
        {backLink}
        <ErrorBanner message={error} />
        <button className="btn btn-outline" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div>
      <TenantHeader tenant={tenant} />
      <TenantOverviewCard tenant={tenant} />
      <TenantOwnerCard tenant={tenant} />
      <TenantActivityCard tenant={tenant} />
    </div>
  );
}
```

---

## `components/tenant-management/TenantHeader.js`

```jsx
import Link from "next/link";
import TenantStatusBadge from "./TenantStatusBadge";
import PlanTag from "../PlanTag";

export default function TenantHeader({ tenant }) {
  return (
    <header>
      <Link href="/admin/tenants" className="btn btn-outline" style={{ marginBottom: 16 }}>
        ← Back to Tenants
      </Link>
      <div className="page-header">
        <div>
          <h1>{tenant.name}</h1>
          <div className="tenant-header-meta">
            <TenantStatusBadge status={tenant.status} />
            <PlanTag plan={tenant.plan} />
            <span className="mono helptext">Created {new Date(tenant.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
```

*(`Back to Tenants` is a `Link` styled with the existing `.btn-outline` class, not the `Button` component — same reasoning already recorded in [Phase 8.1]/[8.2]: `Button` has no link-rendering mode.)*

## `components/tenant-management/TenantOverviewCard.js`

```jsx
import Card from "../ui/Card";
import TenantStatusBadge from "./TenantStatusBadge";
import PlanTag from "../PlanTag";

export default function TenantOverviewCard({ tenant }) {
  return (
    <Card>
      <h2>Overview</h2>
      <dl className="tenant-detail-list">
        <div>
          <dt>Tenant ID</dt>
          <dd className="mono">{tenant.id}</dd>
        </div>
        <div>
          <dt>Company Name</dt>
          <dd>{tenant.name}</dd>
        </div>
        <div>
          <dt>Status</dt>
          <dd>
            <TenantStatusBadge status={tenant.status} />
          </dd>
        </div>
        <div>
          <dt>Plan</dt>
          <dd>
            <PlanTag plan={tenant.plan} />
          </dd>
        </div>
        <div>
          <dt>Created At</dt>
          <dd className="mono">{new Date(tenant.createdAt).toLocaleString()}</dd>
        </div>
        <div>
          <dt>Updated At</dt>
          <dd className="mono">{new Date(tenant.updatedAt).toLocaleString()}</dd>
        </div>
      </dl>
    </Card>
  );
}
```

*(Status and Plan intentionally repeat what `TenantHeader` already shows — both were explicitly listed as fields for both sections in this phase's own instructions; the header is a compact masthead, this card is the fuller structured record. Not treated as redundancy to eliminate.)*

## `components/tenant-management/TenantOwnerCard.js`

```jsx
import Card from "../ui/Card";
import { TENANT_STATUS } from "../../constants/tenantStatus";

// The approved GET /tenants/:id response contains no owner or invitation
// data at all, for any Tenant (Known Backend Gap below). This card can
// only describe the *situation* inferred from tenant.status - a real field
// in the response - never actual owner details (name, email, dates),
// which the API doesn't return regardless of status.
function ownerMessage(status) {
  switch (status) {
    case TENANT_STATUS.DRAFT:
      return "No Owner has been invited yet.";
    case TENANT_STATUS.INVITED:
      return "An invitation has been sent and is pending acceptance.";
    default:
      // ACTIVE, SUSPENDED, ARCHIVED all imply an Owner account exists -
      // showing "not invited yet" here would be false, not just incomplete.
      return "An Owner account exists for this Tenant. Owner details are not yet available in this view.";
  }
}

export default function TenantOwnerCard({ tenant }) {
  return (
    <Card>
      <h2>Owner</h2>
      <p className="helptext">{ownerMessage(tenant.status)}</p>
    </Card>
  );
}
```

## `components/tenant-management/TenantActivityCard.js`

```jsx
import Card from "../ui/Card";

export default function TenantActivityCard({ tenant }) {
  const hasDistinctUpdate = tenant.updatedAt && tenant.updatedAt !== tenant.createdAt;

  return (
    <Card>
      <h2>Activity</h2>
      <dl className="tenant-detail-list">
        <div>
          <dt>Created</dt>
          <dd className="mono">{new Date(tenant.createdAt).toLocaleString()}</dd>
        </div>
        {hasDistinctUpdate && (
          <div>
            <dt>Last Updated</dt>
            <dd className="mono">{new Date(tenant.updatedAt).toLocaleString()}</dd>
          </div>
        )}
      </dl>
      <p className="helptext">No activity history available yet.</p>
    </Card>
  );
}
```

*(`hasDistinctUpdate` hides a "Last Updated" line only when it would show the exact same timestamp as "Created" — a small, deliberate judgment call to avoid a confusing-looking duplicate, not data being withheld. No real information is hidden; the same two fields are always fetched and available. Flagged in review below in case the more literal "always show both" reading is preferred.)*

---

## CSS additions (existing tokens only)

```css
.tenant-header-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 8px;
}

.tenant-detail-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 16px;
  margin: 0;
}
.tenant-detail-list dt {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-ink-soft);
  margin-bottom: 2px;
}
.tenant-detail-list dd {
  margin: 0;
  font-size: 14px;
  color: var(--color-ink);
}
```

No responsive breakpoints were added — see the Performance/Architecture note below on why none were needed.

---

## Architecture Review

Four small, single-purpose components, each owning one section of the page — `TenantHeader` (identity + navigation), `TenantOverviewCard` (structured facts), `TenantOwnerCard` (situational, derived), `TenantActivityCard` (the two real timestamps + an honest gap notice). None of them fetch data themselves; `page.js` fetches once and passes `tenant` down as a plain prop, keeping every card a pure, easily-testable function of its input.

## API Compliance Review

Exactly one call: `api.getTenantDetails(token, tenantId)` → `GET /tenants/:id`. No other endpoint referenced anywhere in this phase's code — no Suspend/Activate/Archive/Invite/Resend call exists, consistent with the explicit "no mutations" scope.

## Accessibility Review

- One `<h1>` (Tenant name, in `TenantHeader`) and one `<h2>` per card (`Overview`, `Owner`, `Activity`) — a correct, single-path document outline a screen reader's heading navigation can rely on.
- `<dl>`/`<dt>`/`<dd>` used for every key-value fact — the semantically correct element for this content, not generic `<div>`s with visual-only styling.
- The Back link and Retry button are both real, keyboard-reachable elements (`<Link>`/`<button>`), not `onClick`-only `<span>`s or `<div>`s.
- No accessibility regression against Phase 8.1/8.2's established patterns — this phase introduces no dialogs or dynamic live-region content that would need additional ARIA beyond what semantic HTML already provides here.

## Performance Review

Single fetch on mount, keyed to `tenantId` so navigating directly between two Tenants' Details pages (without an intermediate List visit) correctly re-fetches rather than showing stale data. No derived state beyond the one `hasDistinctUpdate` boolean, computed inline, not stored. **No responsive CSS breakpoints were needed for the cards themselves** — they're simple stacked block elements, already full-width at every viewport by default; the one grid (`tenant-detail-list`) already reflows via `auto-fit` without a media query. Verified, not assumed.

## Known Backend Gaps

1. **`getTenantById` (as referenced in this task) does not exist — the approved method is `getTenantDetails`.** Used the correct, approved name.
2. **`GET /tenants/:id` returns no owner or invitation data at all**, for any Tenant regardless of status — the single largest limitation this phase works around. `TenantOwnerCard` can describe the *situation* from `status`, never real Owner details.
3. **No richer audit/activity history is available** — no Audit Log read endpoint exists yet (Module 4/V1); `TenantActivityCard` is limited to the two raw timestamps already on the Tenant record.
4. **Errors are plain message strings, not structured codes** — "not found" detection relies on matching the literal text of Phase 5's controller message, which would silently break if that message's wording ever changes without a corresponding structured error code being introduced.

## Future Improvements

1. A dedicated endpoint or included relation returning current Owner/Invitation summary data would let `TenantOwnerCard` show real information instead of status-derived situational text.
2. Structured error codes (not just message strings) on API error responses would make "not found" detection robust to message wording changes.
3. Once Module 4's Audit Log viewer exists, `TenantActivityCard` becomes the natural place to surface real step-by-step history instead of the current placeholder notice.

---

**STOP — awaiting approval before Phase 8.4 (Dialogs). Not yet applied to `frontend/`.**
