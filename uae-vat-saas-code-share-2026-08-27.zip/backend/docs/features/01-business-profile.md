# Sprint 1 — Feature Design: Business Profile

- **Status:** Version 1 — ready for implementation planning
- **Date:** 2026-07-30
- **Module:** Module 1 — Tenant Foundation ([MPS §9](../master-product-specification.md#9-modules--responsibilities), [PAS §7](../platform-architecture-specification.md#7-module-architecture))
- **Built on:** [Product Bible](../product-bible.md), [ADR-0001](../adr/0001-baseline-architecture.md), [UAE VAT Knowledge Base](../knowledge-base/README.md), [MPS](../master-product-specification.md), [PAS](../platform-architecture-specification.md), [DDS](../database-design-specification.md), [SDD](../system-design-document.md), [HLD](../high-level-design.md) — all treated as source of truth, none re-derived here.
- **What this is not:** platform architecture (already fixed by the documents above), a database schema, an API contract, UI design, or code. This is the business-and-functional design for one feature, scoped to be immediately implementable.
- **How this document is organized:** §1–§10 deliver the requested spec sections, already incorporating this document's Product Design Review Board findings — not your original 18-field list transcribed as-is. §11 makes every change explicit and argued, so nothing was silently added, removed, or reclassified. §12 is the final go/no-go review.

---

## 1. Executive Summary

**Purpose**: Business Profile is the record that answers "who is this Tenant, legally and commercially" — the identity, compliance, and branding facts every other module needs before it can produce a correct, compliant document or calculation.

**Business Value**: it is the single highest-leverage feature in Module 1. Every downstream promise this platform makes — a correct tax invoice ([KB §5.1]), a correct VAT Return ([KB §7.1]), a professional-looking document a customer trusts — depends on Business Profile data being complete and correct *before* those modules run, not discovered missing when Module 2 ships.

**Scope (this document)**: capture, validate, and manage the identity/compliance/contact/branding fields for a single Tenant's business, plus the completion and activation state derived from them.

**Out of Scope**:
- Numbering format, default payment terms, and approval-threshold settings — these are part of Module 1's Configuration cascade ([MPS §15]) but are a **distinct sub-feature**, not bundled into Business Profile here. Treat as a separate Sprint 1/2 ticket, not silently expanded into this one.
- Any Firm/multi-Tenant access to this profile — genuinely blocked on [PAS §25 Decision 1], unresolved. Business Profile is, per [MPS §9], the first surface that decision will need to reach — this document does not attempt to resolve it.
- Multi-branch/multi-trade-license support, bank/payment details, and full localization (Arabic UI) — addressed as Future Enhancements in §11, not built here.

**Dependencies**: Authentication, Authorization (RBAC), Audit Logging, File Storage, Configuration — all pre-existing platform services this feature *consumes*, does not redefine. Detail in §9.

---

## 2. Business Goal

**Why does Business Profile exist?** Because every document Ledger will ever produce on a Tenant's behalf — a tax invoice, a VAT Return, a report — is legally required to correctly identify that Tenant ([KB §5.1] mandates supplier name, address, and TRN on every tax invoice). Without a complete, correct Business Profile, no other module can do its job compliantly; Business Profile isn't a settings screen, it's the compliance foundation everything else stands on.

**Why must a Tenant complete it before real use?** Because [KB §1.3] and [DDS §10] already establish that legally-significant fields are *snapshotted onto documents at the moment they're issued* — if the profile is incomplete or wrong when the first invoice is issued, that invoice is wrong, permanently (documents are immutable, [KB §5.1]/[§5.3]). Gating real usage on profile completeness is not friction for its own sake; it's the only point at which a mistake here is still free to fix.

**How does it affect downstream modules?** Directly — see [§10 Future Consumers](#10-future-consumers). Nothing in Module 2 (Invoicing) or Module 3 (VAT Position) can be correctly designed without knowing exactly what Business Profile guarantees to have available, which is precisely why this feature is Sprint 1's first deliverable rather than an afterthought.

---

## 3. Functional Requirements

This table is the **Review Board's final recommendation**, not a transcription of the original 18-field proposal — every addition, removal, or reclassification is explained in [§11](#11-product-design-review-board-findings). Fields are grouped by purpose.

### Identity & Compliance

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Business Name** (trading name) | The name customers know the business by | Mandatory | 1–200 chars | Appears on invoices; distinct from Legal Name because many UAE SMEs trade under a different name than their licensed entity name | Invoicing, Reports |
| **Legal Name** | The name on the trade license/registration | Mandatory | 1–200 chars | Required on tax invoices per [KB §5.1] alongside TRN — the legally binding identity, not the trading brand | Invoicing, VAT Return |
| **Trade License Number** | UAE commercial registration reference | Mandatory | Non-empty; **no fixed format enforced** — license formats vary by Emirate/free zone authority, so only presence is validated, not pattern | Establishes the business is a real, licensed UAE entity | Compliance record-keeping |
| **VAT Registration Status** *(new — see §11)* | Whether the business is VAT-registered, and how | Mandatory | One of: Not Registered / Voluntarily Registered / Mandatorily Registered | Directly gates whether TRN is required and whether the Tenant can issue VAT-bearing invoices at all ([KB §1.1]) | Invoicing, VAT Return, Reports |
| **TRN** | Tax Registration Number | **Conditionally Mandatory** — required only if VAT Registration Status ≠ Not Registered | Exactly 15 numeric digits ([KB §1.2]) | The legal VAT identifier; must appear on every tax invoice and VAT Return | Invoicing, VAT Return, Customers/Suppliers (their own TRN follows the same rule) |
| **VAT Registration Date** *(new — see §11)* | The date VAT registration became effective | **Conditionally Mandatory** — same condition as TRN | Valid date, not in the future | No VAT may be charged before this date ([KB §1.1]); anchors when Invoicing is even allowed to charge VAT | Invoicing, VAT Return |

### Localization (locked for MVP — see §11)

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Country** | Jurisdiction | Mandatory, **pre-set to United Arab Emirates, not user-editable in MVP** | Fixed value | Every rule in the [Knowledge Base] is UAE-specific; presenting a free country picker implies capability the platform doesn't have | VAT Return, Reports |
| **Base/Reporting Currency** | The currency VAT and reports are calculated in | Mandatory, **pre-set to AED, not user-editable in MVP** | Fixed value | [KB §8.3] requires VAT amounts in AED regardless of transaction currency — this field is the *reporting* currency, not a per-invoice transaction currency (that's a separate, Future capability) | VAT Return, Reports |
| **Timezone** | Display/scheduling reference | System-defaulted to `Asia/Dubai`, not exposed in MVP UI | Fixed value | The UAE has one timezone, no DST — a per-Tenant picker adds UI complexity with zero present value | Filing-deadline reminders ([KB §7.2]) |

### Business Classification

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Business Type** | Legal structure (LLC, Sole Establishment, Free Zone Entity, Civil Company, Branch, etc.) | Mandatory | Selected from a controlled list, not free text | Groundwork for future Designated Zone / Free Zone logic ([KB §3.4]) — a lookup, not free text, per [DDS §6]/[§9]'s enum-vs-lookup guidance | VAT Position (future), Reports |
| **Industry** | Sector classification | Optional | Selected from a controlled list | No Module 1–3 logic branches on this today, but it's cheap now and valuable for future analytics/AI ([§10]) | Reports (future), AI (future) |

### Contact & Address

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Business Email** | Primary business contact | Mandatory | Valid email format | Notifications, filing-deadline reminders | Notifications |
| **Business Phone** | Primary business contact | Mandatory | Valid phone format, UAE (+971) or general international | Contact fallback | Notifications |
| **Address — Line 1** | Structured address, restructured from a single free-text field — see §11 | Mandatory | 1–200 chars | Required on every tax invoice ([KB §5.1]); structured data is more reliable to print correctly than a free-text blob | Invoicing |
| **Address — Line 2** | Structured address (suite/floor/building) | Optional | 0–200 chars | Same as above | Invoicing |
| **Address — Emirate/City** | Structured address | Mandatory | Selected from a controlled list of Emirates | Same as above; also relevant to future Emirate-specific rule variations if any arise | Invoicing |
| **Address — PO Box** | Common in UAE business addresses | Optional | Alphanumeric, short | UAE business addresses commonly use PO Box rather than street delivery | Invoicing |
| **Primary Contact Person** *(new — see §11)* | Name of the person to contact for business matters | Optional | 1–100 chars | Useful when the platform login (Owner) isn't who should be contacted operationally — cheap, common pattern | Notifications, future Firm-access review |

### Branding & Documents

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Logo** | Displayed on issued documents | Optional | Image file, size/type limits per [DDS §15] | Professional document appearance — [MPS §15] already committed to "branding basics" as MVP scope | Invoicing (document rendering) |
| **Invoice Footer / Terms Text** *(new — see §11)* | Free text shown at the bottom of issued invoices | Optional | 0–1000 chars | [MPS §15] already committed to "footer" as MVP-scope branding — the original proposal named Logo but not this; closing that gap here | Invoicing |
| **Website** | Optional business link | Optional | Valid URL format if provided | Commonly expected, low cost, not compliance-relevant | Reports (future), AI (future) |
| **Preferred Language** *(new — see §11)* | Display language preference | Optional, defaults to English | One of the supported values; **not functionally switchable in MVP** (Arabic UI remains an open decision, [Product Bible A16]) | Data-readiness for a decision that hasn't been made yet — captured now so it isn't a retrofit later | UI (future) |

### Reporting Reference

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Financial Year Start** | The month/day the Tenant's own financial year begins | Optional, defaults to 1 January | Valid month + day | Used for the Tenant's *own* internal reporting periods — **does not affect VAT filing periods**, which are fixed by the FTA's own calendar regardless of financial year ([KB §7.2]) — this distinction must never be conflated in implementation | Reports (future) |

### System-Managed (not user-entered)

| Field | Purpose | Mandatory? | Validation | Business Reason | Used By |
|---|---|---|---|---|---|
| **Profile Status** | Draft / Active / Deactivated — see [§4] | System-managed | State-machine governed, see [§4] | Distinct from `Tenant.status` (platform billing/access) and VAT Registration Status (compliance) — three separate concepts, never conflated ([§4]) | Invoicing (blocks issuance if not Active) |
| **Profile Completion %** | Onboarding progress indicator | System-computed, read-only | Always derived from which mandatory fields are populated — never independently stored or edited | Cheap, high-value onboarding UX; must never drift from the actual field state | Frontend UI only |

---

## 4. Business Rules

| # | Rule | Rationale |
|---|---|---|
| 1 | **Exactly one Business Profile per Tenant**, no exceptions in MVP. | Matches the current single-legal-entity-per-Tenant model ([Product Bible §1.3] edge case); multi-branch/multi-license is a named Future Enhancement ([§11]), not built now. |
| 2 | **TRN, when present, is unique across the entire platform**, not just per Tenant. | A TRN identifies one real-world legal entity; two Tenants holding the same TRN indicates a duplicate onboarding or an error, never a legitimate state. This resolves the Product Bible's open Assumption A5 for this feature — flagged here explicitly, not silently decided. |
| 3 | **TRN and VAT Registration Date are required if and only if VAT Registration Status is not "Not Registered."** | Directly encodes [KB §1.1] — not every UAE SME is VAT-registered, and forcing a TRN on all of them would be both incorrect and a real onboarding blocker for legitimate non-registered businesses. |
| 4 | **Country, Base Currency, and Timezone are fixed for MVP** and not exposed as editable fields in the UI, even though they exist in the data model. | Every downstream rule in the Knowledge Base is UAE/AED-specific; presenting these as free choices would silently promise capability (multi-country, multi-base-currency) the rest of the platform doesn't have yet. Revisit only alongside Horizon 2 ([MPS §2]). |
| 5 | **Three distinct status concepts must never be conflated**: (a) `Tenant.status` — platform billing/access (`ACTIVE`/`SUSPENDED`, Platform-Admin-controlled, already built in Module 0); (b) **VAT Registration Status** — compliance fact (§3); (c) **Profile Status** — `Draft`/`Active`/`Deactivated`, Owner-controlled, described below. A Tenant can be platform-suspended while VAT-registered and profile-Active; the three axes are independent. | This is the single most important rule in this document — Product Bible v2 already flagged the platform-vs-VAT-status conflation risk ([KB §1.1] edge case); this rule extends the same discipline to the new Profile Status concept this feature introduces. |
| 6 | **Profile Status transitions**: `Draft` → `Active` happens **automatically** the moment every Mandatory field in §3 is populated — never a manual "Activate" button (see [§11] UX finding). `Active` → `Deactivated` is a **deliberate, Owner-only action** (§7); `Deactivated` → `Active` is Owner-reversible. | Automatic activation removes a needless manual step and matches how QuickBooks/Xero/Zoho treat company setup — you don't "activate" your company file, it becomes usable once minimally complete. |
| 7 | **A `Deactivated` Business Profile blocks new document issuance (invoices, credit notes) but does not block viewing historical data.** | Historical records remain subject to FTA retention obligations regardless of the Tenant's current activity state ([KB §8.2]) — deactivation must never look like deletion. |
| 8 | **Profile Completion % is always computed on read from the current field state — never stored as an independently editable value.** | Direct application of [DDS]'s "derived, not entered" principle, already used for VAT Returns and reports elsewhere in this platform. |
| 9 | **Editing Business Profile never retroactively alters previously issued documents.** | Direct restatement of the snapshot-at-issuance principle ([KB §1.3]/[§5.1], [DDS §10]) — not re-derived here, just reaffirmed as binding on this feature specifically. |
| 10 | **Changes to TRN, Legal Name, or VAT Registration Status are Audit-logged with the old and new value**, given their compliance significance — no field in this feature is technically immutable (a TRN *can* legitimately change, [KB §1.2] edge case), but these three changes are never silent. | Balances the real-world need to correct/update these fields against the compliance weight of getting them wrong unnoticed. |
| 11 | **Logo upload does not block Profile Status activation.** | Branding is a completion-tracked, non-blocking field (§3) — a Tenant should be able to start issuing invoices before a logo is uploaded, matching the general MVP principle of minimizing onboarding friction to genuinely necessary fields. |

---

## 5. Validation Rules

| Field / Concern | Rule |
|---|---|
| Mandatory fields (§3) | Enforced server-side always; client-side validation is a UX convenience only, never authoritative ([HLD §10]). |
| Text field maximum lengths | Business/Legal Name 200 chars; Address lines 200 chars; Footer text 1000 chars; Primary Contact Name 100 chars — generous enough for real-world values, bounded to prevent abuse. |
| Email | Standard email format validation; case-insensitive comparison for uniqueness checks elsewhere in the platform. |
| Phone | Accepts UAE (+971) and general international formats; not restricted to a single country code, since a business's contact number is not itself a compliance fact. |
| TRN | Exactly 15 numeric digits, no letters or symbols ([KB §1.2]) — validated server-side regardless of what the client already checked. |
| Country | Not user-input in MVP — validated as the fixed platform value, not an open text/select validation problem. |
| Website | Valid URL format if provided; entirely optional, no validation failure if left blank. |
| Logo | Restricted file types (standard image formats), maximum file size, per [DDS §15]'s file-metadata standards — never validated by filename alone. |
| Financial Year Start | A valid month (1–12) and day (1–31, consistent with the chosen month) — no business-rule dependency beyond calendar validity, since it does not gate VAT logic. |
| VAT Registration Date | A valid date, not in the future; if VAT Registration Status is "Not Registered," this field must be empty, not just optional — an inconsistent combination (status = Not Registered, date populated) is itself a validation failure, not silently accepted. |

---

## 6. User Journey

### Create Business Profile

```mermaid
sequenceDiagram
    participant Owner
    participant UI as Frontend
    participant API as Backend (Tenant Foundation Service)
    participant Audit as Audit Logging

    Owner->>UI: Opens Business Profile setup
    UI->>Owner: Presents form (locked Country/Currency shown, not editable)
    Owner->>UI: Enters identity, compliance, contact fields
    UI->>API: Submit profile data
    API->>API: Validate (server-side, §5)
    alt Validation fails
        API-->>UI: Field-level errors
        UI-->>Owner: Show errors, no state change
    else Validation passes
        API->>API: Persist profile
        API->>API: Compute Profile Completion % and Status (Draft/Active)
        API->>Audit: Log "Business Profile created"
        API-->>UI: Success + current status
        UI-->>Owner: Confirmation, completion indicator shown
    end
```

### Edit Business Profile

```mermaid
sequenceDiagram
    participant Owner
    participant UI as Frontend
    participant API as Backend (Tenant Foundation Service)
    participant Audit as Audit Logging

    Owner->>UI: Opens existing profile
    Owner->>UI: Changes one or more fields
    UI->>API: Submit changed fields
    API->>API: Validate (§5); re-check TRN/VAT status conditional rule (§4.3)
    alt Validation fails
        API-->>UI: Field-level errors
    else Validation passes
        API->>API: Persist changes
        API->>API: Recompute Profile Completion % and Status
        alt TRN, Legal Name, or VAT Registration Status changed
            API->>Audit: Log old + new value (§4.10)
        end
        API-->>UI: Success + updated status
    end
    Note over API: Previously issued documents are never altered (§4.9)
```

### Activate Business (system-triggered, not a manual action — see §11)

```mermaid
sequenceDiagram
    participant Owner
    participant API as Backend (Tenant Foundation Service)
    participant Audit as Audit Logging

    Owner->>API: Completes the last Mandatory field (via any Edit)
    API->>API: Detect all Mandatory fields now populated
    API->>API: Transition Profile Status: Draft -> Active
    API->>Audit: Log "Business Profile activated"
    Note over API: No manual "Activate" button exists in MVP —<br/>activation is a derived state, not a user action
```

### Deactivate Business

```mermaid
sequenceDiagram
    participant Owner
    participant UI as Frontend
    participant API as Backend (Tenant Foundation Service)
    participant Audit as Audit Logging

    Owner->>UI: Chooses "Deactivate Business"
    UI->>Owner: Confirms consequences (blocks new documents; historical data remains accessible)
    Owner->>UI: Confirms
    UI->>API: Deactivate request
    API->>API: Verify requester is Owner (§7)
    API->>API: Transition Profile Status: Active -> Deactivated
    API->>Audit: Log "Business Profile deactivated"
    API-->>UI: Success
    Note over API: Document issuance now blocked;<br/>viewing/reporting on historical data still permitted (§4.7)
```

---

## 7. Permissions

**A note on "Accountant"**: the roles this platform has actually built or committed to for MVP are Platform Admin, Tenant Owner, and Tenant Staff ([PAS §14]) — there is no system-defined "Accountant" role yet. Custom/differentiated roles beyond Owner/Staff are explicitly V1 (Module 4), not MVP ([MPS §14]). For this table, **Accountant is treated as mapping to Staff** — if Accountant needs permissions genuinely different from Staff, that requires the custom-role capability already scoped to V1, not something this feature can create unilaterally. Flagged as a Future Enhancement in [§11].

| Action | Platform Admin | Business Owner | Staff (incl. "Accountant") |
|---|:---:|:---:|:---:|
| **View** | ✅ (support access only) | ✅ | ✅ |
| **Create** | — (created via Tenant onboarding, Module 0) | ✅ (initial setup) | ❌ |
| **Edit** | ❌ | ✅ | ❌ — resolves [Product Bible A6] for this feature: compliance-significant fields (TRN, Legal Name, VAT status) justify Owner-only edit by default |
| **Deactivate** | ❌ | ✅ | ❌ |
| **Export** | ❌ | ✅ | ✅ (read-only data leaving the system is lower-risk than edit) |

**Why Platform Admin has no Edit right**: Business Profile is the Tenant's own compliance record — consistent with the standing platform rule that Platform Admin sees management-level data (plan, status, usage) but never edits a Tenant's own business content ([Product Bible §4]/[ADR §6]). Platform Admin's View access exists for support/troubleshooting, not administration.

---

## 8. Error Scenarios

| Scenario | Handling |
|---|---|
| Duplicate TRN (already used by another Tenant) | Rejected at validation — a business-error, not a generic failure, with a message distinguishing it from a format error |
| Missing required fields | Rejected at validation, field-level errors returned — never a partial save |
| VAT Registration Status ≠ Not Registered, but TRN missing | Rejected — the conditional-mandatory rule (§4.3) is enforced as a combination check, not two independent optional checks |
| VAT Registration Status = Not Registered, but TRN or VAT Registration Date populated | Rejected — an inconsistent state is itself invalid, not silently accepted (§5) |
| Attempt to edit Country/Base Currency | Rejected — these are not editable fields in MVP (§4.4); the API must enforce this even if a client somehow bypasses the UI |
| Platform-suspended Tenant attempts to edit Business Profile | Rejected at the Authentication/Tenant Management layer, before this feature's logic even runs — consistent with the existing platform-wide suspension enforcement ([ADR §6]) |
| Staff attempts to Edit or Deactivate | Rejected by the Authorization (RBAC) check (§7) — a permission error, distinct from a validation error |
| Invalid logo (wrong type / too large) | Rejected with a specific file-validation error; does not block the rest of the profile from being saved (logo is non-blocking, §4.11) |
| Trade License Number duplicate across Tenants | **Not rejected** — Trade License Number uniqueness is not enforced platform-wide (unlike TRN), since license numbering isn't reliably globally unique across all Emirate/free zone authorities in a way this platform can validate confidently; a duplicate here is not itself proof of an error the way a duplicate TRN would be |
| Attempt to Deactivate with a filing deadline imminent | **Not blocked**, but the confirmation step (§6) surfaces a warning — compliance obligations continue regardless of platform activity state, and the platform should inform, not silently prevent, an Owner's legitimate business decision |

---

## 9. Dependencies

| Platform Service | How Business Profile uses it |
|---|---|
| **Authentication** | Every request resolves a verified identity before Business Profile logic runs; this feature never re-implements identity verification ([HLD §11]). |
| **Authorization (RBAC)** | Every Create/Edit/Deactivate call is checked via the standard `requirePermission()` pattern (§7) — no role-string comparison inline in this feature's code ([PAS §14]/[HLD §12]). |
| **Audit Logging** | Explicit calls at profile creation, activation, deactivation, and changes to TRN/Legal Name/VAT Registration Status (§4.10) — this feature decides *when* to call Audit; it does not implement logging itself ([HLD §15]). |
| **File Storage** | The Logo field is stored via the File Storage service's `store()`/`getSignedUrl()` interface — Business Profile never touches an object-storage client directly ([HLD §16]). This is also the **first real consumer** of File Storage, per [DDS §15]'s recommendation to introduce the file-metadata entity at the first genuine need rather than waiting for Module 5's OCR. |
| **Configuration** | Business Profile is itself a *source* feeding the Configuration cascade ([PAS §11]) — Base Currency and Financial Year Start, once populated here, become inputs other Configuration-driven features (Numbering, Reports) will read, not duplicated fields those features re-collect. |

---

## 10. Future Consumers

| Module | How it will use Business Profile |
|---|---|
| **Customers** | No direct dependency beyond standard Tenant scoping; a Customer's own TRN field follows the same 15-digit validation rule defined here, not a separate implementation. |
| **Suppliers** | Same as Customers. |
| **Products/Services** | No direct dependency in MVP; Base Currency (locked here) is the implicit currency every Product/Service price is denominated in. |
| **Invoices** | The heaviest consumer — snapshots Legal Name, Address, TRN, Logo, and Footer text onto every issued tax invoice at the moment of issuance ([KB §5.1]/[§1.3]); blocked entirely if Profile Status is not `Active`. |
| **VAT** | Reads VAT Registration Status and VAT Registration Date to determine whether VAT can be charged at all and from what date ([KB §1.1]); Base Currency anchors every VAT Return figure. |
| **Reports** | Financial Year Start (if adopted) frames the Tenant's own internal reporting periods, distinct from the FTA's VAT filing periods; Industry and Business Type are candidate future segmentation dimensions. |
| **Payments** | Not a Business Profile consumer in MVP — bank/payment details are a named Future Enhancement (§11), tracked separately from this feature. |
| **AI** *(future)* | Structured fields (Industry, Business Type) give a future AI bookkeeping assistant real business context to reason with, rather than inferring it from free text — a direct payoff of choosing controlled lists over free text now ([SDD §22]). |

---

## 11. Product Design Review Board — Findings

Per the explicit instruction not to accept the original proposal as-is. Every finding is classified **Required for MVP** / **Recommended for MVP** / **Future Enhancement**, with reasoning.

### Missing fields identified

| Field | Classification | Reasoning |
|---|---|---|
| **VAT Registration Status** | **Required for MVP** | Without this, the platform cannot correctly implement [KB §1.1]'s core rule that not every business is VAT-registered — omitting it would force TRN as mandatory for everyone, incorrectly blocking legitimate non-registered SMEs from onboarding at all. This is the single most consequential gap in the original proposal. |
| **VAT Registration Date** | **Required for MVP** | Directly required by [KB §1.1]'s FR-106 (already specified in the Knowledge Base before this feature existed) — VAT cannot be legally charged before this date; Invoicing cannot be built correctly without it. |
| **Invoice Footer / Terms Text** | **Required for MVP** | [MPS §15] already committed to "branding basics (logo, footer)" as MVP Configuration scope — the original proposal listed Logo but omitted Footer, an inconsistency with a decision already made elsewhere in this document set. |
| **Structured Address** (line 1/2, Emirate, PO Box) vs. a single free-text field | **Recommended for MVP** | A single address blob is harder to validate and prints less reliably on tax invoices, which legally require a supplier address ([KB §5.1]). The added structuring cost is small relative to the document-quality payoff. |
| **Primary Contact Person** | **Recommended for MVP** | Cheap, common in QuickBooks/Xero/Zoho, useful when the platform login identity isn't who should be operationally contacted. |
| **Preferred Language** | **Recommended for MVP** | Not functionally used yet (Arabic UI remains undecided, [Product Bible A16]), but capturing it now avoids a retrofit later — cheap data-readiness, not a feature. |
| **Emirate/Free Zone flag** | **Future Enhancement** | Ties to Designated Zone treatment ([KB §3.4]), which [MPS §7] already deferred; premature to build the flag before the logic that would use it. |
| **Bank/Payment Details** | **Future Enhancement** | Payments/reconciliation is explicitly V1, not MVP ([MPS §7]); adding structured banking fields now would be building ahead of the module that needs them. |
| **Multiple Trade Licenses / Branches** | **Future Enhancement** | [Product Bible §1.3] already notes UAE VAT registration is generally per legal entity, making single-profile-per-Tenant sufficient for the near term; revisit only if real customer demand surfaces it. |
| **Company Size / Employee Count** | **Future Enhancement** | No current business logic depends on it; a segmentation field for future analytics, not a Sprint 1 need. |

### Unnecessary fields / fields to lock down for MVP

| Field | Original proposal | Recommendation | Reasoning |
|---|---|---|---|
| **Country** | Free/editable | **Lock to United Arab Emirates, hide the picker** | Every rule in this platform is UAE-specific; a free country picker implies capability that doesn't exist and adds UI complexity (validation, country-specific formatting) with zero present payoff. Not removed from the data model — deferred exposure, tied to Horizon 2. |
| **Currency** | Free/editable | **Lock to AED, hide the picker; rename conceptually to "Base/Reporting Currency"** | [KB §8.3] requires AED for VAT purposes regardless of transaction currency — presenting Currency as a free choice conflates the (future) per-invoice transaction currency with the (locked) reporting currency, a real source of confusion. |
| **Timezone** | Free/editable | **System-default to `Asia/Dubai`, remove from MVP UI entirely** | The UAE has a single timezone with no DST; a per-Tenant picker is pure UI complexity with no current business value. |

No field from the original list is recommended for outright deletion from the data model — the three above are recommended to be **present but not exposed as user choices**, which is a materially simpler MVP than building and validating three pickers that don't yet do anything.

### Additional business rules suggested

Already incorporated into [§4] — notably: the three-way Status distinction (Rule 5), the conditional-mandatory TRN/VAT-date pairing (Rule 3), automatic (not manual) activation (Rule 6), and the compliance-significant-field audit rule (Rule 10). These are the Board's most load-bearing contributions to this document, not decorative additions.

### Additional validation rules suggested

The VAT Registration Status/TRN/Date **consistency check** (§5, §8) — rejecting a populated TRN when status says "Not Registered," not just validating each field independently. This is the kind of cross-field validation that's easy to miss when a spec lists fields one at a time rather than as a coherent record.

### Edge cases identified

- A Tenant's VAT Registration Status changes from Not Registered to Registered mid-lifecycle (crossing the mandatory threshold, [KB §1.1]) — Business Profile must support this transition cleanly, requiring TRN/Date to be added *after* the profile was already Active, without treating it as a re-onboarding.
- A Tenant deactivates their Business Profile while a VAT filing deadline is imminent — handled as a warning, not a block (§8), since compliance obligations don't pause with the platform.
- TRN legitimately changes after activation ([KB §1.2] edge case) — handled via the audit-logged-change rule (§4.10), not treated as immutable.
- A field-level inconsistency (VAT status vs. TRN presence) submitted directly via a bypassed client — caught server-side regardless (§5), since client validation is never authoritative.

### UX improvements with business-logic impact

- **Automatic activation over a manual "Activate" button** (§4.6) — removes a step, matches QuickBooks/Xero/Zoho's progressive-onboarding pattern, and avoids a state where a fully-complete profile sits needlessly "not active" because no one clicked a button.
- **Progressive completion, not a single long form** — Mandatory fields gate activation; Optional fields (Logo, Website, Industry, Financial Year) can be completed later without blocking usage, mirroring how QuickBooks/Xero/Zoho front-load only what's truly necessary at signup.
- **Locked-field transparency** — Country/Currency should be *shown* (so the Owner sees their business is UAE/AED) but visibly non-editable, rather than hidden entirely — avoids the appearance of a missing field.

---

## 12. Final Review

**Is this feature sufficient for MVP?** With the additions above (chiefly VAT Registration Status/Date and the Footer field), yes — the original 18-field proposal, unmodified, was **not** sufficient, specifically because it had no way to represent a non-VAT-registered business correctly.

**What important business scenarios are still missing?** The VAT-status-transition edge case (above) needs explicit handling in Module 1's build, not just this spec's acknowledgment. The Firm-managed-Tenant access question ([PAS §25 Decision 1]) remains genuinely unresolved and will need to reach Business Profile specifically, per [MPS §9] — this document doesn't solve it, only confirms it's still the right place to eventually plug it in.

**What risks exist if the original specification had been implemented exactly as proposed?** Three concrete ones: (1) TRN as unconditionally mandatory would have incorrectly blocked legitimate non-VAT-registered SMEs from onboarding — a product and legal correctness bug, not a cosmetic gap; (2) free Country/Currency/Timezone pickers would have implied multi-jurisdiction capability the platform doesn't have, wasting UI effort and risking user confusion; (3) conflating Business Profile "Status/Activation" with the existing `Tenant.status` platform concept was a real, likely architecture bug waiting to happen, given Product Bible v2 had already flagged this exact conflation risk once before.

**What would QuickBooks, Xero, or Zoho Books do differently?** Front-load only the true minimum at signup and let the rest complete progressively (adopted here, §11); lock base currency early with clear warning it's hard to change later (worth adopting as an explicit high-friction-change UX for Currency if it's ever unlocked, beyond this document's MVP scope); show a visible completion checklist tied directly to what unlocks (validates the original Profile Completion % instinct, now given real mechanics in §4.6/§4.8).

**Final recommendations before implementation begins**:
1. Build VAT Registration Status/Date as Required for MVP — this is not optional polish, it's a correctness fix.
2. Implement Profile Status as a third, independent axis from `Tenant.status` — get this distinction into the data model correctly the first time; retrofitting it after Module 2/3 assume otherwise is expensive.
3. Lock Country/Currency/Timezone in the UI now; keep them in the data model for Horizon 2.
4. Treat Numbering/Payment-Terms/Approval-Threshold settings as a separate ticket, not scope creep into this one.
5. Resolve [Product Bible A6] (Staff edit rights) via this document's Owner-only recommendation — don't leave it open into implementation.
6. Confirm with the project owner whether the Firm-access question ([PAS §25 Decision 1]) needs to influence this feature's build order, or can safely wait — worth a direct check before Sprint 1 closes, not assumed either way.
