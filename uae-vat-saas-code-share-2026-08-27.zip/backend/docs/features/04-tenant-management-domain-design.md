# Tenant Management — Implementation Phase 1: Domain & Database Design

- **Status:** Draft — awaiting approval before Phase 2 (Prisma)
- **Date:** 2026-07-30
- **Implements:** [Tenant Management feature spec](02-tenant-management.md), per the standards in [DDS](../database-design-specification.md), consistent with the existing, already-built Module 0 schema (`Tenant`, `User`, `PlatformAdmin`, `AuditLog`).
- **Scope of this phase:** domain model → ER diagram → database design → review. No Prisma, no SQL, no migrations — those are Phase 2, pending sign-off.

---

## 1. Screen to Entity Mapping

| Screen ([UX Blueprint](03-sprint-1-ux-design.md)) | Entity/Entities |
|---|---|
| Tenant List | `Tenant` |
| Create Tenant | `Tenant` (created in `DRAFT`) |
| Tenant Details | `Tenant`, `Invitation` (lifecycle history) |
| Edit Tenant | `Tenant` |
| Invite Owner (dialog) | `Invitation` (created), `Tenant` (status transition) |
| Resend Invitation (dialog) | `Invitation` (new row created, prior row invalidated) |
| Suspend / Activate / Archive (dialogs) | `Tenant` (status transition only) |
| Accept Invitation (public) | `Invitation` (read + accepted), `User` (created — existing entity, not redesigned) |
| Every lifecycle action | `AuditLog` (existing entity, **extended** — see [§4]) |

---

## 2. Domain Model

### Entities

| Entity | New or existing | Identity | Notes |
|---|---|---|---|
| **Tenant** | Existing, **evolved** | `id` (existing) | `status` expands from 2 values (`ACTIVE`/`SUSPENDED`) to 5 (`DRAFT`/`INVITED`/`ACTIVE`/`SUSPENDED`/`ARCHIVED`) — an evolution of the existing field, not a new one alongside it |
| **Invitation** | **New** | `id` | Child entity of the Tenant aggregate (below) — never referenced or acted on independently of a Tenant |
| **User** | Existing, unchanged in shape | `id` (existing) | Created only at the moment an Invitation is accepted — a real change to *when* this entity is created (today: at Tenant creation; going forward: at acceptance), not to the entity itself |
| **PlatformAdmin** | Existing, unchanged | `id` (existing) | Referenced by the new attribution fields below, not otherwise touched |
| **AuditLog** | Existing, **extended** | `id` (existing) | See [§4] — needs one new nullable attribution field to correctly record Platform-Admin-performed actions, which it cannot express today |

### Aggregate

**Tenant is the aggregate root.** `Invitation` is a child entity within the Tenant aggregate — every invariant spanning the two (only one *live* invitation at a time, invitations only creatable while `DRAFT`/`INVITED`, resend invalidates the prior row) is enforced by the Tenant aggregate's own Service-layer logic ([HLD §8]), never by `Invitation` acting as an independent root. This mirrors the aggregate-root pattern already implied for Invoice/line-items elsewhere in this document set ([PAS §6]).

### Value Objects

| Value Object | Carried by | Notes |
|---|---|---|
| **Invitation Token** | `Invitation.token` | An opaque, cryptographically random value — not an entity of its own; no independent identity or lifecycle beyond the Invitation it belongs to |
| **Email** (Owner's) | `Invitation.inviteeEmail`, later `User.email` | Validated string, not a separate table — same validation semantics platform-wide |

### Enums

| Enum | Values | Storage |
|---|---|---|
| **TenantStatus** *(evolved)* | `DRAFT`, `INVITED`, `ACTIVE`, `SUSPENDED`, `ARCHIVED` | Small, stable, code-controlled set → native Postgres enum once migrated ([DDS §6]/[§9]); plain validated string on SQLite today, unchanged mechanism from Module 0 |
| **SubscriptionPlan** | `TRIAL`, `STANDARD`, `PREMIUM` | Existing, untouched |

### Lifecycle (Tenant.status)

```
DRAFT --(Invite Owner)--> INVITED
INVITED --(Resend Invitation)--> INVITED   [new Invitation row; prior invalidated]
INVITED --(Owner accepts)--> ACTIVE
ACTIVE --(Suspend)--> SUSPENDED
SUSPENDED --(Activate)--> ACTIVE
SUSPENDED --(Archive)--> ARCHIVED           [ARCHIVED is terminal]
```

Matches [Tenant Management spec §4] exactly — not re-derived, restated here only to anchor the transition rules that follow.

### Relationships

| Relationship | Cardinality | Notes |
|---|---|---|
| Tenant → Invitation | 1 : N | A Tenant accumulates one Invitation row per invite/resend attempt over time — never overwritten in place, consistent with this platform's standing "corrections are new records, not mutations" instinct ([KB §5.3], applied here by analogy even though Invitation isn't a financial document) |
| Invitation → User | 0..1 : 1 | An accepted Invitation results in exactly one User; an unaccepted one never does |
| Tenant → PlatformAdmin (`createdByAdminId`) | N : 1, nullable | **New** — attribution, see [§4] |
| Invitation → PlatformAdmin (`invitedByAdminId`) | N : 1, nullable | **New** — attribution |

### Business Constraints

| Constraint | Enforced where | Why there |
|---|---|---|
| `TenantStatus` transitions follow the lifecycle above exactly (no skipping, e.g. `DRAFT` → `ACTIVE` directly) | **Service layer** | Contextual, stateful logic — not a single-row invariant a `CHECK` constraint can express ([DDS §16]'s governing rule) |
| `Archive` reachable only from `SUSPENDED` | **Service layer** | Same reasoning |
| Exactly one *live* Invitation per Tenant at a time (`invalidatedAt IS NULL AND acceptedAt IS NULL`) | **Service layer**, reinforced by a partial index ([§4]) | The invariant itself is stateful (depends on prior rows), but the index makes violating it expensive to query around, not just theoretically wrong |
| Invitation token uniqueness | **Database** (`UNIQUE` constraint) | A pure structural invariant — always wrong to violate, regardless of context, per [DDS §16] |
| Owner email not already a `User` anywhere on the platform | **Service layer**, checked against the existing global `User.email` uniqueness ([DDS §22 Decision 5], not re-decided here) | Spans two tables (`Invitation` and `User`) — not a single-table `UNIQUE` constraint |

---

## 3. ER Diagram

```mermaid
erDiagram
    PLATFORM_ADMIN ||--o{ TENANT : "creates (createdByAdminId)"
    PLATFORM_ADMIN ||--o{ INVITATION : "sends (invitedByAdminId)"
    TENANT ||--o{ INVITATION : "has attempts"
    INVITATION |o--|| USER : "accepted into"
    TENANT ||--o{ USER : "owns (existing relationship, unchanged)"
    TENANT ||--o{ AUDIT_LOG : "recorded against (existing, extended)"
    PLATFORM_ADMIN ||--o{ AUDIT_LOG : "attributed to (new)"

    PLATFORM_ADMIN {
        uuid id PK
        string email UK
        string passwordHash
        datetime createdAt
    }

    TENANT {
        uuid id PK
        string name
        enum status "DRAFT|INVITED|ACTIVE|SUSPENDED|ARCHIVED"
        enum plan "TRIAL|STANDARD|PREMIUM"
        uuid createdByAdminId FK "new, nullable"
        datetime createdAt
        datetime updatedAt
    }

    INVITATION {
        uuid id PK
        uuid tenantId FK
        string inviteeName
        string inviteeEmail
        string tokenHash UK "hashed, see Review §5"
        datetime expiresAt
        datetime acceptedAt "nullable"
        datetime invalidatedAt "nullable"
        uuid invitedByAdminId FK "new, nullable"
        datetime createdAt
    }

    USER {
        uuid id PK
        uuid tenantId FK
        string name
        string email UK
        string passwordHash
        enum role "OWNER|STAFF"
        datetime lastLoginAt "nullable"
        datetime createdAt
    }

    AUDIT_LOG {
        uuid id PK
        uuid tenantId FK
        uuid userId FK "nullable, existing"
        uuid platformAdminId FK "new, nullable"
        string action
        string recordType
        datetime createdAt
    }
```

`USER` and `AUDIT_LOG`'s pre-existing fields are shown as-is from Module 0 — only the additions are new, and they're labeled as such directly on the diagram rather than left to be discovered in a diff.

---

## 4. Database Design

### Tables

**`Tenant` (existing table, evolved)**

| Column | Type | Constraint | Change from Module 0 |
|---|---|---|---|
| `id` | UUID | PK | Unchanged |
| `name` | text | NOT NULL | Unchanged — this *is* "Company Name" from the feature spec; no rename |
| `status` | enum/string | NOT NULL, default `DRAFT` | **Changed**: value set expands from 2 to 5; default changes from `ACTIVE` to `DRAFT` (a Tenant no longer starts active — it starts as a draft awaiting invitation) |
| `plan` | enum/string | NOT NULL, default `TRIAL` | Unchanged |
| `createdByAdminId` | UUID | FK → `PlatformAdmin.id`, nullable, indexed | **New** |
| `createdAt`, `updatedAt` | timestamptz | NOT NULL | Unchanged |
| `address`, `trn`, `contactEmail`, `contactPhone` | — | — | **Out of scope for this phase** — these Module 0 fields are superseded by the not-yet-implemented Business Profile feature; left untouched here, addressed when that feature reaches this same implementation phase, not decided now |

**`Invitation` (new table)**

| Column | Type | Constraint |
|---|---|---|
| `id` | UUID | PK |
| `tenantId` | UUID | FK → `Tenant.id`, NOT NULL, indexed |
| `inviteeName` | text | NOT NULL |
| `inviteeEmail` | text | NOT NULL |
| `tokenHash` | text | NOT NULL, `UNIQUE`, indexed — see [§5] on why hashed, not plaintext |
| `expiresAt` | timestamptz | NOT NULL |
| `acceptedAt` | timestamptz | nullable |
| `invalidatedAt` | timestamptz | nullable |
| `invitedByAdminId` | UUID | FK → `PlatformAdmin.id`, nullable, indexed |
| `createdAt` | timestamptz | NOT NULL |

No `updatedAt` — `acceptedAt`/`invalidatedAt` already capture the only two mutations this row ever undergoes; a generic `updatedAt` would add nothing a specific, named timestamp doesn't already say more precisely ([DDS §7]'s guidance on when to omit it). No `deletedAt` — an Invitation is never deleted; its outcome is fully expressed by the three timestamp fields.

**`AuditLog` (existing table, extended)**

| Column | Type | Constraint | Change from Module 0 |
|---|---|---|---|
| `platformAdminId` | UUID | FK → `PlatformAdmin.id`, nullable, indexed | **New** — see [§5], the existing table has no way to attribute an action to a Platform Admin today |

### Relationships & Cascade Behavior

| Relationship | On delete |
|---|---|
| `Invitation.tenantId` → `Tenant.id` | `RESTRICT` — a Tenant is never hard-deleted (no such workflow exists, [Product Bible §6.10]), so this is theoretical, but `RESTRICT` is the correct default per [DDS §8] regardless |
| `Tenant.createdByAdminId` / `Invitation.invitedByAdminId` / `AuditLog.platformAdminId` → `PlatformAdmin.id` | `SET NULL` — if a Platform Admin account is ever removed, historical attribution should degrade to "unknown admin," not block the removal or cascade-delete Tenant history |

### Indexes

| Table | Index | Type | Purpose |
|---|---|---|---|
| `Tenant` | `status` | B-tree | Tenant List's status filter |
| `Tenant` | `createdAt` | B-tree | Default sort |
| `Tenant` | `createdByAdminId` | B-tree | FK, mandatory per [DDS §13] |
| `Invitation` | `tokenHash` | Unique B-tree | Accept-Invitation lookup — high-frequency, latency-sensitive |
| `Invitation` | `tenantId` | B-tree | FK, mandatory |
| `Invitation` | `(tenantId) WHERE invalidatedAt IS NULL AND acceptedAt IS NULL` | **Partial** | Finds "the current live invitation" without scanning historical attempts — a direct, concrete use of [DDS §13]'s partial-index guidance |
| `Invitation` | `invitedByAdminId` | B-tree | FK |
| `AuditLog` | `platformAdminId` | B-tree | FK, new |

### Unique Constraints

| Table | Constraint | Notes |
|---|---|---|
| `Invitation.tokenHash` | Unique | The only new hard-uniqueness rule this feature introduces |
| `Tenant.name` | **None** | Deliberately not unique — [Tenant Management spec §5] treats duplicate Company Names as a soft warning, not a database-level rejection |

### Soft Delete Strategy

**`Tenant` does not get a conventional `deletedAt` column.** The `ARCHIVED` status already *is* the soft-delete-equivalent state — per [Tenant Management spec §4 Rule 5], archiving changes reachability, not existence. Adding a separate `deletedAt` alongside `status = ARCHIVED` would create two overlapping signals for the same fact, which [DDS]'s own governing principle explicitly warns against. `Invitation` needs no soft delete either — its terminal states are already fully expressed by `acceptedAt`/`invalidatedAt`.

### Audit Strategy

Every lifecycle transition ([§2]) is written to the existing `AuditLog` table via the Audit Logging platform service ([HLD §15]) — this feature does not introduce a second audit mechanism. The one required change is the `platformAdminId` addition above, without which none of this feature's actions (all Platform-Admin-performed) could be correctly attributed at all.

### Multi-Tenant Strategy

**`Tenant` and `Invitation` are a genuine exception to the platform's usual tenant-scoping rule, and that exception needs to be stated precisely, not glossed over.** Every other table in this platform is *owned by* a Tenant (`tenantId` points to the Tenant that data belongs to). `Tenant` itself is not owned by a Tenant — its `id` is *what other tables' `tenantId` will reference*. Access control here is **RBAC-based, not tenant-scoped**: a Platform Admin's authorization check is "is this identity a Platform Admin at all" ([HLD §11]/[§12]), not "does this row belong to the caller's Tenant," because a Platform Admin legitimately operates across every Tenant by design ([Product Bible §4]). `Invitation` follows the same logic — it has a `tenantId` (which Tenant it's for), but is read and written by Platform Admin, not by a Tenant-scoped identity. Once an Invitation is accepted and a `User` row is created, that `User` — and everything it subsequently does — becomes properly tenant-scoped under the platform's standard model, unchanged.

---

## 5. Review

### Normalization

**No issue found**, but one deliberate trade-off is worth stating explicitly rather than leaving implicit: `Tenant.status` is a **stored, authoritative field**, updated transactionally alongside `Invitation` changes (e.g., accepting an invitation updates `Invitation.acceptedAt` and `Tenant.status = ACTIVE` in the same transaction) — it is *not* derived on every read from `Invitation` state. This is a conscious choice: `Tenant.status` is read on nearly every request (list views, every authorization check), while it changes rarely — a stored field is the right call here specifically because of that read/write ratio, not a default habit.

### Performance Concerns

- Token lookup (`Invitation.tokenHash`) is the one truly latency-sensitive path in this feature — covered by a unique index, not optional.
- "Find the current live invitation for this Tenant" is covered by the partial index above rather than a full scan of historical attempts, which will otherwise grow unbounded over a Tenant's lifetime (repeated resends).

### Security Issues

**The most important finding in this review**: storing `Invitation.token` in plaintext would mean that any database read access (a bug, a backup export, insider access) directly exposes a currently-valid credential an attacker could use to complete an Owner's onboarding as themselves. **Recommendation: store only a hash of the token** (`tokenHash`, already reflected in [§3]/[§4] above), with the actual token existing only in the emailed link and the verification request — the same treatment already correctly applied to passwords, extended here to a second class of bearer credential this feature introduces. This was not yet decided by the feature spec (which described the *behavior* of tokens, not their storage), so it's flagged here as a genuine addition, not a restatement.

The `AuditLog.platformAdminId` gap ([§4]) is also a security-relevant finding, not just a data-completeness one — without it, no Tenant Management action in this entire feature can be correctly attributed to *which* Platform Admin performed it, undermining the audit trail's value the moment there is ever more than one Platform Admin account.

### Future Scalability Issues

- The `createdByAdminId`/`invitedByAdminId` attribution fields, added now, are exactly what a future multi-Platform-Admin / "Support" role model ([Tenant Management spec §7]/[§11], still Future Enhancement) will need — this design doesn't just avoid blocking that future, it already has the field in place for it.
- Nothing here needs to change if/when the Firm/multi-Tenant access question ([PAS §25 Decision 1]) resolves — a future Firm entity would relate to multiple Tenants as its own, separate concern; this design doesn't encode any assumption that would need unwinding.

### Edge Cases

- **A Tenant cannot be Archived while an Invitation is still pending** — not because of any special-case handling, but because the lifecycle itself makes it structurally unreachable (`Archive` only exists from `SUSPENDED`, which is only reachable from `ACTIVE`, which requires an already-accepted Invitation). Worth stating explicitly as a *validation* that the state machine closes this edge case by construction, not as a gap needing extra code.
- **Two "Resend" clicks in quick succession** could otherwise create two simultaneously-live Invitation rows if not handled atomically — the invalidate-old-and-create-new operation must happen inside one transaction, a Service-layer implementation requirement to carry into Phase 2, not a schema-level fix.

### Recommended Improvements (consolidated)

1. Hash `Invitation.token` before storage — do not persist it in plaintext.
2. Add `platformAdminId` to `AuditLog` — without it, this feature's entire audit trail is attribution-incomplete from day one.
3. Add `createdByAdminId` to `Tenant` and `invitedByAdminId` to `Invitation` — cheap now, load-bearing for the already-anticipated multi-admin future.
4. Confirm the `Tenant.address`/`trn`/`contactEmail`/`contactPhone` fields' deprecation path is explicitly revisited when Business Profile reaches this same implementation phase — not forgotten because this document correctly left them untouched now.

---

**STOP — awaiting approval before Phase 2 (Prisma schema).**
