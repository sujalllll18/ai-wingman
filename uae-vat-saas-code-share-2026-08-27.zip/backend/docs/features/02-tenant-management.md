# Sprint 1 — Feature Design: Tenant Management

- **Status:** Version 1 — ready for implementation planning
- **Date:** 2026-07-30
- **Application:** Platform Admin application (not Tenant-facing)
- **Built on:** [Product Bible](../product-bible.md), [ADR-0001](../adr/0001-baseline-architecture.md), [UAE VAT Knowledge Base](../knowledge-base/README.md), [MPS](../master-product-specification.md), [PAS](../platform-architecture-specification.md), [DDS](../database-design-specification.md), [SDD](../system-design-document.md), [HLD](../high-level-design.md), [MVP Implementation Roadmap](../mvp-implementation-roadmap.md), [Business Profile feature spec](01-business-profile.md) — all treated as source of truth, none re-derived here.
- **What this is not**: platform architecture, a database schema, an API contract, UI design, or code.
- **A note this document must be honest about before anything else**: Tenant onboarding already exists and is **built** (Module 0) — Platform Admin creates a Tenant and its Owner in one atomic step today, with the Owner's password typed directly by the Platform Admin. What follows is a **deliberate rework** of that flow into an invitation-based lifecycle, not a greenfield feature. This directly resolves a gap every prior document has flagged and left open — [Product Bible A17] ("Owner/Staff onboarding via forced-password-reset or email invite, replacing today's admin-set temp password") — rather than introducing new scope from nowhere. Per [ADR §13.3], a change to already-built behavior is stated plainly, not silently absorbed as if it were new.

---

## 1. Executive Summary

**Purpose**: Tenant Management is how a new business enters Ledger. It is Platform Admin's onboarding console — creating a Tenant record, inviting its Owner securely, and managing the Tenant's lifecycle (suspension, reactivation, archival) afterward.

**Business Value**: this is the platform's revenue-onboarding funnel. Every paying customer relationship starts here, and every downstream feature — Business Profile, Customers, Invoicing, VAT — is unreachable until a Tenant exists and its Owner can log in. Getting the onboarding *security* right (no Platform-Admin-visible Owner password) also closes a real, previously-acknowledged gap rather than deferring it further.

**Scope (this document)**: Tenant lifecycle management (creation through archival) and Owner invitation, both exclusively Platform-Admin-operated — consistent with the platform's deliberate no-self-service-signup decision ([Product Bible §13]).

**Out of Scope**:
- Any Tenant-side self-service signup — deliberately excluded platform-wide, not reconsidered here.
- Business Profile's own fields (Legal Name, TRN, Address, etc.) — those belong entirely to the [Business Profile feature](01-business-profile.md) and are **not** re-collected during Tenant creation; see [§11].
- A "Support" role distinct from Platform Admin, and multiple Platform Admin accounts generally — flagged in [§7]/[§11] as genuinely out of MVP scope, not built here.
- Firm/multi-Tenant management — still blocked on [PAS §25 Decision 1], unaffected by this document.

**Dependencies**: Authentication, Authorization (RBAC), Audit Logging, Notifications/Email, Feature Flags, Configuration — detailed in [§9]. **One dependency requires a roadmap change**: this feature's Invite/Resend capabilities need a working email send path, which the [MVP Implementation Roadmap] currently schedules in Sprint 3, after Sprint 1. This is flagged explicitly in [§11] and [§12], not silently worked around.

---

## 2. Business Goal

**Why does Tenant Management exist?** Because Ledger's onboarding model is deliberately sales-led, not self-service ([Product Bible §13]) — a Platform Admin, not the business itself, brings a Tenant onto the platform. Tenant Management is the tooling that makes that model operable at more than a handful of customers: a list to manage, a lifecycle to track, and a secure way to hand control to the Owner without the Platform Admin ever knowing the Owner's password.

**Why does the lifecycle matter, not just creation?** Because "onboarded" isn't a single event — a Tenant can stall before its Owner accepts, need suspending for non-payment, need reactivating, or eventually leave the platform entirely while its historical compliance records remain legally retained ([KB §8.2]). A flat `ACTIVE`/`SUSPENDED` toggle (today's Module 0 reality) cannot represent any of that; a real lifecycle can.

**How does it affect downstream modules?** Every other module's very first precondition is "a Tenant exists, has an Owner, and that Owner can log in." Tenant Management is what makes that precondition true, and — with the archival state this document introduces — what eventually makes it stop being true safely, without deleting anything.

---

## 3. Functional Requirements

Organized as capabilities rather than fields, since this is a workflow-shaped feature — Business Profile's field-by-field format doesn't fit a lifecycle feature well, and forcing it would obscure more than it clarifies.

| Capability | Actor | Purpose | Business Reason |
|---|---|---|---|
| **Tenant List** | Platform Admin | View all Tenants with lifecycle state, plan, and key counts | Already built (Module 0); extended here to show the new lifecycle state, not rebuilt |
| **Create Tenant (Draft)** | Platform Admin | Capture the minimum needed to start onboarding: Company Name, Owner Name, Owner Email, Subscription Plan | Deliberately minimal — **not** a re-collection of Business Profile's fields (Legal Name, TRN, Address); see [§11] |
| **Invite Owner** | Platform Admin (triggers); System (sends) | Send the Owner a secure, time-limited invitation link | Replaces today's Platform-Admin-typed password — the Owner sets their own credential, which the Platform Admin never sees |
| **Resend Invitation** | Platform Admin | Issue a new invitation if the original expired or was lost | Invalidates the prior token entirely (§4/§8) — never extends an old one |
| **Owner Accepts Invitation** | Owner (unauthenticated, token-based) | Owner sets their own password via the invitation link | The one point in this feature where the Owner, not the Platform Admin, acts — see [§7]'s permissions note |
| **Edit Tenant** | Platform Admin | Update Company Name or Subscription Plan | Narrower than the original request's implication — does not include any Business Profile field, per the scope boundary in [§11] |
| **Suspend Tenant** | Platform Admin | Block platform access, reversibly | Already built (Module 0); unchanged behavior, now positioned as one state in a fuller lifecycle |
| **Activate Tenant** (reactivate) | Platform Admin | Restore access to a Suspended Tenant | Already built (Module 0) as "reactivate"; same behavior, same name used here for consistency with the lifecycle diagram in [§4] |
| **Archive Tenant** | Platform Admin | Permanently mark a Tenant as no longer active on the platform, while retaining all historical records | **New** — this is the first real design of the previously-flagged, previously-undesigned offboarding gap ([Product Bible §6.10], [MPS A15]) |
| **View Tenant Details** | Platform Admin | See a single Tenant's full lifecycle history, plan, and usage | Already built (Module 0) as the usage view; extended with lifecycle history |

---

## 4. Business Rules

### Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Invited: Invite Owner
    Invited --> Invited: Resend Invitation (new token, old invalidated)
    Invited --> Active: Owner accepts + sets password
    Active --> Suspended: Suspend
    Suspended --> Active: Activate (reactivate)
    Suspended --> Archived: Archive
    Active --> Archived: Archive (only via Suspended - see Rule 4)
    Archived --> [*]
```

| # | Rule | Rationale |
|---|---|---|
| 1 | **`Draft` is a real, persisted state** — a Platform Admin can save a partially-entered Tenant and return to it later, before ever sending an invitation. | Genuine onboarding UX need — Company info is sometimes gathered across more than one session. |
| 2 | **`Invited` → `Active` happens only when the Owner completes the invitation flow (sets a password).** No Platform Admin action moves a Tenant into `Active`. | The entire point of this rework — Platform Admin can invite, but cannot activate on the Owner's behalf, since that would recreate the password-visibility problem this feature exists to close. |
| 3 | **Resending an invitation invalidates the previous token immediately**, not just issues an additional one. | A previously-sent, possibly-forwarded or intercepted link must stop working the moment a new one is issued — a security requirement, not just a UX one. |
| 4 | **A Tenant can only be Archived from `Suspended`, never directly from `Active`.** | Forces a deliberate two-step process (Suspend, confirm, then Archive) — prevents an accidental one-click permanent-feeling action on a currently-active paying customer. |
| 5 | **Archiving is never deletion.** All historical records (Business Profile, and everything Modules 2–3 will later create) remain fully intact and queryable by Platform Admin for the retention window ([KB §8.2]) — Archive changes *reachability* for the Tenant's own users, not the data's existence. |
| 6 | **An Archived Tenant's Owner/Staff can no longer log in at all** — stricter than Suspended, which blocks access but is explicitly reversible and communicates "temporary." Archived communicates "this business's relationship with the platform has ended." | Matches the real-world distinction between "we're pausing your account" and "you've left" — conflating them would misrepresent both to the Owner. |
| 7 | **This lifecycle is entirely independent of Business Profile's own Profile Status** (`Draft`/`Active`/`Deactivated`, [Business Profile spec §4]) and of VAT Registration Status. Three independent axes, same discipline as established in the Business Profile spec — a Tenant can be lifecycle-`Active` while its Business Profile is still `Draft` (Owner logged in but hasn't finished setup yet). | Direct extension of the three-way status discipline already established — this document adds a fourth axis (platform lifecycle) rather than letting it collide with the other three. |
| 8 | **Company Name entered here pre-fills Business Profile's Business Name as a starting value the Owner can change** — it is not a second, independently-maintained copy of the same fact. | Avoids two sources of truth for "what is this business called," a direct application of the "derived, not duplicated" principle used throughout this document set. |

---

## 5. Validation Rules

| Field / Concern | Rule |
|---|---|
| Company Name | 1–200 characters, mandatory. **Not required to be unique** — see [§11], unlike TRN, a trading name has no real-world uniqueness guarantee. |
| Owner Name | 1–100 characters, mandatory. |
| Owner Email | Valid email format, mandatory, **unique platform-wide** — consistent with the existing global `User.email` uniqueness ([DDS §13]/[§22 Decision 5]) — not re-decided here, just reused. |
| Subscription Plan | Must be one of the platform's defined plans (TRIAL/STANDARD/PREMIUM, already built) — never a free-text value. |
| Duplicate Company Name | **Soft warning, not a hard block** — "a similarly-named Tenant already exists, confirm this is a different business" — since trading names legitimately repeat across unrelated UAE businesses. |
| Duplicate Owner Email | **Hard block** — an email already associated with any User (any Tenant, any role) cannot be invited again; surfaced as a specific error, not a generic failure (§8). |
| Invitation Token | Cryptographically random, single-use, tied to exactly one Tenant/Owner pair. |
| Invitation Expiry | 7 days from issuance (a reasonable, common SaaS default) — expired tokens are rejected outright, not silently extended; the remedy is Resend Invitation (Rule 3), never a client-side workaround. |
| Password (set by Owner at acceptance) | Follows the platform's password policy ([PAS §5]/[ADR §5] — a **[Design Now, Build Later]** gap this document does not itself resolve, only inherits). |

---

## 6. User Journeys

### Full onboarding: Platform Admin → Owner Login

```mermaid
sequenceDiagram
    participant Admin as Platform Admin
    participant System as Tenant Management
    participant Email as Email Service
    participant Owner
    participant Audit as Audit Logging

    Admin->>System: Create Tenant (Company Name, Owner Name/Email, Plan)
    System->>System: Validate (§5); persist as Draft
    System->>Audit: Log "Tenant created (Draft)"
    Admin->>System: Invite Owner
    System->>System: Generate single-use token, 7-day expiry
    System->>System: Transition Draft -> Invited
    System->>Email: Send invitation email
    Email-->>Owner: Invitation link
    System->>Audit: Log "Owner invited"

    Owner->>System: Opens invitation link
    System->>System: Validate token (not expired, not used, matches Tenant)
    alt Token invalid or expired
        System-->>Owner: Reject, direct to contact Platform Admin for a new invitation
    else Token valid
        Owner->>System: Sets password
        System->>System: Create Owner credential; transition Invited -> Active
        System->>Audit: Log "Tenant activated"
        System-->>Owner: Redirect to login
        Owner->>System: Logs in
        System-->>Owner: Access granted (Business Profile setup begins next, per the Business Profile spec)
    end
```

### Suspend / Reactivate

```mermaid
sequenceDiagram
    participant Admin as Platform Admin
    participant System as Tenant Management
    participant Audit as Audit Logging

    Admin->>System: Suspend Tenant
    System->>System: Transition Active -> Suspended
    System->>Audit: Log "Tenant suspended"
    Note over System: Owner/Staff login now blocked (already built behavior)

    Admin->>System: Activate (reactivate) Tenant
    System->>System: Transition Suspended -> Active
    System->>Audit: Log "Tenant reactivated"
    Note over System: Access restored immediately, no re-invitation needed
```

### Archive

```mermaid
sequenceDiagram
    participant Admin as Platform Admin
    participant System as Tenant Management
    participant Audit as Audit Logging

    Admin->>System: Archive Tenant
    System->>System: Verify current state is Suspended (Rule 4)
    alt Tenant is not Suspended
        System-->>Admin: Reject — must suspend first
    else Tenant is Suspended
        System->>Admin: Confirm — explains this is not reversible in MVP and blocks all future login
        Admin->>System: Confirms
        System->>System: Transition Suspended -> Archived
        System->>Audit: Log "Tenant archived"
        Note over System: All historical data retained per KB §8.2;<br/>Owner/Staff login now permanently blocked
    end
```

---

## 7. Permissions

**A note on "Support"**: there is no system-defined "Support" role in MVP scope, and — distinct from the Business Profile spec's "Accountant" question — this one has a second, deeper gap: the platform currently supports **exactly one** seeded Platform Admin account with no mechanism to create a second one at all ([Product Bible], original technical assessment finding, never resolved since). A "Support" role implies multiple Platform-side accounts with *different* permission levels — two unbuilt capabilities stacked on top of each other. Treated as **Future Enhancement** here (§11), not partially built.

| Action | Platform Admin | Tenant Owner | Staff |
|---|:---:|:---:|:---:|
| **Tenant List / View Details** | ✅ | — (not applicable; a Tenant does not view "the tenant list," it only sees itself) | — |
| **Create / Invite / Resend / Edit / Suspend / Activate / Archive** | ✅ | ❌ | ❌ |
| **Accept Invitation** | — | ✅ (the invited Owner only, via token, not an authenticated permission) | — |

Tenant Owner and Staff have **no operational role in this feature** beyond the Owner's one-time acceptance step — consistent with the deliberate no-self-service model ([Product Bible §13]). This asymmetric table is correct, not incomplete.

---

## 8. Error Scenarios

| Scenario | Handling |
|---|---|
| Duplicate Company Name | Soft warning shown, creation not blocked (§5) |
| Duplicate Owner Email | Hard rejection, specific error distinguishing it from a generic validation failure |
| Invitation expired | Rejected at acceptance; Owner is directed to ask the Platform Admin to Resend — no self-service token refresh |
| Invalid/tampered invitation token | Rejected outright, generic error (does not reveal whether a Tenant/token exists, to avoid leaking information to a guesser) |
| Owner already exists (email already a User elsewhere on the platform) | Rejected at invitation time — same rule as duplicate email in §5, surfaced clearly rather than as a generic failure |
| Login attempt on a Suspended Tenant | Rejected — already-built behavior, reaffirmed unchanged |
| Login attempt on an Archived Tenant | Rejected, with messaging distinct from Suspended's ("this account has been closed" vs. "temporarily suspended") — the two must not share one generic message |
| Resend Invitation after the Owner already accepted | Rejected as a no-op error — a Tenant that's already `Active` has nothing to resend |
| Archive attempted from `Active` (not `Suspended`) | Rejected per Rule 4 — the UI should not even present the option, but the backend enforces it regardless of what the client sends |
| Concurrent duplicate Create Tenant submissions | Prevented via the same atomic-creation discipline already used in Module 0's existing Tenant+Owner transaction |

---

## 9. Dependencies

| Platform Service | How Tenant Management uses it |
|---|---|
| **Authentication** | Owner credential creation happens here at acceptance time; every Platform Admin action in this feature requires an already-verified Platform Admin identity. |
| **Authorization (RBAC)** | Every capability in [§3] is Platform-Admin-only, enforced via the same `requirePermission()` pattern as every other feature — no exception for this feature's own significance. |
| **Audit Logging** | Every lifecycle transition (§4) is an audit event — Tenant creation, invitation sent, activation, suspension, reactivation, archival — the fullest, most consistent use of Audit Logging of any feature so far. |
| **Notifications / Email** | Invite and Resend both require a working email send path. **This is a real, flagged scheduling conflict**: the [MVP Implementation Roadmap] currently builds the Notifications service in Sprint 3, not Sprint 1 — addressed directly in [§11]/[§12]. |
| **Feature Flags** | Selecting a Subscription Plan at Create Tenant time is what activates that plan's feature set via the Feature Flags service ([HLD §14]) — this feature is the entry point that makes Feature Flags meaningful for a given Tenant, not just a consumer of it. |
| **Configuration** | Company Name pre-fills a Configuration-adjacent Business Profile value (§4 Rule 8) — a light, one-directional relationship, not a two-way sync. |

---

## 10. Future Consumers

| Module | How it depends on Tenant Management |
|---|---|
| **Business Profile** | Cannot exist until a Tenant is `Active`; Company Name pre-fills its Business Name field (§4 Rule 8). |
| **Customers, Suppliers, Products/Services** | Gated entirely on Tenant existence and `Active` state — no direct field dependency beyond that. |
| **Invoices** | Same gating; an Archived Tenant cannot issue anything, consistent with Rule 6. |
| **VAT** | Same gating; historical VAT Returns remain retrievable for an Archived Tenant per [KB §8.2], even though no new ones can be generated. |
| **Reports** | Same gating; Platform Admin's own Tenant-list-level reporting (not build here) would eventually read lifecycle state as a dimension. |

---

## 11. Product Design Review — Findings

### Missing fields / capabilities identified

| Item | Classification | Reasoning |
|---|---|---|
| **`Draft` as a real, persisted state** | **Required for MVP** | The user's own lifecycle names it; without persistence, a partially-entered Tenant is lost if the Platform Admin navigates away — a real, avoidable UX failure. |
| **Invitation token invalidation on resend** | **Required for MVP** | A security requirement, not a nicety — an old link must stop working the moment a new one is issued (§4 Rule 3). |
| **Explicit Suspended-vs-Archived login messaging** | **Recommended for MVP** | Cheap, and prevents an Owner from believing a permanently-closed account is merely paused. |
| **A confirmation step before Archive** | **Required for MVP** | Given Archive is a one-way trip to permanently blocked login (data retained, but access gone), a plain button with no confirmation is a real risk of an accidental, hard-to-reverse-feeling action. |

### Unnecessary / descoped items

| Item | Original implication | Recommendation |
|---|---|---|
| **Re-collecting Business Profile fields during Tenant creation** | The original request's field examples (Company Name, etc.) could be read as overlapping with Business Profile | **Explicitly descoped** — Tenant Management captures only what's needed to invite an Owner; everything else is the Owner's own job in Business Profile. Two independently-maintained "Business Name" fields would be a genuine data-integrity risk, not a convenience. |
| **"Support" as a distinct role** | Requested in §7 | **Descoped to Future Enhancement** — requires multi-Platform-Admin-account support, which doesn't exist at all today, stacked on top of custom-role tooling that's V1 scope. Building a fake "Support" permission set without real multi-admin accounts underneath it would be building UI for a capability that can't actually be used correctly. |

### Additional business rules suggested

Already incorporated into [§4]: the Archive-only-from-Suspended two-step rule (Rule 4), the independence of this lifecycle from Business Profile's and VAT Registration's status axes (Rule 7), and the Company-Name-pre-fills-Business-Name relationship (Rule 8) instead of duplicate data entry.

### Edge cases identified

- An Owner attempts to use an invitation link twice (once successfully, then again) — the second attempt must fail cleanly (token is single-use, already consumed), not silently reset their password.
- A Platform Admin invites, the Owner never responds, and the Platform Admin also tries to Edit the Tenant's Plan while still `Invited` — Edit should remain available in `Invited` state (a Plan decision shouldn't be blocked on the Owner's response timing).
- A Tenant is Suspended while its Owner has an open session — the existing platform-wide rule already covers this (access blocked on the *next* request, not requiring a fresh login, [ADR §6]) — reaffirmed, not redesigned.

### UX improvements with business-logic impact

- **Progressive Draft saving** (already Required, above) mirrors the same "don't force one long form" instinct the Business Profile spec applied to field completion — applied here to the *process*, not just the data.
- **Distinguishing Suspend's "temporary" framing from Archive's "closed" framing** in every piece of UI copy, not just the login-rejection message — consistency matters more than any single screen.

---

## 12. Final Review

**Is this feature implementation-ready?** Functionally, yes — but **not without a roadmap adjustment first**. This feature cannot ship its Invite/Resend capabilities without a working email send path, and the [MVP Implementation Roadmap] currently schedules Notifications in Sprint 3. Recommend pulling a minimal, email-only Notifications build into Sprint 1 alongside this feature, rather than either delaying Tenant Management's rework to Sprint 3 (which would leave Business Profile's Sprint 1 built against the *old*, less secure onboarding flow) or building a one-off email path outside the platform service (which would violate the "single home per concern" principle this entire document set enforces).

**What assumptions remain?**
- Whether "Support" is genuinely out of scope for MVP (this document assumes yes, per §11) — worth the project owner's explicit confirmation, not just this document's inference.
- The exact password policy applied at Owner acceptance is inherited, not defined here — still a [PAS §5] **[Design Now, Build Later]** item this feature depends on but doesn't resolve.
- Whether Archive should ever become reversible in a later version — this document deliberately treats it as one-way for MVP; revisit only with real customer signal, not speculatively.

**What would QuickBooks, Xero, or Zoho Books do differently?** All three default to self-service signup with email verification — Ledger's Platform-Admin-only onboarding is a **deliberate divergence** from that pattern ([Product Bible §13]), reflecting a sales-led B2B model rather than an oversight. Where this document *does* borrow from them directly is the invitation-link, set-your-own-password pattern itself, which is standard practice precisely because it avoids the Platform-Admin-visible-password problem this rework exists to fix.

**What should be resolved before coding begins?**
1. Update the [MVP Implementation Roadmap] to reflect this feature's real Sprint 1 dependency on a minimal Notifications/email build — a document update, per [ADR §13.3], not a silent workaround during implementation.
2. Confirm "Support" role is out of scope with the project owner directly, not just assumed here.
3. Confirm the 7-day invitation expiry window is acceptable, or specify a different one — arbitrary but stated, not left implicit.
