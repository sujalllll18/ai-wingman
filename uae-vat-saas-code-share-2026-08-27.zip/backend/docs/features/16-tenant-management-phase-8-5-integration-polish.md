# Tenant Management — Phase 8.5: Integration & Polish (Completion Phase)

- **Status:** Proposed — **not yet applied to `frontend/`**; this document also serves as Tenant Management's closing report
- **Date:** 2026-07-30
- **Two findings that shape this entire report**: (1) no frontend page exists for Owner Invitation Acceptance — a gap present since [Phase 7], not introduced here, but only fully visible once the whole flow is traced end-to-end, which is what this phase asked for; (2) three dialogs shared near-identical plumbing, consolidated below into one small new hook, with verified-unchanged behavior.

---

## Minimal Code Changes

### `components/tenant-management/hooks/useTenantStatusMutation.js` (new)

```js
"use client";

import { useApi } from "../../../hooks/useApi";
import { useToast } from "../../../hooks/useToast";
import { adminAuth } from "../../../lib/auth";

// Consolidates the identical execute -> toast -> error-swallow pattern that
// Suspend/Activate/Archive each implemented separately (Phase 8.4).
// Behavior-preserving refactor only - verified against each call site below,
// not a new capability. Does not modify useApi/useToast (frozen); composes them.
export function useTenantStatusMutation(apiFn) {
  const { execute, loading, error } = useApi(apiFn);
  const { showToast } = useToast();

  async function run(tenantId, successMessage, onSuccess) {
    try {
      const token = adminAuth.get();
      await execute(token, tenantId);
      showToast(successMessage);
      onSuccess();
    } catch {
      // error already captured by useApi and exposed via `error` below
    }
  }

  return { run, loading, error };
}
```

### `components/tenant-management/SuspendTenantDialog.js` (refactored, behavior unchanged)

```jsx
"use client";

import { api } from "../../lib/api";
import { useTenantStatusMutation } from "./hooks/useTenantStatusMutation";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function SuspendTenantDialog({ tenant, onClose, onSuccess }) {
  const { run, loading, error } = useTenantStatusMutation(api.suspendTenant);
  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Its Owner and Staff will be unable to log in until reactivated. This is reversible.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Suspend Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Suspending…" : "Suspend"}
      cancelLabel="Cancel"
      variant="danger"
      busy={loading}
      onConfirm={() => run(tenant.id, `"${tenant.name}" has been suspended.`, onSuccess)}
      onCancel={onClose}
    />
  );
}
```

### `components/tenant-management/ActivateTenantDialog.js` (refactored, behavior unchanged)

```jsx
"use client";

import { api } from "../../lib/api";
import { useTenantStatusMutation } from "./hooks/useTenantStatusMutation";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function ActivateTenantDialog({ tenant, onClose, onSuccess }) {
  const { run, loading, error } = useTenantStatusMutation(api.activateTenant);
  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Access will be restored immediately.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Activate Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Activating…" : "Activate"}
      cancelLabel="Cancel"
      variant="primary"
      busy={loading}
      onConfirm={() => run(tenant.id, `"${tenant.name}" has been activated.`, onSuccess)}
      onCancel={onClose}
    />
  );
}
```

### `components/tenant-management/ArchiveTenantDialog.js` (refactored, behavior unchanged)

```jsx
"use client";

import { api } from "../../lib/api";
import { useTenantStatusMutation } from "./hooks/useTenantStatusMutation";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function ArchiveTenantDialog({ tenant, onClose, onSuccess }) {
  const { run, loading, error } = useTenantStatusMutation(api.archiveTenant);
  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Archiving is permanent: this Tenant's Owner and Staff will never be able to log in again. All historical records are retained.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Archive Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Archiving…" : "Archive"}
      cancelLabel="Cancel"
      variant="danger"
      busy={loading}
      onConfirm={() => run(tenant.id, `"${tenant.name}" has been archived.`, onSuccess)}
      onCancel={onClose}
    />
  );
}
```

**Verified unchanged**: each dialog calls the same API function, shows the same toast text, shows the same error text, disables the same buttons during `loading` — the only thing that changed is *where* the plumbing lives. `InviteOwnerDialog` is untouched — it has no equivalent duplication to remove (it's the only form-based dialog).

Tenant List, Tenant Details, Create Tenant, and `TenantActionMenu` required **no code changes** — reviewed below, found correct as built in Phases 8.1–8.4.

---

## Verify Complete User Flow

| Transition | Status |
|---|---|
| Tenant List → Create Tenant | ✅ Works (`+ New Tenant` link) |
| Create Tenant → Tenant Details | ✅ Works (`router.push` using the API's returned `tenant.id`) |
| Tenant Details: Invite Owner (Draft → Invited) | ✅ Works; `load()` correctly reflects the new `INVITED` status |
| **Invited → Active** | ❌ **Not achievable through this UI at all** — see the finding above. This is the Owner's action via `POST /invitations/accept`, which has no frontend page. Not a defect in this phase's code; a gap in what's ever been built. |
| Suspend (Active → Suspended) | ✅ Works, but only reachable if a Tenant became `ACTIVE` by some means outside this UI |
| Activate (Suspended → Active) | ✅ Works |
| Archive (Suspended → Archived, only) | ✅ Works, correctly blocked from `ACTIVE` |
| Tenant Details → Tenant List | ✅ Works (`Back to Tenants`), and correctly shows fresh data on return (Next.js re-mounts the List page, re-running its own fetch — no stale cache) |

**Honest conclusion**: the flow as given cannot be fully verified end-to-end today, and that's a true statement about the product, not a gap in this phase's review.

---

## Architecture Review

The three refactored dialogs are now purely declarative — title, message text, button labels, and variant — with zero duplicated mutation-handling logic. `InviteOwnerDialog` remains a necessary standalone implementation (Phase 8.4's finding, unchanged). `TenantActionMenu`'s zero-hardcoded-status-logic property, verified in Phase 8.1, still holds — nothing in this phase touched it.

## API Compliance Review

| Approved endpoint | Consumed? |
|---|---|
| `GET /tenants` | ✅ |
| `GET /tenants/:id` | ✅ |
| `POST /tenants` | ✅ |
| `POST /tenants/:id/invite` | ✅ |
| `PATCH /tenants/:id/suspend` | ✅ |
| `PATCH /tenants/:id/activate` | ✅ |
| `PATCH /tenants/:id/archive` | ✅ |
| `POST /tenants/:id/resend-invitation` | **Exists in `lib/api.js`, consumed by no UI** — see Known Backend Gaps |
| `POST /invitations/accept` | **Exists on the backend, consumed by no UI at all** — see Known Backend Gaps |

No endpoint outside this approved set was ever called, across all five sub-phases.

## Accessibility Review

Re-verified across the integrated whole, not just per-component: one `<h1>` per page, one `<h2>` per card/section including the Phase 8.4-added Actions card — no heading hierarchy violation introduced by wiring everything together. `ConfirmationDialog`'s `role="alertdialog"` (Suspend/Activate/Archive — decisions with consequences) versus `InviteOwnerDialog`'s `role="dialog"` (a form, not an alert) is a deliberate, correct distinction, confirmed on review, not something to unify. No regression found from Phase 8.4's already-recorded partial-focus-trap limitation — it's the same known gap, not a new one.

## Responsiveness Review

No layout regression found. The Phase 8.4-added Actions card's `TenantActionMenu` wraps correctly at narrow widths via its existing `flex-wrap` rule (Phase 8.1) — no new CSS was needed to integrate it into Tenant Details.

## Performance Review

No duplicate fetches found: each page's single `load()` call remains the only fetch per mount, and `handleActionSuccess` triggers exactly one re-fetch per successful mutation, in both Tenant List and Tenant Details. No unnecessary state was introduced by this phase's refactor — `useTenantStatusMutation` replaces three copies of the same state with one shared implementation, a net reduction.

---

## Technical Debt

| Item | Recommendation |
|---|---|
| `app/admin/dashboard/page.js` (Module 0, pre-Tenant-Management) is now dead/superseded by `app/admin/tenants/page.js` | Recommend removal or a redirect, once explicitly approved — not touched in this phase, since deleting a page is a real action outside "minimal changes to integrate," not something to do unilaterally |
| `ConfirmationDialog`'s single-`<p>` message slot forces error text to replace the confirmation message rather than showing alongside it via `ErrorBanner` | Carried from Phase 8.4, unresolved — would need the frozen component extended |

## Known Backend Gaps (frontend-side, in this case)

1. **No frontend page exists for Owner Invitation Acceptance** (`POST /invitations/accept`) — the single most significant remaining gap in Tenant Management as a whole. The backend has supported this since Phase 5; no UI has ever consumed it.
2. **`ResendInvitationDialog` was never built** — the button exists (Phase 8.1, frozen `TENANT_ACTIONS_BY_STATUS`), the API method exists (Phase 8), no dialog answers the click.
3. `createdByAdmin`/invitation-detail data still isn't included in `GET /tenants`/`GET /tenants/:id` responses (Phase 7/8.3, unresolved).
4. No structured error codes from the API — "not found" detection still relies on string-matching (Phase 8.3, unresolved).

## Production Readiness Checklist

- [ ] Build the Accept Invitation page — **blocking**, without it no Tenant can ever legitimately reach `ACTIVE` through the product
- [ ] Build `ResendInvitationDialog`
- [ ] Remove or redirect the dead `/admin/dashboard` page
- [ ] Server-side pagination/search on `GET /tenants` (acceptable gap at MVP scale, not launch-blocking)
- [ ] Rate limiting on mutation endpoints ([Phase 6], standing gap)
- [ ] MFA for Platform Admin ([Phase 6], standing gap)
- [ ] Automated test coverage for this feature (standing gap since [HLD])
- [ ] Full Tab-cycling focus trap on both dialog implementations

## Final Module Review

| Checklist item | Status |
|---|---|
| All approved APIs consumed | ⚠️ Partially — 7 of 9 approved Tenant Management endpoints have a UI path; `resendInvitation` and `accept` do not |
| No frontend/backend drift | ✅ |
| No placeholder functionality remaining | ❌ — the two gaps above are real, not placeholders that were quietly resolved |
| No invented endpoints | ✅ |
| No duplicated business logic | ✅ — improved by this phase's refactor |
| Component responsibilities remain clean | ✅, with one documented, necessary exception (`InviteOwnerDialog`) |

## Remaining Future Enhancements

Everything already named across Phases 7–8.4's Future Improvements sections, plus, from this phase specifically: extending `ConfirmationDialog` with a `children` slot (would resolve two separate findings at once — error display and the `InviteOwnerDialog` duplication); the Accept Invitation and Resend Invitation gaps above, which are the two items most worth prioritizing next, ahead of any polish item, since they're the difference between "the demo works" and "a real Tenant can actually go live."

---

**This completes Tenant Management as scoped through Phase 8.5 — with the two gaps above stated plainly, not smoothed over. Waiting for approval before the next module.**
