# Tenant Management — Phase 8.1: Tenant List

- **Status:** Proposed — **not yet applied to `frontend/`**; awaiting approval before Phase 8.2
- **Date:** 2026-07-30
- **Consumes**: `GET /tenants` only ([Phase 5], Approved), the shared components and `TENANT_ACTIONS_BY_STATUS`/badge constants from [Phase 8] (Approved, unmodified). No dialogs, no mutations, no Details/Create pages — per the explicit scope of this phase.
- **Three findings, addressed above, not silently**: `Button`'s missing link-rendering mode, the responsive-table technique's screen-reader caveat, and the status-filter scope observation.

---

## `app/admin/tenants/page.js`

```jsx
"use client";

import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { api } from "../../../lib/api";
import { adminAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import Card from "../../../components/ui/Card";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Button from "../../../components/ui/Button";
import TenantTable from "../../../components/tenant-management/TenantTable";

const PAGE_SIZE = 10;

export default function TenantListPage() {
  const [tenants, setTenants] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  // Phase 8.4 will render the actual dialog based on this state. No dialog
  // component exists yet this phase - action buttons only record intent.
  const [pendingAction, setPendingAction] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const { tenants } = await api.listTenants(token);
      setTenants(tenants);
    } catch (err) {
      setError(err.message);
    }
  }

  const filtered = useMemo(() => {
    if (!tenants) return [];
    if (!search.trim()) return tenants;
    const q = search.trim().toLowerCase();
    return tenants.filter((t) => t.name.toLowerCase().includes(q));
  }, [tenants, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function handleSearchChange(value) {
    setSearch(value);
    setPage(1); // avoid landing on a now-empty page after narrowing the results
  }

  function handleAction(action, tenant) {
    setPendingAction({ action, tenant });
    // Phase 8.4 wires this state to an actual dialog. Until then this is a
    // recorded intent only - no mutation happens from this phase.
  }

  return (
    <div>
      <PageHeader
        title="Tenants"
        description="Every business subscribed to the platform, at a glance."
        action={
          <Link href="/admin/tenants/new" className="btn btn-primary">
            + New Tenant
          </Link>
        }
      />

      {error && (
        <div style={{ marginBottom: 16 }}>
          <ErrorBanner message={error} />
          <Button variant="outline" onClick={load}>
            Retry
          </Button>
        </div>
      )}

      <div className="field" style={{ maxWidth: 320 }}>
        <label htmlFor="tenant-search">Search</label>
        <input
          id="tenant-search"
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
          placeholder="Search by company name"
        />
      </div>

      <Card style={{ padding: 0 }}>
        {tenants === null && !error ? (
          <LoadingSkeleton rows={6} columns={6} />
        ) : filtered.length === 0 ? (
          <EmptyState>
            {search
              ? "No Tenants match your search."
              : "No Tenants yet. Onboard the first business to get started."}
          </EmptyState>
        ) : (
          <TenantTable tenants={pageItems} onAction={handleAction} />
        )}
      </Card>

      {totalPages > 1 && (
        <nav className="pagination" aria-label="Tenant list pages">
          <Button variant="outline" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
            Previous
          </Button>
          <span className="mono">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </nav>
      )}
    </div>
  );
}
```

---

## `components/tenant-management/TenantTable.js`

```jsx
import TenantTableRow from "./TenantTableRow";

export default function TenantTable({ tenants, onAction }) {
  return (
    <table className="responsive-table">
      <thead>
        <tr>
          <th>Company</th>
          <th>Plan</th>
          <th>Status</th>
          <th>Created</th>
          <th>Created By</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {tenants.map((tenant) => (
          <TenantTableRow key={tenant.id} tenant={tenant} onAction={onAction} />
        ))}
      </tbody>
    </table>
  );
}
```

## `components/tenant-management/TenantTableRow.js`

```jsx
import Link from "next/link";
import PlanTag from "../PlanTag";
import TenantStatusBadge from "./TenantStatusBadge";
import TenantActionMenu from "./TenantActionMenu";

export default function TenantTableRow({ tenant, onAction }) {
  return (
    <tr>
      <td data-label="Company">{tenant.name}</td>
      <td data-label="Plan">
        <PlanTag plan={tenant.plan} />
      </td>
      <td data-label="Status">
        <TenantStatusBadge status={tenant.status} />
      </td>
      <td data-label="Created" className="mono">
        {new Date(tenant.createdAt).toLocaleDateString()}
      </td>
      {/* Gap #1 from Phase 7 (§11): createdByAdmin is not included by the
          approved API response yet, so this correctly falls back to "—"
          rather than showing a raw UUID. Forward-compatible: shows the
          email the moment the backend adds the include. */}
      <td data-label="Created By" className="mono">
        {tenant.createdByAdmin?.email ?? "—"}
      </td>
      <td data-label="Actions">
        <div className="tenant-row-actions">
          <Link href={`/admin/tenants/${tenant.id}`} className="btn btn-outline">
            View
          </Link>
          <TenantActionMenu tenant={tenant} onAction={onAction} />
        </div>
      </td>
    </tr>
  );
}
```

## `components/tenant-management/TenantStatusBadge.js`

```jsx
import {
  TENANT_STATUS_LABELS,
  TENANT_STATUS_BADGE,
  TENANT_STATUS_TOOLTIPS,
} from "../../constants/tenantStatus";

export default function TenantStatusBadge({ status }) {
  const treatment = TENANT_STATUS_BADGE[status];
  const label = TENANT_STATUS_LABELS[status] || status;
  const tooltip = TENANT_STATUS_TOOLTIPS[status] || "";
  const modifierClass = status.toLowerCase();

  const accessibleLabel = `Status: ${label}. ${tooltip}`;

  if (treatment === "stamp") {
    return (
      <span
        className={`stamp ${modifierClass === "active" ? "" : modifierClass}`}
        title={tooltip}
        aria-label={accessibleLabel}
      >
        {label}
      </span>
    );
  }

  return (
    <span className={`tag ${modifierClass}`} title={tooltip} aria-label={accessibleLabel}>
      {label}
    </span>
  );
}
```

*(Renders the plain status label inside the stamp, e.g. "Active," rather than the old `StatusStamp.js`'s bespoke two-line "In Good Standing" — that component only ever handled two states and isn't reused here; a single consistent label treatment across all five statuses is clearer than a special phrase for one of them. `StatusStamp.js` itself is untouched, still used wherever Module 0's existing pages reference it.)*

## `components/tenant-management/TenantActionMenu.js`

```jsx
import { TENANT_ACTIONS_BY_STATUS } from "../../constants/tenantStatus";

// Labels live here, not in constants/tenantStatus.js - that file is frozen
// this phase (Implementation Rules), and a label string is presentation
// detail, not the status logic TENANT_ACTIONS_BY_STATUS already owns.
const ACTION_LABELS = {
  inviteOwner: "Invite Owner",
  resendInvitation: "Resend Invitation",
  suspend: "Suspend",
  activate: "Activate",
  archive: "Archive",
};

export default function TenantActionMenu({ tenant, onAction }) {
  const availableActions = TENANT_ACTIONS_BY_STATUS[tenant.status] || [];

  if (availableActions.length === 0) {
    return <span className="helptext">No actions available</span>;
  }

  return (
    <div className="tenant-action-menu">
      {availableActions.map((action) => (
        <button
          key={action}
          type="button"
          className="btn btn-outline"
          onClick={() => onAction(action, tenant)}
          aria-label={`${ACTION_LABELS[action] || action} — ${tenant.name}`}
        >
          {ACTION_LABELS[action] || action}
        </button>
      ))}
    </div>
  );
}
```

**Never hardcoded, verified**: this component contains zero `if (status === ...)` branches — every decision about which actions exist for a given status comes from `TENANT_ACTIONS_BY_STATUS`, imported unmodified from Phase 8. Adding a new status or changing its allowed actions later means editing the constant, never this component.

---

## CSS additions (new selectors only, existing tokens throughout)

```css
.tag.draft, .tag.invited {
  --tag-color: var(--color-ink-soft);
}
.stamp.archived {
  --stamp-color: var(--color-ink-soft);
}

.tenant-action-menu {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  margin-top: 16px;
}

/* Responsive table -> stacked cards, per UX Blueprint §9 */
@media (max-width: 640px) {
  .responsive-table thead {
    display: none;
  }
  .responsive-table,
  .responsive-table tbody,
  .responsive-table tr,
  .responsive-table td {
    display: block;
    width: 100%;
  }
  .responsive-table tr {
    border: 1px solid var(--color-line);
    border-radius: var(--radius);
    margin-bottom: 12px;
    padding: 12px;
  }
  .responsive-table td {
    border-bottom: none;
    padding: 6px 0;
  }
  .responsive-table td::before {
    content: attr(data-label);
    display: block;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--color-ink-soft);
    margin-bottom: 2px;
  }
}
```

**Draft/Invited deliberately share one grey tag color, distinguished only by label text** — both are pre-activation, in-progress states with no meaningful visual hierarchy between them; giving them arbitrary distinct hues would imply a difference that doesn't exist, and text already carries the real distinction (consistent with the color-independence requirement below, not in tension with it).

---

## Architecture Review

- **Component boundaries**: `TenantTable` → `TenantTableRow` → (`TenantStatusBadge`, `TenantActionMenu`, existing `PlanTag`) — each component has exactly one responsibility, matching [HLD]'s general componentization discipline applied to the frontend.
- **No status logic outside the constant**: verified above — this was the single most important structural requirement of this phase, and it holds.
- **Mutation-free, verified**: `handleAction` only sets local state; no `api.suspendTenant`/`inviteOwner`/etc. is called anywhere in this phase's code.

## API Compliance Review

Exactly one endpoint called: `GET /tenants` via `api.listTenants(token)`, unmodified from [Phase 8]'s corrected `lib/api.js`. No parameters sent (the approved endpoint accepts none) — search and pagination are entirely client-side, consistent with the gap already recorded in [Phase 7 §11].

## Accessibility Review

- Search input has an associated `<label>`; pagination nav has `aria-label`; every action button has a tenant-specific `aria-label` (not just "Suspend," but "Suspend — Al Noor Trading LLC"), since a screen reader user tabbing through multiple identical-looking buttons needs that context.
- `LoadingSkeleton` carries `aria-busy="true"`.
- Status badges pass color-independence — text label always present, never color-only.
- **Known limitation, not fixed here**: the responsive-table technique's `content: attr(data-label)` pseudo-headers are not reliably announced by all screen readers — a documented limitation of this common CSS pattern, not specific to this implementation. A more robust version would use visually-hidden real DOM text instead of generated content. Flagged as a Future Improvement below, not silently presented as fully solved.

## Performance Review

Single fetch on mount; filtering is `useMemo`'d against `[tenants, search]` so it doesn't re-run on unrelated re-renders (e.g., a pagination click). Pagination slicing is a cheap array operation, not memoized separately — not worth the complexity at MVP data volumes. The whole Tenant list downloads on every visit (no server-side pagination) — acceptable now, a real limitation at Firm-scale, already recorded in [Phase 7 §11] and not re-litigated here.

## UX Review

Matches the UX Blueprint's Tenant List wireframe for search, pagination, empty/loading/error states, and status-aware actions. The status filter dropdown from the original wireframe is intentionally not included here — see the note above this document.

---

**STOP — awaiting approval before Phase 8.2 (Create Tenant). Not yet applied to `frontend/`.**
