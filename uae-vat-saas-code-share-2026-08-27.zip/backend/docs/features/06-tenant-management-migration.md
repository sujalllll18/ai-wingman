# Tenant Management — Implementation Phase 3: Migration

- **Status:** Proposed — **not yet applied to the database or the repository's `prisma/migrations/` folder**; awaiting approval before Phase 4 (services/controllers)
- **Date:** 2026-07-30
- **Implements:** [Phase 2: Prisma Schema](05-tenant-management-prisma-schema.md) (Approved) — exactly. No schema element below was not already in the approved `schema.prisma`.
- **Datasource today:** SQLite, dev-only (`DATABASE_URL="file:./dev.db"`, [ADR §4]). This migration is written for SQLite, since that's what actually runs today — see [§2] on why it will *not* be reused verbatim when Postgres eventually arrives.

---

## 1. Prisma Migration

Proposed folder: `prisma/migrations/20260730120000_tenant_management/migration.sql` (illustrative timestamp — `prisma migrate dev --name tenant_management` will generate the real one).

**Why `Tenant` needs a full table rebuild but `AuditLog` doesn't**: SQLite's `ALTER TABLE` can add a plain column — including one with a `REFERENCES` clause — but it **cannot** alter an existing column's default value. `AuditLog` only gains a new column, so a simple `ADD COLUMN` suffices. `Tenant` needs its `status` column's default changed from `'ACTIVE'` to `'DRAFT'` *in addition to* gaining a new column — SQLite has no `ALTER COLUMN ... SET DEFAULT`, so the only safe path is: create a new table with the final shape, copy every existing row's data across unchanged, drop the old table, rename the new one into place. This is SQLite's own documented pattern for this class of change, not a Prisma workaround.

```sql
-- ============================================================================
-- Tenant: add createdByAdminId (new FK) and change status's default
-- (ACTIVE -> DRAFT). Requires SQLite's table-rebuild pattern because SQLite
-- cannot ALTER an existing column's default value directly.
--
-- IMPORTANT: existing rows are copied with their CURRENT status value
-- unchanged (INSERT ... SELECT preserves actual data). The new DEFAULT
-- 'DRAFT' applies only to future inserts that don't specify a status - no
-- existing Tenant's status is altered by this migration.
-- ============================================================================
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;

CREATE TABLE "new_Tenant" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "address" TEXT,
    "trn" TEXT,
    "contactEmail" TEXT,
    "contactPhone" TEXT,
    "plan" TEXT NOT NULL DEFAULT 'TRIAL',
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "createdByAdminId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Tenant_createdByAdminId_fkey" FOREIGN KEY ("createdByAdminId") REFERENCES "PlatformAdmin" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

INSERT INTO "new_Tenant" ("id", "name", "address", "trn", "contactEmail", "contactPhone", "plan", "status", "createdAt", "updatedAt")
SELECT "id", "name", "address", "trn", "contactEmail", "contactPhone", "plan", "status", "createdAt", "updatedAt" FROM "Tenant";

DROP TABLE "Tenant";
ALTER TABLE "new_Tenant" RENAME TO "Tenant";

-- CreateIndex
CREATE INDEX "Tenant_status_idx" ON "Tenant"("status");

-- CreateIndex
CREATE INDEX "Tenant_createdAt_idx" ON "Tenant"("createdAt");

-- CreateIndex
CREATE INDEX "Tenant_createdByAdminId_idx" ON "Tenant"("createdByAdminId");

PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- ============================================================================
-- AuditLog: add platformAdminId (new, nullable FK). Simple ADD COLUMN
-- suffices - no existing column's default or type is changing, so SQLite's
-- native ADD COLUMN (which does permit a REFERENCES clause) is sufficient;
-- no table rebuild needed here.
-- ============================================================================

-- AlterTable
ALTER TABLE "AuditLog" ADD COLUMN "platformAdminId" TEXT REFERENCES "PlatformAdmin" ("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- CreateIndex
CREATE INDEX "AuditLog_platformAdminId_idx" ON "AuditLog"("platformAdminId");

-- ============================================================================
-- Invitation: new table. Physical name "invitations" and snake_case columns
-- per its @@map/@map directives (Phase 2) - the one table in this schema
-- using that convention; see Phase 2 §2 for why the others don't.
-- ============================================================================

-- CreateTable
CREATE TABLE "invitations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "tenant_id" TEXT NOT NULL,
    "invitee_name" TEXT NOT NULL,
    "invitee_email" TEXT NOT NULL,
    "token_hash" TEXT NOT NULL,
    "expires_at" DATETIME NOT NULL,
    "accepted_at" DATETIME,
    "invalidated_at" DATETIME,
    "invited_by_admin_id" TEXT,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "invitations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "invitations_invited_by_admin_id_fkey" FOREIGN KEY ("invited_by_admin_id") REFERENCES "PlatformAdmin" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "invitations_token_hash_key" ON "invitations"("token_hash");

-- CreateIndex
CREATE INDEX "invitations_tenant_id_idx" ON "invitations"("tenant_id");

-- CreateIndex
CREATE INDEX "invitations_invited_by_admin_id_idx" ON "invitations"("invited_by_admin_id");

-- CreateIndex
CREATE INDEX "invitations_tenant_id_invalidated_at_accepted_at_idx" ON "invitations"("tenant_id", "invalidated_at", "accepted_at");
```

**No enum/value migration needed beyond the default change above**: `status`'s expanded value set (`DRAFT`/`INVITED`/`ACTIVE`/`SUSPENDED`/`ARCHIVED`) requires no schema change at all — it was already a plain `String` column ([ADR §4]'s SQLite-compatible pattern), enforced at the application layer, not a database-level enum. Only the *default* changed, which is what the rebuild above handles.

---

## 2. Migration Review

| Check | Finding |
|---|---|
| **Existing data preserved** | ✅ Every existing `Tenant`, `User`, `PlatformAdmin`, `AuditLog` row survives unchanged. The `Tenant` rebuild copies all columns' actual values via `INSERT ... SELECT` — an existing Tenant currently `ACTIVE` remains `ACTIVE` after this migration, not silently reset to `DRAFT`. New nullable columns (`createdByAdminId`, `platformAdminId`) correctly populate as `NULL` for pre-existing rows, since that attribution genuinely wasn't tracked before now — `NULL` here is accurate, not a data gap. |
| **No destructive schema changes** | ✅ No `DROP COLUMN`, no lossy type conversion, no row deletion. The `Tenant` rebuild *looks* drastic (drop + recreate) but is copy-then-swap, executed atomically — functionally additive from a data standpoint even though mechanically it's SQLite's only path to a default-value change. |
| **Foreign key integrity** | ✅ Every new FK references an existing, correct primary key (`PlatformAdmin.id`, `Tenant.id`) with cascade behavior matching [Phase 2](05-tenant-management-prisma-schema.md) exactly: `RESTRICT` for `invitations.tenant_id`, `SET NULL` for every `→ PlatformAdmin` reference. |
| **Rollback considerations** | Per [DDS §17], forward-fixing is preferred over reversing an applied migration once real data exists against the new shape. Today's `dev.db` holds only local test data, so a manual rollback (recreate the pre-migration `Tenant`/`AuditLog` shape, `DROP TABLE "invitations"`) is *low-risk* if needed pre-Phase-4 — but the standing recommendation, once this reaches any shared environment, is a new corrective migration, never a reverse-applied one. Prisma does not auto-generate a "down" migration; none is included here, consistent with that policy. |
| **SQLite compatibility (current)** | ✅ Every statement above is valid SQLite: `PRAGMA` foreign-key handling around the rebuild, `ADD COLUMN ... REFERENCES` for the simple case, standard `CREATE INDEX`. This is what `prisma migrate dev` would generate and apply against the current `file:./dev.db`. |
| **PostgreSQL compatibility (future)** | This exact SQL is **SQLite-specific and will not be reused**. When [ADR §12]/[PAS §25 Decision 2] eventually resolves and the datasource switches to `postgresql`, Prisma independently regenerates a fresh, Postgres-native migration from the *same* `schema.prisma` — likely simple `ALTER TABLE ... ADD COLUMN` and `ALTER TABLE ... ALTER COLUMN ... SET DEFAULT` statements, since Postgres supports both directly without SQLite's rebuild workaround. The logical schema (tables, columns, relationships, constraints) is identical either way — only the generated SQL mechanics differ per provider, which is Prisma's job to handle, not something to hand-translate now. |

**One item intentionally not included, restated from Phase 2**: the true partial index (`WHERE invalidated_at IS NULL AND accepted_at IS NULL`) that would most precisely serve the "current live invitation" lookup is **not** hand-added to this migration. Phase 2's approved `schema.prisma` only declares the plain composite index (`tenant_id, invalidated_at, accepted_at`), since Prisma's schema DSL can't express the partial predicate — this migration faithfully generates what was approved, not more. Adding the partial index now would be introducing a schema element beyond what Phase 2 approved, which this phase's instructions explicitly rule out. It remains available as a focused, separate future migration if query patterns ever justify it.

---

## 3. Deployment Notes

**Migration order**: this is the second migration in the project's history, applied after the existing `20260728111800_npm_run_seed` migration (already applied). Prisma tracks applied migrations in its own `_prisma_migrations` table, so both `prisma migrate dev` and `prisma migrate deploy` apply only what's new, in the correct order, automatically — no manual sequencing needed.

**Commands to execute**:

```bash
npx prisma migrate dev --name tenant_management
```

For the local/shared dev environment — generates the migration folder (if not already committed) and applies it to `dev.db` in one step, then regenerates the Prisma Client.

```bash
npx prisma migrate deploy
npx prisma generate
```

The production-safe pair, once a real deployment target exists ([ADR §12], still open) — `migrate deploy` applies pending migrations non-interactively (never `migrate dev` in a production context); `prisma generate` is called out separately because, unlike `migrate dev`, `migrate deploy` does **not** automatically regenerate the client — an easy step to forget.

**Manual steps required**: none for the schema/data itself — every change is additive and nullable-safe, with no backfill needed.

**The one real risk worth stating plainly**: this migration must **not** be deployed ahead of the corresponding service-layer changes (Phase 4, not yet built). Today's live `createTenant` code creates a Tenant *and* its Owner `User` together, with no concept of `DRAFT`/`INVITED`. If this migration ships alone, that unchanged code would keep running against a `status` column now defaulting to `DRAFT` instead of `ACTIVE` — meaning newly created Tenants would silently land in `DRAFT` with no invitation ever sent and no Owner able to log in, since the old code path knows nothing about the new `Invitation` flow. **This migration and Phase 4's service/controller updates must ship together, in the same release, not staged apart.**

**Other deployment risks**: minimal at this stage — there is currently no shared or production environment ([ADR §12] unresolved), so this migration's near-term blast radius is limited to local/shared dev SQLite databases holding only test data. The SQLite table-rebuild step is transactional (Prisma wraps SQLite migrations in a transaction), so it is atomic — it either fully applies or fully rolls back, with no risk of a half-migrated `Tenant` table being visible mid-operation.

---

**STOP — awaiting approval before Phase 4. Not yet applied to the database or committed to `prisma/migrations/`.**
