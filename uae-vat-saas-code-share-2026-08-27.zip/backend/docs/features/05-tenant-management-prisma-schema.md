# Tenant Management — Implementation Phase 2: Prisma Schema

- **Status:** Proposed — **not yet applied to `prisma/schema.prisma`**; awaiting approval before Phase 3 (migrations)
- **Date:** 2026-07-30
- **Implements:** [Phase 1: Domain & Database Design](04-tenant-management-domain-design.md) (Approved) — exactly, no new design decisions introduced here that Phase 1 didn't already make.
- **Scope of this phase:** Prisma schema only. No SQL, no migration files, no API, no backend/frontend code.

---

## 1. Complete Prisma Schema

The five models Phase 1 covers. `datasource`/`generator` are shown for context (unchanged from the current file). `Customer`, `Material`, `VatRateHistory`, `Invoice`, `Purchase` are **not reproduced — they are untouched by this feature** and remain exactly as they exist in `prisma/schema.prisma` today.

```prisma
datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

// ---------------------------------------------------------------------------
// Platform Admin - me. Separate identity space from Tenant users on purpose:
// a platform-admin JWT must never be usable as a tenant-user JWT.
// ---------------------------------------------------------------------------
model PlatformAdmin {
  id           String   @id @default(uuid())
  email        String   @unique
  passwordHash String
  createdAt    DateTime @default(now())

  // Attribution back-relations - new for Sprint 1's Tenant Management.
  // Nullable on the owning side (Tenant.createdByAdminId, etc.), paired with
  // onDelete: SetNull there, so removing an admin account later (Future:
  // multi-admin / "Support" role) never blocks on or cascades into Tenant
  // history - see Phase 1 Review.
  createdTenants  Tenant[]
  sentInvitations Invitation[]
  auditLogs       AuditLog[]
}

// ---------------------------------------------------------------------------
// Tenant - a paying business. Every other business record hangs off tenantId.
//
// status: DRAFT | INVITED | ACTIVE | SUSPENDED | ARCHIVED
//   Evolved for Sprint 1 (previously just ACTIVE | SUSPENDED). A Tenant now
//   starts DRAFT - created by Platform Admin, no Owner credential exists yet
//   - and only reaches ACTIVE once its invited Owner accepts and sets their
//   own password (see Invitation below). Transition legality is enforced in
//   the service layer, not here - see the Tenant Management feature spec and
//   its Phase 1 design, not re-derived in this file.
//
// address/trn/contactEmail/contactPhone are untouched by this phase - they
// are superseded by the not-yet-implemented Business Profile feature and are
// deliberately left alone here, per Phase 1 §4's scope boundary.
// ---------------------------------------------------------------------------
model Tenant {
  id           String       @id @default(uuid())
  name         String
  address      String?
  trn          String?
  contactEmail String?
  contactPhone String?

  plan   String @default("TRIAL")  // TRIAL | STANDARD | PREMIUM
  status String @default("DRAFT")  // DRAFT | INVITED | ACTIVE | SUSPENDED | ARCHIVED

  createdByAdminId String?
  createdByAdmin   PlatformAdmin? @relation(fields: [createdByAdminId], references: [id], onDelete: SetNull)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  users          User[]
  invitations    Invitation[]
  customers      Customer[]
  materials      Material[]
  invoices       Invoice[]
  purchases      Purchase[]
  auditLogs      AuditLog[]
  vatRateHistory VatRateHistory[]

  @@index([status])
  @@index([createdAt])
  @@index([createdByAdminId])
}

// ---------------------------------------------------------------------------
// Invitation - one row per invite/resend attempt for a Tenant's Owner. New
// for Sprint 1, replacing the old "Platform Admin types the Owner's password
// directly" flow. A Resend never overwrites an existing row - it creates a
// new one and sets invalidatedAt on the prior row, preserving full attempt
// history (consistent with this platform's "corrections are new records"
// instinct elsewhere, e.g. Credit Notes).
//
// "Live" invitation = invalidatedAt IS NULL AND acceptedAt IS NULL AND
// expiresAt > now(). tokenHash stores a HASH, never the raw token - the raw
// token exists only in the emailed link and the verification request (Phase
// 1 Review §5's security finding).
//
// This is a brand-new table, so it is the one place in this schema that
// applies the DDS's snake_case @@map/@map standard cleanly (§2 explains why
// the other four models in this file deliberately do not).
// ---------------------------------------------------------------------------
model Invitation {
  id       String @id @default(uuid())
  tenantId String @map("tenant_id")
  tenant   Tenant @relation(fields: [tenantId], references: [id], onDelete: Restrict)

  inviteeName  String @map("invitee_name")
  inviteeEmail String @map("invitee_email")

  tokenHash String   @unique @map("token_hash")
  expiresAt DateTime @map("expires_at")

  acceptedAt    DateTime? @map("accepted_at")
  invalidatedAt DateTime? @map("invalidated_at")

  invitedByAdminId String?        @map("invited_by_admin_id")
  invitedByAdmin   PlatformAdmin? @relation(fields: [invitedByAdminId], references: [id], onDelete: SetNull)

  createdAt DateTime @default(now()) @map("created_at")

  @@index([tenantId])
  @@index([invitedByAdminId])
  // Approximates the "current live invitation for this tenant" lookup. The
  // real target is a PARTIAL index (WHERE invalidatedAt IS NULL AND
  // acceptedAt IS NULL) - Prisma's schema DSL cannot express that predicate
  // (DDS §2's documented Prisma/Postgres gap). This composite index is the
  // best Prisma-native approximation; the true partial index needs a
  // hand-authored SQL addition to the migration in Phase 3 - not decided or
  // written here.
  @@index([tenantId, invalidatedAt, acceptedAt])
  @@map("invitations")
}

// ---------------------------------------------------------------------------
// User - a Tenant Owner or Tenant Staff member. Unchanged in shape for
// Sprint 1 - only *when* an Owner's User row is created changes (now: at
// Invitation acceptance, not at Tenant creation), which is service-layer
// behavior, not a schema change.
// ---------------------------------------------------------------------------
model User {
  id           String    @id @default(uuid())
  tenantId     String
  tenant       Tenant    @relation(fields: [tenantId], references: [id])
  name         String
  email        String    @unique
  passwordHash String
  role         String    // OWNER | STAFF
  lastLoginAt  DateTime?
  createdAt    DateTime  @default(now())
}

// ---------------------------------------------------------------------------
// AuditLog - append-only. userId records a Tenant-side actor (existing,
// unchanged - not a formal relation today; a pre-existing Module 0 gap
// outside this phase's approved scope, see §2 below).
// platformAdminId is new for Sprint 1: every Tenant Management action is
// performed by a Platform Admin, not a Tenant User, and this table had no
// way to attribute that until now.
// ---------------------------------------------------------------------------
model AuditLog {
  id         String   @id @default(uuid())
  tenantId   String
  tenant     Tenant   @relation(fields: [tenantId], references: [id])
  userId     String?
  action     String
  recordType String
  createdAt  DateTime @default(now())

  platformAdminId String?
  platformAdmin   PlatformAdmin? @relation(fields: [platformAdminId], references: [id], onDelete: SetNull)

  @@index([platformAdminId])
}
```

---

## 2. Prisma Model Review

### Relations

All five new/extended relations are bidirectional and unambiguous (each model pair has exactly one relation between them, so Prisma needs no explicit `@relation("Name")` disambiguation): `PlatformAdmin ↔ Tenant`, `PlatformAdmin ↔ Invitation`, `PlatformAdmin ↔ AuditLog`, `Tenant ↔ Invitation`. `Tenant ↔ User` is the pre-existing relation, untouched.

**One relation Phase 1's ER diagram implied but its table design did not specify, and this schema does not add**: a direct FK from `Invitation` to the `User` it eventually becomes (the diagram's "accepted into" arrow). Phase 1's actual `Invitation` table definition never included this column. Adding it now would be a schema decision Phase 1 didn't make — flagged here as an open question for the project owner, not added unilaterally. Today, that link is derivable (matching `tenantId` + email) but not stored explicitly; if Tenant Details needs to show "became Owner account X" directly, this is the field that would provide it.

### Cascade Behavior

| Relation | `onDelete` | Verified against Phase 1 |
|---|---|---|
| `Invitation.tenantId` → `Tenant.id` | `Restrict` | ✅ Matches |
| `Tenant.createdByAdminId` → `PlatformAdmin.id` | `SetNull` | ✅ Matches |
| `Invitation.invitedByAdminId` → `PlatformAdmin.id` | `SetNull` | ✅ Matches |
| `AuditLog.platformAdminId` → `PlatformAdmin.id` | `SetNull` | ✅ Matches |

**Pre-existing relations** (`User.tenant`, `Customer.tenant`, etc.) have no explicit `onDelete` in the current schema and are untouched here — they rely on Prisma/the database's implicit default. Noted, not fixed — out of this phase's approved scope.

### Nullable Fields

Every new FK (`createdByAdminId`, `invitedByAdminId`, `platformAdminId`) is nullable **specifically because** it pairs with `onDelete: SetNull` — nullability here is a direct, deliberate consequence of the chosen cascade behavior, not an oversight. `acceptedAt`/`invalidatedAt` are nullable by definition (each occurs 0 or 1 times per row).

### Index Strategy

Matches Phase 1's table exactly: `Tenant` gains `status`, `createdAt`, `createdByAdminId`; `Invitation` gets its unique `tokenHash`, plus `tenantId`, `invitedByAdminId`, and the composite approximating the live-invitation lookup; `AuditLog` gains `platformAdminId`.

**One gap found, not fixed here**: `AuditLog.tenantId` — an existing, mandatory FK column — has **no index today**, in the schema as it already exists in the repository. This is a pre-existing Module 0 gap ([DDS §21] checklist item: "every FK column has an explicit index"), not something Phase 1 or this phase was asked to correct. Since this schema is already touching `AuditLog` to add `platformAdminId`, it would be cheap to fix in the same migration — flagged here explicitly for the project owner's decision, not silently bundled in.

### Multi-Tenant Isolation

Unchanged from Phase 1's finding: `Tenant` and `Invitation` are accessed by Platform Admin via an RBAC identity check ("is this caller a Platform Admin"), not tenant-scoping — `Tenant` is the boundary other tables' `tenantId` points *to*, not itself owned by a tenant. `Invitation.tenantId` records *which* Tenant an invitation is for; it does not change who is authorized to read/write it. Once accepted, the resulting `User` row is tenant-scoped under the platform's standard model, unchanged.

### Performance

Token verification (`tokenHash`, unique index) and Tenant List filtering (`status`, indexed) are both O(log n) lookups, not scans. The live-invitation composite index is a reasonable Prisma-native approximation of the ideal partial index; at MVP invitation volumes per Tenant (realistically single digits), the difference is not performance-material — the limitation is noted for correctness/completeness ([DDS §2]), not because it's an urgent bottleneck.

### A note on the naming inconsistency this schema deliberately introduces

`Invitation` is `@@map`/`@map`'d to snake_case; `Tenant`, `User`, `PlatformAdmin`, and `AuditLog` are not, including the *new* columns added to them (`createdByAdminId`, `platformAdminId` have no `@map`). This is intentional, not inconsistent oversight: the four existing tables should stay internally consistent with their own already-shipped columns (all-unmapped) rather than becoming a patchwork of mapped-and-unmapped fields within the same table. `Invitation` has no existing convention to conflict with, so it gets the clean [DDS §6] standard applied in full. Reconciling the four existing tables to the same standard remains [DDS §22 Open Decision 3] — unresolved, not decided by this phase.

---

**STOP — awaiting approval before Phase 3 (migrations). Not yet applied to `prisma/schema.prisma`.**
