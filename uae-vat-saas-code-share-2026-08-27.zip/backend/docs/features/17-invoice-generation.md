# 17 — Invoice Generation: Domain Design & Implementation Reference

- **Status:** Design approved in conversation on 2026-08-02. This document is the first formal write-up of that approval (the Design→Approve→**Document**→Implement gate this project runs on — see process discipline note in memory). Written 2026-08-03, before any Invoice code exists.
- **Scope:** the full Invoice Generation module — the core module of Ledger.
- **Prerequisites (already built and live):** [Customer Master](../../frontend/app/tenant/customers), [Material Master](../../frontend/app/tenant/materials), [Tax Master](../../frontend/app/tenant/tax-master). Built in that order specifically to be ready for this module.
- **Not started yet:** every line of Invoice-specific code. `Invoice` currently exists in `schema.prisma` only as a Module-0-era stub (see [§2](#2-conflict-found-material--tax-master-are-not-actually-linked) and [§3](#3-schema-changes)).

---

## 1. Integration Points

| Upstream module | What Invoice consumes | How |
|---|---|---|
| **Customer Master** | `Customer.name/address/trn` | A selector autofills these onto the invoice at creation time. Convenience only — never a live read after that point ([§4](#4-snapshotimmutability-principle)). Manual entry (no `Customer` selected) is also supported. |
| **Material Master** | `Material.name/unit/defaultUnitPrice/defaultVatCategory` | A selector autofills each line item's description/unit/price/VAT category. Same snapshot rule. Manual line entry (no `Material` selected) is also supported. |
| **Tax Master** | `resolveTax(tenantId, taxCategoryId, asOfDate)` | Called once per line item at the moment it's priced (added to a Draft, or edited), to fetch the percentage + calculation method that apply *today*. The result is copied onto the line item, never re-resolved later ([§4](#4-snapshotimmutability-principle)). |
| **Business Profile** | *(none yet)* | Invoice prefix configurability and default payment terms are explicitly deferred past Sprint 1, per the approved design. No touch to Business Profile in this module. |
| **Platform Admin** | *(consumer, not a dependency)* | `platformAdmin.controller.js` does `prisma.invoice.count()` / `_count.invoices` for the Tenant list and usage view ([platformAdmin.controller.js:32](../../../uae-vat-saas-module/uae-vat-saas/src/controllers/platformAdmin.controller.js), [:222](../../../uae-vat-saas-module/uae-vat-saas/src/controllers/platformAdmin.controller.js)). Verified: every schema change below keeps the `Invoice` model name and its `tenantId`/`tenant` relation intact, so this count keeps working unmodified. |

---

## 2. Conflict Found: Material ↔ Tax Master Are Not Actually Linked

This is the one real conflict surfaced while checking the approved design against current code, and it blocks line-item VAT calculation as designed. Flagging before any implementation, per instruction.

**The gap:** `Material.defaultVatCategory` is a plain hardcoded string (`STANDARD_RATED | ZERO_RATED | EXEMPT | OUT_OF_SCOPE` — [schema.prisma:115](../../../uae-vat-saas-module/uae-vat-saas/prisma/schema.prisma)), mirrored in `frontend/lib/vatCategories.js`. It was written before Tax Master existed, when "categories are hardcoded now" was the deliberate placeholder ([memory: ledger-invoice-generation]).

Tax Master shipped afterward with **real, user-creatable `TaxCategory` rows** — seeded with four defaults but extendable per tenant, each with its own `id`. `resolveTax(tenantId, categoryId, asOfDate)` ([taxResolver.js](../../../uae-vat-saas-module/uae-vat-saas/src/services/taxResolver.js)) requires a real `TaxCategory.id`, not one of the four hardcoded strings.

**Net effect:** a Material's stored `defaultVatCategory` string cannot be handed to `resolveTax()` today. There is no column connecting a Material to an actual `TaxCategory` row. If a tenant renames "Standard Rated" or adds a fifth category, Material has no way to reference it at all.

**Proposed fix** (small, additive — not a redesign of either completed module):

1. Add `Material.defaultTaxCategoryId` (nullable FK → `TaxCategory`) alongside the existing `defaultVatCategory` string.
2. One-time backfill: for each existing Material, match its `defaultVatCategory` string to that tenant's seeded `TaxCategory` by name (`STANDARD_RATED` → "Standard Rated", etc.) and populate the new FK.
3. Keep `defaultVatCategory` on the schema, unused going forward, rather than dropping it — cheap, avoids a destructive migration, matches this project's existing pattern of leaving superseded fields declared (see `VatRateHistory`).
4. `MaterialFormModal`'s VAT category `<select>` changes from the hardcoded `VAT_CATEGORIES` list to a live fetch of the tenant's `TaxCategory` list (already exposed via `api.listTaxCategories`).
5. Invoice line items resolve VAT via `taxCategoryId` end to end — Material default autofills it, `resolveTax()` consumes it directly, no string-matching at invoice time.

This touches Material Master, a completed module — flagged explicitly per project rule, not applied silently. **Needs your explicit approval before Sprint 1 starts**, since Sprint 1 cannot compute correct VAT without it.

---

## 3. Schema Changes

`Invoice` today is a Module-0-era stub — "minimal shape only, just enough for Module 0's invoice count view to be real" (schema.prisma's own comment). It has no line items, no snapshot fields, no numbering safeguard, no discount, no dates. This was always the plan (Material/Tax Master were built first specifically so this rebuild has real dependencies to snapshot from) — not a surprise conflict, just the expected next step. Proposed replacement:

```prisma
model Tenant {
  // ...existing fields...
  nextInvoiceNumber Int @default(1)   // NEW — per-tenant counter, incremented transactionally at Send
  invoices          Invoice[]         // existing relation, unchanged
}

model Material {
  // ...existing fields...
  defaultTaxCategoryId String?
  defaultTaxCategory   TaxCategory? @relation(fields: [defaultTaxCategoryId], references: [id])  // NEW, see §2
  invoiceLineItems     InvoiceLineItem[]                                                           // NEW, back-relation only
}

model TaxCategory {
  // ...existing fields...
  materials         Material[]         // NEW, back-relation only
  invoiceLineItems  InvoiceLineItem[]  // NEW, back-relation only
}

model Invoice {
  id       String @id @default(uuid())
  tenantId String
  tenant   Tenant @relation(fields: [tenantId], references: [id])

  customerId String?
  customer   Customer? @relation(fields: [customerId], references: [id])

  // Snapshot of the customer at creation time - copied once, never re-read.
  // Populated whether or not `customer` was selected (manual entry allowed).
  customerName    String
  customerAddress String?
  customerTrn     String?

  invoiceNumber        Int?     // assigned only at Send; null for every Draft
  invoiceNumberDisplay String?  // "INV-000001", set alongside invoiceNumber at Send

  issueDate DateTime?  // set at Send
  dueDate   DateTime?
  currency  String @default("AED")

  status        String @default("DRAFT")   // DRAFT | SENT | VOID  - document lifecycle
  paymentStatus String @default("UNPAID")  // UNPAID | PARTIALLY_PAID | PAID - independent axis
  // isOverdue is NOT a column - computed at read time: SENT && paymentStatus != PAID && dueDate < now

  discountType  String? // PERCENTAGE | FIXED - header-level only in Sprint 1
  discountValue Float?  @default(0)

  subtotal      Float @default(0)  // sum of line net amounts, before discount/VAT
  discountTotal Float @default(0)
  vatTotal      Float @default(0)
  grandTotal    Float @default(0)

  notes String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  lineItems InvoiceLineItem[]

  @@unique([tenantId, invoiceNumber])
}

model InvoiceLineItem {
  id        String  @id @default(uuid())
  invoiceId String
  invoice   Invoice @relation(fields: [invoiceId], references: [id], onDelete: Cascade)

  materialId String?
  material   Material? @relation(fields: [materialId], references: [id])

  // Snapshot, copied from Material (or typed manually) when the line is
  // added - never re-read from Material after.
  description String
  unit        String
  quantity    Float
  unitPrice   Float

  taxCategoryId        String?
  taxCategory          TaxCategory? @relation(fields: [taxCategoryId], references: [id])
  taxRateId            String?  // snapshot: which TaxRate row resolveTax() returned
  taxRateName          String?
  taxPercentage        Float  @default(0)
  taxCalculationMethod String @default("EXCLUSIVE")

  lineNetAmount     Float  // quantity * unitPrice, before header discount
  lineDiscountShare Float  @default(0)  // this line's pro-rata share of the header discount
  lineTaxableAmount Float  // lineNetAmount - lineDiscountShare
  lineTaxAmount     Float
  lineTotal         Float

  sortOrder Int @default(0)
  createdAt DateTime @default(now())
}
```

**Why `nextInvoiceNumber` on `Tenant` instead of `count()`-based numbering**: a count can produce collisions/gaps under concurrent Sends or after a Draft is deleted mid-count. A dedicated counter, incremented inside the same transaction that assigns `invoiceNumber`, is the standard safe pattern and matches [database-design-specification.md §"Natural Keys"](../database-design-specification.md)'s existing rule that invoice-number uniqueness is `unique(tenant, number)`.

**Why `invoiceNumber`/`issueDate` are nullable**: Draft invoices have neither — assigned only at Send, per approved decision 2 (avoids gaps from abandoned drafts, FTA-relevant).

**Deletion policy** (matches [database-design-specification.md §"Hard delete policy"](../database-design-specification.md), not a new rule invented here): Draft invoices (never Sent, no `invoiceNumber` consumed) may be hard-deleted. Once `status` leaves `DRAFT`, the invoice is never deleted, soft or hard — `VOID` is the only way to invalidate a Sent invoice.

**Deferred, not modeled now** (kept out of Sprint 1 schema on purpose, matching the approved design's scope cuts):
- Per-line discounts (header-level only, decision 3).
- Credit Notes — future `CreditNote` model with its own FK to `Invoice`, **a relation, not an `Invoice.status` value** (approved decision), so no `CREDITED` status should ever be added to the `status` enum-string above.
- Invoice number prefix configuration (hardcoded `INV-` for now).

---

## 4. Snapshot/Immutability Principle

The load-bearing rule for the whole module, per the approved design: **once an invoice exists, changes to Customer, Material, or Tax Master must never retroactively change it.** Every selector above is a one-time copy, never a live join used for rendering or recalculation:

- Customer selector → copies `name`/`address`/`trn` onto `Invoice.customerName/customerAddress/customerTrn`.
- Material selector → copies `name`/`unit`/`defaultUnitPrice`/`defaultTaxCategoryId` onto the line item's own fields.
- Tax resolution → `resolveTax()` is called once when a line is priced; the returned percentage/method/rate identity are copied onto `InvoiceLineItem.taxPercentage/taxCalculationMethod/taxRateId/taxRateName`.

The `customerId`/`materialId`/`taxCategoryId` foreign keys are kept **only** as "jump to source record" links for the UI (e.g., "View Customer" from an invoice) — never dereferenced to recompute a total. This is why every snapshot field above is a plain column, not something derived through the relation at read time.

While an invoice is still `DRAFT`, re-opening the Material/Customer selector is allowed to re-copy fresh values (the invoice hasn't been issued yet). The immutability guarantee begins at Send.

---

## 5. Invoice Lifecycle & Status Model

Three independent axes, not one giant enum (approved decision):

| Axis | Values | Meaning |
|---|---|---|
| `status` | `DRAFT` → `SENT` → (optionally) `VOID` | Document/legal lifecycle. Freely editable while `DRAFT`. Locked (immutable per §4) once `SENT`, except for `paymentStatus` updates and a `VOID` transition. |
| `paymentStatus` | `UNPAID` → `PARTIALLY_PAID` → `PAID` | Independent of `status`; only meaningful once `SENT`. Updated by future payment-recording actions (Sprint 2+; Sprint 1 may allow a manual mark-as-paid). |
| `isOverdue` | *(computed, not stored)* | `status === "SENT" && paymentStatus !== "PAID" && dueDate < now`. Never persisted — always derived at read time so it's automatically correct without a background job. |

**Why this shape**: a single enum trying to express "sent AND overdue AND partially paid" collapses into an unmanageable value explosion; three orthogonal fields compose cleanly and each is independently queryable/filterable in list views.

---

## 6. Numbering

- Format: `INV-000001` (6-digit zero-padded sequence), prefix hardcoded to `INV-` for Sprint 1 (configurable prefix explicitly deferred).
- Assigned **only at Send**, inside a transaction: read `Tenant.nextInvoiceNumber`, write it onto the invoice as both `invoiceNumber` (int, for the `@@unique` constraint) and `invoiceNumberDisplay` (formatted string), increment `Tenant.nextInvoiceNumber`, all in one `prisma.$transaction`.
- Draft invoices never consume a number, so an abandoned/deleted Draft leaves no gap — matches FTA sequential-numbering expectations from [KB §8.1].

---

## 7. Calculation Engine

Per-line, discount applied pro-rata **before** VAT, so mixed-VAT-category invoices (e.g., one Standard Rated line + one Zero Rated line) compute correctly:

1. For each line: `lineNetAmount = quantity × unitPrice`.
2. `subtotal = Σ lineNetAmount` across all lines.
3. Header discount total: `discountTotal = discountType === "PERCENTAGE" ? subtotal × discountValue / 100 : discountValue`.
4. Each line's pro-rata share: `lineDiscountShare = lineNetAmount / subtotal × discountTotal` (guard `subtotal === 0` → all shares `0`).
5. `lineTaxableAmount = lineNetAmount - lineDiscountShare`.
6. `lineTaxAmount = lineTaxableAmount × taxPercentage / 100` for `EXCLUSIVE`; for `INCLUSIVE`, back out the tax already embedded: `lineTaxAmount = lineTaxableAmount - (lineTaxableAmount / (1 + taxPercentage / 100))`.
7. `lineTotal = lineTaxableAmount + lineTaxAmount` (EXCLUSIVE) or `lineTaxableAmount` (INCLUSIVE, tax already inside).
8. `vatTotal = Σ lineTaxAmount`, `grandTotal = subtotal - discountTotal + vatTotal` (EXCLUSIVE) — for an all-INCLUSIVE invoice, `grandTotal = subtotal - discountTotal`.

Recomputed live on every line/discount edit while `DRAFT` (backend is the source of truth — recalculated server-side on every save, not trusted from the client). Frozen the moment `status` becomes `SENT`.

---

## 8. API Endpoints (proposed)

Mounted under `/api/tenant/invoices`, `requireTenantUser`-scoped by `req.tenantId`, mirroring `customer.controller.js`/`material.controller.js`/`tax.controller.js` exactly (same auth middleware, same `ApiError` pattern, same tenant-scoped `findFirst` guard on every read/write by id).

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/tenant/invoices` | List, tenant-scoped |
| POST | `/api/tenant/invoices` | Create Draft (no number assigned) |
| GET | `/api/tenant/invoices/:id` | Get one, with line items |
| PATCH | `/api/tenant/invoices/:id` | Update Draft (header fields, discount) — 409 if not `DRAFT` |
| POST | `/api/tenant/invoices/:id/line-items` | Add a line item to a Draft |
| PATCH | `/api/tenant/invoices/:id/line-items/:lineId` | Edit a Draft line item |
| DELETE | `/api/tenant/invoices/:id/line-items/:lineId` | Remove a Draft line item |
| DELETE | `/api/tenant/invoices/:id` | Hard-delete — only while `DRAFT` |
| POST | `/api/tenant/invoices/:id/send` | Assigns number (transaction, §6), sets `issueDate`, flips `status` → `SENT`, freezes totals |
| PATCH | `/api/tenant/invoices/:id/payment-status` | Update `paymentStatus` (Sprint 1: manual; Sprint 2+: real payment recording) |
| POST | `/api/tenant/invoices/:id/void` | `status` → `VOID`, only from `SENT` |

Every mutating endpoint recalculates totals server-side per §7 before persisting — never trusts client-submitted totals.

---

## 9. Frontend

**Reused as-is** (no new shared components needed for these): `AppShell`/`Sidebar` (nav already has an "Invoices" entry — [tenant/layout.js:80](../../frontend/app/tenant/layout.js)), `PageHeader`, `DataTable` + `ColumnSelector` + `Toolbar` (list page, same pattern as [Customers list](../../frontend/app/tenant/customers/page.js)), `EmptyState`, `ErrorBanner`, `LoadingSkeleton`, `Toast`/`ToastProvider`, `Button`, `Field`/`Input`/`Select`, `ConfirmationDialog` (Void/Delete confirmations), `Tooltip`, `useLocalStorageState`/`useToast` hooks. `frontend/lib/vatCategories.js` is superseded by a live `TaxCategory` fetch per §2 but the file can stay for now (unused, same "leave declared" pattern as `VatRateHistory`).

**New, module-specific:**
- `app/tenant/invoices/page.js` — List (KPI row: Total/Draft/Sent/Overdue/Paid counts, same `kpi-card-grid` pattern as Customers).
- `app/tenant/invoices/new/page.js` and `app/tenant/invoices/[id]/page.js` — **full page**, not a modal (approved decision 1 — a deliberate departure from the Customer/Onboarding modal-wizard pattern, room for a line-item table + sticky totals sidebar).
- `components/invoices/LineItemsTable.js` — add/edit/remove rows, Material selector per row (autofill + manual override).
- `components/invoices/MaterialSelector.js` — searchable picker sourced from `api.listMaterials`, reusable across rows.
- `components/invoices/InvoiceSummarySidebar.js` — sticky subtotal/discount/VAT/grand-total display, live-recalculated via the same §7 logic mirrored client-side for instant feedback (server recalculation on save remains authoritative).
- `components/invoices/InvoiceStatusBadge.js` — renders the 3-axis state (§5) as one readable badge/cluster.
- New `api.js` functions: `listInvoices`, `createInvoice`, `getInvoice`, `updateInvoice`, `addLineItem`, `updateLineItem`, `deleteLineItem`, `deleteInvoice`, `sendInvoice`, `updateInvoicePaymentStatus`, `voidInvoice` — same `request()` wrapper, same token-passing convention as every existing `api.js` entry.

**Known follow-up, out of scope here**: Tenant Dashboard's `KpiCards.js` still shows "Invoices — Coming Soon" (pre-dates this module, same situation Customer Master left behind — see [ledger-customer-master] memory). Worth wiring once Invoice ships, not part of this document's scope.

---

## 10. Proposed Sprint Breakdown

| Sprint | Scope |
|---|---|
| **Sprint 1** | §2 fix (Material↔TaxCategory link) + full schema (§3) + backend Draft CRUD + line items + calculation engine (§7, live while Draft) + List page + full-page Create/Edit. No Send yet — invoices stay `DRAFT` only. |
| **Sprint 2** | Send action (§6 numbering, freeze), Void, manual payment-status update, `isOverdue` surfaced in list/filters, Dashboard KPI wiring. |
| **Sprint 3+** | PDF generation/download, Credit Notes (as a relation, §3), email delivery, configurable numbering prefix, per-line discounts (if ever revisited). |

This is a proposal, not a locked decision — adjust freely.

---

## Open Question For You

The only item that needs a decision before Sprint 1 can start: **approve the §2 fix to Material Master** (adding `defaultTaxCategoryId`, backfilling from the four seeded categories, swapping the form's hardcoded dropdown for a live one). Everything else in this document is a direct write-up of what was already approved on 2026-08-02 — flagging it for confirmation, not re-litigating it.
