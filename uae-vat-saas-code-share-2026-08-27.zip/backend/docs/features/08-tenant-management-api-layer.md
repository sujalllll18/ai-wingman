# Tenant Management — Implementation Phase 5: API Layer

- **Status:** Proposed — **not yet applied to `uae-vat-saas/src/`**; awaiting approval
- **Date:** 2026-07-30
- **Implements:** [Phase 4 Service Layer](07-tenant-management-service-layer.md) (Approved), exposed over HTTP per [HLD §4]'s Controller/Guard/Pipe mapping.
- **Two findings, addressed before the code, not silently**: (1) a small, purely-additive **Service Layer addendum** (`listTenants`, `getTenantById` — zero business logic, required so Controllers never bypass Service to reach the Repository directly, per [HLD §21]); (2) this phase **replaces specific existing routes/controller functions** in Module 0's already-shipped `platformAdmin.routes.js`/`platformAdmin.controller.js`, rather than adding parallel ones — see the note above this document for why, and exactly what's replaced vs. left untouched.
- **No new dependency introduced**: validation middleware is written by hand (matching Module 0's existing zero-dependency style), not via a new library — [HLD §10] names Zod as a reasonable future direction, but adopting it wasn't necessary here and would be an unflagged dependency addition during an API-layer-only phase.

---

## 0. Service Layer Addendum (flagged, not part of the frozen Phase 4 approval)

Append to `services/tenant.service.js` — pure reads, no validation, no state change, no transaction:

```js
// --- Addendum to Phase 4 ---------------------------------------------------
// Phase 4 approved Create/Suspend/Activate/Archive only. List/Get Tenant
// Details are pure reads with no business logic, but per HLD §21 a
// Controller must still go through a Service, never a Repository directly -
// these two minimal functions close that gap without touching anything
// Phase 4 already approved.
async function listTenants() {
  return prisma.tenant.findMany({ orderBy: { createdAt: "desc" } });
}

async function getTenantById(id) {
  return tenantRepository.findById(id);
}

module.exports = { createTenant, suspendTenant, activateTenant, archiveTenant, listTenants, getTenantById };
```

---

## 1. Controllers

### `controllers/tenant.controller.js`

```js
const tenantService = require("../services/tenant.service");
const ApiError = require("../utils/ApiError");

// POST /api/platform-admin/tenants
async function create(req, res) {
  const { name, plan } = req.body;
  const { tenant, warnings } = await tenantService.createTenant(
    { name, plan },
    { adminId: req.platformAdmin.id }
  );
  res.status(201).json({ tenant, warnings });
}

// GET /api/platform-admin/tenants
async function list(req, res) {
  const tenants = await tenantService.listTenants();
  res.json({ tenants });
}

// GET /api/platform-admin/tenants/:id
async function getDetails(req, res) {
  const tenant = await tenantService.getTenantById(req.params.id);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  res.json({ tenant });
}

// PATCH /api/platform-admin/tenants/:id/suspend
async function suspend(req, res) {
  const tenant = await tenantService.suspendTenant(req.params.id, { adminId: req.platformAdmin.id });
  res.json({ tenant });
}

// PATCH /api/platform-admin/tenants/:id/activate
async function activate(req, res) {
  const tenant = await tenantService.activateTenant(req.params.id, { adminId: req.platformAdmin.id });
  res.json({ tenant });
}

// PATCH /api/platform-admin/tenants/:id/archive
async function archive(req, res) {
  const tenant = await tenantService.archiveTenant(req.params.id, { adminId: req.platformAdmin.id });
  res.json({ tenant });
}

module.exports = { create, list, getDetails, suspend, activate, archive };
```

*(Every response returns the raw `Tenant` row as-is — verified safe: `Tenant` carries no secret fields, unlike `User`/`Invitation` below. See [§4].)*

### `controllers/invitation.controller.js`

```js
const invitationService = require("../services/invitation.service");

// POST /api/platform-admin/tenants/:id/invite
async function inviteOwner(req, res) {
  const { ownerName, ownerEmail } = req.body;
  const invitation = await invitationService.inviteOwner(
    req.params.id,
    { ownerName, ownerEmail },
    { adminId: req.platformAdmin.id }
  );
  res.status(201).json({
    invitation: { id: invitation.id, inviteeEmail: invitation.inviteeEmail, expiresAt: invitation.expiresAt },
  });
}

// POST /api/platform-admin/tenants/:id/resend-invitation
async function resendInvitation(req, res) {
  const invitation = await invitationService.resendInvitation(req.params.id, { adminId: req.platformAdmin.id });
  res.status(201).json({
    invitation: { id: invitation.id, inviteeEmail: invitation.inviteeEmail, expiresAt: invitation.expiresAt },
  });
}

// POST /api/invitations/accept  (public, unauthenticated - token is the credential)
async function acceptInvitation(req, res) {
  const { token, password } = req.body;
  const { user, tenant } = await invitationService.acceptInvitation(token, { password });
  res.status(200).json({
    message: "Password set. You can now sign in.",
    tenant: { id: tenant.id, name: tenant.name },
    user: { id: user.id, name: user.name, email: user.email },
  });
}

module.exports = { inviteOwner, resendInvitation, acceptInvitation };
```

*(Both Invitation responses explicitly pick fields — never `tokenHash`. The accept response explicitly picks `User` fields — never `passwordHash`. Neither returns the raw Prisma row.)*

---

## 2. Request Validation

Pipe-equivalent middleware ([HLD §4]), run before the Controller — parses/validates request **shape**, distinct from the Service layer's already-approved **business-rule** checks (some overlap between the two is expected and correct, not duplication to eliminate — [HLD §10]).

### `middleware/validation/tenant.validation.js`

```js
const ApiError = require("../../utils/ApiError");

function validateCreateTenant(req, res, next) {
  const { name, plan } = req.body;
  const errors = [];
  if (!name || typeof name !== "string" || name.trim().length < 1 || name.length > 200) {
    errors.push("name is required and must be 1-200 characters");
  }
  if (!plan || typeof plan !== "string") {
    errors.push("plan is required");
  }
  if (errors.length) throw new ApiError(400, errors.join("; "));
  next();
}

function validateTenantIdParam(req, res, next) {
  const { id } = req.params;
  if (!id || typeof id !== "string") {
    throw new ApiError(400, "A valid tenant id is required");
  }
  next();
}

module.exports = { validateCreateTenant, validateTenantIdParam };
```

### `middleware/validation/invitation.validation.js`

```js
const ApiError = require("../../utils/ApiError");
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateInviteOwner(req, res, next) {
  const { ownerName, ownerEmail } = req.body;
  const errors = [];
  if (!ownerName || typeof ownerName !== "string" || ownerName.trim().length < 1 || ownerName.length > 100) {
    errors.push("ownerName is required and must be 1-100 characters");
  }
  if (!ownerEmail || typeof ownerEmail !== "string" || !EMAIL_RE.test(ownerEmail)) {
    errors.push("a valid ownerEmail is required");
  }
  if (errors.length) throw new ApiError(400, errors.join("; "));
  next();
}

function validateAcceptInvitation(req, res, next) {
  const { token, password } = req.body;
  const errors = [];
  if (!token || typeof token !== "string") errors.push("token is required");
  if (!password || typeof password !== "string" || password.length < 8) {
    errors.push("password is required and must be at least 8 characters");
  }
  if (errors.length) throw new ApiError(400, errors.join("; "));
  next();
}

module.exports = { validateInviteOwner, validateAcceptInvitation };
```

*(No `try/catch`/`next(err)` wrapping needed — `express-async-errors`, already a Module 0 dependency, routes any thrown error to the existing centralized handler, matching the existing codebase's own style exactly.)*

---

## 3. Route Registration

### `routes/platformAdmin.routes.js` — **replaces** specific bindings, leaves the rest untouched

```js
const express = require("express");
const { requirePlatformAdmin } = require("../middleware/auth");
const ctrl = require("../controllers/platformAdmin.controller");        // unchanged functions only, see below
const tenantCtrl = require("../controllers/tenant.controller");          // new
const invitationCtrl = require("../controllers/invitation.controller");  // new
const tenantValidation = require("../middleware/validation/tenant.validation");
const invitationValidation = require("../middleware/validation/invitation.validation");

const router = express.Router();

// Public
router.post("/login", ctrl.login); // unchanged

// --- Tenant Management (reworked - Sprint 1) --------------------------------
router.get("/tenants", requirePlatformAdmin, tenantCtrl.list);
router.post("/tenants", requirePlatformAdmin, tenantValidation.validateCreateTenant, tenantCtrl.create);
router.get("/tenants/:id", requirePlatformAdmin, tenantValidation.validateTenantIdParam, tenantCtrl.getDetails);
router.patch("/tenants/:id/suspend", requirePlatformAdmin, tenantValidation.validateTenantIdParam, tenantCtrl.suspend);
router.patch("/tenants/:id/activate", requirePlatformAdmin, tenantValidation.validateTenantIdParam, tenantCtrl.activate);
router.patch("/tenants/:id/archive", requirePlatformAdmin, tenantValidation.validateTenantIdParam, tenantCtrl.archive);
router.post(
  "/tenants/:id/invite",
  requirePlatformAdmin,
  tenantValidation.validateTenantIdParam,
  invitationValidation.validateInviteOwner,
  invitationCtrl.inviteOwner
);
router.post(
  "/tenants/:id/resend-invitation",
  requirePlatformAdmin,
  tenantValidation.validateTenantIdParam,
  invitationCtrl.resendInvitation
);

// --- Unchanged from Module 0 (outside this feature's scope) ------------------
router.patch("/tenants/:id/plan", requirePlatformAdmin, ctrl.updateTenantPlan);
router.post("/tenants/:id/staff", requirePlatformAdmin, ctrl.createStaffUser);
router.get("/tenants/:id/usage", requirePlatformAdmin, ctrl.getTenantUsage);

module.exports = router;
```

**Required cleanup, called out explicitly**: `platformAdmin.controller.js`'s old `createTenant`, `listTenants`, `suspendTenant`, and `reactivateTenant` functions become dead code once this route file no longer references them — they should be **removed**, not left unused, as part of applying this phase. Not silently deleted here without saying so; flagged as a required part of this change, same discipline as everything else in this feature.

### `routes/invitation.routes.js` — new, public

```js
const express = require("express");
const ctrl = require("../controllers/invitation.controller");
const { validateAcceptInvitation } = require("../middleware/validation/invitation.validation");

const router = express.Router();

// Public - unauthenticated, token-based. The invited Owner has no session
// yet; possession of a valid token IS the credential for this one endpoint
// (Tenant Management spec §7's permissions note).
router.post("/accept", validateAcceptInvitation, ctrl.acceptInvitation);

module.exports = router;
```

### `app.js` — mounting addition

```js
app.use("/api/platform-admin", platformAdminRoutes); // unchanged mount, updated router internals above
app.use("/api/tenant", tenantRoutes);                  // unchanged - this is the separate Tenant User auth router, not touched by this feature
app.use("/api/invitations", invitationRoutes);          // new
```

*(`routes/tenant.routes.js` — the existing Tenant User login/team router — is a different file from `services/tenant.service.js`'s domain and is not modified here; noted explicitly since the naming is easy to conflate.)*

---

## 4. API Review

| Check | Finding |
|---|---|
| **REST conventions** | ✅ `POST` for creation (`Create Tenant`, `Invite Owner`, `Resend Invitation`), `GET` for reads, `PATCH` for partial state transitions (`suspend`/`activate`/`archive`) — matches Module 0's own existing conventions exactly, no new pattern introduced. Sub-resource-action nesting (`/tenants/:id/invite`) mirrors the already-established `/tenants/:id/staff` pattern. |
| **HTTP status codes** | ✅ `201` for resource creation (Tenant, Invitation); `200` for reads and state transitions. One judgment call worth naming: `acceptInvitation` returns `200`, not `201`, even though it creates a `User` — treated as *completing* an existing Invitation resource rather than the caller's primary intent being resource creation. Defensible either way; noted as a deliberate choice, not an oversight. |
| **Error handling** | ✅ Every controller is `async`, relying on the existing `express-async-errors` dependency to route thrown `ApiError`s to the centralized handler — no new try/catch boilerplate, consistent with existing style. |
| **Authorization** | ✅ `requirePlatformAdmin` applied to every Tenant Management route without exception; explicitly **absent** from `/api/invitations/accept`, correctly — that endpoint's authorization model is token possession, not a Platform Admin session, per [Tenant Management spec §7]. |
| **Validation** | ✅ Every route accepting a body has its validation middleware positioned before the controller in the chain; `suspend`/`activate`/`archive` correctly validate only the `:id` param, since they take no body. |
| **Response format** | ✅ Verified per model, not assumed: `Tenant` responses return the raw Prisma row safely, since `Tenant` carries no secret field. `Invitation` and `User` responses are explicitly field-mapped ([HLD §9]) — `tokenHash` and `passwordHash` are never serialized, checked deliberately for each, not by blanket rule. |

**Compatibility break, stated plainly**: `PATCH /tenants/:id/reactivate` no longer exists — replaced by `PATCH /tenants/:id/activate`, matching Phase 4's approved service function name. Any existing frontend call to the old path will fail (404) until the frontend is updated in a later, not-yet-requested phase. Not worked around silently (e.g., by supporting both paths) — a real, single, correct new name.

---

**STOP — awaiting approval. Not yet applied to `uae-vat-saas/src/`.**
