# Tenant Management — Implementation Phase 4: Backend Service Layer

- **Status:** Proposed — **not yet applied to `uae-vat-saas/src/`**; awaiting approval before Phase 5 (controllers)
- **Date:** 2026-07-30
- **Implements:** [Phase 3 migration](06-tenant-management-migration.md) (Approved), on top of the approved [Phase 1](04-tenant-management-domain-design.md)/[Phase 2](05-tenant-management-prisma-schema.md) design.
- **A finding that changes one behavior from the approved spec/UX, flagged before the code**: see the note above this document — **Owner Name/Email are now collected at Invite Owner time, not Create Tenant time.** Everything else below follows the approved specs exactly.
- **Layering**: Controller → Service → Repository, per [HLD §4]/[§6]/[§7] — no controllers here (not requested), but Services genuinely need a Repository to reach Prisma correctly (Services never call Prisma directly, per [HLD §7]), so a thin Repository per model is included as a necessary part of "Service Layer," not scope creep.
- **New supporting file**: `services/audit.service.js` — a minimal wrapper around the existing `AuditLog` table (no Audit platform service exists in code yet; this is the smallest correct implementation, not a redesign of it).
- **Acknowledged, not resolved here**: `InvitationService` calls a `notificationService.send(...)` interface that does not exist in code yet ([HLD §17]) — the Notification platform service itself is out of this phase's scope. The call is written against the interface [PAS §8]/[HLD §17] already committed to; wiring a real implementation is a separate, still-pending piece of work (see the note in the [Tenant Management spec §12] about pulling this into Sprint 1).

---

## 1. Service Layer

### `repositories/tenant.repository.js`

```js
const prisma = require("../config/prisma");

async function create({ name, plan, createdByAdminId }) {
  return prisma.tenant.create({
    data: { name, plan, status: "DRAFT", createdByAdminId },
  });
}

async function findById(id) {
  return prisma.tenant.findUnique({ where: { id } });
}

async function findSimilarByName(name) {
  // Case-insensitive exact match only - the soft-duplicate warning this
  // supports is intentionally simple (Tenant Management spec §5); fuzzy
  // similarity matching is not built here.
  return prisma.tenant.findFirst({
    where: { name: { equals: name, mode: "insensitive" } },
  });
}

async function updateStatus(id, status) {
  return prisma.tenant.update({ where: { id }, data: { status } });
}

module.exports = { create, findById, findSimilarByName, updateStatus };
```

*(`mode: "insensitive"` is a Postgres-only Prisma filter; on the current SQLite datasource it has no effect and Prisma falls back to a case-sensitive match. Noted, not fixed — a case-insensitive check on SQLite would need an application-level `toLowerCase()` comparison instead, a small provider-specific gap acceptable to leave for the Postgres migration itself, not this phase.)*

### `repositories/invitation.repository.js`

```js
const prisma = require("../config/prisma");

async function findLiveByTenantId(tenantId) {
  return prisma.invitation.findFirst({
    where: { tenantId, invalidatedAt: null, acceptedAt: null },
    orderBy: { createdAt: "desc" },
  });
}

async function findByTokenHash(tokenHash) {
  return prisma.invitation.findUnique({ where: { tokenHash } });
}

async function create({ tenantId, inviteeName, inviteeEmail, tokenHash, expiresAt, invitedByAdminId }) {
  return prisma.invitation.create({
    data: { tenantId, inviteeName, inviteeEmail, tokenHash, expiresAt, invitedByAdminId },
  });
}

async function invalidate(id) {
  return prisma.invitation.update({ where: { id }, data: { invalidatedAt: new Date() } });
}

async function markAccepted(id) {
  return prisma.invitation.update({ where: { id }, data: { acceptedAt: new Date() } });
}

module.exports = { findLiveByTenantId, findByTokenHash, create, invalidate, markAccepted };
```

### `services/audit.service.js`

```js
const prisma = require("../config/prisma");

// Minimal, correct implementation of the Audit Logging platform service's
// write path (PAS §8) - a single, explicit call point every Service uses.
// Never automatic, never inferred - only called where a Service author
// decides an action belongs in the mandatory audit taxonomy (DDS §11).
async function recordAuditEvent({ tenantId, action, recordType, userId, platformAdminId }) {
  return prisma.auditLog.create({
    data: { tenantId, action, recordType, userId: userId ?? null, platformAdminId: platformAdminId ?? null },
  });
}

module.exports = { recordAuditEvent };
```

### `services/tenant.service.js`

```js
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const tenantRepository = require("../repositories/tenant.repository");
const audit = require("./audit.service");
const { PLAN_LIMITS } = require("../config/plans");

const VALID_PLANS = Object.keys(PLAN_LIMITS);

// --- Create Tenant --------------------------------------------------------
// Captures only what Tenant can actually persist (name, plan). Owner
// name/email are NOT collected here - see the note at the top of this
// document; they belong to Invite Owner instead.
async function createTenant({ name, plan }, { adminId }) {
  if (!name || name.trim().length < 1 || name.length > 200) {
    throw new ApiError(400, "Company name is required and must be 1-200 characters");
  }
  if (!plan || !VALID_PLANS.includes(plan)) {
    throw new ApiError(400, `plan must be one of ${VALID_PLANS.join(", ")}`);
  }

  const warnings = [];
  const similar = await tenantRepository.findSimilarByName(name);
  if (similar) {
    // Soft warning only - Tenant Management spec §5 explicitly does not
    // block on this, since trading names legitimately repeat.
    warnings.push(`A Tenant named "${similar.name}" already exists. Confirm this is a different business.`);
  }

  const tenant = await tenantRepository.create({ name, plan, createdByAdminId: adminId });

  await audit.recordAuditEvent({
    tenantId: tenant.id,
    action: "tenant.created",
    recordType: "Tenant",
    platformAdminId: adminId,
  });

  return { tenant, warnings };
}

// --- Suspend Tenant --------------------------------------------------------
async function suspendTenant(tenantId, { adminId }) {
  const tenant = await tenantRepository.findById(tenantId);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (tenant.status !== "ACTIVE") {
    throw new ApiError(409, `Cannot suspend a Tenant in ${tenant.status} status - must be ACTIVE`);
  }

  const updated = await tenantRepository.updateStatus(tenantId, "SUSPENDED");
  await audit.recordAuditEvent({
    tenantId,
    action: "tenant.suspended",
    recordType: "Tenant",
    platformAdminId: adminId,
  });
  return updated;
}

// --- Activate (Reactivate) Tenant -------------------------------------------
async function activateTenant(tenantId, { adminId }) {
  const tenant = await tenantRepository.findById(tenantId);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (tenant.status !== "SUSPENDED") {
    throw new ApiError(409, `Cannot activate a Tenant in ${tenant.status} status - must be SUSPENDED`);
  }

  const updated = await tenantRepository.updateStatus(tenantId, "ACTIVE");
  await audit.recordAuditEvent({
    tenantId,
    action: "tenant.reactivated",
    recordType: "Tenant",
    platformAdminId: adminId,
  });
  return updated;
}

// --- Archive Tenant ----------------------------------------------------------
// Reachable only from SUSPENDED (Tenant Management spec §4 Rule 4) - never
// directly from ACTIVE, enforced here, not left to the caller/UI alone.
async function archiveTenant(tenantId, { adminId }) {
  const tenant = await tenantRepository.findById(tenantId);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (tenant.status !== "SUSPENDED") {
    throw new ApiError(409, "A Tenant can only be archived from Suspended status - suspend it first");
  }

  const updated = await tenantRepository.updateStatus(tenantId, "ARCHIVED");
  await audit.recordAuditEvent({
    tenantId,
    action: "tenant.archived",
    recordType: "Tenant",
    platformAdminId: adminId,
  });
  return updated;
}

module.exports = { createTenant, suspendTenant, activateTenant, archiveTenant };
```

### `services/invitation.service.js`

```js
const crypto = require("crypto");
const bcrypt = require("bcrypt");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const tenantRepository = require("../repositories/tenant.repository");
const invitationRepository = require("../repositories/invitation.repository");
const audit = require("./audit.service");
// Not yet implemented - platform service interface only, per PAS §8/HLD §17.
// Wiring a real provider is separate work, out of this phase's scope.
const notificationService = require("./notification.service");

const INVITATION_EXPIRY_DAYS = 7; // Tenant Management spec §5

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Tokens are single-use bearer credentials, not passwords: high entropy
// (256 bits) makes brute-force infeasible without bcrypt's deliberately
// slow hashing, so a fast SHA-256 hash is the correct, standard choice here
// - the raw token exists only in the emailed link, never stored (Phase 1
// Review §5's security finding).
function generateToken() {
  const raw = crypto.randomBytes(32).toString("hex");
  const hash = crypto.createHash("sha256").update(raw).digest("hex");
  return { raw, hash };
}

async function assertEmailNotInUse(email) {
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw new ApiError(409, "A user with this email already exists");
  }
}

// --- Invite Owner ------------------------------------------------------------
async function inviteOwner(tenantId, { ownerName, ownerEmail }, { adminId }) {
  const tenant = await tenantRepository.findById(tenantId);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (tenant.status !== "DRAFT") {
    throw new ApiError(409, `Cannot invite an Owner for a Tenant in ${tenant.status} status - must be Draft`);
  }
  if (!ownerName || ownerName.trim().length < 1 || ownerName.length > 100) {
    throw new ApiError(400, "Owner name is required and must be 1-100 characters");
  }
  if (!ownerEmail || !EMAIL_RE.test(ownerEmail)) {
    throw new ApiError(400, "A valid owner email is required");
  }
  await assertEmailNotInUse(ownerEmail);

  const { raw, hash } = generateToken();
  const expiresAt = new Date(Date.now() + INVITATION_EXPIRY_DAYS * 24 * 60 * 60 * 1000);

  const invitation = await prisma.$transaction(async (tx) => {
    const created = await tx.invitation.create({
      data: {
        tenantId,
        inviteeName: ownerName,
        inviteeEmail: ownerEmail,
        tokenHash: hash,
        expiresAt,
        invitedByAdminId: adminId,
      },
    });
    await tx.tenant.update({ where: { id: tenantId }, data: { status: "INVITED" } });
    return created;
  });

  await audit.recordAuditEvent({
    tenantId,
    action: "tenant.owner_invited",
    recordType: "Invitation",
    platformAdminId: adminId,
  });

  await notificationService.send({
    to: ownerEmail,
    template: "owner-invitation",
    data: { tenantName: tenant.name, token: raw }, // raw token, only place it ever appears
  });

  return invitation;
}

// --- Resend Invitation ---------------------------------------------------------
async function resendInvitation(tenantId, { adminId }) {
  const tenant = await tenantRepository.findById(tenantId);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (tenant.status !== "INVITED") {
    throw new ApiError(409, "Can only resend an invitation for a Tenant currently in Invited status");
  }

  const live = await invitationRepository.findLiveByTenantId(tenantId);
  if (!live) {
    // Defensive - should be structurally unreachable if status is INVITED,
    // but never assume; fail loudly rather than silently proceed.
    throw new ApiError(500, "No live invitation found for a Tenant in Invited status");
  }

  const { raw, hash } = generateToken();
  const expiresAt = new Date(Date.now() + INVITATION_EXPIRY_DAYS * 24 * 60 * 60 * 1000);

  const newInvitation = await prisma.$transaction(async (tx) => {
    await tx.invitation.update({ where: { id: live.id }, data: { invalidatedAt: new Date() } });
    return tx.invitation.create({
      data: {
        tenantId,
        inviteeName: live.inviteeName,
        inviteeEmail: live.inviteeEmail,
        tokenHash: hash,
        expiresAt,
        invitedByAdminId: adminId,
      },
    });
  });

  await audit.recordAuditEvent({
    tenantId,
    action: "tenant.invitation_resent",
    recordType: "Invitation",
    platformAdminId: adminId,
  });

  await notificationService.send({
    to: live.inviteeEmail,
    template: "owner-invitation",
    data: { tenantName: tenant.name, token: raw },
  });

  return newInvitation;
}

// --- Accept Invitation (Owner, unauthenticated, token-based) --------------------
async function acceptInvitation(rawToken, { password }) {
  if (!rawToken) throw new ApiError(400, "Invitation token is required");
  if (!password || password.length < 8) {
    // Minimal check only - the full platform password policy is still a
    // Design-Now-Build-Later item (PAS §5); this is a floor, not the final rule.
    throw new ApiError(400, "Password must be at least 8 characters");
  }

  const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
  const invitation = await invitationRepository.findByTokenHash(tokenHash);

  // Deliberately generic error for every invalid case (not found, already
  // accepted, invalidated by a resend, or expired) - do not reveal which,
  // to avoid leaking information to someone guessing tokens.
  const invalid = () => new ApiError(400, "This invitation link is no longer valid");
  if (!invitation) throw invalid();
  if (invitation.acceptedAt) throw invalid();
  if (invitation.invalidatedAt) throw invalid();
  if (invitation.expiresAt < new Date()) throw invalid();

  const passwordHash = await bcrypt.hash(password, 10);

  const result = await prisma.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        tenantId: invitation.tenantId,
        name: invitation.inviteeName,
        email: invitation.inviteeEmail,
        passwordHash,
        role: "OWNER",
      },
    });
    await tx.invitation.update({ where: { id: invitation.id }, data: { acceptedAt: new Date() } });
    const tenant = await tx.tenant.update({ where: { id: invitation.tenantId }, data: { status: "ACTIVE" } });
    return { user, tenant };
  });

  await audit.recordAuditEvent({
    tenantId: invitation.tenantId,
    action: "tenant.activated",
    recordType: "Tenant",
    userId: result.user.id,
  });

  return result;
}

module.exports = { inviteOwner, resendInvitation, acceptInvitation };
```

---

## 2. Business Logic — summary

| Operation | Preconditions checked | Side effects (same transaction unless noted) |
|---|---|---|
| Create Tenant | Name/plan valid | Tenant row (`DRAFT`) + audit event. Soft-duplicate-name check is informational only, never blocking. |
| Invite Owner | Tenant is `DRAFT`; owner name/email valid; email not already a `User` anywhere | Invitation row + `Tenant.status → INVITED` (one transaction) → audit event → email (outside the transaction — see [§4]) |
| Resend Invitation | Tenant is `INVITED`; a live Invitation exists | Old Invitation invalidated + new Invitation created (one transaction) → audit event → email |
| Accept Invitation | Token resolves, unaccepted, not invalidated, not expired; password meets the floor policy | `User` created + Invitation accepted + `Tenant.status → ACTIVE` (one transaction) → audit event |
| Suspend Tenant | Tenant is `ACTIVE` | Status → `SUSPENDED` + audit event |
| Activate Tenant | Tenant is `SUSPENDED` | Status → `ACTIVE` + audit event |
| Archive Tenant | Tenant is `SUSPENDED` (never directly from `ACTIVE`) | Status → `ARCHIVED` + audit event |

---

## 3. Validation

| Rule | Enforced in | Matches |
|---|---|---|
| Company Name 1–200 chars | `tenant.service.js` | [Tenant Management spec §5] |
| Owner Name 1–100 chars | `invitation.service.js` | Spec §5 |
| Owner Email format | `invitation.service.js` (regex) | Spec §5 |
| Plan must be a known plan key | `tenant.service.js` (`PLAN_LIMITS`, existing config, reused not redefined) | Spec §5 |
| Duplicate Owner Email → hard block | `invitation.service.js`, checked against the existing global `User.email` uniqueness | Spec §5/§8, [DDS §22 Decision 5] |
| Duplicate Company Name → soft warning only | `tenant.service.js`, returned as a `warnings` array, never thrown | Spec §5 |
| Invitation token validity (exists, unaccepted, not invalidated, unexpired) | `invitation.service.js`, one generic error for all four failure modes | Spec §8 |
| Password floor (≥ 8 chars) | `invitation.service.js` | Inherits [PAS §5]'s still-open full policy — this is a floor, not the final rule |

---

## 4. Transactions

| Operation | Why it needs `$transaction` |
|---|---|
| Invite Owner | Creating the Invitation and moving `Tenant.status` to `INVITED` must succeed or fail together — an Invitation existing without the Tenant reflecting `INVITED` (or vice versa) would be an inconsistent state no query could safely interpret. |
| Resend Invitation | Invalidating the old Invitation and creating the new one must be atomic — a crash between the two steps must never leave two simultaneously-live Invitations (the exact race condition flagged in [Phase 1 Review §5]). |
| Accept Invitation | The most consequential transaction in this feature — `User` creation, marking the Invitation accepted, and activating the Tenant must all succeed together. A partial failure here (e.g., User created but Tenant still `INVITED`) would leave a real person with working credentials to a Tenant they can't actually use. |
| Create Tenant, Suspend, Activate, Archive | **No transaction needed** — each is a single write. Wrapping a single statement in `$transaction` adds nothing. |

**Deliberately outside every transaction**: the email send in `inviteOwner`/`resendInvitation`. Per [HLD §17]'s graceful-degradation principle, a Notification failure must never roll back an already-correct database state — if the email provider is briefly down, the Tenant is still correctly `INVITED` with a valid, real Invitation; the email itself is retryable independently (once a real retry mechanism exists — [SDD §20], not built in this phase).

---

## 5. Error Handling

Every failure is a thrown `ApiError` (the existing Module 0 utility, reused unchanged), each carrying the right HTTP-adjacent status for a not-yet-written controller to pass through:

| Scenario | Status | Message shape |
|---|---|---|
| Missing/invalid Company Name, Owner Name, Owner Email, Plan, Password | 400 | Specific, field-level |
| Duplicate Owner Email | 409 | "A user with this email already exists" |
| Tenant not found | 404 | "Tenant not found" |
| Invalid lifecycle transition (e.g., archiving from `ACTIVE`, suspending a `DRAFT` Tenant) | 409 | States the required current status |
| Invalid/expired/already-accepted/invalidated invitation token | 400 | One deliberately generic message for all four cases — see [§1]'s `acceptInvitation`, prevents information leakage to a guesser |
| Unexpected (e.g., the "no live invitation for an Invited Tenant" defensive check) | 500 | Logged in full server-side; generic to any eventual client, per [ADR §11] |

No error here ever leaks internal detail (a Prisma error message, a stack trace) — every failure path is a deliberately thrown, named `ApiError`, never a bare exception reaching the (not-yet-built) centralized handler unclassified.

---

## 6. Unit-Test Scenarios

Every scenario below tests the Service layer with the Repository **mocked** — no real database involved, per [HLD §20]'s stated payoff for introducing the Repository layer at all.

| Function | Scenario | Expected |
|---|---|---|
| `createTenant` | Valid name/plan, no similar Tenant exists | Tenant created, `warnings: []` |
| `createTenant` | Valid name/plan, a similarly-named Tenant exists | Tenant still created, `warnings` contains one message |
| `createTenant` | Empty name | Throws `ApiError(400)`, no repository call made |
| `createTenant` | Invalid plan value | Throws `ApiError(400)` |
| `inviteOwner` | Tenant is `DRAFT`, valid owner details, email not in use | Invitation created, Tenant status becomes `INVITED`, notification called with the raw token |
| `inviteOwner` | Tenant is `ACTIVE` (wrong state) | Throws `ApiError(409)`, no Invitation created |
| `inviteOwner` | Owner email already belongs to a `User` | Throws `ApiError(409)`, no Invitation created, no email sent |
| `resendInvitation` | Tenant is `INVITED`, a live Invitation exists | Old Invitation's `invalidatedAt` set, new Invitation created with a different token hash |
| `resendInvitation` | Tenant is `DRAFT` (never invited yet) | Throws `ApiError(409)` |
| `acceptInvitation` | Valid token, unexpired, unaccepted, unused | `User` created with role `OWNER`, Invitation `acceptedAt` set, Tenant becomes `ACTIVE` |
| `acceptInvitation` | Token does not exist | Throws `ApiError(400)`, generic message |
| `acceptInvitation` | Token already accepted (double-use) | Throws `ApiError(400)`, same generic message as "not found" — verifies no information leakage |
| `acceptInvitation` | Token invalidated by a prior Resend | Throws `ApiError(400)` |
| `acceptInvitation` | Token expired | Throws `ApiError(400)` |
| `acceptInvitation` | Password under 8 characters | Throws `ApiError(400)` before any database call |
| `suspendTenant` | Tenant is `ACTIVE` | Status becomes `SUSPENDED` |
| `suspendTenant` | Tenant is `DRAFT`/`INVITED`/`SUSPENDED`/`ARCHIVED` (anything but `ACTIVE`) | Throws `ApiError(409)` for each |
| `activateTenant` | Tenant is `SUSPENDED` | Status becomes `ACTIVE` |
| `archiveTenant` | Tenant is `SUSPENDED` | Status becomes `ARCHIVED` |
| `archiveTenant` | Tenant is `ACTIVE` (the specific rule this feature cares most about getting right) | Throws `ApiError(409)`, Tenant remains `ACTIVE` — the direct test of [Tenant Management spec §4 Rule 4] |

### Example — one illustrative test, showing the mocking pattern

```js
const tenantService = require("../services/tenant.service");
jest.mock("../repositories/tenant.repository");
jest.mock("../services/audit.service");
const tenantRepository = require("../repositories/tenant.repository");

test("archiveTenant rejects a Tenant that is ACTIVE, not SUSPENDED", async () => {
  tenantRepository.findById.mockResolvedValue({ id: "t1", status: "ACTIVE" });

  await expect(
    tenantService.archiveTenant("t1", { adminId: "admin1" })
  ).rejects.toMatchObject({ statusCode: 409 });

  expect(tenantRepository.updateStatus).not.toHaveBeenCalled();
});
```

*(No test framework is in either `package.json` yet — [HLD §20]'s flagged, standing gap. Adding one (Jest is assumed above as the illustrative choice) is itself a small setup step, not covered by this phase.)*

---

**STOP — awaiting approval before Phase 5. Not yet applied to `uae-vat-saas/src/`.**
