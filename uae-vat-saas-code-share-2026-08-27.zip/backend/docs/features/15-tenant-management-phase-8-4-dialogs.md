# Tenant Management — Phase 8.4: Tenant Action Dialogs

- **Status:** Proposed — **not yet applied to `frontend/`**; awaiting approval before Phase 8.5
- **Date:** 2026-07-30
- **Consumes**: `api.inviteOwner()`, `api.suspendTenant()`, `api.activateTenant()`, `api.archiveTenant()` only — all approved, unmodified ([Phase 5]/[Phase 8]).
- **Four findings, addressed above, not silently**: `ConfirmationDialog`'s single-`<p>` message slot cannot hold `ErrorBanner`; it also cannot hold form fields at all, so `InviteOwnerDialog` is a necessary independent implementation; Tenant Details needs a minimal Actions addition to have anything to wire dialogs to; `ResendInvitationDialog` is out of this phase's file list even though the button that would trigger it already exists and is frozen.

---

## `components/tenant-management/SuspendTenantDialog.js`

```jsx
"use client";

import { api } from "../../lib/api";
import { adminAuth } from "../../lib/auth";
import { useApi } from "../../hooks/useApi";
import { useToast } from "../../hooks/useToast";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function SuspendTenantDialog({ tenant, onClose, onSuccess }) {
  const { execute, loading, error } = useApi(api.suspendTenant);
  const { showToast } = useToast();

  async function handleConfirm() {
    try {
      const token = adminAuth.get();
      await execute(token, tenant.id);
      showToast(`"${tenant.name}" has been suspended.`);
      onSuccess();
    } catch {
      // error captured by useApi; message prop below swaps to show it -
      // dialog stays open so the Admin can see it and retry or cancel
    }
  }

  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Its Owner and Staff will be unable to log in until reactivated. This is reversible.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Suspend Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Suspending…" : "Suspend"}
      cancelLabel="Cancel"
      variant="danger"
      busy={loading}
      onConfirm={handleConfirm}
      onCancel={onClose}
    />
  );
}
```

## `components/tenant-management/ActivateTenantDialog.js`

```jsx
"use client";

import { api } from "../../lib/api";
import { adminAuth } from "../../lib/auth";
import { useApi } from "../../hooks/useApi";
import { useToast } from "../../hooks/useToast";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function ActivateTenantDialog({ tenant, onClose, onSuccess }) {
  const { execute, loading, error } = useApi(api.activateTenant);
  const { showToast } = useToast();

  async function handleConfirm() {
    try {
      const token = adminAuth.get();
      await execute(token, tenant.id);
      showToast(`"${tenant.name}" has been activated.`);
      onSuccess();
    } catch {
      // error captured by useApi
    }
  }

  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Access will be restored immediately.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Activate Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Activating…" : "Activate"}
      cancelLabel="Cancel"
      variant="primary"
      busy={loading}
      onConfirm={handleConfirm}
      onCancel={onClose}
    />
  );
}
```

## `components/tenant-management/ArchiveTenantDialog.js`

```jsx
"use client";

import { api } from "../../lib/api";
import { adminAuth } from "../../lib/auth";
import { useApi } from "../../hooks/useApi";
import { useToast } from "../../hooks/useToast";
import ConfirmationDialog from "../ui/ConfirmationDialog";
import { TENANT_STATUS_LABELS } from "../../constants/tenantStatus";

export default function ArchiveTenantDialog({ tenant, onClose, onSuccess }) {
  const { execute, loading, error } = useApi(api.archiveTenant);
  const { showToast } = useToast();

  async function handleConfirm() {
    try {
      const token = adminAuth.get();
      await execute(token, tenant.id);
      showToast(`"${tenant.name}" has been archived.`);
      onSuccess();
    } catch {
      // error captured by useApi
    }
  }

  const statusLabel = TENANT_STATUS_LABELS[tenant.status] || tenant.status;
  const confirmationText = `${tenant.name} is currently ${statusLabel}. Archiving is permanent: this Tenant's Owner and Staff will never be able to log in again. All historical records are retained.`;

  return (
    <ConfirmationDialog
      open={true}
      title="Archive Tenant"
      message={error || confirmationText}
      confirmLabel={loading ? "Archiving…" : "Archive"}
      cancelLabel="Cancel"
      variant="danger"
      busy={loading}
      onConfirm={handleConfirm}
      onCancel={onClose}
    />
  );
}
```

## `components/tenant-management/InviteOwnerDialog.js`

```jsx
"use client";

import { useEffect, useRef, useState } from "react";
import { api } from "../../lib/api";
import { adminAuth } from "../../lib/auth";
import { useApi } from "../../hooks/useApi";
import { useToast } from "../../hooks/useToast";
import ErrorBanner from "../ui/ErrorBanner";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(form) {
  const errors = {};
  if (!form.ownerName || !form.ownerName.trim()) {
    errors.ownerName = "Owner name is required";
  }
  if (!form.ownerEmail || !EMAIL_RE.test(form.ownerEmail)) {
    errors.ownerEmail = "A valid owner email is required";
  }
  return errors;
}

// Cannot reuse ConfirmationDialog - it has no slot for form fields (see the
// note at the top of this document). This replicates ConfirmationDialog's
// actual behavior (initial focus, Escape-to-close, focus-return; not a full
// Tab-cycling trap - ConfirmationDialog doesn't implement one either) rather
// than inventing different accessibility behavior for this one dialog.
export default function InviteOwnerDialog({ tenant, onClose, onSuccess }) {
  const [form, setForm] = useState({ ownerName: "", ownerEmail: "" });
  const [fieldErrors, setFieldErrors] = useState({});
  const { execute, loading, error, setError } = useApi(api.inviteOwner);
  const { showToast } = useToast();
  const dialogRef = useRef(null);
  const previouslyFocused = useRef(null);

  useEffect(() => {
    previouslyFocused.current = document.activeElement;
    dialogRef.current?.querySelector("input")?.focus();

    function handleKeyDown(e) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      previouslyFocused.current?.focus();
    };
  }, [onClose]);

  function updateField(key) {
    return (e) => {
      setForm((f) => ({ ...f, [key]: e.target.value }));
      if (fieldErrors[key]) setFieldErrors((prev) => ({ ...prev, [key]: undefined }));
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    const errors = validate(form);
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    try {
      const token = adminAuth.get();
      await execute(token, tenant.id, form);
      showToast(`Invitation sent to ${form.ownerEmail}.`);
      onSuccess();
    } catch {
      // error captured by useApi, rendered via ErrorBanner below - this
      // dialog, unlike the three above, genuinely can hold ErrorBanner,
      // since it isn't constrained by ConfirmationDialog's single-<p> shell
    }
  }

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div
        className="dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="invite-owner-title"
        tabIndex={-1}
        ref={dialogRef}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="invite-owner-title">Invite Owner</h2>
        <p className="helptext">
          An invitation email will be sent to the address below for <strong>{tenant.name}</strong>.
        </p>

        <form onSubmit={handleSubmit} noValidate>
          {error && <ErrorBanner message={error} />}

          <div className="field">
            <label htmlFor="owner-name">
              Owner Name <span aria-hidden="true">*</span>
              <span className="sr-only"> (required)</span>
            </label>
            <input
              id="owner-name"
              value={form.ownerName}
              onChange={updateField("ownerName")}
              required
              aria-required="true"
              aria-invalid={fieldErrors.ownerName ? "true" : "false"}
              aria-describedby={fieldErrors.ownerName ? "owner-name-error" : undefined}
              disabled={loading}
            />
            {fieldErrors.ownerName && (
              <p id="owner-name-error" className="field-error" role="alert">
                {fieldErrors.ownerName}
              </p>
            )}
          </div>

          <div className="field" style={{ marginBottom: 0 }}>
            <label htmlFor="owner-email">
              Owner Email <span aria-hidden="true">*</span>
              <span className="sr-only"> (required)</span>
            </label>
            <input
              id="owner-email"
              type="email"
              value={form.ownerEmail}
              onChange={updateField("ownerEmail")}
              required
              aria-required="true"
              aria-invalid={fieldErrors.ownerEmail ? "true" : "false"}
              aria-describedby={fieldErrors.ownerEmail ? "owner-email-error" : undefined}
              disabled={loading}
            />
            {fieldErrors.ownerEmail && (
              <p id="owner-email-error" className="field-error" role="alert">
                {fieldErrors.ownerEmail}
              </p>
            )}
          </div>

          <div className="dialog-actions">
            <button type="button" className="btn btn-outline" onClick={onClose} disabled={loading}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? "Sending…" : "Send Invitation"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
```

*(Uses the `.dialog-overlay`/`.dialog`/`.dialog-actions` CSS classes already defined for `ConfirmationDialog` in Phase 8 — visually consistent even though the component itself couldn't be reused. No new CSS added.)*

---

## Integration: `app/admin/tenants/page.js` (minimal diff over Phase 8.1's approved version)

```jsx
// ADDED imports
import InviteOwnerDialog from "../../../components/tenant-management/InviteOwnerDialog";
import SuspendTenantDialog from "../../../components/tenant-management/SuspendTenantDialog";
import ActivateTenantDialog from "../../../components/tenant-management/ActivateTenantDialog";
import ArchiveTenantDialog from "../../../components/tenant-management/ArchiveTenantDialog";

// ...unchanged code through the existing handleAction...

// ADDED
function handleActionSuccess() {
  setPendingAction(null);
  load(); // existing pattern - no browser reload
}

// ADDED at the end of the returned JSX (siblings to the existing content):
{pendingAction?.action === "inviteOwner" && (
  <InviteOwnerDialog
    tenant={pendingAction.tenant}
    onClose={() => setPendingAction(null)}
    onSuccess={handleActionSuccess}
  />
)}
{pendingAction?.action === "suspend" && (
  <SuspendTenantDialog
    tenant={pendingAction.tenant}
    onClose={() => setPendingAction(null)}
    onSuccess={handleActionSuccess}
  />
)}
{pendingAction?.action === "activate" && (
  <ActivateTenantDialog
    tenant={pendingAction.tenant}
    onClose={() => setPendingAction(null)}
    onSuccess={handleActionSuccess}
  />
)}
{pendingAction?.action === "archive" && (
  <ArchiveTenantDialog
    tenant={pendingAction.tenant}
    onClose={() => setPendingAction(null)}
    onSuccess={handleActionSuccess}
  />
)}
{/* Known Gap: pendingAction.action === "resendInvitation" has no matching
    dialog in this phase - see the note above this document. The button
    that sets this state already exists (Phase 8.1, frozen); clicking it
    currently has no visible effect. */}
```

Everything else in this file — state declared in Phase 8.1 (`pendingAction`, `handleAction`), the table, search, pagination, loading/empty/error states — is **unchanged**.

## Integration: `app/admin/tenants/[tenantId]/page.js` (minimal diff over Phase 8.3's approved version)

```jsx
// ADDED imports
import Card from "../../../../components/ui/Card";
import TenantActionMenu from "../../../../components/tenant-management/TenantActionMenu";
import InviteOwnerDialog from "../../../../components/tenant-management/InviteOwnerDialog";
import SuspendTenantDialog from "../../../../components/tenant-management/SuspendTenantDialog";
import ActivateTenantDialog from "../../../../components/tenant-management/ActivateTenantDialog";
import ArchiveTenantDialog from "../../../../components/tenant-management/ArchiveTenantDialog";

// ADDED state, same pattern as the List page
const [pendingAction, setPendingAction] = useState(null);

function handleAction(action, tenant) {
  setPendingAction({ action, tenant });
}
function handleActionSuccess() {
  setPendingAction(null);
  load(); // existing Phase 8.3 pattern - re-fetches this one Tenant, no reload
}

// ADDED to the successful-render branch, after the existing four cards -
// the minimal trigger UI Tenant Details needs to have anything to wire a
// dialog to (Phase 8.3 had none, by its own explicit scope):
<Card>
  <h2>Actions</h2>
  <TenantActionMenu tenant={tenant} onAction={handleAction} />
</Card>

// ADDED at the end, identical dialog-rendering block to the List page
// (same four conditions, same Known Gap on resendInvitation)
```

`TenantHeader`, `TenantOverviewCard`, `TenantOwnerCard`, `TenantActivityCard` are **unchanged** — this phase adds one new `Card` block and the dialog wiring, nothing else on this page.

---

## Architecture Review

Every dialog follows the same shape: own its mutation via `useApi`, own its success toast via `useToast`, communicate outward only through `onClose`/`onSuccess` — no dialog reaches into the parent page's state beyond those two callbacks, and no page reaches into a dialog's internals. `InviteOwnerDialog`'s necessary duplication of `ConfirmationDialog`'s shell is the one place this phase's architecture isn't as clean as it would be if the frozen component supported children — recorded as a real cost of the "do not modify shared components" constraint, not hidden.

## API Compliance Review

Four calls, four approved endpoints, verified 1:1: `inviteOwner` → `POST /tenants/:id/invite`; `suspendTenant` → `PATCH /tenants/:id/suspend`; `activateTenant` → `PATCH /tenants/:id/activate`; `archiveTenant` → `PATCH /tenants/:id/archive`. No endpoint invented, no request body beyond what each approved controller expects.

## Accessibility Review

- All three `ConfirmationDialog`-based dialogs inherit its focus/Escape/return behavior unchanged, and its `busy`-disables-both-buttons pattern, which also prevents double submission.
- `InviteOwnerDialog` replicates the same behavior by hand — verified to match, not diverge — including the same partial-trap limitation (no Tab-cycling) already present in the frozen component, inherited rather than newly introduced.
- Every form field in `InviteOwnerDialog` has a real label, `aria-required`, `aria-invalid`, and `aria-describedby` wired to its error text — matching [Phase 8.2]'s established pattern exactly, not a new one.

## Performance Review

Each dialog calls its mutation exactly once per confirm click (`busy` prevents re-entry); `handleActionSuccess` calls `load()` exactly once per successful mutation, never twice, and never triggers a browser reload — verified against both integration diffs above.

## Known Backend Gaps

1. **`ConfirmationDialog`'s message slot cannot hold `ErrorBanner`** — backend errors from Suspend/Activate/Archive are shown as plain text replacing the confirmation message, not via the actual `ErrorBanner` component, because the frozen shell has no structural room for it.
2. **`ConfirmationDialog` cannot hold form fields at all** — `InviteOwnerDialog` had to become an independent implementation rather than a true reuse.
3. **No `ResendInvitationDialog` exists this phase**, while the button that would trigger it is already live and frozen (Phase 8.1) — clicking "Resend Invitation" on an `INVITED` Tenant currently does nothing visible.
4. **`ConfirmationDialog`'s focus handling is not a true Tab-cycling trap** — pre-existing in the frozen component, now also present in `InviteOwnerDialog` by necessary duplication.

## Future Improvements

1. If `ConfirmationDialog` is ever revisited, adding a `children` slot (in addition to `message`) would let it hold `ErrorBanner` properly and would let `InviteOwnerDialog` become a true reuse instead of a parallel implementation — eliminating findings #1, #2, and #4 at once.
2. `ResendInvitationDialog`, structurally the simplest of all five (identical shape to Suspend/Activate) — the clear, low-risk next addition.
3. A real Tab-cycling focus trap across both the shared component and this phase's duplicate, if stricter accessibility conformance is wanted later.

---

**STOP — awaiting approval before Phase 8.5. Not yet applied to `frontend/`.**
