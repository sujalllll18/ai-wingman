# Tenant Management — Implementation Phase 8: Frontend Foundation

- **Status:** Proposed — **not yet applied to `frontend/`**; awaiting approval before pages are built
- **Date:** 2026-07-30
- **Implements:** [Phase 7 Frontend Specification](10-tenant-management-frontend-spec.md) (Approved) — foundation only: layout, API client, shared components, constants, generic hooks. No `app/admin/tenants/*` pages, no tenant-specific hooks, per the explicit scope of this phase.
- **Two findings, addressed below, not silently**: see the note above this document — (1) `lib/api.js`'s existing `createTenant`/`reactivateTenant` methods are corrected to match the approved backend exactly, not left stale; (2) the Admin sidebar's one nav-link change makes `/admin/dashboard` dead code, flagged for removal in a future page-building phase, not touched here.
- **Styling**: every new component is built from the *existing* `globals.css` design tokens (`--color-*`, `--radius`, `.btn`/`.card`/`.page-header`/etc. classes already defined) — two genuinely new visual patterns (skeleton loading, dialogs) are added as small, additive CSS because nothing to reuse exists for them yet, not because the design system is being redesigned.

---

## Folder Structure (created by this phase)

```
frontend/
  components/
    ui/                        NEW - shared, feature-agnostic components
      Button.js
      Card.js
      PageHeader.js
      EmptyState.js
      ErrorBanner.js
      LoadingSkeleton.js
      ConfirmationDialog.js
      Toast.js
      ToastProvider.js
  constants/
    tenantStatus.js             NEW
  hooks/
    useApi.js                   NEW
    useToast.js                 NEW
    useDialog.js                NEW
  lib/
    api.js                      EXTENDED (corrections + additions, see below)
  app/
    admin/
      layout.js                 EXTENDED (one nav-link change)
    layout.js                   EXTENDED (ToastProvider added)
```

`components/tenant-management/` (dialogs, tables, tenant-specific hooks — [Phase 7]'s feature folder) is **not created yet** — it has nothing to hold until the pages that use it are built, which is explicitly the next phase, not this one.

---

## Admin Layout

`app/admin/layout.js` — existing file, **one line changed**: the "Tenants" nav link now points at the new Tenant List location. Protected-route guard, loading state, and redirect-to-login are already correctly implemented and are **unchanged**.

```jsx
"use client";

import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import { useEffect, useState } from "react";
import { adminAuth } from "../../lib/auth";

export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const isLoginPage = pathname === "/admin/login";

  useEffect(() => {
    if (isLoginPage) {
      setReady(true);
      return;
    }
    const token = adminAuth.get();
    if (!token) {
      router.replace("/admin/login");
      return;
    }
    setReady(true);
  }, [isLoginPage, router]);

  if (isLoginPage) return children;
  if (!ready) return null;

  function handleLogout() {
    adminAuth.clear();
    router.push("/admin/login");
  }

  return (
    <div className="shell">
      <aside className="shell-sidebar">
        <div className="brand">
          Ledger
          <small>Platform Admin</small>
        </div>
        <nav>
          <Link href="/admin/tenants">Tenants</Link> {/* was /admin/dashboard - see note above */}
          <Link href="/admin/tenants/new">New Tenant</Link>
        </nav>
        <button className="logout" onClick={handleLogout}>
          Log out
        </button>
      </aside>
      <main className="shell-main">{children}</main>
    </div>
  );
}
```

`app/layout.js` (root layout) — one addition, `ToastProvider` wraps the app so `useToast()` works from any page, admin or tenant:

```jsx
import { Source_Serif_4, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import ToastProvider from "../components/ui/ToastProvider";

const display = Source_Serif_4({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-display-loaded" });
const body = Inter({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--font-body-loaded" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--font-mono-loaded" });

export const metadata = {
  title: "Ledger — UAE VAT Invoice & Management",
  description: "Multi-tenant UAE VAT invoicing and compliance platform.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
```

---

## API Client

`lib/api.js` — full file shown, with **two corrections** (marked) and **four additions** (marked). Every other existing method is unchanged.

```js
const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

async function request(path, { method = "GET", token, body } = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  // Platform Admin
  adminLogin: (email, password) =>
    request("/api/platform-admin/login", { method: "POST", body: { email, password } }),
  listTenants: (token) => request("/api/platform-admin/tenants", { token }),

  // CORRECTED: Phase 5's approved createTenant accepts { name, plan } only -
  // the old { trn, address, contactEmail, contactPhone, owner } shape no
  // longer matches the backend and is removed, not just left unused.
  createTenant: (token, { name, plan }) =>
    request("/api/platform-admin/tenants", { method: "POST", token, body: { name, plan } }),

  // NEW - Phase 5's GET /tenants/:id, distinct from the existing usage endpoint below.
  getTenantDetails: (token, id) => request(`/api/platform-admin/tenants/${id}`, { token }),

  updateTenantPlan: (token, id, plan) =>
    request(`/api/platform-admin/tenants/${id}/plan`, { method: "PATCH", token, body: { plan } }),
  suspendTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/suspend`, { method: "PATCH", token }),

  // CORRECTED (renamed): Phase 5 renamed PATCH .../reactivate to .../activate.
  // The old reactivateTenant name/path no longer exists on the backend.
  activateTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/activate`, { method: "PATCH", token }),

  // NEW - Phase 5.
  archiveTenant: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/archive`, { method: "PATCH", token }),

  // NEW - Phase 5.
  inviteOwner: (token, id, { ownerName, ownerEmail }) =>
    request(`/api/platform-admin/tenants/${id}/invite`, { method: "POST", token, body: { ownerName, ownerEmail } }),

  // NEW - Phase 5.
  resendInvitation: (token, id) =>
    request(`/api/platform-admin/tenants/${id}/resend-invitation`, { method: "POST", token }),

  createStaff: (token, id, payload) =>
    request(`/api/platform-admin/tenants/${id}/staff`, { method: "POST", token, body: payload }),
  getTenantUsage: (token, id) => request(`/api/platform-admin/tenants/${id}/usage`, { token }),

  // Tenant
  tenantLogin: (email, password) =>
    request("/api/tenant/login", { method: "POST", body: { email, password } }),
  listTeam: (token) => request("/api/tenant/team", { token }),
};
```

---

## Shared Components (`components/ui/`)

### `Button.js`

```jsx
export default function Button({ variant = "primary", children, ...props }) {
  return (
    <button className={`btn btn-${variant}`} {...props}>
      {children}
    </button>
  );
}
```

### `Card.js`

```jsx
export default function Card({ children, style }) {
  return (
    <div className="card" style={style}>
      {children}
    </div>
  );
}
```

### `PageHeader.js`

```jsx
export default function PageHeader({ title, description, action }) {
  return (
    <div className="page-header">
      <div>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  );
}
```

### `EmptyState.js`

```jsx
export default function EmptyState({ children }) {
  return <div className="empty-state">{children}</div>;
}
```

### `ErrorBanner.js`

```jsx
export default function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div className="error-banner" role="alert">
      {message}
    </div>
  );
}
```

### `LoadingSkeleton.js` — new visual pattern, built from existing tokens only

```jsx
export default function LoadingSkeleton({ rows = 5, columns = 4 }) {
  return (
    <table aria-busy="true" aria-label="Loading">
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r}>
            {Array.from({ length: columns }).map((_, c) => (
              <td key={c}>
                <div className="skeleton-bar" />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
```

CSS addition to `globals.css` (new rule, existing tokens only — `--radius`, `--color-line`):

```css
.skeleton-bar {
  height: 14px;
  border-radius: var(--radius);
  background: var(--color-line);
  animation: skeleton-pulse 1.2s ease-in-out infinite;
}
@keyframes skeleton-pulse {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.85; }
}
```

### `ConfirmationDialog.js` — new pattern (no prior modal exists in the codebase); accessible by construction, not retrofitted

```jsx
"use client";

import { useEffect, useRef } from "react";

export default function ConfirmationDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  variant = "primary",
  busy = false,
  onConfirm,
  onCancel,
}) {
  const dialogRef = useRef(null);
  const previouslyFocused = useRef(null);

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement;
    dialogRef.current?.focus();

    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      previouslyFocused.current?.focus(); // UX Blueprint §10: focus returns to trigger
    };
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div className="dialog-overlay" onClick={onCancel}>
      <div
        className="dialog"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
        aria-describedby="dialog-message"
        tabIndex={-1}
        ref={dialogRef}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="dialog-title">{title}</h2>
        <p id="dialog-message" className="helptext">
          {message}
        </p>
        <div className="dialog-actions">
          <button className="btn btn-outline" onClick={onCancel} disabled={busy}>
            {cancelLabel}
          </button>
          <button className={`btn btn-${variant}`} onClick={onConfirm} disabled={busy}>
            {busy ? "Working…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
```

CSS addition (existing tokens only — `--color-ink`, `--color-surface`, `--radius`):

```css
.dialog-overlay {
  position: fixed;
  inset: 0;
  background: rgba(23, 41, 59, 0.5); /* --color-ink at reduced opacity */
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  z-index: 100;
}
.dialog {
  background: var(--color-surface);
  border-radius: var(--radius);
  padding: 24px;
  width: 100%;
  max-width: 420px;
}
.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 20px;
}

/* Mobile: full-screen sheet, per UX Blueprint §9 */
@media (max-width: 640px) {
  .dialog-overlay { padding: 0; align-items: flex-end; }
  .dialog { max-width: none; border-radius: var(--radius) var(--radius) 0 0; }
}
```

### `Toast.js` + `ToastProvider.js` — new pattern, distinct from the existing persistent `.error-banner`

```jsx
// Toast.js
export default function Toast({ message, type = "success" }) {
  return (
    <div className={`toast toast-${type}`} role="status" aria-live="polite">
      {message}
    </div>
  );
}
```

```jsx
// ToastProvider.js
"use client";

import { createContext, useCallback, useState } from "react";
import Toast from "./Toast";

export const ToastContext = createContext(null);

export default function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const showToast = useCallback((message, type = "success") => {
    const id = Date.now();
    setToasts((current) => [...current, { id, message, type }]);
    setTimeout(() => {
      setToasts((current) => current.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="toast-container">
        {toasts.map((t) => (
          <Toast key={t.id} message={t.message} type={t.type} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}
```

CSS addition:

```css
.toast-container {
  position: fixed;
  bottom: 24px;
  right: 24px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 200;
}
.toast {
  background: var(--color-ink);
  color: #fff;
  padding: 10px 16px;
  border-radius: var(--radius);
  font-size: 14px;
}
.toast-error { background: var(--color-brick); }

/* Mobile: bottom-center, full-width, per UX Blueprint §9 */
@media (max-width: 640px) {
  .toast-container { left: 16px; right: 16px; bottom: 16px; align-items: stretch; }
}
```

---

## Constants

### `constants/tenantStatus.js`

Directly encodes the state machine already approved in [Tenant Management spec §4] and the badge/tooltip/action design already approved in [Frontend Spec §7] — not new decisions, a single source of truth for values three different components would otherwise each hardcode separately.

```js
export const TENANT_STATUS = {
  DRAFT: "DRAFT",
  INVITED: "INVITED",
  ACTIVE: "ACTIVE",
  SUSPENDED: "SUSPENDED",
  ARCHIVED: "ARCHIVED",
};

export const TENANT_STATUS_LABELS = {
  DRAFT: "Draft",
  INVITED: "Invited",
  ACTIVE: "Active",
  SUSPENDED: "Suspended",
  ARCHIVED: "Archived",
};

// "stamp" = official determination, "tag" = in-progress workflow state -
// the visual distinction UX Blueprint §5 established, applied here as data.
export const TENANT_STATUS_BADGE = {
  DRAFT: "tag",
  INVITED: "tag",
  ACTIVE: "stamp",
  SUSPENDED: "stamp",
  ARCHIVED: "stamp",
};

export const TENANT_STATUS_TOOLTIPS = {
  DRAFT: "Awaiting Owner invitation",
  INVITED: "Invitation sent, awaiting Owner response",
  ACTIVE: "In good standing",
  SUSPENDED: "Access temporarily blocked — reversible",
  ARCHIVED: "Permanently closed — historical data retained",
};

// Allowed forward transitions per Tenant Management spec §4's state machine.
export const TENANT_ALLOWED_TRANSITIONS = {
  DRAFT: ["INVITED"],
  INVITED: ["INVITED", "ACTIVE"], // Resend keeps it INVITED; Owner acceptance moves it to ACTIVE
  ACTIVE: ["SUSPENDED"],
  SUSPENDED: ["ACTIVE", "ARCHIVED"],
  ARCHIVED: [],
};

// Which actions are available per status - matches Frontend Spec §7 exactly.
export const TENANT_ACTIONS_BY_STATUS = {
  DRAFT: ["inviteOwner"],
  INVITED: ["resendInvitation"],
  ACTIVE: ["suspend"],
  SUSPENDED: ["activate", "archive"],
  ARCHIVED: [],
};
```

---

## Hooks

### `hooks/useApi.js` — generic async-call lifecycle, what tenant-specific hooks will be built on top of next phase

```js
"use client";

import { useState, useCallback } from "react";

export function useApi(apiFn) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const execute = useCallback(
    async (...args) => {
      setLoading(true);
      setError("");
      try {
        return await apiFn(...args);
      } catch (err) {
        setError(err.message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [apiFn]
  );

  return { execute, loading, error, setError };
}
```

### `hooks/useToast.js`

```js
"use client";

import { useContext } from "react";
import { ToastContext } from "../components/ui/ToastProvider";

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context; // { showToast(message, type) }
}
```

### `hooks/useDialog.js`

```js
"use client";

import { useState, useCallback } from "react";

export function useDialog() {
  const [isOpen, setIsOpen] = useState(false);
  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);
  return { isOpen, open, close };
}
```

No `useTenantList`/`useTenantDetails` — explicitly excluded from this phase, per the instruction; they belong to the page-building phase that consumes this foundation.

---

**STOP — awaiting approval. Not yet applied to `frontend/`.**
