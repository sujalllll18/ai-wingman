# Sprint 1 — UX Design Blueprint

- **Status:** Version 1 — final UX review before development
- **Date:** 2026-07-30
- **Covers:** [Business Profile](01-business-profile.md) and [Tenant Management](02-tenant-management.md) — both feature specs are source of truth; no business requirement is redesigned here.
- **Built on:** the existing, shipped Module 0 UI (`frontend/app`, `frontend/components`, `frontend/app/globals.css`'s "ledger" design system — paper background, ink-navy text, ledger-green primary actions, the signature rotated ink stamp for official status determinations) — extended, not replaced.
- **What this is not:** code, database schema, or API design. Every wireframe below is a structural sketch, not a visual/pixel design.

---

## Table of Contents

1. [Complete Screen Inventory](#1-complete-screen-inventory) · 2. [Navigation Map](#2-navigation-map) · 3. [Screen Flow](#3-screen-flow) · 4. [Low Fidelity Wireframes](#4-low-fidelity-wireframes) · 5. [Components](#5-components) · 6. [Forms](#6-forms) · 7. [Table Design](#7-table-design) · 8. [Dialogs](#8-dialogs) · 9. [Mobile Behaviour](#9-mobile-behaviour) · 10. [Accessibility](#10-accessibility) · 11. [UX Review](#11-ux-review) · 12. [Final Review](#12-final-review)

---

## 1. Complete Screen Inventory

Grouped by app/context, and by whether it's a full screen, a dialog, or a state of an existing screen — collapsing near-duplicates deliberately, not padding the count.

### Public (unauthenticated)

| Screen | Status |
|---|---|
| Landing / role choice | Existing, unchanged |
| Platform Admin Login | Existing, unchanged |
| Tenant Login | Existing, unchanged |
| **Accept Invitation** | **New** — one screen, three states: Form, Success, Invalid/Expired (§4) |

### Platform Admin App

| Screen | Status |
|---|---|
| **Tenant List** | Redesigned — this *is* the Platform Dashboard for Sprint 1; no separate dashboard screen exists yet, since there is no other content (usage analytics, etc.) to justify a distinct landing page beyond the list itself. Stated explicitly so it doesn't read as an oversight. |
| **Create Tenant** | Redesigned — narrower field set per [Tenant Management spec §11] |
| **Tenant Details** | Redesigned — adds lifecycle history/timeline and the new lifecycle actions |
| **Edit Tenant** | New — designed as an inline/modal edit, not a full page (§3 explains why) |

### Tenant App

| Screen | Status |
|---|---|
| **Tenant Dashboard** | New, deliberately minimal (§11 explains why it isn't more) |
| **Business Profile** | New — the largest single screen in this sprint |
| Team | Existing, unchanged |

### Dialogs (not full screens — designed once as a pattern, §5/§8)

Suspend Confirmation · Activate (Reactivate) Confirmation · Archive Confirmation · Invite Owner Confirmation · Resend Invitation Confirmation · Deactivate Business Profile Confirmation · Unsaved Changes

---

## 2. Navigation Map

```mermaid
graph TD
    Landing["Landing"] --> AdminLogin["Platform Admin Login"]
    Landing --> TenantLogin["Tenant Login"]

    AdminLogin --> TenantList["Tenant List (= Dashboard)"]
    TenantList --> CreateTenant["Create Tenant"]
    TenantList --> TenantDetails["Tenant Details"]
    CreateTenant --> TenantDetails
    TenantDetails --> EditTenant["Edit Tenant (modal)"]
    TenantDetails --> InviteDialog["Invite Owner (dialog)"]
    TenantDetails --> ResendDialog["Resend Invitation (dialog)"]
    TenantDetails --> SuspendDialog["Suspend (dialog)"]
    TenantDetails --> ActivateDialog["Activate (dialog)"]
    TenantDetails --> ArchiveDialog["Archive (dialog)"]

    InviteDialog -.email sent.-> AcceptInvite["Accept Invitation (public)"]
    AcceptInvite -->|success| TenantLogin
    AcceptInvite -->|expired/invalid| AcceptInvite

    TenantLogin --> TenantDashboard["Tenant Dashboard"]
    TenantDashboard --> BusinessProfile["Business Profile"]
    TenantDashboard --> Team["Team"]
    BusinessProfile -.incomplete.-> TenantDashboard
```

---

## 3. Screen Flow

**Platform Admin onboards a Tenant**: Admin Login → Tenant List → "+ Create Tenant" → Create Tenant form (Company Name, Owner Name/Email, Plan) → on save, lands on the new Tenant's Details screen, status `Draft` → Admin clicks "Invite Owner" → confirmation dialog → on confirm, status becomes `Invited`, an email is sent, Admin remains on Tenant Details with the new status visible.

**Owner accepts**: Owner opens the emailed link → Accept Invitation screen (Form state) → sets a password → on success, brief Success state, then automatic redirect to Tenant Login → Owner logs in → lands on Tenant Dashboard.

**Owner completes Business Profile**: Tenant Dashboard shows a prominent "Complete your Business Profile" prompt with the live completion percentage → Owner navigates to Business Profile → fills Mandatory fields (Identity/Compliance/Contact groups first, since those gate activation) → Optional fields (Branding, Classification) can be skipped → the moment every Mandatory field is populated, status silently becomes `Active` — no button, no extra step (per [Business Profile spec §4 Rule 6]) → Owner sees a confirmation banner, not a redirect.

**Platform Admin manages an existing Tenant**: Tenant List → click a row → Tenant Details → Suspend/Activate/Archive via their respective dialogs, or "Edit" for Company Name/Plan via the modal → every action returns the Admin to Tenant Details with an updated status and a toast confirmation (§5).

**Edit Tenant is a modal, not a full page** — deliberate: it edits exactly two fields (Company Name, Plan, per [Tenant Management spec §11]'s explicit descoping of everything else). A full-page navigation for a two-field edit would be a wasted round trip; a modal keeps the Admin's place in the Tenant Details context.

---

## 4. Low Fidelity Wireframes

### Landing

```
+----------------------------------------------------+
|                       Ledger                        |
|      One place to invoice, log purchases, and       |
|          know your VAT position.                    |
|                                                       |
|     [ Platform Admin ]      [ Sign in to your ]      |
|                              [   business     ]      |
+----------------------------------------------------+
```

### Platform Admin Login / Tenant Login (same structure, existing — shown once)

```
+----------------------------------------------------+
| Ledger                          PLATFORM ADMIN       |
+----------------------------------------------------+
|                                                       |
|   Sign in                                            |
|   Email    [_________________________]              |
|   Password [_________________________]              |
|                                                       |
|              [        Sign in        ]               |
+----------------------------------------------------+
```

### Accept Invitation — Form state

```
+----------------------------------------------------+
| Ledger                       SET YOUR PASSWORD       |
+----------------------------------------------------+
| You've been invited to manage: Al Noor Trading LLC   |
|                                                       |
|  New Password         [_________________________]    |
|  Confirm Password     [_________________________]    |
|                                                       |
|              [   Set Password & Continue   ]          |
+----------------------------------------------------+
```

### Accept Invitation — Success / Invalid states

```
  SUCCESS                          INVALID / EXPIRED
 +---------------------------+    +---------------------------+
 | Password set.              |    | This invitation link is   |
 | Redirecting to sign in...  |    | no longer valid.           |
 |                             |    | Contact your Platform     |
 |                             |    | Administrator for a new    |
 |                             |    | invitation.                 |
 +---------------------------+    +---------------------------+
```

### Tenant List (= Platform Dashboard)

```
+----------------------------------------------------+
| Ledger  Platform Admin        [Tenants] [+ New]      |
+----------------------------------------------------+
| Search [______________]  Status [All v]  Plan [All v]|
+----------------------------------------------------+
| Company        | Plan     | Status      | Actions    |
|----------------|----------|-------------|------------|
| Al Noor Trading| PREMIUM  | (o) Active  | Manage >   |
| Zayed Fitout Co| TRIAL    | [Draft]     | Manage >   |
| Reef Marine LLC| STANDARD | [Invited]   | Manage >   |
| Old Vendor LLC | STANDARD | (Archived)  | Manage >   |
+----------------------------------------------------+
|                 < 1  2  3 >                          |
+----------------------------------------------------+
```

### Create Tenant

```
+----------------------------------------------------+
| < Back to Tenants        New Tenant                  |
+----------------------------------------------------+
|  Company Name *   [_________________________]        |
|  Owner Name *     [_________________________]        |
|  Owner Email *    [_________________________]        |
|  Subscription Plan* [ TRIAL v ]                       |
|                                                       |
|              [   Save as Draft   ]                    |
+----------------------------------------------------+
```

### Tenant Details

```
+----------------------------------------------------+
| < Back to Tenants                                     |
+----------------------------------------------------+
|  Al Noor Trading LLC                    [ Active ]    |
|  Plan: PREMIUM              [ Edit ]                  |
+----------------------------------------------------+
| Lifecycle History                                     |
|  Draft -> Invited -> Active                            |
|  Created 12 Jan · Invited 12 Jan · Activated 14 Jan    |
+----------------------------------------------------+
| Actions:  [ Suspend ]  [ Archive ]  [ Resend Invite ]  |
|           (Resend disabled once Active)                |
+----------------------------------------------------+
```

### Edit Tenant (modal, overlaying Tenant Details)

```
        +----------------------------------+
        | Edit Tenant                  [x] |
        +----------------------------------+
        | Company Name [________________]  |
        | Plan         [ PREMIUM v ]        |
        |                                    |
        |         [Cancel]   [Save]          |
        +----------------------------------+
```

### Tenant Dashboard

```
+----------------------------------------------------+
| Ledger   Al Noor Trading LLC     [Team] [Log out]    |
+----------------------------------------------------+
|  Welcome, Fatima                                      |
|                                                       |
|  Business Profile: 60% complete                       |
|  [########------]                                     |
|  [ Complete your Business Profile > ]                 |
+----------------------------------------------------+
```

### Business Profile

```
+----------------------------------------------------+
| Ledger   Al Noor Trading LLC     [Team] [Log out]    |
+----------------------------------------------------+
| Business Profile                    60% complete      |
+----------------------------------------------------+
| Identity & Compliance                                 |
|  Business Name *  [___________________]               |
|  Legal Name *     [___________________]               |
|  Trade License #* [___________________]               |
|  VAT Registration [ Not Registered v ]                 |
|   (TRN + VAT Date fields appear only if Registered)    |
+----------------------------------------------------+
| Localization (locked)                                  |
|  Country  United Arab Emirates  (fixed)                |
|  Currency AED  (fixed)                                  |
+----------------------------------------------------+
| Contact & Address                                       |
|  Email *   [___________________]                        |
|  Phone *   [___________________]                        |
|  Address Line 1 * [___________________]                 |
|  Emirate *  [ Dubai v ]                                  |
+----------------------------------------------------+
| Branding (optional)                                      |
|  Logo    [ Upload ]                                       |
|  Footer  [___________________________________]            |
+----------------------------------------------------+
|                                    [ Save ]                |
+----------------------------------------------------+
```

---

## 5. Components

| Component | Purpose | New or existing |
|---|---|---|
| **Data Table** | Tenant List rows | Existing pattern, extended with sortable headers |
| **Search** | Filter Tenant List by name | New |
| **Filters** | Status/Plan dropdowns on Tenant List | New |
| **Status Badge — two treatments, deliberately** | See below | Extends the existing design system rather than replacing it |
| **Confirmation Modal** | One reusable component for all six dialogs in §8 | New, generalized |
| **Sidebar** | Section nav for both apps | Existing, unchanged structurally |
| **Header** | App-level top bar | Existing |
| **Breadcrumb** | *Recommended, not required* — see §11 | New, optional |
| **Empty State** | Tenant List with zero Tenants; Business Profile before any field is filled | New |
| **Toast** | Transient success confirmation after an action (Invite sent, Tenant suspended, etc.) | **New pattern** — Module 0 today only has a persistent inline error banner, no success feedback pattern at all; a lifecycle-heavy feature like Tenant Management needs one |

**Status Badge — why two treatments**: the existing design system already made a deliberate distinction — a rotated ink *stamp* for an "official determination" (today: Active/Suspended), a flat *tag* for a "product label" (Plan tier). This sprint's richer lifecycle should extend that same logic, not flatten it into one generic 5-state badge:

| State | Treatment | Why |
|---|---|---|
| `Active`, `Suspended`, `Archived` | **Stamp** (existing pattern, Archived gets a third stamp color) | Each is an official determination about the Tenant's standing — exactly what the stamp was designed to communicate |
| `Draft`, `Invited` | **Tag** (existing pattern, new colors) | Both are in-progress workflow states, not determinations — using the lighter tag avoids overstating their weight |

---

## 6. Forms

### Create Tenant

| Field | Required? | Validation | Default | Error State | Success State |
|---|---|---|---|---|---|
| Company Name | Required | 1–200 chars | — | Inline, below field | — |
| Owner Name | Required | 1–100 chars | — | Inline | — |
| Owner Email | Required | Valid email, must not already exist | — | Inline, specific "already in use" message ([Tenant Management spec §8]) | — |
| Subscription Plan | Required | One of TRIAL/STANDARD/PREMIUM | TRIAL | Inline | — |
| *(form-level)* | — | — | — | Top-of-form summary banner if multiple fields fail | Redirect to Tenant Details, status `Draft`, toast "Tenant created" |

### Edit Tenant (modal)

| Field | Required? | Validation | Default | Error State | Success State |
|---|---|---|---|---|---|
| Company Name | Required | Same as above | Current value | Inline within modal | — |
| Plan | Required | Same as above; blocked if downgrade exceeds user limit ([existing Module 0 rule]) | Current value | Inline, specific downgrade-blocked message | Modal closes, Tenant Details refreshes, toast "Tenant updated" |

### Accept Invitation (Set Password)

| Field | Required? | Validation | Default | Error State | Success State |
|---|---|---|---|---|---|
| New Password | Required | Platform password policy ([PAS §5], inherited not redefined here) | — | Inline | — |
| Confirm Password | Required | Must match New Password | — | Inline, "passwords don't match" | Success state (§4), then redirect |

### Business Profile

| Field group | Required? | Notes |
|---|---|---|
| Business Name, Legal Name, Trade License #, VAT Registration Status | Required | Gate activation ([Business Profile spec §3]) |
| TRN, VAT Registration Date | **Conditionally required** | Only shown/required if VAT Registration Status ≠ Not Registered — the form must show/hide these fields reactively, not just validate them |
| Business Email, Phone, Address Line 1, Emirate | Required | Gate activation |
| Business Type | Required | Controlled list |
| Everything else (Logo, Footer, Website, Industry, Language, Financial Year, Address Line 2/PO Box, Primary Contact) | Optional | Does not block activation ([Business Profile spec §4 Rule 6]/[§11]) |
| *(form-level)* | — | No single "Submit" gate for the whole form — see §11's autosave recommendation. Error state: inline per field, plus the VAT-status/TRN consistency check ([spec §5]) surfaced as a combined-field error, not two independent ones. Success state: no redirect — an inline "Saved" confirmation and the completion percentage updating live. |

---

## 7. Table Design

### Tenant List

| Aspect | Design |
|---|---|
| **Columns** | Company Name, Plan, Status, Created Date, Actions |
| **Sorting** | By Company Name or Created Date; default sort is Created Date descending (newest first) |
| **Filtering** | Status (All / Draft / Invited / Active / Suspended / Archived), Plan (All / Trial / Standard / Premium) |
| **Pagination** | Simple offset-based (page numbers) — sufficient at MVP Tenant volumes; cursor-based pagination is a [DDS §14]/[SDD §18] **[Design Now, Build Later]** item, not a Sprint 1 UX concern |
| **Bulk Actions** | **None for MVP** — deliberately descoped; at expected Sprint 1–era Tenant counts, one-at-a-time actions are sufficient, and bulk suspend/archive carries real risk of a costly mistake that isn't worth the convenience yet. Flagged as Future Enhancement, not an oversight. |
| **Empty State** | "No Tenants yet — onboard your first business to get started," with the Create Tenant CTA inline (already the existing Module 0 pattern, reaffirmed) |

---

## 8. Dialogs

All six built on the one Confirmation Modal component (§5) — differing only in copy and consequence severity:

| Dialog | Trigger | Consequence shown | Primary action | Secondary |
|---|---|---|---|---|
| **Invite Owner** | Tenant Details, `Draft` state | "An invitation email will be sent to [Owner Email]." | Send Invite | Cancel |
| **Resend Invitation** | Tenant Details, `Invited` state | "The previous invitation link will stop working immediately." | Resend | Cancel |
| **Suspend** | Tenant Details, `Active` state | "This Tenant's Owner and Staff will be unable to log in until reactivated. This is reversible." | Suspend | Cancel |
| **Activate (Reactivate)** | Tenant Details, `Suspended` state | "Access will be restored immediately." | Activate | Cancel |
| **Archive** | Tenant Details, `Suspended` state only — button is not shown/enabled from `Active` ([Tenant Management spec §4 Rule 4]) | "This cannot be undone. The Tenant's Owner and Staff will never be able to log in again. All historical records are retained." | Archive | Cancel |
| **Deactivate Business Profile** | Business Profile screen, Owner-only | "New invoices and documents cannot be issued until reactivated. Your historical records remain visible." | Deactivate | Cancel |
| **Unsaved Changes** | Navigating away from Edit Tenant or Business Profile with unsaved edits | "You have unsaved changes. Leave anyway?" | Leave | Stay |

**Deliberate severity gradient in the copy**: Suspend and Deactivate are worded as reversible; Archive is the only dialog in this set worded as permanent — the copy itself carries the distinction [§11] flags as a real risk to get right, not just the underlying state machine.

---

## 9. Mobile Behaviour

| Element | Desktop | Tablet / Mobile |
|---|---|---|
| Sidebar (both apps) | Fixed 220px, always visible | Collapses to a hamburger-triggered drawer — **this is a real change from Module 0's current fixed sidebar**, which does not yet satisfy Mobile First ([MPS A21]); this document is where that reassessment lands concretely for Sprint 1 |
| Tenant List table | Full table, all columns | Stacks into cards — Company Name as the card title, Plan/Status as labeled rows, Actions as a menu, not inline buttons |
| Forms (Create Tenant, Business Profile) | Multi-column where grouped | Single column throughout — no field ever sits beside another on a narrow viewport |
| Dialogs | Centered modal | Full-screen sheet — a small centered modal is hard to use accurately on a touch target at phone width |
| Business Profile's conditional TRN/VAT-Date fields | Appear inline within the Identity group | Same behavior, single column — no special mobile-only layout needed since the show/hide logic is already viewport-independent |
| Toast notifications | Bottom-right, stacked | Bottom-center, full-width, one at a time |

---

## 10. Accessibility

| Concern | Approach |
|---|---|
| **Keyboard Navigation** | Every action reachable via Tab/Shift+Tab in a logical order matching visual layout; dialogs trap focus within themselves while open. |
| **Focus** | Visible focus rings on every interactive element (already implied by the existing design system's `focus-visible` outline pattern); focus returns to the triggering element when a dialog closes, never left stranded. |
| **ARIA** | Icon-only controls (e.g., a table row's "Manage" action if ever iconified) carry an accessible label; the Toast component announces via a live region so a screen reader user isn't only informed by a visual pop-in; the conditional TRN/VAT-Date fields' appearance/disappearance is announced, not silent. |
| **Color Contrast** | The existing "ledger" palette (dark ink-navy text on paper) is contrast-favorable by construction; the two new Stamp colors (Archived) and Tag colors (Draft, Invited) must be checked against the same WCAG AA bar the existing palette was presumably designed to — **recommended as an explicit pre-launch check**, not assumed passing by inheritance. |
| **Validation Messages** | Associated with their field programmatically (not just visually adjacent), so the relationship survives for a screen reader user — applies to every form in §6, most importantly Business Profile's combined VAT-status/TRN check, which is easy to get wrong as an accessibility pattern precisely because it spans two fields. |

---

## 11. UX Review

**Missing screens identified**: no **Forgot Password** flow exists for either Platform Admin or Tenant Owner/Staff in either feature spec. This is a real gap, not a stylistic one — without it, a locked-out user has no self-service recovery path, which sits oddly next to how much design effort just went into the Owner *not* needing the Platform Admin to hand them a password. **Recommended for MVP**, not required to block Sprint 1's demo, but flagged clearly so it isn't forgotten past it.

**Missing actions**: no indicator on Tenant List for an invitation approaching its 7-day expiry — a Platform Admin currently has no way to notice a stalled `Invited` Tenant without opening each one. **Recommended**, not required.

**Navigation gaps**: none structural — the map in §2 has no dead end. The one soft gap: Tenant Dashboard's usefulness is genuinely limited once Business Profile is complete, since no other module exists yet to link to. **Not a gap to solve now** — building placeholder dashboard widgets for Modules 2/3 before they exist would be exactly the kind of ahead-of-demand overbuilding this whole document set has consistently argued against.

**Confusing UX, found and corrected in this document**: the word **"Deactivate" is used at two different levels by two different actors** — Platform Admin has no "Deactivate" action (they Suspend or Archive a Tenant); "Deactivate" belongs exclusively to the Owner's own Business Profile action. This document uses the terms deliberately distinctly throughout (§8) specifically to prevent this collision from reaching the UI — worth calling out explicitly since both underlying feature specs used careful, distinct status vocabulary, and it would be easy for UI copy to blur that discipline back together without a document like this one checking for it.

**Edge cases**: a Tenant List row for a `Draft` Tenant has no "Suspend"/"Archive" actions available at all — only "Invite Owner" and standard Edit/View — the Actions menu must be state-aware, not a static set of buttons shown regardless of lifecycle state.

---

## 12. Final Review

**Is Sprint 1 completely designed?** Yes, for the two approved feature specs, with one explicitly acknowledged gap (Forgot Password) that does not block development but should be scheduled — see [§11].

**Can development begin?** Yes — every screen in [§1] has a wireframe, every form has validation/error/success behavior defined, every dialog has its copy and consequence severity specified, and mobile/accessibility behavior is defined per element rather than left to be improvised during implementation.

**What UX improvements would QuickBooks, Xero, or Zoho Books include?** Three worth adopting even at MVP scale: **inline, live validation** rather than submit-then-discover-errors (especially valuable on Business Profile's longer form); **autosave** on a settings-style page like Business Profile, rather than a single all-or-nothing Save button — a Owner filling in fields across an interrupted session shouldn't lose progress the way [Business Profile spec §4 Rule 1]'s Draft-state precedent already protects Platform Admin's Create Tenant flow from; and a **persistent, dismissible setup checklist** (not just a percentage bar) on the Tenant Dashboard, giving the Owner a concrete next action rather than a number alone. The first two are recommended as real Sprint 1 additions to this blueprint, not deferred — they're cheap and directly address a real UX risk (lost work) already treated seriously elsewhere in this design. The checklist is a reasonable **Future Enhancement**, since it has more payoff once Modules 2–3 give it more than one item to check off.
