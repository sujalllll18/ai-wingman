# Tenant Management — Implementation Phase 6: Authentication & Authorization

- **Status:** Proposed — **not yet applied to `uae-vat-saas/src/`**; awaiting approval
- **Date:** 2026-07-30
- **Implements:** [Phase 5 API Layer](08-tenant-management-api-layer.md) (Approved) — this phase formalizes and extends its auth handling, it does not change any existing route, request, or response.
- **Scope resolution (read before the deliverables):** five items requested above conflict with decisions already made in approved documents. Each is called out at the point it matters, not buried — see the message accompanying this document for the full list. In short: refresh tokens, server-side logout, and full data-driven RBAC (Role/Permission tables) are documented as *readiness*, not built; the RBAC surface covers the three roles that actually exist (Platform Admin, Owner, Staff), with the three requested-but-nonexistent roles (Admin, Accountant, Viewer) shown honestly as not implemented rather than faked.

---

## 1. Authentication Flow

### Platform Admin Login (existing, unchanged — documented for completeness)

```
Platform Admin -> Frontend: email, password
Frontend -> API: POST /api/platform-admin/login
API -> Authentication: verify(email, password)
Authentication -> Database: find PlatformAdmin by email
Database --> Authentication: record, or none
Authentication -> Authentication: bcrypt.compare(password, passwordHash)
alt invalid
    Authentication --> API: reject
    API --> Frontend: 401 Invalid credentials
else valid
    Authentication -> Authentication: sign JWT (platform-admin secret, aud="platform-admin")
    Authentication --> API: token
    API --> Frontend: 200 { token, admin }
end
```

### Owner Invitation Acceptance (Phase 4/5, unchanged — reconciled here as an auth event)

```
Owner -> Frontend: opens invitation link (raw token in URL)
Owner -> Frontend: sets password
Frontend -> API: POST /api/invitations/accept { token, password }
API -> InvitationService: acceptInvitation(token, password)
InvitationService -> InvitationService: hash token (SHA-256), look up Invitation
alt invalid/expired/already used
    InvitationService --> API: reject (generic message, Phase 4 §1)
    API --> Frontend: 400
else valid
    InvitationService -> Database: create User (role=OWNER), mark Invitation accepted, Tenant -> ACTIVE
    InvitationService --> API: user, tenant
    API --> Frontend: 200 { user, tenant }
    Note: no token issued here - Owner must now log in separately (below)
end
```

**Deliberate design point, worth stating explicitly**: accepting an invitation does **not** log the Owner in automatically — it only creates their credential. They then go through the same Tenant User Login below. This avoids a subtle auth-bypass shape where "possessing a valid invitation token" would otherwise double as "being logged in," which are different security properties and shouldn't be conflated.

### Tenant User Login (existing, unchanged — documented for completeness)

```
Owner or Staff -> Frontend: email, password
Frontend -> API: POST /api/tenant/login
API -> Authentication: verify(email, password)
Authentication -> Database: find User by email
Authentication -> Database: find Tenant by user.tenantId
alt Tenant is SUSPENDED
    Authentication --> API: reject
    API --> Frontend: 403 Tenant account is suspended
else invalid credentials
    API --> Frontend: 401 Invalid credentials
else valid
    Authentication -> Authentication: sign JWT (tenant secret, aud="tenant-user", tenantId, role)
    Authentication --> API: token
    API --> Frontend: 200 { token, user, tenant }
end
```

**A relevant Tenant Management consequence, not previously stated this precisely**: a Tenant in `DRAFT` or `INVITED` status has no `User` row at all yet (Phase 4), so login attempts against it fail with the existing generic 401 — not a special "not yet active" message, since revealing that an email/Tenant exists in an unauthenticated pre-state would itself be a small information leak. `ARCHIVED` should be added to the existing Suspended-style rejection in [§4]'s middleware section, distinctly worded per the [UX Blueprint §9]'s "closed, not paused" messaging requirement.

### Logout — client-side only, stated honestly

No server-side logout endpoint exists, and this phase does not add one. The platform's JWTs are stateless with no session store or revocation list ([ADR §5]) — there is nothing on the server to invalidate. "Logout" today is entirely the frontend clearing its stored token (`lib/auth.js`'s existing `clear()` functions). A real server-side logout (making a specific token stop working before its natural expiry) requires the same revocation mechanism [§2] documents as not-yet-built — building a logout endpoint without it would just be a button that does nothing meaningful server-side, which is worse than not having one.

### Refresh Token — not implemented, readiness only

Not built, per the scope resolution above. If/when [ADR §5]'s revocation work is picked up, the shape most consistent with this platform's existing patterns would be: a short-lived access token (~15 min) plus a longer-lived refresh token, the refresh token stored and rotated similarly to how `Invitation.tokenHash` is already handled (hashed at rest, raw value never persisted) — reusing an established pattern rather than inventing a new one. **Not decided, not scheduled — a readiness note, not a commitment.**

### Authentication Lifecycle (as it actually exists today)

| Stage | What happens |
|---|---|
| Issuance | On successful login (Platform Admin or Tenant User) |
| Usage | Bearer token on every subsequent request, verified per-request by the relevant Guard-equivalent middleware ([§5]) |
| Expiry | 8 hours ([ADR §5]), fixed — no silent renewal |
| Re-authentication | Full login again — there is no refresh flow to fall back to |
| Early invalidation | **Does not exist** — a stolen or leaked token remains valid until its 8-hour expiry regardless of any action taken (password change, Suspend, Archive) except where the *tenant-level* check already re-verifies status per request ([§4]) |

---

## 2. JWT Strategy

| Claim | Present in | Purpose | Why it exists |
|---|---|---|---|
| `sub` | Both | Subject — the `PlatformAdmin.id` or `User.id` | Identifies *who*, independent of any other claim |
| `email` | Both | The account's email | Avoids an extra database lookup just to display who's logged in |
| `aud` | Both — `"platform-admin"` or `"tenant-user"` | Audience | **The single most important claim in this system.** Verification checks the audience explicitly, so a Platform Admin token is cryptographically rejected on any Tenant route and vice versa — not just logically filtered by code that could have a bug, but structurally impossible to misuse ([ADR §5], unchanged, restated here because it's the claim this whole section exists to explain). |
| `tenantId` | Tenant User only | Which Tenant this token is scoped to | The **only** source of tenant context for every downstream query ([ADR §6]/[§7]) — never accepted from a request body or param, always this claim |
| `role` | Tenant User only | `OWNER` or `STAFF` | Backs the interim role-check in [§4] — not yet the full data-driven permission model PAS §14 ultimately targets, see the scope note above |
| `iat` | Both | Issued-at timestamp | Standard JWT claim, supports the fixed-expiry model |
| `exp` | Both | Expiry timestamp | Enforces the 8-hour lifetime |

**Access Token**: the only token type this platform issues. HS256 signing, one secret per identity space (`PLATFORM_ADMIN_JWT_SECRET`, `TENANT_JWT_SECRET`) — unchanged from [ADR §5].

**Refresh Token**: not implemented — see [§1].

**Token signing / verification**: unchanged from the existing `utils/jwt.js` — `jwt.sign(payload, secret, { expiresIn: "8h" })` per identity space; `jwt.verify(token, secret, { audience })`, which is what makes the `aud` claim's protection real rather than advisory (a token signed with the wrong secret, or missing the expected audience, fails verification outright, before any application code runs).

---

## 3. Password Security

**bcrypt hashing**: unchanged — cost factor 10, applied to every stored credential (`PlatformAdmin`, `User`, and now the Owner's password at Invitation acceptance, [Phase 4 §1]). bcrypt is the right tool here specifically because it's adaptive-cost and self-salting — the correct, different choice from the SHA-256 used for invitation tokens ([Phase 4 §1]), since passwords are low-entropy secrets needing deliberately slow verification, while tokens are high-entropy secrets that don't.

**Password verification**: `bcrypt.compare(input, storedHash)` — constant-time by design, resistant to timing attacks *on the comparison itself*. See [§6] for a related timing issue this phase found but does not fix unilaterally.

**Password policy** — genuinely strengthened in this phase, since it's pure application logic, not a schema or business-rule change:

```js
// utils/passwordPolicy.js
const MIN_LENGTH = 12; // NIST 800-63B favors length over forced complexity rules

function validatePassword(password, { email, name } = {}) {
  const errors = [];
  if (!password || password.length < MIN_LENGTH) {
    errors.push(`Password must be at least ${MIN_LENGTH} characters`);
  }
  if (email && password.toLowerCase().includes(email.split("@")[0].toLowerCase())) {
    errors.push("Password must not contain your email address");
  }
  if (name && password.toLowerCase().includes(name.toLowerCase())) {
    errors.push("Password must not contain your name");
  }
  return errors;
}

module.exports = { validatePassword, MIN_LENGTH };
```

This **raises** the floor Phase 4's `acceptInvitation` set (8 characters) to 12, and adds two basic context checks — a real strengthening within this phase's actual scope, not a redesign. Full policy maturity (breach-list checking against known-compromised passwords, e.g. a haveibeenpwned-style check) remains [PAS §5]'s longer-term, not-yet-built item.

**Password reset readiness** (design sketch, not implementation): the natural pattern is a `PasswordResetToken` mirroring `Invitation`'s already-proven shape — a hashed, single-use, time-limited token, generated and emailed the same way, resolved through the same `notificationService.send(...)` interface. Reusing an established pattern rather than inventing a new one when this is eventually built. **Not implemented here.**

**Security considerations**: see [§6] for the timing-related finding and the bcrypt-cost-factor note.

---

## 4. Authorization (RBAC)

**The roles that actually exist**: Platform Admin (its own identity space), Tenant Owner (`role: OWNER`), Tenant Staff (`role: STAFF`) — per [PAS §14], unchanged. "Admin," "Accountant," and "Viewer" are not implemented roles anywhere in this system; they appear in the table below only because they were named in the request, marked honestly.

### Permission mapping — every Tenant Management API

| Endpoint | Platform Admin | Owner | Staff | "Admin" | "Accountant" | "Viewer" | Public |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| `GET /tenants` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `POST /tenants` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `GET /tenants/:id` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `PATCH /tenants/:id/suspend` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `PATCH /tenants/:id/activate` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `PATCH /tenants/:id/archive` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `POST /tenants/:id/invite` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `POST /tenants/:id/resend-invitation` | ✅ | ❌ | ❌ | N/A¹ | N/A¹ | N/A¹ | ❌ |
| `POST /invitations/accept` | ❌ | ✅ (token-based, unauthenticated — the invited person specifically) | — | — | — | — | ✅ (token is the credential) |

¹ These are not implemented roles — not "denied," genuinely not present in the system's identity model at all. Included per the request's format, not implied to exist.

**Why every Tenant Management endpoint is Platform-Admin-only, with no Owner/Staff row that's ever ✅**: this matches [Tenant Management spec §7] exactly — "Tenant Owner and Staff have no operational role in this feature beyond the Owner's one-time acceptance step." The empty-looking columns are correct, not incomplete.

**On the gap between this and PAS §14's target**: today's enforcement is identity-space authentication (*is this caller a Platform Admin at all*), not a granular permission check (*can this specific Platform Admin perform this specific action*) — because there is currently exactly one Platform Admin account and no Role/Permission data model to check against ([DDS §22 Decision] area, unbuilt). This is the correct interim shape for the current reality, not a shortcut around PAS §14 — building the full data-driven model now would mean designing new tables, which this phase's constraints explicitly rule out.

---

## 5. Middleware

**Authentication middleware** (existing, unchanged — `middleware/auth.js`): `requirePlatformAdmin` and `requireTenantUser` verify the bearer token against the correct secret/audience and attach the verified identity to the request. Every Tenant Management route in [Phase 5] uses `requirePlatformAdmin`; `POST /invitations/accept` uses neither, by design.

**Authorization middleware**: for this feature specifically, authentication *is* authorization — there is no additional permission check layered on top of "is this a valid Platform Admin token," since every Tenant Management action requires exactly that and nothing finer-grained exists yet ([§4]). The existing `requireOwnerRole` middleware (built, currently unused anywhere) demonstrates the pattern a future finer-grained check would follow, but Tenant Management doesn't need it.

**Current User extraction**: `req.platformAdmin = { id, email }` / `req.tenantUser = { id, role, email }`, populated by the middleware above — unchanged, already the existing pattern every controller in [Phase 5] relies on.

**Error handling — 401 vs. 403, verified as already correctly distinct in the existing code**:

| Code | Meaning | When |
|---|---|---|
| **401 Unauthorized** | Not authenticated at all, or the token itself is invalid/expired/wrong-audience | Missing token, malformed token, expired token, a Platform Admin token presented on a Tenant route (or vice versa — rejected at signature/audience verification, never reaches application logic) |
| **403 Forbidden** | Authenticated, but not permitted to do this specific thing | A Suspended Tenant's user attempting any action (existing); the pattern `requireOwnerRole` already demonstrates for a valid-but-wrong-role Tenant User — not currently triggered by any Tenant Management endpoint, since none of them are reachable by a Tenant User at all |

**Response formats** (matching the existing `ApiError` → centralized-handler shape, unchanged):

```json
// 401
{ "error": "Invalid or expired platform admin token" }

// 403
{ "error": "This Tenant account is suspended" }
```

---

## 6. Security Review

| Area | Finding |
|---|---|
| **JWT security** | The dual-secret/audience model is the platform's strongest existing control — verified structurally sound, unchanged. No revocation mechanism exists ([§1]/[§2]) — a real, already-known, still-open gap, not new to this review. |
| **Token replay** | A stolen valid token is fully usable by anyone until its 8-hour expiry — no mitigation exists beyond that expiry window. Directly tied to the revocation gap above, not a separate issue. |
| **Invitation abuse** | Token brute-forcing is infeasible (256-bit random value, [Phase 4 §1]). **No rate limiting exists on `POST /tenants/:id/invite` or `/resend-invitation`** — a Platform Admin account (if compromised) or a bug in a future integration could spam invitation emails with no throttle. Flagged as a gap for a later sprint, consistent with [ADR §5]'s already-flagged missing rate limiting generally. |
| **Session handling** | Fully stateless — no concurrent-session limits, no "log out everywhere" capability. Matches [PAS §10]'s already-documented, not-yet-built scope; not a new finding. |
| **Password storage** | bcrypt cost 10 is still broadly accepted, but current OWASP/NIST guidance increasingly favors either a higher bcrypt work factor or Argon2id for new systems. Not urgent, worth a deliberate revisit before a real production launch rather than left as an unexamined default indefinitely. |
| **Brute-force protection** | **None exists on either login endpoint today.** This is the single most concrete, actionable gap this specific review surfaces — [ADR §5] already named it as a standing gap; restated here with emphasis because authentication is this phase's direct subject, not a tangential concern. |
| **A new finding, not previously surfaced**: timing side-channel in `tenantAuth.controller.js`'s existing login | The current code returns immediately with 401 when the email doesn't exist, **without** calling `bcrypt.compare` — meaning a request for a nonexistent email responds measurably faster than one for a real email with a wrong password (which includes bcrypt's ~100ms comparison). This lets an attacker distinguish "this email exists" from "it doesn't" purely from response timing, without ever seeing an error message that says so. **Not fixed here** — flagged for a later sprint, consistent with this document's discipline of surfacing pre-existing gaps found while working nearby rather than silently patching them mid-phase. |
| **OWASP mapping** | **A01:2021 Broken Access Control** — well handled: tenant isolation is structural, not just checked ([ADR §6]/[§7]), verified again in this review. **A02:2021 Cryptographic Failures** — bcrypt is adequate; see the cost-factor note above. **A07:2021 Identification and Authentication Failures** — the weakest area found: no brute-force protection, no revocation, the timing side-channel above. This is where near-term hardening effort belongs. |

### Consolidated gap list for later sprints

1. Rate limiting on `/login` (both identity spaces) and `/invite`/`/resend-invitation`.
2. Token revocation / refresh mechanism ([§1]/[§2]).
3. MFA, Platform Admin first ([PAS §10]).
4. The timing side-channel in Tenant User login.
5. Full data-driven RBAC (Role/Permission data model) — its own dedicated design phase, not an add-on to this one.
6. Password reset flow ([§3]).
7. bcrypt cost factor / Argon2id evaluation before production launch.
8. Concurrent-session limits, if ever needed.

---

**STOP — awaiting approval. Not yet applied to `uae-vat-saas/src/`.**
