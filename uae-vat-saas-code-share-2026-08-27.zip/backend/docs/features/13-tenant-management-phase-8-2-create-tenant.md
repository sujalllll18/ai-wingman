# Tenant Management — Phase 8.2: Create Tenant

- **Status:** Proposed — **not yet applied to `frontend/`**; awaiting approval before Phase 8.3
- **Date:** 2026-07-30
- **Consumes**: `POST /tenants` only, via `api.createTenant()` ([Phase 5]/[Phase 8], Approved, unmodified). Uses `useApi`, `useToast`, `Button`, `ErrorBanner`, `Card`, `PageHeader` exactly as approved — no shared component, hook, or constant touched.
- **No inconsistencies found this phase** — Create Tenant's approved scope (Company Name + Plan only) maps cleanly onto the approved API's `{ name, plan }` body with nothing left over to reconcile.

---

## `components/tenant-management/CreateTenantForm.js`

```jsx
"use client";

import { useState } from "react";
import Link from "next/link";
import { api } from "../../lib/api";
import { adminAuth } from "../../lib/auth";
import { useApi } from "../../hooks/useApi";
import { useToast } from "../../hooks/useToast";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const NAME_MAX = 200;
const VALID_PLANS = ["TRIAL", "STANDARD", "PREMIUM"]; // mirrors the approved Service Layer's plan set

function validate(form) {
  const errors = {};
  const trimmedName = form.name.trim();
  if (!trimmedName || trimmedName.length > NAME_MAX) {
    errors.name = `Company name is required and must be 1-${NAME_MAX} characters`;
  }
  if (!form.plan || !VALID_PLANS.includes(form.plan)) {
    errors.plan = "A valid plan is required";
  }
  return errors;
}

export default function CreateTenantForm({ onSuccess }) {
  const [form, setForm] = useState({ name: "", plan: "TRIAL" });
  const [fieldErrors, setFieldErrors] = useState({});
  const { execute, loading, error, setError } = useApi(api.createTenant);
  const { showToast } = useToast();

  function updateField(key) {
    return (e) => {
      setForm((f) => ({ ...f, [key]: e.target.value }));
      if (fieldErrors[key]) {
        setFieldErrors((prev) => ({ ...prev, [key]: undefined }));
      }
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    const errors = validate(form);
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    try {
      const token = adminAuth.get();
      const { tenant, warnings } = await execute(token, { name: form.name.trim(), plan: form.plan });

      showToast(`"${tenant.name}" created as a Draft.`);
      // Duplicate-name warnings are informational only (Phase 4 §1) - shown
      // as additional neutral toasts, never as validation errors, and never
      // blocking the navigation below.
      if (warnings && warnings.length > 0) {
        warnings.forEach((warning) => showToast(warning));
      }

      onSuccess(tenant);
    } catch {
      // useApi already captured the message into `error`, rendered below -
      // nothing further to do with the rethrown error here.
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      {error && <ErrorBanner message={error} />}

      <div className="field">
        <label htmlFor="tenant-name">
          Company Name <span aria-hidden="true">*</span>
          <span className="sr-only"> (required)</span>
        </label>
        <input
          id="tenant-name"
          value={form.name}
          onChange={updateField("name")}
          maxLength={NAME_MAX}
          required
          aria-required="true"
          aria-invalid={fieldErrors.name ? "true" : "false"}
          aria-describedby={fieldErrors.name ? "tenant-name-error" : undefined}
          disabled={loading}
        />
        {fieldErrors.name && (
          <p id="tenant-name-error" className="field-error" role="alert">
            {fieldErrors.name}
          </p>
        )}
      </div>

      <div className="field" style={{ marginBottom: 0 }}>
        <label htmlFor="tenant-plan">
          Subscription Plan <span aria-hidden="true">*</span>
          <span className="sr-only"> (required)</span>
        </label>
        <select
          id="tenant-plan"
          value={form.plan}
          onChange={updateField("plan")}
          required
          aria-required="true"
          aria-invalid={fieldErrors.plan ? "true" : "false"}
          aria-describedby={fieldErrors.plan ? "tenant-plan-error" : undefined}
          disabled={loading}
        >
          <option value="TRIAL">Trial</option>
          <option value="STANDARD">Standard</option>
          <option value="PREMIUM">Premium</option>
        </select>
        {fieldErrors.plan && (
          <p id="tenant-plan-error" className="field-error" role="alert">
            {fieldErrors.plan}
          </p>
        )}
      </div>

      <div className="form-actions">
        <Link href="/admin/tenants" className="btn btn-outline">
          Cancel
        </Link>
        <Button type="submit" disabled={loading}>
          {loading ? "Saving…" : "Save Draft"}
        </Button>
      </div>
    </form>
  );
}
```

## `app/admin/tenants/new/page.js`

```jsx
"use client";

import { useRouter } from "next/navigation";
import PageHeader from "../../../components/ui/PageHeader";
import Card from "../../../components/ui/Card";
import CreateTenantForm from "../../../components/tenant-management/CreateTenantForm";

export default function CreateTenantPage() {
  const router = useRouter();

  function handleSuccess(tenant) {
    router.push(`/admin/tenants/${tenant.id}`);
  }

  return (
    <div style={{ maxWidth: 480, margin: "0 auto" }}>
      <PageHeader
        title="New Tenant"
        description="Create a Draft Tenant. You'll invite its Owner from the Tenant Details page next."
      />
      <Card>
        <CreateTenantForm onSuccess={handleSuccess} />
      </Card>
    </div>
  );
}
```

**Cancel is a direct `Link`, not the `Button` component** — same reasoning as Phase 8.1: `Button` (frozen) has no link-rendering mode, so navigation-as-button reuses the plain `.btn-outline` class directly, exactly matching the existing convention.

**On the width constraint achieving all three breakpoints with one rule**: `maxWidth: 480` only *caps* large viewports — desktop and tablet get a genuinely centered, narrower form; mobile viewports are already narrower than 480px, so the same rule imposes no constraint there and the form fills the available width naturally. No media query needed for this specific requirement.

---

## CSS additions (existing tokens only)

```css
.field-error {
  font-size: 12px;
  color: var(--color-brick); /* reuses the existing error color token, same one .error-banner already uses */
  margin-top: 4px;
}

.form-actions {
  display: flex;
  gap: 12px;
}

/* Standard accessibility utility, not a visual pattern - hides text
   visually while keeping it in the accessibility tree */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
```

`.field-error` reuses `--color-brick` — the same token `.error-banner` already uses — applied at a smaller scale for inline field errors; not a new color or pattern, just the existing error convention applied where the accessibility requirements need something visible for `aria-describedby` to point to.

---

## Architecture Review

`CreateTenantForm` owns form state, client validation, and the API call (via `useApi`); `page.js` owns only navigation (`onSuccess` → `router.push`). This split means the form component doesn't need to know it's inside a Next.js route at all beyond the one `Cancel` link — it could be reused in a modal or a different page shape later without rework, which is a genuine (if not yet exercised) benefit of keeping the two files' responsibilities separate as requested.

## API Compliance Review

Exactly one endpoint called: `POST /tenants` via `api.createTenant(token, { name, plan })`, unmodified from [Phase 8]. No other field is collected or sent — Owner Name, Owner Email, TRN, Address, Phone, and Contact Email are absent from this form entirely, matching the approved scope precisely.

## Accessibility Review

- Both fields have real `<label>` elements (not placeholder-as-label), `aria-required`, and `aria-invalid` reflecting live validation state.
- Required-field asterisks are marked `aria-hidden="true"` and paired with genuine screen-reader text ("(required)") via `.sr-only` — the asterisk alone is a purely visual convention many screen readers skip or mis-announce; this ensures the requirement is actually communicated, not just visually implied.
- Each field error is linked via `aria-describedby` and carries `role="alert"`, so it's announced the moment it appears, not just visible to sighted users.
- Both inputs are `disabled` during submission, and `Button`'s existing disabled styling communicates that state visually; the button's own label changes to "Saving…" as a text-based (not just visual) status change.

## Performance Review

Controlled inputs throughout; no `useCallback`/`useMemo` applied to the two trivial field-update closures — deliberately, since memoizing a two-field form's inline handlers would be exactly the over-engineering the task asked to avoid. Re-renders are limited to this one small form component, not the page shell around it.

## Future Improvements

1. If Create Tenant ever grows beyond two fields, revisit whether inline closures remain appropriate or whether a small reducer-based form state becomes worth the complexity — not needed at this size.
2. The duplicate-name warning currently renders as a plain toast identical in style to the success toast (both use the default, non-error `Toast` variant) — visually adequate but not visually distinct from the success message itself; a dedicated "neutral/info" toast styling variant (distinct from both success and error) would make the two easier to tell apart at a glance, without changing the frozen `Toast` component's API.

---

**STOP — awaiting approval before Phase 8.3 (Tenant Details). Not yet applied to `frontend/`.**
