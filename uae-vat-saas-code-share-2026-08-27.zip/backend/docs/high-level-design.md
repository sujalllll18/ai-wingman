# Ledger — High-Level Design (HLD)

- **Status:** Version 1 — official implementation guide
- **Date:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Synthesized from:** [System Design Document](system-design-document.md), [Database Design Specification](database-design-specification.md), [Platform Architecture Specification](platform-architecture-specification.md), [ADR-0001](adr/0001-baseline-architecture.md) (Accepted).
- **Audience:** every engineer writing Module 1+ code.
- **A note on the stack, resolved before writing this document:** this HLD was requested for React/NestJS/Prisma/PostgreSQL/TypeScript. Ledger's Accepted stack ([ADR §2]/[§3]) is **Next.js (which is React), Express (not NestJS), Prisma, PostgreSQL, and JavaScript today with TypeScript adoption still an open, unresolved decision** ([ADR §2], carried through every document in this set). Per the confirmed direction, this document is written for the Accepted stack. Every NestJS-specific concept requested — Modules, Controllers, Services, Repositories, DTOs, Guards, Pipes, Interceptors, Exception Filters, Middleware — is addressed with its Express-idiomatic equivalent, mapped explicitly in [§4], so nothing from the requested structure is lost, only translated. If a genuine framework migration is ever wanted, it is a new ADR proposal, not a document-level substitution.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary) · 2. [Technology Stack](#2-technology-stack) · 3. [Frontend Architecture](#3-frontend-architecture) · 4. [Backend Architecture](#4-backend-architecture) · 5. [Folder Structure](#5-folder-structure) · 6. [Module Organization](#6-module-organization) · 7. [Repository Pattern](#7-repository-pattern) · 8. [Service Layer](#8-service-layer) · 9. [DTO Strategy](#9-dto-strategy) · 10. [Validation Strategy](#10-validation-strategy) · 11. [Authentication Implementation](#11-authentication-implementation) · 12. [RBAC Implementation](#12-rbac-implementation) · 13. [Configuration Management](#13-configuration-management) · 14. [Feature Flags](#14-feature-flags) · 15. [Audit Logging](#15-audit-logging) · 16. [File Storage](#16-file-storage) · 17. [Notification Architecture](#17-notification-architecture) · 18. [Error Handling](#18-error-handling) · 19. [Logging Strategy](#19-logging-strategy) · 20. [Testing Strategy](#20-testing-strategy) · 21. [Dependency Rules](#21-dependency-rules) · 22. [Coding Standards](#22-coding-standards) · 23. [Security Guidelines](#23-security-guidelines) · 24. [Performance Guidelines](#24-performance-guidelines) · 25. [Deployment Readiness](#25-deployment-readiness) · 26. [Future Evolution](#26-future-evolution)

---

## 1. Executive Summary

The SDD explained how the system behaves; this document explains how an engineer writes the code that makes it behave that way. It defines the implementation-level structure — layers, folders, module shape, and the code-level rules (dependency direction, error categories, validation boundaries) that keep the modular monolith from [PAS §2] honest in practice, not just on a diagram.

Every pattern here is deliberately framework-idiomatic to Express rather than a workaround — Express's lack of NestJS's built-in decorators and DI container is not a gap to compensate for; it's a different, equally valid way to get the same layering (Controller → Service → Repository, Guards, Pipes, Interceptors, Exception Filters) that this document maps concept-for-concept in [§4].

---

## 2. Technology Stack

| Technology | Requested | Accepted (this document uses) | Why |
|---|---|---|---|
| Frontend framework | React | **Next.js** (React-based, App Router) | Already built in Module 0; adds file-based routing, layouts, and a mobile-first-friendly rendering model on top of React itself — the request for "React" is satisfied, just with the framework already chosen around it ([ADR §2]). |
| Backend framework | NestJS | **Express** | Accepted in [ADR §2]/[§3]; already the working Module 0 codebase. Every NestJS primitive requested has a mapped Express equivalent — see [§4]. |
| ORM | Prisma | **Prisma** | Unchanged — matches the request directly, and is the [DDS]'s foundation throughout. |
| Database | PostgreSQL | **PostgreSQL** (target; SQLite in local dev only, [ADR §4]) | Unchanged — matches the request directly. |
| Language | TypeScript | **JavaScript today; TypeScript adoption remains open** | [ADR §2] flagged this as undecided from the start, and every document since (MPS, PAS, DDS, SDD) has carried it forward unresolved rather than defaulting either way. This HLD's patterns (Service/Repository layering, DTO-shaped validation) are unaffected by that decision — TypeScript, if adopted, adds compile-time safety on top of this structure; it does not change the structure itself. |

---

## 3. Frontend Architecture

```mermaid
graph TD
    Pages["Pages (Next.js app/ route files)"]
    Layouts["Layouts (per-section auth guard + shell)"]
    Components["Shared Components"]
    FeatureModules["Feature Modules (per domain, e.g. future Invoices)"]
    APILayer["API Layer (lib/api.js)"]
    Backend["Backend API"]

    Pages --> Layouts
    Pages --> FeatureModules
    FeatureModules --> Components
    Pages --> APILayer
    FeatureModules --> APILayer
    APILayer --> Backend
```

| Concept | Pattern | Status |
|---|---|---|
| **Pages** | Next.js file-based routing — each route is a `page.js` under `app/` | Established (Module 0: `app/admin/dashboard/page.js`, etc.) |
| **Layouts** | Section-scoped `layout.js` — owns the auth guard and shell (sidebar/nav) for everything beneath it | Established (`app/admin/layout.js`, `app/tenant/layout.js`) |
| **Components** | Small, reusable, presentation-focused (`PlanTag.js`, `StatusStamp.js`) | Established; extend per-module as new domains ship |
| **Feature Modules** | A folder per domain (future: `app/tenant/customers/`, `app/tenant/invoices/`) grouping that domain's pages | **[Design Now, Build Later]** — Module 0 only has two feature areas (Admin, Tenant); the pattern scales directly as Module 1+ adds domains |
| **Routing** | Next.js App Router, file-based — no client-side router library needed | Established |
| **Forms** | Controlled React components, local `useState` per field | Established; no form library adopted yet — acceptable at current form complexity, revisit if forms grow materially more complex |
| **Validation** | Client-side validation mirrors server-side rules for fast feedback but is never authoritative — the server always re-validates ([§10]) | HTML5 attributes today; a shared schema library (if adopted server-side, [§9]) is the natural next step so validation rules aren't duplicated by hand on both sides |
| **API Layer** | A single fetch wrapper (`lib/api.js`) — every backend call goes through it, never a raw `fetch()` scattered in a component | Established |
| **State Management** | React state + `localStorage` for session ([ADR §2]) — no external state library | Established; revisit only if a genuine cross-page shared-state need appears, not preemptively |
| **Error Handling** | `try/catch` per action, inline error banner components | Established pattern (`error-banner` class, [ADR §2]) |
| **Folder Structure** | See [§5] | — |

---

## 4. Backend Architecture

**NestJS-to-Express concept mapping** — this table is the core translation the rest of this document builds on:

| NestJS concept | Express-idiomatic equivalent | Where it lives |
|---|---|---|
| Module (DI container grouping) | A folder-per-domain convention: routes + controller + service + repository, explicitly exported — no DI container, dependencies passed/imported directly | [§6] |
| Controller | Thin route-handler functions — parse request, call a Service, shape the response. No business logic. | `controllers/` (established, [ADR §13.1]) |
| Service | Business logic, one function per rule, framework-agnostic | `services/` — **new, formalized layer** (Module 0 currently has controllers call Prisma directly; this HLD introduces the Service/Repository split for Module 1+) |
| Repository | Wraps Prisma queries for one module's own tables only | `repositories/` — **new layer**, see [§7] |
| DTO | A validated request/response shape (schema object + mapper function) | [§9] |
| Guard | Middleware run before the route handler, deciding allow/deny (`requirePlatformAdmin`, `requireTenantUser`, future `requirePermission`) | `middleware/` (established pattern, extended for RBAC, [§12]) |
| Pipe | Input parsing/validation middleware, or an explicit validate-and-parse step at the top of a Service call | [§10] |
| Interceptor | Middleware wrapping the request/response cycle (e.g., request-logging) | `middleware/` |
| Exception Filter | The centralized error-handling middleware already in `app.js` | Established ([ADR §11]) — extended per [§18]'s error categories |
| Middleware | Middleware — the one concept that needs no translation; Express *is* middleware-based | `middleware/` |

```mermaid
graph LR
    Req["Incoming Request"] --> MW1["Middleware:\nrequest logging, correlation ID"]
    MW1 --> MW2["Guard-equivalent Middleware:\nAuthentication + Authorization"]
    MW2 --> Pipe["Pipe-equivalent:\nDTO validation"]
    Pipe --> Controller["Controller\n(thin, no business logic)"]
    Controller --> Service["Service\n(business logic, transactions)"]
    Service --> Repo["Repository\n(this module's data only)"]
    Repo --> Prisma["Prisma Client"]
    Prisma --> DB[("PostgreSQL")]
    Controller --> Filter["Exception Filter-equivalent:\ncentralized error middleware"]
    Filter --> Res["Response"]
```

---

## 5. Folder Structure

**Backend** (`uae-vat-saas/src/`) — extending the established Module 0 layout:

```
src/
  app.js                  # Express app assembly, middleware wiring
  server.js                # Process entrypoint
  config/                  # Env config, Prisma client singleton
  middleware/               # Guard-equivalents: auth, RBAC, request logging
  platform-services/        # Cross-cutting services (PAS §8), one folder each:
    authentication/
    authorization/          # RBAC
    tenant-management/
    configuration/
    feature-flags/
    notifications/
    audit/
    numbering/
    file-storage/
  modules/                  # Domain modules (PAS §6/§7), one folder each:
    tenant-foundation/       # Customers, Suppliers, Products/Services, Business Profile
      controllers/
      services/
      repositories/
    invoicing/
    vat-position/            # includes Purchases, VAT Return, Reports
    access-control/          # Module 4
    automation/              # Module 5, future
  utils/                    # ApiError, shared helpers
```

**Frontend** (`frontend/`) — extending the established Module 0 layout:

```
frontend/
  app/
    admin/                  # Platform Admin feature area (existing)
    tenant/                 # Tenant feature area (existing)
      customers/             # future feature module
      invoices/               # future feature module
      ...
  components/               # Shared, presentation-only
  lib/
    api.js                   # API layer
    auth.js                  # Session/token handling
```

Both structures are **additive to what already exists** — no renames, per [ADR §13.3]; new folders (`platform-services/`, `repositories/` per module) are introduced starting with Module 1.

---

## 6. Module Organization

Every domain module — Customer, Supplier, Invoice, VAT, Reports, Configuration — follows the **same internal shape**, so any engineer can predict any module's layout without being told:

| Layer | Responsibility | Depends on |
|---|---|---|
| `controllers/` | Parse request, call one Service function, shape response | Its own module's `services/` only |
| `services/` | Business logic, transactions, validation, calls to other modules' Services and platform services | Its own `repositories/`, other modules' `services/`, `platform-services/` |
| `repositories/` | Prisma queries for this module's own tables only | Prisma Client only |
| `dto/` (or `schemas/`) | Request/response validation shapes | Nothing — pure data shape definitions |

**Configuration** is a partial exception: it is a **platform service** ([PAS §8]), not a domain module — it lives in `platform-services/configuration/`, not `modules/`, even though the user-facing settings screen belongs to Module 1's Tenant Foundation UI. The backend distinction matters even where the frontend experience feels unified.

---

## 7. Repository Pattern

```mermaid
graph TD
    ServiceA["Invoicing Service"] --> RepoA["Invoicing Repository"]
    ServiceA -->|"calls Service, never Repository"| ServiceB["Tenant Foundation Service"]
    ServiceB --> RepoB["Tenant Foundation Repository"]
    RepoA --> Prisma["Prisma Client"]
    RepoB --> Prisma
    Prisma --> DB[("PostgreSQL")]

    ServiceA -.forbidden.-x RepoB
```

| Responsibility | Detail |
|---|---|
| **Owns Prisma access for its module** | Only a module's own Repository imports and calls the Prisma Client for that module's tables — direct implementation of [DDS §4]/[PAS §21]'s data-ownership rule at the code level. |
| **Every method is tenant-scoped** | A Repository method that returns tenant-owned data always takes a tenant context and applies it — there is no "unscoped" query variant to accidentally reach for ([SDD §10]). |
| **No business logic** | A Repository answers "what does the database say," never "is this allowed" or "what should happen next" — those are Service concerns ([§8]). |
| **Mockable in tests** | Because Services depend on Repositories through a stable interface, unit tests can substitute a fake Repository and test business logic with zero database involvement ([§20]). |
| **Never called by another module's Service** | Cross-module data needs go through the owning module's **Service**, never its Repository directly — the enforced version of [PAS §22] Rule 2. |

---

## 8. Service Layer

| Concern | Approach |
|---|---|
| **Business Logic** | Every rule from the [Knowledge Base] and [Product Bible §7] has exactly one implementation, in a named Service function — never duplicated inline in a Controller or copy-pasted across modules ([ADR §13.1], unchanged). |
| **Transactions** | Multi-step writes that must succeed or fail together (already the pattern for Tenant+Owner creation in Module 0) use Prisma's transaction API — a Service-layer concern, never split across multiple Repository calls without a wrapping transaction when atomicity matters. |
| **Validation** | *Business-rule* validation (is this VAT category valid for this transaction type, does this exceed a plan limit) lives here — distinct from the *input-shape* validation that happens earlier, at the DTO/Pipe-equivalent stage ([§9]/[§10]). |
| **Events** | **[Build Now, minimal]**: a Service that completes a significant action (e.g., Invoice issued) makes explicit calls to the platform services that need to react (Audit, Notifications) — synchronous, direct calls, not a message bus. **[Future Vision]**: if the number of things reacting to a single action grows, this becomes a real internal event-emitter or message queue ([§26]) — not adopted now, since two or three direct calls per action is simpler and more debuggable than an event bus at this scale. |

---

## 9. DTO Strategy

Without NestJS's class-decorator DTOs, a DTO in this codebase is: **a validation schema + an explicit response-mapping function** — two plain artifacts, not a framework feature.

| DTO type | Purpose | Implementation shape |
|---|---|---|
| **Request DTO** | Defines and validates exactly what a Controller accepts | A schema object (see [§10] for the validation library recommendation) that the Pipe-equivalent step validates against before the Controller calls its Service |
| **Response DTO** | Defines exactly what a Controller returns — **never** the raw Prisma row | An explicit mapping function selecting only intended fields. This is a hard security rule, not a style preference: a raw `User` row includes `passwordHash`; a raw internal field a future module adds might include something equally unfit to serialize. No Controller ever returns a Prisma result directly. |
| **Validation DTO** | The schema itself, shared between the request-validation step and (optionally) generated documentation later | Same artifact as the Request DTO — not a third, separate thing |

---

## 10. Validation Strategy

Three layers, matching [DDS §16]'s governing rule, now placed concretely in the request pipeline:

| Layer | What it catches | Where |
|---|---|---|
| **Client** | Fast feedback, not authoritative | Frontend forms ([§3]) |
| **Server** | The authoritative layer — every request is validated regardless of what the client already checked | The Pipe-equivalent step in [§4]'s pipeline, before the Controller is even invoked |
| **Database** | Structural invariants that must hold no matter what wrote the row | `NOT NULL`/`CHECK`/`FK` constraints ([DDS §16]) — the last-resort backstop, not the primary defense |

**Recommendation, not yet an ADR-level decision**: adopt a runtime schema-validation library (e.g., Zod — already the direction implied by the original Architecture Review's finding that no validation library exists yet) for the Server layer, since Express has no built-in equivalent to NestJS's `class-validator`. This works identically whether or not TypeScript is later adopted, and gets *more* valuable (inferred types) if it is — a genuine synergy worth knowing about, not a reason to decide TypeScript now.

---

## 11. Authentication Implementation

Architecture only, per the request — no code:

- Two identity spaces (Platform Admin, Tenant User), each with its own signing secret and audience — already built ([ADR §5]), unchanged.
- Guard-equivalent middleware (`requirePlatformAdmin`, `requireTenantUser`) verifies the credential and attaches the verified identity to the request before any Controller runs — already built.
- Password verification (bcrypt) happens inside the Authentication platform service, never inline in a Controller.
- **[Design Now, Build Later]**: MFA and session-revocation checks are additional steps *inside this same middleware*, not a redesign — the architecture already has the right seam ([SDD §8]).

---

## 12. RBAC Implementation

Architecture only:

- A Guard-equivalent middleware, `requirePermission(module, action)`, replaces ad hoc role-string checks — it calls the Authorization platform service's `hasPermission()` function ([PAS §14]), never compares `role === 'OWNER'` inline in a Controller or Service.
- The Authorization service resolves an identity's permissions via its own Repository, reading the Role/Permission data model ([PAS §14]/[DDS §5]).
- This is **data-driven from Module 1**, per the MPS's resolution of the original Product Bible/Review disagreement — every Controller from Module 1 onward is written against `requirePermission(...)`, never a raw role check, so there is no later migration to do.

---

## 13. Configuration Management

- A Configuration platform service exposes one function shape — resolve an effective setting for a Tenant, walking the Platform → Plan → Tenant cascade ([PAS §11]/[§15]).
- Domain Services call this function; they never read a setting from a hardcoded constant or duplicate the cascade logic themselves.
- **[Design Now, Build Later]**: a short-lived, per-request or short-TTL cache in front of this service once read volume justifies it — not needed at MVP scale, but the single-function interface means adding caching later doesn't change any caller.

---

## 14. Feature Flags

- A Feature Flags platform service exposes `hasFeature(tenantId, key)`, generalizing the existing `plans.js` `features` object ([ADR §5]'s existing pattern, formalized).
- Used two ways: as Guard-equivalent middleware gating an entire route (e.g., Audit Log endpoints), or as an inline check inside a Service for finer-grained gating.
- **No Controller or Service ever compares a raw plan string** (`tenant.plan === 'PREMIUM'`) — every gate goes through this one function, directly closing the concrete finding from the Architecture Review.

---

## 15. Audit Logging

- An Audit platform service exposes one function — record an event — called **explicitly** by a domain Service at the specific points in the mandatory action taxonomy ([DDS §11]/[PAS §8]: login, permission change, financial document issuance/void, settings change).
- Never automatic or implicit — a Service author deliberately decides "this action needs an audit record," consistent with only *defined* sensitive actions being logged, not everything.
- Writes are append-only; the Audit Repository has no update or delete method at all — not just a convention, an absence in the interface itself.

---

## 16. File Storage

- A File Storage platform service exposes `store()` and `getSignedUrl()`; no domain module imports an object-storage client directly ([ADR §9]/[DDS §15]).
- Storage keys are tenant-prefixed inside this service, not decided per-caller — a domain Service never constructs a storage key itself.
- File metadata (owning Tenant, storage key, uploader, content type) is persisted via this service's own Repository — the file-metadata entity is introduced the first time any module needs uploads, not deferred to Module 5's OCR need ([DDS §15]).

---

## 17. Notification Architecture

- A Notification platform service exposes `notify(event)`; domain Services call this and never know which provider (email today) actually sends anything.
- Internally, a simple provider-registry pattern selects the right provider per event/channel — additive when SMS/WhatsApp are added later ([MPS §7] V1), no redesign of any calling Service.
- Failure isolation ([SDD §20]): if the Notification service's provider call fails, it does not roll back or block the domain Service's already-committed database write — the triggering action (e.g., Invoice issuance) succeeded; the notification is retried independently.

---

## 18. Error Handling

Four categories, each mapped to a distinct handling path through the centralized Exception-Filter-equivalent middleware ([ADR §11], extended):

| Category | Example | Handling |
|---|---|---|
| **Business Errors** | Plan limit exceeded, duplicate email | Thrown as `ApiError` with an appropriate status (409, etc.) from the Service layer — expected, meaningful to the client |
| **Validation Errors** | Malformed request body, invalid TRN format | Raised at the Pipe-equivalent stage ([§10]), before a Controller/Service ever runs — always 400 |
| **System Errors** | Database connection failure, external provider timeout | Caught centrally, logged with full detail server-side, generic message to the client — never leaks internals ([ADR §11]) |
| **Unexpected Errors** | An unhandled exception the code didn't anticipate | Same centralized handling as System Errors, but specifically flagged in logging/observability as *unhandled* — a signal that a new, deliberate error case is likely missing and should be added |

---

## 19. Logging Strategy

- Structured logs (not `console.log`), with a request/tenant correlation ID attached by the Interceptor-equivalent logging middleware, applied to every request ([ADR §10]).
- Log levels used deliberately (error/warn/info/debug) — not everything at one level.
- **Never logged, ever**: passwords, full JWTs, full request bodies on authentication endpoints ([ADR §10], unchanged).
- Business Audit Logging ([§15]) and this operational logging remain two separate systems — a Service never treats an audit call as "close enough" to a log line, or vice versa ([SDD §21]).

---

## 20. Testing Strategy

| Test type | What it covers | How the architecture enables it |
|---|---|---|
| **Unit Tests** | Service-layer business logic, in isolation | Because Services depend on Repositories through a stable interface ([§7]), a unit test substitutes a fake Repository and verifies business logic with zero database — this is the single biggest payoff of introducing the Repository layer now |
| **Integration Tests** | Repository ↔ real database behavior; Controller → Service → Repository together | Run against a real (test) database — verifies the layers actually compose correctly, not just in isolation |
| **E2E Tests** | Full HTTP request against a running instance | Covers the critical paths this whole document set treats as non-negotiable: authentication, tenant isolation, RBAC denial — these deserve E2E coverage specifically because a regression here is the costliest possible failure |
| **Test Data** | Tenant-scoped fixtures/factories, one per module | Mirrors [§6]'s per-module structure — a module's test data builders live alongside its Repository |
| **Mocking** | Fake Repositories for unit tests; fake providers (Email, Storage) for integration tests | Both are possible specifically because [§7]/[§16]/[§17] already define stable, narrow interfaces to substitute |

**Named directly**: Module 0 currently has zero automated tests, a gap every prior document in this set has flagged. This HLD's layering is what makes closing that gap tractable starting Module 1 — the Repository pattern exists as much for testability as for data-ownership discipline.

---

## 21. Dependency Rules

```mermaid
graph TD
    Controller --> Service
    Service --> OwnRepo["Own Module's Repository"]
    Service --> OtherService["Another Module's Service"]
    Service --> PlatformService["Platform Service"]
    PlatformService -.never depends on.-x Service
    Controller -.forbidden.-x OwnRepo
    Service -.forbidden.-x OtherRepo["Another Module's Repository"]
```

| Rule | Allowed | Forbidden |
|---|---|---|
| Controller → Service | ✅ Always | Controller calling a Repository directly — skips business logic and validation entirely |
| Service → own Repository | ✅ Always | — |
| Service → another module's Service | ✅ The only sanctioned form of cross-module communication | Service → another module's Repository — bypasses that module's business logic and data ownership |
| Service → platform service | ✅ Always | Platform service → any domain Service — would invert the whole layering |
| Two domain modules' Services calling each other circularly | 🚫 Forbidden | A circular dependency is a signal the module boundary itself is drawn wrong, not a case to special-case around |

Direct restatement of [PAS §22] at the code layer — nothing new decided here, only made literal.

---

## 22. Coding Standards

High-level principles only:

- Consistent naming: camelCase for functions/variables, PascalCase for constructors/classes where used.
- No business logic in a Controller — ever, without exception ([ADR §13.1]).
- One clear responsibility per file; a file that's hard to name in one sentence is probably doing too much.
- Prefer pure functions in the Service layer where the logic allows it — easier to test, easier to reason about.
- Comments explain *why*, never *what* — consistent with this whole document set's own style.
- Every thrown error is an `ApiError` (or its future typed-error-category equivalents, [§18]) — never an ad hoc response shape.

---

## 23. Security Guidelines

Implementation-level, not a repeat of [PAS §10]/[DDS §19]:

- Tenant context and identity are **never** read from a request body or query parameter — only from the verified credential, inside Guard-equivalent middleware, before any Controller runs.
- Prisma's parameterized queries are the only way data is queried — no raw string-concatenated SQL, which would reopen the injection risk Prisma otherwise closes by default.
- Passwords: bcrypt hashing only, never logged, never returned in any Response DTO ([§9]).
- Every mutating endpoint runs its Pipe-equivalent validation before touching the Service layer — no exceptions for "trusted" internal callers.
- Secrets live in environment variables only, are never logged ([§19]), and are never committed — `.gitignore` already excludes `.env` correctly.

---

## 24. Performance Guidelines

- Avoid N+1 queries: Repository methods use Prisma's `include`/`select` deliberately rather than looping individual calls ([DDS §14]).
- List endpoints follow the pagination approach from [DDS §14]/[SDD §18] — offset pagination is acceptable at MVP scale; cursor-based is the target once volume grows.
- Heavy computation (large aggregate report generation) stays in set-based Prisma/SQL aggregation, never pulled into application memory to sum in a loop.
- Connection pooling uses Prisma's built-in pool, sized appropriately once a deployment vendor and expected concurrency are known ([ADR §12]).

---

## 25. Deployment Readiness

| Concern | Approach |
|---|---|
| **Configuration** | Environment-based config module (already `dotenv`, [ADR §4]) — no hardcoded environment-specific values anywhere in application code. |
| **Environment Variables** | Categorized: database connection, the two JWT secrets (Platform Admin, Tenant User — deliberately separate, [ADR §5]), `PORT`, seed admin credentials, frontend's `NEXT_PUBLIC_API_URL` — the existing `.env.example` files in both repos remain the reference, not restated here. |
| **Secrets** | Never committed; `.gitignore` already correct in both repos. Vault-based rotation is **[Design Now, Build Later]** ([PAS §10]). |
| **Health Checks** | The existing `/health` liveness endpoint (Module 0) is extended with a readiness check (database connectivity) as the first **[Design Now, Build Later]** addition — same endpoint pattern, more thorough check. |

---

## 26. Future Evolution

| Direction | How this HLD's structure accommodates it | Tier |
|---|---|---|
| **Background Workers** | Notification retries and future OCR/AI processing are the first real candidates — a worker process consuming a queue, calling the *same* Service-layer functions a Controller calls today | **[Future Vision]** |
| **Queues** | The Service layer's direct, synchronous cross-service calls ([§8]) become queue-published events if/when async decoupling is genuinely needed — not adopted speculatively | **[Future Vision]** |
| **Microservices** | Because each module's Repository never leaks outside that module's Service ([§7]/[§21]), a module is extractable into its own deployable service by moving its folder — the interface it exposed to other Services becomes a network call instead of a function call, with no internal redesign | **[Future Vision]**, option preserved, not scheduled ([PAS §16]/[§24]) |
| **Event-Driven Architecture** | The explicit "Service calls the platform services that need to react" pattern in [§8] is the seed of an event system — formalizing it into a real publish/subscribe mechanism is additive once three or more real reactions to a single action exist ([PAS §3] Principle 6, "rule of three") | **[Future Vision]** |
| **AI Services** | An AI orchestration layer calls the same Service-layer functions a Controller calls today, through the same Guard-equivalent RBAC middleware — no new access path ([SDD §22]) | **[Future Vision]** |

---

This document is the implementation reference every Module 1+ pull request is checked against. Where a real implementation need genuinely requires deviating from a layer or rule here, that deviation is proposed and explained before it's built, per [ADR §13.3] — the same discipline this document itself was produced under, given the stack question resolved at the top.
