# Ledger — Master Product Specification (MPS)

- **Status:** Version 1 — single source of truth for product, business, and architectural direction
- **Date:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Synthesized from:** [Product Bible v2](product-bible.md), [ADR-0001](adr/0001-baseline-architecture.md) (Accepted), [UAE VAT Knowledge Base v1](knowledge-base/README.md), the [Enterprise Platform Review](reviews/0001-enterprise-platform-review.md), and the built Module 0 UI (`frontend/app`, `frontend/components` — the platform's working reference for its visual/interaction language).
- **Relationship to the source documents:** this is not a fifth document sitting alongside the other four — it is the **synthesized, resolved** answer to "what is Ledger," built on top of them. Where the source documents disagreed with each other or left something ambiguous, this document states the resolution and says so explicitly. Where a question is genuinely architectural (not product), it is not resolved here — it is listed in [§23 Open Decisions](#23-open-decisions) and remains governed by ADR-0001's change-control process. The four source documents remain the detailed reference for their domains (architecture decisions, VAT law, enterprise-readiness backlog) — this document is what you read first.
- **What this document is not:** it contains no database schema, API design, folder structure, code, or implementation detail, by design. It answers *what* and *why*; the ADR and future engineering design docs answer *how*.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary) · 2. [Vision & Mission](#2-vision--mission) · 3. [Product Principles](#3-product-principles) · 4. [Problem Statement](#4-problem-statement) · 5. [Target Market & Personas](#5-target-market--personas) · 6. [Jobs To Be Done](#6-jobs-to-be-done) · 7. [Product Scope](#7-product-scope) · 8. [User Journeys](#8-user-journeys) · 9. [Modules & Responsibilities](#9-modules--responsibilities) · 10. [Functional Requirements](#10-functional-requirements) · 11. [Non-Functional Requirements](#11-non-functional-requirements) · 12. [Business Rules](#12-business-rules) · 13. [Multi-Tenant Strategy](#13-multi-tenant-strategy) · 14. [RBAC Strategy](#14-rbac-strategy) · 15. [Configuration Strategy](#15-configuration-strategy) · 16. [Security Principles](#16-security-principles) · 17. [Compliance Principles](#17-compliance-principles) · 18. [Reporting Strategy](#18-reporting-strategy) · 19. [AI & Integration Vision](#19-ai--integration-vision) · 20. [Success Metrics](#20-success-metrics) · 21. [Risks & Assumptions](#21-risks--assumptions) · 22. [Product Roadmap](#22-product-roadmap) · 23. [Open Decisions](#23-open-decisions)

---

## 1. Executive Summary

Ledger is a secure, multi-tenant, subscription-based B2B SaaS platform for the UAE market. It is the **daily financial operating system** a business runs on — managing its profile, customers, suppliers, products and services, sales and purchase invoices, and expenses — with UAE VAT compliance produced automatically as a consequence of that daily use, not as a separate quarterly task.

Ledger serves two connected commercial segments through one platform: businesses operating directly, and accounting firms, consultants, and service providers managing multiple client businesses through one relationship. Every business (Tenant) is completely data-isolated regardless of how it's managed.

**Strategic resolution (this document's central call):** the prior product documents oscillated between "narrow UAE VAT compliance tool" and "broad, industry-agnostic enterprise platform." This document resolves that as a **two-horizon strategy**: Horizon 1 proves the model deeply in UAE VAT/SME compliance, built on genuinely reusable foundations (multi-tenancy, RBAC-as-data, configuration-driven behavior); Horizon 2 generalizes those proven foundations to other industries and geographies once Horizon 1 has real traction. Every "enterprise-grade" capability requested for this platform — configurable numbering, RBAC, notifications, feature flags — is architected now and built at the scope Horizon 1 actually needs, not spec'd out to Horizon 2's imagined scale. This is the same sequencing NetSuite, Zoho, and Xero followed; none of them started horizontal.

The MVP is deliberately narrower than the full vision: a single business's daily operations (Modules 0–3, [§9]) with the architectural seams — RBAC data model, configuration cascade, notification abstraction — already in place so that Firm/multi-tenant management, richer automation, and AI capabilities extend the platform in V1 and beyond without a rewrite. What's excluded is stated explicitly in [§7](#7-product-scope), not left to be discovered by omission.

---

## 2. Vision & Mission

**Vision (Horizon 1 → Horizon 2):** Ledger becomes the operating system UAE businesses run on every day — first by becoming indispensable for VAT-compliant SMEs and the firms that serve them, then by generalizing that same configurable, RBAC-driven, engine-based foundation to other compliance regimes and industries.

**Mission (what Ledger does today, to get there):** Reduce the manual work of running a compliant UAE business to the minimum a human judgment call actually requires. Every UAE VAT rule that can be applied automatically ([Knowledge Base](knowledge-base/README.md)) is applied automatically, silently, during ordinary business activity — invoicing a customer, logging a purchase, recording an expense — so that VAT filing becomes an assembly step, not a research project.

---

## 3. Product Principles

Twelve principles, consolidated from the Product Bible's original nine and the Architecture Review's engineering discipline additions — stated once, not twice:

| # | Principle | What it means in practice |
|---|---|---|
| 1 | **Multi-Tenant by Design** | Complete data isolation between Tenants is the platform's single non-negotiable guarantee, regardless of how a Tenant is managed ([§13]). |
| 2 | **RBAC as Data, Not Code** | Who can do what is determined by configurable role/permission data, never a hardcoded role-name comparison scattered through the codebase ([§14]). |
| 3 | **Configuration Over Customization** | Business-specific behavior (numbering, templates, thresholds, locale) is a setting a Tenant changes, never a code branch an engineer writes ([§15]). |
| 4 | **Compliance by Default** | VAT correctness is a side effect of normal use, not a feature a user has to invoke. |
| 5 | **Automation Before Manual Work** | Wherever a rule can be computed instead of asked-and-answered by a human, it is. |
| 6 | **Security & Isolation First** | Every access decision is derived from a verified identity, never trusted from client input; least privilege is the default, not an add-on ([§16]). |
| 7 | **Mobile First** | Every capability is fully usable on phone, tablet, and desktop — not a desktop product with a responsive afterthought. |
| 8 | **Build the Abstraction Before the Engine** | A pattern is generalized into a reusable engine only after three real cases need it — not built speculatively ahead of demand. This is the platform's explicit defense against over-engineering the MVP. |
| 9 | **Business Logic Lives in One Place, Documented Before It's Built** | Each business rule has exactly one implementation, and significant logic or architecture changes are documented before they're coded, not after. |
| 10 | **Architecture Changes Are Never Silent** | Renames, schema changes, and architectural pivots are proposed, explained, and approved — never slipped in alongside unrelated work. |
| 11 | **Subscription-Based, Segment-Aware** | Recurring, tiered revenue from two distinct segments (direct businesses and Firms managing many), not a one-size pricing model. |
| 12 | **Future-Ready, Not Future-Built** | AI, deep integrations, and advanced workflow are designed for — clean service boundaries, structured data, provider abstractions — without being built before there's a proven need ([§19]). |

---

## 4. Problem Statement

UAE VAT compliance is simultaneously **mandatory** (real, escalating financial penalties — [KB §7.3]) and **genuinely hard to get right by hand**: correctly distinguishing Zero Rated from Exempt from Out of Scope supplies ([KB §2]), applying blocked-input-VAT rules ([KB §4.4]), and keeping pace with active 2026 law changes (input VAT carry-forward caps, e-invoicing) is not something a trading or services business owner can be expected to know — they are experts in their trade, not tax law.

The available alternatives fail in different ways: a **spreadsheet** has no rule enforcement and no audit trail; a **part-time bookkeeper** is expensive, inconsistent, and disconnected from daily operations; **generic accounting software** built for other markets bolts UAE VAT on as an afterthought rather than encoding it as a first-class concept; and **enterprise ERPs** (SAP, NetSuite) are priced and staffed for businesses far larger than the UAE SME segment this product targets first.

A second, related problem: even where a business *does* keep good daily records, that data usually lives in a different tool than the one used for VAT filing — invoices in one system, expenses in a spreadsheet, VAT calculated separately at quarter-end. Compliance and daily operations are treated as two different jobs. Ledger's core bet is that they are the same job, and treating them as one is both a better product and a durable moat.

---

## 5. Target Market & Personas

Two commercial segments, five personas — resolved and finalized from the Product Bible's persona set:

| Persona | Segment | Core need | System role status |
|---|---|---|---|
| **SME Owner** | Direct | A daily tool that happens to keep them compliant; confidence, not tax literacy. | Tenant User — `OWNER` (built) |
| **Staff Bookkeeper/Admin** | Direct | Fast, guided data entry with guardrails against misclassification. | Tenant User — `STAFF` (built) |
| **Accounting Firm / Service Provider** | Firm-managed | Efficient management of many client businesses under one relationship, without N separate logins. | Not yet built — [§13]/[§23] |
| **External Tax Agent** | Either | Narrow, often read-heavy access to one client's records for review/filing sign-off. | Not yet built — narrower variant of the Firm access model |
| **Platform Admin** | N/A (platform operator) | Onboard and manage paying Tenants/Firms; explicitly kept out of Tenant financial detail. | Platform Admin (built) |

The **direct SME segment** is the beachhead — it validates the core product loop (daily use → compliant filing) with the shortest sales cycle. The **Firm-managed segment** is the larger, stickier expansion segment (one Firm relationship represents many Tenants) and is deliberately sequenced into V1 rather than MVP — see the resolution in [§7](#7-product-scope).

---

## 6. Jobs To Be Done

| Persona | When... | I want to... | So I can... |
|---|---|---|---|
| SME Owner | I make a sale | issue a correct, compliant invoice in under a minute, from my phone if needed | get paid without worrying I've made a tax mistake |
| SME Owner | a filing deadline approaches | know exactly what's owed and be warned before it's late | avoid a penalty I didn't see coming |
| Staff Bookkeeper | I log a purchase or expense | be told when something looks like it won't be VAT-recoverable | not create a problem the Owner discovers on audit |
| Accounting Firm | I take on a new client | bring their business onto the platform and manage it alongside my other clients | serve more clients without more overhead per client |
| Platform Admin | a business signs up | get them productive quickly with the right plan and limits | grow the platform's revenue without manual overhead per Tenant |
| FTA Auditor *(indirect)* | I review a Tenant's records | find complete, unaltered, correctly-numbered documentation | trust the business's filings without a lengthy investigation |

---

## 7. Product Scope

**Resolution of the MVP-vs-vision tension**: the MVP is the direct-SME, single-Tenant daily-operations loop (Modules 0–3) built on RBAC-as-data and a configuration cascade from day one. Firm/multi-tenant management, advanced automation, and AI are real, committed, but sequenced into V1 and Future — not MVP — because they are either blocked on an unresolved architecture decision ([§23]) or not yet needed to prove the core loop.

| Scope | Includes | Rationale |
|---|---|---|
| **MVP** | Platform Admin & Tenant management (built); Business Profile, Customers, Suppliers, Products/Services, Settings cascade (numbering, payment terms, locale, branding, approval threshold); Sales Invoices, Simplified Invoices, Credit/Debit Notes; Purchases & Expenses with recoverability classification; basic payment status tracking (paid/unpaid/partial) on invoices; VAT Return generation and filing-period tracking; operational reports (sales/purchase registers, customer/supplier statements); RBAC-as-data with system-defined roles (Owner, Staff); email notifications via a provider-abstracted interface; feature flags generalizing the existing plan-tier gating. | Proves the core loop end-to-end for a single business, on foundations that don't need a rewrite for what comes next. |
| **V1** | Firm/Practice management (multi-Tenant access, pending [§23]'s architecture resolution); custom role definitions beyond the system-defined set; Audit Log viewer and fine-grained permissions (Module 4); full payment reconciliation; UAE e-invoicing compliance (Peppol/PINT AE — mandatory from Jan/Jul 2027, a real deadline, not speculative); SMS/WhatsApp notification channels; per-Tenant feature-flag overrides; Arabic/bilingual UI (if market signal confirms it). | Expansion segment (Firms) and regulatory deadlines that must land before 2027, sequenced after the core loop is proven. |
| **Future** | OCR for purchase invoices (Module 5); AI bookkeeping assistant, AI-generated reports/insights; Analytics Dashboard (cross-period BI, distinct from operational reports); workflow engine generalization (beyond the MVP's single approval threshold); global search, command palette, saved views, favorites; deep third-party integrations (payment gateways, banking, accounting software, ERP/CRM, government APIs); push/Slack/webhook notification channels; Capital Assets Scheme, Tax Group registration, full Designated Zone support ([KB §6.1]/[§1.1]/[§3.4]) — real UAE VAT mechanisms, low-frequency for the target SME segment. | High-value, genuinely future capabilities — named and architected for, not scoped into near-term delivery. |
| **Out of Scope** | Self-service Tenant signup (Platform-Admin-onboarded by design); full payroll/ERP functionality; tax jurisdictions outside the UAE; automated legal/tax advice exercising independent judgment; direct EmaraTax filing submission (generate-for-filing only, unless [§23] resolves otherwise); a custom-fields engine; a visual workflow builder. | Deliberately excluded — see [ADR §13.3] and the Review's explicit "won't build yet" guidance; revisit only via explicit decision. |

---

## 8. User Journeys

Four journeys illustrate the product end-to-end, cutting across the transactional workflow list already detailed in the [Product Bible §6](product-bible.md#6-business-workflows):

**1. First 30 days (SME Owner).** Platform Admin onboards the business and its Owner → Owner sets up Business Profile, numbering, and branding once → Owner or Staff issues their first invoice within the first session, correctly classified without needing to know why → by day 30, enough invoices and expenses exist that the VAT Return for the first filing period is substantially pre-assembled.

**2. The daily habit loop (Owner/Staff).** A sale happens → an invoice is issued from a phone in the field → a purchase is logged the same day → over weeks, this becomes the natural way the business records what happened, not an extra step layered on top of "real" bookkeeping done elsewhere.

**3. Filing day (Owner, or eventually a Tax Agent).** The filing-period deadline approaches → the system has already been surfacing the countdown and the concrete penalty at stake → the VAT Return is reviewed, not built from scratch → filing is a 10-minute confirmation, not a multi-day reconciliation project.

**4. A Firm takes on a client (V1).** An Accounting Firm onboards a new client business onto Ledger → the client's Tenant is fully isolated from the Firm's other clients → the Firm's staff work across their portfolio of clients from one login → this journey cannot ship until [§23]'s access-model question is resolved, and is intentionally sequenced after Journeys 1–3 are proven.

---

## 9. Modules & Responsibilities

Resolves the Product Bible's module map with the Review's two structural corrections: Configuration is folded into Module 1 (not left homeless), and Payments plus the Audit Log **write path** are pulled into Module 3 (not deferred to Module 4, since the underlying event-capture pattern is cheap once it exists).

| Module | Responsibility | Scope tier |
|---|---|---|
| **0 — Platform & Tenant Management** | Platform Admin identity; Tenant lifecycle (onboarding, plan, suspension); Tenant User identity. | MVP — built |
| **1 — Tenant Foundation & Configuration** | Business Profile; Customers; Suppliers; Products/Services; the settings cascade (numbering, payment terms, locale, branding, approval threshold); system-defined RBAC roles. | MVP |
| **2 — Invoicing** | Sales/Simplified Invoices, Credit/Debit Notes, discounts, multi-category VAT line items, invoice numbering, email notification on issuance. | MVP |
| **3 — VAT Position, Reporting & Payments** | Purchases/Expenses with recoverability; VAT Return generation; filing-period tracking; operational reports; basic payment status tracking; Audit Log write path (event capture begins here, even though the viewer ships in Module 4). | MVP |
| **4 — Access Control** | Custom role definitions; fine-grained permission management UI; Audit Log viewer; MFA rollout beyond Platform Admin. | V1 |
| **5 — Automation** | Supplier-invoice OCR upload and review. | Future |
| **Cross-cutting: Firm/Multi-Tenant Management** | Does not map to a single module — an access-model layer once [§23] resolves it, touching Module 0 (identity) and Module 1 (Business Profile access) most directly. | V1, blocked on [§23] |

---

## 10. Functional Requirements

Stated as business capabilities, not implementation detail. Full backlog-level requirements remain in the [Product Bible §8](product-bible.md#8-functional-requirements); this table is the MPS-level summary each capability rolls up to.

| Capability | MVP | V1 | Future |
|---|:---:|:---:|:---:|
| Platform Admin can onboard and manage Tenants | ✅ | | |
| Tenant can manage its own Business Profile, Customers, Suppliers, Products/Services | ✅ | | |
| Tenant can configure numbering, payment terms, locale, branding, approval threshold | ✅ | | |
| Tenant can issue compliant Sales/Simplified Invoices and Credit/Debit Notes | ✅ | | |
| Tenant can record Purchases/Expenses with automatic recoverability classification | ✅ | | |
| Tenant can generate a VAT Return and operational reports from real transactions | ✅ | | |
| Tenant can track basic invoice payment status | ✅ | | |
| System notifies on filing deadlines and carry-forward expiry | ✅ | | |
| Tenant receives email notifications (invoice sent, etc.) | ✅ | | |
| A Firm can manage multiple client Tenants | | ✅ | |
| Tenant can define custom roles beyond Owner/Staff | | ✅ | |
| Tenant can view a full Audit Log | | ✅ | |
| Platform supports UAE e-invoicing (Peppol/PINT AE) | | ✅ | |
| Tenant can reconcile payments against bank/gateway activity | | ✅ | |
| Supplier invoices can be OCR-processed | | | ✅ |
| AI-assisted bookkeeping, insights, and reporting | | | ✅ |
| Global search, command palette, saved views | | | ✅ |
| Third-party integrations (payments, banking, ERP/CRM, government) | | | ✅ |

---

## 11. Non-Functional Requirements

| Category | MVP Bar | Future Bar |
|---|---|---|
| **Performance** | List/report endpoints stay responsive at single-Tenant transaction volumes typical of an SME. | Pagination and query optimization as Firm-scale, multi-Tenant volumes arrive. |
| **Availability** | No formal SLA pre-launch; qualitative reliability expectation. | Numeric SLA once a deployment vendor and paying customers exist. |
| **Scalability** | Stateless backend, pooled multi-tenancy — horizontal scaling is an infrastructure choice, not a redesign. | Row-Level Security as defense-in-depth on Postgres; Firm-scale access patterns. |
| **Mobile & Usability** | Every MVP capability fully functional on phone, tablet, desktop. | Global search, command palette, saved views, quick actions. |
| **Auditability** | Every reported figure traceable to a source transaction; audit events captured for defined sensitive actions from Module 3 onward. | Full Audit Log viewer, exportable compliance reports. |
| **Data Portability** | None committed at MVP — flagged risk, see [§21]. | Tenant data export, third-party integration mappings. |
| **Localization** | English UI; AED currency and UAE date conventions by default. | Arabic/bilingual UI if market signal confirms demand. |
| **Backup & Recovery** | Daily automated backups, encrypted at rest, at minimum. | Documented RPO/RTO targets and drilled DR runbook once a vendor is chosen. |

---

## 12. Business Rules

The [UAE VAT Knowledge Base](knowledge-base/README.md) is the authoritative source for VAT rules — restated in full in the [Product Bible §7](product-bible.md#7-business-rules). At the MPS level, three cross-cutting rules matter more than any single VAT figure, because they shape architecture, not just calculation:

1. **Issued financial documents are immutable.** No Invoice, Credit Note, or Debit Note is ever edited or hard-deleted after issuance; corrections are always new, linked records ([KB §5.1]/[§5.3]).
2. **Every legally-significant fact is captured as it was true at the time, not looked up live later.** Business Profile details, VAT rates, and exchange rates are snapshotted onto the document they appear on ([KB §1.3]/[§8.3]).
3. **VAT correctness rules apply continuously during normal use**, not as a separate filing-time pass — the practical embodiment of Compliance by Default ([§3]).

---

## 13. Multi-Tenant Strategy

**Pooled multi-tenancy** — one platform, one shared data store, every Tenant-owned record scoped by a Tenant identifier derived exclusively from a verified session, never supplied by the client ([ADR §7]). This is the platform's foundational security guarantee and is not renegotiated by any capability in this document, including Firm access.

**Extending to Firm access, without weakening isolation:** a Firm managing multiple Tenants is an *access* concept layered on top of this model, not a change to it. Whatever mechanism resolves [§23]'s open question, it must preserve two properties absolutely: (a) a Tenant's data is never reachable by a Firm that hasn't been explicitly granted access, and (b) that grant is Tenant-controlled and revocable, not Firm- or Platform-initiated unilaterally — the latter also satisfies the compliance expectation in [§17].

**Isolation extends beyond data**: storage (documents, future OCR uploads) and audit trails are isolated per Tenant with the same rigor as transactional data — "storage isolation" and "audit isolation" are not new concepts requiring new mechanisms, they are the same JWT-derived-identity guarantee applied to two more subsystems.

---

## 14. RBAC Strategy

**Resolution of a real inconsistency**: the Product Bible treated fine-grained RBAC as Module 4's job; the Architecture Review correctly identified that RBAC must be *modeled as data* starting in Module 1, or every module built before Module 4 accumulates hardcoded role checks that later need to be torn out. This document adopts the Review's position as final: **RBAC is data from day one; RBAC *tooling* (custom roles, delegated administration) is V1.**

Concretely: access decisions are always evaluated as "does this identity hold a permission for this action on this module," never "is this identity's role string equal to a specific value." The MVP ships with a small, fixed set of system-defined roles (Platform Admin, Owner, Staff) expressed through this model — not as an exception to it. Custom roles, permission templates, and delegated administration (a Firm defining roles scoped to the Tenants it manages) are V1 additions to the same model, not a redesign of it.

Least privilege is the default posture: a new role starts with no permissions, not all-minus-a-blocklist.

---

## 15. Configuration Strategy

**Configuration over customization, scoped honestly.** A layered cascade — platform-wide defaults → subscription plan → Tenant-level settings — determines behavior that would otherwise be a code branch. The MVP's configuration surface is deliberately narrow and concrete, not a general-purpose settings framework:

| Configurable now (MVP) | Deferred (V1/Future) |
|---|---|
| Invoice/document numbering format and reset cadence | Custom fields on any record |
| Default payment terms | Visual workflow builder |
| Locale: date format, currency display, language | Rich notification-preference center |
| Branding basics (logo, footer) on documents | Multi-template branding system |
| A single approval threshold (invoice value requiring sign-off) | General configurable approval chains |
| Feature availability by subscription plan | Per-Tenant feature-flag overrides |

The distinction that matters: every item above is a **value** a Tenant sets, read by a fixed piece of logic — not a **rule structure** a Tenant defines. The latter (custom fields, workflow builder, configurable approval chains) is where "configuration" quietly becomes "build a low-code platform," which is explicitly a Future investment, not an MVP one, per Principle 8 ([§3]).

---

## 16. Security Principles

(Full control-by-control detail lives in the [Architecture Review §10](reviews/0001-enterprise-platform-review.md#10-security-requirements) and [ADR §5]/[§6]/[§10]; these are the principles that detail serves.)

- **Identity is always verified server-side; authorization is always derived from it** — never from client-supplied identifiers.
- **Least privilege by default**, enforced through the RBAC model in [§14], not exceptions layered on top of a permissive default.
- **Encryption is non-negotiable**, at rest and in transit, regardless of hosting vendor.
- **Financial and compliance records are immutable and never hard-deleted** — corrections are new records; deletion (where it exists at all, e.g. a draft Customer) is soft and reversible.
- **Every privileged action is auditable**, and the audit trail itself is tamper-evident and retained at least as long as the records it describes.
- **Sensitive entry points (login, password reset) are rate-limited**; credentials follow a real password policy; multi-factor authentication protects the highest-blast-radius identities first (Platform Admin), extending outward.
- **Sessions are short-lived and revocable** — a password change or an administrative action should be able to end an active session, not just prevent new ones.

---

## 17. Compliance Principles

- **UAE VAT correctness is enforced continuously**, not checked at filing time — the practical form of Compliance by Default.
- **Records are retained for exactly as long as UAE law requires** (5/10/15 years by record type, [KB §8.2]) and never shorter — retention is an architectural constraint (no premature deletion path), not a policy honored by convention.
- **Data protection follows the principle that a Tenant owns its own business data.** Any party accessing it on the Tenant's behalf — a Firm, a Tax Agent — does so under an explicit, Tenant-granted, Tenant-revocable permission, consistent with UAE PDPL's controller/processor framing. This is a requirement on the eventual Firm-access design, not an implementation detail.
- **The platform tracks its regulatory obligations proactively**, not reactively — the UAE e-invoicing mandate (confirmed dates in [KB §5.1]) is treated as a committed V1 deadline, not a "future" maybe.

---

## 18. Reporting Strategy

A four-tier maturity ladder, resolving the Bible's scattered references to "operational reports," "VAT returns," and "Analytics Dashboard" into one coherent progression:

| Tier | What it is | Scope |
|---|---|---|
| 1. **Operational Reports** | Sales/purchase registers, customer/supplier statements — the records a business needs to run itself day to day. | MVP |
| 2. **Compliance Reports** | The VAT Return and its supporting breakdown, generated from the same underlying transactions as Tier 1 — never a separately-entered figure. | MVP |
| 3. **Analytics Dashboard** | Cross-period trends, comparative business intelligence — a distinct, later capability, not an extension of Tier 1's simple registers. | Future |
| 4. **AI-Generated Insights** | Natural-language summaries and proactive recommendations built on Tiers 1–3's data. | Future |

Every tier obeys one non-negotiable rule: **a reported number is only ever derived from real transactions, never independently entered** — the same "correct by construction" property this document applies to VAT figures now applies to every report.

---

## 19. AI & Integration Vision

Neither AI nor third-party integrations ship in the MVP. Both are architected for now by holding two disciplines already committed elsewhere in this document: **business logic lives in clean, single-purpose service functions** ([§3] Principle 9), which is exactly the boundary a future AI assistant would call or learn from; and **data is captured as structured facts** (a VAT category, a customer reference, a recoverability status), not just rendered documents, which is exactly what AI-generated insights and third-party integrations both need to consume.

**AI maturity path:** OCR (structured data extraction from documents, Future) → AI Bookkeeping Assistant (using the same classification logic already built for human users) → AI-generated Reports/Insights (Tier 4 of [§18]) → conversational assistant. Each stage depends on the one before it; none are sequenced ahead of a real product need.

**Integration maturity path:** REST API with a documented contract (a natural artifact of the service-layer discipline, not new work) → webhooks for event notification → specific integrations (payment gateways, banking, accounting software, government APIs) built against real customer demand, not spec'd speculatively.

---

## 20. Success Metrics

| Metric | Why it matters | Horizon |
|---|---|---|
| Weekly-active-Tenant rate (logging real transactions, not just logging in) | Direct measure of "daily operating system," not "quarterly filing tool" | MVP |
| Time from onboarding to first issued invoice | Onboarding friction, correlates with retention | MVP |
| Penalty-avoidance rate (deadlines met, no late-filing incidents among active Tenants) | The core compliance value proposition, made measurable | MVP |
| % of VAT Return figures requiring manual correction before filing | Direct proxy for "correct by construction" actually working | MVP |
| Mobile/tablet session share | Validates Mobile First as more than a stated principle | MVP |
| Firm-segment share of total ARR | Tracks the second commercial segment's real traction, informs V1 prioritization | V1 |
| Tenants under active Firm management | Validates the Firm access model was worth building | V1 |

---

## 21. Risks & Assumptions

The full, actively-maintained register is [Product Bible §12](product-bible.md#12-assumptions) (21 rows and growing); these are the handful with strategic, not just implementation, consequence:

| Risk / Assumption | Consequence if unresolved | Status |
|---|---|---|
| Firm/multi-Tenant access mechanism undecided | Blocks the entire V1 Firm segment and the RBAC model's final shape | Needs its own ADR — [§23] |
| No deployment vendor chosen | Blocks quantified NFRs, backup/DR targets, and any production timeline | Needs decision — [ADR §12] |
| PDPL/data-protection posture under-researched | Firm-access consent model could be built non-compliant | Needs research, tied to the Firm ADR |
| Configuration cascade could quietly grow into a low-code platform if not scoped disciplined | Reintroduces the platform-before-product risk this whole document is designed to prevent | Actively mitigated by [§15]'s explicit "now vs. deferred" table |
| Two-horizon vision could be read as "build generic now" by an eager team | Same platform-before-product risk, applied to the whole document, not just Configuration | Actively mitigated by [§7]'s explicit MVP scope and Principle 8 |
| E-invoicing technical spec still evolving (updated once already in 2026) | V1 e-invoicing work could target a stale spec | Re-verify against [KB §5.1] immediately before that work starts |

---

## 22. Product Roadmap

| Phase | Scope | Depends on |
|---|---|---|
| **Phase 0** | Resolve Firm-access architecture ([§23]); finalize RBAC data model, configuration cascade, notification abstraction, feature-flag service design — as design work, not features. | Nothing — this is the prerequisite for everything else. |
| **MVP (Modules 0–3)** | Direct-SME daily operating loop: Tenant Foundation & Configuration, Invoicing, VAT Position/Reporting/Payments, on the Phase 0 foundations. | Phase 0 |
| **V1 (Module 4 + Firm layer)** | Firm/multi-Tenant management, custom roles, Audit Log viewer, e-invoicing compliance, payment reconciliation, additional notification channels. | MVP proven; [§23] resolved |
| **Future (Module 5+)** | OCR, AI capabilities, Analytics Dashboard, workflow engine generalization, UX layer (search/command palette), third-party integrations, low-frequency VAT mechanisms (Capital Assets Scheme, Tax Groups, Designated Zones). | V1 proven; real demand signal |
| **Horizon 2** | Generalize proven engines beyond UAE VAT to other compliance regimes/industries. | Horizon 1 (MVP + V1 + Future) has demonstrated product-market fit. |

---

## 23. Open Decisions

Genuinely unresolved — each requires either a dedicated ADR (architectural) or an explicit stakeholder call (commercial/legal) before the dependent work can start. Nothing in this list is defaulted by this document.

| # | Decision | Type | Blocks |
|---|---|---|---|
| 1 | Firm/multi-Tenant cross-access mechanism | Architecture (ADR) | V1 Firm segment, final RBAC shape |
| 2 | Deployment hosting vendor | Architecture (ADR) | Quantified NFRs, backup/DR targets |
| 3 | Direct EmaraTax filing integration vs. generate-only | Product/commercial | Module 3's final scope |
| 4 | TypeScript adoption timing | Architecture (ADR) | Engineering execution, not product scope |
| 5 | PDPL compliance posture for Firm data access | Legal/compliance | Firm-access ADR's scope (must be an input to Decision 1, not follow it) |
| 6 | Audit Log depth by plan tier, given "complete audit history" is now a baseline expectation | Product/commercial | Module 3/4 scope, pricing |
| 7 | Capital Assets Scheme / Tax Group / Designated Zone support | Product/commercial | Whether these ever leave "Future" |
| 8 | Arabic/bilingual UI timing | Product/commercial | V1 vs. Future placement |

---

This document supersedes the individual source documents as the **first thing to read** about Ledger. It does not supersede their authority within their own domain: architectural decisions are still governed by [ADR-0001](adr/0001-baseline-architecture.md) and its change-control process, and every UAE VAT figure or rule is still sourced from the [Knowledge Base](knowledge-base/README.md), not restated or reinterpreted here.
