# Ledger — Platform Architecture Specification (PAS)

- **Status:** Version 1 — authoritative technical architecture reference
- **Date:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Synthesized from:** [Master Product Specification](master-product-specification.md), [Product Bible v2](product-bible.md), [ADR-0001](adr/0001-baseline-architecture.md) (Accepted), [UAE VAT Knowledge Base](knowledge-base/README.md), the [Enterprise Platform Review](reviews/0001-enterprise-platform-review.md).
- **Relationship to ADR-0001:** this document does not override any Accepted ADR-0001 decision — it organizes those decisions into one technical blueprint and extends them where the MPS made a product-level call that now needs an architectural shape (most notably: RBAC-as-data). Any point below that would change an ADR-0001 decision is called out explicitly and routed to [§25 Open Architecture Decisions](#25-open-architecture-decisions), never silently redefined here, per [ADR §13.3].
- **Audience:** every engineer building on Ledger, before any Module 1+ code is written.
- **Tiering convention used throughout:** **[Build Now]** — required for the MVP · **[Design Now, Build Later]** — interface/contract decided now, fuller implementation deferred to V1/Future · **[Future Vision]** — named and architecturally accommodated, not designed in detail yet.

---

## 1. Executive Summary

This document answers *how* Ledger is built; the [Master Product Specification](master-product-specification.md) already answered *what* and *why*. The architecture is a **modular monolith organized around Domain-Driven Design boundaries**, not a scatter of controllers-and-tables, and not a premature microservices split either. One deployable backend, internally partitioned into domain modules that own their own data and expose their own service interfaces, sitting on a shared set of cross-cutting platform services (Auth, RBAC, Tenant Management, Configuration, Feature Flags, Notifications, Audit, Numbering, File Storage).

The ten-year survivability bet is not "predict the future correctly" — it's **keep domain logic decoupled from delivery mechanism and from other domains**, so that whichever future turns out to be right (multi-industry expansion, a Firm-access layer, extracting Notifications or AI processing into their own service, a completely different frontend), the change is additive at a module boundary, not a rewrite of the core. Every principle in this document exists to protect that property.

Nothing here is a database schema, an API contract, or a folder structure — those are engineering design artifacts that follow this document, module by module, and are reviewed against it.

---

## 2. Architectural Goals

| Goal | Why it matters | How this architecture achieves it |
|---|---|---|
| **Modularity** | Ten-year survivability; the vision itself (Horizon 2) depends on generalizing without rewriting. | Domain modules with owned data and published interfaces ([§6], [§7], [§21]). |
| **Scalability** | Firm-scale usage and eventual multi-industry load, without a redesign. | Stateless services, pooled multi-tenancy, horizontal scaling ([§16]). |
| **Security & Isolation** | Financial/compliance data for multiple businesses in one system. | Structural (not procedural) tenant and permission boundaries ([§9], [§10]). |
| **Maintainability** | One rule, one implementation; no duplicated business logic. | Cross-cutting services as the single home for shared concerns ([§8]). |
| **Extensibility** | Configuration/RBAC/Notification engines must grow without redesign. | Interface-first design on cross-cutting services ([§8], [§11]). |
| **Compliance-by-construction** | VAT correctness is a product promise, not a QA checklist. | Domain logic centralizes rules; nothing bypasses it ([§6], [§19]). |
| **Developer velocity without chaos** | A small team must move fast now without inventing distributed-systems problems. | Modular monolith, not microservices, until proven necessary ([§3], [§16]). |
| **Testability** | Business logic must be verifiable independent of HTTP. | Service-layer isolation from the API layer ([ADR §13.1], [§4]). |

---

## 3. Architecture Principles

| # | Principle | Rationale |
|---|---|---|
| 1 | **Modular monolith first; microservices only if proven necessary.** | Distributed systems solve a scaling problem this platform does not have yet. Module boundaries are designed so a domain *can* be extracted later without redesign — but nothing is extracted speculatively. |
| 2 | **Composition over coupling.** | Domain modules consume cross-cutting services through defined interfaces; they never reach into another module's internals or another service's implementation details. |
| 3 | **Domain logic is independent of delivery mechanism.** | Business rules live in the service layer ([ADR §13.1]); the HTTP layer is a thin adapter. A future GraphQL API, CLI, or AI orchestration layer calls the same services a controller does today. |
| 4 | **Tenant context is explicit, structural, and non-negotiable.** | Every cross-domain and cross-service call carries a verified tenant identity; nothing computes tenant-scoped data by convention or trust ([ADR §6]/[§7], unchanged here). |
| 5 | **Additive evolution over rewrites.** | Schema and module changes default to additive; destructive change requires deliberate, approved exception ([ADR §5], [§23]). |
| 6 | **Build the seam, not the engine.** | Every cross-cutting service gets a real interface and a minimal implementation now; richer implementations arrive when three real cases justify them, not speculatively ([§8]). |
| 7 | **One rule, one implementation.** | Every business rule (VAT or otherwise) has exactly one owning service function; nothing is reimplemented per caller. |
| 8 | **Security and isolation are structural, not procedural.** | Isolation holds because the architecture makes violating it hard to do by accident, not because a code reviewer remembers to check ([§9], [§10]). |
| 9 | **Least coupling, most clarity.** | A module's public interface is small and intention-revealing; its internals are free to change without breaking callers. |

---

## 4. Platform Architecture Overview

Five horizontal layers. Requests flow top to bottom; domain logic never flows back up into the API layer, and cross-cutting services never depend on domain modules.

```mermaid
graph TD
    subgraph Client["Client Layer"]
        WEB["Responsive Web App (Mobile-First)"]
        FUTURE_CLIENT["[Future Vision] Native / Partner Clients"]
    end

    subgraph API["API / Interface Layer — thin adapters only"]
        REST["REST API (versioned when needed)"]
        WEBHOOK["[Design Now, Build Later] Webhook Dispatch"]
    end

    subgraph Platform["Cross-Cutting Platform Services"]
        AUTH["Authentication"]
        RBAC["Authorization (RBAC)"]
        TENANT["Tenant Management"]
        CONFIG["Configuration"]
        FLAGS["Feature Flags"]
        NOTIFY["Notifications"]
        AUDIT["Audit Logging"]
        NUMBER["Numbering"]
        STORAGE["File Storage"]
    end

    subgraph Domains["Core Domain Modules"]
        FOUNDATION["Tenant Foundation"]
        INVOICING["Invoicing & Trade Documents"]
        VATCORE["VAT Compliance & Reporting"]
        ACCESS["Access Control"]
        AUTOMATION["[Future Vision] Automation & Intelligence"]
    end

    subgraph Data["Data Layer"]
        DB[("Pooled Multi-Tenant Data Store")]
        OBJSTORE[("Object Storage — tenant-isolated")]
    end

    subgraph External["External Systems"]
        EMARATAX["FTA / EmaraTax (no direct integration yet)"]
        PEPPOL["[Design Now, Build Later] Peppol E-Invoicing Network"]
        PAYFUT["[Future Vision] Payment / Banking / ERP / CRM"]
    end

    Client --> API
    API --> Platform
    API --> Domains
    Domains --> Platform
    Platform --> Data
    Domains --> Data
    API -.future.-> PEPPOL
    API -.future.-> PAYFUT
    Domains -.manual today.-> EMARATAX
```

The Cross-Cutting Platform Services layer sits **beside** the API layer and **beneath** the domain modules conceptually — both the API layer and domain modules depend on it, it depends on neither. This is what makes "add MFA," "add a notification channel," or "add a feature flag override" changes to one place, not N places.

---

## 5. System Context

```mermaid
graph LR
    Owner["SME Owner"] --> Ledger
    Staff["Staff / Bookkeeper"] --> Ledger
    PlatformAdmin["Platform Admin"] --> Ledger
    Firm["[Design Now, Build Later] Accounting Firm"] -.pending Open Decision 1.-> Ledger
    TaxAgent["[Design Now, Build Later] External Tax Agent"] -.-> Ledger

    Ledger(["Ledger Platform"])

    Ledger -.manual filing today.-> FTA["FTA / EmaraTax"]
    Ledger -.["Design Now, Build Later"].-> Peppol["Peppol E-Invoicing Network"]
    Ledger -.["Future Vision"].-> Payments["Payment Gateways / Banking"]
    Ledger -.["Future Vision"].-> Accounting["External Accounting / ERP / CRM"]
    Ledger -.["Future Vision"].-> AIProviders["AI / OCR Providers"]
```

| Actor / System | Relationship | Status |
|---|---|---|
| SME Owner, Staff | Primary users of a Tenant | Built |
| Platform Admin | Onboards and manages Tenants; never sees Tenant financial detail | Built |
| Accounting Firm, External Tax Agent | Manage or review multiple/one Tenant(s) | **[Design Now, Build Later]** — blocked on [§25 Decision 1] |
| FTA / EmaraTax | Businesses file manually today; no API integration exists or is confirmed available | Out of scope unless [Open Decision, MPS §23.3] resolves otherwise |
| Peppol E-Invoicing Network | Confirmed mandatory 2027 regulatory requirement | **[Design Now, Build Later]** |
| Payment Gateways, Banking, ERP/CRM, AI/OCR Providers | Future integrations, demand-driven | **[Future Vision]** |

---

## 6. Core Domains

Domains are classified using DDD's Core / Supporting / Generic subdomain distinction — this classification is what determines *how much architectural investment* each domain deserves, not just what it does.

| Domain | DDD Classification | Responsibility | Depends on |
|---|---|---|---|
| **VAT Compliance & Reporting** | **Core** — the platform's actual competitive differentiator | Classifies, calculates, and reports every UAE VAT outcome ([KB]); owns the VAT Return generation logic | Tenant Foundation (for VAT rate/settings) |
| **Invoicing & Trade Documents** | **Core** — tightly coupled to VAT Compliance but a distinct responsibility (document lifecycle vs. tax calculation) | Sales/Simplified Invoices, Credit/Debit Notes, document numbering, immutability rules | VAT Compliance, Tenant Foundation, Numbering, Notifications |
| **Tenant Foundation** | **Supporting** — necessary, not differentiating | Business Profile, Customers, Suppliers, Products/Services, the Configuration cascade's Tenant layer | Configuration, Tenant Management |
| **Identity & Access** | **Supporting**, but architecturally the most complex domain right now | Platform Admin, Tenant Users, RBAC, the still-open Firm-access layer | Authentication, Authorization |
| **Platform Operations** | **Generic** — commodity capability, built in-house today for simplicity | Tenant lifecycle, subscription/plan administration | Tenant Management, Feature Flags |
| **Automation & Intelligence** | **[Future Vision]**, potentially Core later | OCR, AI bookkeeping/insights | File Storage, VAT Compliance, Invoicing (as a consumer of their service interfaces) |

```mermaid
graph TD
    TF["Tenant Foundation (Supporting)"]
    VC["VAT Compliance & Reporting (Core)"]
    INV["Invoicing & Trade Documents (Core)"]
    PO["Platform Operations (Generic)"]
    IA["Identity & Access (Supporting)"]
    AI_["[Future Vision] Automation & Intelligence"]

    VC --> TF
    INV --> VC
    INV --> TF
    PO --> TF
    AI_ -.future.-> VC
    AI_ -.future.-> INV
```

**Why this classification matters architecturally**: Core domains (VAT Compliance, Invoicing) get the most design rigor, the most test coverage, and the least willingness to take shortcuts — they're what customers are actually paying for correctness on. Supporting and Generic domains (Tenant Foundation, Platform Operations, Identity) should be built *well* but *simply* — a generic subdomain that's over-engineered is wasted effort that should have gone into the Core. This is also precisely what makes Horizon 2 (multi-industry expansion, [MPS §22]) tractable later: the Supporting/Generic domains were never coupled to VAT specifics if this boundary is respected, so generalizing later means extending the Core domain, not untangling the whole platform.

---

## 7. Module Architecture

Modules ([MPS §9]) are the delivery-sequenced implementation of the domains above. Each module has one primary domain owner, even where it touches cross-cutting services.

| Module | Primary Domain | Depends on (cross-cutting) | Tier |
|---|---|---|---|
| 0 — Platform & Tenant Management | Platform Operations, Identity & Access | Authentication, Tenant Management | **[Build Now]** — built |
| 1 — Tenant Foundation & Configuration | Tenant Foundation | Configuration, Authorization | **[Build Now]** |
| 2 — Invoicing | Invoicing & Trade Documents | VAT Compliance (service calls), Numbering, Notifications, Authorization | **[Build Now]** |
| 3 — VAT Position, Reporting & Payments | VAT Compliance & Reporting | Invoicing/Purchases (read), Audit Logging, Authorization | **[Build Now]** |
| 4 — Access Control | Identity & Access | Authorization, Audit Logging | **[Design Now, Build Later]** |
| 5 — Automation | Automation & Intelligence | File Storage, VAT Compliance, Invoicing | **[Future Vision]** |
| Firm/Multi-Tenant layer | Identity & Access | Tenant Management, Authorization | **[Design Now, Build Later]** — blocked on [§25 Decision 1] |

**Module boundary rule**: a module may call another module's published service interface; it may never query or write another module's data directly. This is the single rule that keeps "modular monolith" from silently becoming "one big shared-everything codebase" — enforced by convention now, and by [§22]'s dependency rules.

---

## 8. Cross-Cutting Platform Services

Nine services, each a **single home** for one concern, consumed by every domain module that needs it — never reimplemented per module.

| Service | Responsibility | Tier | Key architectural discipline |
|---|---|---|---|
| **Authentication** | Verify identity; issue/validate session credentials | **[Build Now]** (dual identity space, per [ADR §5]) · MFA/revocation **[Design Now, Build Later]** | Interface supports pluggable revocation checks even before revocation ships, so it's additive later |
| **Authorization (RBAC)** | Decide "can this identity do this action" | **[Build Now]**, data-driven from Module 1 (resolves [MPS §14]'s update to the original Product Bible) | One decision point every module calls; never a role-string comparison inline |
| **Tenant Management** | Own Tenant identity and lifecycle; the source of "tenant context" | **[Build Now]** | Every other service treats this as upstream — nothing tenant-scoped resolves without it first |
| **Configuration** | Resolve effective settings via the Platform → Plan → Tenant cascade | **[Build Now]**, narrow scope per [MPS §15] | Read-heavy, single source of truth; never a hardcoded value in a module |
| **Feature Flags** | Resolve plan-derived and (later) Tenant-override capability gates | **[Build Now]**, generalizing the existing plan-features data | Distinct from Configuration — flags are binary capability gates, not behavior settings ([§12]) |
| **Notifications** | Dispatch events (email now) without callers knowing the provider | **[Build Now]** interface + email · SMS/WhatsApp **[Design Now, Build Later]** · Push/Slack/webhook **[Future Vision]** | Domain modules emit "notify this event"; they never call a provider directly |
| **Audit Logging** | Capture a defined taxonomy of sensitive actions, append-only | **[Build Now]** write path (pulled forward per [MPS §9]) · full viewer **[Design Now, Build Later]** | Distinct from operational logging ([§18]) — a compliance record, not a debugging tool |
| **Numbering** | Atomic, tenant-scoped sequential identifiers for any document type needing one | **[Build Now]** | Generalized once across Invoice/Credit Note/Debit Note/future document types — never reimplemented per type |
| **File Storage** | Store and retrieve files via tenant-isolated, signed access | **[Build Now]** interface · OCR consumption **[Future Vision]** | Domain modules request storage/signed URLs; they never touch the storage provider directly ([ADR §9], unchanged) |

**Why these nine and not more**: each maps to a concern named explicitly in the MPS or the Architecture Review as something that would otherwise be reimplemented per module (and, per the Review, hardcoded). A cross-cutting service is justified when *at least two* domain modules need the same concern — this list passes that bar; a Workflow Engine and a Search Engine currently do not (only one or zero modules need them at MVP), which is why they are **[Future Vision]**, not a tenth and eleventh entry here.

---

## 9. Multi-Tenant Architecture

Pooled multi-tenancy is unchanged from [ADR §7]: one platform, one shared data store, every Tenant-owned record scoped by a tenant identifier resolved by Tenant Management from a verified identity — never accepted from a client. This section adds the architectural shape for the Firm-access extension without weakening that guarantee.

```mermaid
graph TD
    subgraph Platform["Shared Platform (one deployment, one data store)"]
        TenantA["Tenant A — fully isolated"]
        TenantB["Tenant B — fully isolated"]
        TenantC["Tenant C — fully isolated"]
    end

    Owner["Tenant A Owner"] --> TenantA
    Firm["[Design Now, Build Later] Firm"] -."explicit, revocable grant only".-> TenantA
    Firm -.no default access.-x TenantB
    Firm -.no default access.-x TenantC
```

| Isolation axis | Mechanism | Status |
|---|---|---|
| **Data isolation** | Tenant identifier resolved server-side, required on every tenant-scoped operation | **[Build Now]**, unchanged from [ADR §7] |
| **Storage isolation** | Tenant-prefixed keys, signed per-request access ([ADR §9]) | **[Build Now]** (interface) |
| **Audit isolation** | Audit records scoped and queryable only within their owning Tenant | **[Build Now]** |
| **Firm-access isolation** | An explicit, Tenant-granted, Tenant-revocable access grant — never a broad standing credential across all Tenants | **[Design Now, Build Later]** — the *mechanism* is [§25 Open Decision 1]; the *properties* it must satisfy are fixed here and are not negotiable by whichever ADR resolves it |
| **Defense-in-depth (second layer)** | Row-Level Security at the database layer, beneath application-level scoping | **[Design Now, Build Later]** — arrives with the Postgres migration ([ADR §7]/[§4]) |

The Firm-access layer is deliberately specified here as a set of **required properties**, not a mechanism — resolving the mechanism is real architecture work reserved for its own ADR, consistent with every prior document's treatment of this question.

---

## 10. Security Architecture

A defense-in-depth model — each layer assumes the one above it could fail.

| Layer | Mechanism | Tier |
|---|---|---|
| **Edge** | Rate limiting on authentication endpoints | **[Design Now, Build Later]** — designed now, not yet built ([ADR §5] gap) |
| **Transport** | Encryption in transit, always on | **[Build Now]** |
| **Identity** | Authentication service issues short-lived, verifiable credentials per identity space | **[Build Now]**; revocation **[Design Now, Build Later]** |
| **Authorization** | RBAC service is the single decision point between a verified identity and any action | **[Build Now]** |
| **Tenant boundary** | Application-level tenant scoping, structural not procedural | **[Build Now]** |
| **Data boundary (second layer)** | Row-Level Security | **[Design Now, Build Later]** |
| **At rest** | Encryption at rest, always on regardless of hosting vendor | **[Build Now]** |
| **Record integrity** | Financial/compliance records immutable; no hard-delete path exists in the architecture, not just in policy | **[Build Now]** |
| **Audit trail** | Append-only, tamper-evident, retained per [KB §8.2] | **[Build Now]** write path |
| **Secrets** | Environment-based today; vault-based rotation | **[Build Now]** (dev-appropriate) → **[Design Now, Build Later]** (production) |
| **Recovery** | Backup with tested restore; documented RPO/RTO | **[Design Now, Build Later]** — a genuine gap this document formally closes by naming it (per the Review's finding) |

**Structural vs. procedural, made concrete**: the Tenant boundary and Authorization layers are "structural" because the architecture makes it *impossible to call a domain service without a resolved tenant/identity context* — not because a developer remembers to add a check. This is the same discipline [ADR §6]/[§7] already established for tenant scoping, now explicitly extended to authorization decisions via the RBAC service in [§8].

---

## 11. Configuration Architecture

A single cascade, one direction of precedence: **Platform default → Subscription Plan → Tenant setting**. Each layer may only *narrow or set* a value the layer above allows, never bypass it — e.g., a Plan can cap `maxUsers`, but a Tenant setting cannot raise it above that cap.

```mermaid
graph LR
    PlatformDefault["Platform Default"] --> PlanLayer["Subscription Plan"]
    PlanLayer --> TenantLayer["Tenant Setting"]
    TenantLayer --> Effective["Effective Value (what the module reads)"]
```

| Boundary | Rule |
|---|---|
| Configuration vs. Feature Flags | Configuration = a **value** a module's fixed logic reads (numbering format, payment terms, locale). Feature Flags = a **binary capability gate** (is Audit Log visible at all). Conflating these turns Feature Flags into unbounded configuration — explicitly avoided. |
| Configuration vs. a future Rules/Workflow Engine | Configuration never defines a **rule structure** (a Tenant cannot use Configuration to define a new approval chain or a computed field) — that would silently become a low-code platform, which is **[Future Vision]** by deliberate choice ([MPS §15], Review §6). Configuration Architecture and a future Workflow Engine are different systems; this document does not conflate them even though a future engine will read some of the same settings. |

**MVP scope** (per [MPS §15]): numbering format/cadence, default payment terms, locale (date/currency/language display), branding basics, a single approval threshold. Nothing beyond this list is in the Configuration Architecture's MVP surface — the boundary above exists specifically to keep that list from growing by accretion.

---

## 12. Subscription & Licensing Architecture

Two related but distinct concepts, both derived from a Tenant's Plan:

| Concept | Definition | Example | Owning service |
|---|---|---|---|
| **Entitlement** | A *quantitative* limit | Max 5 users, max 20 invoices/month | Feature Flags (limits variant) + Configuration |
| **Feature Flag** | A *qualitative* capability gate | Audit Log visible, OCR available | Feature Flags |

Both already exist in embryonic form in Module 0's plan-limits data; this architecture formalizes them as the same underlying cascade from [§11], read through the Feature Flags service so no module ever branches on a raw plan-name string. The Firm-level commercial model ([MPS §5]) extends this cascade with a Firm layer sitting alongside or above individual Tenant plans — its exact shape is part of [§25 Open Decision 1]'s resolution, since it depends on the same access-model question.

---

## 13. Reporting Architecture

Reports are **always computed from domain data**, never independently stored — the architectural expression of [MPS §18]'s "correct by construction" rule.

| Tier | Architectural approach | Tier status |
|---|---|---|
| 1–2. Operational & Compliance Reports | Direct queries against domain modules' own data, via each domain's service interface | **[Build Now]** |
| 3. Analytics Dashboard | Cross-domain aggregation at meaningful scale may eventually justify a dedicated read model (a CQRS-lite pattern: a query-optimized projection separate from the transactional domain data) | **[Design Now, Build Later]** — name the pattern now, do not build it for MVP; direct queries are sufficient at MVP data volumes |
| 4. AI-Generated Insights | Consumes Tier 1–3 data through the same service interfaces an AI orchestration layer would use ([§15]) | **[Future Vision]** |

Full CQRS (separate write and read models everywhere) is explicitly **not** adopted platform-wide — it solves a scale problem this platform doesn't have yet, and would contradict the "avoid overengineering the MVP" instruction. It is named here only as the pattern to reach for *if and when* Tier 3 genuinely needs it.

---

## 14. Integration Architecture

| Layer | Description | Tier |
|---|---|---|
| REST API | The same service interfaces internal callers use, exposed externally — no parallel "integration API" with different rules | **[Build Now]**, unversioned until the first breaking change ([ADR §8]) |
| Webhooks | Event notifications for external systems, built on the same event vocabulary Audit Logging and Notifications already use internally | **[Design Now, Build Later]** |
| Specific integrations (payment gateways, banking, accounting software, ERP/CRM, government APIs) | Each is an adapter behind a domain module's service interface, not a new access path into the platform | **[Future Vision]**, demand-driven |
| UAE e-invoicing (Peppol/PINT AE) | A confirmed regulatory integration, not speculative — treated with the urgency of a compliance deadline, not a generic future integration | **[Design Now, Build Later]**, timed against the 2027 mandatory dates ([KB §5.1]) |

**Principle**: every external integration authenticates and is authorized exactly like an internal caller — through Authentication and RBAC ([§8]), scoped to a Tenant, never a bypass path. This is what makes future integrations additive rather than a parallel security model to maintain.

---

## 15. AI Readiness Architecture

AI is not built in the MVP; the architecture is shaped so it doesn't require a redesign later.

| Enabler already in this architecture | Why it matters for AI |
|---|---|
| Domain logic in clean, single-purpose service functions ([§3] Principle 3, [§6]) | A future AI orchestration layer calls the same service functions a human-driven UI calls — it is another caller behind the same RBAC/tenant boundary, not a parallel system |
| Structured data over rendered documents ([KB]'s VAT categorization, recoverability status) | AI-generated insights and OCR-extracted data both need structured facts to reason over, which the Core domains already produce as a byproduct of correctness |
| File Storage as an abstracted service ([§8]) | OCR consumes files the same way any other module would — through the interface, not a bespoke path |

**AI maturity path**: OCR (structured extraction from uploaded documents) → AI Bookkeeping Assistant (reuses the classification logic already built for human users in VAT Compliance) → AI-Generated Reports/Insights (Reporting Tier 4, [§13]) → conversational assistant. Every stage is **[Future Vision]**; none is sequenced ahead of a proven need, per [§3] Principle 6.

---

## 16. Scalability Strategy

| Dimension | Approach | Tier |
|---|---|---|
| Compute | Stateless backend; horizontal scaling is an infrastructure decision, not an architecture change ([ADR §5]/[§12]) | **[Build Now]** |
| Data | Pooled multi-tenancy avoids per-Tenant infrastructure overhead as the customer count grows | **[Build Now]** |
| Hot domains | Module boundaries ([§7], [§21]) preserve the *option* to extract a domain (e.g., Notifications, or future OCR/AI processing) into its own deployable service if it becomes a genuine scaling or team-ownership bottleneck | **[Design Now, Build Later]** — the option is preserved by discipline now; extraction itself is not planned |
| Firm scale | Multi-Tenant access patterns at Firm scale (dozens of Tenants per Firm user) are a load-pattern this architecture must remain correct under once [§25 Decision 1] resolves | **[Design Now, Build Later]** |

Explicitly **not** adopted now: microservices, a message queue/event bus, or a distributed cache — each solves a problem this platform does not yet have, and each would violate "avoid unnecessary enterprise complexity in the MVP." They remain available future options precisely because the module boundaries below don't preclude them.

---

## 17. Reliability & Resilience Principles

| Principle | Application |
|---|---|
| **Idempotency for sensitive operations** | Numbering allocation and financial document issuance must behave correctly under retry/concurrency — a conceptual requirement on those services' design, not an implementation detail here. |
| **Graceful degradation across service boundaries** | If Notifications is unavailable, Invoice issuance still succeeds; the notification is queued/retried rather than blocking the core operation — a direct payoff of Composition over Coupling ([§3]). |
| **Backup & recovery is an explicit reliability requirement**, not an afterthought | Daily automated backups with tested restore as a floor; RPO/RTO targets once a deployment vendor is chosen ([ADR §12]). |
| **Future external calls use retry/circuit-breaking** | Named now for when Integration Architecture ([§14]) becomes real; not implemented for MVP, since there are no external calls yet. |

---

## 18. Observability

Two systems that must never be conflated, despite both being "logs":

| System | Purpose | Audience | Retention |
|---|---|---|---|
| **Operational Logging** | Debugging, performance, incident response | Engineering | Short-to-medium, per [ADR §10]'s structured-logging plan (tenant/request correlation) |
| **Audit Logging** ([§8]) | Compliance record of sensitive business actions | Tenant Owner, future compliance reviewers, FTA if audited | Long (aligned to [KB §8.2] retention), append-only |

| Capability | Tier |
|---|---|
| Structured operational logs with request/tenant correlation | **[Build Now]** ([ADR §10]) |
| Error tracking / APM (Sentry-equivalent) | **[Design Now, Build Later]** |
| Audit event write path | **[Build Now]** |
| Full audit viewer, exportable compliance reports | **[Design Now, Build Later]** |

---

## 19. Error Handling Strategy

Extends [ADR §11]'s centralized pattern architecturally rather than restating it:

- Every cross-cutting service and domain module raises **typed, named errors** — never a bare string or an ad hoc status code chosen inline.
- Three error categories are handled distinctly: **validation** (client's request was malformed), **authorization** (RBAC denied the action), **system** (something unexpected failed) — each maps to a different response shape and a different observability signal, so a spike in authorization denials is distinguishable from a spike in system failures.
- No internal detail (stack traces, data-store errors) ever reaches a client response — unchanged from [ADR §11], reaffirmed as a platform-wide constraint, not a Module-0-only behavior.

---

## 20. Deployment Principles

Restates [ADR §12] as architectural principle, not vendor choice (vendor remains [§25 Decision]):

| Principle | Status |
|---|---|
| Stateless, containerized backend; no local disk dependency | **[Build Now]** |
| Managed database service, not self-hosted | **[Design Now, Build Later]** — pending vendor |
| Frontend and backend deployed and released independently | **[Build Now]**, per [ADR §1] |
| Environment promotion (dev → staging → production) with no direct-to-production changes | **[Design Now, Build Later]** |
| Infrastructure as code | **[Design Now, Build Later]** |
| CI/CD (test + deploy on merge) | **[Design Now, Build Later]** — arrives with the vendor decision, per [ADR §12] |

---

## 21. Data Ownership & Isolation Principles

Two orthogonal isolation axes — both structural, both non-negotiable:

| Axis | Rule |
|---|---|
| **Tenant isolation** (horizontal) | No Tenant's data is ever reachable by another Tenant, or by a Firm without an explicit, revocable grant ([§9]). |
| **Module data ownership** (vertical) | Each domain module ([§6], [§7]) owns its own data exclusively. Other modules read or write it **only** through that module's published service interface — never by reaching into its underlying data directly, even though everything currently lives in one shared data store. |

Module data ownership is what makes the modular monolith real rather than nominal — a shared database with no ownership discipline is just one big coupled system with extra documentation. It's also the specific property that makes future extraction (of Notifications, of AI processing, of anything) a boundary move instead of a surgery.

---

## 22. Module Dependency Rules

```mermaid
graph TD
    API["API / Interface Layer"] --> Domains
    API --> Platform["Cross-Cutting Platform Services"]
    Domains["Core Domain Modules"] --> Platform
    Platform -.never depends on.-x Domains
    Domains -."own service interface only, never internals".-> Domains
```

| Rule | Statement |
|---|---|
| 1 | Cross-cutting platform services may never depend on a domain module. Dependency flows one way: domains depend on services, never the reverse. |
| 2 | A domain module may depend on another domain module's **published service interface** only — never its data, never its internal implementation. |
| 3 | Supporting/Generic domains ([§6]) may not depend on Core domains — dependency points from less-differentiating to more-differentiating logic, never the other way, so Core domain evolution doesn't ripple into infrastructure-shaped modules. |
| 4 | The API/Interface layer contains no business logic — it resolves identity and tenant context, calls a domain or platform service, and shapes the response. Nothing else. |
| 5 | Circular dependencies between domain modules are not permitted; if one seems necessary, it's a signal the domain boundary itself is drawn wrong and needs revisiting, not a signal to add a back-reference. |

---

## 23. Architecture Constraints

Absolute, carried from ADR-0001 and this document, restated here as one list because engineers should be able to find "the rules" in one place without re-deriving them from five documents:

- No tenant-scoped operation ever trusts a client-supplied tenant identifier ([ADR §6]/[§7]).
- No financial or compliance record is ever hard-deleted ([KB §8.2], [§10]).
- No module reads or writes another module's data directly ([§21]).
- No business logic lives in the API/interface layer ([ADR §13.1], [§22]).
- Every schema change is a migration, additive by default ([ADR §5]).
- Every architecture change is proposed and approved before implementation — never silent ([ADR §13.3]).
- Every cross-cutting concern (auth, RBAC, config, flags, notifications, audit, numbering, storage) has exactly one owning service — no module reimplements one.
- No engine (workflow, search, AI) is built ahead of three concrete, real cases needing it ([§3] Principle 6).

---

## 24. Future Evolution Strategy

**Extraction candidates**, if and when genuinely necessary (none planned now): Notifications (naturally isolated, high fan-out potential), Automation & Intelligence/OCR-AI (likely needs different scaling characteristics — GPU/inference workloads — than the rest of the platform), Reporting (if Tier 3 Analytics genuinely needs a dedicated read model at scale, [§13]). Each is extractable specifically *because* [§21]'s module-ownership discipline is enforced now, not because extraction is scheduled.

**Horizon 2 (multi-industry generalization, [MPS §2])**: primarily touches the **VAT Compliance & Reporting** core domain — swapping or extending its rule set for a different compliance regime. Tenant Foundation, Identity & Access, Platform Operations, and every cross-cutting service were never coupled to VAT specifics if [§6]'s domain boundaries are respected — which means the domain design work done now for UAE VAT is exactly what makes a future, different vertical tractable later, not a sunk cost specific to this one.

**Firm/multi-tenant layer**: once [§25 Decision 1] resolves, it is expected to extend Identity & Access and Tenant Management additively — a new access-grant concept layered on top of existing tenant isolation, not a redesign of it ([§9]).

---

## 25. Open Architecture Decisions

Each requires its own ADR before the dependent work starts — none are defaulted by this document, consistent with [ADR §13.3].

| # | Decision | Blocks | Notes |
|---|---|---|---|
| 1 | **Firm/multi-Tenant cross-access mechanism** | V1 Firm segment, final Identity & Access shape, [§9]/[§12] finalization | The required *properties* are fixed in [§9]; the *mechanism* is not. Highest-priority open decision in this entire document set. |
| 2 | Deployment hosting vendor | Quantified NFRs, backup/DR targets, CI/CD, RLS timing | [ADR §12], unresolved since ADR-0001. |
| 3 | TypeScript adoption timing | Engineering execution only, not product/architecture scope | [ADR §2], unresolved since ADR-0001. |
| 4 | Row-Level Security implementation timing relative to Postgres migration | [§9]/[§10]'s second isolation layer | Named as **[Design Now, Build Later]** throughout; exact trigger point not yet an ADR. |
| 5 | Secrets management vendor (beyond `.env`) | Production readiness ([§10]) | Not yet a decision, only a stated gap. |
| 6 | Monitoring/APM vendor | [§18] Observability | Not yet a decision, only a stated gap. |
| 7 | Criteria for extracting a cross-cutting service or domain into its own deployable unit | [§16]/[§24] | Should be decided as a *policy* (what triggers extraction) before it's ever decided as a *specific instance* — recommend resolving this before any extraction is proposed, not reactively. |
| 8 | Direct EmaraTax filing integration feasibility | [§14] Integration Architecture's scope for that specific integration | Carried from [MPS §23.3] — a commercial/product question with an architectural consequence once resolved. |

---

This specification is the architecture every Module 1+ design must be checked against. Where implementation work reveals a need to deviate from a principle or constraint in this document, that deviation is proposed and explained before it's built — per [§3] Principle 8 and [ADR §13.3] — not discovered after the fact in a code review.
