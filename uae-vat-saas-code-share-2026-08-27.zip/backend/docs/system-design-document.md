# Ledger — System Design Document (SDD)

- **Status:** Version 1 — official system design reference
- **Date:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Synthesized from:** [Master Product Specification](master-product-specification.md), [Platform Architecture Specification](platform-architecture-specification.md), [Database Design Specification](database-design-specification.md), [ADR-0001](adr/0001-baseline-architecture.md) (Accepted), [UAE VAT Knowledge Base](knowledge-base/README.md).
- **Audience:** software architects, backend engineers, frontend engineers, DevOps engineers, technical leads.
- **What this is:** the end-to-end *how it runs* view — request flows, component interactions, deployment topology. No code, no API contracts, no database schema. Those follow this document, checked against it.
- **A note on technology naming, addressed directly:** this document's request came with an illustrative deployment example naming **NestJS** and **React**. Ledger's backend framework is **Express** (Node.js), an Accepted decision in [ADR §2]/[ADR §3] — not NestJS. The frontend is **Next.js**, which is built on React, so "React" is directionally correct shorthand. Per [ADR §13.3], architecture is never changed silently — this document uses Express throughout, consistent with the Accepted ADR, and does not adopt NestJS. If a framework change is genuinely wanted, it needs its own ADR proposal and approval, not a substitution introduced through a diagram example. Everything else in this SDD aligns fully with the MPS, PAS, and DDS as instructed.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary) · 2. [Architecture Overview](#2-architecture-overview) · 3. [System Context Diagram](#3-system-context-diagram) · 4. [C4 Context Diagram](#4-c4-context-diagram) · 5. [C4 Container Diagram](#5-c4-container-diagram) · 6. [Component Diagram](#6-component-diagram) · 7. [Request Lifecycle](#7-request-lifecycle) · 8. [Authentication Flow](#8-authentication-flow) · 9. [Authorization Flow (RBAC)](#9-authorization-flow-rbac) · 10. [Tenant Isolation Flow](#10-tenant-isolation-flow) · 11. [Platform Services](#11-platform-services) · 12. [Module Communication](#12-module-communication) · 13. [Data Flow](#13-data-flow) · 14. [External Integrations](#14-external-integrations) · 15. [File Storage Flow](#15-file-storage-flow) · 16. [Deployment Architecture](#16-deployment-architecture) · 17. [Security Architecture](#17-security-architecture) · 18. [Performance Strategy](#18-performance-strategy) · 19. [Scalability Strategy](#19-scalability-strategy) · 20. [Failure Handling](#20-failure-handling) · 21. [Observability](#21-observability) · 22. [AI Extension Points](#22-ai-extension-points) · 23. [Architecture Decision Summary](#23-architecture-decision-summary) · 24. [Future Evolution](#24-future-evolution)

---

## 1. Executive Summary

**Purpose**: describe how Ledger actually runs — as a system, in motion — end to end. The MPS said what and why; the PAS said the architectural shape; the DDS said how data is structured. This document shows the request paths, the sequences, and the deployment topology that all three imply.

**Goals**: give every engineering discipline (backend, frontend, DevOps, QA, architecture) one document that answers "what happens when X occurs" without needing to reconstruct it from four other documents. Every diagram here should be checkable against real behavior once Module 1+ ships.

**Scope**: the full platform as specified by the MPS — MVP through Future Vision — with every capability tagged **[Build Now]** / **[Design Now, Build Later]** / **[Future Vision]** so it's never ambiguous what exists today versus what this design merely accommodates.

---

## 2. Architecture Overview

**Style: Modular Monolith.** One deployable backend service, internally partitioned into domain modules with owned data and published interfaces ([PAS §6]/[§7]/[§21]), sitting on a shared layer of cross-cutting platform services ([PAS §8]).

| Consideration | Why | Benefit | Trade-off |
|---|---|---|---|
| Modular monolith over microservices | The platform does not yet have the team size, operational maturity, or genuine scaling need microservices solve for | Simple deployment, simple transactions (no distributed-transaction problem across module boundaries), fast local development, one thing to monitor | Cannot independently scale or deploy a single hot module — mitigated by module boundaries being strict enough to extract later if proven necessary ([PAS §16]/[§24]) |
| Modular monolith over a single unstructured codebase | Financial software needs auditable, traceable ownership per domain ([DDS §4]) | Clear ownership, "one rule one implementation" enforceable, extraction option preserved | Requires real discipline to keep boundaries honest — not free, but far cheaper than either alternative |

**Why this architecture (summary)**: it is the only option that satisfies *both* "keep MVP practical" and "survive ten years" simultaneously — a single service is what a small team can operate correctly today; module boundaries are what make tomorrow's options (extraction, Horizon 2 generalization, [MPS §22]) additive instead of a rewrite.

**Future evolution**: any module may be extracted into its own deployable service *if and only if* a real scaling or ownership problem justifies it ([PAS §16]/[§24], [DDS §22 Decision 9]) — Notifications and a future Automation/AI processing module are the most plausible first candidates, precisely because they have different load and resource profiles than the rest of the platform.

---

## 3. System Context Diagram

```mermaid
graph TB
    Owner["SME Owner"]
    Staff["Staff / Bookkeeper"]
    Admin["Platform Admin"]
    Firm["Accounting Firm (planned)"]

    subgraph Ledger["Ledger Platform"]
        Core["Multi-tenant B2B SaaS:\ndaily operations + UAE VAT compliance"]
    end

    FTA["FTA / EmaraTax\n(manual filing today; e-invoicing planned)"]
    Email["Email Provider"]
    ObjStore["Object Storage"]
    Banking["Banking / Payment Gateways (future)"]
    AI["AI / OCR Services (future)"]

    Owner --> Ledger
    Staff --> Ledger
    Admin --> Ledger
    Firm -.pending access-model decision.-> Ledger

    Ledger --> Email
    Ledger --> ObjStore
    Ledger -.manual today.-> FTA
    Ledger -.future.-> Banking
    Ledger -.future.-> AI
```

| Actor / System | Relationship | Status |
|---|---|---|
| SME Owner, Staff | Primary Tenant users | **[Build Now]** |
| Platform Admin | Onboards/manages Tenants; no Tenant financial visibility | **[Build Now]** |
| Accounting Firm | Manages multiple Tenants | **[Design Now, Build Later]** — access model open ([PAS §25 Decision 1]) |
| FTA / EmaraTax | No API integration exists; businesses file manually | Out of scope unless [MPS §23 Decision 3] resolves otherwise |
| Email Provider | Transactional notifications | **[Build Now]** |
| Object Storage | Tenant-isolated file storage | **[Build Now]** (interface); heavy use from Module 2+ |
| Banking / Payment Gateways | Reconciliation, payments | **[Future Vision]** |
| AI / OCR Services | Document extraction, insights | **[Future Vision]** |

---

## 4. C4 Context Diagram

```mermaid
C4Context
  title Ledger Platform — System Context (C4 Level 1)

  Person(owner, "SME Owner", "Runs a business on Ledger")
  Person(staff, "Staff / Bookkeeper", "Day-to-day data entry")
  Person(admin, "Platform Admin", "Onboards and manages Tenants")
  Person_Ext(firm, "Accounting Firm", "Manages multiple client Tenants - planned")

  System(ledger, "Ledger Platform", "Multi-tenant B2B SaaS for daily operations and UAE VAT compliance")

  System_Ext(fta, "FTA / EmaraTax", "Manual filing today; e-invoicing network integration planned")
  System_Ext(email, "Email Provider", "Transactional notifications")
  System_Ext(storage, "Object Storage", "Tenant-isolated file storage")
  System_Ext(banking, "Banking / Payment Gateways", "Future")
  System_Ext(ai, "AI / OCR Services", "Future")

  Rel(owner, ledger, "Uses")
  Rel(staff, ledger, "Uses")
  Rel(admin, ledger, "Administers")
  Rel(firm, ledger, "Manages multiple Tenants")
  Rel(ledger, fta, "Manual filing today, planned e-invoicing")
  Rel(ledger, email, "Sends notifications")
  Rel(ledger, storage, "Stores files")
  Rel(ledger, banking, "Future integration")
  Rel(ledger, ai, "Future integration")
```

---

## 5. C4 Container Diagram

```mermaid
C4Container
  title Ledger Platform — Containers (C4 Level 2)

  Person(user, "Tenant User / Platform Admin")

  System_Boundary(ledger, "Ledger Platform") {
    Container(web, "Web Application", "Next.js (React)", "Responsive, mobile-first UI")
    Container(api, "Backend API", "Node.js, Express", "REST API; domain modules and cross-cutting platform services")
    ContainerDb(db, "Primary Database", "PostgreSQL", "Pooled multi-tenant relational store")
    ContainerDb(objstore, "Object Storage", "S3-compatible", "Tenant-isolated file storage")
    Container(notify, "Notification Dispatch", "Within Backend API today; extractable later", "Provider-abstracted notification sending")
    Container(cache, "Cache / Queue", "Redis - future", "Caching, background jobs, rate limiting")
  }

  System_Ext(email, "Email Provider")
  System_Ext(ai, "AI / OCR Services", "Future")
  System_Ext(integrations, "Future Integrations", "Payments, Banking, ERP/CRM, Government APIs")

  Rel(user, web, "Uses", "HTTPS")
  Rel(web, api, "Calls", "REST/JSON over HTTPS")
  Rel(api, db, "Reads/writes", "Prisma")
  Rel(api, objstore, "Stores/retrieves files", "Signed URLs")
  Rel(api, notify, "Dispatches events")
  Rel(notify, email, "Sends", "SMTP/API")
  Rel(api, cache, "Future: caching, queues")
  Rel(api, ai, "Future")
  Rel(api, integrations, "Future")
```

| Container | Technology | Status |
|---|---|---|
| Web Application | Next.js (React), mobile-first | **[Build Now]** |
| Backend API | Node.js, Express ([ADR §2]/[§3]) | **[Build Now]** |
| Primary Database | PostgreSQL (SQLite in dev only, [ADR §4]) | **[Build Now]** for schema discipline; Postgres migration **[Design Now, Build Later]** |
| Object Storage | S3-compatible, tenant-isolated ([ADR §9]) | **[Build Now]** interface |
| Notification Dispatch | In-process today, provider-abstracted | **[Build Now]** interface; email only |
| Cache/Queue | Redis or equivalent | **[Future Vision]** |

---

## 6. Component Diagram

```mermaid
graph TD
    subgraph Platform["Cross-Cutting Platform Services"]
        Auth["Authentication"]
        RBAC["Authorization (RBAC)"]
        TenantMgmt["Tenant Management"]
        Config["Configuration"]
        Flags["Feature Flags"]
        Notify["Notifications"]
        AuditSvc["Audit Logging"]
        Numbering["Numbering"]
        Storage["File Storage"]
    end

    subgraph Modules["Domain Modules"]
        CustomerMod["Customer Module"]
        SupplierMod["Supplier Module"]
        InvoiceMod["Invoice Module"]
        PurchaseMod["Purchase Module"]
        VATMod["VAT Module"]
        ReportsMod["Reports"]
    end

    CustomerMod --> RBAC
    CustomerMod --> Config
    CustomerMod --> TenantMgmt

    SupplierMod --> RBAC
    SupplierMod --> Config
    SupplierMod --> TenantMgmt

    InvoiceMod --> RBAC
    InvoiceMod --> Numbering
    InvoiceMod --> Notify
    InvoiceMod --> AuditSvc
    InvoiceMod --> VATMod
    InvoiceMod --> CustomerMod

    PurchaseMod --> RBAC
    PurchaseMod --> VATMod
    PurchaseMod --> AuditSvc
    PurchaseMod --> SupplierMod

    VATMod --> Config
    VATMod --> TenantMgmt

    ReportsMod --> InvoiceMod
    ReportsMod --> PurchaseMod
    ReportsMod --> VATMod

    Auth --> TenantMgmt
```

| Component | Responsibility |
|---|---|
| **Authentication** | Verifies identity, issues/validates session credentials for both identity spaces (Platform Admin, Tenant User) — [ADR §5]. |
| **Authorization (RBAC)** | Single decision point for "can this identity do this action" — data-driven per [PAS §14]. |
| **Tenant Management** | Owns Tenant identity/lifecycle; resolves the tenant context every other component depends on. |
| **Customer Module** | Tenant Foundation domain — Customer records, reused by Invoicing. |
| **Supplier Module** | Tenant Foundation domain — Supplier records, reused by Purchases. |
| **Invoice Module** | Sales/Simplified Invoices, Credit/Debit Notes, numbering, immutability. |
| **Purchase Module** | Purchases/Expenses, recoverability classification. |
| **VAT Module** | The Core domain — VAT categorization, calculation, VAT Return generation ([KB]). |
| **Reports** | Operational and compliance reporting, always derived from Invoice/Purchase/VAT data, never independently stored ([MPS §18]). |
| **Notification** | Provider-abstracted event dispatch. |
| **Audit** | Append-only capture of defined sensitive actions. |
| **Configuration** | Platform → Plan → Tenant settings cascade ([PAS §15]/[DDS]). |

---

## 7. Request Lifecycle

```mermaid
sequenceDiagram
    participant Browser
    participant API as API Layer
    participant AuthN as Authentication
    participant AuthZ as Authorization (RBAC)
    participant Service as Business Service
    participant DB as Database
    participant Audit as Audit Logging

    Browser->>API: HTTPS request + credential
    API->>AuthN: Verify identity
    AuthN-->>API: Verified identity + tenant context
    API->>AuthZ: Can this identity perform this action?
    AuthZ-->>API: Allow / Deny
    alt Denied
        API-->>Browser: 403 Forbidden
    else Allowed
        API->>Service: Invoke domain service (with tenant context)
        Service->>Service: Validate input, apply business rules
        Service->>DB: Read/write (tenant-scoped)
        DB-->>Service: Result
        Service->>Audit: Emit audit event (if sensitive action)
        Service-->>API: Result
        API-->>Browser: Response
    end
```

Validation is deliberately shown as a step *inside* the Business Service, not the API layer — per [PAS §22] Rule 4, the API layer contains no business logic, including business validation; it only resolves identity/tenant context and shapes the response.

---

## 8. Authentication Flow

```mermaid
sequenceDiagram
    participant Browser
    participant API as API Layer
    participant AuthN as Authentication Service
    participant DB as Database

    Browser->>API: POST /login (email, password)
    API->>AuthN: authenticate(credentials, identity space)
    AuthN->>DB: Look up account by email (scoped to identity space)
    DB-->>AuthN: Account record (password hash)
    AuthN->>AuthN: Verify password hash
    alt Invalid credentials
        AuthN-->>API: Authentication failed
        API-->>Browser: 401 Unauthorized
    else Valid credentials
        AuthN->>AuthN: Issue signed session credential\n(identity-space-specific secret, per ADR §5)
        AuthN-->>API: Session credential + identity
        API-->>Browser: 200 OK + credential
    end
```

Two identity spaces (Platform Admin, Tenant User) are authenticated through the same flow shape but with separate secrets and audiences, per [ADR §5] — unchanged by this document. **[Design Now, Build Later]**: MFA challenge step, session revocation check, rate limiting on this endpoint ([PAS §10]).

---

## 9. Authorization Flow (RBAC)

```mermaid
sequenceDiagram
    participant API as API Layer
    participant AuthZ as Authorization (RBAC) Service
    participant RoleData as Role/Permission Data
    participant Service as Business Service

    API->>AuthZ: hasPermission(identity, action, module, tenantContext)
    AuthZ->>RoleData: Resolve identity's role(s) and granted permissions
    RoleData-->>AuthZ: Permission set
    AuthZ->>AuthZ: Evaluate — deny by default, least privilege
    alt Permission not granted
        AuthZ-->>API: Deny
        API-->>API: Return 403, no Service call made
    else Permission granted
        AuthZ-->>API: Allow
        API->>Service: Proceed with the requested action
    end
```

Per [PAS §14], this is **data-driven from Module 1**, not a hardcoded role-string comparison — the diagram's `RoleData` step is what makes custom roles ([MPS §14 V1 scope]) additive later without changing this flow's shape.

---

## 10. Tenant Isolation Flow

```mermaid
sequenceDiagram
    participant API as API Layer
    participant AuthN as Authentication
    participant TenantMgmt as Tenant Management
    participant Service as Business Service
    participant DB as Database

    API->>AuthN: Verify session credential
    AuthN-->>API: Verified identity (contains tenant reference, never trusted from client body/params)
    API->>TenantMgmt: Resolve tenant context from verified identity
    TenantMgmt-->>API: Tenant context (active, not suspended)
    API->>Service: Invoke with tenant context attached
    Service->>DB: Query, always filtered by tenant context
    Note over DB: Application-level filter today.<br/>Row-Level Security as second layer (Design Now, Build Later, DDS §3).
    DB-->>Service: Tenant-scoped result only
```

| Step | Explanation |
|---|---|
| **Tenant Resolution** | The tenant identifier is derived exclusively from the verified session credential — never accepted from a request body, query parameter, or header supplied by the client ([ADR §6]/[§7], unchanged). |
| **Context Propagation** | Once resolved, the tenant context travels with the request through the API layer into the Business Service and every cross-cutting service it calls — no service re-resolves it independently or trusts a passed-in value from a lower-trust source. |
| **Database Filtering** | Every tenant-owned query includes the tenant context in its filter. Today this is enforced at the application/service layer; Row-Level Security is the planned second, defense-in-depth layer once the Postgres migration lands ([DDS §3]). |

---

## 11. Platform Services

Which modules use which cross-cutting services — a direct implementation of [PAS §8]'s "single home per concern":

| Module | Auth | RBAC | Config | Audit | Notify | Storage | Numbering | Flags | Tenant Mgmt |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Tenant Foundation (Customer/Supplier/Product) | ✅ | ✅ | ✅ | ✅ | — | — | — | — | ✅ |
| Invoicing | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | ✅ |
| Purchases/VAT/Reporting | ✅ | ✅ | ✅ | ✅ | — | — | — | ✅ (recoverability-adjacent) | ✅ |
| Access Control (planned) | ✅ | ✅ | — | ✅ | — | — | — | — | ✅ |
| Automation/OCR (future) | ✅ | ✅ | — | ✅ | — | ✅ | — | ✅ | ✅ |
| Platform Admin / Tenant Mgmt | ✅ | ✅ | ✅ | ✅ | — | — | — | ✅ | — (is the source) |

No module calls a provider (email server, storage bucket) directly — every cross-cutting concern is reached through its owning service's interface, never bypassed, per [PAS §3] Principle 2.

---

## 12. Module Communication

```mermaid
graph LR
    Foundation["Tenant Foundation\n(Customer, Supplier, Product)"]
    Invoicing["Invoicing"]
    VAT["VAT Compliance & Reporting"]
    Access["Access Control (planned)"]
    Automation["Automation & Intelligence (future)"]

    Invoicing -->|"reads Customer/Supplier"| Foundation
    Invoicing -->|"calls: classify line item, calculate tax"| VAT
    VAT -->|"reads settings"| Foundation
    Automation -.future.-> VAT
    Automation -.future.-> Invoicing
    Access -.governs access to.-> Foundation
    Access -.governs access to.-> Invoicing
    Access -.governs access to.-> VAT
```

**Rule**: a module calls another module's **published service interface only** — never its underlying data directly, even in a single shared database ([PAS §22] Rule 2, [DDS §4]). This diagram matches [PAS §6]'s domain dependency graph; it's restated here at the module/communication level because it's the direct answer to "how do modules talk to each other" for engineers implementing them.

---

## 13. Data Flow — Example: Create Invoice

```mermaid
flowchart TD
    A["Create Invoice request"] --> B["Validation\n(business rules, VAT classification per line)"]
    B --> C["Database write\n(tenant-scoped, numbering allocated atomically)"]
    C --> D["PDF generation\n(rendered from the persisted, immutable record)"]
    C --> E["Audit event emitted"]
    C --> F["Notification dispatched\n(email to Customer, if configured)"]
    D --> G["File Storage\n(tenant-isolated, signed access)"]
    C --> H["Available to Reports\n(Operational + VAT Return, derived on read)"]
```

**Why PDF generation happens after the database write, not before**: the invoice's numbering, totals, and content must be the single, already-persisted source of truth before a document *representing* it is generated — generating a PDF from unsaved/unvalidated data risks a document that doesn't match what was actually recorded, breaking the "one source of truth" property [MPS §2]/[PAS §3] depend on everywhere else.

---

## 14. External Integrations

All future, per [MPS §7]/[§19] and [PAS §14] — shown here as the concrete shape each would take without committing to any of them for MVP:

| Integration | Direction | Architectural shape | Tier |
|---|---|---|---|
| **FTA / e-invoicing (Peppol/PINT AE)** | Outbound (submit) | A dedicated adapter behind the Invoicing module's service interface — invoices are generated once, transmitted through this adapter when the mandate applies ([KB §5.1]) | **[Design Now, Build Later]** — real 2027 deadline |
| **Bank APIs** | Inbound (statement/transaction feed) | An adapter feeding the Purchases/Reconciliation capability; never a direct database write path | **[Future Vision]** |
| **Payment Gateway** | Outbound (collect) / Inbound (webhook) | Adapter behind Invoicing/Payments; webhook receipt authenticated and authorized exactly like any other caller ([PAS §14]) | **[Future Vision]** |
| **OCR** | Inbound (extracted data) | Consumes File Storage, produces structured data into the Purchases module via its service interface — never writes to Purchases' tables directly | **[Future Vision]** |
| **AI Services** | Bidirectional | Calls the same domain service functions a human-driven UI calls, mediated by the same RBAC/tenant boundary ([PAS §15]/[§22]) | **[Future Vision]** |
| **Email** | Outbound | Notification Dispatch's first, and currently only, provider | **[Build Now]** |
| **WhatsApp** | Outbound | A second Notification provider behind the same abstraction — additive, no redesign | **[Design Now, Build Later]** |

Every integration in this table is designed to enter the system through an existing module's service interface or the Notification/File Storage platform services — none introduces a new access path into tenant data.

---

## 15. File Storage Flow

```mermaid
sequenceDiagram
    participant Client as Browser (Upload)
    participant API as API Layer
    participant Storage as File Storage Service
    participant ObjStore as Object Storage
    participant DB as Database

    Client->>API: Upload file (e.g., logo, future supplier invoice)
    API->>Storage: store(tenantContext, file)
    Storage->>ObjStore: Write, tenant-prefixed key
    ObjStore-->>Storage: Storage key
    Storage->>DB: Persist file metadata (key, tenant, owner record, uploader)
    Storage-->>API: File reference
    API-->>Client: Confirmation

    Note over API,ObjStore: Generated PDF flow (e.g., Invoice)
    API->>Storage: store(tenantContext, generatedPdf)
    Storage->>ObjStore: Write, tenant-prefixed key
    Storage->>DB: Persist file metadata, linked to source Invoice
    API-->>Client: Signed, time-limited download URL
```

Consistent with [ADR §9] and [DDS §15]: only metadata and a storage key live in the database; file bytes never do. Access is always via a signed, expiring URL — never a public bucket.

---

## 16. Deployment Architecture

```mermaid
graph TD
    Client["Web Client\n(Next.js / React, mobile-first)"]
    LB["Load Balancer"]
    API1["Backend API instance\n(Node.js, Express)"]
    API2["Backend API instance\n(Node.js, Express)"]
    PG[("PostgreSQL\n(managed, primary)")]
    Obj[("Object Storage\n(S3-compatible)")]
    Redis[("Redis - future\ncache / queue")]
    Mon["Monitoring / APM - Design Now, Build Later"]
    Backup["Automated Backup - Build Now floor"]

    Client -->|HTTPS| LB
    LB --> API1
    LB --> API2
    API1 --> PG
    API2 --> PG
    API1 --> Obj
    API2 --> Obj
    API1 -.future.-> Redis
    API2 -.future.-> Redis
    API1 --> Mon
    API2 --> Mon
    PG --> Backup
```

| Layer | Technology | Status |
|---|---|---|
| Client | Next.js (React), responsive/mobile-first | **[Build Now]** |
| Load Balancer | Standard reverse proxy/LB in front of stateless API instances | **[Design Now, Build Later]** — arrives with a chosen deployment vendor ([ADR §12]) |
| Backend API | Node.js, **Express** (not NestJS — see the note at the top of this document) | **[Build Now]** |
| Database | PostgreSQL, managed | **[Design Now, Build Later]** — vendor open ([ADR §12]/[PAS §25]) |
| Object Storage | S3-compatible | **[Build Now]** interface |
| Cache/Queue | Redis or equivalent | **[Future Vision]** |
| Monitoring | APM/error tracking | **[Design Now, Build Later]** |
| Backup | Daily automated, tested restore | **[Build Now]** floor expectation ([DDS §18]) |

The backend is stateless by design ([ADR §5]/[PAS §16]) — horizontal scaling in this diagram (API1, API2, ...) is an infrastructure decision, not an architecture change.

---

## 17. Security Architecture

Synthesized, not repeated verbatim, from [PAS §10] and [DDS §19]:

| Layer | Mechanism | Tier |
|---|---|---|
| Authentication | Dual identity-space JWTs, distinct secrets/audiences ([ADR §5]) | **[Build Now]** |
| Authorization | Data-driven RBAC, deny-by-default ([PAS §14]) | **[Build Now]** |
| Encryption | At rest and in transit, always on | **[Build Now]** |
| Tenant Isolation | Application-level, structural ([§10] above); RLS as second layer | **[Build Now]** app-level; RLS **[Design Now, Build Later]** |
| Audit | Append-only, defined action taxonomy | **[Build Now]** write path |
| Secrets | Environment-based today; vault/rotation later | **[Build Now]** (dev-appropriate) → **[Design Now, Build Later]** |
| Input Validation | Every request validated in the Business Service, never trusted from the client, never re-implemented per module ([§7] above) | **[Build Now]** |

---

## 18. Performance Strategy

| Concern | Approach | Tier |
|---|---|---|
| Caching | None required at MVP data volumes; Redis-backed caching for Configuration/Feature Flag reads (high-frequency, low-change data) is the first candidate when needed | **[Future Vision]** |
| Pagination | Cursor-based (keyset) as the target standard; simple offset pagination acceptable at MVP scale ([DDS §14]) | **[Build Now]** (offset) → **[Design Now, Build Later]** (cursor) |
| Connection Pooling | Standard practice for any production Postgres deployment — sized to the chosen hosting vendor's limits | **[Design Now, Build Later]** — pending [ADR §12] |
| Indexes | Every FK indexed, tenant-scoped composite indexes as the default pattern ([DDS §13]) | **[Build Now]** |
| Background Jobs | None required at MVP (no async workloads yet); Notification retry and future OCR/AI processing are the first real candidates for a job queue | **[Future Vision]** |

---

## 19. Scalability Strategy

| Dimension | Approach | Tier |
|---|---|---|
| Horizontal scaling | Additional stateless API instances behind the load balancer ([§16]) | **[Design Now, Build Later]** — mechanism ready, not yet exercised |
| Vertical scaling | Acceptable stop-gap pre-launch (bigger instance) but not the long-term strategy | **[Build Now]** as a fallback only |
| Read replicas | Isolate analytical/reporting load from transactional writes once volume justifies it ([DDS §20]) | **[Future Vision]** |
| Future microservices | Only if a specific module (Notifications, Automation/AI) proves a genuine scaling or ownership bottleneck ([PAS §16]/[§24]) | **[Future Vision]**, option preserved by module boundaries, not scheduled |

---

## 20. Failure Handling

| Concern | Approach | Tier |
|---|---|---|
| Retries | Idempotent operations (numbering, document issuance) can be safely retried; non-idempotent external calls (future integrations) need explicit retry-with-backoff | **[Build Now]** principle; **[Future Vision]** for external-call retries |
| Dead Letter Queue | For failed async work (notification delivery, future OCR jobs) once a job queue exists | **[Future Vision]** |
| Graceful failure | A Notification or File Storage outage does not block the core operation (e.g., Invoice issuance) that triggered it — the core write succeeds; the dependent side effect is queued/retried ([§13] above) | **[Build Now]** principle |
| Timeouts | Every external/service call has an explicit timeout — no unbounded wait on a dependency | **[Design Now, Build Later]** — named now, tuned once real external calls exist |
| Fallbacks | Read paths (e.g., Reports) fail loudly and specifically rather than silently returning partial/incorrect data — correctness over availability for financial figures | **[Build Now]** principle |

---

## 21. Observability

| Concern | Approach | Tier |
|---|---|---|
| Logging | Structured, with request/tenant correlation ([ADR §10]) | **[Build Now]** |
| Metrics | Request rate, error rate, latency per endpoint | **[Design Now, Build Later]** |
| Tracing | Cross-service request tracing — most valuable once a module is ever extracted ([§2]) | **[Future Vision]** |
| Health checks | A basic liveness endpoint already exists (`/health`, Module 0); readiness checks (DB connectivity, etc.) extend it | **[Build Now]** (liveness) → **[Design Now, Build Later]** (readiness) |
| Monitoring/APM | Error tracking and performance monitoring (Sentry-equivalent, [PAS §18]) | **[Design Now, Build Later]** |

Operational logging and Business Audit Logging remain two distinct systems, never conflated — restated from [DDS §11] because it's a decision every engineer touching either system needs to know.

---

## 22. AI Extension Points

Where AI can plug in **without changing this architecture**, per [PAS §15]:

| Extension point | How AI integrates | Why no redesign is needed |
|---|---|---|
| Business Service layer | An AI orchestration layer calls the same service functions the API layer calls today | Services are already the single, clean interface to domain logic ([§7]) |
| RBAC boundary | An AI-driven action is authorized exactly like a human-driven one — no bypass path | Authorization is a boundary every caller passes through, not a per-caller exception ([§9]) |
| File Storage | OCR consumes uploaded files through the same interface any module would use | File Storage was never module-specific ([§15]) |
| Structured domain data | VAT categorization, recoverability status, and other KB-sourced classifications are already structured facts, not free text | This was a deliberate DDS/PAS choice, not an AI-specific addition ([DDS §9]) |
| Reporting layer | AI-generated insights consume the same derived-from-transactions data Tier 1–3 reports do ([MPS §18]) | Reports were never independently stored figures to begin with |

No component in this document exists solely to support future AI — every extension point above is something the architecture needed anyway, for a human-facing reason, that AI can also use later.

---

## 23. Architecture Decision Summary

| Decision | Why | Benefits | Trade-offs |
|---|---|---|---|
| Modular monolith, not microservices | Team size and scaling need don't justify distributed-systems complexity yet ([§2]) | Simple to build, deploy, debug; transactions stay local | Can't scale a single module independently — mitigated by preserved extraction option |
| Pooled multi-tenancy | Single migration surface, cost-effective at SME scale ([DDS §3]) | Operationally simple, standard SaaS pattern | Isolation depends on discipline — mitigated by structural enforcement + planned RLS |
| RBAC as data, from Module 1 | Retrofitting hardcoded role checks later is expensive ([PAS §14]) | Custom roles, Firm access, least privilege all become additive later | More upfront design than a hardcoded enum |
| Express over NestJS | Already Accepted in [ADR §2]/[§3]; not revisited by this document | Matches the existing, working Module 0 codebase | NestJS's built-in DI/module conventions are foregone — mitigated by this SDD's own module/service discipline achieving similar structure without the framework |
| Next.js frontend | Already Accepted; App Router fits a mobile-first, server-capable UI | Working Module 0 foundation, no rewrite | None material at this stage |
| Cross-cutting services as the single home per concern | Prevents the "hardcoded business logic everywhere" failure mode named throughout the Review | Consistency, testability, one place to change | Requires real discipline not to bypass them |
| Object storage for files, DB for metadata only | Standard, avoids bloating the transactional database | Scalable, standard pattern | An additional service to operate — accepted as necessary |
| Defer Redis/caching/queues | Not needed at MVP volumes | Less to operate now | Will need deliberate introduction later, not a bolt-on afterthought |

---

## 24. Future Evolution

| Tier | What it means here | Examples from this document |
|---|---|---|
| **Build Now** | Required for MVP, built as specified | Express/Next.js containers, Authentication, RBAC data model, Numbering, Audit write path, application-level tenant isolation, encryption, structured logging |
| **Design Now, Build Later** | Interface/shape decided now, fuller build deferred | RLS, Load Balancer/managed Postgres (pending vendor), WhatsApp notification channel, e-invoicing adapter, cursor pagination, metrics/APM, MFA |
| **Future Vision** | Named and architecturally accommodated, not designed in detail | Redis cache/queue, read replicas, microservice extraction, Bank/Payment/OCR/AI integrations, dead letter queues, distributed tracing |

This tiering is the same one used throughout the MPS, PAS, and DDS — carried through to the system level so nothing in this document implies more is built today than actually is.

---

This document is the system-level reference every engineering discipline checks their work against. Where implementation reveals a genuine need to diverge from a flow or diagram here — including, especially, the Express-vs-NestJS point raised at the top — that divergence is proposed and approved before it's built, per [ADR §13.3], not discovered after the fact.
