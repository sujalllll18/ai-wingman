# Enterprise Architecture Review — Ledger Product Bible v2

- **Status:** Review (advisory) — **the Product Bible and ADR-0001 are unchanged by this document**
- **Date:** 2026-07-30
- **Reviewer stance:** Principal Product Architect / Enterprise SaaS Architect / Staff Engineer, reviewing against a stated ambition to become a configurable, multi-industry, enterprise-grade B2B platform (Odoo/Zoho/NetSuite/Xero-class), while keeping the MVP practical.
- **Reviewed against:** [Product Bible v2](../product-bible.md), [ADR-0001 (Accepted)](../adr/0001-baseline-architecture.md), [UAE VAT Knowledge Base v1](../knowledge-base/README.md).
- **Purpose:** challenge the architecture before Module 1 starts, per the request. This is input to a future Product Bible revision and likely a new ADR — it does not itself constitute a decision.

---

## Executive Summary — read this part even if nothing else

**The single biggest risk in this expanded vision is building the platform before the product.** Odoo, Zoho, NetSuite, and SAP did not start as generic engines — they generalized *after* a working vertical proved which abstractions were actually worth building. A configuration engine, workflow engine, notification engine, feature-flag service, and custom-RBAC-builder, all built ahead of Module 1 shipping, is the classic pattern behind SaaS teams that spend a year on infrastructure and ship nothing a customer can use. That is not a hypothetical warning — it is the most common way ambitious B2B SaaS rebuilds fail before they start.

The good news: most of what makes this vision achievable is **already correctly decided**. Pooled multi-tenancy with JWT-derived `tenantId` scoping ([ADR §7]), the services-not-controllers rule ([ADR §13.1]), module-ordered delivery ([ADR §1]), and the discipline of tracking open questions instead of guessing (the Assumptions register) are exactly the right foundations for *both* a lean MVP and a future platform. None of that should be re-architected. What's missing is not a rebuild — it's a set of **cheap, high-leverage abstractions that must go into Module 1's data model now**, paired with an explicit, written-down list of **expensive engines that should wait**.

This review distinguishes those two categories everywhere below using three tags:

- 🟢 **Build now** — cheap, and expensive to retrofit if skipped.
- 🟡 **Model now, build later** — get the data model/interface right in Module 1–3; defer the tooling/UI.
- 🔴 **Defer entirely** — real feature, genuinely not needed until there's a paying customer or three concrete use cases asking for it.

**Score: 6/10** (detail and justification at the end). The vision and documentation discipline are strong; the concrete engineering translation of the 12 priorities in this message barely exists yet in the Bible. That gap is expected at this stage — a vision document naturally precedes detailed architecture — but it should not be mistaken for "ready to start Module 1."

---

## How to read the section-by-section review

Each of the Product Bible's 15 sections gets the 9-point breakdown requested: What's good / What's missing / What should change / What should be postponed / Risks / Better architecture suggestions / Enterprise best practices / MVP recommendation / Future recommendation. To keep 15 × 9 = 135 points navigable, each point is a tight bullet, not an essay — depth is concentrated in the Executive Summary above and the prioritized roadmap at the end.

---

## §1 Product Vision

1. **Good:** The v2 rewrite already reframes Ledger as a daily operating system and explicitly named the Firm/multi-tenant open question instead of quietly deciding it — exactly the right instinct for what this review is asking for more of.
2. **Missing:** No statement that Ledger is meant to be industry-agnostic/configurable by design. The Vision still reads as "a UAE VAT SaaS that also does daily ops," not "a configurable operating system whose first deep vertical is UAE VAT."
3. **Should change:** Add an explicit two-horizon framing: Horizon 1 proves the model in the UAE SME/VAT market on genuinely reusable foundations; Horizon 2 generalizes proven engines to other industries/geographies. This resolves the tension between "keep MVP practical" and "think like NetSuite" honestly instead of leaving it implicit.
4. **Should be postponed:** Any vision language implying multi-industry go-to-market before the UAE VAT vertical has real paying customers.
5. **Risks:** Without the two-horizon framing, an investor or engineer reading "highly configurable, multi-industry" next to a 100%-UAE-VAT-shaped Module 1–5 roadmap will reasonably read it as scope confusion, not deliberate sequencing.
6. **Better architecture suggestion:** State the sequencing explicitly in the Vision itself, not just in the Roadmap — it's a vision-level commitment (build on generic foundations) as much as a scheduling detail.
7. **Enterprise best practice:** Every cited platform (Odoo, Zoho, NetSuite, Xero, QuickBooks) achieved product-market fit in a narrow wedge before generalizing. None started horizontal. Say this is the model being followed — it turns "why isn't this generic yet" into a stated strategy.
8. **MVP recommendation:** Keep the vision aspirational (as requested) but add the two-horizon paragraph so the rest of the roadmap doesn't have to keep re-justifying sequencing.
9. **Future recommendation:** Revisit the vision's horizontal-expansion language once Modules 1–3 ship and there's real cross-industry demand signal — not before, and not based on speculation.

## §2 Business Goals

1. **Good:** Goal ordering already leads with daily-operating-system usage over VAT-only framing (v2's own reordering) — consistent with this message's priorities without further change.
2. **Missing:** No goal tied to configurability/extensibility as a measurable engineering property (e.g., "% of business rules expressed as configuration vs. code"), and no goal tied to time-to-support-a-new-industry-vertical.
3. **Should change:** Add one goal along these lines, framed as a design constraint the architecture is held to, not a near-term deliverable.
4. **Should be postponed:** Any goal implying multi-industry revenue before the UAE VAT vertical is profitable.
5. **Risks:** Goals are currently unmeasurable — no KPIs. Architecture decisions (including this review's recommendations) can't be tested against a goal that has no number attached.
6. **Better architecture suggestion:** N/A — goals aren't architecture, but should gain KPIs (weekly-active-Tenant rate, penalty-avoidance rate, Firm-segment ARR share) before Module 3 ships enough usage data to make them real.
7. **Enterprise best practice:** Goals with owners and a review cadence (quarterly OKR-style) outperform static goal lists — a process recommendation more than a document-content one.
8. **MVP recommendation:** Add the configurability/extensibility goal; leave numeric KPIs for later.
9. **Future recommendation:** Attach real KPI targets once usage data exists.

## §3 User Personas

1. **Good:** The Firm/Practice persona (added in v2) already anticipates multi-tenant-of-tenants — directly aligned with this message's ambition before this review even started.
2. **Missing:** No "Configurator/Administrator" persona — someone (Tenant Owner wearing a different hat, or a future dedicated role) who sets up numbering formats, templates, and settings for a Tenant or Firm. No "Developer/Integrator" persona for the Future Integrations priority.
3. **Should change:** Add both personas — additive, no restructuring needed.
4. **Should be postponed:** Building any tooling for these personas — they're vision-completeness additions now, not near-term features.
5. **Risks:** Without a named Configurator persona, every "configuration" request risks being routed to engineering as a code change by default, quietly defeating the configuration-over-customization principle from day one.
6. **Better architecture suggestion:** N/A at persona level.
7. **Enterprise best practice:** NetSuite/Salesforce explicitly separate Administrator, End User, and Developer personas with different tooling — adopt the same three-way conceptual split now, before building admin tooling.
8. **MVP recommendation:** Add the Configurator persona (mapped to Owner/Firm Admin, not a new system role yet).
9. **Future recommendation:** Developer/Integrator persona becomes concrete once external parties actually consume the API/webhooks.

## §4 User Roles

1. **Good:** The flat OWNER/STAFF model plus the explicit flag that Firm cross-tenant access is an *open architecture question needing its own ADR* — most teams under this kind of pressure would have quietly hacked this in. Keep that discipline.
2. **Missing:** No Role/Permission/Module/Action **data model**. This is the single most consequential gap against this message's RBAC priority — `role: OWNER | STAFF` as a hardcoded string is fine for Module 0, but does not extend to "future custom roles and permissions" without a real redesign.
3. **Should change:** 🟢 **Build now** — introduce a real Role/Permission data model in Module 1: `Role` (system-defined or Tenant-custom), `Permission` (module + action, e.g. `invoices:approve`), and the join tables connecting Users to Roles and Roles to Permissions. Ship with exactly the roles already planned (Platform Admin, Owner, Staff, Firm Admin) as system-defined rows in this model — not as a hardcoded enum.
4. **Should be postponed:** 🔴 The UI/tooling for Tenants to define their *own* custom roles — genuinely complex UX, not needed until a paying customer asks for it.
5. **Risks:** If RBAC stays a hardcoded string through Modules 1–4, every module will accumulate `if (role === 'OWNER')` checks scattered through controllers and services — directly contradicting this message's own "no hardcoded business logic" priority, and creating exactly the technical debt this review exists to prevent. Retrofitting a real permission model after four modules hardcode role checks is a materially larger rewrite than building it correctly now.
6. **Better architecture suggestion:** One `hasPermission(user, 'invoices:approve', tenantContext)` service/middleware function, backed by the data model above — every module calls this; none compare role strings directly. Direct extension of [ADR §13.1].
7. **Enterprise best practice:** This is the same shape as AWS IAM and Salesforce's permission model — Role = named bundle of Permissions; Permission = Module + Action; deny-by-default, principle of least privilege.
8. **MVP recommendation:** Build the data model and `hasPermission()` now; no custom-role UI yet.
9. **Future recommendation:** Custom role builder, permission templates per industry vertical, delegated administration (a Firm Admin creating roles scoped only to Tenants they manage).

## §5 Modules

1. **Good:** Module-ordered delivery ([ADR §1]) is the right instinct and should **not** be abandoned in favor of "build the engines first" — this is the strongest structural defense this project already has against the platform-before-product trap.
2. **Missing:** No explicit home for configuration/settings work. Right now VAT rate, plan limits, and (planned) numbering/branding/locale settings have no single owning module.
3. **Should change:** 🟡 Fold a general Settings/Configuration capability explicitly into Module 1 — not a new numbered module, but an explicit sub-scope, so later modules don't each invent their own settings pattern ad hoc.
4. **Should be postponed:** Reordering Modules 2–5 to build "the RBAC engine" or "the workflow engine" first. Sequencing discipline is a strength — keep it exactly as-is.
5. **Risks:** The temptation to insert a "Module 0.5: Platform Engines" before Module 1 is the single biggest concrete risk this review can name. Flag it explicitly so it doesn't happen by drift.
6. **Better architecture suggestion:** Treat "engines" as cross-cutting infrastructure that gets a **thin v1** alongside Module 1 (permission model, settings schema, notification interface) and a **thick v2** only once 2–3 real modules exist to generalize from honestly.
7. **Enterprise best practice:** The "rule of three" — don't generalize an abstraction until you have three concrete cases needing it. Modules 1–3 will *give* three concrete config/notification/workflow needs to generalize from, rather than guessing them now.
8. **MVP recommendation:** Keep the 0–5 sequence; add Settings to Module 1's scope; do not add a dedicated engines module before it.
9. **Future recommendation:** A deliberate "Platform Generalization" initiative once Modules 1–3 are live, extracting the by-then-proven patterns into the formal engines this message asks for.

## §6 Business Workflows

1. **Good:** Workflows are already written as actor-based sequences, the right level of abstraction pre-implementation; §6.12's "Daily Operations → Passive VAT Readiness" already captures the "compliance as byproduct" thesis well.
2. **Missing:** No workflow for approval chains (e.g., large-invoice sign-off) or notification triggers (e.g., customer notified on invoice issuance) — the two most concrete near-term seeds of the Workflow and Notification priorities.
3. **Should change:** Add 1–2 illustrative workflows naming where a *future* engine would plug in, without building the engine now.
4. **Should be postponed:** 🔴 A generic, configurable approval-workflow *system*. Model the one known need — a large-invoice sign-off — as a simple conditional check, not a rules engine.
5. **Risks:** Jumping straight to a generic workflow engine to handle "require approval above X" means spending weeks on configurable state machines for a rule that's currently just one threshold comparison.
6. **Better architecture suggestion:** 🟢 A single configurable field (e.g., an approval-threshold amount on Business Profile settings) checked by the invoice-issuance service. This *is* "configuration over customization" done right-sized — genuinely configurable, without being an engine.
7. **Enterprise best practice:** Stripe, Linear, and most modern SaaS platforms ship "workflow-lite" (a handful of config toggles) for years before any customer-facing workflow builder — a visual workflow builder is typically a Series B+ investment, not an MVP one.
8. **MVP recommendation:** Add configurable threshold-based approval in Module 2/3; do not build a workflow engine.
9. **Future recommendation:** Once 3+ distinct automation needs exist (approval, low-stock reorder, overdue-invoice reminder), generalize into a lightweight trigger–condition–action model — still short of a full BPMN-style engine even then.

## §7 Business Rules

1. **Good:** VAT rules are already externalized into a structured, sourced table rather than buried in prose — effectively "rules as data" before any code exists, a genuinely good starting posture.
2. **Missing:** No statement of *where* these rules will live in code — the single most direct lever against "no hardcoded business logic."
3. **Should change:** 🟢 Mandate (this belongs in a future ADR, flagged here) that every KB-sourced rule is implemented as one named, testable function in a shared rules module — never inlined as a magic number or string comparison in a controller or the UI.
4. **Should be postponed:** 🔴 A full declarative, admin-editable rules engine (JSON-configurable rules changeable without a deploy). UAE VAT rules change by Cabinet Decision, not daily — "redeploy to update a rule" is an acceptable MVP trade-off.
5. **Risks:** Without the named-function discipline, VAT category logic risks being copy-pasted across Invoice, Purchase, and Credit Note code paths — exactly the duplication the service layer ([ADR §13.1]) exists to prevent.
6. **Better architecture suggestion:** One `VatRulesService` (or equivalent) is the single place every VAT classification/calculation rule from the Knowledge Base is implemented; every module calls it, none reimplement it.
7. **Enterprise best practice:** NetSuite/SAP's declarative rules engines are exactly this pattern generalized — start at the code level, generalize to data only once there's a proven need to change rules without a deploy.
8. **MVP recommendation:** Mandate the named-service-function discipline now (cheap); skip the declarative rules engine.
9. **Future recommendation:** A genuinely declarative rules engine becomes far more justified if/when Ledger expands beyond UAE VAT — tie this directly to the Horizon 2 expansion named in §1's review above, not to Module 1–5.

## §8 Functional Requirements

1. **Good:** FR IDs are stable and traceable to modules — solid existing practice worth keeping.
2. **Missing:** None of this message's 12 priorities are represented as FRs yet — Configuration, RBAC-as-data, Notification abstraction, Feature Flags, Numbering-as-a-service are all absent.
3. **Should change:** Add a new FR block per priority, scoped to the "thin abstraction" level described throughout this review — concrete and buildable, not aspirational.
4. **Should be postponed:** FRs for command palette, global search, saved views, a workflow-builder UI, and multi-channel notifications beyond email — all real, all later.
5. **Risks:** Without thin-engine FRs, these either don't get built at all (reverting to hardcoded checks) or get over-built by an engineer with no scoped requirement to check against — both bad outcomes, in opposite directions.
6. **Better architecture suggestion:** N/A beyond the above.
7. **Enterprise best practice:** Tag FRs MoSCoW-style (Must/Should/Could/Won't) on the next revision, so "thin RBAC now" vs. "custom-role UI later" is explicit at the requirement level, not just in surrounding prose.
8. **MVP recommendation:** Add the thin-engine FRs listed in the "Missing" roundup at the end of this review.
9. **Future recommendation:** Full-engine FRs, gated behind real customer signal.

## §9 Non-Functional Requirements

1. **Good:** Mobile First is already an explicit, elevated NFR in v2 — directly satisfies priority #9 with no further change needed.
2. **Missing:** No Backup/DR NFR (RPO/RTO), no explicit Encryption-at-rest/in-transit NFR, no data-export/portability NFR (relevant to both future integrations and the already-flagged Tenant-offboarding gap).
3. **Should change:** 🟢 Add Backup/DR, Encryption, and Configuration-auditability as explicit NFRs — even before specific numeric targets are chosen (which is blocked on the still-open deployment vendor decision, [ADR §12]).
4. **Should be postponed:** 🔴 Hard numeric SLA targets (99.9% uptime, etc.) — premature before a vendor and real usage exist. State qualitative floors now, quantify later.
5. **Risks:** No Backup/DR NFR today means it could genuinely be forgotten until an incident forces the conversation — a classic "invisible until it's a crisis" gap.
6. **Better architecture suggestion:** N/A beyond stating the NFRs.
7. **Enterprise best practice:** Any enterprise SaaS vendor holding financial records with 5–15 year retention ([KB §8.2]) is expected to state RPO/RTO and encryption posture in a customer security questionnaire — build this NFR now so it isn't a scramble later.
8. **MVP recommendation:** Add Backup/DR and Encryption as non-negotiable floor NFRs (e.g., "daily automated backups, encrypted at rest, quarterly restore test") even before a specific vendor/number is chosen.
9. **Future recommendation:** Formal SLA, geographic redundancy, and a documented, drilled DR runbook once there are enterprise-tier customers who'd require them contractually.

## §10 Security Requirements

1. **Good:** This section already tracks most of this message's asks as Built or "planned before production" (token revocation, MFA, rate limiting, password policy) — the closest-aligned section in the whole Bible already; the Firm cross-tenant risk note added in v2 is genuinely sophisticated pre-existing thinking.
2. **Missing:** Encryption (at rest/in transit) is not mentioned at all. Soft delete is implied elsewhere but never stated here as a formal security control. Backup/DR is entirely absent. Row-Level Security is only a "future" note in [ADR §7], not restated here. Session management (concurrent sessions, idle timeout) is absent beyond the raw 8-hour JWT expiry.
3. **Should change:** Consolidate all 15 of this message's security categories into this section explicitly — even where the honest answer is "deferred, tracked as [item]." Several currently read as simple oversights rather than deliberate deferrals.
4. **Should be postponed:** 🔴 Full session management (concurrent-session caps, device management, "log out everywhere") — real but low pre-launch urgency. 🔴 MFA can reasonably reach Platform Admin first (highest blast radius) before it's required for every Tenant Owner.
5. **Risks:** Encryption-at-rest/in-transit is usually "free" (vendor-provided) but must be explicitly required and verified, not assumed — a silent-gap risk if the deployment vendor decision doesn't check for it explicitly.
6. **Better architecture suggestion:** A security checklist mapped 1:1 to this message's 15-item list, each tagged Built / Planned-pre-production / Deferred — turns this section into an audit-ready artifact rather than a narrative.
7. **Enterprise best practice:** This message's list maps almost exactly onto SOC 2 / ISO 27001 control categories. Aligning to that vocabulary now — without pursuing certification yet — forces completeness and gives future enterprise customers or investors a framework they already recognize.
8. **MVP recommendation:** 🟢 State encryption-at-rest/in-transit as non-negotiable; 🟢 formalize soft-delete as a security control, not just a retention detail; 🟢 state a minimal backup requirement. 🔴 Defer full session management, RLS, and MFA beyond Platform Admin.
9. **Future recommendation:** RLS on the Postgres migration (already flagged in [ADR §7]), SOC 2 readiness once selling to larger enterprise/Firm customers, full session management.

## §11 Compliance Requirements

1. **Good:** Tightly sourced to [KB] [CONFIRMED] rules only — appropriately narrow, no speculation.
2. **Missing:** PDPL (UAE data protection) research is still an open, under-weighted gap — and it's now more urgent, since the Firm-accesses-multiple-Tenants model raises a genuine "who consented to this data being visible to whom" question that doesn't exist in the single-Tenant model.
3. **Should change:** Elevate PDPL from a passing mention to a tracked, named requirement tied directly to the Firm-access architecture decision ([§4]).
4. **Should be postponed:** 🔴 SOC 2/ISO certification *pursuit* itself (expensive, multi-month, needs a live product) — but not the practice of writing controls in that vocabulary now (see §10), which is nearly free.
5. **Risks:** A Firm accessing a client Tenant's data without that Tenant's explicit, revocable consent is a plausible PDPL/contractual problem the moment the Firm-access model ships — this should be a **requirement on that ADR**, not an afterthought bolted on post-launch.
6. **Better architecture suggestion:** Whatever access-grant model resolves the Firm question should include an explicit Tenant-side grant/revoke step — "this Tenant has granted Firm X access, and can revoke it" — as a compliance requirement, not just an access-control nicety.
7. **Enterprise best practice:** Standard controller/processor thinking under GDPR-family law (PDPL is UAE's analogue) — the Tenant is the controller of its own records; a Firm accessing them functions like a processor and needs an explicit legal basis, which the product should mirror as an explicit UI action.
8. **MVP recommendation:** Add the Tenant-facing consent/grant/revoke requirement to the scope of the future Firm-access ADR — not built now, but required in that ADR's scope, not left implicit.
9. **Future recommendation:** Formal PDPL compliance review, timed to precede the Firm-access feature shipping (not Module 1, but before Firm access goes live).

## §12 Assumptions

1. **Good:** Already a well-structured, trackable register (A1–A21) — exactly the mechanism this review's findings should feed into.
2. **Missing:** None of this message's new priorities are registered yet — effectively, this whole review is "twenty more rows for this table" (concrete rows listed in the roadmap section below).
3. **Should change:** Append the new rows once this review's recommendations are accepted.
4. **Should be postponed:** N/A — the register itself is a living artifact, not a deliverable to postpone.
5. **Risks:** If this review's findings aren't captured in the register, they risk staying only in this conversation and not surviving into the next planning session — the exact failure mode the register exists to prevent.
6. **Better architecture suggestion:** N/A.
7. **Enterprise best practice:** An assumptions/open-questions log is standard at disciplined product orgs (Amazon's PRFAQ process, Google design docs' "open questions" section) — this project already does it well; keep it current.
8. **MVP recommendation:** Append rows from this review at the next Bible revision (explicitly deferred per "do not modify yet").
9. **Future recommendation:** N/A.

## §13 Out of Scope

1. **Good:** Already explicitly excludes ERP/payroll, AI bookkeeping, deep integrations, and a full Analytics Dashboard — mostly still correct even under the expanded vision.
2. **Missing:** Doesn't yet explicitly exclude a generic workflow engine, a generic notification engine, or a custom-role builder UI — given this message's priorities, these need to be named out loud as *deliberately* deferred, not missing by omission.
3. **Should change:** Add explicit lines for each: full workflow engine (only threshold config now), full notification engine (email only now, others behind a provider interface), custom-role builder UI (data model yes, UI no), global search/command palette/saved views (all deferred), AI features (hooks only, no features).
4. **Should be postponed:** (Same list — these *are* the postponements.)
5. **Risks:** Without explicit "not now" lines for each of the 12 priorities in this message, Module 1–3 build risks scope creep from an engineer excited about "building it right" quietly starting a workflow engine instead of shipping the next module.
6. **Better architecture suggestion:** N/A.
7. **Enterprise best practice:** Explicit "won't do (yet)" lists are a hallmark of disciplined product orgs under ambitious scope (Basecamp's "no" list, Linear's scoping discipline) — exactly the right instinct for a team excited about an enterprise vision to protect itself from its own ambition.
8. **MVP recommendation:** Add the explicit out-of-scope list above.
9. **Future recommendation:** Revisit each line against real usage signal, not enthusiasm.

## §14 Future Roadmap

1. **Good:** The "Future Vision capabilities — architecture now, build later" table (added in v2) already anticipates almost exactly this message's engine list — genuinely well-positioned; it just needs new rows.
2. **Missing:** RBAC-as-data-model, Configuration Engine, Workflow-lite, Notification abstraction, Feature-flag service, and the UX capability list (search/command-palette/saved-views/etc.) aren't in the table yet.
3. **Should change:** Extend the existing table with these rows, using the same "what today's decisions should keep open" framing — a direct, low-effort extension of an already-good pattern (full content in the roadmap section below).
4. **Should be postponed:** (Same items — see roadmap.)
5. **Risks:** Without adding these, the next engineer reading the roadmap won't know these are intentionally sequenced later versus simply forgotten.
6. **Better architecture suggestion:** N/A — the format is already correct, just needs more rows.
7. **Enterprise best practice:** Staged roadmaps with an explicit "keep-open" column are how platform teams at Stripe/Linear communicate "not now, but not never" without inviting scope creep.
8. **MVP recommendation:** Extend the table per this review's roadmap section.
9. **Future recommendation:** N/A.

## §15 Glossary

1. **Good:** Already bilingual between VAT-domain and platform-domain terms, well organized.
2. **Missing:** RBAC terms (Role, Permission, Least Privilege), engine terms (Configuration/Workflow/Notification Engine, Feature Flag), UX terms (Command Palette, Saved View) aren't defined yet.
3. **Should change:** Append these terms alongside whichever section update introduces each one.
4. **Should be postponed:** N/A — glossary entries are cheap and low-risk.
5. **Risks:** Minimal.
6. **Better architecture suggestion:** N/A.
7. **Enterprise best practice:** N/A.
8. **MVP recommendation:** Add terms alongside other section updates.
9. **Future recommendation:** N/A.

---

## Missing Modules

1. **Configuration & Settings** — not a new numbered module; an explicit sub-scope of Module 1 (see §5 review).
2. **Payments / Reconciliation** — genuinely missing today. Invoices exist (planned) but nothing tracks payment receipt against them; `Invoice.status` defaults to `UNPAID` with no lifecycle beyond that. A real gap for a "daily operating system" vision, not just a VAT one.
3. **Notifications / Communications** — even the thin (email-only) version needs a home; currently has none.
4. **Platform Configuration / Feature Flags** (Platform-Admin-facing) — which features are enabled per plan and, eventually, per Tenant override; distinct from Tenant-level settings.
5. **Reporting & Analytics** — Module 3 covers VAT-adjacent operational reports; a genuine Analytics module is correctly deferred but should be named as a real future module, not folded silently into "Module 3 does reports."
6. **Integrations / Webhooks** — future, but deserves a placeholder in the module map so it isn't invented ad hoc later.
7. **Approval / Workflow** *(naming only — not building yet)* — see §6 review; name it now so its eventual thin-then-thick evolution has a place to live.

## Missing Engines

1. **RBAC/Permission Engine** — 🟢 data-model-first, per §4.
2. **Configuration Engine** — 🟢 a Plan → Tenant settings cascade (numbering formats, payment terms, locale, branding).
3. **Notification abstraction** — 🟢 thin provider-pattern interface, email-only implementation first.
4. **Feature Flag Engine** — 🟢 generalizes the *already-existing* `plans.js` `features` object into a real `hasFeature(tenantId, key)` service — this one is nearly free, since the raw data already exists in Module 0.
5. **Numbering Engine** — 🟢 generalized sequence allocation (per [KB §8.1]'s atomicity requirement) for every document type needing one (Invoice, Credit Note, Debit Note, future Purchase Order) — build once, not per-document-type.
6. **Rules/Validation Engine (thin)** — 🟢 named service functions per §7, not a declarative engine.
7. **Audit/Event Logging Engine** — 🟡 generalize Module 4's Audit Log into a cross-cutting event-capture service used by every module, not a Module-4-only feature bolted on late.
8. **Workflow Engine (full)** — 🔴 defer until 3+ concrete automation needs exist.
9. **Search Engine** — 🔴 defer until real data volume exists.
10. **AI Orchestration layer** — 🔴 defer entirely; keep service-layer functions clean enough to be callable by one later.

## Missing Services (ADR §13.1 sense — one named, testable function per concern)

`VatRulesService` · `PermissionService` (`hasPermission()`) · `NotificationService` · `FeatureFlagService` (`hasFeature()`) · `NumberingService` · `FileStorageService` (implied by [ADR §9] but never named) · `AuditService` (nothing currently writes to `AuditLog` — a pre-existing gap, now sharpened) · `SettingsService` (resolves effective config: Plan defaults → Tenant overrides).

## Missing Security Features

Encryption at rest/in transit (explicit statement, not assumed) · Backup + tested automated restore · DR runbook with RPO/RTO targets · Row-Level Security (Postgres, future, already flagged in [ADR §7] but not restated in [§10]) · Session management (concurrent sessions, idle timeout, "log out everywhere") · Soft-delete as a **universal** convention — not just financial documents, but Customers/Suppliers/Products too, so a deleted Supplier doesn't break a historical invoice's reference · Secrets rotation policy · Dependency/vulnerability scanning (unmentioned anywhere) · Security headers / OWASP baseline (CSP, HSTS) (unmentioned) · Webhook signature verification (future, worth flagging now given the Integrations priority).

## Missing Configuration Options

🟢 Near-term (belongs in Module 1–2): invoice numbering format/prefix/reset-cadence, invoice template/branding basics, payment terms per Customer, default VAT category per Product/Service, date format, currency display, language/locale preference, one transactional email template, approval threshold amount.
🔴 Explicitly deferred: full custom-fields engine (genuinely complex to do well — flag as *not* MVP even though the user's own example list included it), rich notification-preference center, multi-template branding system.

## Missing Workflows

Payment recording/reconciliation against an invoice · Customer/Supplier onboarding within a Tenant (distinct from Tenant onboarding itself) · Notification delivery (invoice emailed to customer) · Firm-grants-access / Tenant-approves-and-can-revoke-access (ties directly to the [§11] PDPL point) · Data export / Tenant offboarding (already flagged as a gap, reaffirmed here with more urgency) · Forced password reset / email invite for new Owner/Staff accounts (already [A17], reaffirmed).

## Missing Business Rules

**Soft-delete referential integrity**: a deleted Customer/Supplier/Product must remain visible (snapshotted, not live-joined) on historical documents that reference it — a direct generalization of the snapshot-at-issuance principle already established for Business Profile and Invoices in the Knowledge Base. **Numbering-sequence rule applies to every document type**, not just Invoices — Credit Notes are already covered; Debit Notes and any future Purchase Order need the same explicit rule. **Plan-downgrade data-retention rule**: undefined today — what happens to Premium-only data (Audit Log entries, OCR documents) if a Tenant downgrades? **Firm-access revocation rule**: undefined and genuinely non-obvious — does revoking a Firm's access retroactively hide historical data they already viewed, or only block future access?

## Missing Audit Requirements

An explicit taxonomy of **mandatory-to-log actions** (login, permission/role change, plan change, data export, Firm access grant/revoke, financial document issuance/void, settings change) — today's `AuditLog.action` is a free string with no defined vocabulary. **Audit log immutability** (append-only/tamper-evident) is never explicitly stated. **Audit log retention period** should explicitly inherit the [KB §8.2] retention logic — not yet stated that the Audit Log itself must be kept 5+ years. **Who can read the audit log** ties directly to the already-flagged [A20] plan-gating reconsideration.

## Missing Reporting Capabilities

Payment/aging reports (who owes what, overdue) — blocked on the missing Payments module above. **Firm-level roll-up reporting** — a Firm managing 20 Tenants wanting a portfolio view is a real enterprise expectation once the Firm persona is real, and isn't mentioned anywhere yet. Exportable report formats (CSV/PDF) — not explicitly required anywhere. Comparative/trend (period-over-period) reporting — correctly Analytics-Dashboard territory and correctly deferred, just naming the gap for completeness.

## Missing System Settings

**Platform-wide settings** (Platform Admin level: default plan limits, global feature flags, maintenance mode) — no concept of platform-level configuration distinct from Tenant-level exists today. **Tenant-level default settings** (numbering format, default payment terms, default VAT category) — the Configuration Engine's actual content. **User-level preferences** (language, notification preferences, date/number format) — the cheapest tier, currently entirely absent.

---

## Product Bible Score: 6 / 10

Two framings, because a single number undersells the nuance:

- **Against the original VAT-compliance-first scope (v1/v2 before this message): 8/10.** Genuinely excellent documentation discipline, correct multi-tenancy and security fundamentals, well-sourced compliance content, and an honest, actively-maintained assumptions register. This is a strong foundation — none of it needs to be thrown away.
- **Against this message's enterprise-platform ambition: 4/10.** The vision language is now aligned (after v2's Firm addition), but almost none of the concrete engine/data-model/security-completeness work this message asks for is represented yet — RBAC-as-data, configuration/notification/feature-flag abstractions, backup/DR, encryption posture, and the missing-modules list above are all currently absent.

**Blended score: 6/10.** This gap is expected — a vision document naturally precedes detailed engineering design — but it should not be read as "ready to start Module 1." The prioritized roadmap below is what closes it.

---

## Prioritized Roadmap — Before Any Development Starts

### Phase 0 — Architecture completion (before Module 1)
1. Resolve the Firm/multi-Tenant cross-access architecture via its own ADR ([A18]) — now more urgent, since the RBAC data model design depends on knowing its shape.
2. Design the RBAC data model (Role/Permission/Module/Action + joins) — schema-level now, tooling later.
3. Design the Settings/Configuration data model (Plan → Tenant cascading settings).
4. Design the generalized Numbering Service (before Module 2 needs its first sequence).
5. Design the Feature Flag service, generalizing the existing `plans.js` features object.
6. Design the Notification abstraction (interface + email-only implementation).
7. State Encryption, Backup/DR, and universal Soft-Delete explicitly in the NFR and Security sections.
8. Add the explicit "won't build yet" list (workflow engine, multi-channel notifications, custom-role UI, search/command-palette, AI features) to Out of Scope.
9. Scope PDPL + Firm-consent research into the Firm-access ADR from item 1.
10. Capture all of the above as new rows in the Assumptions register, then revise the Product Bible and likely open ADR-0002.

### Phase 1 — Module 1 (Tenant Foundation + Settings)
Business Profile, Customers, Suppliers, Products/Services, plus Settings (numbering format, default payment terms, locale/currency/date format, branding basics) built on the Phase 0 configuration model. RBAC data model live with system-defined roles (Owner/Staff/Firm Admin) — no custom-role UI yet.

### Phase 2 — Module 2 (Invoicing)
Built on `NumberingService`, `NotificationService` (email on issue), `FeatureFlagService` (Premium gating via `hasFeature()`, never a hardcoded plan string check). Threshold-based approval config, not a workflow engine.

### Phase 3 — Module 3 (VAT Position + Reporting + **Payments**, newly added)
VAT Return/filing-period tracking as already scoped, plus the newly-identified Payments/Reconciliation module. **Recommend pulling the Audit Log write-path forward into this phase** rather than waiting for Module 4 — once `AuditService` exists as a real event-capture service, wiring it into Module 2/3's write operations is cheap; waiting means retrofitting audit calls into already-shipped code.

### Phase 4 — Module 4 (Access Control)
Full permission-management UI (custom roles), Audit Log viewer, MFA rollout beyond Platform Admin, session management.

### Phase 5 — Module 5 and beyond
OCR, then AI-assisted bookkeeping (reuses OCR output + the clean service-layer functions built since Phase 0), then Workflow Engine generalization (once 3+ real automation needs exist), then the UX layer (search, command palette, saved views), then broader integrations (webhooks, accounting software), then — only once Horizon 1 has real traction — the Horizon 2 multi-industry generalization named in the revised §1.

---

This review deliberately stops short of editing the Product Bible, ADR-0001, or the Knowledge Base. The next step, if these recommendations land, is a Product Bible v3 revision incorporating the roadmap above and a superseding/additive ADR covering the Firm-access model and the RBAC/Configuration/Numbering/Notification/Feature-Flag service boundaries — both explicitly out of scope for this document.
