# Ledger — Product Bible

- **Status:** Version 2 — revised Product Vision
- **Date:** 2026-07-30 (originally published 2026-07-30; Product Vision and dependent sections revised same day — see Revision Note)
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Built on:** [ADR-0001: Baseline System Architecture](adr/0001-baseline-architecture.md) (Accepted) and the [UAE VAT Knowledge Base](knowledge-base/README.md) (Version 1)
- **Purpose:** the single source of truth for *what Ledger is and does*. ADR-0001
  answers "how is it built"; the Knowledge Base answers "what UAE VAT rules
  does it need to know"; this document answers "what product are we
  building, for whom, and to what standard" — and ties the other two
  together into one coherent product definition.

### Revision Note (v1 → v2)

Version 1 framed Ledger primarily as a VAT compliance tool. That
undersold the product: **Ledger is a commercial, multi-tenant B2B SaaS
platform for the UAE market that businesses run their daily operations
on — VAT compliance is a natural by-product of that daily use, not the
product's sole purpose.** Version 2 rewrites [§1 Product Vision](#1-product-vision)
in full to reflect this, and propagates the necessary consistency changes
through Business Goals, Personas, Roles, Modules, Workflows, Functional and
Non-Functional Requirements, Assumptions, Out of Scope, Future Roadmap, and
the Glossary. **ADR-0001 itself is unchanged** — this revision surfaces one
genuine new architectural question (a Firm/Practice managing multiple
Tenants, [§4]) that ADR-0001's current single-Tenant-per-JWT model does not
yet resolve, and registers it as an open decision requiring its own ADR
before implementation, per [ADR §13.3], rather than resolving it here.

## How to use this document

This is a reference document, not a linear read. Each section is
self-contained and cross-links to the ADR and Knowledge Base rather than
repeating their content — where you see `[KB §X.Y]`, that's a pointer into
the [Knowledge Base](knowledge-base/README.md)'s topic files; where you see
`[ADR §N]`, that's a pointer into [ADR-0001](adr/0001-baseline-architecture.md).

Per ADR-0001 Principle 13.2 (Documentation First) and 13.3 (AI Collaboration
Rules), this document is updated **before** any module that changes what's
described here is implemented — it is not a retrospective summary. Per
13.3, it is not edited silently: material changes to Vision, Goals, Modules,
or Business Rules should be called out to the project owner, the same way
architectural changes are.

## Table of Contents

1. [Product Vision](#1-product-vision)
2. [Business Goals](#2-business-goals)
3. [User Personas](#3-user-personas)
4. [User Roles](#4-user-roles)
5. [Modules](#5-modules)
6. [Business Workflows](#6-business-workflows)
7. [Business Rules](#7-business-rules)
8. [Functional Requirements](#8-functional-requirements)
9. [Non-Functional Requirements](#9-non-functional-requirements)
10. [Security Requirements](#10-security-requirements)
11. [Compliance Requirements](#11-compliance-requirements)
12. [Assumptions](#12-assumptions)
13. [Out of Scope](#13-out-of-scope)
14. [Future Roadmap](#14-future-roadmap)
15. [Glossary](#15-glossary)

---

## 1. Product Vision

### Vision Statement

**Ledger is a secure, multi-tenant, subscription-based B2B SaaS platform
for the UAE market — the daily operating system a business runs on, not a
tool it opens once a quarter to file VAT.**

Ledger serves two connected audiences through one platform: businesses that
run their own operations directly, and accounting firms, consultants,
service providers, and enterprises that onboard and manage *multiple*
client businesses through it. Both experience the same product; what
differs is scale and role, not the platform itself. Every business
(Tenant) on Ledger — however it was onboarded, and by whomever manages it —
operates in a completely isolated data space and functions independently,
per the multi-tenancy model already locked in at [ADR §7].

### The product, not just the filing

The goal is not only to help a business at VAT filing time. Ledger should
become the system a business reaches for every working day: managing its
**Business Profile**, its **Customers** and **Suppliers**, its
**Products and Services**; creating **Sales Invoices**, recording
**Purchase Invoices** and **Business Expenses**; tracking VAT
automatically as a consequence of that activity; generating **Reports**;
storing every business record securely; and maintaining a complete
**audit history** of what happened and when.

This reframes VAT compliance rather than removing it. **The more a
business uses Ledger for its normal daily operations, the easier VAT
filing becomes — because everything a filing needs is already there,
already organized, already classified.** Ledger reduces manual work by
applying UAE VAT rules automatically wherever the rules allow it to,
instead of expecting a business owner to understand tax regulations
themselves ([KB §2]–[§8] encode exactly this). **VAT compliance should be
a natural outcome of normal business operations, not a separate activity
performed only at filing time** — this sentence is the single idea Version
1 of this document undersold, and it is now the organizing thesis of the
whole product.

### Mobile-first, as a matter of principle

A business owner does not run their business from behind a desk. Ledger
must provide an excellent, fully-functional responsive experience —
generating invoices, recording purchases, viewing reports, checking VAT
summaries, and managing customers should all work without loss of
functionality on desktop, tablet, or mobile. This is not a
"responsive-if-convenient" afterthought; it is one of the core product
principles below, and it should shape UI and API design decisions from
here forward (see [§9] and the note on Module 0's existing fixed-width
shell needing reassessment against this principle).

### Built for what comes next

The architecture should support, and not preclude, capabilities the
product doesn't need to ship on day one: UAE e-invoicing (already a
confirmed near-term requirement, [KB §5.1]), OCR for purchase invoices
(Module 5), AI-powered bookkeeping assistance, third-party API
integrations, accounting-software integrations, an analytics dashboard,
and workflow automation. These should influence architectural decisions
**today**, the same way Module 0's schema already pre-modeled Modules 1–5's
tables so they wouldn't require disruptive migrations later ([ADR §1]) —
that precedent is exactly the discipline this broader future list should
receive too. See [§14 Future Roadmap](#14-future-roadmap) for how each
capability is expected to land, and what today's decisions should keep
open for it.

Ledger is not a general-purpose ERP, a payroll system, or a tax *advisory*
service exercising independent legal judgment — see
[§13 Out of Scope](#13-out-of-scope) for the boundary. Within that
boundary, it is the full daily operating system for a UAE business's
financial and compliance life, delivered to both individual businesses and
the firms that serve many of them at once.

### Core Product Principles

These nine principles are the lens every subsequent product and
architecture decision should be checked against. Where a principle is
already backed by a concrete decision elsewhere in this document set, it's
cross-referenced rather than restated.

1. **Multi-Tenant by Design.** Every Tenant's data is fully isolated,
   per [ADR §7]'s pooled multi-tenancy model — the platform's single most
   important guarantee. This vision adds a second layer above the Tenant:
   a Firm/Practice that manages several Tenants under one commercial
   relationship ([§3]/[§4]). Both layers must uphold the same guarantee:
   one Tenant's data must never be reachable by another Tenant, and — once
   designed — one Firm's managed Tenants must never be reachable by a
   different Firm.
2. **RBAC First.** Role-Based Access Control is a day-one design lens, not
   a Module 4 add-on. Every capability is reasoned about in terms of "who
   is allowed to do this" — from the existing Platform Admin / Owner /
   Staff split ([ADR §6]) through the Firm-level roles this vision
   introduces, to the fine-grained permission model already planned for
   Module 4.
3. **Subscription-Based SaaS.** Revenue is recurring and tiered
   (TRIAL/STANDARD/PREMIUM, already built in Module 0). This vision adds a
   second, distinct commercial dimension: a Firm managing many Tenants is
   its own valuable customer segment, worth a deliberate commercial model
   — not just N individual Tenant subscriptions informally bundled
   together (see [§2 Business Goals] and [§12 A18]).
4. **Mobile First.** A fully-functional responsive experience across
   desktop, tablet, and mobile is a baseline requirement for every
   user-facing capability, not a subset of them — see the dedicated
   discussion above and [§9].
5. **Compliance by Default.** VAT correctness is what happens
   automatically when a business uses Ledger normally. Every rule in the
   [Knowledge Base](knowledge-base/README.md) exists to be applied
   silently and correctly during ordinary daily use — invoicing,
   purchasing, expense recording — never surfaced as tax jargon the user
   has to resolve themselves.
6. **Automation Before Manual Work.** Wherever the product can compute or
   classify instead of asking the user to know the rule, it should — the
   "Business Logic First" principle already binding at [ADR §13.1],
   extended here beyond VAT specifically (deemed-supply gift tracking
   [KB §6.2], blocked-expense flagging [KB §4.4], and eventually OCR and
   AI-assisted bookkeeping are all the same underlying commitment).
7. **Security & Data Isolation.** The JWT-derived, never-client-supplied
   `tenantId` rule ([ADR §6]/[§7]) is the platform's core security
   invariant. Extending access across multiple Tenants for a Firm role
   ([§4]) is a genuine expansion of this attack surface and must be
   designed with that risk explicit, not incidental — see [§10].
8. **Scalability.** A stateless backend, pooled multi-tenancy, and
   module-ordered delivery ([ADR §1]/[§12]) already make horizontal
   scaling a matter of infrastructure, not architecture, as the product
   grows from individual SMEs to firms managing dozens of client Tenants.
9. **Future Ready.** Today's decisions — file storage ([ADR §9]), API
   design ([ADR §8]), and the services-not-controllers rule ([ADR §13.1])
   — are made with UAE e-invoicing, OCR, AI bookkeeping assistance, API
   and accounting-software integrations, analytics, and workflow
   automation in mind, even though most of these ship later. See
   [§14 Future Roadmap](#14-future-roadmap).

---

## 2. Business Goals

Ordered by how directly each goal is testable against what's already built
or specified. Goals 1–3 are new/reframed in this revision; goals 4–8 carry
forward from Version 1, reordered to reflect that compliance is now framed
as an outcome of daily use rather than the product's sole purpose.

1. **Become the daily operating system a UAE business actually opens every
   day**, not a quarterly-only tool — measured by how much of a Tenant's
   Customers, Suppliers, Products/Services, Sales Invoices, Purchase
   Invoices, and Expenses live in Ledger, not just its VAT filings. This is
   the primary retention and stickiness lever, ahead of any single
   compliance feature.
2. **Serve two distinct, connected commercial segments profitably**:
   businesses operating directly, and accounting firms, consultants,
   service providers, and enterprises managing multiple client businesses
   through one relationship. The second segment is a materially larger and
   stickier addressable market than SME-direct alone, and a distinct
   pricing/commercial model for it is a deliberate goal, not an
   afterthought (see [§12 A18]).
3. **Make VAT compliance an automatic by-product of normal use**, not a
   distinct goal a user has to separately pursue — every penalty category
   in [KB §7.3] (late registration, late filing, late payment, invoice
   defects, audit documentation failures) should be prevented outright or
   actively flagged well before it becomes a missed deadline, purely as a
   consequence of a business having used Ledger normally throughout the
   period.
4. **A non-tax-expert SME owner can operate the product without external
   help for routine compliance.** Registration awareness, invoicing, basic
   VAT return preparation should not require the Owner to have read the
   VAT Executive Regulations — the product should have already read them
   (see the [Knowledge Base](knowledge-base/README.md)).
5. **Deliver a genuinely excellent mobile and tablet experience**, not a
   desktop product with a mobile afterthought — a direct expression of the
   Mobile First principle ([§1]), and a real competitive differentiator
   given how much of the target audience manages their business away from
   a desk.
6. **Every number the product reports — on a VAT return, a sales report, a
   customer statement — is traceable to a real transaction.** Per [ADR
   §11] and the "derived, not entered" principle throughout the Knowledge
   Base ([KB §4.1], [§7.1]) — trust in the product depends on this being
   true across *all* reporting, not just VAT figures, now that reporting
   is a first-class daily-use feature and not a filing-time-only concern.
7. **Sustainable, tiered revenue**, extended beyond the existing TRIAL /
   STANDARD / PREMIUM per-Tenant model ([Module 0](#module-0--platform--tenant-management-built))
   to account for the Firm/multi-Tenant commercial segment in Goal 2 —
   Premium-tier gating (Audit Log, OCR) remains a natural fit between
   willingness-to-pay and cost-to-serve, and should be revisited once a
   Firm-level commercial model exists.
8. **Platform trust as the moat.** Against a spreadsheet or a part-time
   bookkeeper, the durable differentiator is *never getting a business's
   records wrong* — VAT treatment, invoice numbering, retained history —
   across the full range of daily operations this vision now covers, not
   just VAT specifically. This should bias every close product decision
   toward correctness over speed-to-ship, unchanged from Version 1.

---

## 3. User Personas

Personas describe *people*; [§4 User Roles](#4-user-roles) describes the
*system permissions* each maps to. A persona can map to more than one role
over time (e.g., an Owner is also, functionally, a Staff-equivalent user
day-to-day).

| Persona | Who they are | What they need from Ledger | Current system role |
|---|---|---|---|
| **The Platform Operator** | Runs Ledger itself — onboards paying Tenants, manages subscriptions, is the first line of support. Technically comfortable; not the product's compliance audience. | A reliable, low-friction way to onboard/manage Tenants and see platform-wide health, without seeing Tenant financial detail they don't need (already a deliberate Module 0 decision — [ADR-0001's predecessor README], reaffirmed here). | Platform Admin |
| **The SME Owner** | Runs a trading, retail, services, or trades business directly on Ledger. Not a tax professional — VAT is a compliance obligation they'd rather not think about more than necessary. Time-poor, risk-averse about penalties, price-sensitive on tooling spend, frequently managing the business from their phone between other work. | A daily operational tool (invoicing, customers, expenses) that happens to keep them compliant, not a compliance tool they have to remember to use; confidence that invoices are correct; a mobile experience that loses no functionality versus desktop. | Tenant User — role `OWNER` |
| **The Staff Bookkeeper/Admin** | An employee or contracted bookkeeper who does the day-to-day data entry — creating invoices, logging purchases — on the Owner's behalf. May have more transactional VAT familiarity than the Owner, but is not a licensed tax agent. | Fast, low-error data entry; guardrails against misclassification (e.g., [KB §2.3] vs [KB §2.4] confusion); a clear boundary on what they're allowed to change vs. what's Owner-only. | Tenant User — role `STAFF` |
| **The Accounting Firm / Service Provider** *(new in this revision — now central to the product vision, not a future maybe)* | An accounting practice, bookkeeping consultancy, tax agency, or corporate service provider that manages financial/VAT operations for **multiple client businesses at once** as its core commercial activity. This is a paying platform customer in its own right, distinct from any single Tenant it manages. | An efficient way to onboard, switch between, and work across many client Tenants without maintaining separate credentials per client; the same daily-operations tooling the SME Owner gets, applied across a portfolio of businesses; a commercial relationship (billing, plan) that reflects managing many Tenants, not one. | **Not yet modeled as a role.** This is a committed product direction as of this revision, but the *mechanism* by which a Firm safely accesses multiple Tenants is a genuine open architecture question — see [§4] and [§12 A18]. |
| **The External Tax Agent** *(narrower than the Firm persona above — may or may not be affiliated with one)* | A licensed UAE tax agent engaged for VAT return review/filing sign-off or complex judgment calls (e.g., the debit note ambiguity in [KB §5.4], or voluntary disclosure per [KB §7.1]) on a single Tenant's behalf, without necessarily managing that Tenant's day-to-day operations the way an Accounting Firm does. | Read access to accurate, exportable records for one Tenant; a way to review a VAT return before it's filed. | Not yet modeled — see [§12 Assumptions]. Likely a narrower, more restricted version of whatever access model is designed for the Firm persona, not a separate mechanism. |
| **The FTA Auditor** *(indirect stakeholder, never a system user)* | Never logs into Ledger, but every design decision about invoice immutability, numbering, retention, and evidence-linking ([KB §5.1], [KB §8.1], [KB §8.2]) exists because this persona might one day ask for it. | N/A — but shapes requirements throughout §7–§11 below. | N/A |

---

## 4. User Roles

Roles are the system-enforced permission boundaries. Per [ADR §6], the
`tenantId` a role operates within is always derived from the verified JWT,
never client-supplied — this is a hard platform rule, not a per-role
detail, and applies to every role below.

| Role | Identity space | Can do today (Module 0) | Planned scope (later modules) |
|---|---|---|---|
| **Platform Admin** | Separate JWT secret/audience from all Tenant roles ([ADR §5]/[§6]) | Onboard Tenants + mandatory Owner, change plan, suspend/reactivate, create Staff, view usage | No planned expansion of Platform Admin into Tenant-financial-data visibility — deliberately kept management-level only, consistent with the existing spec |
| **Tenant Owner** (`role: OWNER`) | Tenant JWT identity space | Log in, view team | Everything Staff can do, plus: Business Profile edits ([KB §1.3]), plan-affecting actions, and any action the currently-unwired `requireOwnerRole` middleware ([ADR §6]) gets attached to as Modules 1–4 build out — this is the natural first real use of that middleware |
| **Tenant Staff** (`role: STAFF`) | Tenant JWT identity space | Log in, view team | Day-to-day transactional work once it exists — invoice/purchase entry — with Owner-only actions excluded per the table above. Fine-grained permissions beyond this flat split are explicitly Module 4's job ([ADR §6] future scalability note) |
| **Firm Administrator / Practice User** *(new — committed product direction, mechanism not yet designed)* | **Not yet defined — open architecture question** | N/A today | Manages multiple Tenants under one Firm-level account, per [§1]/[§3]. **This role cannot be added as a simple third identity space the way Platform Admin and Tenant User were** — it needs cross-Tenant access, which ADR-0001's current model (one `tenantId`, always singular, derived from the verified JWT, [ADR §6]/[§7]) does not accommodate. See the callout below. |
| **External Tax Agent** | Not modeled | N/A | Not committed — see [§12 Assumptions](#12-assumptions). Most likely a narrower, more restricted variant of whatever access model is designed for the Firm Administrator role above (read-heavy, export-capable, no ability to issue/void financial documents), rather than its own separate mechanism |

> **Open architecture question — flagged, not resolved, by this Product
> Bible revision.** ADR-0001 designed authorization around a single,
> singular `tenantId` per verified JWT ([ADR §6]/[§7]) — deliberately, as
> the strongest available guarantee against cross-tenant data leakage. A
> Firm Administrator who legitimately needs access to *multiple* Tenants
> breaks that singular assumption. Resolving this is real architecture
> work — candidate shapes include (non-exhaustively, and **none of these
> are decided here**): a Firm-scoped token that enumerates permitted
> Tenants with per-request Tenant selection, a short-lived
> Tenant-impersonation token issued to an already-authenticated Firm user,
> or a grant/membership model queried per request. Per [ADR §13.3], this
> requires its own ADR — evaluating the isolation trade-offs explicitly —
> **before** it's implemented, not a default chosen while building
> whichever module first needs it. Recommended timing: before Module 1
> locks in its Business Profile/Tenant-access patterns, since retrofitting
> cross-Tenant access after single-Tenant assumptions are baked into
> several modules is more expensive than deciding it once, now.

---

## 5. Modules

The module-ordered delivery plan is itself an architectural decision
([ADR §1]) — each module ships fully working before the next starts, and
the database schema for later modules is pre-modeled now precisely so this
order doesn't force disruptive re-migrations. This section is the
authoritative scope statement per module; **Sections 6–8 below draw their
content directly from this map** rather than re-deriving it.

### Module 0 — Platform & Tenant Management (**Built**)
Platform Admin identity and Tenant lifecycle: onboarding (Tenant +
mandatory Owner), plan assignment/change ([Business Profile — KB §1.3]
groundwork), suspend/reactivate, Staff creation, usage visibility, Tenant
login and team view. No VAT business logic. Full detail: existing repo
READMEs and [ADR §1]–[§7].

### Module 1 — Tenant Foundation (**Planned, next**)
Business Profile ([KB §1.3]) as Tenant-self-service; **Customers and
Suppliers** as reusable, first-class records (Suppliers elevating what the
original technical assessment flagged as a free-text-only gap —
`Purchase.supplier` — into a real, reusable entity, mirroring Customers);
**Products and Services** as reusable records (broadening the existing
`Material` concept per the revised vision's daily-operations framing —
whether this is a rename or an additive relabeling is an implementation
detail for whoever builds Module 1, not decided here, per [ADR §13.3]'s
rule against renaming without approval); VAT rate management (extending
the existing `VatRateHistory` precedent). This is where TRN validation
([KB §1.2]) and registration-date capture ([KB §1.1]) should be fixed,
since Module 1 is the first module where those gaps become load-bearing
rather than latent. **Module 1 is also where the Firm/multi-Tenant access
architecture question ([§4]) should be resolved**, since Business Profile
is the first Tenant-self-service surface a Firm user would need to reach
on a client's behalf.

### Module 2 — Invoicing (**Planned**)
Tax Invoices and Simplified Tax Invoices ([KB §5.1]/[§5.2]), Credit Notes
and Debit Notes ([KB §5.3]/[§5.4]), discounts and shipping treatment
([KB §5.5]/[§5.6]), invoice numbering ([KB §8.1]), and multi-category
line-item VAT calculation ([KB §2.1]). **This is the module most directly
shaped by the UAE e-invoicing mandate** ([KB §5.1]) — the scope/timing
decision flagged there (build PINT AE-ready now vs. classic-invoice MVP
first) should be resolved before this module's design is finalized, not
during implementation.

### Module 3 — VAT Position & Reporting (**Planned**)
Purchases log (including imports/reverse charge, [KB §3.1]/[§3.3]),
recoverability calculation ([KB §4.2]–[§4.4]), the VAT Return itself
([KB §7.1]), filing-period tracking and deadline reminders ([KB §7.2]),
adjustments (bad debt relief, [KB §5.7]), and carry-forward tracking under
the new 5-year cap ([KB §4.3]). The single most business-logic-dense
module — the strongest early test case for the service-layer requirement
in [ADR §13.1]. **This revision also scopes day-to-day operational
reporting into Module 3** (sales register, purchase register,
customer/supplier statements) alongside the VAT-specific reports — a
direct expression of Business Goal 1's "daily operating system" framing.
The richer, cross-period **Analytics Dashboard** remains a separate,
later [Future Roadmap](#14-future-roadmap) item, not part of Module 3.

### Cross-cutting: Firm / Multi-Tenant Management (**Planned — architecture decision pending**)
Does not fit cleanly into the Module 0–5 numbering above, because it's an
access-model concern that potentially cuts across every module rather than
a module of its own. Scoping and sequencing this depends entirely on the
open architecture question flagged in [§4] — deliberately not force-fit
into a module number here until that's resolved.

### Module 4 — Access Control (**Planned**)
Fine-grained Staff permissions beyond the flat OWNER/STAFF split (extending
[ADR §6]'s existing note that this should be *additive*, not a replacement
of the current role field), and a working Audit Log **write path** — the
`AuditLog` table already exists in the Module 0 schema but nothing
populates it yet; Module 4 is where that gets fixed. Premium-plan gated,
per the existing plan-limits model.

### Module 5 — Automation (**Planned**)
Supplier-invoice OCR upload and review workflow. Premium-plan gated.
Depends on the file storage strategy already decided in [ADR §9].

### Cross-cutting, not a numbered module
File storage ([ADR §9]), structured logging ([ADR §10]), TRN validation
([KB §1.2]) — these are prerequisites that get pulled forward into whichever
module first needs them (see [ADR §9]/[§10]'s "before Module 2/5" notes),
rather than being their own module. **Mobile-first responsive design
([§1]) is likewise not a module** — it's a quality bar every module's UI
work is held to from Module 1 onward, including a deliberate reassessment
of Module 0's existing fixed-width sidebar shell against it (see [§9]).

---

## 6. Business Workflows

Each workflow lists its actors and the module it belongs to, so gaps
(workflows described here that aren't buildable yet) are visible rather
than implied.

### 6.1 Tenant Onboarding *(Module 0 — built)*
Platform Admin creates a Tenant + mandatory Owner in one transaction
(`tenant.create` + `user.create` + a seeded default VAT rate entry) →
Owner receives credentials directly from the Platform Admin (no
self-service signup, no email invite yet — see [§12 Assumptions]) → Owner
logs in for the first time.

### 6.2 Staff Addition *(Module 0 — built)*
Platform Admin creates a Staff user for an existing Tenant, subject to the
Tenant's plan's `maxUsers` limit → Staff logs in with credentials shared
directly by the Platform Admin (same temp-password gap noted in the
original assessment and [ADR §5] future scalability note).

### 6.3 Plan Change *(Module 0 — built)*
Platform Admin changes a Tenant's plan → downgrade is blocked if current
user count exceeds the target plan's limit → Tenant's available features
(Audit Log, OCR — Module 4/5 gated) change immediately on next request.

### 6.4 Suspension / Reactivation *(Module 0 — built)*
Platform Admin suspends a Tenant → every subsequent request from that
Tenant's users is rejected at the middleware level (`requireTenantUser`
re-checks status per request, not just at login) → reactivation restores
access immediately.

### 6.5 Tax Invoice Issuance *(Module 2 — planned)*
Owner/Staff selects a Customer → adds line items, each with its own VAT
category ([KB §2.1]) and rate → system determines full vs. simplified
invoice eligibility automatically ([KB §5.2]) → system assigns the next
sequential invoice number atomically ([KB §8.1]) → system snapshots
supplier/recipient identity ([KB §1.3]) onto the document → invoice is
issued and becomes immutable ([KB §5.1]/[§8.2]).

### 6.6 Invoice Correction *(Module 2 — planned)*
A previously issued invoice needs correcting (return, price error,
cancellation) → user initiates a Credit Note *from* the original invoice
(never edits it directly, [KB §5.3]) → system validates the reference and
computes the value delta → Credit Note is issued within the 14-day window
where applicable, with the system able to warn if that window is at risk.

### 6.7 Import / Reverse-Charge Purchase Entry *(Module 3 — planned)*
Owner/Staff logs a purchase from a non-UAE or Designated-Zone supplier →
marks it as an import → enters CIF value/customs duty → system
self-accounts VAT as both output and input tax entries in the same period
([KB §3.1]/[§3.3]), subject to the Tenant's actual recovery rights
([KB §4.4]) rather than assuming automatic net-zero.

### 6.8 VAT Return Preparation *(Module 3 — planned)*
System aggregates the period's output VAT (by category), recoverable input
VAT, adjustments (bad debt relief, etc.), and carry-forward tranche
consumption ([KB §4.1]–[§4.3], [§5.7], [§7.1]) → Owner/Staff (or the
external accountant persona, once modeled) reviews the generated return →
Tenant files with the FTA via EmaraTax themselves (see [§13 Out of Scope]
on direct filing integration).

### 6.9 Filing Deadline Monitoring *(Module 3 — planned)*
System tracks the Tenant's assigned filing period ([KB §7.2]) → surfaces
the next due date and, as it approaches, the concrete penalty at stake
([KB §7.3]) → this is one of the product's clearest expressions of Business
Goal #1 (zero avoidable penalties).

### 6.10 Tenant Deregistration / Offboarding *(not yet designed — gap)*
Flagged explicitly: neither [ADR-0001] nor the Knowledge Base fully designs
what happens when a Tenant stops being VAT-registered ([KB §1.1] edge case)
or leaves the platform entirely ([KB §8.2] edge case) while its historical
records remain subject to FTA retention obligations. This workflow needs
deliberate design before it's needed in practice, not reactively.

### 6.11 Firm Onboarding and Multi-Tenant Management *(new in this revision — planned, blocked on the [§4] architecture decision)*
A Firm/Practice is onboarded onto the platform (mechanism — Platform-Admin
-created, like today's Tenants, vs. a distinct self-service path — not yet
decided) → the Firm links or is granted access to multiple existing or
newly-created Tenants under its management → a Firm Administrator switches
between managed Tenants to perform work on each one's behalf, strictly
within whatever access boundaries the eventual RBAC/cross-tenant design
establishes → each managed Tenant's data remains fully isolated from every
*other* Firm and every other unrelated Tenant, exactly as it is between
any two Tenants today ([ADR §7]). This workflow cannot be built until the
[§4] open architecture question is resolved.

### 6.12 Daily Operations → Passive VAT Readiness *(new in this revision — the direct expression of the Product Vision's central thesis)*
Owner/Staff performs ordinary daily operations — issuing a sales invoice,
recording a purchase, logging an expense — for entirely ordinary business
reasons, not tax reasons → the system classifies and tracks each
transaction's VAT implications automatically at the point of entry
([KB §2], [§4]) → by the time a filing period ends, the VAT Return
([§6.8]) is substantially already assembled from data that was entered
because the business needed it for its own operations, not because
filing was imminent. This is the workflow Business Goals 1 and 3
([§2]) are measured against.

---

## 7. Business Rules

This section is a curated index into the Knowledge Base's confirmed rules —
it does not restate them in full (the Knowledge Base is the source of
truth for the rule itself; this is the "which rules matter and where" map).
Tags follow the [Knowledge Base legend](knowledge-base/README.md#legend--read-this-before-reading-any-topic-file).
**None of these rules changed in this revision** — what changed is *when*
they're applied: per [§1]'s Compliance by Default principle, every rule
below should be enforced continuously as part of ordinary daily data entry
([§6.12]), not treated as a filing-time-only checklist.

| Rule | Tag | Source |
|---|---|---|
| Standard VAT rate is 5%; mandatory registration at AED 375,000 trailing-12-month taxable supplies, voluntary at AED 187,500 | [CONFIRMED] | [KB §1.1] |
| TRN is exactly 15 numeric digits | [CONFIRMED] | [KB §1.2] |
| Four VAT categories — Standard Rated, Zero Rated, Exempt, Out of Scope — apply per line item, not per invoice | [CONFIRMED] | [KB §2.1] |
| Zero-rated export claims require documentary evidence; unsupported claims risk reclassification on audit | [CONFIRMED] | [KB §3.2] |
| Reverse charge self-accounts output = input tax on imports; no longer requires self-invoicing (2026 amendment) | [CONFIRMED] | [KB §3.1]/[§3.3] |
| Input VAT blocked for non-employee entertainment and personal-use motor vehicles, regardless of business purpose elsewhere | [CONFIRMED] | [KB §4.4] |
| Excess recoverable input VAT can only be carried forward 5 years (2026 amendment, was indefinite) | [CONFIRMED] | [KB §4.3] |
| Full tax invoices require the Article 59 field set; simplified invoices allowed only under AED 10,000 to a registered recipient, or any amount to a non-registered recipient | [CONFIRMED] | [KB §5.1]/[§5.2] |
| Issued invoices are immutable; corrections happen via Credit/Debit Notes only | [BEST PRACTICE, elevated to standing platform rule] | [KB §5.1]/[§5.3], [ADR §11] |
| Credit Notes must be issued within 14 calendar days of the qualifying event | [CONFIRMED] | [KB §5.3] |
| Invoice numbering must be sequential/unique per Tenant, gap-free, atomically assigned | [CONFIRMED] + [BEST PRACTICE implementation] | [KB §8.1] |
| Records retained 5 years (general), 10 years (capital assets), 15 years (real estate) from end of relevant tax period | [CONFIRMED] | [KB §8.2] |
| Foreign currency amounts convert to AED at full-precision CBUAE published rate on date of supply | [CONFIRMED] | [KB §8.3] |
| VAT rounds to the nearest fil, applied consistently (never mixed) per invoice | [CONFIRMED] | [KB §8.4] |
| Standard filing period is quarterly under AED 150M turnover, monthly at/above; return due 28 days after period end | [CONFIRMED] | [KB §7.2] |
| Late filing: AED 1,000/2,000; late payment: 14%/year monthly (Cabinet Decision 129/2025, eff. 14 Apr 2026); late registration: AED 10,000 | [CONFIRMED] | [KB §7.3] |
| UAE e-invoicing mandatory from 1 Jan 2027 (large) / 1 Jul 2027 (smaller), via 5-corner Peppol/PINT AE | [CONFIRMED] | [KB §5.1] |
| `tenantId` for any data access is always derived from the verified JWT, never client-supplied | [CONFIRMED — platform rule] | [ADR §6]/[§7] |

**Rules explicitly called out as evolving during 2026** (re-verify before
the module that depends on them locks in implementation): input VAT
recovery denial for tax-evasion-linked supplies, the 5-year carry-forward
cap's exact mechanics, and the e-invoicing technical field spec (published
February 2026, already updated once by June 2026) — see [KB README]'s
research-basis note.

---

## 8. Functional Requirements

Organized by module. Status: **Built** (Module 0, shipped), **Planned**
(specified here, not yet implemented). FR IDs are stable identifiers for
future cross-referencing (e.g., from a future ticket or test plan) — do not
renumber existing IDs when adding new ones; append.

### Module 0 (Built)
- **FR-001**: Platform Admin can authenticate and receive a scoped JWT.
- **FR-002**: Platform Admin can create a Tenant with a mandatory Owner in
  a single atomic operation.
- **FR-003**: Platform Admin can view all Tenants with plan, status, user
  count, and invoice count.
- **FR-004**: Platform Admin can change a Tenant's plan, blocked if the
  Tenant's current user count exceeds the target plan's limit.
- **FR-005**: Platform Admin can suspend and reactivate a Tenant.
- **FR-006**: Platform Admin can create a Staff user for a Tenant, blocked
  once the Tenant's plan user limit is reached.
- **FR-007**: Platform Admin can view a Tenant's usage detail (users,
  invoices, last login).
- **FR-008**: Tenant Owner/Staff can authenticate and receive a
  Tenant-scoped JWT; a suspended Tenant's users are rejected on their very
  next request, not just at next login.
- **FR-009**: Tenant Owner/Staff can view their own Tenant's team list.

### Module 1 (Planned)
- **FR-101**: Tenant Owner can view and edit their Business Profile
  (legal name, address, TRN, contact details) — see [KB §1.3].
- **FR-102**: System validates TRN format (15 numeric digits) on every
  entry point (Business Profile, Customer creation) — see [KB §1.2].
- **FR-103**: Tenant Owner/Staff can create, view, edit, and (soft-)remove
  Customer records, each with its own TRN.
- **FR-104**: Tenant Owner/Staff can create, view, edit Product/Service
  records (broadening the existing Material concept, [§5]) for reuse on
  future invoices.
- **FR-105**: Tenant Owner can view and update the Tenant's effective VAT
  rate, recorded as a new `VatRateHistory` entry rather than overwriting
  the previous rate — see [KB §2.1].
- **FR-106**: System captures a Tenant's VAT registration date, distinct
  from platform account creation date — see [KB §1.1].
- **FR-107**: Tenant Owner/Staff can create, view, edit, and (soft-)remove
  Supplier records, each with its own TRN — new in this revision,
  elevating Suppliers from a free-text field to a first-class record
  mirroring Customers ([§5]).

### Module 2 (Planned)
- **FR-201**: Tenant Owner/Staff can create a multi-line invoice, each line
  independently classified by VAT category — see [KB §2.1].
- **FR-202**: System determines full vs. simplified tax invoice type
  automatically at issuance — see [KB §5.2].
- **FR-203**: System assigns a sequential, gap-free, per-Tenant invoice
  number atomically at issuance — see [KB §8.1].
- **FR-204**: Issued invoices are immutable; no edit or delete path exists
  in the UI or API.
- **FR-205**: Tenant Owner/Staff can issue a Credit Note or Debit Note
  referencing an original invoice, with the system computing the value
  delta — see [KB §5.3]/[§5.4].
- **FR-206**: System supports per-line discounts, applied before VAT
  calculation — see [KB §5.5].
- **FR-207**: System supports foreign-currency invoicing with full-precision
  CBUAE-rate AED conversion, snapshotted at issuance — see [KB §8.3].
- **FR-208**: System applies consistent VAT rounding (nearest fil) via one
  shared calculation function — see [KB §8.4].

### Module 3 (Planned)
- **FR-301**: Tenant Owner/Staff can log a Purchase/Expense, classified by
  recoverability (full/none/partial) — see [KB §4.2]–[§4.4].
- **FR-302**: System flags likely-blocked expense categories (entertainment,
  personal-use vehicles) at entry time — see [KB §4.4].
- **FR-303**: Tenant Owner/Staff can log an import purchase; system
  self-accounts reverse-charge VAT as both output and input entries — see
  [KB §3.1]/[§3.3].
- **FR-304**: System generates a VAT Return for a given tax period,
  derived entirely from underlying transactions, broken down by category
  — see [KB §7.1].
- **FR-305**: System tracks the Tenant's assigned filing period and
  surfaces the next due date with penalty-at-stake messaging — see
  [KB §7.2]/[§7.3].
- **FR-306**: System tracks excess input VAT carry-forward as dated
  tranches and warns before the 5-year expiry — see [KB §4.3].
- **FR-307**: Tenant Owner/Staff can record bad debt relief against an
  original invoice, subject to the Article 64 conditions — see [KB §5.7].
- **FR-308**: Tenant Owner/Staff can generate day-to-day operational
  reports (sales register, purchase register, customer and supplier
  statements) alongside VAT-specific reports — new in this revision,
  see [§5]/[§2 Goal 1].

### Cross-Tenant / Firm Management (Planned — blocked on [§4] architecture decision)
- **FR-F01**: A Firm Administrator can be granted access to multiple
  Tenants and switch between them without re-authenticating per Tenant.
  **Not buildable until the [§4] open architecture question is resolved**
  — listed here as a committed requirement, not a committed implementation.
- **FR-F02**: A Tenant's data remains fully isolated from every Firm other
  than the one(s) explicitly granted access to it, with the same rigor as
  Tenant-to-Tenant isolation today ([ADR §7]).

### Module 4 (Planned)
- **FR-401**: System writes an Audit Log entry for defined sensitive
  actions (currently: table exists, nothing writes to it).
- **FR-402**: Tenant Owner can view the Tenant's Audit Log (Premium plan
  only, per existing plan-limits model).
- **FR-403**: System supports fine-grained Staff permissions beyond the
  flat OWNER/STAFF split, additive to the existing role field — see
  [ADR §6].

### Module 5 (Planned)
- **FR-501**: Tenant Owner/Staff can upload a supplier invoice image/PDF
  for OCR processing (Premium plan only).
- **FR-502**: Tenant Owner/Staff can review and correct OCR-extracted data
  before it becomes a Purchase record.

---

## 9. Non-Functional Requirements

- **Mobile First / Responsive Design** *(new, elevated in this revision)*:
  every user-facing capability — invoicing, purchase recording, reports,
  VAT summaries, customer/supplier management — must be fully usable on
  mobile and tablet viewports, not a desktop experience with a mobile
  afterthought. This is a core product principle ([§1]), not a
  nice-to-have. **Module 0's existing UI shell (a fixed-width 220px
  sidebar layout) predates this principle and has not been verified
  against it** — it should be explicitly reassessed starting Module 1,
  with any resulting change explained and approved per [ADR §13.3] rather
  than silently retrofitted.
- **Performance**: list/aggregation endpoints (Tenant list, VAT Return
  generation) must remain responsive as transaction volume grows; pagination
  is a committed [ADR §8] direction, not optional, once Module 1's first
  list endpoint ships.
- **Scalability**: the backend is stateless by design ([ADR §5]/[§12]) —
  horizontal scaling is a matter of running more instances, not an
  architectural change, once a real deployment target exists.
- **Availability**: no formal SLA yet (pre-production); once a deployment
  target is chosen ([ADR §12]), availability targets should be set relative
  to the filing-deadline stakes in [KB §7.3] — downtime near a filing
  deadline is a materially worse failure than downtime otherwise.
- **Usability**: the product's primary audience ([§3], The SME Owner) is
  not a tax expert — every VAT-category or compliance decision surfaced in
  the UI should explain itself in plain language, not just present a
  correct-but-opaque control (a recurring UI implication throughout the
  Knowledge Base, e.g. [KB §2.4], [KB §3.1]).
- **Maintainability**: business logic lives in services, not controllers
  ([ADR §13.1]), specifically so the VAT calculation rules in this document
  and the Knowledge Base can be unit-tested independent of HTTP.
- **Data integrity**: financial documents are immutable once issued
  ([KB §5.1], [§5.3], [§8.2]) — this is as much a non-functional guarantee
  (the system must be architecturally incapable of silently altering
  filed history) as it is a business rule.
- **Localization**: not yet committed — see [§12 Assumptions] on Arabic/
  bilingual UI.
- **Auditability**: every computed VAT figure must be traceable back to its
  source transactions ([ADR §11], [KB §4.1], [§7.1]) — a non-functional
  requirement on the *shape* of the calculation logic, not just a feature.

---

## 10. Security Requirements

Consolidates and extends [ADR §5]/[§6]/[§7] with the compliance-driven
requirements the Knowledge Base surfaces:

- Two fully separate JWT identity spaces (Platform Admin, Tenant User),
  distinct secrets and audiences — **built**, standing rule ([ADR §5]).
- `tenantId` for any data access always derived from the verified JWT,
  never client input — **built**, standing rule, explicitly reaffirmed as
  binding for every future module ([ADR §6]/[§7]).
- Passwords hashed with bcrypt — **built**.
- **Planned before production**: token revocation mechanism (password
  change / force-logout currently has no effect on an already-issued
  8-hour token) — [ADR §5].
- **Planned before production**: MFA, at minimum for Platform Admin given
  that account can create/suspend every Tenant — [ADR §5].
- **Planned before production**: server-side password policy (currently
  only a client-side `minLength` hint) — [ADR §5].
- **Planned**: rate limiting on both login endpoints — [ADR §5] flagged
  gap, unresolved.
- TRN input validated server-side wherever entered, never trusted from
  client format alone — [KB §1.2].
- Financial-document APIs never expose a delete path — a security property
  as much as a compliance one, since an accidental or malicious deletion
  of an issued invoice would be both a data-integrity and an FTA-retention
  failure ([KB §8.2]).
- File storage (Module 2/5, once built) uses signed, expiring URLs scoped
  per-Tenant — never public buckets, never local disk — [ADR §9].
- Structured logs must never contain passwords, full JWTs, or full request
  bodies from auth endpoints — [ADR §10].
- Secrets management: `.env`-based today (dev-appropriate); needs a
  real secrets story before any shared environment — [ADR §12].
- **New risk surface from this revision**: a Firm Administrator role with
  access to multiple Tenants ([§4]) has a materially larger blast radius
  than today's single-Tenant JWT model — a single compromised Firm-level
  credential could expose several businesses' data at once, not one. This
  must be an explicit, weighed design input to whichever ADR resolves the
  [§4] access-model question — e.g., scoped/short-lived per-Tenant access
  tokens rather than one broad standing credential — not treated as an
  incidental detail of "just add more Tenants to the JWT."

---

## 11. Compliance Requirements

This section states compliance obligations as product requirements — each
traces to a Knowledge Base rule already marked [CONFIRMED]. Per the
Compliance by Default principle ([§1]), these are requirements on the
*ordinary* invoicing/purchasing/expense flows in Modules 1–3, not a
separate filing-time checklist:

- Every tax invoice/credit note issued must contain the full Article 59/60
  mandatory field set — [KB §5.1]/[§5.3] — enforced by validation before
  any document transitions from draft to issued state, not just encouraged
  in the UI.
- Simplified vs. full invoice type must be determined by the system, not
  left to user discretion — misclassification above AED 10,000 is a
  confirmed common audit finding — [KB §5.2].
- Invoice and Credit Note numbering must be sequential, gap-free, and
  per-Tenant — [KB §8.1].
- All VAT-relevant records must be retrievable for the correct retention
  period per record type (5/10/15 years) — [KB §8.2] — which is why no
  hard-delete path may ever be built for these record types (a compliance
  requirement enforced architecturally, per [§10] above).
- Foreign-currency invoices must convert at the full-precision CBUAE rate
  for the date of supply — [KB §8.3].
- The product must track and be ready to build toward the UAE e-invoicing
  mandate (Peppol/PINT AE, mandatory from 1 January 2027 for large
  businesses) — [KB §5.1] — a live compliance deadline, not a hypothetical
  future feature.
- Data belonging to a UAE business (contact details, TRN, transaction
  history) should be handled with UAE PDPL (data protection) considerations
  in mind — flagged in the original assessment and not yet deep-researched
  in the Knowledge Base; treat as an open compliance research item, not yet
  a confirmed, cited rule the way the VAT-specific items above are.
- Bad debt relief, bad-debt notification, and the 6-month waiting period
  must be enforced as conjunctive conditions, not optional guidance —
  [KB §5.7].

---

## 12. Assumptions

A consolidated register of every point flagged
`[ASSUMPTION — NEEDS PRODUCT DECISION]` across the ADR and Knowledge Base,
gathered here so they're tracked in one place rather than scattered across
nine documents. None of these are decided by this Product Bible — they are
listed so they get decided deliberately, not by default.

| # | Assumption | Where flagged | Decision needed by |
|---|---|---|---|
| A1 | TypeScript adoption (incremental, starting Module 1) | [ADR §2] | Before Module 1 |
| A2 | Deployment hosting vendor | [ADR §12] | Before any staging/production environment |
| A3 | Pre-registration threshold-tracking feature (help a not-yet-registered business track its approach to AED 375,000) | [KB §1.1] | Module 1 scoping |
| A4 | Tax Group (multi-entity consolidated filing) support | [KB §1.1], [ADR §6] | Before it's needed by a target customer |
| A5 | TRN uniqueness enforced at the database level for `Tenant` | [KB §1.2] | Module 1 schema design |
| A6 | Whether Staff can edit Business Profile, or Owner-only | [KB §1.3] | Module 1 — natural first use of `requireOwnerRole` |
| A7 | Designated Zone support scope | [KB §3.4] | Before Module 3's VAT engine locks in |
| A8 | Debit Note modeling — distinct document type vs. "additional invoice with reference" | [KB §5.4] | Before Module 2, ideally with tax-agent input given weaker legislative footing |
| A9 | Direct EmaraTax filing integration vs. "generate for Tenant to file themselves" | [KB §7.1] | Module 3 scoping |
| A10 | Capital Assets Scheme — in scope for an early release, or deferred Premium-tier feature | [KB §6.1] | Before Module 3, given AED 5M threshold makes it low-frequency for target SMEs |
| A11 | Built-in "commonly blocked expense" warnings (entertainment/vehicles) — assistive vs. none | [KB §4.4] | Module 3 UX design |
| A12 | Gift/sample deemed-supply tracking as an explicit feature | [KB §6.2] | Module 3 scoping |
| A13 | Per-line vs. gross-total VAT rounding convention (recommendation: per-line, platform-wide, non-configurable) | [KB §8.4] | Before Module 2's VAT calculation service is built |
| A14 | External Tax Agent as a modeled system role | [§3]/[§4] of this document | Whenever Module 3's review workflow ([§6.8]) is scoped. **Status update (v2)**: partially resolved — the broader Accounting Firm persona is now a committed product direction ([§1]/[§3]), so the open question is narrower: whether External Tax Agent needs its own access variant, or reuses the Firm access model at reduced scope |
| A15 | Tenant deregistration / offboarding workflow | [KB §1.1], [KB §8.2], [§6.10] of this document | Before it's needed in practice — currently undesigned |
| A16 | Arabic/bilingual UI | Original assessment, reaffirmed here | Before targeting government/formal-bilingual-expectation customers |
| A17 | Owner/Staff onboarding via forced-password-reset or email invite, replacing today's admin-set temp password shown in-UI | [ADR §5] | Before production rollout |
| A18 | **Firm/multi-Tenant cross-access architecture** — the mechanism by which a Firm Administrator safely accesses multiple Tenants | [§1]/[§3]/[§4] (new in v2) | Requires its own ADR per [ADR §13.3]; recommended before Module 1 locks in Business Profile/Tenant-access patterns |
| A19 | Whether "Products/Services" (v2 vision language) is implemented as a rename of the existing `Material` concept or an additive relabeling | [§5] (new in v2) | Module 1 implementation planning — not a Product Bible decision |
| A20 | Whether Audit Log access should remain fully Premium-gated given "maintain complete audit history" is now a vision-level daily-use expectation ([§1]), not just a Premium upsell | [§1]/[Module 4] (new in v2) | Before Module 4 plan-gating is finalized |
| A21 | How Module 0's existing fixed-width sidebar UI shell is reassessed/adapted against the new Mobile First principle | [§9] (new in v2) | Before/during Module 1 frontend work |

---

## 13. Out of Scope

Explicitly not being built, for the reasons stated — revisit only via an
explicit decision, not by default drift:

- **Self-service Tenant signup.** Deliberate Module 0 decision — all
  accounts are created by the Platform Admin. Not revisited here.
- **Full-scale ERP or payroll functionality** (payroll processing,
  manufacturing/inventory management beyond what Products/Services records
  need for invoicing and VAT purposes, multi-entity consolidated financial
  reporting beyond VAT and the operational reports in [§5]/[§8]). Ledger is
  the daily financial and compliance operating system described in [§1] —
  broader than a VAT-only tool, but still short of a full ERP or payroll
  suite.
- **Tax jurisdictions outside the UAE.** No multi-country tax engine is
  planned; UAE Corporate Tax is a related but distinct regime and is not
  covered by this product or its Knowledge Base.
- **Automated legal/tax advice.** The product computes and applies rules
  that are already settled in law; it does not exercise judgment on
  genuinely ambiguous classifications (e.g., basic vs. elective healthcare,
  [KB §2.3]) — those remain human decisions the product supports, not
  replaces.
- **Direct EmaraTax filing submission**, until [A9] is explicitly decided
  otherwise — the safer default scope is "generate an accurate return for
  the Tenant/their accountant to file," not automated submission with its
  own liability profile.
- **MFA, refresh tokens, rate limiting** — acknowledged security gaps
  ([ADR §5], [§10] of this document), explicitly planned but not yet built;
  listed here only to be clear they are not silently deferred forever.
- **Capital Assets Scheme, Tax Groups, Designated Zone full support** —
  each a real UAE VAT mechanism ([KB §6.1], [§1.1], [§3.4]), each deferred
  pending the corresponding assumption ([A10], [A4], [A7]) being resolved,
  not because they're out of scope permanently.
- **AI-powered bookkeeping assistance, deep third-party accounting-software
  integrations, and a full Analytics Dashboard** *(new in this revision)*
  — all committed future direction ([§1]/[§14]), not near-term
  deliverables. Today's architecture should stay compatible with them
  (service-layer separation, file storage, API design — [ADR §13.1]/[§9]/[§8])
  without building them now.
- **Firm/multi-Tenant management as a shipped feature** — the *persona and
  product commitment* are in scope as of this revision ([§1]/[§3]), but the
  feature itself is explicitly not buildable until the [§4] architecture
  question is resolved via its own ADR. Scoped-in intent, scoped-out
  implementation, until that decision lands.

---

## 14. Future Roadmap

### Future Vision capabilities — architecture now, build later

These six capabilities, named explicitly in this revision's Product
Vision ([§1]), are not scheduled deliverables — they are commitments that
today's architecture decisions should stay compatible with, the same way
Module 0's schema pre-modeled Modules 1–5 without building their logic
([ADR §1]). Each row states the concrete "keep this open" implication for
current work, not a build date.

| Capability | What today's decisions should keep open |
|---|---|
| **UAE E-Invoicing** | Already a *confirmed, dated* near-term requirement, not speculative — see [KB §5.1] and Module 2's scope note in [§5]. |
| **OCR for Purchase Invoices** | Already Module 5; depends on the file storage decision in [ADR §9] being in place before it's needed. |
| **AI-powered bookkeeping assistance** | The blocked-expense detection ([KB §4.4]), deemed-supply tracking ([KB §6.2]), and VAT-category classification logic built as clean, standalone service functions ([ADR §13.1]) for Modules 2–3 are the same logic an AI assistant would eventually call or learn from — build them decoupled from controllers now, and this becomes an additive capability later rather than a rebuild. |
| **API integrations (third-party)** | [ADR §8]'s eventual OpenAPI-spec-first direction should be timed to precede, not follow, any external integration commitment. |
| **Accounting software integrations** | Depends on Module 1/2's data model (Customers, Suppliers, Products/Services, Invoices) being clean and stable enough to map to external formats — a reason to get [A19]'s Products/Services decision right early rather than patch it later. |
| **Analytics Dashboard** | Distinct from Module 3's operational reports ([§5]/[FR-308]) — depends on reporting data being derived/traceable ([§2 Goal 6]) from day one, since an analytics layer built on ungoverned data would just compound whatever wasn't traceable underneath it. |
| **Workflow automation** | No specific current dependency identified; flagged for re-evaluation once Modules 1–4 establish what "a workflow" concretely means in this product (e.g., approval chains, reminders, recurring invoices). |

**Near-term (before/alongside Module 1, new priorities from this revision):**
- Resolve the Firm/multi-Tenant cross-access architecture question via its
  own ADR ([§4], [A18]) — recommended before Module 1's Business Profile
  work locks in single-Tenant-only access patterns.
- Reassess Module 0's UI shell against the Mobile First principle ([§9],
  [A21]).
- Decide the Products/Services vs. Material naming question ([A19]) before
  Module 1's schema work.

**Near-term (alongside Modules 2–3):**
- File storage + structured logging prerequisites ([ADR §9]/[§10]).
- E-invoicing (Peppol/PINT AE) readiness work, timed against the confirmed
  1 January 2027 / 1 July 2027 mandatory dates ([KB §5.1]).
- Filing-deadline and carry-forward-expiry proactive notifications
  ([KB §7.2], [§4.3]) — a genuine differentiator, not just a compliance
  checkbox.

**Mid-term (alongside/after Module 4):**
- Token revocation, MFA, rate limiting, server-side password policy
  ([ADR §5]).
- CI/CD, once a deployment target is chosen ([ADR §12]).
- Resolution of the Assumptions register ([§12]) items tied to Module 3/4
  scope (A4, A7, A9, A10, A14, A20).

**Longer-term:**
- OpenAPI spec generation, as the API surface grows past Module 2–3
  ([ADR §8]).
- Postgres Row-Level Security as a second enforcement layer under the
  existing JWT-derived tenant filtering ([ADR §7]).
- Arabic/bilingual UI ([A16]), if the target market's formal-document
  expectations require it.
- Multi-currency invoicing beyond the AED-conversion baseline already
  specified ([KB §8.3]), if UAE trade patterns in the actual customer base
  demand it.
- White-label invoice branding — carried over from the original technical
  assessment's gap analysis as genuine future value. (Analytics Dashboard
  and accounting-software integrations are now tracked in the Future
  Vision table above, not listed twice.)
- Direct EmaraTax integration, if [A9] is ever resolved in favor of it and
  a suitable government-facing API exists.

---

## 15. Glossary

**Product terms**

- **Ledger** — this product's name.
- **Platform Admin** — the operator of the Ledger platform itself; manages
  Tenants. See [§3]/[§4].
- **Tenant** — a paying UAE business subscribed to Ledger.
- **Tenant Owner / Staff** — the two Tenant-side user roles; see [§4].
- **Plan** — subscription tier (TRIAL / STANDARD / PREMIUM), each with its
  own user/invoice limits and feature gates (Audit Log, OCR).
- **Module** — a scoped, sequentially-delivered slice of product
  functionality; see [§5].
- **Business Profile** — a Tenant's own compliance identity record (name,
  address, TRN, VAT configuration); [KB §1.3].
- **Firm / Practice** *(new in v2)* — an accounting firm, consultancy, or
  service provider that manages multiple Tenants under one commercial
  relationship; see [§3]/[§4]. Access mechanism not yet designed — [A18].
- **RBAC** *(new in v2)* — Role-Based Access Control; the core product
  principle governing who can do what, at both the Tenant and (once
  designed) Firm level; [§1 Principle 2].
- **Operational Report** *(new in v2)* — a daily-business report (sales
  register, purchase register, customer/supplier statement), distinct from
  a VAT-specific report; part of Module 3 ([§5]/[FR-308]).
- **Analytics Dashboard** *(new in v2)* — a planned, later cross-period
  business-intelligence capability, distinct from Module 3's Operational
  Reports; [§14].
- **Workflow Automation** *(new in v2)* — a named Future Vision capability
  ([§1]/[§14]); concrete product meaning (approvals, reminders, recurring
  documents) not yet defined.
- **AI Bookkeeping Assistant** *(new in v2)* — a named Future Vision
  capability ([§1]/[§14]) intended to build on the same classification/
  service-layer logic already required for Modules 2–3 ([ADR §13.1]).

**UAE VAT terms** *(full detail in the [Knowledge Base](knowledge-base/README.md); summarized here for quick reference)*

- **FTA** — Federal Tax Authority, the UAE's tax administrator.
- **TRN** — Tax Registration Number, a business's unique 15-digit VAT
  identifier; [KB §1.2].
- **Output VAT / Input VAT** — VAT charged on sales / VAT paid on
  purchases; [KB §4.1]/[§4.2].
- **Standard Rated / Zero Rated / Exempt / Out of Scope** — the four VAT
  treatment categories; [KB §2.1]–[§2.5].
- **Reverse Charge** — mechanism shifting VAT accounting from supplier to
  recipient, mainly for imports; [KB §3.3].
- **Designated Zone** — a specific list of UAE free zones treated as
  outside the UAE for VAT on goods; [KB §3.4].
- **Recoverable / Non-Recoverable Input VAT** — whether input VAT can
  offset output VAT; [KB §4.3]/[§4.4].
- **Tax Invoice / Simplified Tax Invoice** — the two invoice formats;
  [KB §5.1]/[§5.2].
- **Tax Credit Note / Debit Note** — documents correcting a previously
  issued invoice, downward/upward; [KB §5.3]/[§5.4].
- **Capital Asset Scheme** — multi-year input VAT monitoring for
  large (≥AED 5M) qualifying assets; [KB §6.1].
- **Deemed Supply** — a free-of-charge transfer treated as a taxable supply
  above certain thresholds; [KB §6.2].
- **VAT Return / Filing Period / Tax Period** — the periodic FTA
  declaration and its cadence (monthly/quarterly); [KB §7.1]/[§7.2].
- **Bad Debt Relief** — output VAT adjustment for written-off receivables;
  [KB §5.7].
- **CIF** — Cost, Insurance, Freight; the customs valuation basis for
  import VAT; [KB §3.1].
- **TOGC** — Transfer of a business as a Going Concern; an out-of-scope
  transaction type; [KB §2.5].
- **PINT AE / Peppol / DCTCE** — the UAE's e-invoicing technical framework
  and network model; [KB §5.1].
- **EmaraTax** — the FTA's online portal for registration and filing.

**Platform/architecture terms** *(full detail in [ADR-0001](adr/0001-baseline-architecture.md))*

- **Pooled multi-tenancy** — one shared database/schema, `tenantId`-scoped;
  [ADR §7].
- **ADR** — Architecture Decision Record; this project's binding
  architecture documentation process; [ADR §13.3].
