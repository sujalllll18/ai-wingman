# 1. Registration & Identity

Covers: **VAT Registration**, **TRN**, **Business Profile**.
See the [legend](README.md#legend--read-this-before-reading-any-topic-file) for what [CONFIRMED] / [BEST PRACTICE] / [ASSUMPTION] mean.

---

## 1.1 VAT Registration

### Definition
The formal process by which a business becomes a UAE VAT registrant with the
Federal Tax Authority (FTA), obtaining a Tax Registration Number (TRN) and
becoming legally obligated to charge, collect, and remit VAT on its taxable
supplies, and entitled to recover VAT on its taxable inputs.

### Official UAE FTA business rules
- **[CONFIRMED]** Mandatory registration: a UAE-resident business must
  register if the value of its taxable supplies and imports exceeded
  **AED 375,000** over the previous 12 months, or is expected to exceed that
  amount in the next 30 days.
- **[CONFIRMED]** Voluntary registration: available once taxable supplies,
  imports, *or taxable expenses* exceed **AED 187,500** (trailing 12 months
  or next-30-days test) — note expenses count toward the voluntary
  threshold, not just sales.
- **[CONFIRMED]** Registration is done via the FTA's EmaraTax portal.
- **[CONFIRMED]** Failure to register within 30 days of crossing the
  mandatory threshold: **AED 10,000 penalty**, plus the business becomes
  retroactively liable for VAT on taxable supplies made from the date it
  *should* have registered.
- **[CONFIRMED]** Two or more UAE-established related/commonly-controlled
  entities may register jointly as a **Tax Group** (Article 14) and file one
  consolidated return; intra-group supplies are generally disregarded for
  VAT.
- **[BEST PRACTICE]** Businesses below the voluntary threshold typically do
  not register — there is no benefit and it adds compliance overhead.

### Real-world example
Al Noor Trading LLC starts trading in January with modest sales. By
September, its trailing-12-month taxable supplies hit AED 380,000 — it
crossed the mandatory threshold and must register within 30 days or face the
AED 10,000 penalty and backdated liability. A smaller sole proprietorship
with AED 200,000 in annual sales is *not* required to register, but may
choose to (voluntary) to reclaim VAT on its input costs.

### Product implications
- The platform currently (Module 0) has Platform-Admin-driven onboarding —
  a Tenant is created *after* it has (presumably) already registered with
  the FTA and obtained a TRN. The product does not currently help a business
  determine *whether* it needs to register, or walk them through FTA
  registration itself.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Should Module 1 add a
  "pre-registration" / threshold-tracking mode for a Tenant that hasn't
  registered yet (so they can track their trailing-12-month turnover and get
  warned as they approach AED 375,000)? This is a real value-add but is out
  of Module 0's stated scope and not mentioned in the module roadmap.
- The product should record *when* a Tenant became VAT-registered (its
  effective registration date), since VAT can only be charged and recovered
  from that date forward — this date is not currently captured anywhere in
  the schema.

### Database implications
- `Tenant` needs a `vatRegistrationDate` (or `effectiveRegistrationDate`)
  field distinct from `createdAt` (the platform account's creation date,
  which is a different thing).
- If the pre-registration/threshold-tracking assumption above is accepted,
  a `registrationStatus` (e.g., `NOT_REGISTERED | VOLUNTARY | MANDATORY`)
  concept is needed, plus a way to track cumulative taxable-supply value
  before a TRN exists.
- Tax Group support (multiple Tenants filing one consolidated return) is not
  modeled at all today — `Tenant` is a single flat entity with no concept of
  a parent/group. This is a **structural gap** if Tax Groups are ever
  in scope; flagged here rather than assumed out of scope, since UAE SME
  groups commonly use this.

### API implications
- No registration-related endpoints exist today beyond Platform-Admin
  tenant creation (which assumes a TRN is already known and provided).
- A future "registration status/threshold tracking" feature would need its
  own read/write endpoints, tenant-scoped like everything else per
  ADR-0001 §6/§7.

### UI implications
- The "New Tenant" admin form (`app/admin/tenants/new/page.js`) currently
  treats TRN as an optional free-text field with no registration-date
  capture and no distinction between "registered" and "not yet registered"
  Tenants.
- If pre-registration tracking is added, it needs its own UI surface
  (likely Tenant-side, under a future Business Profile/Settings screen) —
  not an Admin-console concern, since it's about the *Tenant's* commercial
  state, not the platform's.

### Validation rules
- **[BEST PRACTICE]** A Tenant flagged as VAT-registered should have a
  non-empty, correctly-formatted TRN (see §1.2) and a registration date not
  in the future.
- **[ASSUMPTION]** Whether the product *enforces* that a Tenant cannot issue
  tax invoices before its registration date is a product decision for
  Module 2 — legally, an unregistered business cannot charge VAT at all, so
  this should probably be a hard validation once Invoicing exists.

### Edge cases
- A Tenant deregisters (voluntarily, or is forced to by FTA due to falling
  below the threshold, or ceasing business) — the product has no concept of
  deregistration today; `Tenant.status` only models `ACTIVE`/`SUSPENDED`,
  which is a *platform* billing/access concept, not a *VAT* registration
  concept. These two states must not be conflated: a Tenant can be
  platform-`SUSPENDED` (stopped paying the SaaS) while still being
  VAT-registered with the FTA, or vice versa.
- A Tenant registers for VAT mid-tax-period — historical invoices issued
  before the registration date must never show VAT.
- Group registration/deregistration (members joining or leaving a Tax
  Group) — entirely unmodeled today.

### Future considerations
- Threshold-tracking as a value-add feature (see Product implications).
- Tax Group support, if the target market includes UAE conglomerates/SME
  groups with multiple legal entities under common control.
- Deregistration workflow and its effect on historical data retention
  (retention rules in §8.2 apply regardless of current registration status).

---

## 1.2 TRN (Tax Registration Number)

### Definition
The unique identifier the FTA assigns to a VAT-registered business upon
successful registration. It must appear on every tax invoice, tax credit
note, and VAT return.

### Official UAE FTA business rules
- **[CONFIRMED]** A TRN is always **15 digits**, numeric only (no letters,
  no dashes as part of the number itself, though dashes are sometimes used
  cosmetically when displaying it), and every TRN observed begins with
  `1` (commonly formatted starting `100...`).
- **[CONFIRMED]** The TRN must appear on tax invoices (supplier's TRN always;
  recipient's TRN too, if the recipient is VAT-registered and it's a full
  tax invoice — see §5.1), tax credit notes, and VAT returns.
- Businesses/individuals can verify any TRN's validity via the FTA's public
  TRN verification service on the EmaraTax portal.
- **Not publicly documented by the FTA**: the internal structure/meaning of
  the 15 digits beyond "starts with 1" and there being no official published
  checksum algorithm. Treat any claimed internal structure beyond length +
  numeric-only as unverified.

### Real-world example
Al Noor Trading LLC's TRN, `100123456700003`, must appear on every invoice
it issues from its registration date onward, and on every invoice it
receives from another UAE-registered supplier when that supplier's TRN is
needed to support the recipient's own input VAT recovery claim.

### Product implications
- TRN is currently modeled as a free-text `String?` on both `Tenant` and
  `Customer` with **zero format validation** anywhere in the stack (backend
  or frontend) — this is the single most concrete, cheap-to-fix compliance
  gap surfaced by this research.
- TRN correctness matters most at the moment it prints on a tax invoice
  (Module 2) — an invalid TRN on an invoice is an FTA compliance defect on a
  legal document, not just a data-quality issue.

### Database implications
- `Tenant.trn` and `Customer.trn` should both be validated at the
  application layer (format: exactly 15 numeric digits) before being
  persisted — this is a validation-layer change, not a schema-shape change,
  since the field is already a `String?`.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Should TRN be `@unique` at the
  database level for `Tenant`? Two different Tenants sharing one TRN would
  be a real-world data-integrity red flag (same legal entity onboarded
  twice, or a typo), but a hard unique constraint could also block
  legitimate edge cases (see Edge cases below) — worth deciding deliberately
  rather than defaulting either way.

### API implications
- Tenant-creation and Customer-creation endpoints (existing and future)
  should validate TRN format server-side, not just rely on frontend input
  masking — the backend must never trust client-supplied format compliance,
  consistent with ADR-0001's general validation posture.
- A future TRN-verification integration (calling the FTA's public
  verification service) is plausible but not confirmed as a real-time API
  the FTA exposes for third-party automated integration — this needs actual
  verification before being assumed available; flagged, not promised.

### UI implications
- TRN input fields (already present in `NewTenantPage` and implicitly
  needed on future Customer forms) should use `inputMode="numeric"`,
  a 15-digit max length, and inline format feedback — currently just a
  plain text input with `className="mono"` styling and no constraints.

### Validation rules
- **[BEST PRACTICE]** Exactly 15 numeric digits, no letters/symbols.
- **[ASSUMPTION]** Whether TRN is *required* (not optional) once a Tenant is
  marked VAT-registered is a product decision — today it's fully optional
  even for tenants that clearly need one.

### Edge cases
- A Tenant's TRN changes (rare, but can happen after certain FTA-side
  corrections or re-registrations) — the product needs a way to update it
  without breaking the link to historically-issued invoices that correctly
  carried the *old* TRN at the time.
- A Customer's TRN is invalid or unverifiable (typo, fraud, deregistered
  customer) — affects whether a supplier can safely treat that customer as
  VAT-registered for invoice-type purposes (see §5.1/§5.2).
- Free zone entities and government entities have TRNs in the same 15-digit
  format — no special-casing needed at the format level.

### Future considerations
- Real-time TRN verification against the FTA registry at data-entry time
  (Customer creation, Tenant onboarding) would materially reduce invoice
  defects — worth scoping once Module 1/2 are underway, pending confirmation
  of what the FTA actually exposes programmatically.
- The e-invoicing mandate (see [file 5](05-invoicing-and-documents.md)) will
  likely make TRN accuracy load-bearing in an automated, machine-validated
  way (Peppol network validation), raising the cost of today's zero-validation
  gap the longer it's left unfixed.

---

## 1.3 Business Profile

### Definition
The set of a Tenant's own business details — legal name, address, TRN,
contact information, and (eventually) VAT-specific configuration like
default VAT rate, invoice numbering scheme, and logo/branding for invoice
generation — that describes *who the Tenant is* for compliance and document
purposes. Explicitly named as a **Module 1** deliverable in the existing
module roadmap.

### Official UAE FTA business rules
- **[CONFIRMED]** A tax invoice must show the supplier's (the Tenant's)
  name, address, and TRN (§5.1) — meaning whatever the Business Profile
  stores must be accurate and current at the moment any invoice is
  generated.
- No FTA rule mandates a specific software concept called "Business
  Profile" — this is a product/UX grouping of legally-required supplier
  identity fields, not itself a distinct legal requirement.

### Real-world example
Al Noor Trading LLC's Business Profile stores its legal name ("Al Noor
Trading LLC"), registered address, TRN, and — once Module 2 exists — the
logo and footer text that should appear on every tax invoice it generates.
When the Owner updates the registered address after an office move, every
*future* invoice should reflect the new address, while past invoices must
continue to show the address that was correct on the date they were issued.

### Product implications
- Module 0 already stores a minimal slice of this on `Tenant`
  (`name`, `address`, `trn`, `contactEmail`, `contactPhone`) — Module 1's
  job is to expand this into a full, Tenant-editable profile (self-service,
  unlike Tenant/Owner *account* creation which stays Platform-Admin-only
  per the existing spec).
- Business Profile fields that appear on legal documents (name, address,
  TRN) are **snapshot-sensitive** — see Database implications.

### Database implications
- **[BEST PRACTICE]** Legally-significant Business Profile fields must be
  *snapshotted onto each invoice/credit note at issuance time*, not just
  live-joined from the current `Tenant` row — otherwise editing the address
  today silently rewrites what a document issued last year appears to say.
  This is a general principle that recurs throughout this knowledge base
  (see Customer details in §5.1, VAT rate in §2.1) and should be treated as
  a standing design rule for Module 2, not a one-off decision.
- Fields like default VAT rate per Tenant already exist as a *history* table
  (`VatRateHistory`) — a good precedent to extend to other Business Profile
  fields that need point-in-time accuracy (e.g., a `TenantProfileHistory` or
  simply snapshotting the relevant fields onto each document row rather than
  versioning the whole profile).
- Per ADR-0001 §5, every schema change here goes through a Prisma migration;
  extending `Tenant` with new profile fields is additive (no destructive
  change) and low-risk.

### API implications
- Module 1 needs Tenant-self-service endpoints (`GET/PATCH
  /api/tenant/business-profile` or similar) — distinct from the
  Platform-Admin tenant-management endpoints that exist today, and scoped
  strictly to `req.tenantId` per ADR-0001 §6/§7 (never a client-supplied
  tenant ID).
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Should Staff be allowed to edit
  the Business Profile, or is this Owner-only? This is exactly the kind of
  decision the currently-unused `requireOwnerRole` middleware
  (ADR-0001 §6) was likely built for — a natural first real use for it.

### UI implications
- A new `/tenant/settings` (or `/tenant/business-profile`) screen is needed
  — not present today; the Tenant portal currently only has `/tenant/team`.
- Should surface the *current* profile with clear indication that changes
  only affect future documents, not past ones (to avoid a Tenant assuming
  they can "fix" an old invoice by editing their profile).

### Validation rules
- TRN format validation (§1.2) applies here too.
- **[BEST PRACTICE]** Legal name and address should be required (non-empty)
  before the Tenant is allowed to issue its first tax invoice in Module 2 —
  an invoice without a valid supplier name/address/TRN is non-compliant by
  definition (§5.1).

### Edge cases
- A Tenant changes its legal name (e.g., after a corporate restructuring)
  but keeps the same TRN — must be supported, and again must not retroactively
  alter historical documents.
- Multi-branch/multi-address businesses — UAE VAT registration is generally
  per legal entity, not per branch, so a single Business Profile per Tenant
  is very likely sufficient; flagged as an assumption only if the target
  customer base includes businesses that register branches separately
  (uncommon, but not impossible).

### Future considerations
- Invoice branding/template configuration (logo, footer, terms) as part of
  Business Profile, needed by Module 2.
- If Tax Groups (§1.1) are ever built, Business Profile would need to
  distinguish "this legal entity's profile" from "the group's consolidated
  filing identity" — a real complexity, deferred until Tax Groups are
  actually in scope.
