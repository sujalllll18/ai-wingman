# 5. Invoicing & Documents

Covers: **Tax Invoices**, **Simplified Tax Invoices**, **Credit Notes**,
**Debit Notes**, **Discounts**, **Shipping**, **Adjustments**.
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

**This entire file is directly shaped by the UAE's active e-invoicing
rollout** (see the callout under 5.1) — read that first, since it changes
the near-term design stakes for everything else here.

---

## 5.1 Tax Invoices

### Definition
The legally-mandated document a VAT-registered business must issue for a
taxable supply, containing specific fields required by law, that supports
both the supplier's output tax reporting and the recipient's input tax
recovery claim.

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 59, VAT Executive Regulations
  (amended by Cabinet Decision No. 100 of 2025, effective 29 September
  2025). A full tax invoice must contain: the words **"Tax Invoice"**
  clearly displayed; supplier's name, address, and **TRN**; recipient's
  name, address, and **TRN** (where the recipient is VAT-registered); a
  **sequential or otherwise unique invoice number** enabling identification
  (§8.1); the **date of issue**; the **date of supply**, if different from
  the issue date; a description of the goods/services; for each line: unit
  price, quantity, tax rate, and amount payable in AED; any **discount**
  offered (§5.4); the **gross amount payable in AED**; and the **tax amount
  payable in AED**.
- **[CONFIRMED]** The invoice must be issued within **14 days** of the date
  of supply (the tax point — determined per Articles 25/26, generally the
  earliest of delivery/completion, invoice issuance, or payment received).
- **[CONFIRMED — MAJOR, ACTIVE CHANGE]** The UAE is rolling out **mandatory
  e-invoicing**, built on a 5-corner Peppol-based "Decentralised Continuous
  Transaction Control and Exchange" (DCTCE) model — standard 4-corner Peppol
  (supplier → supplier's access point → buyer's access point → buyer) plus
  a 5th corner: the **FTA itself**, which receives tax data as invoices move
  through the network in near-real-time. The national format is **PINT AE**.
  - The FTA published a 51-mandatory-field technical semantic model for
    UAE e-invoices on 23 February 2026 (invoice details, seller/buyer
    identification, totals, tax breakdowns, line-level data).
  - Timeline: **voluntary pilot live since 1 July 2026**; large businesses
    (AED 50 million+ revenue) must appoint an Accredited Service Provider
    (ASP) by **30 October 2026** (extended deadline); **mandatory from 1
    January 2027** for large businesses, **1 July 2027** for smaller
    businesses, **1 October 2027** for government entities.
  - Under the e-invoicing framework, all invoices and credit notes must
    carry the full mandated field set **regardless of transaction value or
    customer type** — this has direct implications for the Simplified Tax
    Invoice concept (§5.2), which historically had a reduced field set.

### Real-world example
Al Noor Trading LLC issues a AED 10,500 tax invoice (AED 10,000 + AED 500
VAT) to a Dubai customer, showing both parties' TRNs, a unique invoice
number, issue/supply dates, and a line-item breakdown. From 1 July 2027 (per
the current phased timeline), if Al Noor's revenue puts it in scope, that
same invoice must instead be generated and transmitted through the Peppol
e-invoicing network in PINT AE format, with the FTA receiving the tax data
automatically as it moves.

### Product implications
- **This is the single highest-stakes design decision facing Module 2.**
  Building an invoice-generation feature today that only targets the
  "classic" PDF/paper tax invoice model, without an eye toward the 51-field
  PINT AE structure, risks a costly rebuild within 12–18 months of Module
  2's release, given the confirmed 2027 mandatory dates.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Should Module 2 build directly
  toward PINT AE field completeness from day one (more upfront work, no
  rework later), or build a simpler classic-invoice MVP first with an
  explicitly planned Module-2.5/e-invoicing follow-up? This is a real
  scope/timeline trade-off for you to make deliberately — this document
  flags it rather than deciding it.
- Regardless of that decision, the invoice data model should capture *at
  least* the Article 59 field set now, since every one of those fields is
  also a subset of what PINT AE will require — nothing here is wasted work.

### Database implications
- `Invoice` (currently a Module-0 stub with just `invoiceNumber`, `status`,
  `customerId`, `tenantId`) needs substantial expansion: issue date, supply
  date, line items (each with description, quantity, unit price, VAT
  category/rate/amount — see §2.1), discount, gross/net/tax totals, and
  **snapshotted** supplier and recipient identity fields (name/address/TRN
  as they were *at issuance*, not live-joined — see the same principle in
  §1.3).
- If e-invoicing readiness is pursued now: additional fields for the
  broader PINT AE field set, and likely a `transmissionStatus` concept
  (draft / issued / transmitted-to-Peppol / FTA-acknowledged) once that
  integration exists.

### API implications
Invoice creation/issuance needs to be a genuinely atomic, auditable
operation (once issued, immutable — corrections go through Credit Notes,
§5.3) — a strong candidate for a dedicated service class per ADR-0001
§13.1, not controller logic, given the complexity of tax-point
determination, sequential numbering (§8.1), and multi-category line totals
all needing to happen correctly together.

### UI implications
Invoice creation UI needs line-item entry with per-line VAT category
(§2.1), a clear running total, and a preview of the rendered document before
issuance (since issuance is a one-way door). Given the design system already
established in Module 0 (`.mono` for numeric/tabular data, the "ledger"
aesthetic), invoice rendering is a natural extension of that visual
language, not a new one.

### Validation rules
Every Article 59 mandatory field must be present and correctly formatted
before an invoice can be issued (not just saved as a draft) — draft/issued
should likely be two distinct states, with full field validation gating the
transition, not gating draft creation.

### Edge cases
- Recipient not VAT-registered → recipient TRN is not required, but this
  starts to overlap with Simplified Tax Invoice rules (§5.2) — the product
  needs a clear, consistent rule for when a "full" vs. "simplified" invoice
  is generated, not a manual per-invoice choice prone to error.
- Multi-currency invoices — covered in depth in §8.3 (Currency Rules); the
  AED-conversion requirement applies at the tax-invoice level specifically.

### Future considerations
Re-verify the e-invoicing technical requirements (the 51-field PINT AE
spec, and any updates to it) immediately before Module 2 development starts
— this is actively evolving (the spec itself was only published in February
2026, with a "Version 1.1" update noted in June 2026), so treat any specific
field list as provisional until re-checked at build time, not treat this
document's summary as the final word.

---

## 5.2 Simplified Tax Invoices

### Definition
A reduced-field-set tax invoice permitted for certain lower-value or
consumer-facing transactions, omitting the recipient's name/address/TRN.

### Official UAE FTA business rules
- **[CONFIRMED]** A simplified tax invoice may be issued where **the
  recipient is not VAT-registered**, or where the recipient **is**
  VAT-registered but the total consideration does **not exceed AED
  10,000** (inclusive of VAT).
- **[CONFIRMED]** For B2B transactions, or any transaction at or above AED
  10,000, a **full** tax invoice is required — issuing a simplified invoice
  above that threshold is a documented, common finding in FTA audits (cited
  specifically in restaurant/retail sector guidance) and should be treated
  as a hard compliance rule, not a soft guideline.
- **[CONFIRMED — interacts with 5.1's e-invoicing note]** Under the
  e-invoicing framework, all invoices (implicitly including what were
  previously "simplified" invoices) must carry the full mandated field set
  — meaning the *reduced-field* concept of a simplified invoice may
  effectively be superseded by the e-invoicing mandate's uniform field
  requirements once that regime is mandatory for a given Tenant. This is an
  important, easy-to-miss interaction between two otherwise-separate rules.

### Real-world example
A retail customer buys AED 850 of goods with cash and no TRN — Al Noor
issues a simplified tax invoice: no customer name/address/TRN needed, but
still shows "Tax Invoice," Al Noor's own TRN, date, description, and the
VAT amount. The same AED 850 sale to another VAT-registered business still
qualifies for simplified treatment (below AED 10,000) — the AED 10,000
threshold, not the B2B/B2C distinction alone, is the deciding factor once
that threshold is not exceeded.

### Product implications
- The system should **automatically determine** full vs. simplified
  eligibility from transaction value and recipient VAT-registration status
  — not leave this as a free user choice, given how easy it is to get wrong
  and how directly it's called out as a common audit finding.
- Given the e-invoicing interaction noted above, this determination logic
  has a **built-in expiry** for any Tenant that becomes subject to the
  e-invoicing mandate (2027) — worth designing as a configurable rule, not
  a permanently hardcoded threshold check.

### Database implications
No separate `SimplifiedInvoice` entity needed — best modeled as an `Invoice`
with an `isSimplified` (or `invoiceType`) flag and nullable
recipient-identity fields, since the two share almost all other structure
and business logic (numbering, VAT calculation, issuance rules).

### API implications
Invoice-issuance logic should compute the full/simplified determination
server-side at issuance time based on the current total and recipient
status — never accept a client-asserted "this is simplified" flag without
validating it against the AED 10,000 rule.

### UI implications
The invoice creation flow can surface the determination as an automatic,
visible label ("This will be issued as a Simplified Tax Invoice because...")
rather than a manual toggle — educates the user while removing a
misclassification risk.

### Validation rules
**[BEST PRACTICE]** Hard-block issuing a simplified invoice for a
registered-recipient transaction at or above AED 10,000 — this is exactly
the kind of validation worth enforcing strictly, not just warning about,
given it's an explicitly cited common audit failure.

### Edge cases
A transaction that starts below AED 10,000 but is later increased via a
Debit Note (§5.4) or additional line items past the threshold — the
determination logic should be re-evaluated at the point of any value
change, not fixed permanently at original issuance.

### Future considerations
Track the e-invoicing rollout's actual treatment of simplified invoices
specifically (not just full invoices) as FTA guidance matures through 2026
— this document's research did not find explicit confirmation of whether
simplified invoices survive as a concept post-mandate, or are fully absorbed
into the uniform e-invoicing field set; flagged as an open question rather
than guessed at.

---

## 5.3 Credit Notes

### Definition
A document a supplier issues to **reduce** a previously reported taxable
value and output VAT — used for returns, price corrections, post-sale
discounts, cancellations, or any downward adjustment to an already-issued
tax invoice.

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 60 (format/content) and Article 61
  (when required), VAT Executive Regulations, also amended by Cabinet
  Decision No. 100 of 2025 (effective 29 September 2025).
- **[CONFIRMED]** Mandatory fields (Article 60): the words **"Tax Credit
  Note"** clearly displayed; supplier and recipient name/address/TRN (as
  applicable); date of issue; a clear explanation for issuance; a reference
  sufficient to identify the original supply/invoice being adjusted; and
  the financial adjustment detail — original value, corrected value, the
  difference, and the tax charged on that difference, in AED.
- **[CONFIRMED]** Article 61 requires the supplier to adjust output tax
  when a qualifying event occurs (e.g., a supply is cancelled or its value
  changes), and **Article 70 requires the credit note to be issued within
  14 calendar days** of that qualifying event.
- **[CONFIRMED]** Under the e-invoicing framework, credit notes carry the
  same full-field-set requirement as tax invoices (§5.1) — this is an
  explicit part of the Cabinet Decision No. 100 of 2025 amendment, not an
  inference.

### Real-world example
A customer returns AED 5,000 (+ AED 250 VAT) of goods originally invoiced
last month. Al Noor issues a Tax Credit Note referencing the original
invoice number, showing the AED 5,000/AED 250 reduction, within 14 days of
the return — reducing its output VAT liability for the period the credit
note is issued in (not retroactively restating the original period).

### Product implications
- Credit Notes are the product's **only** mechanism for correcting an
  issued invoice — per ADR-0001's general "no silent data mutation"
  philosophy and standard accounting practice, an issued Invoice should
  never be edited or deleted once issued; every correction is a new Credit
  (or Debit, §5.4) Note referencing it.
- The 14-day issuance window from the qualifying event is a real compliance
  deadline the product could actively help Tenants meet (e.g., flagging
  pending returns/cancellations approaching their deadline) — a genuine
  value-add opportunity, not just a passive record-keeping field.

### Database implications
`CreditNote` needs: a mandatory reference to the original `Invoice`, its own
sequential numbering (§8.1 — credit notes need their own numbering sequence,
distinct from invoices), the qualifying-event date (to support the 14-day
rule), issue date, reason/explanation, and the original/corrected/difference
value breakdown per Article 60.

### API implications
Credit Note creation must validate that it references a real, previously
issued Invoice belonging to the same Tenant (never allow cross-tenant
references, per ADR-0001 §6/§7's tenant-isolation rule) and should compute
the difference figures from the referenced invoice's actual values, not
accept them as arbitrary client input.

### UI implications
Credit Note creation should be initiated *from* the original invoice's
detail view ("Issue a Credit Note against this Invoice"), not as a
standalone form disconnected from its source — reduces the chance of a
misreferenced or orphaned credit note.

### Validation rules
**[BEST PRACTICE]** Warn (not necessarily hard-block, since real-world
delays happen) when a Credit Note is being issued more than 14 days after
its stated qualifying-event date, surfacing the compliance risk rather than
hiding it.

### Edge cases
- Partial credit (only some line items/quantity returned) vs. full
  cancellation of an invoice — both must be supported; the value breakdown
  should support partial-line adjustments, not just whole-invoice
  reversals.
- A credit note that would reduce the invoice's value below zero (over-
  crediting) is a data-integrity error the system should prevent, not
  silently allow.

### Future considerations
Same e-invoicing field-completeness stakes as §5.1 apply directly here —
design Credit Notes with the same PINT AE-readiness lens as Tax Invoices.

---

## 5.4 Debit Notes

### Definition
A document used to **increase** a previously invoiced value (e.g.,
under-billing correction, additional agreed charges after the original
invoice) — the inverse of a Credit Note.

### Official UAE FTA business rules
- **[BEST PRACTICE / not distinctly legislated the way Credit Notes are]**
  Research did not find a UAE VAT Law article that separately and formally
  legislates a "Tax Debit Note" the way Article 60 legislates the Tax
  Credit Note specifically. In UAE VAT practice, an **upward** correction to
  a previously issued invoice is commonly handled either by (a) issuing an
  additional/supplementary Tax Invoice for the extra amount, or (b) issuing
  a document commonly called a "debit note" by commercial convention,
  generally expected to carry the same core information as a tax invoice
  (parties, reference to the original supply, the additional value and VAT)
  even though it isn't a distinctly named creature of the VAT Law text
  itself. **Treat "Debit Note" in this product as an industry-standard
  commercial practice modeled on the Credit Note's structure, not as an
  independently confirmed FTA-legislated document type** — this is flagged
  explicitly because it's a meaningfully different confidence level than
  everything else in this section.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Whether to build Debit Notes as
  a first-class distinct document type (mirroring Credit Notes structurally)
  or to simply support "issue an additional Tax Invoice referencing the
  original" as the product's answer to upward corrections is a genuine
  design choice this document flags rather than resolves — recommend
  confirming with a licensed UAE tax agent before Module 2 locks in the
  approach, given the weaker legislative footing versus Credit Notes.

### Real-world example
Al Noor under-billed a customer by AED 2,000 due to a pricing error. Under
the (b) convention above, Al Noor would issue a debit note for AED 2,000 +
VAT, referencing the original invoice, to correct the shortfall.

### Product implications
Given the weaker/less distinctly legislated footing, the product should
avoid over-engineering a rigid "Debit Note" workflow disconnected from
ordinary invoicing — the safer default is likely to let an upward
correction be handled as a new Tax Invoice (fully compliant, unambiguous)
with an optional reference field pointing back to the original transaction,
while still offering a "Debit Note" label/template for businesses whose own
accounting convention expects one.

### Database implications
If built as a distinct type: mirror the `CreditNote` structure with an
increase rather than decrease in value. If built as "just another invoice
with a reference field" (the lower-risk option): no new entity needed
beyond an optional `relatedInvoiceId` on `Invoice` itself.

### API implications
Whichever approach is chosen, it should reuse the Credit Note's
tenant-isolation and reference-validation logic (§5.3) rather than
duplicating it.

### UI implications
Label clearly as "Debit Note" in the UI regardless of underlying
implementation, since that's the term UAE business users will expect and
search for, even if the backend models it as a specialized invoice.

### Validation rules
Same original-invoice-reference validation as Credit Notes, mirrored for
the increase direction.

### Edge cases
A dispute over whether an upward correction should have been a debit note
vs. a fresh, independent sale — a business-process question outside what
the software can resolve; the product's job is to make either path
recordable and auditable, not to adjudicate intent.

### Future considerations
Confirm actual current FTA/Ministry guidance on debit notes specifically
before Module 2 build — this section carries the lowest confidence rating
in this entire knowledge base and deserves a direct tax-agent check, not
just further web research.

---

## 5.5 Discounts

### Definition
A reduction to the value of a supply, applied before or after the date of
supply, which reduces the taxable value VAT is calculated on.

### Official UAE FTA business rules
- **[CONFIRMED]** The value of supply is reduced in proportion to any
  discount given (before, at, or after the date of supply) — VAT is charged
  on the **net (discounted) value**, not the pre-discount value.
- **[CONFIRMED]** For discounts applied **after** an invoice has already
  been issued (post-sale discounts/rebates), the correction is made via a
  **Credit Note** (§5.3), adjusting the previously reported output tax —
  not by editing the original invoice.

### Real-world example
A AED 10,000 sale with a AED 500 discount is invoiced at a net value of AED
9,500, with 5% VAT (AED 475) charged on the discounted amount — not AED 500
VAT on the pre-discount value.

### Product implications
Discounts applied at the point of invoice creation are simply a line-item
(or invoice-level) value reduction feeding into the standard VAT
calculation — no special VAT logic beyond "calculate on net, not gross."
Discounts applied *after* issuance must route through the Credit Note flow
in §5.3, not a direct edit.

### Database implications
Invoice line items need a discount field (amount or percentage) that
reduces the taxable value *before* VAT is computed on that line — and per
Article 59 (§5.1), the discount amount itself must be shown on the invoice,
so it needs to be a visible, stored value, not just netted away silently.

### API implications
VAT calculation logic (wherever it lives — ideally a shared service per
ADR-0001 §13.1) must apply discount before computing tax on every line,
consistently, so this isn't reimplemented ad hoc per feature.

### UI implications
Invoice line-item entry should show gross, discount, net, and VAT amount
distinctly — matching the Article 59 requirement that discount be visible
on the rendered document, not folded invisibly into a single "price" field.

### Validation rules
**[BEST PRACTICE]** A discount should never exceed the line's gross value
(no negative net values from a discount alone).

### Edge cases
- Invoice-level discounts (e.g., "10% off the whole order") vs. line-level
  discounts — both are common in practice; the product should decide (and
  document) whether invoice-level discounts are apportioned across lines
  for per-line VAT reporting, or the invoice supports a single blended
  discount line — this affects the granularity needed for multi-category
  invoices (§2.1) where lines carry different VAT rates.
- Volume/loyalty discounts issued well after the original sale, sometimes
  aggregated across multiple invoices — these should be modeled as Credit
  Notes against the specific original invoices, not a vague "loyalty
  credit" untethered to identifiable original supplies.

### Future considerations
None beyond what Credit Notes (§5.3) and multi-category invoicing (§2.1)
already require.

---

## 5.6 Shipping

### Definition
Charges for delivery, freight, or courier services associated with a supply
of goods — VAT treatment depends on whether the transport is domestic or
international, and who is providing it relative to the underlying goods
supply.

### Official UAE FTA business rules
- **[CONFIRMED]** **Domestic** shipping/delivery (within the UAE) is
  generally a **standard-rated** taxable supply of services at 5% — a
  courier fee for a Dubai-to-Abu Dhabi delivery is taxed normally.
- **[CONFIRMED]** **International** transport of goods (entering, leaving,
  or passing through the UAE) is **zero-rated** (§2.3/§3.2) under Article
  33 of the Executive Regulations.
- **[CONFIRMED]** A **domestic leg** of an international transport journey
  can also be zero-rated, but **only** when supplied by the **same taxable
  person** providing the international leg — a separately contracted local
  courier completing the "last mile" of an international shipment does
  **not** automatically inherit zero-rating; that leg is standard-rated
  unless it's the same supplier providing an integrated international
  service.

### Real-world example
Al Noor ships goods from Dubai to a customer in Abu Dhabi via a local
courier — standard-rated, 5% VAT on the delivery fee. When Al Noor exports
goods to Saudi Arabia and itself handles the full door-to-door logistics
(domestic collection through international delivery) as one supplier, the
entire freight charge — including the domestic collection leg — can be
zero-rated as part of the international transport service.

### Product implications
Shipping/delivery charges on an invoice are simply another line item with
its own VAT category (§2.1) — not a special "invoice fee" type that bypasses
normal VAT categorization. The category (standard vs. zero-rated) depends
on the international/domestic and same-supplier conditions above, which the
product should prompt for rather than assume.

### Database implications
No new entity — a shipping charge is an `Invoice` line item like any other,
with its own description, value, and VAT category/rate — reinforcing why
line-item-level (not invoice-level) VAT categorization (§2.1) is the correct
foundational model.

### API implications
No special endpoint — covered entirely by general line-item creation
(§2.1/§5.1).

### UI implications
When adding a "shipping" line, the invoice UI could offer a helpful default
category prompt ("Is this domestic or international transport, and is it
part of an international shipment you're also supplying?") rather than
silently defaulting shipping lines to standard-rated, given how easy the
zero-rating condition is to miss.

### Validation rules
None beyond the general per-line VAT category rules in §2.1.

### Edge cases
Mixed shipments (part of the goods going domestically, part
internationally, on one invoice) — shipping charges may need to be split
proportionally, which is a real modeling complexity worth flagging for
whichever Tenant persona (e.g., a freight/logistics business) would
encounter it, though likely rare for a typical UAE SME trading business.

### Future considerations
None beyond the general multi-category invoicing capability this depends on.

---

## 5.7 Adjustments

### Definition
A general term covering any correction to previously reported VAT figures
that isn't cleanly a standard Credit Note against a single invoice —
includes bad debt relief, deemed-supply corrections, capital asset scheme
annual adjustments (§6.1), and error corrections reported directly on a VAT
return.

### Official UAE FTA business rules
- **[CONFIRMED] Bad debt relief** (Article 64): a supplier that charged,
  accounted for, and paid output VAT on a supply, where the consideration
  has since been **wholly or partly written off as a bad debt** in the
  accounts, **more than 6 months** have passed since the date of supply,
  and the supplier has **notified the recipient** of the write-off, may
  adjust (reduce) previously reported output VAT to the extent of the
  amount actually written off. Reported specifically in the **Adjustments
  column of Box 1** of the VAT return.
- **[CONFIRMED]** The **Capital Assets Scheme** (§6.1) requires its own
  annual input VAT adjustment over the asset's monitoring period — a
  distinct, recurring type of adjustment, not a one-off correction.
- **[CONFIRMED]** The VAT return itself has a dedicated adjustment
  mechanism (the "Adjustments" column referenced above) distinct from the
  main supply-value boxes — meaning the product's VAT return generation
  (§7.1) needs to model adjustments as their own reportable category, not
  fold them into ordinary period totals.

### Real-world example
Al Noor supplied AED 20,000 + AED 1,000 VAT to a customer 8 months ago. The
customer has gone into liquidation and the debt is written off in Al Noor's
accounts; having notified the customer of the write-off, Al Noor adjusts its
VAT return, reducing output VAT by AED 1,000 in the Adjustments column of
the period it makes the write-off — without needing to reissue or
retroactively alter the original invoice.

### Product implications
- Bad debt relief is a genuinely useful feature for the product to support
  explicitly (many SME accounting tools miss this) — it requires tracking
  invoice **payment/aging status**, which doesn't exist anywhere in the
  current schema (Module 0's `Invoice.status` is just `UNPAID` by default
  with no broader lifecycle) and will need real design attention once
  Module 2/3 build out payment tracking.
- Adjustments as a category need their own place in the VAT return data
  model (§7.1), distinct from both normal supplies and Credit/Debit Notes.

### Database implications
- A bad-debt adjustment needs: reference to the original invoice, write-off
  date, write-off amount, the 6-month-elapsed check (derivable from
  invoice supply date), and evidence of recipient notification (at minimum
  a recorded date/flag, ideally a linked record of the notification sent).
- The Capital Assets Scheme's annual adjustments (§6.1) are a structurally
  different, recurring adjustment type and should not be modeled as the
  same entity as a one-off bad-debt adjustment, even though both ultimately
  land in the same VAT-return "Adjustments" reporting box.

### API implications
Adjustment creation (bad debt, capital asset, or manual/error-correction)
should be modeled as its own operation type feeding into VAT return
generation (Module 3), auditable and reversible-by-further-adjustment
(never a silent edit to historical figures) — consistent with the
"corrections are new records, not mutations" principle established for
Credit Notes (§5.3).

### UI implications
A future VAT Position/Adjustments view should let a Tenant see all
adjustments for a period in one place (bad debt write-offs, capital asset
adjustments, manual corrections), since they all ultimately feed the same
VAT return box and a Tenant/accountant will want to review them together
before filing.

### Validation rules
**[BEST PRACTICE]** Bad debt relief should validate the 6-month elapsed
condition and require the notification evidence before allowing the
adjustment — the FTA's four conditions (Article 64) are conjunctive (all
must be true), not a checklist of options.

### Edge cases
A partially written-off debt followed by a later partial recovery (customer
pays some of it back after relief was claimed) — VAT law generally expects
the relief to be reversed proportionally if the debt is later recovered;
worth explicit design attention once payment tracking exists, not assumed
away.

### Future considerations
This category is a strong candidate for its own dedicated service class
(ADR-0001 §13.1) given how many distinct sub-rules (bad debt, capital asset,
manual) feed into one reporting concept — a good real-world test of the
"business logic in services, not controllers" principle once Module 3 is
built.
