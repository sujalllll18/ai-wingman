# 8. Invoice Numbering, Record Retention, Currency & Rounding

Covers: **Invoice Numbering**, **Record Retention**, **Currency Rules**,
**Rounding Rules**.
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

---

## 8.1 Invoice Numbering

### Definition
The requirement that every tax invoice carry a number that uniquely and
verifiably identifies it, supporting the FTA's ability to confirm no
invoices have been skipped, duplicated, or backdated.

### Official UAE FTA business rules
- **[CONFIRMED]** Article 59 requires a **"sequential or otherwise unique
  number which enables identification of the Tax Invoice"** — the law's own
  wording allows either a sequential number *or* another scheme that
  achieves unique identification, but sequential numbering is the
  overwhelmingly standard, safest interpretation in practice, and is what
  FTA audits specifically check for (an unexplained gap in a sequential
  series is a common audit red flag).
- **[CONFIRMED]** Credit Notes (§5.3) need their own unique
  identification, separate from Tax Invoice numbers, per Article 60's
  content requirements.
- **[CONFIRMED — from the e-invoicing technical spec]** The FTA's 51-field
  PINT AE model (§5.1) includes invoice-identification fields as part of
  its mandatory structure — meaning numbering isn't just an internal
  bookkeeping choice once e-invoicing applies to a Tenant; it becomes part
  of a machine-validated network exchange.
- **[BEST PRACTICE]** Common practice, not a specific numeric-format
  mandate: numbering per legal entity/TRN, often with a format like a
  prefix + year + sequence (e.g., `INV-2026-000123`), reset annually or
  continued indefinitely depending on the business's own convention — the
  law does not mandate a specific format, only sequentiality/uniqueness and
  identifiability.

### Real-world example
Al Noor issues invoices `INV-2026-000001` through `INV-2026-000150` across
the year with no gaps; if an FTA auditor requests invoice `000042` and it
doesn't exist (deleted, or renumbered), that's a direct, hard-to-explain
compliance defect — which is exactly why issued invoices must never be
deletable (§5.1's immutability point).

### Product implications
- Given ADR-0001 §7's pooled multi-tenancy model, invoice numbering **must
  be scoped per Tenant** (each Tenant's own sequence), not a single global
  platform-wide sequence — two different Tenants both having an "Invoice
  #1" is entirely normal and expected; a gap in *one* Tenant's sequence is
  the compliance concern, not cross-tenant numbering overlap.
- Sequence generation must be **atomic and gap-free under concurrency** —
  if two invoices are created near-simultaneously for the same Tenant (e.g.,
  two Staff users both issuing invoices at once), the numbering logic must
  not produce a duplicate or accidentally skip a number. This is a genuine
  concurrency-correctness requirement, not just a UI nicety, and should be
  handled at the database/transaction level (e.g., a per-Tenant counter
  updated within the same transaction as invoice creation), not computed
  client-side or via a naive "count existing invoices + 1" query (which is
  race-condition-prone).

### Database implications
- A per-Tenant sequence counter (could be a dedicated `InvoiceSequence`
  row per Tenant, incremented atomically, or a database-native sequence
  scoped appropriately) — the earlier ADR-0001 §4 recommendation to add
  `@@unique([tenantId, invoiceNumber])` once Invoicing is built is the
  right database-level backstop, but shouldn't be the *only* safeguard,
  since a unique constraint prevents duplicates but doesn't by itself
  guarantee gap-free sequential allocation under concurrent access — the
  allocation logic itself needs to be atomic.
- Credit Notes need their own equivalently-scoped, equivalently-atomic
  sequence, separate from Invoice numbers (per Article 60).

### API implications
Invoice-number assignment belongs entirely inside the invoice-issuance
service (ADR-0001 §13.1), never client-supplied or client-influenced — the
number is assigned by the backend at the moment of issuance, atomically,
as part of the same operation that finalizes the invoice.

### UI implications
The invoice number should be displayed prominently and read-only once
issued (already implicitly the pattern established by Module 0's
`.mono`-styled numeric display conventions) — never presented as an
editable field.

### Validation rules
**[BEST PRACTICE]** The system should be able to detect and flag (for the
Tenant's own awareness, ideally never let happen in the first place) any
gap in a Tenant's invoice sequence — a genuinely valuable audit-readiness
feature.

### Edge cases
- A draft invoice that's abandoned before issuance — should **not** consume
  a sequence number if numbers are only assigned at issuance (the safer
  design), avoiding an "explainable but awkward" gap. If numbers are instead
  assigned at draft-creation, gaps from abandoned drafts become a real,
  recurring nuisance to explain on audit — a strong argument for
  assign-at-issuance as the default design.
- Multi-currency or multi-branch numbering conventions — not needed unless
  Tax Groups (§1.1) or Designated Zone multi-entity structures (§3.4) are
  ever in scope; a single per-Tenant sequence is sufficient for the current
  single-legal-entity-per-Tenant model.

### Future considerations
The e-invoicing PINT AE format (§5.1) will formalize invoice identification
requirements at a network-validated level — worth re-confirming this
section's specifics against the actual PINT AE spec once Module 2 build
starts.

---

## 8.2 Record Retention

### Definition
The minimum period a business must keep VAT-relevant records, accessible
and producible on FTA request.

### Official UAE FTA business rules
- **[CONFIRMED]** **Standard retention: 5 years**, calculated from the
  **end of the tax period** the record relates to (not the document date
  itself) — applies to invoices, VAT returns, ledgers, and general
  supporting documentation.
- **[CONFIRMED]** **Capital Assets** (§6.1): records must be retained for
  **10 years**, reflecting the Capital Asset Scheme's own multi-year
  monitoring obligation.
- **[CONFIRMED]** **Real estate**-related records specifically: **15
  years** — the longest retention period, reflecting real estate's
  extended compliance/audit exposure (this is a real-estate-specific rule,
  layered on top of, not replacing, the general capital-asset 10-year rule
  — a real estate capital asset gets the longer 15-year period).
- **[CONFIRMED]** Records may be kept electronically or physically, but
  must remain **accurate, secure, and accessible within the UAE**, capable
  of being produced promptly on FTA request.

### Real-world example
An ordinary sales invoice from Q2 2026 must be retrievable until the end of
Q2 2031 (5 years from the end of that tax period). Records for the AED
8,000,000 warehouse capital asset from §6.1's example must be retrievable
for 10 years from its relevant period-end (or 15, if it also counts as a
real-estate-specific record); if it's later leased out as real estate, the
longer real-estate retention period should apply.

### Product implications
- Retention period is **not uniform** — the product must track it
  per-record-type, not apply a single blanket policy, since ordinary
  transactions, capital assets, and real estate each have different
  minimums.
- This has a direct, immediate consequence for ADR-0001 §4's already-
  flagged recommendation: **financial records should favor soft-delete
  (`deletedAt`) over hard-delete**, specifically *because* of these
  multi-year (and in the real-estate case, 15-year) legal retention
  requirements — a hard-delete capability on an invoice or capital-asset
  record would make it structurally impossible to comply with this rule if
  ever misused, whether accidentally or by a bad actor.

### Database implications
- No record type this knowledge base has described (Invoice, Credit Note,
  Purchase, Capital Asset, VAT Return) should ever support hard deletion
  from the UI/API once issued/finalized — consistent with the immutability
  principle already established for Invoices (§5.1) and Credit Notes
  (§5.3), now generalized: **retention, not just immutability, is the
  reason**.
- A per-record "retain until" date (derivable from record type + relevant
  period-end, per the rules above) is a useful concept for a future
  retention-compliance/archival view, even if not enforced as a hard
  technical block on deletion (soft-delete + no UI delete path is likely
  sufficient enforcement without needing a separate retention-date field
  from day one).

### API implications
No delete endpoints should exist for issued financial documents — this
should be treated as a permanent API design constraint, not merely a
current-Module-0 observation (Module 0 has no such endpoints yet because it
has no financial documents yet; this is guidance for when they're built).

### UI implications
No delete action should ever be exposed for an issued invoice, credit note,
or finalized VAT return anywhere in the UI — corrections happen via new
records (Credit/Debit Notes, adjustments), never removal of the original.

### Validation rules
**[BEST PRACTICE]** Enforce retention at the architecture level (no delete
capability exists at all for these record types) rather than as a
time-based validation rule that could theoretically be bypassed — the
safest compliance posture is "the delete button doesn't exist," not "the
delete button checks a date first."

### Edge cases
A Tenant deregisters or leaves the platform entirely — their historical
records still carry the same FTA retention obligations regardless of
whether they're an active paying Tenant; data export/long-term archival on
Tenant offboarding needs its own explicit design (not currently addressed
anywhere in Module 0) so retention obligations survive a Tenant's
departure from the platform.

### Future considerations
A formal data-retention/archival policy (how records are kept accessible
for 5/10/15 years even as the platform itself evolves, changes database
providers, etc.) is worth a dedicated design pass once real financial data
exists — flagged here as a real, non-hypothetical future requirement, not
just a nice-to-have.

---

## 8.3 Currency Rules

### Definition
Rules governing how amounts in a currency other than the UAE Dirham (AED)
must be handled on VAT-relevant documents.

### Official UAE FTA business rules
- **[CONFIRMED]** All amounts on a tax invoice — and the VAT amount
  specifically — must be expressed in **AED**, even if the underlying
  commercial transaction is agreed/invoiced in a foreign currency.
- **[CONFIRMED]** Foreign currency amounts must be converted to AED using
  the **exchange rate published by the UAE Central Bank** (CBUAE), using
  the **full published decimal precision** — rounding the *exchange rate*
  itself to fewer decimal places (e.g., rounding to AED 3.7 instead of the
  full published rate) is **not permitted**. This requirement has applied
  to invoices issued from **17 May 2018** onward.
- **[CONFIRMED]** CBUAE publishes rates for 70+ currencies, updated Monday
  through Friday based on FX rates prevailing at 6pm UAE time each day — the
  applicable rate is generally the one published for the **date of
  supply** (the tax point, §5.1/§8.1-adjacent).

### Real-world example
Al Noor invoices a customer USD 10,000 for goods. Using CBUAE's published
rate for the date of supply (e.g., 3.6725, at full published precision, not
rounded to 3.67), the invoice must show the AED-equivalent value and AED
VAT amount, alongside (optionally) the original USD figures.

### Product implications
- Any future multi-currency invoicing capability (not in Module 0/1's
  current scope, but plausible for Module 2 given UAE's international trade
  volume) needs a reliable, current, full-precision AED exchange rate
  source **for the specific date of supply** — not "today's rate" applied
  retroactively, and not a rounded/simplified rate.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Whether the product integrates
  directly with a CBUAE rate feed (if one is programmatically available) or
  requires manual/periodic rate entry is a real build-vs-scope decision for
  whichever module first supports foreign-currency invoicing — flagged, not
  resolved, here.

### Database implications
A foreign-currency invoice needs to store: the original currency and
amount, the exchange rate actually used (at full precision, with its
source date), and the resulting AED amounts — all snapshotted at issuance,
never recomputed later from a "current" rate (consistent with the general
snapshot-at-issuance principle established in §1.3/§5.1).

### API implications
If built, exchange-rate lookup should be a distinct, testable service
function (ADR-0001 §13.1) — feeding the invoice-issuance service, not
embedded inline in it, since rate-source reliability and precision
handling deserve isolated testing.

### UI implications
A foreign-currency invoice should display both the original currency amount
and the AED-converted amount clearly, with the exchange rate and its date
visible (supports the Tenant's own audit trail, and is generally good
practice for any invoice recipient reconciling the amount against their own
records).

### Validation rules
**[BEST PRACTICE]** Reject invoice issuance if no valid CBUAE-sourced rate
is available for the required date — never silently fall back to an
approximate or manually-guessed rate for a legal document.

### Edge cases
- CBUAE doesn't publish rates on weekends/UAE holidays (updates are
  Monday–Friday) — the applicable rate for a Friday/Saturday/Sunday date of
  supply needs a defined fallback rule (most likely: the most recently
  published rate), which should be confirmed directly against CBUAE/FTA
  guidance rather than assumed, before this is built.
- A currency CBUAE doesn't publish a rate for at all (rare, exotic
  currencies) — needs its own fallback policy, not encountered in this
  research pass.

### Future considerations
Not urgent for Module 0/1; becomes directly relevant the moment Module 2
supports any customer or supplier transacting in a non-AED currency —
common enough in UAE trade (given significant USD/other-currency invoicing
in some sectors) that it shouldn't be assumed out of scope indefinitely.

---

## 8.4 Rounding Rules

### Definition
Rules for handling fractional amounts smaller than the smallest unit UAE
VAT figures are expressed in (the **fils**, 1/100 of a dirham) when
computing VAT.

### Official UAE FTA business rules
- **[CONFIRMED]** When a computed VAT amount lands on a fraction of a fil,
  it should be **rounded mathematically to the nearest fil** (standard
  round-half-up/round-to-nearest convention, not truncation).
- **[CONFIRMED]** Rounding should be applied **consistently** — either
  **per line item** or on the **gross invoice total**, but **not a mixture
  of both approaches within the same invoice**. Mixing methods on one
  document is specifically flagged as something to avoid, since it can
  produce small but auditable discrepancies between a "sum of rounded
  lines" total and a "round the sum once" total.
- **[CONFIRMED]** This is distinct from a separate, narrower **consumer
  cash-rounding** rule seen in some Emirates (e.g., Abu Dhabi permitting
  final retail prices to round up to the nearest 25 fils for cash
  transactions where exact coins aren't available) — that's a retail
  pricing-display convenience rule, not a VAT-calculation rule, and should
  not be conflated with how VAT itself is computed and reported.

### Real-world example
A line item of AED 333.33 at 5% VAT computes to AED 16.6665 — rounded to
AED 16.67 (nearest fil). If an invoice has multiple lines, the business must
consistently either round each line this way and sum the rounded VAT
amounts, or sum the exact (unrounded) VAT across all lines and round once
at the gross total — not switch between the two approaches on the same
document.

### Product implications
- This is a small-looking rule with real audit consequences: inconsistent
  rounding is exactly the kind of discrepancy that shows up when an FTA
  auditor (or a customer's AP team) recalculates an invoice's VAT from its
  line items and gets a slightly different total than what's printed.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Per-line rounding vs.
  gross-total rounding is a genuine implementation choice the law leaves
  open (as long as it's applied consistently) — recommend choosing
  **per-line rounding** as the product-wide standard (it's the more common
  convention in invoicing software generally, and makes each line
  independently auditable), applied identically across every Tenant and
  every invoice, never configurable per-Tenant (configurability here would
  reintroduce exactly the "mixed methods" risk the rule warns against, just
  at the platform level instead of the single-invoice level).

### Database implications
VAT amounts should be stored with enough precision to avoid double-rounding
errors — e.g., storing line-level VAT already rounded to the fil (2 decimal
places in AED terms) if per-line rounding is the chosen standard, with the
invoice total computed as a straightforward sum of those already-rounded
values (never re-derived by recomputing from an unrounded base).

### API implications
The VAT calculation service (ADR-0001 §13.1) should implement rounding as
one single, shared, well-tested function used everywhere a VAT amount is
computed — Invoices, Credit Notes, Purchases, Capital Asset adjustments —
so the platform-wide consistency requirement above is structurally
guaranteed, not dependent on every call site remembering to round the same
way.

### UI implications
No user-facing rounding configuration should be exposed — this should be a
fixed platform behavior, not a per-Tenant preference, precisely because
inconsistency (even well-intentioned, Tenant-chosen inconsistency) is the
thing the underlying FTA guidance warns against.

### Validation rules
**[BEST PRACTICE]** Any automated test of the VAT calculation service
(a natural fit once that service exists per ADR-0001 §13.1) should include
explicit rounding-boundary test cases (e.g., exact half-fil amounts) to
lock in the chosen convention and prevent silent drift if the calculation
logic is ever refactored.

### Edge cases
Foreign-currency invoices (§8.3) compound this: rounding applies to the
converted AED amount, not the original foreign-currency amount — the order
of operations (convert-then-round vs. round-then-convert) matters and
should be fixed as convert-at-full-precision-then-round-the-AED-result, to
avoid compounding two separate rounding errors.

### Future considerations
None beyond ensuring this stays a single, shared, tested calculation
function as the product grows — the risk here is architectural drift
(multiple call sites reimplementing rounding slightly differently) more
than any change in the underlying rule itself.
