# 7. Returns & Filing

Covers: **VAT Returns**, **Filing Periods**, and the penalty framework that
gives both real stakes (added because it's inseparable from "why filing
periods and deadlines matter" — the product's value proposition here is
literally helping a Tenant avoid these).
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

---

## 7.1 VAT Returns

### Definition
The periodic declaration a VAT-registered business submits to the FTA
(via the EmaraTax portal), summarizing output VAT charged, input VAT
recovered, and the resulting net VAT payable or refundable for a tax period.

### Official UAE FTA business rules
- **[CONFIRMED]** Filed through the FTA's **EmaraTax** platform.
- **[CONFIRMED]** Structurally, the return separates figures by category —
  standard-rated supplies, zero-rated supplies, exempt supplies, and
  reverse-charge/imports each have distinct reporting boxes (this document's
  research consistently referenced "Box 1" for output tax and its
  adjustment column, per §5.7's bad debt relief mechanic; a full box-by-box
  layout wasn't independently re-verified in this pass and should be
  confirmed against the current EmaraTax return template before Module 3
  build, since presentation details can change even if the underlying VAT
  law doesn't).
- **[CONFIRMED]** The return nets output VAT against recoverable input VAT
  for the period; a positive balance is payable to the FTA, a negative
  balance is either refundable or carried forward — subject to the 5-year
  carry-forward cap (§4.3) introduced by the 1 January 2026 amendments.
- **[CONFIRMED]** Adjustments (bad debt relief, Capital Asset Scheme annual
  adjustments — §5.7/§6.1) are reported in a dedicated adjustments
  mechanism within the return, distinct from ordinary period totals.

### Real-world example
Al Noor's Q1 return declares: AED 200,000 standard-rated supplies (AED
10,000 output VAT), AED 50,000 zero-rated exports (AED 0 output VAT but
still reported as a supply), AED 80,000 recoverable input VAT, and one bad
debt adjustment reducing output VAT by AED 1,000 — netting to AED 9,000
payable to the FTA for the quarter.

### Product implications
- This is the entire *point* of Module 3 (VAT Position): everything modeled
  in this knowledge base (categories, invoices, credit notes, reverse
  charge, recoverability, adjustments) ultimately feeds one computed return
  for a period. The VAT Return should be built as a **derived report**, not
  an independently-entered form — every figure on it must be traceable back
  to the underlying transactions that produced it.
- Given VAT returns are legal filings with real financial and penalty
  consequences (§7.3), the product should almost certainly stop short of
  actually *submitting* to EmaraTax automatically in early modules —
  generating an accurate, well-organized return the Tenant/their accountant
  reviews and files themselves is a safer, still highly valuable first
  version. **[ASSUMPTION — NEEDS PRODUCT DECISION]**: whether direct
  EmaraTax API filing is ever a goal is a real product/liability decision,
  not assumed here either way.

### Database implications
A `VatReturn` (or `VatPeriodSummary`) concept, generated per Tenant per tax
period, aggregating: output VAT by category, input VAT by
recoverability status, net position, adjustments, and carry-forward
tranche consumption (§4.3) — should be regeneratable/recomputable on demand
from underlying data, not a value that's manually entered and then trusted.

### API implications
A `GET /api/tenant/vat-returns/:period` (or similar) endpoint that computes
and returns the full breakdown — a strong candidate for the "service layer"
principle (ADR-0001 §13.1) given how many of this knowledge base's other
topics (§2, §3.3, §4, §5.3, §5.7, §6.1, §6.2) all feed into this single
calculation.

### UI implications
A VAT Position/Returns dashboard, showing the period's figures broken down
by category with drill-down to the underlying transactions — the single
most valuable screen in the eventual product, and worth designing carefully
once Module 3 starts, not treated as an afterthought summary page.

### Validation rules
**[BEST PRACTICE]** A return should not be presentable as "final/ready to
file" while any of its constituent Invoices are still in draft state, or
while known-pending Credit Notes (§5.3, within their 14-day window) haven't
been resolved — a review-readiness check, not a hard block, since real
businesses will sometimes need to file with incomplete information and
amend later.

### Edge cases
Amending a previously filed return (errors discovered after filing) — UAE
VAT procedure allows corrections, generally either through a voluntary
disclosure process for material errors or through the adjustments mechanism
for smaller corrections in a later period; this document did not
deep-research the voluntary disclosure threshold/process specifically, and
it should be researched directly before Module 3 builds any
correction/amendment workflow.

### Future considerations
Direct EmaraTax API integration (if UAE government e-services expose one)
would be a significant differentiator but needs its own dedicated research
pass — not assumed available in this document.

---

## 7.2 Filing Periods

### Definition
The recurring time window (monthly or quarterly) for which a Tenant must
prepare and submit a VAT return.

### Official UAE FTA business rules
- **[CONFIRMED]** Standard tax period: **quarterly** for businesses with
  annual turnover **below AED 150 million**; **monthly** for businesses
  with annual turnover **AED 150 million or more**. The FTA may assign a
  different period to specific businesses at its discretion.
- **[CONFIRMED]** Filing deadline: **28 days after the end of the tax
  period** (e.g., a Jan–Mar quarter is due by 28 April). If the 28th falls
  on a weekend or national holiday, the deadline extends to the next
  business day.
- **[CONFIRMED]** The specific tax period assigned to each registrant is
  visible on their own FTA/EmaraTax portal account — not something the
  product can assume from turnover alone without the Tenant confirming
  their actual assigned period, since the FTA retains discretion to assign
  a different period.

### Real-world example
Al Noor, with annual turnover of AED 4 million (well below AED 150 million),
files quarterly. Its Q1 (Jan–Mar) return is due by 28 April; if 28 April
falls on a Friday (UAE weekend), the deadline moves to the next business
day.

### Product implications
- The product needs to know **each Tenant's actual assigned filing
  period** — not derive it purely from a turnover threshold, since the FTA
  can assign a non-standard period. This should be a Business Profile field
  (§1.3) the Tenant confirms/enters, not an auto-computed value the product
  asserts confidently.
- Deadline tracking (28 days + weekend/holiday adjustment) is a concrete,
  buildable reminder feature — genuinely useful and low-complexity relative
  to the rest of this knowledge base.

### Database implications
`Tenant` (or a new Business Profile entity, §1.3) needs a `filingPeriod`
(`MONTHLY | QUARTERLY`) field and enough information to compute the current
and next period's start/end/due dates — a UAE public-holiday calendar
becomes a real, if small, dependency for correct due-date computation.

### API implications
A "current/upcoming filing period" endpoint, useful both for the VAT Return
feature (§7.1) and for reminder/notification features.

### UI implications
A persistent, visible "next VAT return due" indicator somewhere in the
Tenant portal (a natural home on a future Tenant dashboard) — turns an
abstract compliance date into an always-visible product touchpoint.

### Validation rules
**[BEST PRACTICE]** Filing period should not be user-editable without
friction/confirmation, since it's an FTA-assigned fact about the business,
not a product preference — an accidental change here would produce
incorrect deadline tracking.

### Edge cases
A Tenant's filing period changes (FTA reassigns monthly due to turnover
growth crossing AED 150 million, or a special assignment) — the product
needs a way to record an *effective date* for a filing-period change, not
just overwrite the current value, so historical periods are still computed
correctly.

### Future considerations
A UAE public-holiday calendar (for accurate weekend/holiday deadline
shifting) needs a maintenance source — likely a small reference dataset
updated periodically, not hardcoded once and forgotten.

---

## 7.3 Penalty Framework (context for §7.1/§7.2)

### Definition
The FTA's administrative penalty regime for non-compliance — included here
because it's the concrete "why this matters" behind Returns and Filing
Periods, and because a VAT SaaS product's core value proposition is
directly measured in penalties avoided.

### Official UAE FTA business rules
- **[CONFIRMED]** Late registration (§1.1): **AED 10,000**.
- **[CONFIRMED]** Late filing: **AED 1,000** for a first occurrence, **AED
  2,000** for a repeat violation within 24 months — applies even to a nil
  return (no VAT due doesn't exempt a business from the filing obligation
  or its penalty).
- **[CONFIRMED]** Late payment: as of **Cabinet Decision No. 129 of 2025**
  (effective **14 April 2026**), late payment accrues at **14% per annum**,
  calculated monthly on the outstanding balance — this **replaced** the
  previous compounding daily/monthly penalty structure, so any older
  guidance describing the pre-2026 late-payment penalty structure is now
  outdated.
- **[CONFIRMED]** Persistent non-filing (two or more consecutive missed
  returns) can trigger an FTA inspection; documentation-submission failures
  during such an inspection carry their own **AED 5,000 per violation**
  penalty under the same Cabinet Decision No. 129 of 2025.
- **[CONFIRMED]** General penalty range for other violations (incorrect
  returns, poor record-keeping, etc.): cited sources describe a range from
  AED 500 for minor violations up to 15% of unpaid tax for FTA-discovered
  errors — this document did not deep-research every specific violation
  type's exact penalty; treat the general range as directionally correct
  and re-verify specifics before building any in-product penalty-estimation
  feature.

### Real-world example
If Al Noor files its Q1 return 10 days late, it owes a flat AED 1,000
penalty (or AED 2,000 if it's a repeat late filing within 24 months) on top
of whatever VAT is actually due — and if the VAT payment itself is also
late, an additional 14%-per-annum charge accrues monthly on the unpaid
balance from Cabinet Decision No. 129 of 2025.

### Product implications
This entire framework is the business case for §7.2's deadline-tracking
features — the product should be able to state, concretely, "filing X days
late costs a minimum of AED 1,000" as part of its own value proposition,
not just as background compliance trivia.

### Database implications
No new entity required — this is reference/informational data (could be a
small static lookup used in UI copy/warnings) rather than something tracked
per-transaction.

### API implications
None directly — informs the *urgency* framing of the filing-period
reminder feature (§7.2), not a separate API surface.

### UI implications
Deadline reminders (§7.2) are more effective when they state the concrete
penalty at stake ("File within 3 days to avoid the AED 1,000 late-filing
penalty") rather than a generic date reminder — directly actionable,
directly tied to this section's confirmed figures.

### Validation rules
Not applicable — this is reference information, not a data-validation
concern.

### Edge cases
Penalty amounts and structures are exactly the kind of thing that changes
by Cabinet Decision (as the April 2026 late-payment restructuring shows) —
any in-product penalty figures should be sourced from a single,
easily-updatable reference point, not hardcoded in multiple places across
the UI.

### Future considerations
Re-verify this entire section's figures immediately before building any
feature that states a specific penalty amount to a user — penalty structure
has already changed once in 2026 during this research window, and doing so
again before this product ships is entirely plausible.
