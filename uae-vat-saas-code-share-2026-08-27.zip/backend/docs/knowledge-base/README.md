# UAE VAT Knowledge Base — Index

- **Status:** Living reference document (not an ADR — see relationship note below)
- **Created:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Purpose:** the business/domain foundation for every future module (1–5).
  This is *not* application code and *not* a technical design — it's the set
  of UAE VAT facts, rules, and product decisions that Modules 1–5 will be
  built against. Per [ADR-0001 §13.2](../adr/0001-baseline-architecture.md)
  (Documentation First), this document — and the Product Bible it feeds —
  must be updated *before* any module that touches a topic covered here is
  implemented, not after.

## How this relates to ADR-0001

ADR-0001 decided **how** the system is built (architecture, stack, auth,
multi-tenancy, deployment). This knowledge base decides **what the system
needs to know and do** to be correct UAE VAT software. Where a topic here has
a direct architectural consequence already locked in by ADR-0001 (e.g.,
Prisma-only migrations, no client-supplied `tenantId`, pooled multi-tenancy),
this document references it rather than re-deciding it.

## Legend — read this before reading any topic file

Every rule below is tagged so you always know how much weight to put on it:

| Tag | Meaning |
|---|---|
| **[CONFIRMED]** | Stated in UAE Federal Decree-Law No. 8 of 2017, its Executive Regulation (Cabinet Decision No. 52 of 2017, as amended), a Cabinet Decision, or official FTA/Ministry of Finance guidance. Sourced during research; treat as ground truth unless you find a newer official amendment. |
| **[BEST PRACTICE]** | Not a specific legal mandate, but standard practice among UAE VAT-registered businesses, accounting software, and Big-4/FTA-adjacent advisory guidance. Sensible to build, but you *could* legally build differently. |
| **[ASSUMPTION — NEEDS PRODUCT DECISION]** | Not covered by law or established practice — genuinely a call this product has to make. Flagged explicitly so it isn't accidentally decided by whoever writes the code that week. |

Anything not tagged inline is scene-setting/explanation, not a rule claim.

## Research basis and limitations

Facts marked [CONFIRMED] were verified through live web research in July
2026 against the UAE Federal Decree-Law No. 8 of 2017, its Executive
Regulations, recent Cabinet Decisions (notably **Cabinet Decision No. 100 of
2025**, amending Tax Invoice/Credit Note rules and introducing the
e-invoicing mandate; **amendments effective 1 January 2026** to input VAT
recovery, carry-forward, and self-invoicing; and **Cabinet Decision No. 129
of 2025**, effective 14 April 2026, on penalties), plus FTA public
guides/clarifications referenced by professional tax advisory sources. This
is **not a substitute for a licensed UAE tax agent's sign-off** before
launch — VAT law is actively changing in 2026 (see the e-invoicing rollout
below), and some fine details (e.g., the internal structure of a TRN beyond
"15 numeric digits") are not publicly documented by the FTA at all. Anything
time-sensitive is dated so it can be re-verified before Module 2 build starts.

**The single most important current event**: the UAE is mid-rollout of a
mandatory **e-invoicing regime** (5-corner Peppol/DCTCE model, PINT AE
format) — voluntary pilot live since 1 July 2026, mandatory from 1 January
2027 for large businesses. This affects the Tax Invoices, Credit Notes, and
Invoice Numbering topics directly and should shape Module 2's design even
though it's a "future consideration" today, not a Module 0/1 requirement.

## Topic Index

| # | File | Topics covered |
|---|---|---|
| 1 | [Registration & Identity](01-registration-and-identity.md) | VAT Registration, TRN, Business Profile |
| 2 | [VAT Categories & Supplies](02-vat-categories-and-supplies.md) | VAT Categories, Standard Rated, Zero Rated, Exempt Supplies, Out of Scope |
| 3 | [Cross-Border & Reverse Charge](03-cross-border-and-reverse-charge.md) | Imports, Exports, Reverse Charge, Designated Zones |
| 4 | [Input/Output & Recoverability](04-input-output-recoverability.md) | Input VAT, Output VAT, Recoverable VAT, Non-Recoverable VAT |
| 5 | [Invoicing & Documents](05-invoicing-and-documents.md) | Tax Invoices, Simplified Tax Invoices, Credit Notes, Debit Notes, Discounts, Shipping, Adjustments |
| 6 | [Assets & Expenses](06-assets-and-expenses.md) | Assets (incl. Capital Assets Scheme), Expenses (incl. blocked/apportioned input VAT, deemed supplies) |
| 7 | [Returns & Filing](07-returns-and-filing.md) | VAT Returns, Filing Periods, penalty framework |
| 8 | [Numbering, Retention, Currency & Rounding](08-numbering-retention-currency-rounding.md) | Invoice Numbering, Record Retention, Currency Rules, Rounding Rules |

Topics are grouped by domain rather than kept as 30 separate files, so
related rules (e.g., Zero Rated vs. Exempt, or Tax Invoices vs. Simplified
Tax Invoices) stay next to each other for comparison — each file is still
organized as one clearly-headed section per individual topic, so nothing
from the requested list is merged away.

## Maintenance rule

Per ADR-0001 Principle 13.2/13.3: when a future module needs to deviate from
or add nuance to a rule recorded here, this document is updated **before**
that module's implementation starts, and any change that would alter a
`[CONFIRMED]` rule's product implication should be flagged to the project
owner rather than silently reinterpreted.
