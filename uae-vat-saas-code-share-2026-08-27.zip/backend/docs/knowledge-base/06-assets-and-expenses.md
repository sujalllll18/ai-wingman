# 6. Assets & Expenses

Covers: **Assets** (including the Capital Assets Scheme), **Expenses**
(including blocked/apportioned input VAT and deemed supplies).
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).
Cross-references §4.3/§4.4 (Recoverable/Non-Recoverable VAT), which this
section builds on rather than repeats.

---

## 6.1 Assets

### Definition
Business-owned property used over time rather than consumed immediately.
Most asset purchases are treated like any other input-VAT-bearing expense
(§6.2), but **Capital Assets** meeting a specific value/useful-life
threshold are subject to a distinct, multi-year VAT monitoring and
adjustment regime.

### Official UAE FTA business rules
- **[CONFIRMED]** **Capital Asset Scheme** — legal basis: Article 58, VAT
  Executive Regulations. A **Capital Asset** is a single item of expenditure
  of **AED 5,000,000 or more** (excluding VAT), on which VAT is payable,
  with an estimated useful life of **10 years or more for a building** (or
  part of a building) or **5 years or more for other capital assets**.
- **[CONFIRMED]** For a qualifying Capital Asset, the input VAT recovered
  at purchase is not simply locked in — it must be **monitored and adjusted
  annually** over the relevant adjustment period (10 years for buildings, 5
  years for other capital assets), starting from the day the owner first
  uses the asset for business purposes. Each year's adjustment depends on
  the asset's actual taxable-use proportion that year, which can differ
  from the proportion assumed at purchase (e.g., if a building's tenant mix
  shifts between taxable and exempt use over time).
- **[CONFIRMED]** A **Capital Asset Register** must be maintained, recording
  original input tax incurred and every subsequent adjustment with its
  calculation basis. Records relating to capital assets must be kept for a
  **minimum of 10 years** (§8.2 covers this in full, alongside the separate
  15-year real-estate-specific retention rule).
- **[CONFIRMED]** Ordinary (non-capital) assets — most equipment, vehicles
  (subject to §4.4's blocked-vehicle rules), furniture, computers — are
  simply expensed for VAT purposes: input VAT is recovered once, upfront,
  based on the asset's use at the time of purchase, with no multi-year
  monitoring obligation.

### Real-world example
Al Noor Trading LLC buys a AED 8,000,000 warehouse (excl. VAT), fully used
for its taxable trading business at purchase — the AED 400,000 input VAT is
recovered in full initially, but Al Noor must monitor and, if the
warehouse's use changes (e.g., part of it is later leased out as exempt
residential space), adjust the recovered amount annually for 10 years. A
AED 15,000 forklift purchase, by contrast, is simply expensed — input VAT
recovered once, no ongoing monitoring.

### Product implications
- The AED 5,000,000 threshold means the Capital Assets Scheme is very
  unlikely to be relevant to the typical small-to-mid UAE SME this product
  currently targets (per the Module 0 README's framing) — but for larger
  Tenants (property owners, larger trading/manufacturing businesses), it's
  a real and materially complex obligation.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Given the likely low frequency
  but high complexity of this feature, it's worth deciding explicitly
  whether the Capital Assets Scheme is in scope for an early Module 3
  release, or deliberately deferred as a "Premium tier, later module"
  capability — building it well requires real design time (multi-year
  monitoring, an asset register, annual re-calculation), and building it
  half-heartedly risks getting a genuinely complex FTA obligation wrong for
  exactly the larger, higher-stakes Tenants who'd need it.

### Database implications
If in scope: a `CapitalAsset` entity distinct from ordinary expense records
— purchase value, useful-life category (building/other), adjustment-period
length (10 or 5 years derived from category), original input VAT, and a
related `CapitalAssetAdjustment` per-year history (the "register" from the
FTA rule above) recording each year's taxable-use proportion and resulting
adjustment amount.

### API implications
If built, this is a strong candidate for its own dedicated service (ADR-0001
§13.1) given the genuinely complex, date-driven, recurring calculation
involved — not something to embed inline in a general Purchases controller.

### UI implications
If built: a distinct "Capital Assets Register" view (Module 3+), separate
from the general expense list, given its multi-year nature — a Tenant/
accountant needs to see "this asset is 3 years into a 10-year adjustment
period" as a standing record, not a one-time transaction.

### Validation rules
**[BEST PRACTICE]** A purchase should be flagged as a potential Capital
Asset (prompting the user to confirm useful-life category) whenever its
value meets or exceeds AED 5,000,000 — the threshold check itself is simple
and cheap to build even before the full multi-year monitoring feature
exists, and prevents a large qualifying purchase from being silently
misclassified as an ordinary expense.

### Edge cases
Partial business use of a capital asset from day one (e.g., a mixed-use
building, partly taxable retail and partly exempt residential from the
start) — the *initial* recovery, not just subsequent years' adjustments,
must reflect the actual use split; this is a case where the general
apportionment rules (§4.4/§6.2) and the Capital Asset Scheme's own
adjustment mechanism interact and should be designed together, not treated
as two unrelated features.

### Future considerations
Given the AED 5,000,000 threshold, this is realistically a Premium-tier,
later-module feature for larger Tenants — flagged now so the schema/roadmap
doesn't accidentally preclude it later, without necessarily building it in
an early release.

---

## 6.2 Expenses

### Definition
Business costs incurred in the ordinary course of operations, generating
input VAT that is recoverable in full, in part (apportioned), or not at all
(blocked), per the rules already detailed in §4.2–§4.4. This section covers
the *expense-specific* mechanics not already covered there: partial
exemption apportionment method, and deemed supplies arising from
free-of-charge business outputs.

### Official UAE FTA business rules
- **[CONFIRMED] Partial exemption / apportionment**: where a business makes
  both taxable and exempt supplies (§2.4), input VAT that cannot be
  **directly** attributed to either category (i.e., general overhead —
  rent, utilities, admin costs benefiting the whole business) must be
  apportioned using a recovery method, generally based on the ratio of
  taxable supplies to total supplies, with special methods available in
  specific circumstances. Blocked-category rules (§4.4) are applied
  *before* apportionment, not blended into it.
- **[CONFIRMED] Deemed supplies** (Article 12, VAT Decree-Law, with
  exceptions under Article 5 of the Executive Regulations): goods or
  services given away free of charge, or business assets put to
  non-business use, can trigger a **deemed supply** — meaning the business
  must account for output VAT as if it had sold the item, even though no
  payment was received — **if** input VAT was originally recovered on it.
  - **Exception 1**: samples/gifts are **not** a deemed supply if their
    value does not exceed **AED 500 per recipient within a 12-month
    period**.
  - **Exception 2**: if the **total output tax** that would be payable on
    all deemed supplies to a person over a 12-month period is **less than
    AED 2,000**, no deemed supply arises.
- **[CONFIRMED]** Employee-related expenses sit at the intersection of
  several rules covered elsewhere: genuine business-purpose employee
  entertainment is generally **not** blocked (§4.4), while non-employee
  entertainment specifically is blocked regardless of amount.

### Real-world example
Al Noor gives a AED 300 corporate gift to each of 40 different clients
during the year (none exceeding AED 500 per recipient) — no deemed supply
arises on any of them, even though Al Noor recovered input VAT on the gifts
when purchased. If Al Noor instead gave one client AED 5,000 in gifts across
the year, that would exceed the AED 500 threshold for that recipient, and
(unless the total output tax across all such excess gifts stays under the
AED 2,000 aggregate threshold) a deemed supply would need to be recognized.

### Product implications
- **Apportionment** is only relevant to Tenants with mixed taxable/exempt
  activity (§2.4) — a purely taxable Tenant (the likely majority of the
  product's early SME customer base) never needs this calculation. The
  product should apply it conditionally, not force every Tenant through
  apportionment complexity they don't need.
- **Deemed supplies** are a genuinely easy-to-miss compliance gap for gift-
  and marketing-heavy businesses — worth building explicit gift/sample
  tracking (per-recipient, rolling 12-month value) as a real feature, not
  an afterthought, given how specific and stateful the AED 500/AED 2,000
  thresholds are (they require tracking cumulative value per recipient over
  a rolling window, which is not a simple point-in-time check).

### Database implications
- Apportionment: needs a period-level ratio calculation (taxable supplies ÷
  total supplies) applied to a Tenant's "general overhead" input VAT pool —
  a Module 3 VAT-engine concern, not a per-transaction one.
- Deemed supplies: needs per-recipient, rolling-12-month cumulative
  gift/sample value tracking — likely a `Gift`/`FreeSupply` record type
  linked to a recipient (Customer or a more general "person" record, since
  gift recipients aren't always existing Customers) with a query capable of
  summing value per recipient over a trailing 365-day window.

### API implications
Both apportionment and deemed-supply calculations belong in the same
VAT-calculation service layer discussed throughout this document (ADR-0001
§13.1) — genuinely business-logic-heavy, stateful-over-time calculations
that do not belong in a controller.

### UI implications
- A future "Gifts & Samples" tracking view, showing per-recipient running
  totals against the AED 500 threshold, would be a concrete, demonstrable
  differentiator for SME users who currently track this (if at all) in a
  spreadsheet.
- Apportionment results (for Tenants who need it) should be surfaced
  transparently in the VAT Position view — showing the ratio used and how
  it was calculated, not just a final recovered-VAT number, since this is
  exactly the kind of figure an FTA audit will ask a business to justify.

### Validation rules
**[BEST PRACTICE]** Gift/sample entry should warn (not block) when a
recipient's rolling 12-month total is approaching or has crossed the AED
500 threshold — informational, since the actual deemed-supply obligation
also depends on the AED 2,000 aggregate exception, which the system should
compute automatically rather than expect the user to track manually.

### Edge cases
- A recipient who is *both* a paying Customer and an occasional gift
  recipient — the AED 500 threshold applies to free-of-charge value only,
  not their total commercial relationship value; must not conflate the two
  in tracking.
- Employee gifts vs. client gifts may have different treatment nuances
  (employee benefits have their own separate considerations under UAE VAT,
  not deeply covered by this research pass) — flagged as needing further
  research specifically if the product ever builds employee-expense
  features.

### Future considerations
If Module 5's OCR capability eventually auto-classifies purchase receipts,
the blocked-category (§4.4) and deemed-supply detection logic built here
becomes directly reusable for auto-flagging — another case (alongside §4.4)
where building this as clean, standalone business rules now pays off later.
