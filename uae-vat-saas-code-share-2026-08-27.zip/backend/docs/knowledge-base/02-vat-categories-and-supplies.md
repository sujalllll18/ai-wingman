# 2. VAT Categories & Supplies

Covers: **VAT Categories** (overview), **Standard Rated**, **Zero Rated**, **Exempt Supplies**, **Out of Scope**.
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

---

## 2.1 VAT Categories (overview)

### Definition
Every supply of goods or services made by a UAE VAT-registered business
falls into exactly one of four VAT treatment categories, each with different
consequences for output tax charged and input tax recovery. This section
frames the four categories together; each is detailed in its own section
below (2.2–2.5).

### Official UAE FTA business rules
- **[CONFIRMED]** The four categories, defined across Federal Decree-Law
  No. 8 of 2017: **Standard Rated** (5%, Article 3/61), **Zero Rated** (0%,
  Article 45), **Exempt** (Article 46), and **Out of Scope** (transactions
  falling outside UAE VAT law entirely — not a single article, but the
  residual category for anything not a taxable supply under UAE VAT law at
  all).
- **[CONFIRMED]** The current standard VAT rate is **5%** — unchanged since
  VAT's introduction on 1 January 2018.
- **[CONFIRMED]** Zero Rated and Standard Rated are both "taxable supplies"
  — the business stays fully in the VAT system, charges VAT (at 0% or 5%),
  and recovers input VAT on related costs. Exempt supplies are *not*
  taxable supplies — no output VAT is charged, and input VAT on directly
  related costs generally cannot be recovered (§4.4). Out of Scope
  transactions sit outside the VAT system entirely and don't factor into
  either output or input VAT calculations at all.

### Real-world example
Al Noor Trading LLC, a general trading company, sells goods locally
(Standard Rated, 5%), exports goods to Saudi Arabia (Zero Rated, 0%, full
input recovery), rents out a residential unit it owns (Exempt — no VAT
charged, related input VAT blocked), and sells its old delivery van as part
of selling the whole business as a going concern (Out of Scope — not a
supply at all under VAT law).

### Product implications
- Every line item on every invoice, and every purchase entry, needs a VAT
  category classification — this is the single most foundational data
  concept the whole Invoicing/VAT-Position build (Modules 2/3) depends on.
  Getting this modeled generically and correctly now avoids a rebuild later.
- The category directly drives: whether VAT is charged, at what rate,
  whether it counts toward the VAT-registration threshold (§1.1 — Exempt
  and Out of Scope supplies are treated differently in the threshold
  calculation than Standard/Zero Rated), and whether related input VAT is
  recoverable.

### Database implications
- A `VatCategory` concept (lookup/enum: `STANDARD_RATED | ZERO_RATED |
  EXEMPT | OUT_OF_SCOPE`) is needed at the line-item level (not just the
  invoice level — a single invoice can legitimately mix categories, e.g., a
  logistics company invoicing a mix of local and international transport
  legs).
- Rate applied should be stored as a *value* (e.g., `5.00` or `0.00`) on
  each line, not derived purely from the category at render time — because
  the rate that applied *on the date of supply* must be preserved even if
  the standard rate ever changes in the future (it hasn't since 2018, but
  the schema shouldn't assume it never will).
- Consistent with `VatRateHistory` already in the Module 0 schema (tracks
  rate changes over time) — the category concept is a natural sibling
  structure, not a replacement.

### API implications
- Any future line-item creation endpoint (Invoice, Purchase, Credit Note)
  needs to accept and validate a VAT category per line, and compute/store
  the resulting tax amount server-side — never trust a client-submitted tax
  amount without recomputing it, since this is exactly the kind of value an
  incorrect frontend calculation (or a malicious client) could get wrong.

### UI implications
- Line-item entry UI (Module 2) needs a clear, low-friction way to pick a
  VAT category per line — most transactions will default to Standard Rated,
  so the UI should optimize for that common case while making the other
  three categories easy to select when needed, not buried behind extra
  clicks.
- Category should be visually distinguishable on rendered invoices — an FTA
  auditor or a customer's AP team should be able to see at a glance which
  lines carried VAT and which didn't, and why.

### Validation rules
- **[BEST PRACTICE]** A Standard Rated line must have a rate matching the
  currently-effective standard rate (5%, per the Tenant's `VatRateHistory`)
  — the UI/API should not allow arbitrary rate entry that silently deviates
  from FTA-mandated rates.
- **[BEST PRACTICE]** A Zero Rated or Exempt line should require a
  reason/sub-category to be recorded (see 2.3/2.4) — "zero-rated because...
  [export / education / healthcare / etc.]" — both for the business's own
  audit trail and because the VAT return (§7.1) reports these categories
  separately.

### Edge cases
- A single supply legitimately spans two categories is not possible (one
  supply = one category), but a single *invoice* commonly contains multiple
  line items with different categories — the system must total these
  correctly per category, not just sum a single "invoice total" blindly.
- Category can be genuinely ambiguous in real transactions (e.g., is a
  specific healthcare service "basic" (zero-rated) or a cosmetic procedure
  (standard-rated)?) — the product should not attempt to auto-classify this
  from a product/service description; it should let the business (who knows
  their own supply) choose, with sensible category defaults per
  Customer/Material where that helps (see §6.1).

### Future considerations
- If UAE VAT rate ever changes (it has not since 2018, but GCC peers have
  discussed rate changes), the category/rate-value separation above means
  only new transactions need the new rate — historical data stays correct
  automatically.
- The e-invoicing PINT AE format (§5.1) will require category/rate data at
  a specific structured level per line — designing the category model
  correctly now pays off directly when Module 2 needs to emit that format.

---

## 2.2 Standard Rated

### Definition
The default VAT treatment: a taxable supply of goods or services made in the
UAE, charged at the standard rate, currently 5%.

### Official UAE FTA business rules
- **[CONFIRMED]** 5% is the default rate for any taxable supply that isn't
  specifically zero-rated (§2.3) or exempt (§2.4) under the VAT law.
  Most domestic B2B and B2C sales of goods and services fall here.
- **[CONFIRMED]** Full input VAT recovery applies on costs related to
  making standard-rated supplies (subject to the general blocked-input
  rules in §4.4, which apply regardless of the *output* category).

### Real-world example
Al Noor Trading LLC sells construction materials to a Dubai-based
contractor. The AED 50,000 invoice carries AED 2,500 (5%) VAT — standard
rated, no special treatment needed.

### Product implications
This is the default case the product should optimize for — most Module 2
invoice lines, most Module 3 purchase entries, will be Standard Rated.
Design the data model and UI around this being the common path, with the
other categories as clearly-supported but secondary flows.

### Database implications
No special schema beyond the general `VatCategory`/rate model in §2.1 — this
is the "no special case" category by definition.

### API implications
Default category on line-item creation, to reduce clicks for the common
case — but the API must still require an explicit category value rather
than silently assuming Standard Rated, so the choice is always deliberate
and auditable, not a silent default that could hide a misclassification.

### UI implications
Standard Rated should be the pre-selected default in any VAT category
picker, with the rate auto-populated (not manually typed) from the Tenant's
current effective rate.

### Validation rules
Rate must equal the current standard rate per the Tenant's `VatRateHistory`
at the date of supply — not an arbitrary number.

### Edge cases
None specific to this category beyond the general ones in §2.1 — by
definition, Standard Rated is "the case with no special rule."

### Future considerations
None beyond the general rate-change resilience noted in §2.1.

---

## 2.3 Zero Rated

### Definition
A taxable supply charged VAT at **0%** — legally still a taxable supply (the
business stays in the VAT system and fully recovers related input VAT), but
no VAT is actually collected from the customer.

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 45, Federal Decree-Law No. 8 of 2017.
  The FTA/law recognizes roughly 14 specific zero-rated categories,
  including (non-exhaustively): exports of goods and services outside the
  UAE (§3.2), international transport of goods and passengers, certain
  qualifying means of transport (trains, trams, vessels, airplanes meeting
  specific criteria), the **first supply** of residential buildings (sale
  or lease within a defined period — commonly cited as within 3 years of
  completion), aircraft/vessels used for rescue and assistance, certain
  investment-grade precious metals (gold/silver/platinum meeting a purity
  threshold), and specific education and healthcare services (see below).
- **[CONFIRMED]** Education: services provided by a "recognized" UAE
  educational institution (nursery through higher education) are zero-rated,
  including tuition and closely related goods (e.g., course-required
  textbooks, uniforms supplied by the institution itself) — note this is
  narrower than "anything an education-sector business sells" (e.g.,
  unrelated merchandise or a non-recognized private tutoring service may
  not qualify).
- **[CONFIRMED]** Healthcare: "preventive and basic" healthcare services and
  closely related goods/services are zero-rated — again narrower than "all
  healthcare"; elective/cosmetic procedures are typically standard-rated,
  not zero-rated.
- **[CONFIRMED]** Full input VAT recovery applies to costs related to making
  zero-rated supplies — this is the key practical difference from Exempt
  (§2.4).

### Real-world example
Al Noor Trading LLC exports AED 100,000 of goods to a customer in Saudi
Arabia (subject to export documentation rules, §3.2) — the invoice shows 0%
VAT, AED 0 charged, but Al Noor still fully recovers the VAT it paid on the
materials/freight/overhead that went into fulfilling that export.

### Product implications
- Zero-rated status is *conditional* in several categories (export
  documentation, "first supply" timing windows for real estate, "recognized
  institution" status for education) — the product should not treat
  "Zero Rated" as a single flat, unconditional checkbox; it needs a
  sub-reason so the business (and any future audit) can show *why* a supply
  qualified.
- This category directly interacts with Export documentation requirements
  (§3.2) — a zero-rated export claim without adequate proof of export can be
  reclassified as standard-rated by the FTA on audit, with penalties.

### Database implications
- A `zeroRatedReason` (or similarly named) field/enum alongside the VAT
  category on a line item — at minimum distinguishing export vs. the other
  statutory categories, since export specifically needs supporting
  documentation linkage (§3.2) that the other zero-rated categories don't.
- The VAT return (§7.1) reports zero-rated supplies as their own box,
  separate from standard-rated and exempt — so category-level aggregation
  must be reliable, not something computed ad hoc at filing time.

### API implications
Line-item creation for a zero-rated line should require the sub-reason to
be specified, not just the bare category — enforced server-side, not merely
suggested in the UI, given the audit exposure of misclassification.

### UI implications
When a user selects "Zero Rated," the UI should prompt for *why* (a
constrained list: export / international transport / education / healthcare
/ first supply of residential property / precious metals / other qualifying
category) rather than accepting a bare rate override — this both guides
correct classification and creates the audit trail FTA guidance expects
businesses to maintain.

### Validation rules
- **[BEST PRACTICE]** Rate must be exactly 0% — never a partial rate.
- **[BEST PRACTICE]** A zero-rated line claiming "export" should be linkable
  to export/shipping evidence once that data exists (Module 2/3) — not
  enforced at Module 0/1 stage, but the data model should not preclude it
  later.

### Edge cases
- The "first supply" residential real estate zero-rating is time-bound
  (within a defined window of completion) — a supply of the *same* building
  outside that window becomes Exempt (§2.4), not Zero Rated. This is a
  genuinely easy real-world misclassification and worth explicit UI
  guardrails once a real-estate-adjacent Tenant type is in scope.
- Education/healthcare zero-rating depends on the *provider's* recognized
  status and the *specific service's* nature (basic vs. elective) — not
  something the software can safely auto-determine from a free-text
  description; must remain a user judgment call, supported (not automated)
  by the product.

### Future considerations
- If the product ever targets real-estate or healthcare/education verticals
  specifically, the zero-rated sub-reason list and its supporting-evidence
  requirements deserve deeper, vertical-specific product work beyond this
  general-purpose baseline.

---

## 2.4 Exempt Supplies

### Definition
A supply of goods or services on which **no VAT is charged**, and which is
**not** a taxable supply at all (distinct from Zero Rated, which *is* a
taxable supply at a 0% rate). Input VAT directly related to making exempt
supplies is generally **not recoverable** (§4.4).

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 46, Federal Decree-Law No. 8 of 2017.
  Four categories: **financial services** (specifically those *not* charged
  via an explicit fee/commission/discount — margin-based financial services
  like most conventional lending interest; fee-based financial services
  such as advisory fees or explicit banking charges are standard-rated, not
  exempt), **supply of residential buildings** (sale or lease, *other than*
  the zero-rated first supply — see §2.3's edge case), **supply of bare
  land** (land with no completed buildings and no development/servicing —
  once utilities, access roads, or groundwork begin, it's no longer "bare"
  and becomes taxable), and **local passenger transport** (land, water, or
  air transport wholly within the UAE, e.g., metro, local buses, licensed
  taxis — domestic flights are commonly included under this exemption too).
- **[CONFIRMED]** Input VAT directly attributable to exempt supplies is
  blocked from recovery; where a business makes both taxable and exempt
  supplies, input VAT apportionment applies (§4.4, §6.2 partial exemption).

### Real-world example
A property owner leases a residential apartment for AED 8,000/month — no
VAT is charged on the rent (Exempt), and VAT the landlord paid on
maintenance costs for that specific unit is generally not recoverable. Contrast
with a *commercial* office lease, which is Standard Rated.

### Product implications
- Exempt and Zero Rated are the two categories most commonly confused by
  end users (both show "0% charged" on an invoice) — the product must make
  the distinction obvious in the UI and correct in the data model, since
  they have opposite input-recovery consequences and are reported in
  different VAT return boxes.
- A Tenant that makes *any* exempt supplies alongside taxable ones needs
  input VAT apportionment logic eventually (§4.4/§6.2) — a materially more
  complex calculation than a Tenant that is 100% taxable. Worth knowing
  which Tenant profile you're building for before Module 3's VAT engine is
  designed.

### Database implications
- Same line-item category field as §2.1/§2.3, with `EXEMPT` as a distinct
  value from `ZERO_RATED` — never conflate the two, even though both show
  "AED 0 VAT" on the rendered document.
- Supports the same sub-reason pattern as zero-rated (financial services /
  residential real estate / bare land / local passenger transport), useful
  for the same audit-trail and VAT-return-box reasons.

### API implications
Same as §2.3 — sub-reason required server-side on exempt line creation.

### UI implications
- The invoice/purchase line UI should visually and textually distinguish
  "Zero Rated (0%)" from "Exempt" — not just two dropdown options with
  similar-looking effects, since users who don't know VAT law well (many
  UAE SME owners) will otherwise treat them as interchangeable.
- A Tenant whose business is entirely/mostly exempt (e.g., a residential
  landlord) may not even need to register for VAT at all if they have no
  other taxable activity — worth surfacing as guidance in a future
  Business Profile/onboarding flow (§1.3), not silently assumed.

### Validation rules
Same 0%-rate validation as Zero Rated, but tagged as the distinct `EXEMPT`
category, never interchangeable with `ZERO_RATED` in reporting logic.

### Edge cases
- Mixed-use real estate (part residential/exempt, part commercial/taxable)
  — apportionment needed at the property or even unit level; a real
  complexity for any Tenant in real estate, deferred design work.
- A financial service that sometimes charges an explicit fee and sometimes
  doesn't (e.g., a bank's account maintenance fee vs. interest earned) can
  have *both* exempt and standard-rated components within the same
  commercial relationship — must be split at the line/transaction level,
  never assumed uniform per customer or per business.

### Future considerations
Input VAT apportionment/partial exemption calculation (§4.4/§6.2) is the
real complexity this category ultimately drives — flagged now, designed
later, likely in Module 3.

---

## 2.5 Out of Scope

### Definition
A transaction that falls **entirely outside** UAE VAT law — not a taxable
supply, not zero-rated, not exempt, simply not something VAT law addresses
at all. Distinct from Exempt: an exempt supply *is* within the scope of VAT
law but attracts no tax; an out-of-scope transaction never enters the VAT
system's supply/tax-point framework in the first place.

### Official UAE FTA business rules
- **[CONFIRMED]** **Transfer of a business as a going concern (TOGC)**: when
  a whole business (or an independent part of one) is sold/transferred to
  another VAT-registered person who continues the same kind of business,
  the transfer is treated as *neither a supply of goods nor a supply of
  services* — genuinely out of scope, not zero-rated. Specific conditions
  apply (recipient must be/become VAT-registered, must intend to continue
  the same business), consistent with GCC-wide TOGC guidance.
- **[CONFIRMED]** Transactions where the **place of supply is outside the
  UAE** are out of scope of *UAE* VAT (they may be subject to another
  country's tax regime instead) — this is different from an export, which
  is zero-rated precisely *because* UAE VAT law still applies to it, just at
  0%. Place-of-supply-outside-UAE means UAE VAT law simply has no
  jurisdiction over the transaction.
- **[CONFIRMED]** Supplies made between members of the same **Tax Group**
  (§1.1) are generally disregarded for VAT purposes — effectively out of
  scope from the perspective of VAT accounting, since the group files one
  consolidated return.
- Genuinely private/non-business transactions with no economic nexus to a
  taxable person's business activity also fall outside VAT law's scope by
  definition, though this rarely intersects with what a VAT SaaS product
  needs to track (the product only sees a Tenant's *business* transactions).

### Real-world example
Al Noor Trading LLC sells its entire trading division — inventory,
contracts, staff, goodwill — to another VAT-registered trading company that
will continue operating it as-is. No VAT is charged on the sale price at
all; it's structurally outside VAT law (TOGC), not a 0%-rated supply of
goods.

### Product implications
- Out of Scope is the category most likely to be *underbuilt* in a first
  version of Invoicing/Purchases, because it's rare in day-to-day SME
  trading — but it must still exist as a first-class option, not a
  workaround (e.g., "just don't create an invoice for it"), because a TOGC
  or intra-group transaction may still need to be *recorded* for the
  business's own books even though no VAT applies.
- This category should **not** appear in the VAT-collected/VAT-recoverable
  totals on the VAT return at all (§7.1) — unlike Zero Rated and Exempt,
  which each have their own reporting box, Out of Scope transactions
  generally don't get reported to the FTA as part of the VAT return's
  supply figures.

### Database implications
Same line-item category field, with `OUT_OF_SCOPE` as a fourth distinct
value — important that reporting/aggregation logic (Module 3) explicitly
excludes this category from VAT return box totals rather than defaulting it
to zero-and-included (which would be wrong — it shouldn't be counted at all,
not counted-as-zero).

### API implications
No special endpoint needs beyond the shared line-item category API — but
any VAT-return-generation logic (Module 3) must explicitly filter this
category out, which is a validation/business-logic detail worth flagging
now so it isn't missed when that engine is built.

### UI implications
Available as a category option but reasonably de-prioritized in the default
UI ordering (Standard Rated first, then Zero Rated/Exempt, Out of Scope
last) given how rarely SME users will need it day-to-day.

### Validation rules
**[BEST PRACTICE]** An Out of Scope line should have no VAT amount at all
(not even a stored zero that gets added into "zero-rated total" reporting
by mistake) — the distinction from Exempt/Zero Rated in the reporting layer
matters more than in the UI.

### Edge cases
- TOGC has specific qualifying conditions (recipient must be or become
  registered, must continue the same business) — a transfer that fails
  those conditions is *not* automatically out of scope and may need to be
  treated as a normal taxable supply of assets instead. The product
  shouldn't auto-classify a "business sale" as TOGC without the user
  confirming the qualifying conditions are met.
- Place-of-supply-outside-UAE determination itself has its own detailed
  rules (generally: for services, where the recipient is established) that
  interact with Export rules (§3.2) — getting Export vs. Out-of-Scope right
  requires knowing this distinction, not just "was money received from
  abroad."

### Future considerations
Genuinely low-priority for Module 2/3's first version given SME trading
patterns, but should not be designed out of the data model — a category
that's rare in volume but legally binary (get it wrong and it's a
compliance defect) is exactly the kind of thing worth including from day
one rather than retrofitting.
