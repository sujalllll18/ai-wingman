# 3. Cross-Border & Reverse Charge

Covers: **Imports**, **Exports**, **Reverse Charge**, and **Designated
Zones** (added because it's inseparable from correctly modeling imports,
exports, and reverse charge — a transaction's Designated Zone status changes
its VAT treatment in all three).
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

---

## 3.1 Imports

### Definition
Goods or services brought into the UAE from outside the UAE (or from an FTA
Designated Zone into the mainland, see §3.4) by a UAE business, generally
subject to VAT at the standard rate, collected either at the point of
customs clearance or self-accounted via the reverse charge mechanism (§3.3).

### Official UAE FTA business rules
- **[CONFIRMED]** VAT applies at the standard rate (5%) on imported goods,
  calculated on the **CIF value** (Cost, Insurance, Freight) *plus* any
  customs duties — i.e., VAT is charged on the full landed cost, not just
  the goods' price.
- **[CONFIRMED]** Payment mechanism differs by registration status:
  - A **VAT-registered** importer can self-account for import VAT via
    reverse charge (declaring it as both output tax and input tax in the
    same return, net-zero cash impact) instead of paying cash at customs and
    reclaiming it later — a genuine cash-flow benefit.
  - A **non-registered** importer or private individual must pay VAT in
    cash directly to customs at the time of clearance, alongside any
    customs duty.
- **[CONFIRMED]** Import of *services* (not goods) from outside the UAE is
  handled through the reverse charge mechanism (§3.3), not a customs
  process, since there's no physical border-crossing checkpoint for
  services.
- **[CONFIRMED]** As of amendments effective 1 January 2026, the previous
  requirement for a reverse-charge importer to issue a formal tax invoice
  to *itself* has been **removed** — the reverse charge accounting
  obligation itself is unchanged, only the self-invoicing paperwork
  requirement was dropped.

### Real-world example
Al Noor Trading LLC (VAT-registered) imports AED 200,000 of materials from
outside the GCC. At customs, it self-accounts: AED 10,000 (5%) is declared
as output tax *and* input tax in the same VAT return — no cash changes
hands at the border, and the net VAT effect is zero (assuming full
recoverability).

### Product implications
- Import VAT is fundamentally a **Purchases** concept (Module 3), not an
  Invoicing (Module 2) concept — the Tenant is the *recipient*, not the
  issuer, of the underlying commercial document (a supplier's foreign
  invoice/bill of lading), but the Tenant must still generate its own
  VAT accounting entries from it.
- The self-accounting mechanic (output tax = input tax on the same
  transaction) means an import purchase entry needs to generate **two**
  VAT effects internally, not one — a materially different calculation
  shape from a normal domestic purchase (input VAT only).

### Database implications
- A Purchase/Expense record needs an `isImport` (or a more general
  `reverseChargeApplicable`) flag distinct from its VAT category, since
  imports interact with §3.3's reverse charge mechanics regardless of the
  underlying goods' VAT category.
- CIF value + customs duty need to be captured as inputs to the VAT
  calculation, not just a single "amount" field — the taxable value for
  import VAT is not simply the invoice value from the foreign supplier.

### API implications
Purchase/expense-creation endpoints (Module 3) need an explicit way to mark
a transaction as an import and capture the customs-relevant value
components, with server-side computation of the resulting self-accounted
VAT — not a client-submitted VAT figure.

### UI implications
Purchase entry UI should offer an "Import" toggle that reveals CIF/customs
duty fields and clearly explains (in-product) that no VAT will be
cash-collected — this is a genuinely confusing mechanic for SME owners
unfamiliar with reverse charge, so the UI carries real explanatory
responsibility here, not just data entry.

### Validation rules
**[BEST PRACTICE]** An import transaction should require a non-zero CIF
value before it can be saved as "Import" category — an import with no
declared customs value is very likely a data-entry error.

### Edge cases
- Goods moving from an FTA Designated Zone into the mainland are treated as
  an import for VAT purposes even though no international border was
  crossed (§3.4) — a Tenant sourcing from, e.g., JAFZA needs this treated
  identically to a genuine cross-border import.
- Partial recoverability: if the imported goods/services relate to exempt
  or non-business activity, the "self-accounting nets to zero" simplification
  breaks down — the input side is only recoverable to the extent the
  general recovery rules (§4.3/§4.4) allow, so output and input legs are not
  automatically guaranteed to cancel out for every Tenant.

### Future considerations
Integration with customs data (if ever pursued) would reduce manual CIF
entry — a Module 3+ consideration, not urgent now.

---

## 3.2 Exports

### Definition
Goods or services supplied by a UAE business to a customer outside the UAE
(or, for goods, physically leaving the UAE). Exports are **zero-rated**
(§2.3), not out of scope — the supplier stays fully in the VAT system and
recovers all related input VAT, but charges the customer 0%.

### Official UAE FTA business rules
- **[CONFIRMED]** Export of goods and export of services are both
  zero-rated under Article 45.
- **[CONFIRMED]** Zero-rating an export is **conditional on adequate
  documentary evidence** of export — the search research consistently
  flagged that documentation requirements for zero-rating exports have
  tightened; typical evidence includes customs export declarations,
  shipping/airway bills, and proof the goods actually left the UAE (or, for
  services, evidence the recipient is located and consuming the service
  outside the UAE). Without this evidence, the FTA can reclassify the
  supply as standard-rated on audit.
- **[CONFIRMED]** International transport of goods and passengers is itself
  a distinct zero-rated category (§2.3), and a *domestic leg* of an
  international transport journey can also be zero-rated, but only when
  supplied by the same taxable person providing the international leg
  (Article 33 of the Executive Regulations) — a domestic-only shipment by a
  different carrier does not inherit this treatment.

### Real-world example
Al Noor Trading LLC exports AED 100,000 of goods to a customer in Saudi
Arabia, retaining the customs export declaration and shipping documents as
proof. The invoice is zero-rated; without the retained proof, an FTA audit
could reclassify the transaction as standard-rated and assess AED 5,000 in
under-collected VAT plus penalties.

### Product implications
- Export zero-rating is the clearest case in this entire knowledge base
  where the **product needs to support evidence-linking**, not just a
  category flag — an invoice claiming zero-rated export status should be
  able to reference supporting documents (even if just an attached file in
  early modules, before any dedicated OCR/document module exists).
- This is a natural link point to Module 5 (OCR/document handling) later,
  but shouldn't wait for Module 5 to exist in some minimal form — even a
  simple file-attachment capability on an invoice in Module 2 would close a
  real compliance gap cheaply.

### Database implications
An Invoice (or its zero-rated line items) should support an optional
evidence/attachment reference — doesn't need to be a rich document-management
system in Module 2, but the schema shouldn't preclude attaching proof-of-export
records to the transaction that claims the zero rating.

### API implications
Future invoice-creation endpoints should allow (not require, since evidence
may arrive after invoicing, e.g., once goods actually ship) linking
supporting documents to a zero-rated export line.

### UI implications
When a user marks an invoice line as "Zero Rated — Export," the UI should
prompt for or allow attaching proof of export, and should visually flag
export lines with *no* attached evidence as an audit-risk item — a
lightweight nudge, not a hard block, since evidence often arrives after the
invoice is raised.

### Validation rules
**[BEST PRACTICE]** No hard validation requiring evidence at invoice-creation
time (since real-world timing doesn't always allow it), but the system
should be able to report which zero-rated export invoices are missing
supporting evidence, as an operational/audit-readiness view.

### Edge cases
- Export of services is harder to "prove" than export of goods (no physical
  shipment) — place-of-supply rules (recipient's location) do most of the
  legal work here, and evidence tends to be contractual/billing-address-based
  rather than a shipping document. The product should not assume all export
  evidence looks like a shipping bill.
- A sale initially invoiced as a domestic (standard-rated) supply that later
  turns out to be an export (or vice versa) needs correction via a Credit
  Note (§5.3), not a silent edit to the original invoice — invoices, once
  issued, are not mutable financial records.

### Future considerations
Deeper Module 5 (OCR) integration could eventually auto-extract and link
shipping-document data to export invoices — long-term, not near-term.

---

## 3.3 Reverse Charge

### Definition
A VAT mechanism that shifts the obligation to account for VAT from the
supplier to the recipient. Instead of a foreign (or Designated Zone) supplier
charging UAE VAT, the UAE-registered recipient self-accounts for VAT on
their own VAT return — declaring it as both output tax (payable) and input
tax (recoverable, subject to the normal recovery rules).

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 48, Federal Decree-Law No. 8 of 2017.
  Applies principally to: imports of goods/services by a UAE-registered
  recipient from outside the UAE (§3.1), purchases of goods from an FTA
  Designated Zone moving into the mainland (§3.4), and certain specific
  domestic supplies the law separately designates for reverse charge (e.g.,
  specific transactions in gold/diamonds between registrants, per separate
  Cabinet Decisions not detailed in this research pass).
- **[CONFIRMED]** As of amendments effective 1 January 2026, the recipient
  no longer needs to issue a formal self-billed tax invoice for reverse
  charge transactions — the underlying obligation to self-account for the
  VAT (output tax = input tax entries on the return) is unchanged.
- **[CONFIRMED]** For a fully taxable business (no exempt supplies, full
  recovery rights), reverse charge is cash-flow-neutral: the self-declared
  output tax and input tax offset exactly. For a partially-exempt business,
  they do not fully offset (§2.4/§4.4), and reverse charge becomes a genuine
  net cost on the non-recoverable portion.

### Real-world example
Al Noor Trading LLC pays a UK-based marketing consultancy AED 20,000 for
services with no UAE VAT charged by the supplier (correctly — the UK firm
isn't UAE VAT-registered). Al Noor self-accounts: declares AED 1,000 (5%)
as output tax and, since the expense is fully business-related and Al Noor
makes only taxable supplies, the same AED 1,000 as recoverable input tax —
net VAT effect: zero cash paid, but both figures must still appear
correctly on the VAT return.

### Product implications
- Reverse charge needs to be modeled as a **transaction property**, not a
  separate document type — it's a purchase/import that happens to require
  dual VAT-return reporting, not a fundamentally different kind of record.
- This is the mechanic most likely to be **built wrong** if the team treats
  "input VAT" and "output VAT" as simple opposite-signed fields on
  different document types (Purchases vs. Invoices) — reverse charge is the
  one case where a single Purchase-side transaction generates *both* an
  output tax entry and an input tax entry. The VAT Position engine (Module
  3) needs this modeled explicitly from the start, not patched in later.

### Database implications
A reverse-charge Purchase/expense entry needs to be capable of producing
two VAT ledger effects (one output, one input) from one source record —
worth deciding now whether that's two derived rows or one row with two
amount fields, since retrofitting this after Module 3's VAT engine exists
would be a real rework.

### API implications
The VAT-position/return-generation logic (Module 3) must correctly pull
reverse-charge transactions into *both* the output tax and input tax totals
— a specific, testable business rule worth an explicit unit test once a
service layer exists (per ADR-0001 §13.1).

### UI implications
Purchase entry UI should clearly label reverse-charge transactions and,
ideally, show the user both VAT effects (output and input) at entry time
rather than hiding the mechanic entirely — SME users benefit from
understanding why a "foreign purchase" shows a VAT number even though they
paid the foreign supplier VAT-free.

### Validation rules
**[BEST PRACTICE]** Reverse charge should only apply to purchases from
non-UAE-registered or Designated Zone suppliers — a domestic purchase from
a UAE mainland VAT-registered supplier should never be flagged reverse
charge (that supplier should be charging VAT normally).

### Edge cases
- Partially-exempt Tenants (§2.4/§4.4): reverse charge is not cash-neutral
  for them — the product must apply the same input-recovery restrictions to
  the reverse-charge input leg as it would to any other input VAT, not
  assume automatic full offset.
- Designated Zone reverse charge specifically depends on whether the goods
  are "used or consumed" in a way that keeps them within Designated Zone
  VAT treatment, or whether they're genuinely moving into mainland
  circulation — a nuance worth a tax advisor's input before Module 3
  finalizes the exact trigger logic.

### Future considerations
As the e-invoicing mandate (§5.1) matures, reverse-charge transactions will
still need correct internal accounting even though the self-invoicing
paperwork requirement was dropped — worth confirming, closer to Module 2/3
build time, how the Peppol e-invoicing framework expects reverse-charge
imports to be represented (if at all, since they may fall outside the
domestic e-invoicing exchange entirely).

---

## 3.4 Designated Zones

### Definition
Specific, geographically-fenced free zones that the UAE Cabinet has
designated (via Cabinet Decision No. 59 of 2017 and subsequent updates) to
be treated as **outside the UAE for VAT purposes on goods** — a distinct,
narrower list than the general set of UAE free zones, and a completely
separate list from Corporate Tax's "Qualifying Free Zone" designation (the
two should never be conflated).

### Official UAE FTA business rules
- **[CONFIRMED]** As of the research date (July 2026), roughly 27+ zones
  hold Designated Zone status, including JAFZA, KIZAD, DAFZA, Hamriyah Free
  Zone, SAIF Zone, Al Ain International Airport Free Zone, and others —
  the authoritative, current list is published by the FTA/Cabinet Decision,
  not fixed permanently (zones can be added or removed).
- **[CONFIRMED]** Not every "free zone" business location is a Designated
  Zone — e.g., Dubai Media City and DMCC are commonly cited as **not**
  fenced/designated, meaning normal (mainland-equivalent) VAT rules apply
  there, not Designated Zone treatment.
- **[CONFIRMED]** Designated Zone treatment applies specifically to the
  movement and supply of **goods** within/into/out of the zone under
  defined conditions (e.g., the zone must be fenced, have security/customs
  controls, and internal procedures for storing/processing goods) — it does
  **not** generally extend the same "outside UAE" treatment to services,
  which are typically taxed based on normal place-of-supply rules
  regardless of a Designated Zone location.
- **[CONFIRMED]** Goods moving from a Designated Zone into UAE mainland are
  treated as an import, triggering reverse charge (§3.1/§3.3) for a
  registered mainland recipient.

### Real-world example
A trading company based in JAFZA (a Designated Zone) sells goods to another
business also within JAFZA — potentially outside the scope of UAE VAT
(goods never entered the mainland VAT territory). The same company selling
identical goods to a Dubai mainland customer is making what's treated as an
import into the mainland, triggering reverse charge for that mainland buyer.

### Product implications
- If any Tenant is established in, or regularly trades with, a Designated
  Zone, the product needs a way to record a counterparty's (Customer's or
  Supplier's) zone status, since it changes VAT treatment materially and
  isn't inferable from an address string alone.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Given the target customer base
  (UAE SMEs, per the Module 0 README's framing) is likely mainland-focused,
  it's worth explicitly deciding whether full Designated Zone support is
  in scope for early modules, or a deliberately deferred edge case — this
  materially affects Module 1's Business Profile and Module 3's VAT engine
  complexity, so it's better decided than defaulted.

### Database implications
If in scope: `Tenant`/`Customer` would need a zone-status field
(`MAINLAND | DESIGNATED_ZONE | OUTSIDE_UAE`), maintained against the
current Cabinet Decision list — which itself changes over time, so this
should be a lookup table the product can update, not a hardcoded enum
baked into application code.

### API implications
No endpoints exist yet; if built, zone-status lookups should probably be
maintained centrally (not per-Tenant hardcoded), since the authoritative
list is a UAE-wide fact, not tenant-specific data.

### UI implications
If in scope: Business Profile and Customer-creation forms would need a
zone-status selector; if out of scope for now, the product should default
everyone to mainland treatment and document that assumption clearly rather
than silently getting Designated Zone transactions wrong.

### Validation rules
Not applicable until the scope decision above is made.

### Edge cases
The Designated Zone list itself is not static — the product's own reference
data (if built) needs a maintenance process, not a one-time hardcoded list,
or it will silently go stale as zones are added/removed by future Cabinet
Decisions.

### Future considerations
This is one of the more genuinely complex UAE-specific VAT nuances and is
recommended as an explicit, deliberate scoping conversation before Module 3
(VAT Position) locks in its calculation engine — better to decide "not
supported in v1" clearly than to build an engine that quietly gets
Designated Zone transactions wrong.
