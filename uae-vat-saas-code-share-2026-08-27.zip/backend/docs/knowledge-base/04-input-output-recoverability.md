# 4. Input/Output VAT & Recoverability

Covers: **Input VAT**, **Output VAT**, **Recoverable VAT**, **Non-Recoverable VAT**.
See the [legend](README.md#legend--read-this-before-reading-any-topic-file).

---

## 4.1 Output VAT

### Definition
The VAT a business **charges and collects** on its taxable sales (Standard
Rated and Zero Rated supplies, §2.2/§2.3). Output VAT is a liability owed to
the FTA, reported and paid via the VAT return (§7.1).

### Official UAE FTA business rules
- **[CONFIRMED]** Output VAT = the sum of VAT charged across all Standard
  Rated (5%) and Zero Rated (0%, so contributes AED 0 but still counted as a
  supply) transactions in a tax period, computed on the value of supply
  (after discounts, §5.4) at the tax point (date of supply, §8.1-adjacent
  concept covered under Filing Periods, §7.2).
- **[CONFIRMED]** Reverse-charge imports (§3.3) also generate an output tax
  entry on the recipient's own return, despite the recipient not being the
  "seller" in the traditional sense.
- **[CONFIRMED]** Deemed supplies (§6.2) can generate output tax even
  without a traditional sale (e.g., gifts/samples exceeding the AED 500/AED
  2,000 thresholds, or business assets converted to non-business use).

### Real-world example
Al Noor Trading LLC's Q1 output VAT is the sum of VAT charged on all
invoices issued in Q1 (standard-rated sales), plus AED 0 from its zero-rated
export sales (still counted as supplies), plus any reverse-charge import
output-tax entries, plus any deemed-supply output tax.

### Product implications
Output VAT is fundamentally an **aggregation** over Invoice line items
(Module 2) plus reverse-charge Purchase entries (§3.3) plus deemed supplies
(§6.2) — it is not a field the user enters directly; it must always be
computed from underlying transactions, never manually overridden, to
preserve audit integrity.

### Database implications
No new entity needed beyond what Invoicing (Module 2) and the reverse-charge
modeling in §3.3 already require — Output VAT is a **query/aggregation**
over existing transaction data for a given tax period, not a stored balance
that's independently maintained (storing it independently risks drift from
the underlying transactions).

### API implications
A VAT-position/summary endpoint (Module 3) should compute output VAT
on-demand from the underlying line items for the requested period, exposing
the breakdown by category (standard/zero-rated/reverse-charge/deemed) since
the VAT return (§7.1) itself requires category-level boxes, not just one
total.

### UI implications
A VAT Position/Dashboard view (Module 3) should show output VAT broken down
by source category, not just a single number — both for the Tenant's own
understanding and because that's how the FTA return itself is structured.

### Validation rules
**[BEST PRACTICE]** Output VAT total should always be independently
re-derivable from line-item data — if the product ever caches/stores a
period total for performance, it must be treated as a cache with a clear
recomputation path, never the source of truth.

### Edge cases
Credit notes (§5.3) reduce previously-reported output VAT in the period
they're issued — the aggregation logic must account for credit notes issued
in a *different* period than the original invoice, which is the common case
for real returns/adjustments.

### Future considerations
None beyond what's already covered in the Returns (§7.1) and Invoicing
(§5.1/§5.3) sections this concept depends on.

---

## 4.2 Input VAT

### Definition
The VAT a business **pays** on its taxable purchases and expenses, which it
may be entitled to recover (subject to the rules in §4.3/§4.4) by offsetting
it against output VAT owed, or reclaiming it as a refund if input exceeds
output.

### Official UAE FTA business rules
- **[CONFIRMED]** Input VAT is only recoverable if: the cost relates to
  making taxable supplies (standard or zero-rated — see §2.1), the business
  holds a valid tax invoice (or import/customs documentation) supporting the
  claim, and the cost isn't specifically blocked under Article 53 (§4.4).
- **[CONFIRMED]** Where a business makes both taxable and exempt supplies,
  input VAT that can't be directly attributed to one or the other must be
  apportioned (partial exemption, §4.4/§6.2) — not fully recovered, not
  fully blocked, but proportioned.
- **[CONFIRMED]** As of the 1 January 2026 amendments: the FTA may deny
  input VAT recovery where a supply is connected to tax evasion and the
  recipient knew, or reasonably should have known, that the VAT treatment
  applied to it was incorrect (e.g., VAT wrongly charged on an exempt/
  zero-rated/out-of-scope supply, VAT charged by an unregistered supplier,
  or reverse charge incorrectly not applied). This is a **new, active
  compliance risk** as of this year, not historical background — worth
  flagging to whoever designs Module 3's recovery logic.

### Real-world example
Al Noor Trading LLC pays AED 1,000 in VAT on office supplies used entirely
for its taxable trading business — fully recoverable, offset directly
against its output VAT liability for the period.

### Product implications
Input VAT recovery is the flip side of Output VAT (§4.1) — same aggregation
principle, computed from Purchase/Expense records (Module 3), never
manually entered as a standalone total.

### Database implications
Every Purchase/Expense record needs: a VAT amount, a recoverability flag or
computed status (Recoverable / Non-Recoverable / Partially Recoverable —
see §4.3/§4.4), and a link to supporting documentation (the tax invoice
received from the supplier) — the last point matters because recovery
without a valid supporting tax invoice is not legally defensible even if the
expense is otherwise legitimate.

### API implications
Purchase/expense creation (Module 3) needs to classify recoverability at
entry time (or provide a clear default with override), since this figure
feeds directly into the VAT return.

### UI implications
Purchase entry UI should make recoverability status visible and, where
blocked categories apply (entertainment, personal-use vehicles — §4.4),
should proactively flag likely-blocked expense types rather than silently
accepting a recovery claim the FTA would reject on audit.

### Validation rules
**[BEST PRACTICE]** A Purchase/Expense claiming input VAT recovery should
require an attached/referenced supplier tax invoice reference — enforced as
guidance/warning at minimum, ideally a hard requirement once Module 3 exists.

### Edge cases
Recovery denial for tax-evasion-linked supplies (2026 amendment, above) is a
judgment call the software cannot make automatically — the product's role
is to capture enough data (was VAT charged by a party who shouldn't have
charged it? was reverse charge missed?) to support a human/advisor review,
not to auto-deny recovery algorithmically without cause.

### Future considerations
As e-invoicing (§5.1) rolls out through 2027, input VAT recovery will
increasingly be validated against invoices the recipient actually received
through the Peppol network — worth revisiting this section's product
implications once Module 2/3 build coincides with that mandate's mainland
rollout.

---

## 4.3 Recoverable VAT

### Definition
The portion of input VAT (§4.2) a business is legally entitled to offset
against its output VAT liability or claim as a refund.

### Official UAE FTA business rules
- **[CONFIRMED]** Full recovery applies to input VAT on costs wholly used
  for making taxable (standard-rated or zero-rated) supplies, holding valid
  supporting documentation, and not falling into a blocked category (§4.4).
- **[CONFIRMED]** Where input VAT relates to a mix of taxable and exempt
  activity (or business and non-business use), only the taxable-use
  proportion is recoverable — calculated via an apportionment method (the
  standard method is generally based on the ratio of taxable to total
  supplies, though special methods can apply in specific circumstances).
- **[CONFIRMED]** As of the 1 January 2026 amendment, **excess recoverable
  input VAT (input exceeding output in a period) can now only be carried
  forward for a maximum of 5 years** from the end of the tax period in
  which it arose — previously indefinite. If not refunded or offset within
  that window, the right to recover it lapses. This is a materially
  important, *recently changed* rule with direct product implications.

### Real-world example
Al Noor Trading LLC has AED 15,000 in recoverable input VAT for Q1 but only
AED 10,000 in output VAT owed — the AED 5,000 excess can be requested as a
refund or carried forward to offset future periods, but (per the 2026
amendment) must be used or refunded within 5 years of the end of Q1, or it's
permanently lost.

### Product implications
- The 5-year carry-forward cap is a genuinely new compliance risk the
  product should actively help Tenants avoid — an accumulating excess
  input VAT balance approaching its 5-year expiry is exactly the kind of
  thing a VAT SaaS product should proactively surface, not leave the Tenant
  to track manually in a spreadsheet.
- This requires the VAT Position engine (Module 3) to track excess input
  VAT **by the tax period it originated in**, not just as a single running
  balance — because the 5-year clock starts from each period's end, not
  from "now."

### Database implications
A carry-forward balance needs to be tracked as a **ledger of dated
tranches** (period X generated AED Y excess, expiring on date Z), not a
single aggregate number — otherwise the product cannot correctly determine
which portion of a current balance is about to expire.

### API implications
The VAT Position/summary endpoint (Module 3) should be able to report
"expiring soon" carry-forward amounts, which requires the tranche-level
tracking above to exist in the data model from the start.

### UI implications
A VAT Position dashboard (Module 3) should surface a clear warning when
carried-forward excess input VAT is approaching its 5-year expiry — a
genuinely valuable, differentiating feature given how recent and easy-to-miss
this rule change is.

### Validation rules
**[BEST PRACTICE]** Carry-forward tranches should be automatically
"consumed" oldest-first when offsetting against future output VAT (a FIFO
approach) — both because it's the most Tenant-favorable ordering (uses the
soonest-to-expire amounts first) and because it's the most defensible
default absent specific FTA guidance on ordering.

### Edge cases
- A Tenant with a chronically exempt-heavy or zero-rated-heavy business
  (common excess-input-VAT position, e.g., an exporter) is the profile most
  likely to accumulate large, aging carry-forward balances — worth keeping
  in mind as a primary persona for this feature's UX, not an edge case to
  deprioritize.
- Refund *requests* and refund *processing/payment* are separate FTA
  processes with separate timing — submitting a refund request before the
  5-year deadline preserves the right even if the FTA hasn't processed
  payment yet; the product should track "requested" as sufficient to stop
  the clock, distinct from "received."

### Future considerations
This is a live, recently-changed rule (2026) — re-verify with a licensed tax
agent before Module 3's carry-forward logic is finalized, since guidance on
exact mechanics (FIFO ordering, refund-request-vs-payment timing) may
continue to be clarified by the FTA as businesses first hit the 5-year wall
starting around 2031 (five years after the 2026 change).

---

## 4.4 Non-Recoverable VAT

### Definition
Input VAT that cannot be recovered, either because it's specifically
blocked by law regardless of business purpose (Article 53), or because it
relates to exempt/non-business activity rather than taxable supplies.

### Official UAE FTA business rules
- **[CONFIRMED]** Legal basis: Article 53, VAT Executive Regulations.
  Specifically blocked categories include:
  - **Entertainment provided to non-employees** — hospitality
    (accommodation, food, drinks not provided in the normal course of a
    business meeting), event/show access, or pleasure/entertainment trips —
    when provided to customers, potential customers, officials,
    shareholders, or investors (i.e., anyone who is *not* an employee of the
    business). Entertainment provided to *employees* for a genuine business
    purpose (staff motivation, normal business operations) is generally
    **not** blocked — the block specifically targets non-employee
    entertainment.
  - **Motor vehicles available for personal use** — input VAT on the
    purchase, lease, or running costs (fuel, servicing, insurance) of a
    motor vehicle is blocked if the vehicle is available for any person's
    personal use, even occasionally. A vehicle used *exclusively* for
    business (e.g., a taxi, a rental-fleet vehicle, a delivery-only van with
    no personal-use allowance) is not blocked.
- **[CONFIRMED]** Blocked-category rules take priority over apportionment —
  a blocked cost is 0% recoverable regardless of how "taxable" the rest of
  the business is; it's never blended into a partial-exemption ratio.
- **[CONFIRMED]** Input VAT attributable to exempt supplies (§2.4) is
  non-recoverable, subject to apportionment where mixed with taxable use.

### Real-world example
Al Noor Trading LLC buys a company car that its Sales Manager also uses on
weekends for personal errands — the input VAT on that purchase (and its
fuel/servicing) is entirely non-recoverable, even though the car is mostly
used for business, because "available for personal use" is the trigger, not
"used more than 50% for business."

### Product implications
- This is the category most likely to trip up SME users who assume
  "business expense = recoverable VAT" — the product has real value in
  proactively flagging expense categories (entertainment, vehicles) that
  are commonly, specifically blocked, rather than leaving users to
  discover this only on an FTA audit.
- **[ASSUMPTION — NEEDS PRODUCT DECISION]** Should the product maintain a
  built-in list of "commonly blocked" expense categories/keywords to warn
  against at entry time (e.g., flag "restaurant," "hotel," "entertainment"
  category purchases for extra scrutiny), or leave classification entirely
  to the user? A lightweight assistive warning (not a hard block, since
  legitimate exceptions exist — e.g., employee entertainment) seems like
  the safer default, but is a genuine product decision, not a legal
  requirement.

### Database implications
Purchase/Expense records need a recoverability classification that can be
`FULL | NONE | PARTIAL (apportioned)`, with the blocked-category rule
evaluated *before* any general apportionment calculation — the schema/logic
order matters: check "is this specifically blocked" first, and only run
partial-exemption apportionment on what's left.

### API implications
Expense-creation logic (Module 3, likely in a dedicated service per
ADR-0001 §13.1, not a controller) needs the blocked-category check and the
apportionment calculation as two distinct, ordered steps — good candidate
for its own unit-tested service function given the real financial
consequence of getting the order or the categories wrong.

### UI implications
Expense entry should show the resulting recoverability (full/none/partial)
clearly after category selection, with a brief "why" explanation — building
user trust and VAT literacy at the point of data entry is more valuable
than a bare percentage number.

### Validation rules
**[BEST PRACTICE]** Vehicle and entertainment expense categories should
default to non-recoverable unless the user explicitly confirms an
exclusive-business-use exception — defaulting to blocked (safer/conservative)
rather than defaulting to recoverable (riskier) reflects how an auditor
would approach an ambiguous claim.

### Edge cases
- A vehicle used exclusively for business but occasionally lent to an
  employee "just this once" for personal use — technically triggers the
  block the moment personal use is *available*, regardless of actual
  frequency; a strict reading worth surfacing explicitly in product
  copy/help text, since it's counter-intuitive.
- Employee entertainment vs. non-employee entertainment can be genuinely
  ambiguous in mixed events (e.g., a staff party that clients also attend)
  — the product should support splitting a single event's cost across
  recoverable/non-recoverable portions rather than forcing an all-or-nothing
  classification.

### Future considerations
If the product ever adds automated expense-category suggestions (e.g., from
OCR'd receipts in Module 5), the blocked-category detection logic built here
becomes directly reusable — worth building it as a clean, standalone rule
set from the start rather than UI-only copy.
