# Ledger — Database Design Specification (DDS)

- **Status:** Version 1 — authoritative database architecture standard
- **Date:** 2026-07-30
- **Applies to:** both repos — `uae-vat-saas-frontend-module0/frontend` and `uae-vat-saas-module/uae-vat-saas`
- **Synthesized from:** [Master Product Specification](master-product-specification.md), [Platform Architecture Specification](platform-architecture-specification.md), [Product Bible v2](product-bible.md), [ADR-0001](adr/0001-baseline-architecture.md) (Accepted), [UAE VAT Knowledge Base](knowledge-base/README.md).
- **What this is:** the database *design standard* every future table must satisfy — naming, typing, keying, isolation, and lifecycle rules. It is not a schema; it contains no table definitions, no Prisma models, no SQL, no migrations.
- **Relationship to ADR-0001:** this document does not override any Accepted decision (Prisma, Postgres-as-target, pooled multi-tenancy, migration-only schema changes, soft-delete preference). It makes those decisions concrete and operational at the database-design level, and it surfaces a small number of honest findings against the current Module 0 schema — flagged as findings, not silently fixed, per [ADR §13.3].
- **Tiering convention:** **[Build Now]** · **[Design Now, Build Later]** · **[Future Vision]** — consistent with the [PAS](platform-architecture-specification.md).

---

## 1. Database Vision

**Purpose:** the database is the system of record for compliance-grade financial data belonging to many businesses at once. Its job is to make correctness and isolation structurally hard to violate — not to be clever.

**Goals:** every table is self-explanatory from consistent conventions alone; schema evolution is additive by default; a new engineer can read the standards in this document once and correctly predict how any future table should look, without asking.

**Design Philosophy:** *boring, consistent, and auditable beats clever.* Financial software rewards predictability — a data model an FTA auditor's expectations, a new engineer's intuition, and a future AI orchestration layer's assumptions all agree on, without each needing a special explanation. Every rule below exists to make one of those three audiences' lives simpler at the cost of a small amount of upfront discipline.

**Guiding Principles** (database-level expression of [PAS §3]):

| PAS Principle | Database expression |
|---|---|
| Tenant context is structural | Every tenant-owned table carries a mandatory tenant discriminator column; isolation does not depend on every query author remembering to filter ([§3]). |
| Composition over coupling | Cross-cutting platform services ([PAS §8]) own their own tables; domain modules never write into another module's tables directly ([§4]). |
| Additive evolution over rewrites | Schema changes default to additive; destructive change is the deliberate exception, not the norm ([§17]). |
| One rule, one implementation | Business rules are enforced once, in the service layer; the database enforces *structural* invariants, not re-implementations of business logic ([§16]). |
| Build the seam, not the engine | Standards are set now for patterns every module will need (soft delete, audit columns, numbering); no module-specific tables are designed ahead of the module that needs them. |

---

## 2. Database Technology Stack

### PostgreSQL

| Alternative considered | Why not chosen |
|---|---|
| MySQL/MariaDB | Weaker native JSONB, no native Row-Level Security (a defense-in-depth layer [PAS §9]/[§10] already commits to), less mature partial-index support. |
| A NoSQL document store | This domain is inherently relational with strict referential-integrity needs (an Invoice must belong to exactly one Tenant, line items must sum correctly, a Customer reference must resolve) — exactly the case NoSQL fits worst. |
| SQLite (current dev database) | Fine for solo local development ([ADR §4]), but lacks native enums, native RLS, and robust concurrent-write handling — not a target for any shared/production environment, per [ADR §4]'s own stated migration path. |

**Why Postgres**: mature ACID guarantees, native Row-Level Security (the second isolation layer this platform has already committed to, [PAS §9]), a rich type system (native enums, JSONB, arrays, `NUMERIC` for exact decimal arithmetic — directly relevant to [KB §8.4]'s rounding rules), strong extension ecosystem, and broad managed-hosting availability that fits [ADR §12]'s "managed database service" deployment principle.

### Prisma ORM

Confirmed by [ADR §4]; this section states the operational implications for a Postgres target, honestly:

- **Fit**: type-safe, schema-first workflow; its migration tool is what makes "every schema change is a reviewable migration" ([ADR §5]/[§17]) an enforced practice rather than a policy people can forget.
- **Gap to plan for**: Prisma does not natively author or manage Postgres Row-Level Security policies, some partial-index predicates, or certain Postgres-specific features. The standard pattern — and the one this platform adopts — is Prisma-generated migrations for schema shape, with hand-authored SQL segments (which Prisma Migrate supports appending to a generated migration) for RLS policies and any Postgres-native feature Prisma's schema language doesn't express directly. This is normal, well-established Prisma+Postgres practice, not a workaround.

### UUID Strategy

| Decision | Rationale | Trade-off |
|---|---|---|
| Surrogate UUID primary keys, platform-wide | No coordination needed across a future extracted service ([PAS §16]/[§24]); doesn't leak sequential business volume (a competitor inferring invoice count from a sequential ID is a real B2B SaaS concern); globally unique if the platform ever needs multi-region or sharded data ([§20]). | UUIDs are 16 bytes vs. 4–8 for an integer — larger indexes, and *random* UUIDv4 causes index-page fragmentation and insert hot-spotting at high write volume. |
| **[Design Now, Build Later]** — evaluate UUIDv7 (time-ordered) once real write volume justifies it | UUIDv7 keeps global uniqueness while being mostly monotonic, restoring the index-locality benefit a sequential key would have had. | Requires either a Postgres-side default function or an application-side generator — not Prisma's out-of-the-box `uuid()` default, which is v4. Not worth adopting speculatively; listed as [§22 Open Decision]. |

### Extensions

| Extension | Purpose | Tier |
|---|---|---|
| `pgcrypto` or `uuid-ossp` | DB-generated UUID defaults, so ID generation is consistent regardless of which service/caller inserts a row | **[Build Now]** |
| `citext` | Case-insensitive uniqueness/comparison for fields like email | **[Build Now]** — cheap, prevents a real class of "duplicate account, different casing" bugs |
| `pg_trgm` | Fuzzy/full-text search support | **[Future Vision]** — ties to [PAS]'s deliberately deferred Search capability; not needed at MVP data volumes |

---

## 3. Multi-Tenant Database Strategy

**Why pooled multi-tenancy** (reaffirming [ADR §7], made concrete at the schema level):

| Model | Isolation strength | Operational cost | Prisma fit |
|---|---|---|---|
| Database-per-tenant | Strongest | High — one migration run and backup target per Tenant; doesn't scale to an SME customer base | Poor — Prisma assumes one connection/schema per Client instance |
| Schema-per-tenant (Postgres `search_path`) | Moderate-strong | Moderate — still N schemas to migrate | Poor — requires dynamic datasource switching Prisma doesn't support cleanly |
| **Pooled, row-level discriminator (chosen)** | Strong, when enforced structurally | Low — one schema, one migration surface | Native fit |

**Tenant isolation principles**:
- Every tenant-owned table carries a mandatory, non-nullable tenant discriminator column, resolved server-side from a verified identity — never accepted from a client ([PAS §3]/[§9], unchanged).
- **A foreign key alone does not guarantee cross-tenant safety.** An FK from one tenant-owned table to another only guarantees the referenced row *exists* — not that it belongs to the *same* Tenant. This must be enforced at the service layer (verify both sides resolve to the same tenant context before writing) and should additionally be reinforced at the database layer wherever practical (e.g., a composite foreign key that includes the tenant discriminator on both sides). This is a genuine, easy-to-miss risk, named explicitly here so it isn't discovered in a security review later.

**Tenant ownership taxonomy**:

| Tier | Example | Tenant discriminator? | RLS applicability |
|---|---|---|---|
| **Tenant-Owned** | Business Profile, Customers, Invoices, Purchases | Mandatory | Primary RLS target |
| **Shared-Reference** | UAE public holiday calendar, Designated Zone list ([KB §3.4]), CBUAE exchange-rate cache ([KB §8.3]) | None — read-only, platform-maintained | Not applicable — same data for every Tenant |
| **Platform-Global** | Plan definitions, Platform Admin accounts, global feature-flag definitions | None | Not applicable — no Tenant should ever see another's platform-level config, but there's only one copy to protect, not per-Tenant rows |

**Cross-tenant protection**: application-level tenant scoping is the mandatory, always-on layer. Row-Level Security is the **[Design Now, Build Later]** second layer, arriving with the Postgres migration ([PAS §25 Decision 4]) — Postgres RLS policies keyed on a per-request tenant-context session value, applied to every Tenant-Owned table. With Prisma, this means each request's database work runs inside a transaction that first sets the tenant-context session value, so the RLS policy has something to check — a well-established pattern, not a novel one. RLS is defense-in-depth: it must never become the *only* enforcement layer, since the application layer's explicit checks remain the primary, auditable control.

---

## 4. Data Ownership Principles

**Module ownership** (database expression of [PAS §21]): each domain module owns its tables exclusively. Other modules access that data only through the owning module's service interface — never by querying its tables directly, even though, in a pooled single-schema database, nothing at the SQL level currently *prevents* that. This is enforced by convention and code review today.

**[Design Now, Build Later]**: Postgres supports multiple schemas (namespaces) within one database, and Prisma supports this via its multi-schema capability. Using **one Postgres schema per domain module** (not per Tenant — tenancy stays row-level per [§3]) is a real option for turning "module data ownership" from a convention into something the database itself can help enforce (via schema-level permissions). This is a deliberate, non-trivial change — not adopted for Module 0/1 reflexively — and is listed as [§22 Open Decision].

**Data boundaries**:

| Ownership tier | Owned by | Examples |
|---|---|---|
| Domain-owned | The domain module itself ([PAS §6]/[§7]) | Tenant Foundation's Customers/Suppliers; Invoicing's documents |
| Cross-cutting platform service–owned | The platform service, not any single domain ([PAS §8]) | Audit Log entries, Numbering sequences, Configuration values, File metadata |
| Shared/Platform | No single module | Plan definitions, shared reference data ([§3]) |

**Cross-module communication**: a migration adding a table should document which module owns it (a naming/documentation convention, [§6]); a foreign key from one module's table into another module's table is permitted at the database level (referential integrity doesn't respect module boundaries and shouldn't be weakened to pretend otherwise) — but the *application code* that populates and reads across that relationship must still go through the owning module's service interface, not query the table directly. Module ownership is an application-layer discipline; foreign-key integrity is a database-layer one, and the two are not in tension.

---

## 5. Entity Design Principles

| Concern | Standard | Rationale |
|---|---|---|
| **Primary Keys** | Surrogate UUID, always | Natural keys (TRN, email) can change ([KB §1.2] edge case) or have format edge cases; a surrogate PK never needs to change even if the business-meaningful value does. |
| **Foreign Keys** | Always reference the surrogate PK; always explicitly indexed | Postgres does **not** auto-index FK columns — a common, costly oversight. Every FK column gets an explicit index without exception ([§13]). |
| **Composite Keys** | Avoided as primary keys; used instead as composite `UNIQUE` constraints on top of a surrogate PK | A true composite PK complicates FK references from a third table and is materially clunkier in Prisma's relational API. A junction table gets its own UUID PK plus a composite unique constraint on the pair it joins — trivially extensible later (e.g., adding a `grantedAt` timestamp to a future RBAC junction) without restructuring keys. |
| **Natural Keys** | Never a PK; used only as business-uniqueness constraints, almost always tenant-scoped (e.g., invoice-number uniqueness per [KB §8.1] is `unique(tenant, number)`, not globally unique) | Keeps the uniqueness rule matched to the actual business rule, not an accidental platform-wide constraint. |
| **Surrogate Keys** | The default and mandatory PK strategy | Consistency; see Primary Keys above. |
| **Junction Tables** | Own UUID PK + composite unique constraint on the joined pair; carry their own audit columns if the relationship itself has meaningful lifecycle (e.g., a future access-grant record needs its own `grantedAt`/`grantedBy`, not just two foreign keys) | A relationship with meaningful lifecycle (per [MPS §17]'s consent/grant requirement) is itself a first-class fact, not just a link. |

---

## 6. Naming Standards

| Element | Standard | Note |
|---|---|---|
| **Tables (Prisma models)** | PascalCase in Prisma; mapped to `snake_case` actual Postgres identifiers | Postgres community convention is unquoted `snake_case`; PascalCase identifiers require quoting in every raw SQL statement, RLS policy, and `psql` session — a real, avoidable friction point. **Finding**: Module 0's current schema does not use this mapping, so its actual Postgres table names will be quoted PascalCase once migrated. Reconciling existing tables to this standard is a deliberate decision, not something this document changes — see [§22 Open Decision]. |
| **Columns** | camelCase in Prisma (application-facing); mapped to `snake_case` in Postgres | Same rationale as tables; keeps the Prisma/TypeScript side idiomatic while the database side stays idiomatic Postgres. |
| **Constraints** | Explicit, meaningful names (e.g., a unique constraint named for what it guarantees), never left to auto-generated defaults | Auto-generated constraint names surface in production error messages (a unique-violation error names its constraint) — a meaningful name is the difference between an instantly-readable error and a support investigation. |
| **Indexes** | A consistent short grammar: `idx_<table>_<column(s)>` for regular indexes, `uq_<table>_<column(s)>` for unique indexes | Predictable names make migration diffs and `EXPLAIN` output easier to reason about. |
| **Enums** | PascalCase type name, `UPPER_SNAKE_CASE` values | Matches the value-naming convention already established informally in Module 0 (`TRIAL`, `ACTIVE`, `OWNER`). |
| **Relations** | Singular field name for to-one, plural for to-many; explicit relation names whenever a model has more than one relationship to the same target table | Disambiguation matters the moment a table has two distinct relationships to another table (e.g., a "created by" and a "last updated by" both referencing Users) — decide the naming convention before the first such case, not during it. |

---

## 7. Common Columns Standard

| Column | Type | Mandatory when | Purpose | Omit when |
|---|---|---|---|---|
| `id` | UUID | Always | Surrogate primary key | Never |
| `tenantId` | UUID (FK) | Tenant-owned tables ([§3]) | Isolation discriminator | Platform-Global / Shared-Reference tables |
| `createdAt` | `timestamptz` | Always | Auditability, default sort key | Never |
| `updatedAt` | `timestamptz` | Mutable tables | Change tracking | Immutable/append-only tables (e.g., an issued document's line items, Audit Log entries) — an `updatedAt` that always equals `createdAt` is misleading, not harmless |
| `createdBy` | UUID (FK, nullable) | Tenant-owned mutable tables | Attribution | High-volume system-generated rows where the Audit Log ([§11]) is the more appropriate home for "who did this" |
| `updatedBy` | UUID (FK, nullable) | Alongside `updatedAt` | Attribution | Same reasoning as `createdBy` |
| `deletedAt` | `timestamptz`, nullable | Entities with a genuine delete/restore lifecycle ([§10]) | Soft-delete marker | Immutable financial documents (never deleted, softly or otherwise — a Credit Note is the correction mechanism, [KB §5.3]) and simple reference/lookup tables |
| `status` | Enum or lookup FK | Entities with a real lifecycle | State-machine anchor | Tables with no meaningful state |
| `version` | Integer, default 1 | Tables with real concurrent-edit risk ([§12]) | Optimistic concurrency control | Single-writer or append-only tables |

**`createdBy`/`updatedBy` vs. the Audit Log — not redundant, complementary**: the columns answer "who, right now, most recently" cheaply, for UI display ("last edited by..."). The Audit Log ([§11], [PAS §8]) answers "what happened, over time, in detail" for compliance and investigation. A table needing the second doesn't need to duplicate it into the first, and vice versa.

---

## 8. Relationship Strategy

| Pattern | Standard | Notes |
|---|---|---|
| **One-to-One** | Rare; implemented via a shared unique FK, not mirrored primary keys | Only justified when the split-off data has a different access profile or lifecycle than its parent (e.g., a future optional branding extension). |
| **One-to-Many** | The dominant pattern | FK always lives on the "many" side, always indexed ([§13]). |
| **Many-to-Many** | Junction tables only ([§5]) | Never modeled via array columns — arrays can't be indexed for join-style queries as efficiently, and Prisma cannot express them as a real relation with its own integrity guarantees. |
| **Cascade Rules** | `RESTRICT` is the default posture for anything tenant-owned and financial/compliance-relevant; `CASCADE`/`SET NULL` require explicit, per-relationship justification | Cascading deletes on financial data risk silently destroying retained records ([KB §8.2]). **Tenant deletion is explicitly not a cascading operation** — no offboarding workflow exists yet ([MPS §6.10]), and when one is designed, it will be archival/soft, never a cascade that deletes a Tenant and everything under it in one operation. |
| **Referential Integrity** | Real database-level FK constraints always — never an application-only "soft" reference | This holds even across module boundaries ([§4]) — module ownership is an application-layer discipline about *who writes through what interface*, not a reason to weaken database-level integrity. |

---

## 9. Data Type Standards

| Data | Standard | Rationale |
|---|---|---|
| **Money** | `NUMERIC(14,2)` (Prisma `Decimal`) — **never floating point** | Floating point cannot exactly represent decimal currency and will produce the fils-level rounding errors [KB §8.4] explicitly warns against. **Finding**: the current Module 0 schema uses `Float` for `Material.defaultUnitPrice` and `Purchase.amount` — flagged here as a concrete correction needed before any real money moves through the system, not fixed silently in this document. |
| **Exchange rates** | Higher precision than money fields (e.g., 6 decimal places) | [KB §8.3] requires the *full* CBUAE-published precision, not rounded — a distinct precision requirement from AED amounts. |
| **Dates with no time/timezone meaning** | Postgres `date` (e.g., date of supply, VAT rate effective-from) | Storing a calendar date as a timestamp risks off-by-one-day bugs across timezone conversions near midnight — a subtle, real bug class for exactly the tax-point-sensitive dates [KB §5.1] describes. |
| **Timestamps** | `timestamptz`, always stored UTC | Consistent with Prisma's `DateTime` default; UI renders in the Tenant's configured locale ([MPS §15]) — the database itself stays timezone-agnostic. |
| **Booleans** | Native `boolean`; avoid using a boolean where a real multi-value status exists | A `status` enum (already Module 0's correct pattern for `ACTIVE`/`SUSPENDED`) should never be flattened into `isActive: boolean` the moment a third state becomes plausible. |
| **JSONB** | Sparing, deliberate use only — genuinely schema-flexible data (future custom fields, provider-specific metadata) | Not a substitute for relational modeling of core domain entities — dumping structured business data into JSONB undermines referential integrity, indexability, and the "one rule, one implementation" principle ([PAS §3]). Queryable via GIN indexes when genuinely needed. |
| **UUID** | Native Postgres `uuid` type, not `text` | **Finding**: SQLite has no native UUID type, so Module 0's current dev database stores these as text — a real type-tightening the Postgres migration should complete, not just a connection-string swap. |
| **Text** | Postgres `text` (unbounded) by default; `varchar(n)` only when the length limit is itself a genuine business rule enforced via `CHECK`, not decoration | Postgres has no performance difference between `text` and `varchar(n)` — an arbitrary length cap without a `CHECK` doesn't actually validate anything (e.g., a 15-character cap doesn't confirm "15 digits"). |
| **Enum** | Native Postgres enum for small, stable, code-controlled sets (plan tier, Tenant status, system role) | Lookup tables instead, wherever a value set might need runtime extensibility, per-Tenant customization, or additional attributes ([§6]) — e.g., future custom roles. |
| **Arrays** | Native array columns acceptable for small, unordered, non-relational value lists only | Never a substitute for a real relationship ([§8]). |

---

## 10. Soft Delete Strategy

**Why**: [KB §8.2] retention requirements, document immutability ([KB §5.1]/[§5.3]), and protecting Tenant history from accidental or malicious loss ([PAS §10]/[§23]).

**Soft delete and snapshot-at-issuance are complementary, not redundant** — worth stating precisely, since they're often conflated: soft delete keeps a *row* queryable and its foreign keys valid after a Tenant "removes" it (e.g., a Customer no longer in active use). Snapshotting ([KB §1.3]/[§5.1]) keeps a *historical document* displaying what was true when it was issued, regardless of what happens to the source row afterward. A deleted Customer's historical invoices need both: the row must still resolve (soft delete, not hard delete) and the invoice must still show the Customer's details as they were then (snapshot), not as the row currently stands, deleted or otherwise.

| Rule | Standard |
|---|---|
| **Implementation** | Nullable `deletedAt` timestamp; never a bare boolean — the timestamp is directly useful for retention-window math ([KB §8.2]) that a boolean can't provide. |
| **Query behaviour** | Every query against a soft-deletable table filters `deletedAt IS NULL` by default. This should be enforced centrally — a Prisma Client extension applied once, rather than trusted to every service function remembering the filter. |
| **Restoration** | Supported for entities with a reasonable "undo" UX (Customer, Supplier, Product/Service) — not applicable to financial documents, which are never deleted at all, softly or otherwise, once issued. |
| **Hard delete policy** | Permitted only for: (a) genuine drafts never finalized (an abandoned invoice draft that never consumed a sequence number, [KB §8.1]); (b) non-business-critical operational data with no compliance weight; (c) an explicit, legally-required data-subject-erasure request — which can genuinely conflict with FTA retention obligations, a conflict this document does not resolve (see [§22 Open Decision]). |

---

## 11. Audit Data Strategy

Three distinct concerns, deliberately not merged into one system:

| Concern | What it captures | Owner | Retention |
|---|---|---|---|
| **Business Audit** (the compliance-facing Audit Log, [PAS §8]) | Defined sensitive actions — login, permission change, financial document issuance/void, settings change | Audit Logging platform service | Aligned to [KB §8.2] — never shorter than the records it describes |
| **System Audit** (operational logging) | Debugging/operational events | Primarily infrastructure ([ADR §10]), not a database-design concern | Short-to-medium |
| **Change History** (field-level before/after) | *Not built for MVP* | — | **[Future Vision]** |

**Why field-level change history is deliberately deferred**: issued financial documents are immutable, so there's nothing to diff once issued; mutable entities (Business Profile, Customer) changing over time are adequately served by `createdBy`/`updatedBy` ([§7]) plus a coarse Business Audit event ("profile updated") without needing a full temporal/history-table pattern. Postgres supports proper system-versioned/temporal patterns (via triggers or extensions) if a specific future need (e.g., "show me exactly what this record looked like on a given date") justifies the real complexity — not adopted speculatively, consistent with "avoid overengineering the MVP."

---

## 12. Versioning Strategy

**Optimistic locking** (a `version` integer, incremented on every update, checked in the update's `WHERE` clause) is a **targeted tool for a specific problem** — two people editing the same row without knowing about each other — not a default column on every table.

| Use it when | Don't use it when |
|---|---|
| A record is plausibly edited by more than one actor near-simultaneously (e.g., a shared settings/configuration record) | The access pattern is single-writer-per-request (most CRUD) |
| Silent overwrite would be a real, costly bug | The table is append-only (line items, Audit Log — nothing to conflict over) |
| | The table already has its own concurrency-safe mechanism — **Numbering is the clearest example**: sequence allocation needs atomic, pessimistic allocation ([PAS §8]), not optimistic locking. These are different tools for different concurrency problems, and conflating them is a common design mistake worth naming explicitly. |

---

## 13. Index Strategy

| Index type | Standard | Notes |
|---|---|---|
| **Primary** | Automatic on the UUID PK | No action needed; see [§2]'s UUIDv7 note for the one real trade-off. |
| **Foreign key** | **Mandatory explicit index on every FK column** | Postgres does not auto-create these, unlike the PK's automatic unique index — the single most common, avoidable indexing mistake, called out explicitly in [§21]'s checklist. |
| **Composite** | `(tenantId, createdAt)` or `(tenantId, status)` as the near-universal pattern for "list this Tenant's records" queries | Column order follows the leftmost-prefix rule — the discriminator column goes first, since it's in nearly every query pooled multi-tenancy produces. |
| **Unique** | Almost always composite with `tenantId` (e.g., invoice numbering per [KB §8.1]) | Global (non-tenant-scoped) uniqueness is reserved for genuinely platform-wide values. **Worth flagging now**: Module 0's current global uniqueness on `User.email` (one email = one User = one Tenant) is a concrete design question the still-open Firm/multi-Tenant access decision ([PAS §25 Decision 1]) will directly affect — a Firm user needing access to multiple Tenants may not fit today's "one email, one Tenant" shape. Listed at [§22]. |
| **Partial** | Excellent fit for the soft-delete pattern — an index with a `deletedAt IS NULL` predicate keeps the common "active records" path lean; similarly useful for status-specific hot paths (e.g., unpaid invoices only) | A genuinely Postgres-native strength worth using deliberately, not just B-tree everything. |
| **Search** | Deferred — standard B-tree indexing is sufficient at MVP data volumes | Full-text (`tsvector`/`pg_trgm`) is **[Future Vision]**, tied to [PAS]'s deferred Search capability. |

---

## 14. Performance Guidelines

| Concern | Standard |
|---|---|
| **Query optimization** | Filter by `tenantId` first, leveraging the composite index in [§13]. Avoid N+1 query patterns — a very real, common Prisma footgun; use `include`/`select` deliberately rather than looping individual Prisma calls. |
| **Pagination** | Cursor-based (keyset) pagination is the standard to adopt before Firm-scale volumes arrive — `OFFSET` pagination degrades linearly with depth, while keyset stays roughly constant. Acceptable to use simple offset pagination at MVP's small per-Tenant datasets, but this is explicitly a **[Design Now, Build Later]** migration, not a permanent choice, consistent with [ADR §8]'s own pagination commitment. |
| **Filtering** | Every supported filter should be backed by a real index — no ad hoc filtering on unindexed or computed expressions. |
| **Sorting** | Default sort on an already-indexed column — `createdAt` is the universal safe default. |
| **Large datasets** | Aggregate operations (e.g., VAT Return generation across a full tax period, [PAS §13]) use set-based SQL aggregation (Prisma's `aggregate`/`groupBy`, or raw SQL where needed) — never pull rows into application memory to sum in JavaScript. |

---

## 15. File & Attachment Strategy

Consistent with [ADR §9] and [PAS §8]'s File Storage service:

- **Store references, never files.** The database stores only metadata and a storage key — file bytes live in object storage, never in Postgres.
- **Metadata shape (principle-level)**: owning Tenant, the record it's attached to, storage key, original filename, content type, size, `uploadedBy`/`uploadedAt`, and a **[Design Now, Build Later]** malware/virus-scan status field — a real security surface the moment user-uploaded files exist (future supplier-invoice OCR uploads), worth naming now even though no module currently uploads files.
- **Tenant isolation**: storage keys are tenant-prefixed ([ADR §9]); file-metadata rows are themselves tenant-owned tables, following every standard in this document like any other.
- **Future OCR compatibility**: the file-metadata entity should be introduced as a reusable, cross-cutting concept **the first time any module needs file upload** (likely branding/logo in Module 1, or generated invoice PDFs in Module 2) — not deferred until Module 5's OCR need, since OCR will simply be the second consumer of an entity that should already exist.

---

## 16. Data Integrity Rules

**The governing split**: *if violating a rule is always wrong regardless of business context, it's a database constraint. If it depends on business logic or cross-entity context, it's a service-layer rule* ([PAS §3] Principle 7, made concrete).

| Rule type | Example | Enforced where |
|---|---|---|
| Structural/format invariant | A field must never be null; a TRN must match a 15-digit pattern | Database (`NOT NULL`, `CHECK`) — as a defense-in-depth backstop even when the primary validation UX is in the application ([KB §1.2]) |
| Referential integrity | An Invoice's Customer reference must resolve to a real row | Database (foreign key) |
| Business rule requiring context | Whether a line item is Zero Rated, Exempt, or Standard Rated ([KB §2]); whether an expense is recoverable ([KB §4.4]) | Service layer only — the database has no business context to evaluate this correctly, and encoding it there would violate "one rule, one implementation" |

**Triggers**: acceptable for narrow, non-business-logic mechanics (an `updatedAt` auto-touch trigger is standard and safe). **Never** used to implement or duplicate a business rule already owned by the service layer — a trigger enforcing a VAT classification rule would be a second, invisible implementation of a rule [PAS §3] Principle 7 says must have exactly one.

---

## 17. Migration Strategy

| Principle | Standard |
|---|---|
| **Schema evolution** | Additive by default ([ADR §5]); every change is a Prisma-generated, reviewed migration — never a hand-edited production schema. |
| **Backward compatibility** | A migration must not break already-deployed application code mid-rollout. Adding a `NOT NULL` column without a default requires a two-step migration: add nullable → backfill → enforce `NOT NULL` in a follow-up migration, not a single unsafe step. |
| **Safe migrations** | Renames are the highest-risk operation — Postgres/Prisma can't always distinguish "rename" from "drop and add." The safe pattern: add the new column → dual-write/backfill → migrate reads → drop the old column in a *later*, separate migration. This is the concrete technical procedure behind [ADR §13.3]'s "never rename without approval." |
| **Rollback** | Prefer forward-fixing (a new corrective migration) over reversing an already-applied migration once real Tenant data exists against the new shape — a schema "rollback" against live data can itself be destructive. Reversal is acceptable pre-production only. |

---

## 18. Backup & Recovery Principles

High-level, per the request — quantified targets remain gated on the still-open deployment vendor decision ([ADR §12]/[PAS §25]):

- Daily automated backups, encrypted at rest and in transit, as an absolute floor.
- Periodic (e.g., quarterly) restore drills — a backup that has never been restored is not a verified backup.
- Point-in-time recovery (Postgres WAL-based) as the target capability — most managed Postgres providers offer this natively, and it should be an explicit selection criterion for [ADR §12]'s vendor decision, not an afterthought discovered post-selection.
- RPO/RTO numeric targets are deferred to that vendor decision, but the floor expectation stated in [PAS §17] (recovery measured in hours, not days) applies here too.

---

## 19. Security Principles

| Area | Standard |
|---|---|
| **Encryption** | At rest and in transit, always on, via the managed database provider — no exception regardless of hosting vendor ([PAS §10]). |
| **Sensitive fields** | Password hashes only, never plaintext or reversibly-encrypted credentials (already correct practice, bcrypt, reaffirmed). |
| **Column-level encryption beyond at-rest** | Not adopted for business contact data (TRN, address, phone) by default — storage-level at-rest encryption is judged sufficient for this data class, and column-level encryption would meaningfully complicate indexing/querying. Contingent on the still-open PDPL research outcome ([MPS §23 Decision 5]) — if that research finds otherwise, this position changes, and is listed at [§22]. |
| **PII** | Limited in this B2B context — mostly User account details (name, email) rather than consumer personal data — but still real PII, handled per whatever PDPL posture the open decision resolves. |
| **Access control** | MVP uses a single application database credential, consistent with Module 0 today. **[Design Now, Build Later]**: least-privilege, purpose-specific database roles (a read-only analytics role, a migration-only role distinct from the runtime application role) before any broader team or external integration touches the database directly. |
| **Secrets** | Database credentials follow the same secrets-management lifecycle as any other secret ([PAS §10]) — no database-specific exception. |

---

## 20. Future Scalability

| Capability | Database-level implication | Tier |
|---|---|---|
| **AI** | No special schema change — structured, well-typed data (already this document's default posture) is what makes data AI-consumable later; the risk to avoid is dumping business data into JSONB "for flexibility" and losing that property ([§9]). | **[Future Vision]** enabler, built in by default now |
| **OCR** | Needs the File Storage / file-metadata entity ([§15]) as its landing zone, feeding structured output into existing domain tables — no new database paradigm. | **[Future Vision]**, entity introduced earlier per [§15] |
| **Analytics** | A read replica (native Postgres streaming replication, available from most managed providers) to isolate analytical load from transactional writes, or the CQRS-lite read-model option already named in [PAS §13]. | **[Future Vision]** — not needed at MVP volumes |
| **Reporting** | Set-based aggregation discipline ([§14]) is the near-term enabler; a dedicated read model only if Analytics genuinely needs one. | **[Build Now]** discipline, **[Future Vision]** infrastructure |
| **Integrations** | Webhook/integration event data follows every standard in this document — no special-case tables. | **[Future Vision]** |
| **Multi-region** | Two distinct paths: read replicas in additional regions for latency (data still single-sourced), or full tenant-region sharding (each Tenant's data pinned to a home region) — the latter is a Horizon-2-scale undertaking, realistically only triggered by geographic expansion beyond the UAE, not by scale alone. | **[Future Vision]**, not a near-term concern |

---

## 21. Database Design Checklist

Every future table must satisfy this before implementation:

- [ ] Has a UUID surrogate primary key ([§5])
- [ ] Has `tenantId` if tenant-owned; correctly has none if Platform-Global/Shared-Reference ([§3]/[§7])
- [ ] Has `createdAt`; has `updatedAt` unless genuinely immutable/append-only ([§7])
- [ ] Every foreign key column has an explicit index ([§13])
- [ ] Every foreign key's cascade behavior (`RESTRICT`/`CASCADE`/`SET NULL`) was deliberately chosen, not left as a default ([§8])
- [ ] Money fields use `Decimal`/`NUMERIC`, never floating point ([§9])
- [ ] Date-only values use `date`; timestamp values use `timestamptz` ([§9])
- [ ] `deletedAt` is present only if the entity has a genuine delete/restore lifecycle ([§10])
- [ ] Business-uniqueness constraints are tenant-scoped composite uniques unless deliberately platform-global ([§13])
- [ ] Table, column, and constraint names follow [§6]'s standard
- [ ] No business rule is duplicated into a database trigger or constraint that belongs in the service layer ([§16])
- [ ] The table's owning module/platform-service is documented ([§4])
- [ ] The enum-vs-lookup-table choice was made deliberately, not defaulted ([§6]/[§9])
- [ ] If the table stores files, it stores only metadata/references, never file bytes ([§15])
- [ ] The migration adding it is additive and safe for a currently-deployed application ([§17])

---

## 22. Open Database Decisions

Each requires its own ADR or explicit product decision before the dependent work proceeds — none are defaulted by this document.

| # | Decision | Depends on / blocks |
|---|---|---|
| 1 | UUIDv4 vs. UUIDv7 for primary keys | Real write-volume data to justify the change; [§2] |
| 2 | Adopting Prisma multi-schema (Postgres schema-per-module) as database-level enforcement of module ownership | [§4]; a real, deliberate migration, not a default |
| 3 | Reconciling Module 0's existing table/column identifiers with this document's `@@map`-based snake_case standard | [§6]; backward-compatibility question for already-shipped tables |
| 4 | Row-Level Security policy design and activation timing relative to the Postgres migration | [PAS §25 Decision 4]; [§3] |
| 5 | Whether `User.email` should remain globally unique once the Firm/multi-Tenant access model is resolved | [PAS §25 Decision 1]; [§13] — a concrete database consequence of that still-open decision |
| 6 | PDPL right-to-erasure vs. FTA retention-period conflict resolution | [MPS §23 Decision 5]; [§10] hard-delete policy |
| 7 | Column-level encryption scope, contingent on the PDPL research outcome | [§19]; decision 6 above |
| 8 | Database role/credential separation (application vs. analytics vs. migration) timing | [§19] |
| 9 | Trigger criteria for read-replica or multi-region investment | [§20]; should be decided as policy before ever needed reactively, echoing [PAS §25 Decision 7]'s service-extraction guidance |

---

This specification is the standard every future migration is checked against — via [§21]'s checklist at minimum. Where a module's real needs genuinely require deviating from a rule here, that deviation is proposed and explained before it's built, per [ADR §13.3], not discovered in review after the fact.
