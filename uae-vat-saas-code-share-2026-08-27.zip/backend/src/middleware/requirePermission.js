const ApiError = require("../utils/ApiError");
const { hasPermission } = require("../services/permission.service");
const { isActionEnabled } = require("../services/plan.service");

// Factory - requirePermission("invoices.send") returns middleware checking
// the permission Set requireTenantUser already resolved onto req.tenantUser.
// Always chained AFTER requireTenantUser, never a replacement for it - this
// only answers "can this identity do this," it never re-verifies identity or
// tenant scoping. The one decision point every module calls, per
// docs/master-product-specification.md §14 - never a role-string comparison
// inline in a controller.
//
// Plan + RBAC combined enforcement (2026-08-09) - the SAME key doubles as
// the moduleAccess lookup ("module.action" is the format both RBAC
// Permission.key and Plan Builder's moduleAccess already use, see
// permissionCatalog.js/plan.service.js), so no second key vocabulary was
// introduced. RBAC is still checked first and still produces the exact same
// error it always did for a plain permission miss; the Plan check is purely
// additive on top of it, reading req.tenantModuleAccess (already resolved
// once in requireTenantUser, no extra query here). Applying this at this
// one shared choke point - every route in every module already calls
// requirePermission() - means Invoices/Purchases/Credit Notes/Debit Notes/
// Imports/VAT Returns/etc. all get Plan-gating for free, with zero changes
// to any of those routes individually.
function requirePermission(key) {
  return function (req, res, next) {
    if (!hasPermission(req, key)) {
      throw new ApiError(403, `Missing permission: ${key}`);
    }
    const [module, action] = key.split(".");
    if (!isActionEnabled(req.tenantModuleAccess, module, action)) {
      throw new ApiError(403, `This feature isn't included in your current plan: ${key}`);
    }
    next();
  };
}

module.exports = requirePermission;
