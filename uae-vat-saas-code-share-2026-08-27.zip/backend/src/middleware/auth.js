const ApiError = require("../utils/ApiError");
const {
  verifyPlatformAdminToken,
  verifyTenantUserToken,
} = require("../utils/jwt");
const { getEffectivePermissions } = require("../services/permission.service");
const { getModuleAccess } = require("../services/plan.service");

function getBearerToken(req) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) return null;
  return token;
}

// Guards routes that only the Platform Admin (me) may call, e.g. creating
// Tenants, changing plans, suspending accounts.
function requirePlatformAdmin(req, res, next) {
  const token = getBearerToken(req);
  if (!token) throw new ApiError(401, "Missing platform admin token");

  try {
    const payload = verifyPlatformAdminToken(token);
    req.platformAdmin = { id: payload.sub, email: payload.email };
    next();
  } catch (err) {
    throw new ApiError(401, "Invalid or expired platform admin token");
  }
}

// Routes reachable even while a token's mustChangePassword claim is true -
// deliberately tiny allowlist, checked against req.originalUrl (stable
// regardless of which router mounted this middleware, unlike req.path)
// rather than by touching every other route file's permission wiring.
const PASSWORD_CHANGE_ALLOWLIST = ["/api/tenant/change-password", "/api/tenant/me/permissions"];

// Guards routes only a logged-in Tenant user (Owner or Staff) may call.
// Also enforces that the Tenant hasn't been suspended since the token was
// issued - a suspended Tenant's users must be locked out immediately.
async function requireTenantUser(req, res, next) {
  const token = getBearerToken(req);
  if (!token) throw new ApiError(401, "Missing tenant user token");

  let payload;
  try {
    payload = verifyTenantUserToken(token);
  } catch (err) {
    throw new ApiError(401, "Invalid or expired tenant user token");
  }

  const prisma = require("../config/prisma");
  const tenant = await prisma.tenant.findUnique({ where: { id: payload.tenantId } });
  if (!tenant || tenant.status === "SUSPENDED") {
    throw new ApiError(403, "This Tenant account is suspended");
  }

  // Forced password change (2026-08-09) - a temporary-password account is
  // blocked from every tenant endpoint except the tiny allowlist above
  // until they successfully change it. Checked from the JWT claim (set at
  // sign time), not a fresh DB read, matching every other claim already
  // trusted from this token.
  if (payload.mustChangePassword) {
    const requestPath = (req.originalUrl || "").split("?")[0];
    if (!PASSWORD_CHANGE_ALLOWLIST.includes(requestPath)) {
      throw new ApiError(403, "You must change your temporary password before continuing");
    }
  }

  // req.tenantId is the ONLY thing every downstream query should filter by.
  // Never trust a tenantId from the request body/params for data access.
  req.tenantId = payload.tenantId;
  // permissions + moduleAccess resolved once here, in parallel - permissions
  // via permission.service.js (RBAC module, 2026-08-06), moduleAccess via
  // plan.service.js (Plan + RBAC combined enforcement, 2026-08-09) - so
  // every requirePermission() check downstream is two plain lookups, never
  // a re-query. `role` (legacy OWNER|STAFF string) is kept on req.tenantUser
  // for anything not yet migrated to the permission engine - never dropped,
  // never re-purposed.
  const [permissions, tenantModuleAccess] = await Promise.all([getEffectivePermissions(payload.sub), getModuleAccess(tenant.plan)]);
  req.tenantUser = {
    id: payload.sub,
    role: payload.role,
    email: payload.email,
    permissions,
  };
  req.tenantModuleAccess = tenantModuleAccess;
  // req.tenant: the already-fetched row above, reused so controllers that
  // need Business Profile fields (e.g. Invoice's business snapshot) don't
  // have to re-query it themselves.
  req.tenant = tenant;
  next();
}

function requireOwnerRole(req, res, next) {
  if (req.tenantUser?.role !== "OWNER") {
    throw new ApiError(403, "This action requires the Tenant Owner role");
  }
  next();
}

module.exports = {
  requirePlatformAdmin,
  requireTenantUser,
  requireOwnerRole,
};
