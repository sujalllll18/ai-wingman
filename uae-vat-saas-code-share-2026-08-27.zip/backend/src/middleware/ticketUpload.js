const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const ApiError = require("../utils/ApiError");

// Shared multer config for ticket attachments/screenshots - used by both
// ticket.routes.js (tenant) and platformAdmin.routes.js (support team), so
// the upload rules (disk location, mime types, size limit) live in exactly
// one place. Same disk-storage/random-filename pattern as purchase.routes.js.
const ALLOWED_MIME_TYPES = [
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "text/plain",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
];

const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "..", "uploads", "tickets"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});

const ticketUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new ApiError(400, "That file type isn't supported"));
    }
    cb(null, true);
  },
});

module.exports = ticketUpload;
