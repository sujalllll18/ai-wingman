const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { resolveTax } = require("../services/taxResolver");
const { calculateInvoiceTotals, round2 } = require("../services/invoiceCalc");
const { resolveVendor } = require("../services/vendorResolver");
const { extractPurchaseData } = require("../services/ocrService");

const VALID_PAYMENT_STATUSES = ["UNPAID", "PARTIALLY_PAID", "PAID"];
const VALID_PAYMENT_METHODS = ["CASH", "BANK_TRANSFER", "CARD", "CHEQUE", "OTHER"];
const VALID_ACTIVITY_TYPES = ["DOWNLOADED", "PREVIEWED"];

// Same "always return the full shape" rule as Invoice's FULL_INCLUDE - every
// mutating endpoint returns this so the frontend's setPurchase(response...)
// is always safe, never a partial object missing lists that genuinely exist.
const FULL_INCLUDE = {
  lineItems: { orderBy: { sortOrder: "asc" } },
  // Legacy relation - see invoice.controller.js's identical comment on its
  // own FULL_INCLUDE. No longer the display source, see below.
  payments: { orderBy: { paymentDate: "desc" } },
  // Phase 2 Payments module (2026-08-22) - real source for the Purchase
  // detail page's Payments card, supplier-side mirror of Invoice's own.
  purchasePaymentAllocations: {
    include: { purchasePayment: { select: { id: true, paymentNumberDisplay: true, paymentDate: true, method: true, reference: true, status: true, currency: true, reconciliationStatus: true } } },
    orderBy: { createdAt: "desc" },
  },
  activities: { orderBy: { createdAt: "desc" } },
  attachments: { orderBy: { createdAt: "desc" } },
};

// Reconciliation Engine (Phase 4, 2026-08-23) - vendor-side mirror of
// invoice.controller.js's deriveInvoiceReconciliationSummary, same reasoning.
function derivePurchaseReconciliationSummary(purchase) {
  const confirmed = (purchase.purchasePaymentAllocations || []).filter((a) => a.purchasePayment?.status === "CONFIRMED");
  if (confirmed.length === 0) return "NOT_PAID";
  const statuses = new Set(confirmed.map((a) => a.purchasePayment.reconciliationStatus));
  if (statuses.size === 1 && statuses.has("RECONCILED")) return "RECONCILED";
  if (statuses.has("RECONCILED") || statuses.has("PARTIALLY_RECONCILED")) return "PARTIALLY_RECONCILED";
  return "UNRECONCILED";
}

function assertDraft(bill) {
  if (bill.status !== "DRAFT") {
    throw new ApiError(409, "This purchase bill is no longer a Draft and can't be edited");
  }
}

function logActivity(tx, purchaseBillId, type, description) {
  return tx.purchaseActivity.create({ data: { purchaseBillId, type, description: description || null } });
}

// Derives UNPAID/PARTIALLY_PAID/PAID purely from amountPaid vs grandTotal -
// same rule as Invoice's derivePaymentStatus, no Bad Debt equivalent (that's
// a receivables concept - not modeled for a payable).
function derivePaymentStatus(amountPaid, grandTotal) {
  if (amountPaid <= 0) return "UNPAID";
  if (amountPaid >= grandTotal) return "PAID";
  return "PARTIALLY_PAID";
}

// Freeform line items only - Product & Service Master represents what the
// tenant sells, not what a vendor sells them, so there's no material lookup
// here (unlike Invoice's resolveLineItemSnapshot). Tax Category/percentage
// still resolves through the same resolveTax() service - Tax Master stays
// the single source of truth for every percentage in Ledger.
// asOfDate (Import Framework, 2026-08-09) - defaults to "now" so every
// pre-existing call site (manual entry, OCR confirm) is unaffected; the
// importer passes the bill's real historical purchaseDate, matching
// invoice.controller.js's resolveLineItemSnapshot fix for the same reason.
async function resolvePurchaseLineItemSnapshot(tenantId, input, asOfDate = new Date()) {
  const description = input.description?.trim();
  if (!description) throw new ApiError(400, "Line item description is required");

  const unitPrice = Number(input.unitPrice);
  if (Number.isNaN(unitPrice) || unitPrice < 0) {
    throw new ApiError(400, "Line item unit price must be a non-negative number");
  }
  const quantity = Number(input.quantity);
  if (!quantity || Number.isNaN(quantity) || quantity <= 0) {
    throw new ApiError(400, "Line item quantity must be a positive number");
  }

  let taxSnapshot = { taxCategoryId: null, taxRateId: null, taxRateName: null, taxPercentage: 0, taxCalculationMethod: "EXCLUSIVE" };
  if (input.taxCategoryId) {
    const category = await prisma.taxCategory.findFirst({ where: { id: input.taxCategoryId, tenantId } });
    if (!category) throw new ApiError(400, "taxCategoryId does not refer to a tax category on this tenant");
    const resolved = await resolveTax(tenantId, input.taxCategoryId, asOfDate);
    if (!resolved) {
      const whenLabel = asOfDate.toDateString() === new Date().toDateString() ? "as of today" : `as of ${asOfDate.toISOString().slice(0, 10)}`;
      throw new ApiError(400, `No active tax rate covers "${category.name}" ${whenLabel} - fix Tax Master before pricing this line`);
    }
    taxSnapshot = {
      taxCategoryId: input.taxCategoryId,
      taxRateId: resolved.taxRateId,
      taxRateName: resolved.taxRateName,
      taxPercentage: resolved.percentage,
      taxCalculationMethod: resolved.calculationMethod,
    };
  }

  return {
    description,
    quantity,
    unitPrice,
    sortOrder: input.sortOrder ?? 0,
    ...taxSnapshot,
  };
}

// Recomputes every line item's totals + the bill's header totals. Purchase
// Bills never have a header discount (out of the confirmed scope), so this
// calls the exact same calculateInvoiceTotals() Invoice uses with an empty
// discount object - the pro-rata-share math just always comes out zero.
async function recomputeAndPersist(tx, purchaseBillId) {
  const bill = await tx.purchaseBill.findUnique({ where: { id: purchaseBillId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  const result = calculateInvoiceTotals(bill.lineItems, {});

  for (const line of result.lines) {
    await tx.purchaseLineItem.update({
      where: { id: line.id },
      data: {
        lineNetAmount: line.lineNetAmount,
        lineTaxableAmount: line.lineTaxableAmount,
        lineTaxAmount: line.lineTaxAmount,
        lineTotal: line.lineTotal,
      },
    });
  }

  return tx.purchaseBill.update({
    where: { id: purchaseBillId },
    data: {
      subtotal: result.subtotal,
      vatTotal: result.vatTotal,
      grandTotal: result.grandTotal,
      outstandingAmount: round2(result.grandTotal - bill.amountPaid),
    },
    include: FULL_INCLUDE,
  });
}

// Shared by manual creation and OCR-confirm - the only difference between
// the two entry points is where `input` came from and whether an
// attachment/OCR provenance is attached. Vendor resolution always runs
// (unlike Invoice's Customer, which permits a pure-manual no-record entry) -
// per the confirmed Purchase design, every Purchase Bill ends up linked to a
// real Vendor row, created silently if it didn't already exist.
async function createPurchaseBillTx(tx, tenantId, input) {
  const { vendor, matchedBy } = await resolveVendor(tx, tenantId, { name: input.vendorName, trn: input.vendorTrn });

  // Tax resolves as-of purchaseDate (the date vatReturnCalc.js actually
  // buckets this bill by), not invoiceDate or "today" - matters once
  // historical import can pass a real backdated purchaseDate.
  const asOfDate = input.purchaseDate ? new Date(input.purchaseDate) : new Date();
  const resolvedLines = [];
  for (const [i, item] of (input.lineItems || []).entries()) {
    resolvedLines.push(await resolvePurchaseLineItemSnapshot(tenantId, { ...item, sortOrder: i }, asOfDate));
  }

  const created = await tx.purchaseBill.create({
    data: {
      tenantId,
      vendorId: vendor.id,
      vendorName: vendor.name,
      vendorAddress: input.vendorAddress !== undefined ? input.vendorAddress || null : vendor.address,
      vendorTrn: vendor.trn,
      supplierInvoiceNumber: input.supplierInvoiceNumber || null,
      invoiceDate: input.invoiceDate ? new Date(input.invoiceDate) : null,
      purchaseDate: input.purchaseDate ? new Date(input.purchaseDate) : new Date(),
      currency: input.currency || "AED",
      notes: input.notes || null,
      sourceType: input.sourceType || "MANUAL",
      ocrConfidence: input.ocrConfidence ?? null,
      ocrRawExtraction: input.ocrRawExtraction || null,
      // Import batch traceability (Import Framework, 2026-08-09) - null for
      // every existing MANUAL/OCR_UPLOAD caller, unchanged.
      importBatchId: input.importBatchId || null,
      lineItems: { create: resolvedLines },
      ...(input.attachment
        ? {
            attachments: {
              create: [
                {
                  fileName: input.attachment.fileName,
                  fileUrl: input.attachment.fileUrl,
                  mimeType: input.attachment.mimeType,
                  fileSize: input.attachment.fileSize,
                  isSourceDocument: true,
                },
              ],
            },
          }
        : {}),
    },
  });

  await logActivity(tx, created.id, matchedBy === "created" ? "VENDOR_CREATED" : "VENDOR_LINKED", vendor.name);
  if (input.sourceType === "OCR_UPLOAD") {
    await logActivity(tx, created.id, "OCR_EXTRACTED", `Confidence ${Math.round((input.ocrConfidence || 0) * 100)}%`);
  }
  await logActivity(tx, created.id, "CREATED", null);

  return recomputeAndPersist(tx, created.id);
}

// GET /api/tenant/purchases
async function listPurchases(req, res) {
  const wantArchived = req.query.archived === "true";
  const purchases = await prisma.purchaseBill.findMany({
    where: { tenantId: req.tenantId, archivedAt: wantArchived ? { not: null } : null },
    include: { lineItems: { select: { id: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ purchases });
}

// POST /api/tenant/purchases - manual entry, the alternative path alongside
// OCR upload. Same vendor auto-resolution as the OCR-confirm path.
async function createPurchase(req, res) {
  const { vendorName, vendorAddress, vendorTrn, supplierInvoiceNumber, invoiceDate, purchaseDate, currency, notes, lineItems } = req.body;
  if (!vendorName?.trim()) throw new ApiError(400, "Vendor name is required (select a Vendor or enter one manually)");

  const purchase = await prisma.$transaction((tx) =>
    createPurchaseBillTx(tx, req.tenantId, {
      vendorName,
      vendorAddress,
      vendorTrn,
      supplierInvoiceNumber,
      invoiceDate,
      purchaseDate,
      currency,
      notes,
      lineItems,
      sourceType: "MANUAL",
    })
  );

  res.status(201).json({ purchase });
}

// GET /api/tenant/purchases/:id
async function getPurchase(req, res) {
  const purchase = await prisma.purchaseBill.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: FULL_INCLUDE,
  });
  if (!purchase) throw new ApiError(404, "Purchase bill not found");
  res.json({ purchase: { ...purchase, reconciliationSummary: derivePurchaseReconciliationSummary(purchase) } });
}

// PATCH /api/tenant/purchases/:id
async function updatePurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);

  const { vendorName, vendorAddress, vendorTrn, supplierInvoiceNumber, invoiceDate, purchaseDate, currency, notes } = req.body;

  const purchase = await prisma.$transaction(async (tx) => {
    let vendorData = {};
    if (vendorName !== undefined) {
      const { vendor, matchedBy } = await resolveVendor(tx, req.tenantId, { name: vendorName, trn: vendorTrn });
      vendorData = { vendorId: vendor.id, vendorName: vendor.name, vendorTrn: vendor.trn };
      if (vendor.id !== existing.vendorId) await logActivity(tx, existing.id, matchedBy === "created" ? "VENDOR_CREATED" : "VENDOR_LINKED", vendor.name);
    }

    await tx.purchaseBill.update({
      where: { id: existing.id },
      data: {
        ...vendorData,
        ...(vendorAddress !== undefined ? { vendorAddress: vendorAddress || null } : {}),
        ...(supplierInvoiceNumber !== undefined ? { supplierInvoiceNumber: supplierInvoiceNumber || null } : {}),
        ...(invoiceDate !== undefined ? { invoiceDate: invoiceDate ? new Date(invoiceDate) : null } : {}),
        ...(purchaseDate !== undefined ? { purchaseDate: purchaseDate ? new Date(purchaseDate) : new Date() } : {}),
        ...(currency !== undefined ? { currency } : {}),
        ...(notes !== undefined ? { notes: notes || null } : {}),
      },
    });
    await logActivity(tx, existing.id, "EDITED", null);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ purchase });
}

// POST /api/tenant/purchases/:id/line-items
async function addLineItem(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);

  const snapshot = await resolvePurchaseLineItemSnapshot(req.tenantId, { ...req.body, sortOrder: existing.lineItems.length }, existing.purchaseDate);

  const purchase = await prisma.$transaction(async (tx) => {
    await tx.purchaseLineItem.create({ data: { purchaseBillId: existing.id, ...snapshot } });
    await logActivity(tx, existing.id, "EDITED", `Added line: ${snapshot.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.status(201).json({ purchase });
}

// PATCH /api/tenant/purchases/:id/line-items/:lineId
async function updateLineItem(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);

  const line = await prisma.purchaseLineItem.findFirst({ where: { id: req.params.lineId, purchaseBillId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const snapshot = await resolvePurchaseLineItemSnapshot(req.tenantId, {
    description: req.body.description !== undefined ? req.body.description : line.description,
    unitPrice: req.body.unitPrice !== undefined ? req.body.unitPrice : line.unitPrice,
    quantity: req.body.quantity !== undefined ? req.body.quantity : line.quantity,
    taxCategoryId: req.body.taxCategoryId !== undefined ? req.body.taxCategoryId : line.taxCategoryId,
    sortOrder: line.sortOrder,
  }, existing.purchaseDate);

  const purchase = await prisma.$transaction(async (tx) => {
    await tx.purchaseLineItem.update({ where: { id: line.id }, data: snapshot });
    await logActivity(tx, existing.id, "EDITED", `Updated line: ${snapshot.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ purchase });
}

// DELETE /api/tenant/purchases/:id/line-items/:lineId
async function deleteLineItem(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);

  const line = await prisma.purchaseLineItem.findFirst({ where: { id: req.params.lineId, purchaseBillId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const purchase = await prisma.$transaction(async (tx) => {
    await tx.purchaseLineItem.delete({ where: { id: line.id } });
    await logActivity(tx, existing.id, "EDITED", `Removed line: ${line.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ purchase });
}

// DELETE /api/tenant/purchases/:id - hard delete, Draft-only, same policy as Invoice.
async function deletePurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);

  await prisma.purchaseBill.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// POST /api/tenant/purchases/:id/record - the Purchase-domain equivalent of
// Invoice's Send: assigns the permanent sequential billNumber, freezes the
// document. Nothing about this bill is ever recomputed from Vendor/Tax
// Master again after this point.
// Factored out (Import Framework, 2026-08-09) so the numbering-assignment
// transaction has exactly one implementation, shared by the normal Record
// endpoint below and the import adapter (which creates an already-historical
// Draft via createPurchaseBillTx, then finalizes it in the same commit -
// Purchase isn't Maker-Checker-integrated at all today, so there's no
// executor layer to route through here, unlike Invoice.send).
async function recordPurchaseTx(tx, tenantId, purchaseBillId) {
  await recomputeAndPersist(tx, purchaseBillId);

  const tenant = await tx.tenant.update({
    where: { id: tenantId },
    data: { nextPurchaseNumber: { increment: 1 } },
  });
  const assignedNumber = tenant.nextPurchaseNumber - 1;
  const display = `PB-${String(assignedNumber).padStart(6, "0")}`;

  await logActivity(tx, purchaseBillId, "RECORDED", display);

  return tx.purchaseBill.update({
    where: { id: purchaseBillId },
    data: { billNumber: assignedNumber, billNumberDisplay: display, status: "RECORDED" },
    include: FULL_INCLUDE,
  });
}

async function recordPurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  assertDraft(existing);
  if (existing.lineItems.length === 0) throw new ApiError(400, "Add at least one line item before recording");

  const purchase = await prisma.$transaction((tx) => recordPurchaseTx(tx, req.tenantId, existing.id));

  res.json({ purchase });
}

// POST /api/tenant/purchases/:id/void
async function voidPurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (existing.status !== "RECORDED") throw new ApiError(409, "Only a Recorded purchase bill can be voided");

  const purchase = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "CANCELLED", null);
    return tx.purchaseBill.update({ where: { id: existing.id }, data: { status: "VOID" }, include: FULL_INCLUDE });
  });
  res.json({ purchase });
}

// PATCH /api/tenant/purchases/:id/payment-status - manual override, same
// role as Invoice's endpoint. No BAD_DEBT value here (payables concept doesn't apply).
async function updatePaymentStatus(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (existing.status !== "RECORDED") throw new ApiError(409, "Payment status only applies to a Recorded purchase bill");

  const { paymentStatus } = req.body;
  if (!VALID_PAYMENT_STATUSES.includes(paymentStatus)) {
    throw new ApiError(400, `paymentStatus must be one of ${VALID_PAYMENT_STATUSES.join(", ")}`);
  }

  const purchase = await prisma.purchaseBill.update({ where: { id: existing.id }, data: { paymentStatus }, include: FULL_INCLUDE });
  res.json({ purchase });
}

// Phase 2 Payments module (2026-08-22) - supplier-side mirror of
// invoice.controller.js's recalculatePaymentFields exactly. Single source of
// truth for amountPaid/outstandingAmount/paymentStatus, from the sum of this
// bill's CONFIRMED-payment PurchasePaymentAllocation rows.
async function recalculatePaymentFields(tx, purchaseBillId) {
  const bill = await tx.purchaseBill.findUnique({ where: { id: purchaseBillId } });
  const agg = await tx.purchasePaymentAllocation.aggregate({
    where: { purchaseBillId, purchasePayment: { status: "CONFIRMED" } },
    _sum: { allocatedAmount: true },
  });
  const amountPaid = round2(agg._sum.allocatedAmount || 0);
  const outstandingAmount = round2(Math.max(0, bill.grandTotal - amountPaid));
  const paymentStatus = derivePaymentStatus(amountPaid, bill.grandTotal);

  return tx.purchaseBill.update({
    where: { id: purchaseBillId },
    data: { amountPaid, outstandingAmount, paymentStatus },
    include: FULL_INCLUDE,
  });
}

// POST /api/tenant/purchases/:id/payments
// Same "unchanged contract, restructured internals" treatment as Invoice's
// own quick-pay action above - see recordPayment in invoice.controller.js.
async function recordPayment(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (existing.status !== "RECORDED") throw new ApiError(409, "Payments can only be recorded against a Recorded purchase bill");

  const { amount, paymentDate, method, reference, notes } = req.body;
  if (amount === undefined || amount === null || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
    throw new ApiError(400, "amount must be a positive number");
  }
  if (!paymentDate) throw new ApiError(400, "paymentDate is required");
  if (!VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  const purchase = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: req.tenantId }, data: { nextPurchasePaymentNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextPurchasePaymentNumber - 1;
    const display = `SPAY-${String(assignedNumber).padStart(6, "0")}`;

    const payment = await tx.purchasePayment.create({
      data: {
        tenantId: req.tenantId,
        vendorId: existing.vendorId,
        vendorName: existing.vendorName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        purchaseBillId: existing.id,
        amount: Number(amount),
        currency: existing.currency,
        paymentDate: new Date(paymentDate),
        method,
        reference: reference || null,
        notes: notes || null,
      },
    });
    await tx.purchasePaymentAllocation.create({ data: { purchasePaymentId: payment.id, purchaseBillId: existing.id, allocatedAmount: Number(amount) } });
    await tx.purchasePaymentActivity.create({
      data: { purchasePaymentId: payment.id, type: "CREATED", description: `${existing.currency} ${Number(amount).toFixed(2)} via ${method}, allocated to ${existing.billNumberDisplay || "this bill"}` },
    });

    await logActivity(tx, existing.id, "PAYMENT_RECORDED", `${existing.currency} ${Number(amount).toFixed(2)} via ${method}`);

    return recalculatePaymentFields(tx, existing.id);
  });

  res.status(201).json({ purchase });
}

// PATCH /api/tenant/purchases/:id/internal-notes
async function updateInternalNotes(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");

  const purchase = await prisma.purchaseBill.update({
    where: { id: existing.id },
    data: { internalNotes: req.body.internalNotes || null },
    include: FULL_INCLUDE,
  });
  res.json({ purchase });
}

// POST /api/tenant/purchases/:id/archive
async function archivePurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (existing.archivedAt) throw new ApiError(409, "Already archived");

  const purchase = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "ARCHIVED", null);
    return tx.purchaseBill.update({ where: { id: existing.id }, data: { archivedAt: new Date() }, include: FULL_INCLUDE });
  });
  res.json({ purchase });
}

// POST /api/tenant/purchases/:id/restore
async function restorePurchase(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (!existing.archivedAt) throw new ApiError(409, "Not archived");

  const purchase = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "RESTORED", null);
    return tx.purchaseBill.update({ where: { id: existing.id }, data: { archivedAt: null }, include: FULL_INCLUDE });
  });
  res.json({ purchase });
}

// POST /api/tenant/purchases/:id/duplicate - fresh Draft, vendor re-linked
// (not re-resolved by name/trn text - reuses the exact same vendorId so a
// duplicate never accidentally creates a second Vendor), tax re-resolved
// fresh per line, same as Invoice's duplicateInvoice. No billNumber unless
// this new Draft is itself Recorded.
async function duplicatePurchase(req, res) {
  const source = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  if (!source) throw new ApiError(404, "Purchase bill not found");

  const resolvedLines = [];
  for (const [i, li] of source.lineItems.entries()) {
    resolvedLines.push(
      await resolvePurchaseLineItemSnapshot(req.tenantId, {
        description: li.description,
        unitPrice: li.unitPrice,
        quantity: li.quantity,
        taxCategoryId: li.taxCategoryId,
        sortOrder: i,
      })
    );
  }

  const purchase = await prisma.$transaction(async (tx) => {
    const created = await tx.purchaseBill.create({
      data: {
        tenantId: req.tenantId,
        vendorId: source.vendorId,
        vendorName: source.vendorName,
        vendorAddress: source.vendorAddress,
        vendorTrn: source.vendorTrn,
        currency: source.currency,
        notes: source.notes,
        sourceType: "MANUAL",
        lineItems: { create: resolvedLines },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Duplicated from ${source.billNumberDisplay || "a draft"}`);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ purchase });
}

// POST /api/tenant/purchases/:id/activity - lets the Viewer log DOWNLOADED/PREVIEWED.
async function logPurchaseActivity(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.purchaseActivity.create({ data: { purchaseBillId: existing.id, type, description: description || null } });
  res.status(201).json({ activity });
}

// POST /api/tenant/purchases/ocr/extract - multipart upload (see
// purchase.routes.js multer config). Saves the file to disk and runs it
// through the placeholder OCR service, but creates NOTHING in the database
// yet - the Review Screen shows this extraction for the user to correct
// before anything is persisted as a real Purchase Bill (see ocr/confirm).
async function extractOcr(req, res) {
  if (!req.file) throw new ApiError(400, "No file uploaded");

  const extraction = await extractPurchaseData(req.file);
  const fileUrl = `/uploads/purchases/${req.file.filename}`;

  res.status(201).json({
    extraction,
    file: {
      fileName: req.file.originalname,
      fileUrl,
      mimeType: req.file.mimetype,
      fileSize: req.file.size,
    },
  });
}

// POST /api/tenant/purchases/ocr/confirm - the "User confirms before saving"
// step. Body carries whatever the user ended up with after editing the
// extraction from ocr/extract, plus the same `file` descriptor returned by
// that call (so the already-uploaded document gets attached, not re-uploaded).
async function confirmOcr(req, res) {
  const { vendorName, vendorTrn, supplierInvoiceNumber, invoiceDate, purchaseDate, currency, notes, lineItems, overallConfidence, rawExtraction, file } = req.body;
  if (!vendorName?.trim()) throw new ApiError(400, "Vendor name is required");
  if (!file?.fileUrl) throw new ApiError(400, "Missing uploaded file reference - re-upload the document");

  const purchase = await prisma.$transaction((tx) =>
    createPurchaseBillTx(tx, req.tenantId, {
      vendorName,
      vendorTrn,
      supplierInvoiceNumber,
      invoiceDate,
      purchaseDate,
      currency,
      notes,
      lineItems,
      sourceType: "OCR_UPLOAD",
      ocrConfidence: overallConfidence !== undefined ? Number(overallConfidence) : null,
      ocrRawExtraction: rawExtraction ? JSON.stringify(rawExtraction) : null,
      attachment: file,
    })
  );

  res.status(201).json({ purchase });
}

// POST /api/tenant/purchases/:id/attachments - manual addition of a further
// attachment (e.g. a delivery note) after the bill already exists. Uses the
// same multer disk storage as the OCR upload endpoint.
async function addAttachment(req, res) {
  const existing = await prisma.purchaseBill.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Purchase bill not found");
  if (!req.file) throw new ApiError(400, "No file uploaded");

  const attachment = await prisma.purchaseAttachment.create({
    data: {
      purchaseBillId: existing.id,
      fileName: req.file.originalname,
      fileUrl: `/uploads/purchases/${req.file.filename}`,
      mimeType: req.file.mimetype,
      fileSize: req.file.size,
      isSourceDocument: false,
    },
  });
  res.status(201).json({ attachment });
}

module.exports = {
  listPurchases,
  createPurchase,
  getPurchase,
  updatePurchase,
  addLineItem,
  updateLineItem,
  deleteLineItem,
  deletePurchase,
  recordPurchase,
  voidPurchase,
  updatePaymentStatus,
  recordPayment,
  updateInternalNotes,
  archivePurchase,
  restorePurchase,
  duplicatePurchase,
  logPurchaseActivity,
  extractOcr,
  confirmOcr,
  addAttachment,
  // Exported for importAdapters.js's Purchase Bill adapter - the exact same
  // creation/finalize helpers manual entry and OCR-confirm already share,
  // not a copy.
  createPurchaseBillTx,
  resolvePurchaseLineItemSnapshot,
  recordPurchaseTx,
  // Exported for purchasePayment.controller.js (Phase 2 Payments module,
  // 2026-08-22) - the exact same balance-derivation helper and activity
  // logger this file's own recordPayment uses, not copies.
  recalculatePaymentFields,
  logActivity,
};
