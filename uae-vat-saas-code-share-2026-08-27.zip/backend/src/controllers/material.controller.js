const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

function validateFields({ name, unit, defaultUnitPrice }, { requireCore }) {
  if (requireCore) {
    if (!name?.trim()) throw new ApiError(400, "Description is required");
    if (!unit?.trim()) throw new ApiError(400, "Unit is required");
    if (defaultUnitPrice === undefined || defaultUnitPrice === null || Number.isNaN(Number(defaultUnitPrice))) {
      throw new ApiError(400, "Selling price is required");
    }
  }
  if (defaultUnitPrice !== undefined && defaultUnitPrice !== null && Number(defaultUnitPrice) < 0) {
    throw new ApiError(400, "Selling price cannot be negative");
  }
}

// Validates defaultTaxCategoryId belongs to this tenant, if provided.
async function assertTaxCategoryBelongsToTenant(tenantId, defaultTaxCategoryId) {
  if (!defaultTaxCategoryId) return;
  const category = await prisma.taxCategory.findFirst({ where: { id: defaultTaxCategoryId, tenantId } });
  if (!category) throw new ApiError(400, "defaultTaxCategoryId does not refer to a tax category on this tenant");
}

// GET /api/tenant/materials
async function listMaterials(req, res) {
  const materials = await prisma.material.findMany({
    where: { tenantId: req.tenantId },
    include: { defaultTaxCategory: true },
    orderBy: { createdAt: "desc" },
  });
  res.json({ materials });
}

// POST /api/tenant/materials
async function createMaterial(req, res) {
  const { name, unit, defaultUnitPrice, defaultTaxCategoryId } = req.body;
  validateFields({ name, unit, defaultUnitPrice }, { requireCore: true });
  await assertTaxCategoryBelongsToTenant(req.tenantId, defaultTaxCategoryId);

  const material = await prisma.material.create({
    data: {
      tenantId: req.tenantId,
      name: name.trim(),
      unit: unit.trim(),
      defaultUnitPrice: Number(defaultUnitPrice),
      defaultTaxCategoryId: defaultTaxCategoryId || null,
    },
    include: { defaultTaxCategory: true },
  });
  res.status(201).json({ material });
}

// GET /api/tenant/materials/:id
async function getMaterial(req, res) {
  const material = await prisma.material.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { defaultTaxCategory: true },
  });
  if (!material) throw new ApiError(404, "Material not found");
  res.json({ material });
}

// PATCH /api/tenant/materials/:id
async function updateMaterial(req, res) {
  const existing = await prisma.material.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
  });
  if (!existing) throw new ApiError(404, "Material not found");

  const { name, unit, defaultUnitPrice, defaultTaxCategoryId } = req.body;
  validateFields({ name, unit, defaultUnitPrice }, { requireCore: false });
  if (defaultTaxCategoryId !== undefined) {
    await assertTaxCategoryBelongsToTenant(req.tenantId, defaultTaxCategoryId);
  }

  const material = await prisma.material.update({
    where: { id: existing.id },
    data: {
      ...(name !== undefined ? { name: name.trim() } : {}),
      ...(unit !== undefined ? { unit: unit.trim() } : {}),
      ...(defaultUnitPrice !== undefined ? { defaultUnitPrice: Number(defaultUnitPrice) } : {}),
      ...(defaultTaxCategoryId !== undefined ? { defaultTaxCategoryId: defaultTaxCategoryId || null } : {}),
    },
    include: { defaultTaxCategory: true },
  });
  res.json({ material });
}

module.exports = { listMaterials, createMaterial, getMaterial, updateMaterial };
