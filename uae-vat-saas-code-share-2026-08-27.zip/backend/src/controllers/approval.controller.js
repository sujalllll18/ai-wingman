const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { APPROVABLE_PERMISSIONS } = require("../config/permissionCatalog");
const { hasPermission } = require("../services/permission.service");
const engine = require("../services/approvalEngine.service");

// GET /api/tenant/approvals
async function listQueue(req, res) {
  const { module, mine } = req.query;
  const requests = await engine.listQueue({
    tenantId: req.tenantId,
    module: module || undefined,
    mine: mine === "true" ? req.tenantUser.id : undefined,
  });
  res.json({ approvalRequests: requests });
}

// GET /api/tenant/approvals/history
async function listHistory(req, res) {
  const { module } = req.query;
  const requests = await engine.listHistory({ tenantId: req.tenantId, module: module || undefined });
  res.json({ approvalRequests: requests });
}

// GET /api/tenant/approvals/:id
async function getRequest(req, res) {
  const request = await engine.getRequest({ tenantId: req.tenantId, id: req.params.id });
  res.json({ approvalRequest: request });
}

// The generic /approve and /reject endpoints span every module, so the
// permission actually enforced ("<module>.approve"/"<module>.reject")
// depends on the request being decided, which is only known once it's
// loaded - unlike every other route in this app, it can't be a static
// requirePermission(key) in the route file. This is the one deliberate
// exception; RBAC still decides WHO, just checked dynamically here instead
// of in middleware.
function assertCanDecide(req, module, decision) {
  const key = `${module}.${decision === "APPROVE" ? "approve" : "reject"}`;
  if (!hasPermission(req, key)) {
    throw new ApiError(403, `Missing permission: ${key}`);
  }
}

// POST /api/tenant/approvals/:id/approve
async function approveRequest(req, res) {
  const request = await prisma.approvalRequest.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!request) throw new ApiError(404, "Approval request not found");
  assertCanDecide(req, request.module, "APPROVE");

  const updated = await engine.decide({
    approvalRequestId: req.params.id,
    tenantId: req.tenantId,
    deciderUserId: req.tenantUser.id,
    decision: "APPROVE",
    comments: req.body?.comments || null,
  });
  res.json({ approvalRequest: updated });
}

// POST /api/tenant/approvals/:id/reject
async function rejectRequest(req, res) {
  const request = await prisma.approvalRequest.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!request) throw new ApiError(404, "Approval request not found");
  assertCanDecide(req, request.module, "REJECT");

  const updated = await engine.decide({
    approvalRequestId: req.params.id,
    tenantId: req.tenantId,
    deciderUserId: req.tenantUser.id,
    decision: "REJECT",
    comments: req.body?.comments || null,
  });
  res.json({ approvalRequest: updated });
}

// POST /api/tenant/approvals/:id/cancel - maker withdrawing their own request
async function cancelRequest(req, res) {
  const updated = await engine.cancel({ approvalRequestId: req.params.id, tenantId: req.tenantId, userId: req.tenantUser.id });
  res.json({ approvalRequest: updated });
}

// GET /api/tenant/approval-rules
// Returns every configurable (mutating-action) permission merged with the
// tenant's existing rule row, if any - a missing row means "Immediate
// Execution", not "not shown", so the screen always lists the full set.
async function listRules(req, res) {
  const rules = await prisma.permissionApprovalRule.findMany({
    where: { tenantId: req.tenantId },
    include: { approverRole: { select: { id: true, name: true } } },
  });
  const rulesByPermissionKey = new Map();
  for (const rule of rules) {
    const permission = await prisma.permission.findUnique({ where: { id: rule.permissionId } });
    if (permission) rulesByPermissionKey.set(permission.key, rule);
  }

  const merged = APPROVABLE_PERMISSIONS.map((p) => {
    const rule = rulesByPermissionKey.get(p.key);
    return {
      permissionKey: p.key,
      module: p.module,
      moduleLabel: p.moduleLabel,
      action: p.action,
      label: p.label,
      requiresApproval: rule?.requiresApproval ?? false,
      approverRoleId: rule?.approverRoleId ?? null,
      approverRoleName: rule?.approverRole?.name ?? null,
      makerCannotApproveOwn: rule?.makerCannotApproveOwn ?? true,
      isActive: rule?.isActive ?? true,
      thresholdValue: rule?.thresholdValue ?? null,
    };
  });

  res.json({ rules: merged });
}

// PUT /api/tenant/approval-rules/:permissionKey
async function upsertRule(req, res) {
  const permission = await prisma.permission.findUnique({ where: { key: req.params.permissionKey } });
  if (!permission) throw new ApiError(404, `Unknown permission key: ${req.params.permissionKey}`);

  const { requiresApproval, approverRoleId, makerCannotApproveOwn, isActive } = req.body;

  if (approverRoleId) {
    const role = await prisma.role.findFirst({ where: { id: approverRoleId, tenantId: req.tenantId } });
    if (!role) throw new ApiError(400, "approverRoleId does not belong to this tenant");
  }

  const rule = await prisma.permissionApprovalRule.upsert({
    where: { tenantId_permissionId: { tenantId: req.tenantId, permissionId: permission.id } },
    update: {
      requiresApproval: requiresApproval ?? false,
      approverRoleId: approverRoleId ?? null,
      makerCannotApproveOwn: makerCannotApproveOwn ?? true,
      isActive: isActive ?? true,
    },
    create: {
      tenantId: req.tenantId,
      permissionId: permission.id,
      requiresApproval: requiresApproval ?? false,
      approverRoleId: approverRoleId ?? null,
      makerCannotApproveOwn: makerCannotApproveOwn ?? true,
      isActive: isActive ?? true,
    },
    include: { approverRole: { select: { id: true, name: true } } },
  });

  res.json({ rule });
}

module.exports = {
  listQueue,
  listHistory,
  getRequest,
  approveRequest,
  rejectRequest,
  cancelRequest,
  listRules,
  upsertRule,
};
