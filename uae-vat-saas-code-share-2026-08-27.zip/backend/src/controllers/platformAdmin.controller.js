const bcrypt = require("bcrypt");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { signPlatformAdminToken } = require("../utils/jwt");
const { getPlanLimits, getActivePlanSlugs } = require("../config/plans");
const { seedSystemRolesForTenant, assignDefaultUserRole } = require("../services/roleSeed.service");
const { isStrongPassword, PASSWORD_REQUIREMENT_MESSAGE } = require("../utils/passwordPolicy");

// POST /api/platform-admin/login
async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) throw new ApiError(400, "email and password are required");

  const admin = await prisma.platformAdmin.findUnique({ where: { email } });
  if (!admin) throw new ApiError(401, "Invalid credentials");

  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) throw new ApiError(401, "Invalid credentials");

  const token = signPlatformAdminToken(admin);
  res.json({ token, admin: { id: admin.id, email: admin.email } });
}

// GET /api/platform-admin/tenants
// Dashboard list: plan, status, user count, invoice count per Tenant.
// Deliberately does NOT include Customers/Materials/Purchases/financial
// detail - Platform Admin sees management-level info only, per spec.
async function listTenants(req, res) {
  const tenants = await prisma.tenant.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      _count: { select: { users: true, invoices: true } },
    },
  });

  const shaped = tenants.map((t) => ({
    id: t.id,
    name: t.name,
    trn: t.trn,
    plan: t.plan,
    status: t.status,
    userCount: t._count.users,
    invoiceCount: t._count.invoices,
    createdAt: t.createdAt,
  }));

  res.json({ tenants: shaped });
}

// POST /api/platform-admin/tenants
// Creates a Tenant AND its mandatory Owner user in one transaction, so a
// Tenant can never exist without exactly one Owner.
async function createTenant(req, res) {
  const {
    name,
    address,
    trn,
    contactEmail,
    contactPhone,
    plan = "TRIAL",
    owner, // { name, email, password }
  } = req.body;

  if (!name) throw new ApiError(400, "Tenant name is required");
  const validPlans = await getActivePlanSlugs();
  if (!validPlans.includes(plan)) throw new ApiError(400, `plan must be one of ${validPlans.join(", ")}`);
  if (!owner?.name || !owner?.email || !owner?.password) {
    throw new ApiError(400, "owner.name, owner.email and owner.password are required");
  }
  if (!isStrongPassword(owner.password)) {
    throw new ApiError(400, PASSWORD_REQUIREMENT_MESSAGE);
  }

  const existingEmail = await prisma.user.findUnique({ where: { email: owner.email } });
  if (existingEmail) throw new ApiError(409, "A user with this email already exists");

  const passwordHash = await bcrypt.hash(owner.password, 10);
  // Temporary-password flow (2026-08-09) - defaults to true (matches the
  // wizard's own "Force password change on first login" checkbox, checked
  // by default) unless the caller explicitly opts out.
  const mustChangePassword = owner.forcePasswordChange !== false;

  const tenant = await prisma.$transaction(async (tx) => {
    const created = await tx.tenant.create({
      data: { name, address, trn, contactEmail, contactPhone, plan },
    });

    const ownerUser = await tx.user.create({
      data: {
        tenantId: created.id,
        name: owner.name,
        email: owner.email,
        passwordHash,
        role: "OWNER",
        mustChangePassword,
      },
    });

    // Seed the four default Tax Categories + their Tax Rates so Tax Master
    // (and everything that will resolve rates through it) has a starting
    // point without a manual "first-time setup" step. Standard Rated points
    // at the real 5% UAE VAT rate; the other three each get their own 0%
    // rate rather than sharing one, since UAE VAT returns report Zero
    // Rated/Exempt/Out of Scope supplies in different boxes even though the
    // number is the same.
    // classification (2026-08-03) feeds VAT Return bucketing directly -
    // these 4 seeded names/classifications are the canonical mapping;
    // anything a tenant creates later must be classified explicitly via the
    // Tax Master category form (see tax.controller.js).
    const seedCategories = [
      { name: "Standard Rated", rateName: "UAE Standard VAT", percentage: 5.0, classification: "STANDARD_RATED" },
      { name: "Zero Rated", rateName: "Zero Rated", percentage: 0, classification: "ZERO_RATED" },
      { name: "Exempt", rateName: "Exempt", percentage: 0, classification: "EXEMPT" },
      { name: "Out of Scope", rateName: "Out of Scope", percentage: 0, classification: "OUT_OF_SCOPE" },
    ];
    for (const seed of seedCategories) {
      const rate = await tx.taxRate.create({
        data: {
          tenantId: created.id,
          name: seed.rateName,
          percentage: seed.percentage,
          calculationMethod: "EXCLUSIVE",
          effectiveFrom: new Date(),
        },
      });
      await tx.taxCategory.create({
        data: { tenantId: created.id, name: seed.name, taxRateId: rate.id, classification: seed.classification },
      });
    }

    // RBAC (2026-08-06): seed the 8 system roles for this Tenant and assign
    // the new Owner their role, same pattern as the Tax Master default-seed
    // just above - not a separate onboarding step, part of Tenant creation.
    await seedSystemRolesForTenant(tx, created.id);
    await assignDefaultUserRole(tx, { userId: ownerUser.id, tenantId: created.id, legacyRole: "OWNER" });

    // Plan Builder (2026-08-07): give the new Tenant a real
    // TenantPlanAssignment pointing at its plan's current published
    // version, same as every pre-existing Tenant got via the one-time
    // backfill in prisma/seed-plans.js - otherwise a brand-new Tenant's
    // Subscription tab would show "no plan assignment yet" until an admin
    // manually assigned one.
    const planRecord = await tx.plan.findUnique({ where: { slug: plan } });
    if (planRecord) {
      const publishedVersion = await tx.planVersion.findFirst({ where: { planId: planRecord.id, status: "PUBLISHED" }, orderBy: { versionNumber: "desc" } });
      if (publishedVersion) {
        await tx.tenantPlanAssignment.create({ data: { tenantId: created.id, planVersionId: publishedVersion.id } });
      }
    }

    return created;
  });

  res.status(201).json({ tenant });
}

// PATCH /api/platform-admin/tenants/:id/plan
async function updateTenantPlan(req, res) {
  const { id } = req.params;
  const { plan } = req.body;
  const validPlans = await getActivePlanSlugs();
  if (!validPlans.includes(plan)) throw new ApiError(400, `plan must be one of ${validPlans.join(", ")}`);

  const tenant = await prisma.tenant.findUnique({ where: { id } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  // Guard: don't allow downgrading into a plan whose user limit the Tenant
  // already exceeds (e.g. Premium -> Trial with 4 users already active).
  const targetLimits = await getPlanLimits(plan);
  if (targetLimits.maxUsers !== null) {
    const userCount = await prisma.user.count({ where: { tenantId: id } });
    if (userCount > targetLimits.maxUsers) {
      throw new ApiError(
        409,
        `Cannot downgrade to ${plan}: Tenant has ${userCount} users, which exceeds the ${targetLimits.maxUsers}-user limit for this plan`
      );
    }
  }

  const updated = await prisma.tenant.update({ where: { id }, data: { plan } });
  res.json({ tenant: updated });
}

// PATCH /api/platform-admin/tenants/:id/suspend
async function suspendTenant(req, res) {
  const { id } = req.params;
  const tenant = await prisma.tenant.findUnique({ where: { id } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const updated = await prisma.tenant.update({
    where: { id },
    data: { status: "SUSPENDED" },
  });
  res.json({ tenant: updated });
}

// PATCH /api/platform-admin/tenants/:id/reactivate
async function reactivateTenant(req, res) {
  const { id } = req.params;
  const tenant = await prisma.tenant.findUnique({ where: { id } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const updated = await prisma.tenant.update({
    where: { id },
    data: { status: "ACTIVE" },
  });
  res.json({ tenant: updated });
}

// POST /api/platform-admin/tenants/:id/staff
// Staff creation is Platform Admin's job, not tenant self-service - per spec.
async function createStaffUser(req, res) {
  const { id } = req.params;
  const { name, email, password } = req.body;
  if (!name || !email || !password) throw new ApiError(400, "name, email and password are required");
  if (!isStrongPassword(password)) throw new ApiError(400, PASSWORD_REQUIREMENT_MESSAGE);

  const tenant = await prisma.tenant.findUnique({ where: { id } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const limits = await getPlanLimits(tenant.plan);
  if (limits.maxUsers !== null) {
    const userCount = await prisma.user.count({ where: { tenantId: id } });
    if (userCount >= limits.maxUsers) {
      throw new ApiError(
        409,
        `${tenant.plan} plan allows a maximum of ${limits.maxUsers} users for this Tenant`
      );
    }
  }

  const existingEmail = await prisma.user.findUnique({ where: { email } });
  if (existingEmail) throw new ApiError(409, "A user with this email already exists");

  const passwordHash = await bcrypt.hash(password, 10);
  // Same temporary-password convention as createTenant's owner - the
  // UsersTab form already labels this field "Temporary password".
  const user = await prisma.user.create({
    data: { tenantId: id, name, email, passwordHash, role: "STAFF", mustChangePassword: true },
  });

  // RBAC (2026-08-06): every new user gets a default UserRole immediately -
  // never left unresolved until someone remembers to assign one via the
  // Roles & Permissions UI. STAFF -> Administrator, see roleSeed.service.js
  // for why that's the correct default, not Team/Sales/etc.
  await assignDefaultUserRole(prisma, { userId: user.id, tenantId: id, legacyRole: "STAFF" });

  res.status(201).json({
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
}

// GET /api/platform-admin/tenants/:id/users
// The Owner is always created alongside the Tenant itself (see createTenant
// above); Staff are added via createStaffUser. Both are plain rows in the
// same User table, distinguished only by the legacy `role` string - this is
// just the first GET Platform Admin has ever had onto that table for a
// given Tenant. Same select-only, no-passwordHash query shape as
// tenantAuth.controller.js's listTeam (the tenant-self-service equivalent),
// scoped by the Tenant id in the URL instead of the caller's own JWT.
async function listTenantUsers(req, res) {
  const { id } = req.params;
  const tenant = await prisma.tenant.findUnique({ where: { id } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const users = await prisma.user.findMany({
    where: { tenantId: id },
    select: { id: true, name: true, email: true, role: true, lastLoginAt: true, createdAt: true, mustChangePassword: true },
    orderBy: { createdAt: "asc" },
  });

  res.json({ users });
}

// GET /api/platform-admin/tenants/:id/usage
async function getTenantUsage(req, res) {
  const { id } = req.params;

  const tenant = await prisma.tenant.findUnique({
    where: { id },
    include: { users: { select: { lastLoginAt: true } } },
  });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const [userCount, invoiceCount] = await Promise.all([
    prisma.user.count({ where: { tenantId: id } }),
    prisma.invoice.count({ where: { tenantId: id } }),
  ]);

  const lastLoginAt = tenant.users
    .map((u) => u.lastLoginAt)
    .filter(Boolean)
    .sort((a, b) => b - a)[0] || null;

  const limits = await getPlanLimits(tenant.plan);

  res.json({
    tenantId: tenant.id,
    plan: tenant.plan,
    status: tenant.status,
    userCount,
    userLimit: limits.maxUsers,
    invoiceCount,
    invoiceLimitPerMonth: limits.maxInvoicesPerMonth,
    lastLoginAt,
  });
}

module.exports = {
  login,
  listTenants,
  createTenant,
  updateTenantPlan,
  suspendTenant,
  reactivateTenant,
  createStaffUser,
  listTenantUsers,
  getTenantUsage,
};
