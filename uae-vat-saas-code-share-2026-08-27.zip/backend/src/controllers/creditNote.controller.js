const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { calculateInvoiceTotals, round2 } = require("../services/invoiceCalc");
const engine = require("../services/approvalEngine.service");

// Full response shape every mutating endpoint returns - same rule as
// Invoice/Purchase's FULL_INCLUDE, so the frontend's setCreditNote(response)
// is always safe to render directly.
const FULL_INCLUDE = {
  lineItems: { orderBy: { sortOrder: "asc" } },
  activities: { orderBy: { createdAt: "desc" } },
  // Every mutating endpoint (not just GET) must return `invoice` - the
  // frontend detail page renders a link to it unconditionally. Omitting
  // this from issue/void's response (while GET had it) caused a real crash:
  // the page briefly rendered `creditNote.invoice.id` against an
  // invoice-less object between the Issue response landing and the
  // follow-up load() completing.
  invoice: { select: { id: true, invoiceNumberDisplay: true, grandTotal: true, issueDate: true, currency: true } },
};

const VALID_ACTIVITY_TYPES = ["DOWNLOADED", "PREVIEWED"];

function assertDraft(creditNote) {
  if (creditNote.status !== "DRAFT") {
    throw new ApiError(409, "This credit note is no longer a Draft and can't be edited");
  }
}

function logActivity(tx, creditNoteId, type, description, actorId = null) {
  return tx.creditNoteActivity.create({ data: { creditNoteId, type, description: description || null, actorId } });
}

// Sum of grandTotal across every ISSUED credit note against this invoice
// (excluding the one being edited, if any) - the header-level cap.
async function sumIssuedAgainstInvoice(tx, invoiceId, excludeCreditNoteId = null) {
  const agg = await tx.creditNote.aggregate({
    where: { invoiceId, status: "ISSUED", ...(excludeCreditNoteId ? { id: { not: excludeCreditNoteId } } : {}) },
    _sum: { grandTotal: true },
  });
  return round2(agg._sum.grandTotal || 0);
}

// Sum of lineTotal across every ISSUED credit note's lines that reference
// this specific source Invoice line - the line-level cap.
async function sumIssuedAgainstInvoiceLine(tx, invoiceLineItemId, excludeCreditNoteId = null) {
  const lines = await tx.creditNoteLineItem.findMany({
    where: {
      invoiceLineItemId,
      creditNote: { status: "ISSUED", ...(excludeCreditNoteId ? { id: { not: excludeCreditNoteId } } : {}) },
    },
    select: { lineTotal: true },
  });
  return round2(lines.reduce((s, l) => s + l.lineTotal, 0));
}

// Validates the source Invoice is eligible to be credited at all: exists,
// belongs to this tenant, is Sent (not Draft, not Void). Returns the
// invoice with its line items included.
async function loadEligibleInvoice(tenantId, invoiceId) {
  const invoice = await prisma.invoice.findFirst({
    where: { id: invoiceId, tenantId },
    include: { lineItems: { orderBy: { sortOrder: "asc" } } },
  });
  if (!invoice) throw new ApiError(404, "Invoice not found");
  if (invoice.status === "DRAFT") throw new ApiError(409, "A Credit Note can't be raised against a Draft invoice - send it first");
  if (invoice.status === "VOID") throw new ApiError(409, "A Credit Note can't be raised against a cancelled invoice");
  return invoice;
}

// Resolves each requested line's snapshot by copying it from a matching
// Invoice line - never re-resolves tax via taxResolver.js. This is the
// load-bearing VAT rule for this whole feature.
function resolveNoteLineFromSource(invoice, input) {
  const quantity = Number(input.quantity);
  if (!quantity || Number.isNaN(quantity) || quantity <= 0) {
    throw new ApiError(400, "Line item quantity must be a positive number");
  }

  let sourceLine = null;
  if (input.invoiceLineItemId) {
    sourceLine = invoice.lineItems.find((li) => li.id === input.invoiceLineItemId);
    if (!sourceLine) throw new ApiError(400, "invoiceLineItemId does not refer to a line item on this invoice");
  } else if (input.taxCategoryId) {
    // Freeform line: the chosen category must have actually appeared on the
    // source invoice, so a Credit Note can never apply a VAT treatment the
    // original document never had. Copy that line's frozen rate.
    sourceLine = invoice.lineItems.find((li) => li.taxCategoryId === input.taxCategoryId);
    if (!sourceLine) throw new ApiError(400, "This tax category doesn't appear on the source invoice - pick one that was actually charged");
  } else if (invoice.lineItems.some((li) => li.taxCategoryId)) {
    throw new ApiError(400, "Select an original line item or a tax category that was used on the invoice");
  }

  const description = (input.description || sourceLine?.description || "").trim();
  if (!description) throw new ApiError(400, "Line item description is required");

  const unitPrice = input.unitPrice !== undefined ? Number(input.unitPrice) : Number(sourceLine?.unitPrice || 0);
  if (Number.isNaN(unitPrice) || unitPrice < 0) {
    throw new ApiError(400, "Line item unit price must be a non-negative number");
  }

  return {
    invoiceLineItemId: sourceLine?.id || null,
    description,
    quantity,
    unitPrice,
    sortOrder: input.sortOrder ?? 0,
    // Copied, never resolved:
    taxCategoryId: sourceLine?.taxCategoryId || null,
    taxRateId: sourceLine?.taxRateId || null,
    taxRateName: sourceLine?.taxRateName || null,
    taxPercentage: sourceLine?.taxPercentage || 0,
    taxCalculationMethod: sourceLine?.taxCalculationMethod || "EXCLUSIVE",
    _sourceLineTotal: sourceLine?.lineTotal ?? null,
  };
}

async function recomputeAndPersist(tx, creditNoteId) {
  const note = await tx.creditNote.findUnique({ where: { id: creditNoteId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  const result = calculateInvoiceTotals(note.lineItems, {});

  for (const line of result.lines) {
    await tx.creditNoteLineItem.update({
      where: { id: line.id },
      data: {
        lineNetAmount: line.lineNetAmount,
        lineTaxableAmount: line.lineTaxableAmount,
        lineTaxAmount: line.lineTaxAmount,
        lineTotal: line.lineTotal,
      },
    });
  }

  return tx.creditNote.update({
    where: { id: creditNoteId },
    data: { subtotal: result.subtotal, vatTotal: result.vatTotal, grandTotal: result.grandTotal },
    include: FULL_INCLUDE,
  });
}

// GET /api/tenant/credit-notes
async function listCreditNotes(req, res) {
  const notes = await prisma.creditNote.findMany({
    where: { tenantId: req.tenantId },
    include: { lineItems: { select: { id: true } }, invoice: { select: { id: true, invoiceNumberDisplay: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ creditNotes: notes });
}

// POST /api/tenant/credit-notes
// Body: { invoiceId, reason, issueDate?, notes?, lineItems: [{ invoiceLineItemId?, taxCategoryId?, description?, quantity, unitPrice? }] }
async function createCreditNote(req, res) {
  const { invoiceId, reason, issueDate, notes, lineItems } = req.body;
  if (!invoiceId) throw new ApiError(400, "invoiceId is required");
  if (!reason?.trim()) throw new ApiError(400, "A reason is required");
  if (!Array.isArray(lineItems) || lineItems.length === 0) throw new ApiError(400, "At least one line item is required");

  const invoice = await loadEligibleInvoice(req.tenantId, invoiceId);

  let resolvedIssueDate = new Date();
  if (issueDate) {
    resolvedIssueDate = new Date(issueDate);
    if (Number.isNaN(resolvedIssueDate.getTime())) throw new ApiError(400, "Invalid issueDate");
    if (invoice.issueDate && resolvedIssueDate < invoice.issueDate) {
      throw new ApiError(400, "Credit Note issue date can't be before the original invoice's issue date");
    }
  }

  const resolvedLines = lineItems.map((item, i) => resolveNoteLineFromSource(invoice, { ...item, sortOrder: i }));

  const creditNote = await prisma.$transaction(async (tx) => {
    // Header-level cap check at creation time too (not just at Issue) so a
    // Draft is never created already knowing it will be rejected.
    const alreadyIssued = await sumIssuedAgainstInvoice(tx, invoice.id);
    const proposedTotal = calculateInvoiceTotals(resolvedLines, {}).grandTotal;
    if (round2(alreadyIssued + proposedTotal) > round2(invoice.grandTotal) + 0.01) {
      throw new ApiError(409, `This exceeds the remaining eligible amount. Remaining: ${round2(invoice.grandTotal - alreadyIssued)} ${invoice.currency}`);
    }
    for (const line of resolvedLines) {
      if (line.invoiceLineItemId) {
        const alreadyLine = await sumIssuedAgainstInvoiceLine(tx, line.invoiceLineItemId);
        const lineTotal = calculateInvoiceTotals([line], {}).lines[0].lineTotal;
        if (round2(alreadyLine + lineTotal) > round2(line._sourceLineTotal) + 0.01) {
          throw new ApiError(409, `"${line.description}" exceeds the remaining eligible amount on that line`);
        }
      }
    }

    const created = await tx.creditNote.create({
      data: {
        tenantId: req.tenantId,
        invoiceId: invoice.id,
        reason: reason.trim(),
        businessName: invoice.businessName,
        businessTrn: invoice.businessTrn,
        businessAddress: invoice.businessAddress,
        customerName: invoice.customerName,
        customerAddress: invoice.customerAddress,
        customerTrn: invoice.customerTrn,
        currency: invoice.currency,
        notes: notes || null,
        // Stored now (not just validated) so a user-specified issue date
        // survives to the Issue transaction, which only defaults to "now"
        // when this is still null - see issueCreditNoteTx().
        issueDate: issueDate ? resolvedIssueDate : null,
        lineItems: { create: resolvedLines.map(({ _sourceLineTotal, ...l }) => l) },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Against ${invoice.invoiceNumberDisplay}`, req.tenantUser.id);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ creditNote });
}

// GET /api/tenant/credit-notes/:id
async function getCreditNote(req, res) {
  const creditNote = await prisma.creditNote.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: FULL_INCLUDE,
  });
  if (!creditNote) throw new ApiError(404, "Credit note not found");

  // previouslyAdjusted always excludes this note itself (it means "issued
  // independently of/before this one"). remainingAmount must additionally
  // subtract THIS note's own amount when it is itself ISSUED - otherwise an
  // already-issued note's own detail view would wrongly show the amount it
  // just consumed as still "remaining".
  const previouslyAdjusted = await sumIssuedAgainstInvoice(prisma, creditNote.invoiceId, creditNote.id);
  const thisNoteConsumed = creditNote.status === "ISSUED" ? creditNote.grandTotal : 0;
  const remaining = round2(creditNote.invoice.grandTotal - previouslyAdjusted - thisNoteConsumed);

  res.json({ creditNote, adjustment: { originalAmount: creditNote.invoice.grandTotal, previouslyAdjusted, currentNote: creditNote.grandTotal, remainingAmount: remaining } });
}

// PATCH /api/tenant/credit-notes/:id - Draft-only, replaces reason/notes/issueDate.
async function updateCreditNote(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  const { reason, notes, issueDate } = req.body;
  const data = {};
  if (reason !== undefined) {
    if (!reason?.trim()) throw new ApiError(400, "A reason is required");
    data.reason = reason.trim();
  }
  if (notes !== undefined) data.notes = notes || null;
  if (issueDate !== undefined) {
    const d = issueDate ? new Date(issueDate) : null;
    if (issueDate && Number.isNaN(d.getTime())) throw new ApiError(400, "Invalid issueDate");
    data.issueDate = d;
  }

  const creditNote = await prisma.$transaction(async (tx) => {
    await tx.creditNote.update({ where: { id: existing.id }, data });
    await logActivity(tx, existing.id, "EDITED", null, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ creditNote });
}

// POST /api/tenant/credit-notes/:id/line-items
async function addLineItem(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  const invoice = await prisma.invoice.findFirst({ where: { id: existing.invoiceId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(invoice, { ...req.body, sortOrder: existing.lineItems.length });

  const creditNote = await prisma.$transaction(async (tx) => {
    const { _sourceLineTotal, ...data } = resolved;
    await tx.creditNoteLineItem.create({ data: { creditNoteId: existing.id, ...data } });
    await logActivity(tx, existing.id, "EDITED", `Added line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.status(201).json({ creditNote });
}

// PATCH /api/tenant/credit-notes/:id/line-items/:lineId
async function updateLineItem(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  const line = await prisma.creditNoteLineItem.findFirst({ where: { id: req.params.lineId, creditNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const invoice = await prisma.invoice.findFirst({ where: { id: existing.invoiceId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(invoice, {
    invoiceLineItemId: req.body.invoiceLineItemId !== undefined ? req.body.invoiceLineItemId : line.invoiceLineItemId,
    taxCategoryId: req.body.taxCategoryId !== undefined ? req.body.taxCategoryId : line.taxCategoryId,
    description: req.body.description !== undefined ? req.body.description : line.description,
    unitPrice: req.body.unitPrice !== undefined ? req.body.unitPrice : line.unitPrice,
    quantity: req.body.quantity !== undefined ? req.body.quantity : line.quantity,
    sortOrder: line.sortOrder,
  });

  const creditNote = await prisma.$transaction(async (tx) => {
    const { _sourceLineTotal, ...data } = resolved;
    await tx.creditNoteLineItem.update({ where: { id: line.id }, data });
    await logActivity(tx, existing.id, "EDITED", `Updated line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ creditNote });
}

// DELETE /api/tenant/credit-notes/:id/line-items/:lineId
async function deleteLineItem(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  const line = await prisma.creditNoteLineItem.findFirst({ where: { id: req.params.lineId, creditNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const creditNote = await prisma.$transaction(async (tx) => {
    await tx.creditNoteLineItem.delete({ where: { id: line.id } });
    await logActivity(tx, existing.id, "EDITED", `Removed line: ${line.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ creditNote });
}

// DELETE /api/tenant/credit-notes/:id - hard delete, Draft-only, same policy as Invoice.
async function deleteCreditNote(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  await prisma.creditNote.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// The real numbering-assignment + status-transition mutation. Called
// identically whether immediate (no approval rule) or after a checker
// approves a pending request (see approvalExecutors.js's "CreditNote.issue").
// Re-checks the remaining-amount cap INSIDE this transaction - the whole
// point of doing it here and not just at create/pre-check time, to close
// the race window between two near-simultaneous partial notes (or a
// pending-approval note that could otherwise double-count against a
// meanwhile-issued one).
async function issueCreditNoteTx(tx, tenantId, creditNoteId, actorId) {
  const existing = await tx.creditNote.findFirst({ where: { id: creditNoteId, tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  if (existing.status !== "DRAFT") throw new ApiError(409, "This credit note is no longer a Draft and can't be issued");
  if (existing.lineItems.length === 0) throw new ApiError(400, "Add at least one line item before issuing");

  const invoice = await tx.invoice.findFirst({ where: { id: existing.invoiceId } });
  if (!invoice) throw new ApiError(404, "Original invoice not found");
  if (invoice.status !== "SENT") throw new ApiError(409, "The original invoice is no longer eligible (not Sent)");

  await recomputeAndPersist(tx, existing.id);
  const recomputed = await tx.creditNote.findUnique({ where: { id: existing.id }, include: { lineItems: true } });

  const alreadyIssued = await sumIssuedAgainstInvoice(tx, invoice.id, existing.id);
  if (round2(alreadyIssued + recomputed.grandTotal) > round2(invoice.grandTotal) + 0.01) {
    throw new ApiError(409, `This exceeds the remaining eligible amount. Remaining: ${round2(invoice.grandTotal - alreadyIssued)} ${invoice.currency}`);
  }
  for (const line of recomputed.lineItems) {
    if (line.invoiceLineItemId) {
      const sourceLine = await tx.invoiceLineItem.findUnique({ where: { id: line.invoiceLineItemId } });
      const alreadyLine = await sumIssuedAgainstInvoiceLine(tx, line.invoiceLineItemId, existing.id);
      if (sourceLine && round2(alreadyLine + line.lineTotal) > round2(sourceLine.lineTotal) + 0.01) {
        throw new ApiError(409, `"${line.description}" exceeds the remaining eligible amount on that line`);
      }
    }
  }

  const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextCreditNoteNumber: { increment: 1 } } });
  const assignedNumber = tenant.nextCreditNoteNumber - 1;
  const display = `CN-${String(assignedNumber).padStart(6, "0")}`;

  await logActivity(tx, existing.id, "ISSUED", display, actorId);

  return tx.creditNote.update({
    where: { id: existing.id },
    data: { creditNoteNumber: assignedNumber, creditNoteNumberDisplay: display, issueDate: existing.issueDate || new Date(), status: "ISSUED" },
    include: FULL_INCLUDE,
  });
}

// POST /api/tenant/credit-notes/:id/issue - routed through Maker-Checker,
// same pilot pattern as Invoice.send.
async function issueCreditNote(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  assertDraft(existing);

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "credit_notes.issue",
    module: "credit_notes",
    action: "issue",
    entityType: "CreditNote",
    entityId: existing.id,
    payload: {},
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.json({ creditNote: result.entity });
}

// POST /api/tenant/credit-notes/:id/void
async function voidCreditNote(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");
  if (existing.status !== "ISSUED") throw new ApiError(409, "Only an Issued credit note can be voided");

  const creditNote = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "VOIDED", null, req.tenantUser.id);
    return tx.creditNote.update({ where: { id: existing.id }, data: { status: "VOID" }, include: FULL_INCLUDE });
  });
  res.json({ creditNote });
}

// POST /api/tenant/credit-notes/:id/activity - lets the Viewer log DOWNLOADED/PREVIEWED.
async function logCreditNoteActivity(req, res) {
  const existing = await prisma.creditNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Credit note not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.creditNoteActivity.create({ data: { creditNoteId: existing.id, type, description: description || null, actorId: req.tenantUser.id } });
  res.status(201).json({ activity });
}

module.exports = {
  listCreditNotes,
  createCreditNote,
  getCreditNote,
  updateCreditNote,
  addLineItem,
  updateLineItem,
  deleteLineItem,
  deleteCreditNote,
  issueCreditNote,
  voidCreditNote,
  logCreditNoteActivity,
  // Exported for approvalExecutors.js's "CreditNote.issue" executor.
  issueCreditNoteTx,
  logActivity,
  FULL_INCLUDE,
};
