// Customer Payments module (Phase 2, 2026-08-22) - see prisma/schema.prisma's
// Payment/PaymentAllocation/PaymentActivity model comments for the full
// architecture. This is the real, allocation-aware module the brief asked
// for; invoice.controller.js's own recordPayment (the pre-existing Invoice-
// detail "Record Payment" quick action) is untouched from the caller's point
// of view and reuses the exact same recalculatePaymentFields helper this file
// calls - there is exactly one place that derives an invoice's balance.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { round2 } = require("../services/invoiceCalc");
const { recalculatePaymentFields, logActivity: logInvoiceActivity } = require("./invoice.controller");

const VALID_PAYMENT_METHODS = ["CASH", "BANK_TRANSFER", "CARD", "CHEQUE", "OTHER"];

const FULL_INCLUDE = {
  allocations: {
    include: { invoice: { select: { id: true, invoiceNumberDisplay: true, grandTotal: true, outstandingAmount: true, currency: true, status: true, paymentStatus: true } } },
    orderBy: { createdAt: "asc" },
  },
  activities: { orderBy: { createdAt: "desc" } },
  // Reconciliation Engine (Phase 4, 2026-08-23) - which bank transaction(s),
  // if any, this payment has been matched against. Only CONFIRMED matches
  // are ever real reconciliation; a SUGGESTED one is surfaced too (read via
  // this same relation) so the Payment detail page can point at "pending
  // review" without a second request.
  reconciliationLines: {
    where: { match: { status: { in: ["SUGGESTED", "CONFIRMED"] } } },
    include: {
      match: {
        select: {
          id: true,
          matchNumberDisplay: true,
          status: true,
          confidence: true,
          matchedAt: true,
          bankLines: { include: { bankTransaction: { select: { id: true, transactionDate: true, description: true, reference: true, amount: true, currency: true, bankAccount: { select: { accountName: true } } } } } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  },
};

function logPaymentActivity(tx, paymentId, type, description) {
  return tx.paymentActivity.create({ data: { paymentId, type, description: description || null } });
}

// Adds the two figures that are never stored, always derived: how much of
// this payment has actually been assigned to an invoice, and how much is
// still sitting unallocated (received but not yet applied anywhere).
function withComputed(payment) {
  const allocatedTotal = round2((payment.allocations || []).reduce((sum, a) => sum + a.allocatedAmount, 0));
  const unallocatedAmount = round2(Math.max(0, payment.amount - allocatedTotal));
  return { ...payment, allocatedTotal, unallocatedAmount };
}

function assertEditable(payment) {
  if (payment.status === "CANCELLED") throw new ApiError(409, "This payment has been cancelled");
  // PARTIALLY_RECONCILED added (Reconciliation Engine, Phase 4, 2026-08-23) -
  // this payment already has at least one CONFIRMED bank match; reallocating
  // or cancelling it out from under that match would silently strand the
  // reconciliation, so it must be unmatched (via the Reconciliation module)
  // before it can be edited, same as the pre-existing RECONCILED rule.
  if (payment.reconciliationStatus === "RECONCILED" || payment.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - unmatch it first");
  }
}

// Validates a proposed allocation set against this tenant's own Invoices,
// returning the resolved Invoice rows alongside each requested amount.
// Deliberately does NOT cap an individual allocation against the invoice's
// own outstanding balance - allocating more to one invoice than it currently
// owes is a supported overpayment scenario, not an error (see schema comment
// on PaymentAllocation). The one real guard is that the allocations can't
// add up to more than the payment's own amount - that would assign money
// that was never received.
async function resolveAllocations(tenantId, allocationInputs, paymentAmount) {
  const list = Array.isArray(allocationInputs) ? allocationInputs : [];
  const resolved = [];
  let total = 0;

  for (const item of list) {
    const allocAmount = Number(item.amount);
    if (!allocAmount || Number.isNaN(allocAmount) || allocAmount <= 0) {
      throw new ApiError(400, "Each allocation amount must be a positive number");
    }
    const invoice = await prisma.invoice.findFirst({ where: { id: item.invoiceId, tenantId } });
    if (!invoice) throw new ApiError(400, `invoiceId ${item.invoiceId} does not refer to an invoice on this tenant`);
    if (invoice.status !== "SENT") {
      throw new ApiError(400, `Invoice ${invoice.invoiceNumberDisplay || invoice.id} must be Sent before a payment can be allocated to it`);
    }
    total += allocAmount;
    resolved.push({ invoice, allocAmount: round2(allocAmount) });
  }

  if (round2(total) > round2(Number(paymentAmount)) + 0.005) {
    throw new ApiError(400, `Total allocated amount (${round2(total)}) cannot exceed the payment amount (${round2(Number(paymentAmount))})`);
  }

  return resolved;
}

// GET /api/tenant/payments
// ?customerId, ?status (CONFIRMED|CANCELLED) optional filters.
async function listPayments(req, res) {
  const { customerId, status } = req.query;
  const payments = await prisma.payment.findMany({
    where: {
      tenantId: req.tenantId,
      ...(customerId ? { customerId } : {}),
      ...(status ? { status } : {}),
    },
    include: { allocations: { select: { allocatedAmount: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ payments: payments.map(withComputed) });
}

// GET /api/tenant/payments/allocatable-invoices?customerId=...
// Supports the New Payment wizard's invoice picker - every Sent invoice for
// a customer that still has an outstanding balance (an already-overpaid
// invoice is deliberately still included - a user may legitimately want to
// allocate more here anyway, e.g. correcting a previous under-allocation).
async function listAllocatableInvoices(req, res) {
  const { customerId } = req.query;
  if (!customerId) throw new ApiError(400, "customerId is required");

  const invoices = await prisma.invoice.findMany({
    where: { tenantId: req.tenantId, customerId, status: "SENT" },
    select: { id: true, invoiceNumberDisplay: true, issueDate: true, currency: true, grandTotal: true, amountPaid: true, outstandingAmount: true, paymentStatus: true },
    orderBy: { issueDate: "asc" },
  });
  res.json({ invoices });
}

// POST /api/tenant/payments
async function createPayment(req, res) {
  const { customerId, customerName, paymentDate, amount, currency, method, accountRef, reference, notes, allocations } = req.body;

  if (amount === undefined || amount === null || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
    throw new ApiError(400, "amount must be a positive number");
  }
  if (!paymentDate) throw new ApiError(400, "paymentDate is required");
  if (!VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  let resolvedCustomerId = null;
  let customerSnapshotName = customerName?.trim() || "";
  if (customerId) {
    const customer = await prisma.customer.findFirst({ where: { id: customerId, tenantId: req.tenantId } });
    if (!customer) throw new ApiError(400, "customerId does not refer to a customer on this tenant");
    resolvedCustomerId = customer.id;
    customerSnapshotName = customerName?.trim() || customer.name;
  }
  if (!customerSnapshotName) throw new ApiError(400, "Customer is required (select a Customer or enter one manually)");

  const resolvedAllocations = await resolveAllocations(req.tenantId, allocations, amount);
  const paymentCurrency = currency || "AED";

  const payment = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: req.tenantId }, data: { nextPaymentNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextPaymentNumber - 1;
    const display = `PAY-${String(assignedNumber).padStart(6, "0")}`;

    const created = await tx.payment.create({
      data: {
        tenantId: req.tenantId,
        customerId: resolvedCustomerId,
        customerName: customerSnapshotName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        amount: Number(amount),
        currency: paymentCurrency,
        paymentDate: new Date(paymentDate),
        method,
        accountRef: accountRef || null,
        reference: reference || null,
        notes: notes || null,
        source: "MANUAL",
      },
    });

    await logPaymentActivity(tx, created.id, "CREATED", `${paymentCurrency} ${Number(amount).toFixed(2)} via ${method} from ${customerSnapshotName}`);

    for (const { invoice, allocAmount } of resolvedAllocations) {
      await tx.paymentAllocation.create({ data: { paymentId: created.id, invoiceId: invoice.id, allocatedAmount: allocAmount } });
    }
    if (resolvedAllocations.length > 0) {
      const summary = resolvedAllocations.map((r) => `${r.invoice.invoiceNumberDisplay || r.invoice.id}: ${paymentCurrency} ${r.allocAmount.toFixed(2)}`).join(", ");
      await logPaymentActivity(tx, created.id, "ALLOCATED", summary);
      for (const { invoice, allocAmount } of resolvedAllocations) {
        await recalculatePaymentFields(tx, invoice.id);
        await logInvoiceActivity(tx, invoice.id, "PAYMENT_RECORDED", `${paymentCurrency} ${allocAmount.toFixed(2)} via ${method} (${display})`);
      }
    }

    return tx.payment.findUnique({ where: { id: created.id }, include: FULL_INCLUDE });
  });

  res.status(201).json({ payment: withComputed(payment) });
}

// GET /api/tenant/payments/:id
async function getPayment(req, res) {
  const payment = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: FULL_INCLUDE });
  if (!payment) throw new ApiError(404, "Payment not found");
  res.json({ payment: withComputed(payment) });
}

// PATCH /api/tenant/payments/:id
// Header fields only - amount/allocations never change here, see
// reallocatePayment below (changing what a payment settles always has to
// recompute invoice balances, so it gets its own explicit, auditable action).
async function updatePayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  assertEditable(existing);

  const { paymentDate, method, accountRef, reference, notes } = req.body;
  if (method !== undefined && !VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.payment.update({
      where: { id: existing.id },
      data: {
        ...(paymentDate !== undefined ? { paymentDate: new Date(paymentDate) } : {}),
        ...(method !== undefined ? { method } : {}),
        ...(accountRef !== undefined ? { accountRef: accountRef || null } : {}),
        ...(reference !== undefined ? { reference: reference || null } : {}),
        ...(notes !== undefined ? { notes: notes || null } : {}),
      },
    });
    await logPaymentActivity(tx, existing.id, "EDITED", null);
    return tx.payment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// POST /api/tenant/payments/:id/allocate
// Full replace of this payment's allocation set - simpler and more auditable
// than a patch-style partial update. Recomputes every invoice touched by
// either the old or the new set (an invoice dropped from the allocation
// needs its balance recalculated back down just as much as one newly added).
async function reallocatePayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  assertEditable(existing);

  const resolvedAllocations = await resolveAllocations(req.tenantId, req.body.allocations, existing.amount);

  const affectedInvoiceIds = new Set([...existing.allocations.map((a) => a.invoiceId), ...resolvedAllocations.map((r) => r.invoice.id)]);

  const payment = await prisma.$transaction(async (tx) => {
    await tx.paymentAllocation.deleteMany({ where: { paymentId: existing.id } });
    for (const { invoice, allocAmount } of resolvedAllocations) {
      await tx.paymentAllocation.create({ data: { paymentId: existing.id, invoiceId: invoice.id, allocatedAmount: allocAmount } });
    }

    const summary = resolvedAllocations.length > 0
      ? resolvedAllocations.map((r) => `${r.invoice.invoiceNumberDisplay || r.invoice.id}: ${existing.currency} ${r.allocAmount.toFixed(2)}`).join(", ")
      : "fully unallocated";
    await logPaymentActivity(tx, existing.id, "REALLOCATED", summary);

    for (const invoiceId of affectedInvoiceIds) {
      await recalculatePaymentFields(tx, invoiceId);
      await logInvoiceActivity(tx, invoiceId, "EDITED", `Payment ${existing.paymentNumberDisplay || existing.id} reallocation updated`);
    }

    return tx.payment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// POST /api/tenant/payments/:id/cancel
// Soft reversal - mirrors Invoice/PurchaseBill/CreditNote's own Void pattern
// (immediate, RBAC-gated only, no Maker-Checker routing - consistent with
// how every sibling module treats its own cancellation action). The
// allocation rows are never deleted (full history stays intact via
// PaymentActivity); recalculatePaymentFields already only sums CONFIRMED
// payments, so flipping this one to CANCELLED automatically excludes it from
// every affected invoice's derived balance.
async function cancelPayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.status === "CANCELLED") throw new ApiError(409, "This payment is already cancelled");
  if (existing.reconciliationStatus === "RECONCILED" || existing.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - unmatch it first");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.payment.update({ where: { id: existing.id }, data: { status: "CANCELLED" } });
    await logPaymentActivity(tx, existing.id, "CANCELLED", req.body?.reason || null);

    for (const allocation of existing.allocations) {
      await recalculatePaymentFields(tx, allocation.invoiceId);
      await logInvoiceActivity(tx, allocation.invoiceId, "EDITED", `Payment ${existing.paymentNumberDisplay || existing.id} was cancelled`);
    }

    return tx.payment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// DELETE /api/tenant/payments/:id
// Hard delete only when this payment has never touched any invoice's
// balance (zero allocations) - the closest real analogue in this schema to
// "Draft, never issued" for a document type with no Draft phase of its own.
// Anything with real allocations must go through cancelPayment instead, so
// the reversal is always visible in history.
async function deletePayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.allocations.length > 0) {
    throw new ApiError(409, "This payment has allocations against one or more invoices - cancel it instead of deleting");
  }

  await prisma.payment.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// POST /api/tenant/payments/:id/reconcile
// Manual, no-bank-statement-involved toggle (e.g. pure cash) - kept exactly
// as it was pre-Phase-4. A payment with any real bank match must go through
// the Reconciliation module instead (see reconciliation.controller.js's
// confirmMatch/unmatchMatch), since only that path knows how much of the
// payment is actually covered - this endpoint would otherwise let someone
// mark a PARTIALLY_RECONCILED payment fully RECONCILED without the bank
// amount actually supporting it.
async function reconcilePayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.status === "CANCELLED") throw new ApiError(409, "A cancelled payment can't be reconciled");
  if (existing.reconciliationStatus === "RECONCILED") throw new ApiError(409, "Already reconciled");
  if (existing.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment already has a bank match in progress - use the Reconciliation module to complete or unmatch it");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.payment.update({ where: { id: existing.id }, data: { reconciliationStatus: "RECONCILED" } });
    await logPaymentActivity(tx, existing.id, "RECONCILED", null);
    return tx.payment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });
  res.json({ payment: withComputed(payment) });
}

async function unreconcilePayment(req, res) {
  const existing = await prisma.payment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.reconciliationStatus !== "RECONCILED") throw new ApiError(409, "This payment is not reconciled");
  const activeBankMatch = await prisma.reconciliationLedgerLine.findFirst({ where: { paymentId: existing.id, match: { status: "CONFIRMED" } } });
  if (activeBankMatch) {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - use the Reconciliation module's Unmatch action instead");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.payment.update({ where: { id: existing.id }, data: { reconciliationStatus: "UNRECONCILED" } });
    await logPaymentActivity(tx, existing.id, "UNRECONCILED", null);
    return tx.payment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });
  res.json({ payment: withComputed(payment) });
}

module.exports = {
  listPayments,
  listAllocatableInvoices,
  createPayment,
  getPayment,
  updatePayment,
  reallocatePayment,
  cancelPayment,
  deletePayment,
  reconcilePayment,
  unreconcilePayment,
  // Exported for importAdapters.js's PAYMENT adapter - the exact same
  // creation path manual entry uses under the hood, not a copy.
  FULL_INCLUDE,
  withComputed,
};
