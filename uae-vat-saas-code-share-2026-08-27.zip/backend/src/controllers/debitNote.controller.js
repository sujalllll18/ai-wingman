const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { calculateInvoiceTotals, round2 } = require("../services/invoiceCalc");
const engine = require("../services/approvalEngine.service");

// Mirrors creditNote.controller.js exactly, one level down (Purchase side
// instead of Invoice side). See that file's comments for the reasoning
// behind each rule - not repeated verbatim here.
const FULL_INCLUDE = {
  lineItems: { orderBy: { sortOrder: "asc" } },
  activities: { orderBy: { createdAt: "desc" } },
  // Same fix as creditNote.controller.js's FULL_INCLUDE - every mutating
  // endpoint must return `purchaseBill`, not just GET.
  purchaseBill: { select: { id: true, billNumberDisplay: true, grandTotal: true, purchaseDate: true, currency: true } },
};

const VALID_ACTIVITY_TYPES = ["DOWNLOADED", "PREVIEWED"];

function assertDraft(debitNote) {
  if (debitNote.status !== "DRAFT") {
    throw new ApiError(409, "This debit note is no longer a Draft and can't be edited");
  }
}

function logActivity(tx, debitNoteId, type, description, actorId = null) {
  return tx.debitNoteActivity.create({ data: { debitNoteId, type, description: description || null, actorId } });
}

async function sumIssuedAgainstPurchase(tx, purchaseBillId, excludeDebitNoteId = null) {
  const agg = await tx.debitNote.aggregate({
    where: { purchaseBillId, status: "ISSUED", ...(excludeDebitNoteId ? { id: { not: excludeDebitNoteId } } : {}) },
    _sum: { grandTotal: true },
  });
  return round2(agg._sum.grandTotal || 0);
}

async function sumIssuedAgainstPurchaseLine(tx, purchaseLineItemId, excludeDebitNoteId = null) {
  const lines = await tx.debitNoteLineItem.findMany({
    where: {
      purchaseLineItemId,
      debitNote: { status: "ISSUED", ...(excludeDebitNoteId ? { id: { not: excludeDebitNoteId } } : {}) },
    },
    select: { lineTotal: true },
  });
  return round2(lines.reduce((s, l) => s + l.lineTotal, 0));
}

async function loadEligiblePurchase(tenantId, purchaseBillId) {
  const purchase = await prisma.purchaseBill.findFirst({
    where: { id: purchaseBillId, tenantId },
    include: { lineItems: { orderBy: { sortOrder: "asc" } }, tenant: { select: { name: true, trn: true } } },
  });
  if (!purchase) throw new ApiError(404, "Purchase bill not found");
  if (purchase.status === "DRAFT") throw new ApiError(409, "A Debit Note can't be raised against a Draft purchase bill - record it first");
  if (purchase.status === "VOID") throw new ApiError(409, "A Debit Note can't be raised against a cancelled purchase bill");
  return purchase;
}

// Note: unlike Credit Notes (return of goods), a Debit Note's most common
// use case is an ADDITIONAL charge that may exceed the original line's
// quantity (e.g. supplier undercharged) - so unlike CreditNote, there is no
// per-line "remaining" cap here by default. The header-level total is still
// tracked for the Original/Previously Adjusted/Remaining display, but a
// Debit Note is deliberately allowed to add new taxable value, not just
// consume existing value, matching its business purpose (increase, not
// reduce). A freeform line's tax category must still have appeared on the
// original purchase, so the VAT treatment stays traceable.
function resolveNoteLineFromSource(purchase, input) {
  const quantity = Number(input.quantity);
  if (!quantity || Number.isNaN(quantity) || quantity <= 0) {
    throw new ApiError(400, "Line item quantity must be a positive number");
  }

  let sourceLine = null;
  if (input.purchaseLineItemId) {
    sourceLine = purchase.lineItems.find((li) => li.id === input.purchaseLineItemId);
    if (!sourceLine) throw new ApiError(400, "purchaseLineItemId does not refer to a line item on this purchase bill");
  } else if (input.taxCategoryId) {
    sourceLine = purchase.lineItems.find((li) => li.taxCategoryId === input.taxCategoryId);
    if (!sourceLine) throw new ApiError(400, "This tax category doesn't appear on the source purchase bill - pick one that was actually charged");
  } else if (purchase.lineItems.some((li) => li.taxCategoryId)) {
    throw new ApiError(400, "Select an original line item or a tax category that was used on the purchase bill");
  }

  const description = (input.description || sourceLine?.description || "").trim();
  if (!description) throw new ApiError(400, "Line item description is required");

  const unitPrice = input.unitPrice !== undefined ? Number(input.unitPrice) : Number(sourceLine?.unitPrice || 0);
  if (Number.isNaN(unitPrice) || unitPrice < 0) {
    throw new ApiError(400, "Line item unit price must be a non-negative number");
  }

  return {
    purchaseLineItemId: sourceLine?.id || null,
    description,
    quantity,
    unitPrice,
    sortOrder: input.sortOrder ?? 0,
    taxCategoryId: sourceLine?.taxCategoryId || null,
    taxRateId: sourceLine?.taxRateId || null,
    taxRateName: sourceLine?.taxRateName || null,
    taxPercentage: sourceLine?.taxPercentage || 0,
    taxCalculationMethod: sourceLine?.taxCalculationMethod || "EXCLUSIVE",
  };
}

async function recomputeAndPersist(tx, debitNoteId) {
  const note = await tx.debitNote.findUnique({ where: { id: debitNoteId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  const result = calculateInvoiceTotals(note.lineItems, {});

  for (const line of result.lines) {
    await tx.debitNoteLineItem.update({
      where: { id: line.id },
      data: {
        lineNetAmount: line.lineNetAmount,
        lineTaxableAmount: line.lineTaxableAmount,
        lineTaxAmount: line.lineTaxAmount,
        lineTotal: line.lineTotal,
      },
    });
  }

  return tx.debitNote.update({
    where: { id: debitNoteId },
    data: { subtotal: result.subtotal, vatTotal: result.vatTotal, grandTotal: result.grandTotal },
    include: FULL_INCLUDE,
  });
}

// GET /api/tenant/debit-notes
async function listDebitNotes(req, res) {
  const notes = await prisma.debitNote.findMany({
    where: { tenantId: req.tenantId },
    include: { lineItems: { select: { id: true } }, purchaseBill: { select: { id: true, billNumberDisplay: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ debitNotes: notes });
}

// POST /api/tenant/debit-notes
async function createDebitNote(req, res) {
  const { purchaseBillId, reason, issueDate, notes, lineItems } = req.body;
  if (!purchaseBillId) throw new ApiError(400, "purchaseBillId is required");
  if (!reason?.trim()) throw new ApiError(400, "A reason is required");
  if (!Array.isArray(lineItems) || lineItems.length === 0) throw new ApiError(400, "At least one line item is required");

  const purchase = await loadEligiblePurchase(req.tenantId, purchaseBillId);

  let resolvedIssueDate = new Date();
  if (issueDate) {
    resolvedIssueDate = new Date(issueDate);
    if (Number.isNaN(resolvedIssueDate.getTime())) throw new ApiError(400, "Invalid issueDate");
    const originalDate = purchase.invoiceDate || purchase.purchaseDate;
    if (originalDate && resolvedIssueDate < originalDate) {
      throw new ApiError(400, "Debit Note issue date can't be before the original purchase bill's date");
    }
  }

  const resolvedLines = lineItems.map((item, i) => resolveNoteLineFromSource(purchase, { ...item, sortOrder: i }));

  const debitNote = await prisma.$transaction(async (tx) => {
    const created = await tx.debitNote.create({
      data: {
        tenantId: req.tenantId,
        purchaseBillId: purchase.id,
        reason: reason.trim(),
        businessName: purchase.tenant.name,
        businessTrn: purchase.tenant.trn,
        vendorName: purchase.vendorName,
        vendorAddress: purchase.vendorAddress,
        vendorTrn: purchase.vendorTrn,
        currency: purchase.currency,
        notes: notes || null,
        issueDate: issueDate ? resolvedIssueDate : null,
        lineItems: { create: resolvedLines },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Against ${purchase.billNumberDisplay}`, req.tenantUser.id);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ debitNote });
}

// GET /api/tenant/debit-notes/:id
async function getDebitNote(req, res) {
  const debitNote = await prisma.debitNote.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: FULL_INCLUDE,
  });
  if (!debitNote) throw new ApiError(404, "Debit note not found");

  const previouslyAdjusted = await sumIssuedAgainstPurchase(prisma, debitNote.purchaseBillId, debitNote.id);

  res.json({
    debitNote,
    adjustment: { originalAmount: debitNote.purchaseBill.grandTotal, previouslyAdjusted, currentNote: debitNote.grandTotal },
  });
}

// PATCH /api/tenant/debit-notes/:id - Draft-only.
async function updateDebitNote(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const { reason, notes, issueDate } = req.body;
  const data = {};
  if (reason !== undefined) {
    if (!reason?.trim()) throw new ApiError(400, "A reason is required");
    data.reason = reason.trim();
  }
  if (notes !== undefined) data.notes = notes || null;
  if (issueDate !== undefined) {
    const d = issueDate ? new Date(issueDate) : null;
    if (issueDate && Number.isNaN(d.getTime())) throw new ApiError(400, "Invalid issueDate");
    data.issueDate = d;
  }

  const debitNote = await prisma.$transaction(async (tx) => {
    await tx.debitNote.update({ where: { id: existing.id }, data });
    await logActivity(tx, existing.id, "EDITED", null, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ debitNote });
}

// POST /api/tenant/debit-notes/:id/line-items
async function addLineItem(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const purchase = await prisma.purchaseBill.findFirst({ where: { id: existing.purchaseBillId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(purchase, { ...req.body, sortOrder: existing.lineItems.length });

  const debitNote = await prisma.$transaction(async (tx) => {
    await tx.debitNoteLineItem.create({ data: { debitNoteId: existing.id, ...resolved } });
    await logActivity(tx, existing.id, "EDITED", `Added line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.status(201).json({ debitNote });
}

// PATCH /api/tenant/debit-notes/:id/line-items/:lineId
async function updateLineItem(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const line = await prisma.debitNoteLineItem.findFirst({ where: { id: req.params.lineId, debitNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const purchase = await prisma.purchaseBill.findFirst({ where: { id: existing.purchaseBillId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(purchase, {
    purchaseLineItemId: req.body.purchaseLineItemId !== undefined ? req.body.purchaseLineItemId : line.purchaseLineItemId,
    taxCategoryId: req.body.taxCategoryId !== undefined ? req.body.taxCategoryId : line.taxCategoryId,
    description: req.body.description !== undefined ? req.body.description : line.description,
    unitPrice: req.body.unitPrice !== undefined ? req.body.unitPrice : line.unitPrice,
    quantity: req.body.quantity !== undefined ? req.body.quantity : line.quantity,
    sortOrder: line.sortOrder,
  });

  const debitNote = await prisma.$transaction(async (tx) => {
    await tx.debitNoteLineItem.update({ where: { id: line.id }, data: resolved });
    await logActivity(tx, existing.id, "EDITED", `Updated line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ debitNote });
}

// DELETE /api/tenant/debit-notes/:id/line-items/:lineId
async function deleteLineItem(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const line = await prisma.debitNoteLineItem.findFirst({ where: { id: req.params.lineId, debitNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const debitNote = await prisma.$transaction(async (tx) => {
    await tx.debitNoteLineItem.delete({ where: { id: line.id } });
    await logActivity(tx, existing.id, "EDITED", `Removed line: ${line.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ debitNote });
}

// DELETE /api/tenant/debit-notes/:id
async function deleteDebitNote(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  await prisma.debitNote.delete({ where: { id: existing.id } });
  res.status(204).send();
}

async function issueDebitNoteTx(tx, tenantId, debitNoteId, actorId) {
  const existing = await tx.debitNote.findFirst({ where: { id: debitNoteId, tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  if (existing.status !== "DRAFT") throw new ApiError(409, "This debit note is no longer a Draft and can't be issued");
  if (existing.lineItems.length === 0) throw new ApiError(400, "Add at least one line item before issuing");

  const purchase = await tx.purchaseBill.findFirst({ where: { id: existing.purchaseBillId } });
  if (!purchase) throw new ApiError(404, "Original purchase bill not found");
  if (purchase.status !== "RECORDED") throw new ApiError(409, "The original purchase bill is no longer eligible (not Recorded)");

  await recomputeAndPersist(tx, existing.id);

  const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextDebitNoteNumber: { increment: 1 } } });
  const assignedNumber = tenant.nextDebitNoteNumber - 1;
  const display = `DN-${String(assignedNumber).padStart(6, "0")}`;

  await logActivity(tx, existing.id, "ISSUED", display, actorId);

  return tx.debitNote.update({
    where: { id: existing.id },
    data: { debitNoteNumber: assignedNumber, debitNoteNumberDisplay: display, issueDate: existing.issueDate || new Date(), status: "ISSUED" },
    include: FULL_INCLUDE,
  });
}

// POST /api/tenant/debit-notes/:id/issue
async function issueDebitNote(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "debit_notes.issue",
    module: "debit_notes",
    action: "issue",
    entityType: "DebitNote",
    entityId: existing.id,
    payload: {},
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.json({ debitNote: result.entity });
}

// POST /api/tenant/debit-notes/:id/void
async function voidDebitNote(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  if (existing.status !== "ISSUED") throw new ApiError(409, "Only an Issued debit note can be voided");

  const debitNote = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "VOIDED", null, req.tenantUser.id);
    return tx.debitNote.update({ where: { id: existing.id }, data: { status: "VOID" }, include: FULL_INCLUDE });
  });
  res.json({ debitNote });
}

// POST /api/tenant/debit-notes/:id/activity
async function logDebitNoteActivity(req, res) {
  const existing = await prisma.debitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.debitNoteActivity.create({ data: { debitNoteId: existing.id, type, description: description || null, actorId: req.tenantUser.id } });
  res.status(201).json({ activity });
}

module.exports = {
  listDebitNotes,
  createDebitNote,
  getDebitNote,
  updateDebitNote,
  addLineItem,
  updateLineItem,
  deleteLineItem,
  deleteDebitNote,
  issueDebitNote,
  voidDebitNote,
  logDebitNoteActivity,
  issueDebitNoteTx,
  logActivity,
  FULL_INCLUDE,
};
