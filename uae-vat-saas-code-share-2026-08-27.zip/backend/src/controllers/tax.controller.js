const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const engine = require("../services/approvalEngine.service");

const VALID_CALC_METHODS = ["EXCLUSIVE", "INCLUSIVE"];
const VALID_STATUSES = ["ACTIVE", "INACTIVE"];
// VAT Return bucketing (2026-08-03) - see schema comment on TaxCategory.classification.
const VALID_CLASSIFICATIONS = ["STANDARD_RATED", "ZERO_RATED", "EXEMPT", "OUT_OF_SCOPE"];

function rangesOverlap(aFrom, aTo, bFrom, bTo) {
  const aEnd = aTo ?? Infinity;
  const bEnd = bTo ?? Infinity;
  return aFrom < bEnd && bFrom < aEnd;
}

// Unchanged since the original Tax Master build - still the single source of
// truth taxResolver.js and this controller both rely on: only ACTIVE rows
// sharing a name can ever conflict. A superseded (isCurrentVersion=false)
// row's window gets closed off when its successor is created (see
// createTaxRateVersion), so it naturally stops colliding here without this
// function needing to know about versioning at all.
async function assertNoOverlap(tenantId, name, effectiveFrom, effectiveTo, excludeId) {
  const siblings = await prisma.taxRate.findMany({
    where: { tenantId, name, status: "ACTIVE", ...(excludeId ? { id: { not: excludeId } } : {}) },
  });
  const from = effectiveFrom.getTime();
  const to = effectiveTo ? effectiveTo.getTime() : null;
  const conflict = siblings.some((s) =>
    rangesOverlap(from, to, new Date(s.effectiveFrom).getTime(), s.effectiveTo ? new Date(s.effectiveTo).getTime() : null)
  );
  if (conflict) {
    throw new ApiError(409, `Another active "${name}" rate already covers part of this date range`);
  }
}

// ---------- Tax Categories (unchanged - still load-bearing for Invoice/
// Purchase line-item pricing and VAT Return bucketing; no UI manages these
// directly anymore, but the API stays exactly as it was) ----------

async function listTaxCategories(req, res) {
  const categories = await prisma.taxCategory.findMany({
    where: { tenantId: req.tenantId },
    include: { taxRate: true },
    orderBy: { createdAt: "asc" },
  });
  res.json({ categories });
}

async function getTaxCategory(req, res) {
  const category = await prisma.taxCategory.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { taxRate: true },
  });
  if (!category) throw new ApiError(404, "Tax category not found");
  res.json({ category });
}

async function createTaxCategory(req, res) {
  const { name, description, taxRateId, status, classification } = req.body;
  if (!name?.trim()) throw new ApiError(400, "Name is required");
  if (status && !VALID_STATUSES.includes(status)) throw new ApiError(400, `status must be one of ${VALID_STATUSES.join(", ")}`);
  if (classification && !VALID_CLASSIFICATIONS.includes(classification)) {
    throw new ApiError(400, `classification must be one of ${VALID_CLASSIFICATIONS.join(", ")}`);
  }

  if (taxRateId) {
    const rate = await prisma.taxRate.findFirst({ where: { id: taxRateId, tenantId: req.tenantId } });
    if (!rate) throw new ApiError(400, "taxRateId does not refer to a tax rate on this tenant");
  }

  const category = await prisma.taxCategory.create({
    data: {
      tenantId: req.tenantId,
      name: name.trim(),
      description: description || null,
      taxRateId: taxRateId || null,
      status: status || "ACTIVE",
      classification: classification || "STANDARD_RATED",
    },
    include: { taxRate: true },
  });
  res.status(201).json({ category });
}

async function updateTaxCategory(req, res) {
  const existing = await prisma.taxCategory.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Tax category not found");

  const { name, description, taxRateId, status, classification } = req.body;
  if (status && !VALID_STATUSES.includes(status)) throw new ApiError(400, `status must be one of ${VALID_STATUSES.join(", ")}`);
  if (classification && !VALID_CLASSIFICATIONS.includes(classification)) {
    throw new ApiError(400, `classification must be one of ${VALID_CLASSIFICATIONS.join(", ")}`);
  }
  if (taxRateId) {
    const rate = await prisma.taxRate.findFirst({ where: { id: taxRateId, tenantId: req.tenantId } });
    if (!rate) throw new ApiError(400, "taxRateId does not refer to a tax rate on this tenant");
  }

  const category = await prisma.taxCategory.update({
    where: { id: existing.id },
    data: {
      ...(name !== undefined ? { name: name.trim() } : {}),
      ...(description !== undefined ? { description: description || null } : {}),
      ...(taxRateId !== undefined ? { taxRateId: taxRateId || null } : {}),
      ...(status !== undefined ? { status } : {}),
      ...(classification !== undefined ? { classification } : {}),
    },
    include: { taxRate: true },
  });
  res.json({ category });
}

// ---------- Tax Rates ----------

function validateRatePayload({ name, percentage, calculationMethod, effectiveFrom, effectiveTo, status }, { requireName = true, requireFrom = true } = {}) {
  if (requireName && !name?.trim()) throw new ApiError(400, "Tax name is required");
  if (percentage === undefined || percentage === null || Number.isNaN(Number(percentage)) || Number(percentage) < 0) {
    throw new ApiError(400, "Percentage must be a non-negative number");
  }
  if (requireFrom && !effectiveFrom) throw new ApiError(400, "Applicable From is required");
  if (calculationMethod && !VALID_CALC_METHODS.includes(calculationMethod)) {
    throw new ApiError(400, `calculationMethod must be one of ${VALID_CALC_METHODS.join(", ")}`);
  }
  if (status && !VALID_STATUSES.includes(status)) throw new ApiError(400, `status must be one of ${VALID_STATUSES.join(", ")}`);

  const from = effectiveFrom ? new Date(effectiveFrom) : null;
  const to = effectiveTo ? new Date(effectiveTo) : null;
  if (to && from && to <= from) throw new ApiError(400, "Applicable To must be after Applicable From");
  return { from, to };
}

// Batches User.name lookups for createdBy/updatedBy - same pattern as
// approvalEngine.service.js's attachNames(), kept local since it's the only
// other place in the app that needs this shape today.
async function attachActorNames(rates) {
  const ids = new Set();
  for (const r of rates) {
    if (r.createdBy) ids.add(r.createdBy);
    if (r.updatedBy) ids.add(r.updatedBy);
  }
  const users = await prisma.user.findMany({ where: { id: { in: [...ids] } }, select: { id: true, name: true } });
  const nameById = new Map(users.map((u) => [u.id, u.name]));
  return rates.map((r) => ({
    ...r,
    createdByName: r.createdBy ? nameById.get(r.createdBy) || r.createdBy : null,
    updatedByName: r.updatedBy ? nameById.get(r.updatedBy) || r.updatedBy : null,
  }));
}

// GET /api/tenant/tax/rates - every version of every rate (the frontend
// filters to isCurrentVersion for the main list and reuses the same
// response, name-grouped, for the History view - no second endpoint needed).
async function listTaxRates(req, res) {
  const rates = await prisma.taxRate.findMany({
    where: { tenantId: req.tenantId },
    orderBy: [{ name: "asc" }, { version: "desc" }],
  });

  const ids = rates.map((r) => r.id);
  const [invoiceUsage, purchaseUsage, auditLogs] = await Promise.all([
    prisma.invoiceLineItem.findMany({ where: { taxRateId: { in: ids } }, select: { taxRateId: true } }),
    prisma.purchaseLineItem.findMany({ where: { taxRateId: { in: ids } }, select: { taxRateId: true } }),
    // Latest audit entry per rate, for the History view's optional Audit Ref
    // column - a short, human-referenceable id, not the full uuid.
    prisma.taxRateAuditLog.findMany({ where: { tenantId: req.tenantId, taxRateId: { in: ids } }, orderBy: { changedAt: "desc" }, select: { id: true, taxRateId: true } }),
  ]);
  const usedIds = new Set([...invoiceUsage.map((u) => u.taxRateId), ...purchaseUsage.map((u) => u.taxRateId)]);
  const auditRefByRateId = new Map();
  for (const log of auditLogs) {
    if (!auditRefByRateId.has(log.taxRateId)) auditRefByRateId.set(log.taxRateId, log.id.slice(0, 8).toUpperCase());
  }

  const withUsage = rates.map((r) => ({ ...r, isUsed: usedIds.has(r.id), auditRef: auditRefByRateId.get(r.id) || null }));
  res.json({ rates: await attachActorNames(withUsage) });
}

async function getTaxRate(req, res) {
  const rate = await prisma.taxRate.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!rate) throw new ApiError(404, "Tax rate not found");
  res.json({ rate });
}

// POST /api/tenant/tax/rates - a brand-new named rate (version 1). Routed
// through the Maker-Checker engine like every other integrated mutation.
async function createTaxRate(req, res) {
  const { name, percentage, calculationMethod, effectiveFrom, effectiveTo, status, notes } = req.body;
  const { from, to } = validateRatePayload(req.body);

  if ((status || "ACTIVE") === "ACTIVE") {
    await assertNoOverlap(req.tenantId, name.trim(), from, to);
  }

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "tax_master.create",
    module: "tax_master",
    action: "create",
    entityType: "TaxRate",
    payload: {
      name: name.trim(),
      percentage: Number(percentage),
      calculationMethod: calculationMethod || "EXCLUSIVE",
      effectiveFrom: from,
      effectiveTo: to,
      status: status || "ACTIVE",
      notes: notes || null,
    },
    ipAddress: req.ip,
  });

  if (result.status === "PENDING") return res.status(202).json({ approvalRequest: result.approvalRequest });
  res.status(201).json({ rate: result.entity });
}

// POST /api/tenant/tax/rates/:id/versions - "Create New Version". Never
// mutates `existing` - closes its window, flips isCurrentVersion, and the
// executor creates a new row. Only the CURRENT version of a family can be
// versioned again; a historical row is read-only.
async function createTaxRateVersion(req, res) {
  const existing = await prisma.taxRate.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Tax rate not found");
  if (!existing.isCurrentVersion) throw new ApiError(409, "This is a historical version and is read-only. Create a new version from the current version instead.");

  const { percentage, calculationMethod, effectiveFrom, effectiveTo, status, notes, reason } = req.body;
  const { from, to } = validateRatePayload({ ...req.body, name: existing.name }, { requireName: false });

  if ((status || existing.status) === "ACTIVE") {
    await assertNoOverlap(req.tenantId, existing.name, from, to, existing.id);
  }

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "tax_master.update",
    module: "tax_master",
    action: "update",
    entityType: "TaxRate",
    entityId: existing.id,
    payload: {
      name: existing.name,
      percentage: Number(percentage),
      calculationMethod: calculationMethod || existing.calculationMethod,
      effectiveFrom: from,
      effectiveTo: to,
      status: status || existing.status,
      notes: notes !== undefined ? notes || null : existing.notes,
      reason: reason || null,
    },
    previousValues: {
      percentage: existing.percentage,
      calculationMethod: existing.calculationMethod,
      effectiveFrom: existing.effectiveFrom,
      effectiveTo: existing.effectiveTo,
      status: existing.status,
      notes: existing.notes,
    },
    reason: reason || null,
    ipAddress: req.ip,
  });

  if (result.status === "PENDING") return res.status(202).json({ approvalRequest: result.approvalRequest });
  res.status(201).json({ rate: result.entity });
}

// POST /api/tenant/tax/rates/:id/activate | /deactivate - in-place toggle on
// the current version only. This is availability, not a value change, so it
// never creates a new version or touches history. Two dedicated routes
// (rather than one generic status PATCH) so each can be gated by its own
// distinct tax_master.activate/deactivate permission, matching the catalog
// and the same dedicated-action-route convention Invoice/Purchase already
// use (send/void/archive).
async function changeTaxRateStatus(req, res, targetStatus) {
  const existing = await prisma.taxRate.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Tax rate not found");
  if (!existing.isCurrentVersion) throw new ApiError(409, "This is a historical version and is read-only.");
  if (existing.status === targetStatus) throw new ApiError(400, `This rate is already ${targetStatus === "ACTIVE" ? "Active" : "Inactive"}`);

  if (targetStatus === "ACTIVE") {
    await assertNoOverlap(req.tenantId, existing.name, existing.effectiveFrom, existing.effectiveTo, existing.id);
  }

  const { reason } = req.body || {};
  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: targetStatus === "ACTIVE" ? "tax_master.activate" : "tax_master.deactivate",
    module: "tax_master",
    action: targetStatus === "ACTIVE" ? "activate" : "deactivate",
    entityType: "TaxRate",
    entityId: existing.id,
    payload: { reason: reason || null },
    previousValues: { status: existing.status },
    reason: reason || null,
    ipAddress: req.ip,
  });

  if (result.status === "PENDING") return res.status(202).json({ approvalRequest: result.approvalRequest });
  res.json({ rate: result.entity });
}

async function activateTaxRate(req, res) {
  return changeTaxRateStatus(req, res, "ACTIVE");
}

async function deactivateTaxRate(req, res) {
  return changeTaxRateStatus(req, res, "INACTIVE");
}

// DELETE /api/tenant/tax/rates/:id - only the unambiguous safe case: a
// version-1 (no history), never-used, current rate. Anything with history
// behind it, or any usage, must be deactivated instead - never deleted.
async function deleteTaxRate(req, res) {
  const existing = await prisma.taxRate.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Tax rate not found");
  if (!existing.isCurrentVersion) throw new ApiError(409, "Historical versions can never be deleted.");
  if (existing.version > 1) throw new ApiError(409, "This rate has version history - deactivate it instead of deleting it.");

  const [invoiceCount, purchaseCount] = await Promise.all([
    prisma.invoiceLineItem.count({ where: { taxRateId: existing.id } }),
    prisma.purchaseLineItem.count({ where: { taxRateId: existing.id } }),
  ]);
  if (invoiceCount + purchaseCount > 0) {
    throw new ApiError(409, "This tax rate has already been used on invoices or purchases and cannot be deleted.");
  }

  const { reason } = req.body || {};
  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "tax_master.delete",
    module: "tax_master",
    action: "delete",
    entityType: "TaxRate",
    entityId: existing.id,
    payload: { reason: reason || null },
    previousValues: { name: existing.name, percentage: existing.percentage, status: existing.status },
    reason: reason || null,
    ipAddress: req.ip,
  });

  if (result.status === "PENDING") return res.status(202).json({ approvalRequest: result.approvalRequest });
  res.json({ deleted: true });
}

module.exports = {
  listTaxCategories,
  getTaxCategory,
  createTaxCategory,
  updateTaxCategory,
  listTaxRates,
  getTaxRate,
  createTaxRate,
  createTaxRateVersion,
  activateTaxRate,
  deactivateTaxRate,
  deleteTaxRate,
};
