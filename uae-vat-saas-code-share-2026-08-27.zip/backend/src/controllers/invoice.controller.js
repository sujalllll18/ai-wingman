const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { resolveTax } = require("../services/taxResolver");
const { calculateInvoiceTotals, round2 } = require("../services/invoiceCalc");
const engine = require("../services/approvalEngine.service");

const VALID_DISCOUNT_TYPES = ["PERCENTAGE", "FIXED"];
// BAD_DEBT added Sprint 3 - one addition to this allow-list, existing
// updatePaymentStatus endpoint/behavior otherwise untouched.
const VALID_PAYMENT_STATUSES = ["UNPAID", "PARTIALLY_PAID", "PAID", "BAD_DEBT"];
const VALID_PAYMENT_METHODS = ["CASH", "BANK_TRANSFER", "CARD", "CHEQUE", "OTHER"];
const VALID_ACTIVITY_TYPES = ["DOWNLOADED", "PREVIEWED"]; // caller-loggable types only - the rest are logged internally alongside their real action

// Full response shape every mutating endpoint should return, so the
// frontend's setInvoice(response.invoice) is always safe to render directly
// (Payments/Activity/Line Items cards) - never a partial object missing
// lists that genuinely exist in the DB.
const FULL_INCLUDE = {
  lineItems: { orderBy: { sortOrder: "asc" } },
  // Legacy relation (Sprint 3, via Payment.invoiceId) - kept for back-compat,
  // no longer the display source for "what has been paid on this invoice"
  // (see paymentAllocations below, the real one now that a Payment can span
  // multiple invoices).
  payments: { orderBy: { paymentDate: "desc" } },
  // Phase 2 Payments module (2026-08-22) - the real source for the Invoice
  // detail page's Payments card: every allocation against this invoice,
  // regardless of which Payment (single- or multi-invoice, from the quick-pay
  // action or the full Payments module) it came from.
  paymentAllocations: {
    include: { payment: { select: { id: true, paymentNumberDisplay: true, paymentDate: true, method: true, reference: true, status: true, currency: true, reconciliationStatus: true } } },
    orderBy: { createdAt: "desc" },
  },
  activities: { orderBy: { createdAt: "desc" } },
};

// Reconciliation Engine (Phase 4, 2026-08-23) - a read-only, computed-at-
// response-time summary of "has the money received against this invoice
// actually been matched to a bank statement yet." Deliberately NOT a stored
// column (would be a third copy of information the Payment rows already
// carry) - derived here, once, from the same paymentAllocations already
// included above, same principle as amountPaid/outstandingAmount being
// derived rather than trusted. Only getInvoice (the detail page) computes
// this, not listInvoices, to avoid an N+1 cost on the list view.
function deriveInvoiceReconciliationSummary(invoice) {
  const confirmed = (invoice.paymentAllocations || []).filter((a) => a.payment?.status === "CONFIRMED");
  if (confirmed.length === 0) return "NOT_RECEIVED";
  const statuses = new Set(confirmed.map((a) => a.payment.reconciliationStatus));
  if (statuses.size === 1 && statuses.has("RECONCILED")) return "RECONCILED";
  if (statuses.has("RECONCILED") || statuses.has("PARTIALLY_RECONCILED")) return "PARTIALLY_RECONCILED";
  return "UNRECONCILED";
}

function assertDraft(invoice) {
  if (invoice.status !== "DRAFT") {
    throw new ApiError(409, "This invoice is no longer a Draft and can't be edited");
  }
}

// Sprint 3 - append-only operational timeline. Written inside the same
// transaction as the state change it describes, never instead of it.
function logActivity(tx, invoiceId, type, description) {
  return tx.invoiceActivity.create({ data: { invoiceId, type, description: description || null } });
}

// Derives UNPAID/PARTIALLY_PAID/PAID purely from amountPaid vs grandTotal -
// the only place this logic lives, so recordPayment is always the single
// source of truth for these three values (BAD_DEBT stays a manual flag set
// via the existing updatePaymentStatus endpoint, cleared automatically the
// next time a real payment comes in).
function derivePaymentStatus(amountPaid, grandTotal) {
  if (amountPaid <= 0) return "UNPAID";
  if (amountPaid >= grandTotal) return "PAID";
  return "PARTIALLY_PAID";
}

// Resolves one line item's snapshot fields from its input, following
// Material (if given) then any explicit overrides, then Tax Master via
// resolveTax(). Snapshot/immutability principle: everything returned here is
// copied once, at pricing time - never re-read from Material/TaxCategory
// again after this call. See docs/features/17-invoice-generation.md §4.
// asOfDate (Import Framework, 2026-08-09) - defaults to "now" so every
// pre-existing call site (manual entry) is unaffected; the importer is the
// one caller that passes the invoice's real historical issueDate, so a
// January-dated imported line resolves against whatever VAT rate was
// actually in effect in January, not today's rate.
async function resolveLineItemSnapshot(tenantId, input, asOfDate = new Date()) {
  const { materialId, taxCategoryId: explicitTaxCategoryId } = input;
  let base = { description: input.description, unit: input.unit, unitPrice: input.unitPrice, taxCategoryId: explicitTaxCategoryId };

  if (materialId) {
    const material = await prisma.material.findFirst({ where: { id: materialId, tenantId } });
    if (!material) throw new ApiError(400, "materialId does not refer to a material on this tenant");
    base = {
      description: input.description ?? material.name,
      unit: input.unit ?? material.unit,
      unitPrice: input.unitPrice ?? material.defaultUnitPrice,
      taxCategoryId: explicitTaxCategoryId ?? material.defaultTaxCategoryId ?? undefined,
    };
  }

  if (!base.description?.trim()) throw new ApiError(400, "Line item description is required");
  if (!base.unit?.trim()) throw new ApiError(400, "Line item unit is required");
  if (base.unitPrice === undefined || base.unitPrice === null || Number.isNaN(Number(base.unitPrice)) || Number(base.unitPrice) < 0) {
    throw new ApiError(400, "Line item unit price must be a non-negative number");
  }
  const quantity = Number(input.quantity);
  if (!quantity || Number.isNaN(quantity) || quantity <= 0) {
    throw new ApiError(400, "Line item quantity must be a positive number");
  }

  let taxSnapshot = { taxCategoryId: null, taxRateId: null, taxRateName: null, taxPercentage: 0, taxCalculationMethod: "EXCLUSIVE" };
  if (base.taxCategoryId) {
    const category = await prisma.taxCategory.findFirst({ where: { id: base.taxCategoryId, tenantId } });
    if (!category) throw new ApiError(400, "taxCategoryId does not refer to a tax category on this tenant");
    const resolved = await resolveTax(tenantId, base.taxCategoryId, asOfDate);
    if (!resolved) {
      const whenLabel = asOfDate.toDateString() === new Date().toDateString() ? "as of today" : `as of ${asOfDate.toISOString().slice(0, 10)}`;
      throw new ApiError(400, `No active tax rate covers "${category.name}" ${whenLabel} - fix Tax Master before pricing this line`);
    }
    taxSnapshot = {
      taxCategoryId: base.taxCategoryId,
      taxRateId: resolved.taxRateId,
      taxRateName: resolved.taxRateName,
      taxPercentage: resolved.percentage,
      taxCalculationMethod: resolved.calculationMethod,
    };
  }

  return {
    materialId: materialId || null,
    description: base.description.trim(),
    unit: base.unit.trim(),
    quantity,
    unitPrice: Number(base.unitPrice),
    sortOrder: input.sortOrder ?? 0,
    ...taxSnapshot,
  };
}

// Recomputes every line item's totals + the invoice's header totals from
// current snapshot fields (quantity/unitPrice/taxPercentage/method + header
// discount) and persists both. Called after any Draft mutation, and again
// authoritatively inside the Send transaction - server-side totals are never
// trusted from the client.
async function recomputeAndPersist(tx, invoiceId) {
  const invoice = await tx.invoice.findUnique({ where: { id: invoiceId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  const result = calculateInvoiceTotals(invoice.lineItems, { discountType: invoice.discountType, discountValue: invoice.discountValue });

  for (const line of result.lines) {
    await tx.invoiceLineItem.update({
      where: { id: line.id },
      data: {
        lineNetAmount: line.lineNetAmount,
        lineDiscountShare: line.lineDiscountShare,
        lineTaxableAmount: line.lineTaxableAmount,
        lineTaxAmount: line.lineTaxAmount,
        lineTotal: line.lineTotal,
      },
    });
  }

  return tx.invoice.update({
    where: { id: invoiceId },
    data: {
      subtotal: result.subtotal,
      discountTotal: result.discountTotal,
      vatTotal: result.vatTotal,
      grandTotal: result.grandTotal,
      // amountPaid itself is only ever touched by recordPayment (payments
      // don't exist until a Draft is Sent) - just keep outstanding in sync
      // with whatever grandTotal now is.
      outstandingAmount: round2(result.grandTotal - invoice.amountPaid),
    },
    include: FULL_INCLUDE,
  });
}

function validateDiscount({ discountType, discountValue }) {
  if (discountType !== undefined && discountType !== null && !VALID_DISCOUNT_TYPES.includes(discountType)) {
    throw new ApiError(400, `discountType must be one of ${VALID_DISCOUNT_TYPES.join(", ")}`);
  }
  if (discountValue !== undefined && discountValue !== null && (Number.isNaN(Number(discountValue)) || Number(discountValue) < 0)) {
    throw new ApiError(400, "discountValue must be a non-negative number");
  }
}

// GET /api/tenant/invoices
// ?archived=true returns only archived invoices; omitted/false (default)
// excludes them - matches this project's documented deletedAt-style
// soft-delete convention (see docs/database-design-specification.md).
async function listInvoices(req, res) {
  const wantArchived = req.query.archived === "true";
  const invoices = await prisma.invoice.findMany({
    where: { tenantId: req.tenantId, archivedAt: wantArchived ? { not: null } : null },
    include: { lineItems: { select: { id: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ invoices });
}

// POST /api/tenant/invoices
// Creates a Draft. No invoiceNumber is assigned here (see §6) - that only
// happens at Send. Business snapshot is taken from req.tenant (attached by
// requireTenantUser); Customer snapshot from the selected Customer or from
// manually supplied fields.
// issueDate (Import Framework, 2026-08-09) - optional, normally left unset
// (every existing caller still gets the same Draft-with-no-issueDate
// behavior). When provided, it's honored at Send instead of being
// overwritten with "now" (see approvalExecutors.js's "Invoice.send"
// executor) - same pre-set-on-Draft/honored-at-finalize pattern
// CreditNote/DebitNote already use for their own issueDate. Also used as
// this Draft's tax-resolution date, so a backdated invoice prices its lines
// against the VAT rate that was actually in effect then, not today's.
async function createInvoice(req, res) {
  const { customerId, customerName, customerAddress, customerTrn, issueDate, dueDate, currency, discountType, discountValue, notes, lineItems } = req.body;
  validateDiscount({ discountType, discountValue });

  let resolvedIssueDate = null;
  if (issueDate) {
    resolvedIssueDate = new Date(issueDate);
    if (Number.isNaN(resolvedIssueDate.getTime())) throw new ApiError(400, "Invalid issueDate");
  }

  let customerSnapshot = { customerId: null, customerName: customerName?.trim() || "", customerAddress: customerAddress || null, customerTrn: customerTrn || null };
  if (customerId) {
    const customer = await prisma.customer.findFirst({ where: { id: customerId, tenantId: req.tenantId } });
    if (!customer) throw new ApiError(400, "customerId does not refer to a customer on this tenant");
    customerSnapshot = {
      customerId: customer.id,
      customerName: customerName?.trim() || customer.name,
      customerAddress: customerAddress !== undefined ? customerAddress || null : customer.address,
      customerTrn: customerTrn !== undefined ? customerTrn || null : customer.trn,
    };
  }
  if (!customerSnapshot.customerName) throw new ApiError(400, "Customer name is required (select a Customer or enter one manually)");

  const tenant = req.tenant;
  const asOfDate = resolvedIssueDate || new Date();
  const resolvedLines = [];
  for (const [i, item] of (lineItems || []).entries()) {
    resolvedLines.push(await resolveLineItemSnapshot(req.tenantId, { ...item, sortOrder: i }, asOfDate));
  }

  const invoice = await prisma.$transaction(async (tx) => {
    const created = await tx.invoice.create({
      data: {
        tenantId: req.tenantId,
        businessName: tenant.name,
        businessAddress: tenant.address || null,
        businessTrn: tenant.trn || null,
        businessContactEmail: tenant.contactEmail || null,
        businessContactPhone: tenant.contactPhone || null,
        ...customerSnapshot,
        issueDate: resolvedIssueDate,
        dueDate: dueDate ? new Date(dueDate) : null,
        currency: currency || "AED",
        discountType: discountType || null,
        discountValue: discountValue !== undefined ? Number(discountValue) : 0,
        notes: notes || null,
        lineItems: { create: resolvedLines },
      },
    });
    await logActivity(tx, created.id, "CREATED", null);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ invoice });
}

// GET /api/tenant/invoices/:id
async function getInvoice(req, res) {
  const invoice = await prisma.invoice.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: FULL_INCLUDE,
  });
  if (!invoice) throw new ApiError(404, "Invoice not found");
  res.json({ invoice: { ...invoice, reconciliationSummary: deriveInvoiceReconciliationSummary(invoice) } });
}

// PATCH /api/tenant/invoices/:id
async function updateInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);

  const { customerId, customerName, customerAddress, customerTrn, issueDate, dueDate, currency, discountType, discountValue, notes } = req.body;
  validateDiscount({ discountType, discountValue });

  // issueDate patch (Import Framework, 2026-08-09) - lets a still-Draft
  // imported invoice's backdated issueDate be corrected during Resolve
  // Errors, same "editable until Send" rule as every other Draft field.
  let resolvedIssueDate;
  if (issueDate !== undefined) {
    resolvedIssueDate = issueDate ? new Date(issueDate) : null;
    if (issueDate && Number.isNaN(resolvedIssueDate.getTime())) throw new ApiError(400, "Invalid issueDate");
  }

  let customerData = {};
  if (customerId !== undefined) {
    if (customerId) {
      const customer = await prisma.customer.findFirst({ where: { id: customerId, tenantId: req.tenantId } });
      if (!customer) throw new ApiError(400, "customerId does not refer to a customer on this tenant");
      customerData = {
        customerId: customer.id,
        customerName: customerName?.trim() || customer.name,
        customerAddress: customerAddress !== undefined ? customerAddress || null : customer.address,
        customerTrn: customerTrn !== undefined ? customerTrn || null : customer.trn,
      };
    } else {
      customerData = { customerId: null };
    }
  }
  if (customerName !== undefined && customerId === undefined) customerData.customerName = customerName.trim();
  if (customerAddress !== undefined && customerId === undefined) customerData.customerAddress = customerAddress || null;
  if (customerTrn !== undefined && customerId === undefined) customerData.customerTrn = customerTrn || null;

  const invoice = await prisma.$transaction(async (tx) => {
    await tx.invoice.update({
      where: { id: existing.id },
      data: {
        ...customerData,
        ...(issueDate !== undefined ? { issueDate: resolvedIssueDate } : {}),
        ...(dueDate !== undefined ? { dueDate: dueDate ? new Date(dueDate) : null } : {}),
        ...(currency !== undefined ? { currency } : {}),
        ...(discountType !== undefined ? { discountType: discountType || null } : {}),
        ...(discountValue !== undefined ? { discountValue: Number(discountValue) } : {}),
        ...(notes !== undefined ? { notes: notes || null } : {}),
      },
    });
    await logActivity(tx, existing.id, "EDITED", null);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ invoice });
}

// POST /api/tenant/invoices/:id/line-items
async function addLineItem(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);

  const snapshot = await resolveLineItemSnapshot(req.tenantId, { ...req.body, sortOrder: existing.lineItems.length }, existing.issueDate || new Date());

  const invoice = await prisma.$transaction(async (tx) => {
    await tx.invoiceLineItem.create({ data: { invoiceId: existing.id, ...snapshot } });
    await logActivity(tx, existing.id, "EDITED", `Added line: ${snapshot.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.status(201).json({ invoice });
}

// PATCH /api/tenant/invoices/:id/line-items/:lineId
async function updateLineItem(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);

  const line = await prisma.invoiceLineItem.findFirst({ where: { id: req.params.lineId, invoiceId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const snapshot = await resolveLineItemSnapshot(req.tenantId, {
    materialId: req.body.materialId !== undefined ? req.body.materialId : line.materialId,
    description: req.body.description !== undefined ? req.body.description : line.description,
    unit: req.body.unit !== undefined ? req.body.unit : line.unit,
    unitPrice: req.body.unitPrice !== undefined ? req.body.unitPrice : line.unitPrice,
    quantity: req.body.quantity !== undefined ? req.body.quantity : line.quantity,
    taxCategoryId: req.body.taxCategoryId !== undefined ? req.body.taxCategoryId : line.taxCategoryId,
    sortOrder: line.sortOrder,
  }, existing.issueDate || new Date());

  const invoice = await prisma.$transaction(async (tx) => {
    await tx.invoiceLineItem.update({ where: { id: line.id }, data: snapshot });
    await logActivity(tx, existing.id, "EDITED", `Updated line: ${snapshot.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ invoice });
}

// DELETE /api/tenant/invoices/:id/line-items/:lineId
async function deleteLineItem(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);

  const line = await prisma.invoiceLineItem.findFirst({ where: { id: req.params.lineId, invoiceId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const invoice = await prisma.$transaction(async (tx) => {
    await tx.invoiceLineItem.delete({ where: { id: line.id } });
    await logActivity(tx, existing.id, "EDITED", `Removed line: ${line.description}`);
    return recomputeAndPersist(tx, existing.id);
  });

  res.json({ invoice });
}

// DELETE /api/tenant/invoices/:id
// Hard delete - only ever permitted for a Draft that never consumed a
// number, per the deletion policy in docs/database-design-specification.md.
async function deleteInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);

  await prisma.invoice.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// POST /api/tenant/invoices/:id/send
// Assigns the sequential number inside a transaction (§6), freezes the
// document. From this point on, per the snapshot/immutability principle,
// nothing about this invoice is ever recomputed from Customer/Material/Tax
// Master/Business Profile again.
// Routed through the Maker-Checker engine (2026-08-06, pilot integration) -
// the Draft-only/line-items validation stays here exactly as before;
// dispatch() decides whether the numbering-assignment transaction below
// (registered as the "Invoice.send" executor in approvalExecutors.js) runs
// immediately or waits for a checker's approval.
// The actual numbering-assignment + finalize transaction, factored out so
// it has exactly one implementation shared by two callers: the "Invoice.send"
// approval executor (approvalExecutors.js, normal Draft -> Send flow) and
// the Import Framework's Sales Invoice adapter (importAdapters.js, which
// creates an already-historical Draft then finalizes it in the same commit,
// never through a second Maker-Checker dispatch - the ImportBatch's own
// commit is the one approval gate for an imported row). issueDate honors
// whatever the Draft already has (see createInvoice/updateInvoice above) -
// "now" only for a normal, never-backdated Draft.
async function sendInvoiceTx(tx, tenantId, invoiceId) {
  await recomputeAndPersist(tx, invoiceId); // authoritative final recalculation

  const current = await tx.invoice.findUnique({ where: { id: invoiceId }, select: { issueDate: true } });

  const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextInvoiceNumber: { increment: 1 } } });
  const assignedNumber = tenant.nextInvoiceNumber - 1;
  const display = `INV-${String(assignedNumber).padStart(6, "0")}`;

  await logActivity(tx, invoiceId, "SENT", display);

  return tx.invoice.update({
    where: { id: invoiceId },
    data: { invoiceNumber: assignedNumber, invoiceNumberDisplay: display, issueDate: current.issueDate || new Date(), status: "SENT" },
    include: FULL_INCLUDE,
  });
}

async function sendInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  assertDraft(existing);
  if (existing.lineItems.length === 0) throw new ApiError(400, "Add at least one line item before sending");
  // Mandatory tax-invoice field check (2026-08-11) - a UAE tax invoice must
  // carry the issuing business's TRN; this was previously never validated,
  // so an invoice could be Sent (and its financial values frozen) with no
  // TRN at all. businessTrn is the frozen snapshot copied from Tenant.trn at
  // creation - checked here rather than re-reading the live Tenant row, same
  // "snapshot is the source of truth once created" principle as everywhere
  // else on this model.
  if (!existing.businessTrn?.trim()) {
    throw new ApiError(400, "Add your business TRN in Business Profile before sending a tax invoice");
  }

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "invoices.send",
    module: "invoices",
    action: "send",
    entityType: "Invoice",
    entityId: existing.id,
    payload: {},
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.json({ invoice: result.entity });
}

// POST /api/tenant/invoices/:id/void
async function voidInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  if (existing.status !== "SENT") throw new ApiError(409, "Only a Sent invoice can be voided");

  const invoice = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "CANCELLED", null);
    return tx.invoice.update({ where: { id: existing.id }, data: { status: "VOID" }, include: FULL_INCLUDE });
  });
  res.json({ invoice });
}

// PATCH /api/tenant/invoices/:id/payment-status
// Unchanged from Sprint 1 except BAD_DEBT joining the allow-list and an
// activity-log entry when that's the value being set. UNPAID/PARTIALLY_PAID/
// PAID are still accepted here for manual override, same as before - Sprint
// 3's recordPayment() is a separate, additive path for the normal case of
// recording a real amount, not a replacement for this endpoint.
async function updatePaymentStatus(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  if (existing.status !== "SENT") throw new ApiError(409, "Payment status only applies to a Sent invoice");

  const { paymentStatus } = req.body;
  if (!VALID_PAYMENT_STATUSES.includes(paymentStatus)) {
    throw new ApiError(400, `paymentStatus must be one of ${VALID_PAYMENT_STATUSES.join(", ")}`);
  }
  if (paymentStatus === "BAD_DEBT" && existing.paymentStatus === "PAID") {
    throw new ApiError(409, "A fully paid invoice can't be marked Bad Debt");
  }

  const invoice = await prisma.$transaction(async (tx) => {
    if (paymentStatus === "BAD_DEBT") await logActivity(tx, existing.id, "BAD_DEBT", null);
    return tx.invoice.update({ where: { id: existing.id }, data: { paymentStatus }, include: FULL_INCLUDE });
  });
  res.json({ invoice });
}

// Phase 2 Payments module (2026-08-22) - the single place that recomputes
// amountPaid/outstandingAmount/paymentStatus, from the sum of this invoice's
// CONFIRMED-payment PaymentAllocation rows (never from the legacy
// Payment.invoiceId link below, which is now a display-only convenience
// field). Every path that can affect an invoice's balance - this quick-pay
// endpoint, and every create/reallocate/cancel action in
// payment.controller.js - calls this, so there is exactly one derivation.
async function recalculatePaymentFields(tx, invoiceId) {
  const invoice = await tx.invoice.findUnique({ where: { id: invoiceId } });
  const agg = await tx.paymentAllocation.aggregate({
    where: { invoiceId, payment: { status: "CONFIRMED" } },
    _sum: { allocatedAmount: true },
  });
  const amountPaid = round2(agg._sum.allocatedAmount || 0);
  const outstandingAmount = round2(Math.max(0, invoice.grandTotal - amountPaid));
  const paymentStatus = derivePaymentStatus(amountPaid, invoice.grandTotal);

  return tx.invoice.update({
    where: { id: invoiceId },
    data: { amountPaid, outstandingAmount, paymentStatus },
    include: FULL_INCLUDE,
  });
}

// POST /api/tenant/invoices/:id/payments
// The original Sprint 3 quick-pay action - kept exactly as-is from the
// caller's point of view (same request/response contract, same single-
// invoice-only shape) so the existing Invoice-detail "Record Payment" modal
// needs zero changes. Internally (Phase 2, 2026-08-22) it now creates a real
// Payment header + one PaymentAllocation row through the same model the new
// Payments module uses, rather than a separate code path, and always wins
// over a prior BAD_DEBT flag (real money received supersedes it).
async function recordPayment(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  if (existing.status !== "SENT") throw new ApiError(409, "Payments can only be recorded against a Sent invoice");

  const { amount, paymentDate, method, reference, notes } = req.body;
  if (amount === undefined || amount === null || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
    throw new ApiError(400, "amount must be a positive number");
  }
  if (!paymentDate) throw new ApiError(400, "paymentDate is required");
  if (!VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  const invoice = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: req.tenantId }, data: { nextPaymentNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextPaymentNumber - 1;
    const display = `PAY-${String(assignedNumber).padStart(6, "0")}`;

    const payment = await tx.payment.create({
      data: {
        tenantId: req.tenantId,
        customerId: existing.customerId,
        customerName: existing.customerName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        invoiceId: existing.id,
        amount: Number(amount),
        currency: existing.currency,
        paymentDate: new Date(paymentDate),
        method,
        reference: reference || null,
        notes: notes || null,
      },
    });
    await tx.paymentAllocation.create({ data: { paymentId: payment.id, invoiceId: existing.id, allocatedAmount: Number(amount) } });
    await tx.paymentActivity.create({
      data: { paymentId: payment.id, type: "CREATED", description: `${existing.currency} ${Number(amount).toFixed(2)} via ${method}, allocated to ${existing.invoiceNumberDisplay || "this invoice"}` },
    });

    await logActivity(tx, existing.id, "PAYMENT_RECORDED", `${existing.currency} ${Number(amount).toFixed(2)} via ${method}`);

    return recalculatePaymentFields(tx, existing.id);
  });

  res.status(201).json({ invoice });
}

// PATCH /api/tenant/invoices/:id/internal-notes
// Operational, never printed/exported (see ClassicTemplate, which only ever
// reads `notes`) - deliberately allowed regardless of status, unlike every
// other field on the invoice, since it's not part of the immutable snapshot.
async function updateInternalNotes(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");

  const invoice = await prisma.invoice.update({
    where: { id: existing.id },
    data: { internalNotes: req.body.internalNotes || null },
    include: FULL_INCLUDE,
  });
  res.json({ invoice });
}

// POST /api/tenant/invoices/:id/archive
// Soft-delete, orthogonal to status - see schema comment. Allowed from any
// status, including Draft (an additional option alongside the existing hard
// Delete Draft action, not a replacement for it).
async function archiveInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  if (existing.archivedAt) throw new ApiError(409, "Already archived");

  const invoice = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "ARCHIVED", null);
    return tx.invoice.update({ where: { id: existing.id }, data: { archivedAt: new Date() }, include: FULL_INCLUDE });
  });
  res.json({ invoice });
}

// POST /api/tenant/invoices/:id/restore
async function restoreInvoice(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");
  if (!existing.archivedAt) throw new ApiError(409, "Not archived");

  const invoice = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "RESTORED", null);
    return tx.invoice.update({ where: { id: existing.id }, data: { archivedAt: null }, include: FULL_INCLUDE });
  });
  res.json({ invoice });
}

// POST /api/tenant/invoices/:id/duplicate
// New Draft, fresh business snapshot (current Tenant info, not copied from
// the source - the whole point is a new document), copied customer/line
// items with tax re-resolved fresh via resolveLineItemSnapshot (same
// pricing-time-resolution rule as every other line item, source is just
// where the material/description/qty/price came from this time instead of
// direct user entry). No invoiceNumber - only assigned if/when this new
// Draft is itself Sent, per §6.
async function duplicateInvoice(req, res) {
  const source = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  if (!source) throw new ApiError(404, "Invoice not found");

  const tenant = req.tenant;
  const resolvedLines = [];
  for (const [i, li] of source.lineItems.entries()) {
    resolvedLines.push(
      await resolveLineItemSnapshot(req.tenantId, {
        materialId: li.materialId,
        description: li.description,
        unit: li.unit,
        unitPrice: li.unitPrice,
        quantity: li.quantity,
        taxCategoryId: li.taxCategoryId,
        sortOrder: i,
      })
    );
  }

  const invoice = await prisma.$transaction(async (tx) => {
    const created = await tx.invoice.create({
      data: {
        tenantId: req.tenantId,
        businessName: tenant.name,
        businessAddress: tenant.address || null,
        businessTrn: tenant.trn || null,
        businessContactEmail: tenant.contactEmail || null,
        businessContactPhone: tenant.contactPhone || null,
        customerId: source.customerId,
        customerName: source.customerName,
        customerAddress: source.customerAddress,
        customerTrn: source.customerTrn,
        currency: source.currency,
        discountType: source.discountType,
        discountValue: source.discountValue,
        notes: source.notes,
        lineItems: { create: resolvedLines },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Duplicated from ${source.invoiceNumberDisplay || "a draft"}`);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ invoice });
}

// POST /api/tenant/invoices/:id/activity
// Lets the Viewer log DOWNLOADED/PREVIEWED - the only two activity types a
// caller sets directly rather than earning as a side effect of a real state
// change. Best-effort: the frontend fires this without blocking on it.
async function logInvoiceActivity(req, res) {
  const existing = await prisma.invoice.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Invoice not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.invoiceActivity.create({ data: { invoiceId: existing.id, type, description: description || null } });
  res.status(201).json({ activity });
}

module.exports = {
  listInvoices,
  createInvoice,
  getInvoice,
  updateInvoice,
  addLineItem,
  updateLineItem,
  deleteLineItem,
  deleteInvoice,
  sendInvoice,
  voidInvoice,
  updatePaymentStatus,
  recordPayment,
  updateInternalNotes,
  archiveInvoice,
  restoreInvoice,
  duplicateInvoice,
  logInvoiceActivity,
  // Exported for approvalExecutors.js's "Invoice.send" executor and
  // importAdapters.js's Sales Invoice adapter - the exact same
  // recalculation/logging/finalize helpers sendInvoice always used, not a copy.
  resolveLineItemSnapshot,
  recomputeAndPersist,
  logActivity,
  sendInvoiceTx,
  FULL_INCLUDE,
  // Exported for payment.controller.js (Phase 2 Payments module, 2026-08-22) -
  // the exact same balance-derivation helper this file's own recordPayment
  // uses, not a copy.
  recalculatePaymentFields,
};
