const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { computePeriodBounds, aggregatePeriod, computeValidationWarnings } = require("../services/vatReturnCalc");

const VALID_PERIOD_TYPES = ["MONTHLY", "QUARTERLY"];
const VALID_ACTIVITY_TYPES = ["VIEWED", "EXPORTED"]; // caller-loggable types only, rest are logged internally
const CATEGORY_KEYS = ["STANDARD_RATED", "ZERO_RATED", "EXEMPT", "OUT_OF_SCOPE", "OUTPUT_VAT", "INPUT_VAT", "TOTAL_SALES", "TOTAL_PURCHASES"];

function logActivity(tx, vatReturnId, type, description) {
  return tx.vatReturnActivity.create({ data: { vatReturnId, type, description: description || null } });
}

function assertDraft(vatReturn) {
  if (vatReturn.status !== "DRAFT") {
    throw new ApiError(409, "This VAT Return is locked and can't be modified - unlock it first");
  }
}

// GET /api/tenant/vat-returns
async function listVatReturns(req, res) {
  const vatReturns = await prisma.vatReturn.findMany({
    where: { tenantId: req.tenantId },
    orderBy: { periodStart: "desc" },
  });
  res.json({ vatReturns });
}

// POST /api/tenant/vat-returns
// The core "auto-generate, no manual calculation" entry point. If a return
// already exists for the exact same period: regenerates it in place if
// still DRAFT, or rejects if it's already LOCKED (immutable).
async function generateVatReturn(req, res) {
  const { periodType, year, month, quarter } = req.body;
  if (!VALID_PERIOD_TYPES.includes(periodType)) {
    throw new ApiError(400, `periodType must be one of ${VALID_PERIOD_TYPES.join(", ")}`);
  }
  if (!year) throw new ApiError(400, "year is required");
  if (periodType === "MONTHLY" && !month) throw new ApiError(400, "month is required for a Monthly return");
  if (periodType === "QUARTERLY" && !quarter) throw new ApiError(400, "quarter is required for a Quarterly return");

  const bounds = computePeriodBounds(periodType, year, periodType === "MONTHLY" ? month : quarter);
  if (!bounds) throw new ApiError(400, "Could not compute a valid period from the given inputs");
  const { periodStart, periodEnd, periodLabel } = bounds;

  const tenant = req.tenant;
  const totals = await aggregatePeriod(req.tenantId, periodStart, periodEnd);
  // creditNoteCount/debitNoteCount/creditNotesTotal/debitNotesTotal aren't
  // VatReturn columns (deliberately not added - the existing sales/purchase
  // buckets and outputVat/inputVat are already net-of-notes, per the "don't
  // add fields unless technically required" instruction) - stripped out
  // before the Prisma write, re-attached to the API response only below.
  const { creditNoteCount, debitNoteCount, salesDebitNoteCount, creditNotesTotal, debitNotesTotal, salesDebitNotesTotal, ...persistableTotals } = totals;

  const existing = await prisma.vatReturn.findFirst({ where: { tenantId: req.tenantId, periodStart, periodEnd } });
  if (existing) assertDraft(existing);

  const vatReturn = await prisma.$transaction(async (tx) => {
    let record;
    if (existing) {
      record = await tx.vatReturn.update({
        where: { id: existing.id },
        data: { ...persistableTotals, generatedAt: new Date() },
      });
      await logActivity(tx, record.id, "REGENERATED", periodLabel);
    } else {
      record = await tx.vatReturn.create({
        data: {
          tenantId: req.tenantId,
          periodType,
          periodStart,
          periodEnd,
          periodLabel,
          businessName: tenant.name,
          businessTrn: tenant.trn || null,
          businessAddress: tenant.address || null,
          ...persistableTotals,
        },
      });
      await logActivity(tx, record.id, "GENERATED", periodLabel);
    }
    return tx.vatReturn.findUnique({ where: { id: record.id }, include: { activities: { orderBy: { createdAt: "desc" } } } });
  });

  res.status(201).json({ vatReturn: { ...vatReturn, creditNoteCount, debitNoteCount, salesDebitNoteCount, creditNotesTotal, debitNotesTotal, salesDebitNotesTotal } });
}

// GET /api/tenant/vat-returns/:id - includes live-computed validation
// warnings (never stored, always reflects the current state of Invoice/
// Purchase data, not just what was true at generation time).
async function getVatReturn(req, res) {
  const vatReturn = await prisma.vatReturn.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { activities: { orderBy: { createdAt: "desc" } } },
  });
  if (!vatReturn) throw new ApiError(404, "VAT Return not found");

  const warnings = await computeValidationWarnings(req.tenantId, vatReturn.periodStart, vatReturn.periodEnd);
  res.json({ vatReturn, warnings });
}

// POST /api/tenant/vat-returns/:id/regenerate - DRAFT only. Re-runs the
// exact same aggregation as generate, for when more Invoices/Purchases have
// been Sent/Recorded into this period since it was first generated.
async function regenerateVatReturn(req, res) {
  const existing = await prisma.vatReturn.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "VAT Return not found");
  assertDraft(existing);

  const totals = await aggregatePeriod(req.tenantId, existing.periodStart, existing.periodEnd);
  const { creditNoteCount, debitNoteCount, salesDebitNoteCount, creditNotesTotal, debitNotesTotal, salesDebitNotesTotal, ...persistableTotals } = totals;

  const vatReturn = await prisma.$transaction(async (tx) => {
    await tx.vatReturn.update({ where: { id: existing.id }, data: { ...persistableTotals, generatedAt: new Date() } });
    await logActivity(tx, existing.id, "REGENERATED", existing.periodLabel);
    return tx.vatReturn.findUnique({ where: { id: existing.id }, include: { activities: { orderBy: { createdAt: "desc" } } } });
  });

  res.json({ vatReturn: { ...vatReturn, creditNoteCount, debitNoteCount, salesDebitNoteCount, creditNotesTotal, debitNotesTotal, salesDebitNotesTotal } });
}

// POST /api/tenant/vat-returns/:id/lock
async function lockVatReturn(req, res) {
  const existing = await prisma.vatReturn.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "VAT Return not found");
  assertDraft(existing);

  const vatReturn = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "LOCKED", null);
    await tx.vatReturn.update({ where: { id: existing.id }, data: { status: "LOCKED", lockedAt: new Date() } });
    return tx.vatReturn.findUnique({ where: { id: existing.id }, include: { activities: { orderBy: { createdAt: "desc" } } } });
  });
  res.json({ vatReturn });
}

// POST /api/tenant/vat-returns/:id/unlock
async function unlockVatReturn(req, res) {
  const existing = await prisma.vatReturn.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "VAT Return not found");
  if (existing.status !== "LOCKED") throw new ApiError(409, "This VAT Return is not locked");

  const vatReturn = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "UNLOCKED", null);
    await tx.vatReturn.update({ where: { id: existing.id }, data: { status: "DRAFT", lockedAt: null } });
    return tx.vatReturn.findUnique({ where: { id: existing.id }, include: { activities: { orderBy: { createdAt: "desc" } } } });
  });
  res.json({ vatReturn });
}

// GET /api/tenant/vat-returns/:id/drilldown?type=sales|purchases&category=...
// Never reads from any stored snapshot list - always re-queries Invoice/
// PurchaseBill live using this return's own period bounds, so drill-down
// always reflects "every calculated value must support drill-down to its
// source transactions" even for an old return.
async function getDrilldown(req, res) {
  const vatReturn = await prisma.vatReturn.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!vatReturn) throw new ApiError(404, "VAT Return not found");

  const { type, category } = req.query;
  if (!["sales", "purchases"].includes(type)) throw new ApiError(400, "type must be sales or purchases");
  if (!CATEGORY_KEYS.includes(category)) throw new ApiError(400, `category must be one of ${CATEGORY_KEYS.join(", ")}`);

  const isClassificationCategory = ["STANDARD_RATED", "ZERO_RATED", "EXEMPT", "OUT_OF_SCOPE"].includes(category);

  if (type === "sales") {
    const invoices = await prisma.invoice.findMany({
      where: { tenantId: req.tenantId, status: "SENT", issueDate: { gte: vatReturn.periodStart, lte: vatReturn.periodEnd } },
      include: { lineItems: { include: { taxCategory: true } } },
      orderBy: { issueDate: "asc" },
    });
    const filtered = isClassificationCategory
      ? invoices.filter((i) => i.lineItems.some((li) => (li.taxCategory?.classification || "OUT_OF_SCOPE") === category))
      : invoices;
    res.json({
      transactions: filtered.map((i) => ({
        id: i.id,
        reference: i.invoiceNumberDisplay,
        counterparty: i.customerName,
        date: i.issueDate,
        subtotal: i.subtotal,
        vatTotal: i.vatTotal,
        grandTotal: i.grandTotal,
      })),
    });
  } else {
    const purchases = await prisma.purchaseBill.findMany({
      where: { tenantId: req.tenantId, status: "RECORDED", purchaseDate: { gte: vatReturn.periodStart, lte: vatReturn.periodEnd } },
      include: { lineItems: { include: { taxCategory: true } } },
      orderBy: { purchaseDate: "asc" },
    });
    const filtered = isClassificationCategory
      ? purchases.filter((p) => p.lineItems.some((li) => (li.taxCategory?.classification || "OUT_OF_SCOPE") === category))
      : purchases;
    res.json({
      transactions: filtered.map((p) => ({
        id: p.id,
        reference: p.billNumberDisplay,
        counterparty: p.vendorName,
        date: p.purchaseDate,
        subtotal: p.subtotal,
        vatTotal: p.vatTotal,
        grandTotal: p.grandTotal,
      })),
    });
  }
}

// POST /api/tenant/vat-returns/:id/activity - lets the Preview/Export UI log
// VIEWED/EXPORTED, same pattern as Invoice/Purchase Viewer activity logging.
async function logVatReturnActivity(req, res) {
  const existing = await prisma.vatReturn.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "VAT Return not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.vatReturnActivity.create({ data: { vatReturnId: existing.id, type, description: description || null } });
  res.status(201).json({ activity });
}

module.exports = {
  listVatReturns,
  generateVatReturn,
  getVatReturn,
  regenerateVatReturn,
  lockVatReturn,
  unlockVatReturn,
  getDrilldown,
  logVatReturnActivity,
};
