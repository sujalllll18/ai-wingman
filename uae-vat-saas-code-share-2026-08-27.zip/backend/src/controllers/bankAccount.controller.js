// Bank Account master (Banking module, Phase 3 2026-08-22). Plain RBAC-gated
// CRUD, not routed through the Maker-Checker engine - unlike Customer/Tax
// Rate, creating or editing a Bank Account has no direct VAT/financial
// consequence of its own (it's a container statements import into, not a
// transaction), so wiring approvalEngine.dispatch() here would be adding
// process weight the brief never asked for. Deactivating (not deleting) is
// the only lifecycle action, same ACTIVE/INACTIVE convention as Customer/
// Vendor/TaxCategory - a Bank Account is never hard-deleted once created
// since real BankTransaction rows may already reference it.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

const VALID_ACCOUNT_TYPES = ["CURRENT", "SAVINGS", "OTHER"];
const VALID_STATUSES = ["ACTIVE", "INACTIVE"];

function logActivity(tx, bankAccountId, type, description) {
  return tx.bankAccountActivity.create({ data: { bankAccountId, type, description: description || null } });
}

function validateFields({ accountName, bankName, accountType, currency, status }, { requireCore }) {
  if (requireCore && !accountName?.trim()) throw new ApiError(400, "Account name is required");
  if (requireCore && !bankName?.trim()) throw new ApiError(400, "Bank name is required");
  if (accountType && !VALID_ACCOUNT_TYPES.includes(accountType)) {
    throw new ApiError(400, `accountType must be one of ${VALID_ACCOUNT_TYPES.join(", ")}`);
  }
  if (currency !== undefined && currency !== null && !currency.trim()) {
    throw new ApiError(400, "currency cannot be blank");
  }
  if (status && !VALID_STATUSES.includes(status)) {
    throw new ApiError(400, `status must be one of ${VALID_STATUSES.join(", ")}`);
  }
}

// GET /api/tenant/banking/accounts
async function listBankAccounts(req, res) {
  const accounts = await prisma.bankAccount.findMany({
    where: { tenantId: req.tenantId },
    orderBy: { createdAt: "desc" },
  });
  res.json({ bankAccounts: accounts });
}

// POST /api/tenant/banking/accounts
async function createBankAccount(req, res) {
  const { accountName, bankName, accountType, currency, accountNumber, openingBalance, status } = req.body;
  validateFields({ accountName, bankName, accountType, currency, status }, { requireCore: true });
  if (openingBalance !== undefined && openingBalance !== null && Number.isNaN(Number(openingBalance))) {
    throw new ApiError(400, "openingBalance must be a number");
  }

  const account = await prisma.$transaction(async (tx) => {
    const created = await tx.bankAccount.create({
      data: {
        tenantId: req.tenantId,
        accountName: accountName.trim(),
        bankName: bankName.trim(),
        accountType: accountType || "CURRENT",
        currency: currency?.trim() || "AED",
        accountNumber: accountNumber || null,
        openingBalance: openingBalance !== undefined && openingBalance !== null && openingBalance !== "" ? Number(openingBalance) : null,
        status: status || "ACTIVE",
      },
    });
    await logActivity(tx, created.id, "ACCOUNT_CREATED", `${created.bankName} - ${created.accountName}`);
    return created;
  });

  res.status(201).json({ bankAccount: account });
}

// GET /api/tenant/banking/accounts/:id
async function getBankAccount(req, res) {
  const account = await prisma.bankAccount.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!account) throw new ApiError(404, "Bank account not found");
  const [transactionCount, activities] = await Promise.all([
    prisma.bankTransaction.count({ where: { bankAccountId: account.id, status: "ACTIVE" } }),
    prisma.bankAccountActivity.findMany({ where: { bankAccountId: account.id }, orderBy: { createdAt: "desc" } }),
  ]);
  res.json({ bankAccount: account, transactionCount, activities });
}

// PATCH /api/tenant/banking/accounts/:id
async function updateBankAccount(req, res) {
  const existing = await prisma.bankAccount.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Bank account not found");

  const { accountName, bankName, accountType, currency, accountNumber, openingBalance, status } = req.body;
  validateFields({ accountName, bankName, accountType, currency, status }, { requireCore: false });
  if (openingBalance !== undefined && openingBalance !== null && openingBalance !== "" && Number.isNaN(Number(openingBalance))) {
    throw new ApiError(400, "openingBalance must be a number");
  }

  const patch = {
    ...(accountName !== undefined ? { accountName: accountName.trim() } : {}),
    ...(bankName !== undefined ? { bankName: bankName.trim() } : {}),
    ...(accountType !== undefined ? { accountType } : {}),
    ...(currency !== undefined ? { currency: currency.trim() } : {}),
    ...(accountNumber !== undefined ? { accountNumber: accountNumber || null } : {}),
    ...(openingBalance !== undefined ? { openingBalance: openingBalance === null || openingBalance === "" ? null : Number(openingBalance) } : {}),
    ...(status !== undefined ? { status } : {}),
  };

  const account = await prisma.$transaction(async (tx) => {
    const updated = await tx.bankAccount.update({ where: { id: existing.id }, data: patch });
    await logActivity(tx, existing.id, "ACCOUNT_EDITED", null);
    return updated;
  });

  res.json({ bankAccount: account });
}

module.exports = { listBankAccounts, createBankAccount, getBankAccount, updateBankAccount };
