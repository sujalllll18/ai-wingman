const ApiError = require("../utils/ApiError");
const ticketService = require("../services/ticket.service");

// Platform Admin (support team) side Support Center handlers (2026-08-07).
// req.platformAdmin is set by requirePlatformAdmin. No RBAC/permission gate
// here - Platform Admin auth is deliberately coarse/binary (see Phase 1
// audit), same as every other platform-admin route in this app.

async function getDashboard(req, res) {
  res.json({ stats: await ticketService.getDashboardStats() });
}

async function listCategories(req, res) {
  res.json({ categories: await ticketService.listCategories() });
}

async function listSlaPolicies(req, res) {
  res.json({ policies: await ticketService.listSlaPolicies() });
}

async function listAdmins(req, res) {
  res.json({ admins: await ticketService.listAssignableAdmins() });
}

async function listTickets(req, res) {
  const { tenantId, plan, module, priority, status, assignedToAdminId, dateFrom, dateTo, search } = req.query;
  const tickets = await ticketService.listAllTickets({ tenantId, plan, module, priority, status, assignedToAdminId, dateFrom, dateTo, search });
  res.json({ tickets });
}

async function getTicket(req, res) {
  const result = await ticketService.getTicketForAdmin(req.params.id);
  res.json(result);
}

async function addComment(req, res) {
  const comment = await ticketService.addCommentAsAdmin(req.platformAdmin.id, req.params.id, req.body);
  res.status(201).json({ comment });
}

async function assign(req, res) {
  const { assignedToAdminId, transfer } = req.body;
  if (!assignedToAdminId) throw new ApiError(400, "assignedToAdminId is required");
  const ticket = await ticketService.assignTicket(req.platformAdmin.id, req.params.id, assignedToAdminId, { transfer });
  res.json({ ticket });
}

async function changePriority(req, res) {
  const { priority } = req.body;
  if (!priority) throw new ApiError(400, "priority is required");
  const ticket = await ticketService.changePriority(req.platformAdmin.id, req.params.id, priority);
  res.json({ ticket });
}

async function changeStatus(req, res) {
  const { status } = req.body;
  if (!status) throw new ApiError(400, "status is required");
  const ticket = await ticketService.changeStatus(req.platformAdmin.id, req.params.id, status);
  res.json({ ticket });
}

async function addWatcher(req, res) {
  const watcher = await ticketService.addWatcher(req.platformAdmin.id, req.params.id, req.body);
  res.status(201).json({ watcher });
}

async function removeWatcher(req, res) {
  await ticketService.removeWatcher(req.params.id, req.params.watcherId);
  res.status(204).end();
}

async function merge(req, res) {
  const { intoTicketId } = req.body;
  if (!intoTicketId) throw new ApiError(400, "intoTicketId is required");
  const ticket = await ticketService.mergeTicket(req.platformAdmin.id, req.params.id, intoTicketId);
  res.json({ ticket });
}

async function link(req, res) {
  const { linkedTicketId } = req.body;
  if (!linkedTicketId) throw new ApiError(400, "linkedTicketId is required");
  const ticket = await ticketService.linkTicket(req.platformAdmin.id, req.params.id, linkedTicketId);
  res.json({ ticket });
}

async function addAttachment(req, res) {
  if (!req.file) throw new ApiError(400, "No file uploaded");
  const attachment = await ticketService.addAttachment(req.params.id, req.file, {
    commentId: req.body.commentId,
    isScreenshot: req.body.isScreenshot === "true",
    uploaderType: "PLATFORM_ADMIN",
    uploaderId: req.platformAdmin.id,
  });
  res.status(201).json({ attachment });
}

module.exports = {
  getDashboard,
  listCategories,
  listSlaPolicies,
  listAdmins,
  listTickets,
  getTicket,
  addComment,
  assign,
  changePriority,
  changeStatus,
  addWatcher,
  removeWatcher,
  merge,
  link,
  addAttachment,
};
