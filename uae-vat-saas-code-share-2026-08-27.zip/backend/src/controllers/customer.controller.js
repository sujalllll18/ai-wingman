const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
// approvalEngine.service.js requires approvalExecutors.js itself, which is
// where Customer.create/Customer.update are registered - importing the
// engine here is enough, no separate require needed.
const engine = require("../services/approvalEngine.service");

const VALID_TYPES = ["BUSINESS", "INDIVIDUAL"];
const VALID_STATUSES = ["ACTIVE", "INACTIVE"];
const TRN_RE = /^\d{15}$/;

function validateFields({ name, trn, customerType, status }, { requireName }) {
  if (requireName && !name?.trim()) throw new ApiError(400, "Customer name is required");
  if (trn && !TRN_RE.test(trn)) throw new ApiError(400, "TRN must be exactly 15 digits");
  if (customerType && !VALID_TYPES.includes(customerType)) {
    throw new ApiError(400, `customerType must be one of ${VALID_TYPES.join(", ")}`);
  }
  if (status && !VALID_STATUSES.includes(status)) {
    throw new ApiError(400, `status must be one of ${VALID_STATUSES.join(", ")}`);
  }
}

// GET /api/tenant/customers
// Returns every Customer for the caller's own Tenant, unfiltered - the
// frontend does search/filter/sort/pagination client-side, same pattern
// listTenants already uses for the Platform Admin's Tenant List.
async function listCustomers(req, res) {
  const customers = await prisma.customer.findMany({
    where: { tenantId: req.tenantId },
    orderBy: { createdAt: "desc" },
  });
  res.json({ customers });
}

// POST /api/tenant/customers
// Routed through the Maker-Checker engine (2026-08-06, pilot integration) -
// validation stays here exactly as before; dispatch() decides whether this
// runs immediately (today's behavior, when no Approval Rule is configured)
// or becomes a pending ApprovalRequest instead. Either way the actual
// Prisma write is Customer.create, registered once in approvalExecutors.js.
async function createCustomer(req, res) {
  const { name, address, trn, customerType, status } = req.body;
  validateFields({ name, trn, customerType, status }, { requireName: true });

  const payload = {
    name: name.trim(),
    address: address || null,
    trn: trn || null,
    customerType: customerType || "BUSINESS",
    status: status || "ACTIVE",
  };

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "customers.create",
    module: "customers",
    action: "create",
    entityType: "Customer",
    payload,
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.status(201).json({ customer: result.entity });
}

// GET /api/tenant/customers/:id
async function getCustomer(req, res) {
  const customer = await prisma.customer.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
  });
  if (!customer) throw new ApiError(404, "Customer not found");
  res.json({ customer });
}

// PATCH /api/tenant/customers/:id
async function updateCustomer(req, res) {
  const existing = await prisma.customer.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
  });
  if (!existing) throw new ApiError(404, "Customer not found");

  const { name, address, trn, customerType, status } = req.body;
  validateFields({ name, trn, customerType, status }, { requireName: false });

  const patch = {
    ...(name !== undefined ? { name: name.trim() } : {}),
    ...(address !== undefined ? { address: address || null } : {}),
    ...(trn !== undefined ? { trn: trn || null } : {}),
    ...(customerType !== undefined ? { customerType } : {}),
    ...(status !== undefined ? { status } : {}),
  };
  const previousValues = Object.fromEntries(Object.keys(patch).map((key) => [key, existing[key]]));

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "customers.update",
    module: "customers",
    action: "update",
    entityType: "Customer",
    entityId: existing.id,
    payload: patch,
    previousValues,
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.json({ customer: result.entity });
}

module.exports = { listCustomers, createCustomer, getCustomer, updateCustomer };
