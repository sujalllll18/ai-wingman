const fs = require("fs");
const path = require("path");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ASSET_FIELDS = { logo: "logoUrl", stamp: "stampUrl", signature: "signatureUrl" };
// Matches the size hints already shown in the Brand Assets UI
// (BrandAssetCard's recommendedFormats text) - multer's own `limits` in
// businessProfile.routes.js is one shared, more generous ceiling (2MB) for
// all three fields, since multer can't vary its limit by fieldname; this is
// the real, per-asset-type enforcement.
const MAX_ASSET_BYTES = { logo: 2 * 1024 * 1024, stamp: 2 * 1024 * 1024, signature: 1 * 1024 * 1024 };

// GET /api/tenant/business-profile
// Everything a tenant self-service session needs to render its own profile
// page and (via the two invoice-rendering call sites) its brand assets -
// scoped strictly by req.tenantId from the verified JWT. name/trn are
// included read-only (never editable here, see updateBusinessProfile).
async function getBusinessProfile(req, res) {
  const tenant = await prisma.tenant.findUnique({
    where: { id: req.tenantId },
    select: { name: true, trn: true, address: true, contactEmail: true, contactPhone: true, logoUrl: true, stampUrl: true, signatureUrl: true },
  });
  if (!tenant) throw new ApiError(404, "Tenant not found");
  res.json({ businessProfile: tenant });
}

// PATCH /api/tenant/business-profile
// Only contactEmail/contactPhone/address are ever writable here - name and
// trn are compliance-sensitive/locked-after-onboarding and deliberately
// have no write path in this endpoint at all (not just hidden client-side).
async function updateBusinessProfile(req, res) {
  const { contactEmail, contactPhone, address } = req.body;

  if (contactEmail !== undefined && contactEmail !== null && contactEmail !== "" && !EMAIL_RE.test(contactEmail)) {
    throw new ApiError(400, "Enter a valid contact email address");
  }
  if (contactPhone !== undefined && contactPhone !== null && contactPhone !== "" && String(contactPhone).length > 30) {
    throw new ApiError(400, "Contact number is too long");
  }
  if (address !== undefined && address !== null && String(address).length > 500) {
    throw new ApiError(400, "Business address is too long");
  }

  const tenant = await prisma.tenant.update({
    where: { id: req.tenantId },
    data: {
      ...(contactEmail !== undefined ? { contactEmail: contactEmail || null } : {}),
      ...(contactPhone !== undefined ? { contactPhone: contactPhone || null } : {}),
      ...(address !== undefined ? { address: address || null } : {}),
    },
    select: { name: true, trn: true, address: true, contactEmail: true, contactPhone: true, logoUrl: true, stampUrl: true, signatureUrl: true },
  });
  res.json({ businessProfile: tenant });
}

// POST /api/tenant/business-profile/:assetType(logo|stamp|signature)
// Same disk-storage pattern as Purchase OCR/Import uploads - multer already
// wrote the file to uploads/business/ (see businessProfile.routes.js) by
// the time this runs. Replace: the old file on disk is deleted (best-effort,
// never blocks the response) and the Tenant row's URL is overwritten - one
// current file per slot, no versioned list, matching the UI's own
// Upload/Replace/Remove model.
async function uploadBusinessAsset(req, res) {
  const assetType = req.params.assetType;
  const field = ASSET_FIELDS[assetType];
  if (!field) throw new ApiError(404, "Unknown asset type");
  if (!req.file) throw new ApiError(400, "No file uploaded");

  if (req.file.size > MAX_ASSET_BYTES[assetType]) {
    fs.unlink(req.file.path, () => {});
    const maxMb = MAX_ASSET_BYTES[assetType] / (1024 * 1024);
    throw new ApiError(400, `${assetType[0].toUpperCase()}${assetType.slice(1)} must be ${maxMb}MB or smaller`);
  }

  const existing = await prisma.tenant.findUnique({ where: { id: req.tenantId }, select: { [field]: true } });
  const fileUrl = `/uploads/business/${req.file.filename}`;

  const tenant = await prisma.tenant.update({
    where: { id: req.tenantId },
    data: { [field]: fileUrl },
    select: { name: true, trn: true, address: true, contactEmail: true, contactPhone: true, logoUrl: true, stampUrl: true, signatureUrl: true },
  });

  deleteOldAssetFile(existing?.[field]);
  res.status(201).json({ businessProfile: tenant });
}

// DELETE /api/tenant/business-profile/:assetType(logo|stamp|signature)
async function removeBusinessAsset(req, res) {
  const assetType = req.params.assetType;
  const field = ASSET_FIELDS[assetType];
  if (!field) throw new ApiError(404, "Unknown asset type");

  const existing = await prisma.tenant.findUnique({ where: { id: req.tenantId }, select: { [field]: true } });

  const tenant = await prisma.tenant.update({
    where: { id: req.tenantId },
    data: { [field]: null },
    select: { name: true, trn: true, address: true, contactEmail: true, contactPhone: true, logoUrl: true, stampUrl: true, signatureUrl: true },
  });

  deleteOldAssetFile(existing?.[field]);
  res.json({ businessProfile: tenant });
}

// Best-effort disk cleanup - never lets a filesystem error fail the actual
// DB update, which is the source of truth for what's "current." A file left
// behind after Replace/Remove is harmless (unguessable uuid filename,
// unreferenced by anything), unlike a failed DB update.
function deleteOldAssetFile(oldUrl) {
  if (!oldUrl || !oldUrl.startsWith("/uploads/business/")) return;
  const filePath = path.join(__dirname, "..", "..", oldUrl);
  fs.unlink(filePath, () => {});
}

module.exports = { getBusinessProfile, updateBusinessProfile, uploadBusinessAsset, removeBusinessAsset };
