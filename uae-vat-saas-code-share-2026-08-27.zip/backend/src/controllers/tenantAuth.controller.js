const bcrypt = require("bcrypt");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { signTenantUserToken } = require("../utils/jwt");
const { isStrongPassword, PASSWORD_REQUIREMENT_MESSAGE } = require("../utils/passwordPolicy");
const { getPlanLimits } = require("../config/plans");
const { assignDefaultUserRole } = require("../services/roleSeed.service");

// POST /api/tenant/login
// Tenant Owner and Tenant Staff both log in here. Email is globally unique
// across all Tenants, so no separate "which Tenant" field is needed.
async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) throw new ApiError(400, "email and password are required");

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new ApiError(401, "Invalid credentials");

  const tenant = await prisma.tenant.findUnique({ where: { id: user.tenantId } });
  if (!tenant) throw new ApiError(401, "Invalid credentials");
  if (tenant.status === "SUSPENDED") {
    throw new ApiError(403, "This Tenant account is suspended. Contact your platform administrator.");
  }
  // Team self-service module (2026-08-09) - same shape as the Tenant-level
  // SUSPENDED check just above, one level down. Without this, "Deactivate"
  // would only be a cosmetic label (the account would still work exactly
  // as before) - the Team page's own confirmation message tells the user
  // this account "will no longer be able to sign in," which has to stay true.
  if (user.status === "INACTIVE") {
    throw new ApiError(403, "This account has been deactivated. Contact your business owner or platform administrator.");
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) throw new ApiError(401, "Invalid credentials");

  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  const token = signTenantUserToken(user);
  res.json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, mustChangePassword: user.mustChangePassword },
    tenant: { id: tenant.id, name: tenant.name, plan: tenant.plan },
  });
}

// POST /api/tenant/change-password
// Reachable even when the caller's token carries mustChangePassword=true -
// requireTenantUser explicitly allowlists this route for that reason (see
// middleware/auth.js). Works identically for a genuinely temporary
// password OR a routine self-service change later - the same "prove you
// know the current password, then set a new one" flow either way. Issues a
// fresh token reflecting the cleared flag, since the caller's existing
// token would otherwise keep claiming mustChangePassword for the rest of
// its lifetime (JWT claims are fixed at signing time).
async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    throw new ApiError(400, "currentPassword and newPassword are required");
  }
  if (!isStrongPassword(newPassword)) {
    throw new ApiError(400, PASSWORD_REQUIREMENT_MESSAGE);
  }

  const user = await prisma.user.findUnique({ where: { id: req.tenantUser.id } });
  if (!user) throw new ApiError(404, "User not found");

  const valid = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!valid) throw new ApiError(401, "Current password is incorrect");

  if (currentPassword === newPassword) {
    throw new ApiError(400, "New password must be different from the current password");
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash, mustChangePassword: false },
  });

  const token = signTenantUserToken(updated);
  res.json({
    token,
    user: { id: updated.id, name: updated.name, email: updated.email, role: updated.role, mustChangePassword: updated.mustChangePassword },
  });
}

// GET /api/tenant/team
// List of users at the logged-in user's own Tenant. Scoped strictly by
// req.tenantId from the verified JWT - never client input.
// usage (Team self-service module, 2026-08-09) - added so the page can show
// "X of Y users" without a second round trip; purely informational on the
// frontend, never used there to gate anything (see createTeamMember for the
// one real enforcement point). activeCount only counts status="ACTIVE" -
// same rule the create endpoint's own limit check uses.
async function listTeam(req, res) {
  const [users, tenant] = await Promise.all([
    prisma.user.findMany({
      where: { tenantId: req.tenantId },
      select: { id: true, name: true, email: true, role: true, status: true, lastLoginAt: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    }),
    prisma.tenant.findUnique({ where: { id: req.tenantId } }),
  ]);

  const limits = await getPlanLimits(tenant.plan);
  const activeCount = users.filter((u) => u.status === "ACTIVE").length;

  res.json({ users, usage: { activeCount, maxUsers: limits.maxUsers } });
}

// POST /api/tenant/team
// Tenant self-service equivalent of Platform Admin's createStaffUser
// (platformAdmin.controller.js) - same validation/creation shape, scoped by
// req.tenantId from the verified JWT instead of a URL param, gated by
// team.create (RBAC permission key already existed in the catalog,
// reserved, never enforced anywhere until now). role is always hardcoded
// "STAFF" server-side - never trusted from the request body, same rule
// createStaffUser already follows.
//
// The plan-limit check is deliberately the LAST guard before the real
// prisma.user.create, and there is no separate "can I open this form"
// endpoint at all - the frontend's Add Member modal is never blocked from
// opening or being filled in by this check; only this final Create request
// can fail on it, and when it does, nothing is created (this whole function
// returns before ever calling prisma.user.create). Counts ACTIVE users only
// (status field, 2026-08-09) so a deactivated member's seat is immediately
// available to a new one, per the module's own requirement.
async function createTeamMember(req, res) {
  const { name, email, password } = req.body;
  if (!name || !email || !password) throw new ApiError(400, "name, email and password are required");
  if (!isStrongPassword(password)) throw new ApiError(400, PASSWORD_REQUIREMENT_MESSAGE);

  const tenant = await prisma.tenant.findUnique({ where: { id: req.tenantId } });
  if (!tenant) throw new ApiError(404, "Tenant not found");

  const limits = await getPlanLimits(tenant.plan);
  if (limits.maxUsers !== null) {
    const activeUserCount = await prisma.user.count({ where: { tenantId: req.tenantId, status: "ACTIVE" } });
    if (activeUserCount >= limits.maxUsers) {
      // Structured, not just a message string - the frontend's Add Member
      // modal renders the exact "Your current plan allows up to N users..."
      // copy from these fields rather than parsing English text. `error`
      // still carries the human message, matching every other endpoint's
      // { error } shape, so nothing that only reads err.message breaks.
      return res.status(409).json({
        error: `Your current plan allows up to ${limits.maxUsers} users. You currently have ${activeUserCount} active users.`,
        code: "USER_LIMIT_REACHED",
        plan: tenant.plan,
        maxUsers: limits.maxUsers,
        activeUserCount,
      });
    }
  }

  const existingEmail = await prisma.user.findUnique({ where: { email } });
  if (existingEmail) throw new ApiError(409, "A user with this email already exists");

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: { tenantId: req.tenantId, name, email, passwordHash, role: "STAFF", mustChangePassword: true },
  });

  // RBAC (2026-08-06) - same default-role assignment createStaffUser
  // already does, so a self-service-added member is never left without a
  // resolvable Role.
  await assignDefaultUserRole(prisma, { userId: user.id, tenantId: req.tenantId, legacyRole: "STAFF" });

  res.status(201).json({
    user: { id: user.id, name: user.name, email: user.email, role: user.role, status: user.status, createdAt: user.createdAt, lastLoginAt: user.lastLoginAt },
  });
}

// PATCH /api/tenant/team/:id/deactivate
// PATCH /api/tenant/team/:id/activate
// Soft toggle only (User.status) - never a hard delete, so nothing that
// references this User (ApprovalRequest.requestedBy/decidedBy,
// InvoiceActivity, etc.) ever loses its row. Two guards: the Owner can
// never be deactivated (would permanently lock the Tenant out - same
// protection role.controller.js already gives the Owner Role itself), and
// a user can't deactivate their own account (would end their own session
// with no self-service way back in).
async function setTeamMemberStatus(req, res, status) {
  const target = await prisma.user.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!target) throw new ApiError(404, "Team member not found");
  if (status === "INACTIVE") {
    if (target.role === "OWNER") throw new ApiError(409, "The Owner account can't be deactivated");
    if (target.id === req.tenantUser.id) throw new ApiError(409, "You can't deactivate your own account");
  }

  const updated = await prisma.user.update({
    where: { id: target.id },
    data: { status },
    select: { id: true, name: true, email: true, role: true, status: true, lastLoginAt: true, createdAt: true },
  });
  res.json({ user: updated });
}

const deactivateTeamMember = (req, res) => setTeamMemberStatus(req, res, "INACTIVE");
const activateTeamMember = (req, res) => setTeamMemberStatus(req, res, "ACTIVE");

// GET /api/tenant/me/permissions
// Returns the logged-in user's resolved permission set (RBAC module,
// 2026-08-06) - fetched once by the frontend right after login and cached
// alongside the session, never re-derived per page. req.tenantUser.permissions
// is already resolved by requireTenantUser; this endpoint just serializes it.
async function getMyPermissions(req, res) {
  const role = await prisma.userRole.findFirst({
    where: { userId: req.tenantUser.id, isPrimary: true },
    include: { role: { select: { id: true, name: true, code: true } } },
  });

  res.json({
    role: role?.role || null,
    permissions: Array.from(req.tenantUser.permissions),
    // Plan + RBAC combined enforcement (2026-08-09) - already resolved once
    // by requireTenantUser, reused here at zero extra query cost so the
    // frontend's PermissionsProvider can combine both checks in its own
    // can(key), the same way requirePermission() does on the backend.
    moduleAccess: req.tenantModuleAccess,
  });
}

module.exports = { login, listTeam, createTeamMember, deactivateTeamMember, activateTeamMember, getMyPermissions, changePassword };
