const ApiError = require("../utils/ApiError");
const planService = require("../services/plan.service");

// GET /api/platform-admin/module-catalog
async function getModuleCatalog(req, res) {
  res.json({ modules: planService.getModuleCatalog() });
}

// GET /api/platform-admin/plans
async function listPlans(req, res) {
  const plans = await planService.listPlans();
  res.json({ plans });
}

// GET /api/platform-admin/plans/:id
async function getPlan(req, res) {
  const plan = await planService.getPlanDetail(req.params.id);
  res.json({ plan });
}

// POST /api/platform-admin/plans
async function createPlan(req, res) {
  const { slug, name, description, isDefault, ...versionData } = req.body;
  if (!slug || !name) throw new ApiError(400, "slug and name are required");
  const result = await planService.createPlan({
    slug: slug.toUpperCase().replace(/[^A-Z0-9_]/g, "_"),
    name,
    description,
    isDefault,
    versionData,
    createdBy: req.platformAdmin.id,
  });
  res.status(201).json(result);
}

// POST /api/platform-admin/plans/:id/clone
async function clonePlan(req, res) {
  const { name, slug } = req.body;
  if (!name || !slug) throw new ApiError(400, "name and slug are required");
  const result = await planService.clonePlan(req.params.id, { name, slug: slug.toUpperCase().replace(/[^A-Z0-9_]/g, "_") });
  res.status(201).json(result);
}

// PATCH /api/platform-admin/plans/:id
async function updatePlanMeta(req, res) {
  const { name, description, isDefault } = req.body;
  const plan = await planService.updatePlanMeta(req.params.id, { name, description, isDefault });
  res.json({ plan });
}

// PATCH /api/platform-admin/plans/:id/status
async function setPlanStatus(req, res) {
  const { status } = req.body;
  const plan = await planService.setPlanStatus(req.params.id, status);
  res.json({ plan });
}

// POST /api/platform-admin/plans/:id/versions - save/update the draft version
async function saveDraftVersion(req, res) {
  const { changeSummary, ...versionData } = req.body;
  const version = await planService.saveDraftVersion(req.params.id, versionData, { createdBy: req.platformAdmin.id, changeSummary });
  res.json({ version });
}

// POST /api/platform-admin/plan-versions/:versionId/publish
async function publishVersion(req, res) {
  const version = await planService.publishVersion(req.params.versionId);
  res.json({ version });
}

// POST /api/platform-admin/plan-versions/:versionId/archive
async function archiveVersion(req, res) {
  const version = await planService.archiveVersion(req.params.versionId);
  res.json({ version });
}

// GET /api/platform-admin/tenants/:id/plan-assignment
async function getTenantAssignment(req, res) {
  await planService.applyDueScheduledChanges(req.params.id);
  const assignment = await planService.getTenantAssignment(req.params.id);
  res.json({ assignment });
}

// POST /api/platform-admin/tenants/:id/plan-assignment
async function assignPlan(req, res) {
  const { planVersionId, reason } = req.body;
  if (!planVersionId) throw new ApiError(400, "planVersionId is required");
  const assignment = await planService.assignPlan(req.params.id, planVersionId, { changedBy: req.platformAdmin.id, reason });
  res.json({ assignment });
}

// POST /api/platform-admin/tenants/:id/plan-assignment/schedule
async function scheduleChange(req, res) {
  const { planVersionId, effectiveDate, reason } = req.body;
  if (!planVersionId || !effectiveDate) throw new ApiError(400, "planVersionId and effectiveDate are required");
  const assignment = await planService.schedulePlanChange(req.params.id, planVersionId, effectiveDate, { changedBy: req.platformAdmin.id, reason });
  res.json({ assignment });
}

// DELETE /api/platform-admin/tenants/:id/plan-assignment/schedule
async function cancelScheduledChange(req, res) {
  const assignment = await planService.cancelScheduledChange(req.params.id);
  res.json({ assignment });
}

// GET /api/platform-admin/tenants/:id/plan-change-history
async function listChangeHistory(req, res) {
  const history = await planService.listChangeHistory(req.params.id);
  res.json({ history });
}

module.exports = {
  getModuleCatalog,
  listPlans,
  getPlan,
  createPlan,
  updatePlanMeta,
  clonePlan,
  setPlanStatus,
  saveDraftVersion,
  publishVersion,
  archiveVersion,
  getTenantAssignment,
  assignPlan,
  scheduleChange,
  cancelScheduledChange,
  listChangeHistory,
};
