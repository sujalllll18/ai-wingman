const ApiError = require("../utils/ApiError");
const ticketService = require("../services/ticket.service");

// Tenant-side Support Center handlers (2026-08-07). req.tenantId/req.tenantUser
// are set by requireTenantUser; every query is scoped to req.tenantId, never
// a tenantId from params/body.

async function listCategories(req, res) {
  res.json({ categories: await ticketService.listCategories() });
}

async function listTickets(req, res) {
  const { status, priority, module, dateFrom, dateTo, search } = req.query;
  const tickets = await ticketService.listTicketsForTenant(req.tenantId, { status, priority, module, dateFrom, dateTo, search });
  res.json({ tickets });
}

async function createTicket(req, res) {
  const ticket = await ticketService.createTicket(req.tenantId, req.tenantUser.id, req.body);
  res.status(201).json({ ticket });
}

async function getTicket(req, res) {
  const result = await ticketService.getTicketForTenant(req.tenantId, req.params.id);
  res.json(result);
}

async function reply(req, res) {
  const comment = await ticketService.addReplyAsTenant(req.tenantId, req.tenantUser.id, req.params.id, req.body.body);
  res.status(201).json({ comment });
}

async function reopen(req, res) {
  const ticket = await ticketService.reopenTicketAsTenant(req.tenantId, req.tenantUser.id, req.params.id);
  res.json({ ticket });
}

async function close(req, res) {
  const ticket = await ticketService.closeTicketAsTenant(req.tenantId, req.tenantUser.id, req.params.id);
  res.json({ ticket });
}

async function addAttachment(req, res) {
  if (!req.file) throw new ApiError(400, "No file uploaded");
  const attachment = await ticketService.addAttachment(req.params.id, req.file, {
    commentId: req.body.commentId,
    isScreenshot: req.body.isScreenshot === "true",
    uploaderType: "TENANT_USER",
    uploaderId: req.tenantUser.id,
  });
  res.status(201).json({ attachment });
}

module.exports = { listCategories, listTickets, createTicket, getTicket, reply, reopen, close, addAttachment };
