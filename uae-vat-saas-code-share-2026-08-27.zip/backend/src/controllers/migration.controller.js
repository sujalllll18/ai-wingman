// Tenant self-service "Migration Center" - multi-file wrapper around the
// existing single-file Import Framework (import.controller.js, untouched).
// Every per-file operation before Commit (set mapping, validate, preview,
// records, error-report for ONE file) is deliberately NOT duplicated here -
// the existing /api/tenant/imports/:id/* endpoints already work per-batch
// regardless of whether that batch belongs to a Migration, so the frontend
// Migration wizard calls those directly for each staged file. Only the
// migration-level (multi-file) operations live here.
const fs = require("fs");
const ApiError = require("../utils/ApiError");
const orchestrator = require("../services/migrationOrchestrator.service");
const { listAdapters } = require("../services/importAdapters");

const VALID_IMPORT_TYPES = listAdapters().map((a) => a.importType);

// POST /api/tenant/migrations - multipart upload, one or more files, each
// tagged with its entity type via a parallel `fileMeta` JSON array
// (same disk-storage pattern as import.routes.js - see migration.routes.js).
async function createMigration(req, res) {
  const files = req.files || [];
  if (files.length === 0) throw new ApiError(400, "At least one file is required");

  let meta;
  try {
    meta = JSON.parse(req.body.fileMeta || "[]");
  } catch {
    throw new ApiError(400, "fileMeta must be a JSON array");
  }
  if (!Array.isArray(meta) || meta.length !== files.length) {
    throw new ApiError(400, "fileMeta must have exactly one entry per uploaded file, in the same order");
  }
  for (const m of meta) {
    if (!VALID_IMPORT_TYPES.includes(m.importType)) {
      throw new ApiError(400, `importType must be one of ${VALID_IMPORT_TYPES.join(", ")}`);
    }
  }

  const { migration, batches } = await orchestrator.createMigration({
    tenantId: req.tenantId,
    source: req.body.source || "EXCEL",
    startedByType: "TENANT_USER",
    startedById: req.tenantUser.id,
    files: files.map((file, i) => ({
      importType: meta[i].importType,
      periodFrom: meta[i].periodFrom,
      periodTo: meta[i].periodTo,
      file: {
        buffer: fs.readFileSync(file.path),
        originalname: file.originalname,
        fileUrl: `/uploads/imports/${file.filename}`,
      },
    })),
  });

  res.status(201).json({ migration, batches });
}

async function listMigrations(req, res) {
  const migrations = await orchestrator.listMigrations({ tenantId: req.tenantId });
  res.json({ migrations });
}

async function getMigration(req, res) {
  const migration = await orchestrator.getMigration({ tenantId: req.tenantId, migrationId: req.params.id });
  res.json({ migration });
}

async function getMigrationPreview(req, res) {
  const preview = await orchestrator.getMigrationPreview({ tenantId: req.tenantId, migrationId: req.params.id });
  res.json(preview);
}

async function getMigrationStatus(req, res) {
  const status = await orchestrator.getMigrationStatus({ tenantId: req.tenantId, migrationId: req.params.id });
  res.json(status);
}

// POST /api/tenant/migrations/:id/commit - routes each committable child
// batch through the existing imports.commit Maker-Checker rule, exactly
// like a standalone single-file commit already does (import.controller.js's
// commitBatch). This is the ONLY endpoint that can start real data writes.
async function commitMigration(req, res) {
  const result = await orchestrator.commitMigration({
    tenantId: req.tenantId,
    migrationId: req.params.id,
    actorId: req.tenantUser.id,
    dispatchThroughApproval: true,
  });
  res.json(result);
}

async function pauseMigration(req, res) {
  res.json(await orchestrator.pauseMigrationBatches({ tenantId: req.tenantId, migrationId: req.params.id }));
}
async function resumeMigration(req, res) {
  res.json(await orchestrator.resumeMigrationBatches({ tenantId: req.tenantId, migrationId: req.params.id, actorId: req.tenantUser.id }));
}
async function cancelMigration(req, res) {
  res.json(await orchestrator.cancelMigrationBatches({ tenantId: req.tenantId, migrationId: req.params.id }));
}
async function retryFailed(req, res) {
  res.json(await orchestrator.retryFailedRecordsForMigration({ tenantId: req.tenantId, migrationId: req.params.id, actorId: req.tenantUser.id }));
}

async function downloadErrorReport(req, res) {
  const csv = await orchestrator.buildMigrationErrorReportCsv({ tenantId: req.tenantId, migrationId: req.params.id });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="migration-errors.csv"`);
  res.send(csv);
}

async function getDataCounts(req, res) {
  res.json(await orchestrator.getTenantDataCounts(req.tenantId));
}

module.exports = {
  createMigration,
  listMigrations,
  getMigration,
  getMigrationPreview,
  getMigrationStatus,
  commitMigration,
  pauseMigration,
  resumeMigration,
  cancelMigration,
  retryFailed,
  downloadErrorReport,
  getDataCounts,
};
