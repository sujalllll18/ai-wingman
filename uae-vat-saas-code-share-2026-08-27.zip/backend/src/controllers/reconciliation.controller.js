// Reconciliation Engine (Phase 4, 2026-08-23) - see
// prisma/schema.prisma's ReconciliationMatch comment and
// src/services/reconciliationEngine.service.js for the data model and
// scoring logic this controller drives. Every write here goes through that
// service's recompute* helpers so BankTransaction/Payment/PurchasePayment's
// own reconciliationStatus fields are always DERIVED, never trusted as
// caller input - the same convention Invoice.paymentStatus already uses.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { round2 } = require("../services/invoiceCalc");
const engine = require("../services/reconciliationEngine.service");

const DIFFERENCE_TYPES = ["BANK_CHARGE", "ADJUSTMENT", "OTHER"];

function logActivity(tx, matchId, type, { description, actorId, previousStatus, newStatus } = {}) {
  return tx.reconciliationActivity.create({
    data: { matchId, type, description: description || null, actorId: actorId || null, previousStatus: previousStatus || null, newStatus: newStatus || null },
  });
}

const MATCH_INCLUDE = {
  bankLines: { include: { bankTransaction: { include: { bankAccount: { select: { id: true, accountName: true, bankName: true } } } } } },
  ledgerLines: {
    include: {
      payment: { include: { allocations: { include: { invoice: { select: { id: true, invoiceNumberDisplay: true, grandTotal: true, outstandingAmount: true } } } } } },
      purchasePayment: { include: { allocations: { include: { purchaseBill: { select: { id: true, billNumberDisplay: true, grandTotal: true, outstandingAmount: true } } } } } },
    },
  },
  activities: { orderBy: { createdAt: "desc" } },
};

// GET /api/tenant/reconciliation/dashboard
// One pass over this tenant's ACTIVE bank transactions, grouped by their own
// (derived) reconciliationStatus - server-side aggregate, never "fetch every
// row and sum in JS" per the performance requirement.
async function getDashboard(req, res) {
  const { bankAccountId } = req.query;
  const where = { tenantId: req.tenantId, status: "ACTIVE", ...(bankAccountId ? { bankAccountId } : {}) };

  const groups = await prisma.bankTransaction.groupBy({
    by: ["reconciliationStatus"],
    where,
    _count: true,
    _sum: { amount: true },
  });

  const byStatus = { UNMATCHED: { count: 0, amount: 0 }, SUGGESTED: { count: 0, amount: 0 }, MATCHED: { count: 0, amount: 0 }, RECONCILED: { count: 0, amount: 0 }, PARTIALLY_RECONCILED: { count: 0, amount: 0 }, IGNORED: { count: 0, amount: 0 } };
  let totalCount = 0;
  let totalAmount = 0;
  for (const g of groups) {
    const abs = round2(Math.abs(g._sum.amount || 0));
    byStatus[g.reconciliationStatus] = { count: g._count, amount: abs };
    totalCount += g._count;
    totalAmount = round2(totalAmount + abs);
  }

  res.json({ totalCount, totalAmount, byStatus });
}

// GET /api/tenant/reconciliation/transactions
// Same server-side filtered/paginated shape as bankTransaction.controller.js's
// listBankTransactions (this table is designed to hold 100,000+ rows), with
// each row additionally enriched by its own currently-active match (a
// SUGGESTED one if pending review, else the most recent CONFIRMED one) -
// fetched as one batched second query keyed by the page's own transaction
// ids, never N+1.
async function listReconciliation(req, res) {
  const { bankAccountId, dateFrom, dateTo, direction, reconciliationStatus, search, page = "1", pageSize = "25" } = req.query;

  const where = {
    tenantId: req.tenantId,
    status: "ACTIVE",
    ...(bankAccountId ? { bankAccountId } : {}),
    ...(reconciliationStatus ? { reconciliationStatus } : {}),
    ...(dateFrom || dateTo
      ? { transactionDate: { ...(dateFrom ? { gte: new Date(dateFrom) } : {}), ...(dateTo ? { lte: new Date(new Date(dateTo).getTime() + 86399999) } : {}) } }
      : {}),
    ...(direction === "DEBIT" ? { debit: { gt: 0 } } : direction === "CREDIT" ? { credit: { gt: 0 } } : {}),
    ...(search ? { OR: [{ description: { contains: search } }, { reference: { contains: search } }] } : {}),
  };

  const take = Math.min(200, Math.max(1, Number(pageSize) || 25));
  const skip = (Math.max(1, Number(page) || 1) - 1) * take;

  const [total, transactions] = await Promise.all([
    prisma.bankTransaction.count({ where }),
    prisma.bankTransaction.findMany({
      where,
      include: { bankAccount: { select: { id: true, accountName: true, bankName: true, currency: true } } },
      orderBy: { transactionDate: "desc" },
      skip,
      take,
    }),
  ]);

  const ids = transactions.map((t) => t.id);
  const activeMatches = ids.length
    ? await prisma.reconciliationMatch.findMany({
        where: { tenantId: req.tenantId, status: { in: ["SUGGESTED", "CONFIRMED"] }, bankLines: { some: { bankTransactionId: { in: ids } } } },
        include: { bankLines: { select: { bankTransactionId: true } }, ledgerLines: { include: { payment: { select: { customerName: true, paymentNumberDisplay: true } }, purchasePayment: { select: { vendorName: true, paymentNumberDisplay: true } } } } },
        orderBy: { createdAt: "desc" },
      })
    : [];

  const matchByTxnId = new Map();
  for (const m of activeMatches) {
    for (const line of m.bankLines) {
      if (!matchByTxnId.has(line.bankTransactionId)) matchByTxnId.set(line.bankTransactionId, m);
    }
  }

  const rows = transactions.map((t) => {
    const m = matchByTxnId.get(t.id) || null;
    const ledgerLabel = m
      ? m.ledgerLines.map((l) => l.payment?.paymentNumberDisplay || l.purchasePayment?.paymentNumberDisplay).filter(Boolean).join(", ")
      : null;
    const partyLabel = m
      ? m.ledgerLines.map((l) => l.payment?.customerName || l.purchasePayment?.vendorName).filter(Boolean).join(", ")
      : null;
    return {
      ...t,
      suggestedMatch: m
        ? { id: m.id, status: m.status, confidence: m.confidence, score: m.score, ledgerLabel, partyLabel }
        : null,
    };
  });

  res.json({ transactions: rows, total, page: Math.max(1, Number(page) || 1), pageSize: take });
}

// POST /api/tenant/reconciliation/run
// Body: { bankAccountId? } - processes one controlled batch of this
// tenant's own UNMATCHED/PARTIALLY_RECONCILED transactions (see
// reconciliationEngine.service.js's RUN_BATCH_SIZE). Returns hasMore so the
// caller can re-invoke to continue across a large statement without ever
// loading the whole table into memory at once.
async function runMatching(req, res) {
  const { bankAccountId } = req.body || {};
  const result = await engine.runMatchingBatch(prisma, req.tenantId, { bankAccountId });
  res.json(result);
}

// GET /api/tenant/reconciliation/transactions/:id
async function getTransactionDetail(req, res) {
  const transaction = await prisma.bankTransaction.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { bankAccount: { select: { id: true, accountName: true, bankName: true, currency: true } } },
  });
  if (!transaction) throw new ApiError(404, "Bank transaction not found");

  const matches = await prisma.reconciliationMatch.findMany({
    where: { tenantId: req.tenantId, bankLines: { some: { bankTransactionId: transaction.id } } },
    include: MATCH_INCLUDE,
    orderBy: { createdAt: "desc" },
  });

  const remaining = round2(Math.max(0, Math.abs(transaction.amount) - (await engine.getBankTransactionRemaining(prisma, transaction.id))));

  res.json({ transaction, matches, remaining });
}

// GET /api/tenant/reconciliation/transactions/:id/suggestions
// On-demand scoring for one transaction - cheap (bounded candidate pool),
// used by the Review Match screen. Does NOT persist anything; the currently
// active SUGGESTED match (if generateSuggestion already created one via a
// prior /run call) is returned alongside so the UI can show "the system's
// current proposal" plus "other candidates you could pick instead."
async function getSuggestions(req, res) {
  const { candidates, remaining, direction } = await engine.findCandidates(prisma, req.tenantId, req.params.id);
  const activeMatch = await prisma.reconciliationMatch.findFirst({
    where: { tenantId: req.tenantId, status: "SUGGESTED", bankLines: { some: { bankTransactionId: req.params.id } } },
    include: MATCH_INCLUDE,
  });
  res.json({ direction, remaining, candidates, activeMatch });
}

// GET /api/tenant/reconciliation/transactions/:id/search?q=&type=payment|purchasePayment
// Manual Match's own search - direction-appropriate (a CREDIT bank
// transaction can only ever be matched to a Payment, a DEBIT one only to a
// PurchasePayment), across customer/vendor name, reference, payment number,
// and any allocated invoice/bill number.
async function searchLedgerCandidates(req, res) {
  const transaction = await prisma.bankTransaction.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!transaction) throw new ApiError(404, "Bank transaction not found");

  const q = String(req.query.q || "").trim();
  const direction = transaction.amount >= 0 ? "CREDIT" : "DEBIT";

  if (direction === "CREDIT") {
    const payments = await prisma.payment.findMany({
      where: {
        tenantId: req.tenantId,
        status: "CONFIRMED",
        ...(q ? { OR: [{ customerName: { contains: q } }, { reference: { contains: q } }, { paymentNumberDisplay: { contains: q } }] } : {}),
      },
      include: { allocations: { include: { invoice: { select: { invoiceNumberDisplay: true } } } }, reconciliationLines: { where: { match: { status: "CONFIRMED" } }, select: { amount: true } } },
      orderBy: { paymentDate: "desc" },
      take: 50,
    });
    const results = payments
      .map((p) => {
        const linked = round2((p.reconciliationLines || []).reduce((s, l) => s + l.amount, 0));
        return {
          id: p.id,
          paymentNumberDisplay: p.paymentNumberDisplay,
          customerName: p.customerName,
          paymentDate: p.paymentDate,
          amount: p.amount,
          currency: p.currency,
          reference: p.reference,
          remainingBalance: round2(Math.max(0, p.amount - linked)),
          documentNumbers: p.allocations.map((a) => a.invoice?.invoiceNumberDisplay).filter(Boolean),
        };
      })
      .filter((p) => p.remainingBalance > engine.AMOUNT_EPSILON);
    return res.json({ direction, results });
  }

  const purchasePayments = await prisma.purchasePayment.findMany({
    where: {
      tenantId: req.tenantId,
      status: "CONFIRMED",
      ...(q ? { OR: [{ vendorName: { contains: q } }, { reference: { contains: q } }, { paymentNumberDisplay: { contains: q } }] } : {}),
    },
    include: { allocations: { include: { purchaseBill: { select: { billNumberDisplay: true } } } }, reconciliationLines: { where: { match: { status: "CONFIRMED" } }, select: { amount: true } } },
    orderBy: { paymentDate: "desc" },
    take: 50,
  });
  const results = purchasePayments
    .map((p) => {
      const linked = round2((p.reconciliationLines || []).reduce((s, l) => s + l.amount, 0));
      return {
        id: p.id,
        paymentNumberDisplay: p.paymentNumberDisplay,
        vendorName: p.vendorName,
        paymentDate: p.paymentDate,
        amount: p.amount,
        currency: p.currency,
        reference: p.reference,
        remainingBalance: round2(Math.max(0, p.amount - linked)),
        documentNumbers: p.allocations.map((a) => a.purchaseBill?.billNumberDisplay).filter(Boolean),
      };
    })
    .filter((p) => p.remainingBalance > engine.AMOUNT_EPSILON);
  res.json({ direction, results });
}

// Shared validation for confirmMatch/manualMatch - resolves+re-checks every
// bank/ledger line against LIVE remaining balances (fresh reads inside the
// caller's own $transaction, not the possibly-stale values the client sent),
// which is what actually prevents duplicate/double reconciliation (Test
// scenario #16) under concurrent requests.
async function resolveBankLines(tx, tenantId, lines, excludeMatchId) {
  const list = Array.isArray(lines) ? lines : [];
  if (list.length === 0) throw new ApiError(400, "At least one bank transaction line is required");
  const resolved = [];
  let direction = null;

  for (const item of list) {
    const amount = round2(Number(item.amount));
    if (!amount || Number.isNaN(amount) || amount <= 0) throw new ApiError(400, "Each bank line amount must be a positive number");
    const bankTxn = await tx.bankTransaction.findFirst({ where: { id: item.bankTransactionId, tenantId } });
    if (!bankTxn) throw new ApiError(400, `bankTransactionId ${item.bankTransactionId} does not refer to a bank transaction on this tenant`);
    if (bankTxn.status !== "ACTIVE") throw new ApiError(409, `Bank transaction on ${bankTxn.transactionDate.toISOString().slice(0, 10)} is not active`);

    const lineDirection = bankTxn.amount >= 0 ? "CREDIT" : "DEBIT";
    if (direction && direction !== lineDirection) throw new ApiError(400, "All bank transaction lines in one match must be the same direction (all incoming or all outgoing)");
    direction = lineDirection;

    const confirmedElsewhere = await tx.reconciliationBankLine.aggregate({
      where: { bankTransactionId: bankTxn.id, match: { status: "CONFIRMED", ...(excludeMatchId ? { id: { not: excludeMatchId } } : {}) } },
      _sum: { amount: true },
    });
    const already = round2(confirmedElsewhere._sum.amount || 0);
    const fullAmount = round2(Math.abs(bankTxn.amount));
    if (round2(already + amount) > fullAmount + engine.AMOUNT_EPSILON) {
      throw new ApiError(409, `This would over-reconcile the bank transaction on ${bankTxn.transactionDate.toISOString().slice(0, 10)} (already ${already} of ${fullAmount} matched)`);
    }
    resolved.push({ bankTxn, amount });
  }

  return { resolved, direction };
}

async function resolveLedgerLines(tx, tenantId, lines, direction, excludeMatchId) {
  const list = Array.isArray(lines) ? lines : [];
  if (list.length === 0) throw new ApiError(400, "At least one payment/purchase payment line is required");
  const resolved = [];

  for (const item of list) {
    const amount = round2(Number(item.amount));
    if (!amount || Number.isNaN(amount) || amount <= 0) throw new ApiError(400, "Each ledger line amount must be a positive number");

    if (direction === "CREDIT") {
      if (!item.paymentId) throw new ApiError(400, "An incoming bank transaction can only be matched to a Payment Received");
      const payment = await tx.payment.findFirst({ where: { id: item.paymentId, tenantId } });
      if (!payment) throw new ApiError(400, `paymentId ${item.paymentId} does not refer to a payment on this tenant`);
      if (payment.status !== "CONFIRMED") throw new ApiError(409, `Payment ${payment.paymentNumberDisplay} is not confirmed`);

      const confirmedElsewhere = await tx.reconciliationLedgerLine.aggregate({
        where: { paymentId: payment.id, match: { status: "CONFIRMED", ...(excludeMatchId ? { id: { not: excludeMatchId } } : {}) } },
        _sum: { amount: true },
      });
      const already = round2(confirmedElsewhere._sum.amount || 0);
      if (round2(already + amount) > round2(payment.amount) + engine.AMOUNT_EPSILON) {
        throw new ApiError(409, `This would reconcile more than Payment ${payment.paymentNumberDisplay} actually received (already ${already} of ${payment.amount} matched)`);
      }
      resolved.push({ kind: "payment", row: payment, amount });
    } else {
      if (!item.purchasePaymentId) throw new ApiError(400, "An outgoing bank transaction can only be matched to a Payment Made");
      const payment = await tx.purchasePayment.findFirst({ where: { id: item.purchasePaymentId, tenantId } });
      if (!payment) throw new ApiError(400, `purchasePaymentId ${item.purchasePaymentId} does not refer to a supplier payment on this tenant`);
      if (payment.status !== "CONFIRMED") throw new ApiError(409, `Payment ${payment.paymentNumberDisplay} is not confirmed`);

      const confirmedElsewhere = await tx.reconciliationLedgerLine.aggregate({
        where: { purchasePaymentId: payment.id, match: { status: "CONFIRMED", ...(excludeMatchId ? { id: { not: excludeMatchId } } : {}) } },
        _sum: { amount: true },
      });
      const already = round2(confirmedElsewhere._sum.amount || 0);
      if (round2(already + amount) > round2(payment.amount) + engine.AMOUNT_EPSILON) {
        throw new ApiError(409, `This would reconcile more than Payment ${payment.paymentNumberDisplay} actually paid (already ${already} of ${payment.amount} matched)`);
      }
      resolved.push({ kind: "purchasePayment", row: payment, amount });
    }
  }

  return resolved;
}

// POST /api/tenant/reconciliation/matches
// Body: { matchId?, bankLines: [{bankTransactionId, amount}],
//         ledgerLines: [{paymentId|purchasePaymentId, amount}],
//         differenceType?, differenceNotes? }
// matchId (optional) confirms/edits an existing SUGGESTED row in place,
// preserving its SUGGESTED activity/history; omitted means a fresh Manual
// Match. Either way this is the ONLY place a ReconciliationMatch becomes
// CONFIRMED - see accounting-safety comment on the schema model for what it
// deliberately does NOT do (never touches Invoice/PurchaseBill totals, never
// creates a Payment, never changes VAT).
async function confirmMatch(req, res) {
  const { matchId, bankLines, ledgerLines, differenceType, differenceNotes } = req.body || {};

  let existing = null;
  if (matchId) {
    existing = await prisma.reconciliationMatch.findFirst({ where: { id: matchId, tenantId: req.tenantId } });
    if (!existing) throw new ApiError(404, "Reconciliation match not found");
    if (existing.status !== "SUGGESTED") throw new ApiError(409, `This match is already ${existing.status.toLowerCase()}`);
  }

  if (differenceType !== undefined && differenceType !== null && !DIFFERENCE_TYPES.includes(differenceType)) {
    throw new ApiError(400, `differenceType must be one of ${DIFFERENCE_TYPES.join(", ")}`);
  }

  const match = await prisma.$transaction(async (tx) => {
    const { resolved: bankResolved, direction } = await resolveBankLines(tx, req.tenantId, bankLines, matchId || null);
    const ledgerResolved = await resolveLedgerLines(tx, req.tenantId, ledgerLines, direction, matchId || null);

    const totalBankAmount = round2(bankResolved.reduce((s, l) => s + l.amount, 0));
    const totalLedgerAmount = round2(ledgerResolved.reduce((s, l) => s + l.amount, 0));
    const difference = round2(totalBankAmount - totalLedgerAmount);

    if (Math.abs(difference) > engine.AMOUNT_EPSILON && !differenceType) {
      throw new ApiError(400, `Bank amount (${totalBankAmount}) and matched amount (${totalLedgerAmount}) differ by ${difference} - classify the difference (Bank Charge, Adjustment, or Other) before confirming`);
    }

    const tenant = await tx.tenant.update({ where: { id: req.tenantId }, data: { nextReconciliationNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextReconciliationNumber - 1;
    const display = `REC-${String(assignedNumber).padStart(6, "0")}`;

    const lineCreateData = {
      bankLines: { create: bankResolved.map((l) => ({ bankTransactionId: l.bankTxn.id, amount: l.amount })) },
      ledgerLines: {
        create: ledgerResolved.map((l) => (l.kind === "payment" ? { paymentId: l.row.id, amount: l.amount } : { purchasePaymentId: l.row.id, amount: l.amount })),
      },
    };

    let saved;
    if (existing) {
      await tx.reconciliationBankLine.deleteMany({ where: { matchId: existing.id } });
      await tx.reconciliationLedgerLine.deleteMany({ where: { matchId: existing.id } });
      saved = await tx.reconciliationMatch.update({
        where: { id: existing.id },
        data: {
          status: "CONFIRMED",
          direction,
          matchNumber: assignedNumber,
          matchNumberDisplay: display,
          totalBankAmount,
          totalLedgerAmount,
          difference,
          differenceType: Math.abs(difference) > engine.AMOUNT_EPSILON ? differenceType : null,
          differenceNotes: differenceNotes || null,
          matchedBy: req.tenantUser.id,
          matchedAt: new Date(),
          ...lineCreateData,
        },
      });
      await logActivity(tx, saved.id, "CONFIRMED", { description: `Suggested match confirmed as ${display}`, actorId: req.tenantUser.id, previousStatus: "SUGGESTED", newStatus: "CONFIRMED" });
    } else {
      saved = await tx.reconciliationMatch.create({
        data: {
          tenantId: req.tenantId,
          status: "CONFIRMED",
          direction,
          source: "MANUAL",
          matchNumber: assignedNumber,
          matchNumberDisplay: display,
          totalBankAmount,
          totalLedgerAmount,
          difference,
          differenceType: Math.abs(difference) > engine.AMOUNT_EPSILON ? differenceType : null,
          differenceNotes: differenceNotes || null,
          matchedBy: req.tenantUser.id,
          matchedAt: new Date(),
          ...lineCreateData,
        },
      });
      await logActivity(tx, saved.id, "MANUAL_MATCHED", { description: `Manually matched as ${display}`, actorId: req.tenantUser.id, previousStatus: null, newStatus: "CONFIRMED" });
    }

    for (const l of bankResolved) await engine.recomputeBankTransactionStatus(tx, l.bankTxn.id);
    for (const l of ledgerResolved) {
      await engine.recomputeLedgerReconciliation(tx, l.kind === "payment" ? { paymentId: l.row.id } : { purchasePaymentId: l.row.id });
    }

    return tx.reconciliationMatch.findUnique({ where: { id: saved.id }, include: MATCH_INCLUDE });
  });

  res.status(201).json({ match });
}

// POST /api/tenant/reconciliation/matches/:id/reject
async function rejectMatch(req, res) {
  const existing = await prisma.reconciliationMatch.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { bankLines: true } });
  if (!existing) throw new ApiError(404, "Reconciliation match not found");
  if (existing.status !== "SUGGESTED") throw new ApiError(409, `This match is already ${existing.status.toLowerCase()}`);

  const match = await prisma.$transaction(async (tx) => {
    const updated = await tx.reconciliationMatch.update({ where: { id: existing.id }, data: { status: "REJECTED", reason: req.body?.reason || null } });
    await logActivity(tx, existing.id, "REJECTED", { description: req.body?.reason || null, actorId: req.tenantUser.id, previousStatus: "SUGGESTED", newStatus: "REJECTED" });
    for (const line of existing.bankLines) await engine.recomputeBankTransactionStatus(tx, line.bankTransactionId);
    return updated;
  });

  res.json({ match });
}

// POST /api/tenant/reconciliation/matches/:id/unmatch
// Reverses an already-CONFIRMED match. Never deletes the row or its lines -
// full history stays intact (status becomes "UNMATCHED", a terminal state
// distinct from REJECTED, which means "never was reconciled" - see schema
// comment). Both sides' derived statuses recompute back down immediately.
async function unmatchMatch(req, res) {
  const existing = await prisma.reconciliationMatch.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { bankLines: true, ledgerLines: true },
  });
  if (!existing) throw new ApiError(404, "Reconciliation match not found");
  if (existing.status !== "CONFIRMED") throw new ApiError(409, "Only a confirmed match can be unmatched");

  const match = await prisma.$transaction(async (tx) => {
    const updated = await tx.reconciliationMatch.update({
      where: { id: existing.id },
      data: { status: "UNMATCHED", unmatchedBy: req.tenantUser.id, unmatchedAt: new Date(), unmatchReason: req.body?.reason || null },
    });
    await logActivity(tx, existing.id, "UNMATCHED", { description: req.body?.reason || null, actorId: req.tenantUser.id, previousStatus: "CONFIRMED", newStatus: "UNMATCHED" });
    for (const line of existing.bankLines) await engine.recomputeBankTransactionStatus(tx, line.bankTransactionId);
    for (const line of existing.ledgerLines) {
      await engine.recomputeLedgerReconciliation(tx, line.paymentId ? { paymentId: line.paymentId } : { purchasePaymentId: line.purchasePaymentId });
    }
    return updated;
  });

  res.json({ match });
}

// POST /api/tenant/reconciliation/transactions/:id/ignore
async function ignoreTransaction(req, res) {
  const transaction = await prisma.bankTransaction.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!transaction) throw new ApiError(404, "Bank transaction not found");
  if (transaction.reconciliationStatus === "RECONCILED" || transaction.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This transaction already has a confirmed reconciliation - unmatch it first");
  }
  if (transaction.reconciliationStatus === "IGNORED") throw new ApiError(409, "Already ignored");

  const remaining = round2(Math.max(0, Math.abs(transaction.amount) - (await engine.getBankTransactionRemaining(prisma, transaction.id))));
  if (remaining <= engine.AMOUNT_EPSILON) throw new ApiError(409, "Nothing left on this transaction to ignore");

  const match = await prisma.$transaction(async (tx) => {
    const activeSuggestion = await tx.reconciliationMatch.findFirst({
      where: { tenantId: req.tenantId, status: "SUGGESTED", bankLines: { some: { bankTransactionId: transaction.id } } },
    });
    if (activeSuggestion) {
      await tx.reconciliationMatch.update({ where: { id: activeSuggestion.id }, data: { status: "REJECTED", reason: "Superseded by Ignore" } });
      await logActivity(tx, activeSuggestion.id, "REJECTED", { description: "Superseded by Ignore", actorId: req.tenantUser.id, previousStatus: "SUGGESTED", newStatus: "REJECTED" });
    }

    const created = await tx.reconciliationMatch.create({
      data: {
        tenantId: req.tenantId,
        status: "IGNORED",
        direction: transaction.amount >= 0 ? "CREDIT" : "DEBIT",
        source: "MANUAL",
        reason: req.body?.reason || null,
        totalBankAmount: remaining,
        totalLedgerAmount: 0,
        difference: remaining,
        matchedBy: req.tenantUser.id,
        matchedAt: new Date(),
        bankLines: { create: [{ bankTransactionId: transaction.id, amount: remaining }] },
      },
    });
    await logActivity(tx, created.id, "IGNORED", { description: req.body?.reason || null, actorId: req.tenantUser.id, previousStatus: transaction.reconciliationStatus, newStatus: "IGNORED" });
    await engine.recomputeBankTransactionStatus(tx, transaction.id);
    return created;
  });

  res.status(201).json({ match });
}

// POST /api/tenant/reconciliation/transactions/:id/unignore
async function unignoreTransaction(req, res) {
  const transaction = await prisma.bankTransaction.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!transaction) throw new ApiError(404, "Bank transaction not found");
  if (transaction.reconciliationStatus !== "IGNORED") throw new ApiError(409, "This transaction is not ignored");

  await prisma.$transaction(async (tx) => {
    const activeIgnore = await tx.reconciliationMatch.findFirst({
      where: { tenantId: req.tenantId, status: "IGNORED", bankLines: { some: { bankTransactionId: transaction.id } } },
      orderBy: { createdAt: "desc" },
    });
    if (activeIgnore) {
      await tx.reconciliationMatch.update({ where: { id: activeIgnore.id }, data: { status: "REJECTED" } });
      await logActivity(tx, activeIgnore.id, "UNIGNORED", { actorId: req.tenantUser.id, previousStatus: "IGNORED", newStatus: "REJECTED" });
    }
    await engine.recomputeBankTransactionStatus(tx, transaction.id);
  });

  const updated = await prisma.bankTransaction.findUnique({ where: { id: transaction.id } });
  res.json({ transaction: updated });
}

// GET /api/tenant/reconciliation/matches/:id
async function getMatch(req, res) {
  const match = await prisma.reconciliationMatch.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: MATCH_INCLUDE });
  if (!match) throw new ApiError(404, "Reconciliation match not found");
  res.json({ match });
}

module.exports = {
  getDashboard,
  listReconciliation,
  runMatching,
  getTransactionDetail,
  getSuggestions,
  searchLedgerCandidates,
  confirmMatch,
  rejectMatch,
  unmatchMatch,
  ignoreTransaction,
  unignoreTransaction,
  getMatch,
};
