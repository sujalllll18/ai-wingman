const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { calculateInvoiceTotals, round2 } = require("../services/invoiceCalc");
const engine = require("../services/approvalEngine.service");

// Sales Debit Note (2026-08-11) - increases an already-issued Invoice's
// amount. Structural mirror of creditNote.controller.js (same lifecycle,
// same snapshot/immutability principle), but line resolution follows
// debitNote.controller.js's UNCAPPED pattern instead - this is an additive
// adjustment ("forgot to add an item"), not a reduction, so there is no
// "remaining eligible amount" ceiling to enforce. See prisma/schema.prisma's
// SalesDebitNote model comment for why this is a distinct model from the
// existing purchase-side DebitNote rather than a repurposed one.
const FULL_INCLUDE = {
  lineItems: { orderBy: { sortOrder: "asc" } },
  activities: { orderBy: { createdAt: "desc" } },
  invoice: { select: { id: true, invoiceNumberDisplay: true, grandTotal: true, issueDate: true, currency: true } },
};

const VALID_ACTIVITY_TYPES = ["DOWNLOADED", "PREVIEWED"];

function assertDraft(note) {
  if (note.status !== "DRAFT") {
    throw new ApiError(409, "This debit note is no longer a Draft and can't be edited");
  }
}

function logActivity(tx, salesDebitNoteId, type, description, actorId = null) {
  return tx.salesDebitNoteActivity.create({ data: { salesDebitNoteId, type, description: description || null, actorId } });
}

// Sum of grandTotal across every ISSUED sales debit note against this
// invoice (excluding the one being edited, if any) - shown on the
// Adjustment Summary card as "Previously Adjusted", informational only
// (no cap enforced against it, unlike Credit Note's identical-shaped sum).
async function sumIssuedAgainstInvoice(tx, invoiceId, excludeId = null) {
  const agg = await tx.salesDebitNote.aggregate({
    where: { invoiceId, status: "ISSUED", ...(excludeId ? { id: { not: excludeId } } : {}) },
    _sum: { grandTotal: true },
  });
  return round2(agg._sum.grandTotal || 0);
}

async function loadEligibleInvoice(tenantId, invoiceId) {
  const invoice = await prisma.invoice.findFirst({
    where: { id: invoiceId, tenantId },
    include: { lineItems: { orderBy: { sortOrder: "asc" } } },
  });
  if (!invoice) throw new ApiError(404, "Invoice not found");
  if (invoice.status === "DRAFT") throw new ApiError(409, "A Debit Note can't be raised against a Draft invoice - send it first");
  if (invoice.status === "VOID") throw new ApiError(409, "A Debit Note can't be raised against a cancelled invoice");
  return invoice;
}

// Mirrors debitNote.controller.js's resolveNoteLineFromSource exactly
// (uncapped: no quantity ceiling against the source line, freeform lines
// allowed) - the sales-side mirror of the same additive-adjustment pattern.
function resolveNoteLineFromSource(invoice, input) {
  const quantity = Number(input.quantity);
  if (!quantity || Number.isNaN(quantity) || quantity <= 0) {
    throw new ApiError(400, "Line item quantity must be a positive number");
  }

  let sourceLine = null;
  if (input.invoiceLineItemId) {
    sourceLine = invoice.lineItems.find((li) => li.id === input.invoiceLineItemId);
    if (!sourceLine) throw new ApiError(400, "invoiceLineItemId does not refer to a line item on this invoice");
  } else if (input.taxCategoryId) {
    sourceLine = invoice.lineItems.find((li) => li.taxCategoryId === input.taxCategoryId);
    if (!sourceLine) throw new ApiError(400, "This tax category doesn't appear on the source invoice - pick one that was actually charged");
  } else if (invoice.lineItems.some((li) => li.taxCategoryId)) {
    throw new ApiError(400, "Select an original line item or a tax category that was used on the invoice");
  }

  const description = (input.description || sourceLine?.description || "").trim();
  if (!description) throw new ApiError(400, "Line item description is required");

  const unitPrice = input.unitPrice !== undefined ? Number(input.unitPrice) : Number(sourceLine?.unitPrice || 0);
  if (Number.isNaN(unitPrice) || unitPrice < 0) {
    throw new ApiError(400, "Line item unit price must be a non-negative number");
  }

  return {
    invoiceLineItemId: sourceLine?.id || null,
    description,
    quantity,
    unitPrice,
    sortOrder: input.sortOrder ?? 0,
    taxCategoryId: sourceLine?.taxCategoryId || null,
    taxRateId: sourceLine?.taxRateId || null,
    taxRateName: sourceLine?.taxRateName || null,
    taxPercentage: sourceLine?.taxPercentage || 0,
    taxCalculationMethod: sourceLine?.taxCalculationMethod || "EXCLUSIVE",
  };
}

async function recomputeAndPersist(tx, salesDebitNoteId) {
  const note = await tx.salesDebitNote.findUnique({ where: { id: salesDebitNoteId }, include: { lineItems: { orderBy: { sortOrder: "asc" } } } });
  const result = calculateInvoiceTotals(note.lineItems, {});

  for (const line of result.lines) {
    await tx.salesDebitNoteLineItem.update({
      where: { id: line.id },
      data: { lineNetAmount: line.lineNetAmount, lineTaxableAmount: line.lineTaxableAmount, lineTaxAmount: line.lineTaxAmount, lineTotal: line.lineTotal },
    });
  }

  return tx.salesDebitNote.update({
    where: { id: salesDebitNoteId },
    data: { subtotal: result.subtotal, vatTotal: result.vatTotal, grandTotal: result.grandTotal },
    include: FULL_INCLUDE,
  });
}

// GET /api/tenant/sales-debit-notes
async function listSalesDebitNotes(req, res) {
  const notes = await prisma.salesDebitNote.findMany({
    where: { tenantId: req.tenantId },
    include: { lineItems: { select: { id: true } }, invoice: { select: { id: true, invoiceNumberDisplay: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ salesDebitNotes: notes });
}

// POST /api/tenant/sales-debit-notes
// Body: { invoiceId, reason, issueDate?, notes?, lineItems: [{ invoiceLineItemId?, taxCategoryId?, description?, quantity, unitPrice? }] }
async function createSalesDebitNote(req, res) {
  const { invoiceId, reason, issueDate, notes, lineItems } = req.body;
  if (!invoiceId) throw new ApiError(400, "invoiceId is required");
  if (!reason?.trim()) throw new ApiError(400, "A reason is required");
  if (!Array.isArray(lineItems) || lineItems.length === 0) throw new ApiError(400, "At least one line item is required");

  const invoice = await loadEligibleInvoice(req.tenantId, invoiceId);

  let resolvedIssueDate = new Date();
  if (issueDate) {
    resolvedIssueDate = new Date(issueDate);
    if (Number.isNaN(resolvedIssueDate.getTime())) throw new ApiError(400, "Invalid issueDate");
    if (invoice.issueDate && resolvedIssueDate < invoice.issueDate) {
      throw new ApiError(400, "Debit Note issue date can't be before the original invoice's issue date");
    }
  }

  const resolvedLines = lineItems.map((item, i) => resolveNoteLineFromSource(invoice, { ...item, sortOrder: i }));

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    const created = await tx.salesDebitNote.create({
      data: {
        tenantId: req.tenantId,
        invoiceId: invoice.id,
        reason: reason.trim(),
        businessName: invoice.businessName,
        businessTrn: invoice.businessTrn,
        customerName: invoice.customerName,
        customerAddress: invoice.customerAddress,
        customerTrn: invoice.customerTrn,
        currency: invoice.currency,
        notes: notes || null,
        issueDate: issueDate ? resolvedIssueDate : null,
        lineItems: { create: resolvedLines },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Against ${invoice.invoiceNumberDisplay}`, req.tenantUser.id);
    return recomputeAndPersist(tx, created.id);
  });

  res.status(201).json({ salesDebitNote });
}

// GET /api/tenant/sales-debit-notes/:id
async function getSalesDebitNote(req, res) {
  const salesDebitNote = await prisma.salesDebitNote.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: FULL_INCLUDE,
  });
  if (!salesDebitNote) throw new ApiError(404, "Debit note not found");

  const previouslyAdjusted = await sumIssuedAgainstInvoice(prisma, salesDebitNote.invoiceId, salesDebitNote.id);

  res.json({ salesDebitNote, adjustment: { originalAmount: salesDebitNote.invoice.grandTotal, previouslyAdjusted, currentNote: salesDebitNote.grandTotal } });
}

// PATCH /api/tenant/sales-debit-notes/:id - Draft-only, replaces reason/notes/issueDate.
async function updateSalesDebitNote(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const { reason, notes, issueDate } = req.body;
  const data = {};
  if (reason !== undefined) {
    if (!reason?.trim()) throw new ApiError(400, "A reason is required");
    data.reason = reason.trim();
  }
  if (notes !== undefined) data.notes = notes || null;
  if (issueDate !== undefined) {
    const d = issueDate ? new Date(issueDate) : null;
    if (issueDate && Number.isNaN(d.getTime())) throw new ApiError(400, "Invalid issueDate");
    data.issueDate = d;
  }

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    await tx.salesDebitNote.update({ where: { id: existing.id }, data });
    await logActivity(tx, existing.id, "EDITED", null, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ salesDebitNote });
}

// POST /api/tenant/sales-debit-notes/:id/line-items
async function addLineItem(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const invoice = await prisma.invoice.findFirst({ where: { id: existing.invoiceId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(invoice, { ...req.body, sortOrder: existing.lineItems.length });

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    await tx.salesDebitNoteLineItem.create({ data: { salesDebitNoteId: existing.id, ...resolved } });
    await logActivity(tx, existing.id, "EDITED", `Added line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.status(201).json({ salesDebitNote });
}

// PATCH /api/tenant/sales-debit-notes/:id/line-items/:lineId
async function updateLineItem(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const line = await prisma.salesDebitNoteLineItem.findFirst({ where: { id: req.params.lineId, salesDebitNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const invoice = await prisma.invoice.findFirst({ where: { id: existing.invoiceId }, include: { lineItems: true } });
  const resolved = resolveNoteLineFromSource(invoice, {
    invoiceLineItemId: req.body.invoiceLineItemId !== undefined ? req.body.invoiceLineItemId : line.invoiceLineItemId,
    taxCategoryId: req.body.taxCategoryId !== undefined ? req.body.taxCategoryId : line.taxCategoryId,
    description: req.body.description !== undefined ? req.body.description : line.description,
    unitPrice: req.body.unitPrice !== undefined ? req.body.unitPrice : line.unitPrice,
    quantity: req.body.quantity !== undefined ? req.body.quantity : line.quantity,
    sortOrder: line.sortOrder,
  });

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    await tx.salesDebitNoteLineItem.update({ where: { id: line.id }, data: resolved });
    await logActivity(tx, existing.id, "EDITED", `Updated line: ${resolved.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ salesDebitNote });
}

// DELETE /api/tenant/sales-debit-notes/:id/line-items/:lineId
async function deleteLineItem(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const line = await prisma.salesDebitNoteLineItem.findFirst({ where: { id: req.params.lineId, salesDebitNoteId: existing.id } });
  if (!line) throw new ApiError(404, "Line item not found");

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    await tx.salesDebitNoteLineItem.delete({ where: { id: line.id } });
    await logActivity(tx, existing.id, "EDITED", `Removed line: ${line.description}`, req.tenantUser.id);
    return recomputeAndPersist(tx, existing.id);
  });
  res.json({ salesDebitNote });
}

// DELETE /api/tenant/sales-debit-notes/:id - hard delete, Draft-only.
async function deleteSalesDebitNote(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  await prisma.salesDebitNote.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// The real numbering-assignment + status-transition mutation - resolvable by
// name for the Maker-Checker executor, same shape as issueCreditNoteTx.
async function issueSalesDebitNoteTx(tx, tenantId, salesDebitNoteId, actorId) {
  const existing = await tx.salesDebitNote.findFirst({ where: { id: salesDebitNoteId, tenantId }, include: { lineItems: true } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  if (existing.status !== "DRAFT") throw new ApiError(409, "This debit note is no longer a Draft and can't be issued");
  if (existing.lineItems.length === 0) throw new ApiError(400, "Add at least one line item before issuing");

  const invoice = await tx.invoice.findFirst({ where: { id: existing.invoiceId } });
  if (!invoice) throw new ApiError(404, "Original invoice not found");
  if (invoice.status !== "SENT") throw new ApiError(409, "The original invoice is no longer eligible (not Sent)");

  await recomputeAndPersist(tx, existing.id);

  const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextSalesDebitNoteNumber: { increment: 1 } } });
  const assignedNumber = tenant.nextSalesDebitNoteNumber - 1;
  const display = `DN-${String(assignedNumber).padStart(6, "0")}`;

  await logActivity(tx, existing.id, "ISSUED", display, actorId);

  return tx.salesDebitNote.update({
    where: { id: existing.id },
    data: { salesDebitNoteNumber: assignedNumber, salesDebitNoteNumberDisplay: display, issueDate: existing.issueDate || new Date(), status: "ISSUED" },
    include: FULL_INCLUDE,
  });
}

// POST /api/tenant/sales-debit-notes/:id/issue - routed through Maker-Checker.
async function issueSalesDebitNote(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  assertDraft(existing);

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "sales_debit_notes.issue",
    module: "sales_debit_notes",
    action: "issue",
    entityType: "SalesDebitNote",
    entityId: existing.id,
    payload: {},
  });

  if (result.status === "PENDING") {
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  res.json({ salesDebitNote: result.entity });
}

// POST /api/tenant/sales-debit-notes/:id/void
async function voidSalesDebitNote(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");
  if (existing.status !== "ISSUED") throw new ApiError(409, "Only an Issued debit note can be voided");

  const salesDebitNote = await prisma.$transaction(async (tx) => {
    await logActivity(tx, existing.id, "VOIDED", null, req.tenantUser.id);
    return tx.salesDebitNote.update({ where: { id: existing.id }, data: { status: "VOID" }, include: FULL_INCLUDE });
  });
  res.json({ salesDebitNote });
}

// POST /api/tenant/sales-debit-notes/:id/activity
async function logSalesDebitNoteActivity(req, res) {
  const existing = await prisma.salesDebitNote.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Debit note not found");

  const { type, description } = req.body;
  if (!VALID_ACTIVITY_TYPES.includes(type)) {
    throw new ApiError(400, `type must be one of ${VALID_ACTIVITY_TYPES.join(", ")}`);
  }

  const activity = await prisma.salesDebitNoteActivity.create({ data: { salesDebitNoteId: existing.id, type, description: description || null, actorId: req.tenantUser.id } });
  res.status(201).json({ activity });
}

module.exports = {
  listSalesDebitNotes,
  createSalesDebitNote,
  getSalesDebitNote,
  updateSalesDebitNote,
  addLineItem,
  updateLineItem,
  deleteLineItem,
  deleteSalesDebitNote,
  issueSalesDebitNote,
  voidSalesDebitNote,
  logSalesDebitNoteActivity,
  issueSalesDebitNoteTx,
  logActivity,
  FULL_INCLUDE,
};
