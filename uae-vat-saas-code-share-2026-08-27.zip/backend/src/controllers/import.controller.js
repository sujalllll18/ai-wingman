const fs = require("fs");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const engine = require("../services/approvalEngine.service");
const importEngine = require("../services/importEngine.service");

// BANK_TRANSACTION added (Bank Statement Import, Phase 3 2026-08-22) - same
// single-file wizard as Sales Invoice/Purchase Bill, just with an extra
// bankAccountId the frontend collects before Upload (see createBatch below).
const VALID_IMPORT_TYPES = ["SALES_INVOICE", "PURCHASE_BILL", "BANK_TRANSACTION"];

// GET /api/tenant/imports/types - what the "New Import" screen offers, and
// the real field list each one's template/mapping step is built from
// (never a hardcoded field list in the frontend - see importAdapters.js).
function listImportTypes(req, res) {
  res.json({ importTypes: importEngine.listAdapters() });
}

// POST /api/tenant/imports - multipart upload (see import.routes.js multer
// config, same disk-storage pattern as Purchase OCR). Parses the file and
// creates the batch + one ImportRecord per row, but writes NOTHING to any
// real ledger table yet - same "nothing is final until Commit" principle
// Purchase OCR's extract/confirm split already established.
async function createBatch(req, res) {
  if (!req.file) throw new ApiError(400, "No file uploaded");
  const { importType, periodFrom, periodTo, bankAccountId } = req.body;
  if (!VALID_IMPORT_TYPES.includes(importType)) {
    throw new ApiError(400, `importType must be one of ${VALID_IMPORT_TYPES.join(", ")}`);
  }
  // bankAccountId is required for BANK_TRANSACTION only - every other import
  // type ignores it (importEngine.createBatch only persists it when given).
  if (importType === "BANK_TRANSACTION") {
    if (!bankAccountId) throw new ApiError(400, "bankAccountId is required for a Bank Transaction import");
    const account = await prisma.bankAccount.findFirst({ where: { id: bankAccountId, tenantId: req.tenantId } });
    if (!account) throw new ApiError(400, "bankAccountId does not refer to a bank account on this tenant");
  }

  // Same disk-storage pattern as Purchase OCR (multer writes the file to
  // uploads/imports/ first, see import.routes.js) - read it back into a
  // buffer for xlsx to parse, so the original file also stays on disk for
  // "download original file" / re-inspection later, not just in memory.
  const buffer = fs.readFileSync(req.file.path);
  const { batch, headers, mapping } = await importEngine.createBatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    importType,
    periodFrom,
    periodTo,
    bankAccountId: importType === "BANK_TRANSACTION" ? bankAccountId : undefined,
    file: {
      buffer,
      originalname: req.file.originalname,
      fileUrl: `/uploads/imports/${req.file.filename}`,
    },
  });

  if (importType === "BANK_TRANSACTION") {
    await prisma.bankAccountActivity.create({
      data: { bankAccountId, type: "STATEMENT_UPLOADED", description: `${req.file.originalname} (${batch.batchNumber})` },
    });
  }

  res.status(201).json({ batch, headers, mapping });
}

// POST /api/tenant/imports/:id/mapping
async function setMapping(req, res) {
  const { mapping } = req.body;
  if (!mapping || typeof mapping !== "object") throw new ApiError(400, "mapping is required");
  const batch = await importEngine.setMapping({ tenantId: req.tenantId, batchId: req.params.id, mapping });
  if (batch.importType === "BANK_TRANSACTION" && batch.bankAccountId) {
    await prisma.bankAccountActivity.create({ data: { bankAccountId: batch.bankAccountId, type: "MAPPING_CHANGED", description: batch.batchNumber } });
  }
  res.json({ batch });
}

// POST /api/tenant/imports/:id/validate
async function validateBatch(req, res) {
  const batch = await importEngine.validateBatch({ tenantId: req.tenantId, batchId: req.params.id });
  res.json({ batch });
}

// GET /api/tenant/imports/:id/preview?status=VALID|INVALID
async function previewBatch(req, res) {
  const result = await importEngine.previewBatch({ tenantId: req.tenantId, batchId: req.params.id, status: req.query.status });
  res.json(result);
}

// POST /api/tenant/imports/:id/commit - the one gated step. Routed through
// the same Maker-Checker engine every other module uses; "ImportBatch.commit"
// is registered in approvalExecutors.js. Batch-level approval (Phase 1
// decision - see the Import Framework plan): one ApprovalRequest for the
// whole batch when imports.commit's rule is active, not one per row.
//
// The executor now starts the migration engine rather than running it to
// completion (see importEngine.service.js) - this endpoint's response is a
// QUEUED/PROCESSING batch, not a finished one, even outside the approval
// path. The frontend polls GET /:id for progress.
async function commitBatch(req, res) {
  const existing = await importEngine.getBatch({ tenantId: req.tenantId, batchId: req.params.id });
  if (!["PREVIEW", "PENDING_APPROVAL"].includes(existing.status)) {
    throw new ApiError(409, `This batch is ${existing.status.toLowerCase()} and can't be committed`);
  }

  const result = await engine.dispatch({
    tenantId: req.tenantId,
    userId: req.tenantUser.id,
    permissionKey: "imports.commit",
    module: "imports",
    action: "commit",
    entityType: "ImportBatch",
    entityId: existing.id,
    payload: {},
  });

  if (result.status === "PENDING") {
    // Cosmetic status flip only - see importEngine.service.js's
    // markPendingApproval doc comment for why this isn't the real gate.
    await importEngine.markPendingApproval({ tenantId: req.tenantId, batchId: existing.id });
    return res.status(202).json({ approvalRequest: result.approvalRequest });
  }
  if (existing.importType === "BANK_TRANSACTION" && existing.bankAccountId) {
    await prisma.bankAccountActivity.create({ data: { bankAccountId: existing.bankAccountId, type: "IMPORT_STARTED", description: existing.batchNumber } });
  }
  res.json({ batch: result.entity });
}

// POST /api/tenant/imports/:id/pause - requests a pause at the next chunk
// boundary (never mid-record). Status flips to PAUSED asynchronously.
async function pauseBatch(req, res) {
  const batch = await importEngine.pauseMigration({ tenantId: req.tenantId, batchId: req.params.id });
  res.json({ batch });
}

// POST /api/tenant/imports/:id/resume - continues a PAUSED batch (including
// one a server restart flipped to PAUSED after a crash) from exactly where
// it left off - see importEngine.service.js's resumeMigration doc comment.
async function resumeBatch(req, res) {
  const batch = await importEngine.resumeMigration({ tenantId: req.tenantId, batchId: req.params.id, actorId: req.tenantUser.id });
  res.json({ batch });
}

// POST /api/tenant/imports/:id/cancel
async function cancelBatch(req, res) {
  const batch = await importEngine.cancelMigration({ tenantId: req.tenantId, batchId: req.params.id });
  res.json({ batch });
}

// POST /api/tenant/imports/:id/retry-failed - re-attempts only FAILED
// (commit-time failure) records, without re-uploading anything.
async function retryFailed(req, res) {
  const batch = await importEngine.retryFailedRecords({ tenantId: req.tenantId, batchId: req.params.id, actorId: req.tenantUser.id });
  if (batch.importType === "BANK_TRANSACTION" && batch.bankAccountId) {
    await prisma.bankAccountActivity.create({ data: { bankAccountId: batch.bankAccountId, type: "IMPORT_RETRIED", description: batch.batchNumber } });
  }
  res.json({ batch });
}

// GET /api/tenant/imports
async function listBatches(req, res) {
  const batches = await importEngine.listBatches({ tenantId: req.tenantId });
  res.json({ batches });
}

// GET /api/tenant/imports/:id
async function getBatch(req, res) {
  const batch = await importEngine.getBatch({ tenantId: req.tenantId, batchId: req.params.id });
  res.json({ batch });
}

// GET /api/tenant/imports/:id/records?status=
async function getRecords(req, res) {
  const records = await importEngine.getRecords({
    tenantId: req.tenantId,
    batchId: req.params.id,
    status: req.query.status,
    onlyWarnings: req.query.onlyWarnings === "true",
    onlyDuplicates: req.query.onlyDuplicates === "true",
  });
  res.json({ records });
}

// GET /api/tenant/imports/:id/error-report - CSV download of every failed
// row + its errors, so the user can fix the source file and re-upload.
async function downloadErrorReport(req, res) {
  const csv = await importEngine.buildErrorReportCsv({ tenantId: req.tenantId, batchId: req.params.id });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="import-errors.csv"`);
  res.send(csv);
}

module.exports = {
  listImportTypes,
  createBatch,
  setMapping,
  validateBatch,
  previewBatch,
  commitBatch,
  pauseBatch,
  resumeBatch,
  cancelBatch,
  retryFailed,
  listBatches,
  getBatch,
  getRecords,
  downloadErrorReport,
};
