const prisma = require("../config/prisma");

// Vendor Master works silently in the background (per Purchase Module scope)
// - there's no create/update endpoint here. Vendors only ever come into
// existence via src/services/vendorResolver.js, called from
// purchase.controller.js when a Purchase Bill is created/confirmed. This
// list endpoint exists purely so the frontend can populate a Vendor
// filter/selector, same read-only role Customers plays for Invoice's
// customer selector.
async function listVendors(req, res) {
  const vendors = await prisma.vendor.findMany({
    where: { tenantId: req.tenantId },
    orderBy: { name: "asc" },
  });
  res.json({ vendors });
}

module.exports = { listVendors };
