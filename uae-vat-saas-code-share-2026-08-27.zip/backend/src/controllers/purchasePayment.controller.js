// Supplier Payments module (Phase 2, 2026-08-22) - the vendor-side mirror of
// payment.controller.js, kept as a fully separate model/controller/route
// namespace per the brief's explicit "keep Customer Payments and Supplier
// Payments logically separated" requirement. See that file's comments for
// the shared design reasoning (allocation model, reconciliation foundation,
// cancel-not-delete lifecycle) - not repeated here line for line.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { round2 } = require("../services/invoiceCalc");
const { recalculatePaymentFields, logActivity: logPurchaseActivity } = require("./purchase.controller");

const VALID_PAYMENT_METHODS = ["CASH", "BANK_TRANSFER", "CARD", "CHEQUE", "OTHER"];

const FULL_INCLUDE = {
  allocations: {
    include: { purchaseBill: { select: { id: true, billNumberDisplay: true, grandTotal: true, outstandingAmount: true, currency: true, status: true, paymentStatus: true } } },
    orderBy: { createdAt: "asc" },
  },
  activities: { orderBy: { createdAt: "desc" } },
  // Reconciliation Engine (Phase 4, 2026-08-23) - vendor-side mirror of
  // payment.controller.js's own reconciliationLines include, same reasoning.
  reconciliationLines: {
    where: { match: { status: { in: ["SUGGESTED", "CONFIRMED"] } } },
    include: {
      match: {
        select: {
          id: true,
          matchNumberDisplay: true,
          status: true,
          confidence: true,
          matchedAt: true,
          bankLines: { include: { bankTransaction: { select: { id: true, transactionDate: true, description: true, reference: true, amount: true, currency: true, bankAccount: { select: { accountName: true } } } } } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  },
};

function logPaymentActivity(tx, purchasePaymentId, type, description) {
  return tx.purchasePaymentActivity.create({ data: { purchasePaymentId, type, description: description || null } });
}

function withComputed(payment) {
  const allocatedTotal = round2((payment.allocations || []).reduce((sum, a) => sum + a.allocatedAmount, 0));
  const unallocatedAmount = round2(Math.max(0, payment.amount - allocatedTotal));
  return { ...payment, allocatedTotal, unallocatedAmount };
}

function assertEditable(payment) {
  if (payment.status === "CANCELLED") throw new ApiError(409, "This payment has been cancelled");
  if (payment.reconciliationStatus === "RECONCILED" || payment.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - unmatch it first");
  }
}

async function resolveAllocations(tenantId, allocationInputs, paymentAmount) {
  const list = Array.isArray(allocationInputs) ? allocationInputs : [];
  const resolved = [];
  let total = 0;

  for (const item of list) {
    const allocAmount = Number(item.amount);
    if (!allocAmount || Number.isNaN(allocAmount) || allocAmount <= 0) {
      throw new ApiError(400, "Each allocation amount must be a positive number");
    }
    const bill = await prisma.purchaseBill.findFirst({ where: { id: item.purchaseBillId, tenantId } });
    if (!bill) throw new ApiError(400, `purchaseBillId ${item.purchaseBillId} does not refer to a purchase bill on this tenant`);
    if (bill.status !== "RECORDED") {
      throw new ApiError(400, `Purchase bill ${bill.billNumberDisplay || bill.id} must be Recorded before a payment can be allocated to it`);
    }
    total += allocAmount;
    resolved.push({ bill, allocAmount: round2(allocAmount) });
  }

  if (round2(total) > round2(Number(paymentAmount)) + 0.005) {
    throw new ApiError(400, `Total allocated amount (${round2(total)}) cannot exceed the payment amount (${round2(Number(paymentAmount))})`);
  }

  return resolved;
}

// GET /api/tenant/purchase-payments
async function listPurchasePayments(req, res) {
  const { vendorId, status } = req.query;
  const payments = await prisma.purchasePayment.findMany({
    where: {
      tenantId: req.tenantId,
      ...(vendorId ? { vendorId } : {}),
      ...(status ? { status } : {}),
    },
    include: { allocations: { select: { allocatedAmount: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ payments: payments.map(withComputed) });
}

// GET /api/tenant/purchase-payments/allocatable-bills?vendorId=...
async function listAllocatableBills(req, res) {
  const { vendorId } = req.query;
  if (!vendorId) throw new ApiError(400, "vendorId is required");

  const bills = await prisma.purchaseBill.findMany({
    where: { tenantId: req.tenantId, vendorId, status: "RECORDED" },
    select: { id: true, billNumberDisplay: true, purchaseDate: true, currency: true, grandTotal: true, amountPaid: true, outstandingAmount: true, paymentStatus: true },
    orderBy: { purchaseDate: "asc" },
  });
  res.json({ purchaseBills: bills });
}

// POST /api/tenant/purchase-payments
async function createPurchasePayment(req, res) {
  const { vendorId, vendorName, paymentDate, amount, currency, method, accountRef, reference, notes, allocations } = req.body;

  if (amount === undefined || amount === null || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
    throw new ApiError(400, "amount must be a positive number");
  }
  if (!paymentDate) throw new ApiError(400, "paymentDate is required");
  if (!VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  let resolvedVendorId = null;
  let vendorSnapshotName = vendorName?.trim() || "";
  if (vendorId) {
    const vendor = await prisma.vendor.findFirst({ where: { id: vendorId, tenantId: req.tenantId } });
    if (!vendor) throw new ApiError(400, "vendorId does not refer to a vendor on this tenant");
    resolvedVendorId = vendor.id;
    vendorSnapshotName = vendorName?.trim() || vendor.name;
  }
  if (!vendorSnapshotName) throw new ApiError(400, "Supplier is required (select a Supplier or enter one manually)");

  const resolvedAllocations = await resolveAllocations(req.tenantId, allocations, amount);
  const paymentCurrency = currency || "AED";

  const payment = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: req.tenantId }, data: { nextPurchasePaymentNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextPurchasePaymentNumber - 1;
    const display = `SPAY-${String(assignedNumber).padStart(6, "0")}`;

    const created = await tx.purchasePayment.create({
      data: {
        tenantId: req.tenantId,
        vendorId: resolvedVendorId,
        vendorName: vendorSnapshotName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        amount: Number(amount),
        currency: paymentCurrency,
        paymentDate: new Date(paymentDate),
        method,
        accountRef: accountRef || null,
        reference: reference || null,
        notes: notes || null,
        source: "MANUAL",
      },
    });

    await logPaymentActivity(tx, created.id, "CREATED", `${paymentCurrency} ${Number(amount).toFixed(2)} via ${method} to ${vendorSnapshotName}`);

    for (const { bill, allocAmount } of resolvedAllocations) {
      await tx.purchasePaymentAllocation.create({ data: { purchasePaymentId: created.id, purchaseBillId: bill.id, allocatedAmount: allocAmount } });
    }
    if (resolvedAllocations.length > 0) {
      const summary = resolvedAllocations.map((r) => `${r.bill.billNumberDisplay || r.bill.id}: ${paymentCurrency} ${r.allocAmount.toFixed(2)}`).join(", ");
      await logPaymentActivity(tx, created.id, "ALLOCATED", summary);
      for (const { bill, allocAmount } of resolvedAllocations) {
        await recalculatePaymentFields(tx, bill.id);
        await logPurchaseActivity(tx, bill.id, "PAYMENT_RECORDED", `${paymentCurrency} ${allocAmount.toFixed(2)} via ${method} (${display})`);
      }
    }

    return tx.purchasePayment.findUnique({ where: { id: created.id }, include: FULL_INCLUDE });
  });

  res.status(201).json({ payment: withComputed(payment) });
}

// GET /api/tenant/purchase-payments/:id
async function getPurchasePayment(req, res) {
  const payment = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: FULL_INCLUDE });
  if (!payment) throw new ApiError(404, "Payment not found");
  res.json({ payment: withComputed(payment) });
}

// PATCH /api/tenant/purchase-payments/:id
async function updatePurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  assertEditable(existing);

  const { paymentDate, method, accountRef, reference, notes } = req.body;
  if (method !== undefined && !VALID_PAYMENT_METHODS.includes(method)) {
    throw new ApiError(400, `method must be one of ${VALID_PAYMENT_METHODS.join(", ")}`);
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.purchasePayment.update({
      where: { id: existing.id },
      data: {
        ...(paymentDate !== undefined ? { paymentDate: new Date(paymentDate) } : {}),
        ...(method !== undefined ? { method } : {}),
        ...(accountRef !== undefined ? { accountRef: accountRef || null } : {}),
        ...(reference !== undefined ? { reference: reference || null } : {}),
        ...(notes !== undefined ? { notes: notes || null } : {}),
      },
    });
    await logPaymentActivity(tx, existing.id, "EDITED", null);
    return tx.purchasePayment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// POST /api/tenant/purchase-payments/:id/allocate
async function reallocatePurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  assertEditable(existing);

  const resolvedAllocations = await resolveAllocations(req.tenantId, req.body.allocations, existing.amount);
  const affectedBillIds = new Set([...existing.allocations.map((a) => a.purchaseBillId), ...resolvedAllocations.map((r) => r.bill.id)]);

  const payment = await prisma.$transaction(async (tx) => {
    await tx.purchasePaymentAllocation.deleteMany({ where: { purchasePaymentId: existing.id } });
    for (const { bill, allocAmount } of resolvedAllocations) {
      await tx.purchasePaymentAllocation.create({ data: { purchasePaymentId: existing.id, purchaseBillId: bill.id, allocatedAmount: allocAmount } });
    }

    const summary = resolvedAllocations.length > 0
      ? resolvedAllocations.map((r) => `${r.bill.billNumberDisplay || r.bill.id}: ${existing.currency} ${r.allocAmount.toFixed(2)}`).join(", ")
      : "fully unallocated";
    await logPaymentActivity(tx, existing.id, "REALLOCATED", summary);

    for (const purchaseBillId of affectedBillIds) {
      await recalculatePaymentFields(tx, purchaseBillId);
      await logPurchaseActivity(tx, purchaseBillId, "EDITED", `Payment ${existing.paymentNumberDisplay || existing.id} reallocation updated`);
    }

    return tx.purchasePayment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// POST /api/tenant/purchase-payments/:id/cancel
async function cancelPurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.status === "CANCELLED") throw new ApiError(409, "This payment is already cancelled");
  if (existing.reconciliationStatus === "RECONCILED" || existing.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - unmatch it first");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.purchasePayment.update({ where: { id: existing.id }, data: { status: "CANCELLED" } });
    await logPaymentActivity(tx, existing.id, "CANCELLED", req.body?.reason || null);

    for (const allocation of existing.allocations) {
      await recalculatePaymentFields(tx, allocation.purchaseBillId);
      await logPurchaseActivity(tx, allocation.purchaseBillId, "EDITED", `Payment ${existing.paymentNumberDisplay || existing.id} was cancelled`);
    }

    return tx.purchasePayment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });

  res.json({ payment: withComputed(payment) });
}

// DELETE /api/tenant/purchase-payments/:id
async function deletePurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId }, include: { allocations: true } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.allocations.length > 0) {
    throw new ApiError(409, "This payment has allocations against one or more purchase bills - cancel it instead of deleting");
  }

  await prisma.purchasePayment.delete({ where: { id: existing.id } });
  res.status(204).send();
}

// Manual, no-bank-statement-involved toggle - see payment.controller.js's
// reconcilePayment for the full reasoning (vendor-side mirror).
async function reconcilePurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.status === "CANCELLED") throw new ApiError(409, "A cancelled payment can't be reconciled");
  if (existing.reconciliationStatus === "RECONCILED") throw new ApiError(409, "Already reconciled");
  if (existing.reconciliationStatus === "PARTIALLY_RECONCILED") {
    throw new ApiError(409, "This payment already has a bank match in progress - use the Reconciliation module to complete or unmatch it");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.purchasePayment.update({ where: { id: existing.id }, data: { reconciliationStatus: "RECONCILED" } });
    await logPaymentActivity(tx, existing.id, "RECONCILED", null);
    return tx.purchasePayment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });
  res.json({ payment: withComputed(payment) });
}

async function unreconcilePurchasePayment(req, res) {
  const existing = await prisma.purchasePayment.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!existing) throw new ApiError(404, "Payment not found");
  if (existing.reconciliationStatus !== "RECONCILED") throw new ApiError(409, "This payment is not reconciled");
  const activeBankMatch = await prisma.reconciliationLedgerLine.findFirst({ where: { purchasePaymentId: existing.id, match: { status: "CONFIRMED" } } });
  if (activeBankMatch) {
    throw new ApiError(409, "This payment is reconciled against a bank transaction - use the Reconciliation module's Unmatch action instead");
  }

  const payment = await prisma.$transaction(async (tx) => {
    await tx.purchasePayment.update({ where: { id: existing.id }, data: { reconciliationStatus: "UNRECONCILED" } });
    await logPaymentActivity(tx, existing.id, "UNRECONCILED", null);
    return tx.purchasePayment.findUnique({ where: { id: existing.id }, include: FULL_INCLUDE });
  });
  res.json({ payment: withComputed(payment) });
}

module.exports = {
  listPurchasePayments,
  listAllocatableBills,
  createPurchasePayment,
  getPurchasePayment,
  updatePurchasePayment,
  reallocatePurchasePayment,
  cancelPurchasePayment,
  deletePurchasePayment,
  reconcilePurchasePayment,
  unreconcilePurchasePayment,
  FULL_INCLUDE,
  withComputed,
};
