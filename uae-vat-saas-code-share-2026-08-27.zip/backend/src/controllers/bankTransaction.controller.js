// Bank Transaction read surface (Banking module, Phase 3 2026-08-22). Every
// row is created exclusively by the BANK_TRANSACTION import adapter
// (importAdapters.js) via the existing Migration Engine - there is no
// manual create/edit endpoint here by design, this phase is import-only.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

// GET /api/tenant/banking/transactions
// Filters mirror the brief's own list: bankAccountId, date range, debit/
// credit presence, status, reconciliationStatus, and a free-text search over
// description/reference. All server-side (this table is meant to hold
// 100,000+ rows per the Migration Engine's own design target, so - unlike
// Invoices/Purchases - client-side filtering of the full unfiltered set
// would not scale).
async function listBankTransactions(req, res) {
  const { bankAccountId, dateFrom, dateTo, direction, status, reconciliationStatus, search, page = "1", pageSize = "25" } = req.query;

  const where = {
    tenantId: req.tenantId,
    ...(bankAccountId ? { bankAccountId } : {}),
    ...(status ? { status } : {}),
    ...(reconciliationStatus ? { reconciliationStatus } : {}),
    ...(dateFrom || dateTo
      ? {
          transactionDate: {
            ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
            ...(dateTo ? { lte: new Date(new Date(dateTo).getTime() + 86399999) } : {}),
          },
        }
      : {}),
    ...(direction === "DEBIT" ? { debit: { gt: 0 } } : direction === "CREDIT" ? { credit: { gt: 0 } } : {}),
    ...(search
      ? {
          OR: [
            { description: { contains: search } },
            { reference: { contains: search } },
          ],
        }
      : {}),
  };

  const take = Math.min(200, Math.max(1, Number(pageSize) || 25));
  const skip = (Math.max(1, Number(page) || 1) - 1) * take;

  const [total, transactions] = await Promise.all([
    prisma.bankTransaction.count({ where }),
    prisma.bankTransaction.findMany({
      where,
      include: { bankAccount: { select: { id: true, accountName: true, bankName: true, currency: true } } },
      orderBy: { transactionDate: "desc" },
      skip,
      take,
    }),
  ]);

  res.json({ transactions, total, page: Math.max(1, Number(page) || 1), pageSize: take });
}

// GET /api/tenant/banking/transactions/:id
async function getBankTransaction(req, res) {
  const transaction = await prisma.bankTransaction.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { bankAccount: { select: { id: true, accountName: true, bankName: true, currency: true } } },
  });
  if (!transaction) throw new ApiError(404, "Bank transaction not found");

  // Import batch is plain data (importBatchId), not a relation - same
  // convention as every other importBatchId in this schema - resolved here
  // as a display convenience only.
  const importBatch = transaction.importBatchId
    ? await prisma.importBatch.findUnique({ where: { id: transaction.importBatchId }, select: { id: true, batchNumber: true, sourceFileName: true } })
    : null;

  res.json({ transaction, importBatch });
}

module.exports = { listBankTransactions, getBankTransaction };
