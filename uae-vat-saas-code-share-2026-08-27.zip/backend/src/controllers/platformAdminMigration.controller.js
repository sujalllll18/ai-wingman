// Platform Admin's side of the Migration lifecycle - lets a Platform Admin
// start/drive a historical data migration for a tenant that either already
// exists ("Platform Admin -> Tenants -> Select Tenant -> Migration" tab) or
// was just created via onboarding. Mirrors the exact existing pattern every
// other tenant-scoped Platform Admin action already uses (suspendTenant,
// createStaffUser, getTenantUsage in platformAdmin.controller.js):
// requirePlatformAdmin only, tenantId trusted directly from req.params -
// Platform Admin is a single flat identity with no RBAC and (confirmed via
// the PlanChangeHistory.approvalStatus schema comment) never routes through
// the tenant-scoped Maker-Checker engine, so migrations started this way
// commit immediately, with no approval step.
//
// Every per-file operation before Commit (set mapping, validate) needs its
// own pass-through here, unlike the tenant self-service side - Platform
// Admin has no tenant JWT and therefore cannot call the existing
// /api/tenant/imports/:id/* endpoints at all. Each pass-through still goes
// through the SAME importEngine.service.js functions the tenant-side
// controller uses; nothing about the engine itself is duplicated.
const fs = require("fs");
const ApiError = require("../utils/ApiError");
const prisma = require("../config/prisma");
const importEngine = require("../services/importEngine.service");
const orchestrator = require("../services/migrationOrchestrator.service");
const { listAdapters } = require("../services/importAdapters");

const VALID_IMPORT_TYPES = listAdapters().map((a) => a.importType);

async function assertTenantExists(tenantId) {
  const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
  if (!tenant) throw new ApiError(404, "Tenant not found");
  return tenant;
}

// GET /tenants/:tenantId/migrations/types - not actually tenant-specific
// data (the adapter registry is global), but kept under this same
// tenant-scoped path for routing consistency with everything else here, and
// because Platform Admin has no other existing "list import types" entry
// point (the tenant-side GET /api/tenant/imports/types is unreachable
// without a tenant JWT).
function listImportTypes(req, res) {
  res.json({ importTypes: listAdapters() });
}

async function createMigration(req, res) {
  const { tenantId } = req.params;
  await assertTenantExists(tenantId);

  const files = req.files || [];
  if (files.length === 0) throw new ApiError(400, "At least one file is required");

  let meta;
  try {
    meta = JSON.parse(req.body.fileMeta || "[]");
  } catch {
    throw new ApiError(400, "fileMeta must be a JSON array");
  }
  if (!Array.isArray(meta) || meta.length !== files.length) {
    throw new ApiError(400, "fileMeta must have exactly one entry per uploaded file, in the same order");
  }
  for (const m of meta) {
    if (!VALID_IMPORT_TYPES.includes(m.importType)) {
      throw new ApiError(400, `importType must be one of ${VALID_IMPORT_TYPES.join(", ")}`);
    }
  }

  const { migration, batches } = await orchestrator.createMigration({
    tenantId,
    source: req.body.source || "EXCEL",
    startedByType: "PLATFORM_ADMIN",
    startedById: req.platformAdmin.id,
    files: files.map((file, i) => ({
      importType: meta[i].importType,
      periodFrom: meta[i].periodFrom,
      periodTo: meta[i].periodTo,
      file: {
        buffer: fs.readFileSync(file.path),
        originalname: file.originalname,
        fileUrl: `/uploads/imports/${file.filename}`,
      },
    })),
  });

  res.status(201).json({ migration, batches });
}

async function listMigrations(req, res) {
  const { tenantId } = req.params;
  await assertTenantExists(tenantId);
  res.json({ migrations: await orchestrator.listMigrations({ tenantId }) });
}

async function getMigration(req, res) {
  const { tenantId, id } = req.params;
  res.json({ migration: await orchestrator.getMigration({ tenantId, migrationId: id }) });
}

async function getMigrationPreview(req, res) {
  const { tenantId, id } = req.params;
  res.json(await orchestrator.getMigrationPreview({ tenantId, migrationId: id }));
}

async function getMigrationStatus(req, res) {
  const { tenantId, id } = req.params;
  res.json(await orchestrator.getMigrationStatus({ tenantId, migrationId: id }));
}

// The one endpoint that starts real data writes - direct to the engine, no
// approval routing, per this file's header comment.
async function commitMigration(req, res) {
  const { tenantId, id } = req.params;
  res.json(
    await orchestrator.commitMigration({
      tenantId,
      migrationId: id,
      actorId: req.platformAdmin.id,
      dispatchThroughApproval: false,
    })
  );
}

async function pauseMigration(req, res) {
  res.json(await orchestrator.pauseMigrationBatches({ tenantId: req.params.tenantId, migrationId: req.params.id }));
}
async function resumeMigration(req, res) {
  res.json(await orchestrator.resumeMigrationBatches({ tenantId: req.params.tenantId, migrationId: req.params.id, actorId: req.platformAdmin.id }));
}
async function cancelMigration(req, res) {
  res.json(await orchestrator.cancelMigrationBatches({ tenantId: req.params.tenantId, migrationId: req.params.id }));
}
async function retryFailed(req, res) {
  res.json(await orchestrator.retryFailedRecordsForMigration({ tenantId: req.params.tenantId, migrationId: req.params.id, actorId: req.platformAdmin.id }));
}

async function downloadErrorReport(req, res) {
  const csv = await orchestrator.buildMigrationErrorReportCsv({ tenantId: req.params.tenantId, migrationId: req.params.id });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="migration-errors.csv"`);
  res.send(csv);
}

async function getDataCounts(req, res) {
  const { tenantId } = req.params;
  await assertTenantExists(tenantId);
  res.json(await orchestrator.getTenantDataCounts(tenantId));
}

// --- Per-file pass-throughs (Preview stage, before Commit) ---------------
// Platform Admin has no tenant JWT, so it cannot reach the existing
// /api/tenant/imports/:id/mapping|validate|preview endpoints - these call
// the exact same importEngine.service.js functions those use, just with an
// admin-supplied tenantId instead of one derived from a tenant token.
// importEngine's own queries are still always `where: { id, tenantId }`,
// so a mismatched tenantId/batchId pair 404s exactly as it would for a
// tenant user - cross-tenant access is structurally impossible either way.

async function setBatchMapping(req, res) {
  const { tenantId, batchId } = req.params;
  const { mapping } = req.body;
  if (!mapping || typeof mapping !== "object") throw new ApiError(400, "mapping is required");
  res.json({ batch: await importEngine.setMapping({ tenantId, batchId, mapping }) });
}

async function validateBatch(req, res) {
  const { tenantId, batchId } = req.params;
  res.json({ batch: await importEngine.validateBatch({ tenantId, batchId }) });
}

async function previewBatch(req, res) {
  const { tenantId, batchId } = req.params;
  res.json(await importEngine.previewBatch({ tenantId, batchId, status: req.query.status }));
}

async function getBatchRecords(req, res) {
  const { tenantId, batchId } = req.params;
  res.json({
    records: await importEngine.getRecords({
      tenantId,
      batchId,
      status: req.query.status,
      onlyWarnings: req.query.onlyWarnings === "true",
      onlyDuplicates: req.query.onlyDuplicates === "true",
    }),
  });
}

module.exports = {
  listImportTypes,
  createMigration,
  listMigrations,
  getMigration,
  getMigrationPreview,
  getMigrationStatus,
  commitMigration,
  pauseMigration,
  resumeMigration,
  cancelMigration,
  retryFailed,
  downloadErrorReport,
  getDataCounts,
  setBatchMapping,
  validateBatch,
  previewBatch,
  getBatchRecords,
};
