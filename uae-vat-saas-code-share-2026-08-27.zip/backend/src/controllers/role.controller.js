const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { MODULES } = require("../config/permissionCatalog");

// createdBy stores either "system" (the 8 seeded roles) or a User.id -
// resolved to a display name here rather than making every caller do a
// second lookup for a raw UUID.
async function resolveCreatorNames(roles) {
  const creatorIds = [...new Set(roles.map((r) => r.createdBy).filter((id) => id !== "system"))];
  const creators = creatorIds.length > 0 ? await prisma.user.findMany({ where: { id: { in: creatorIds } }, select: { id: true, name: true } }) : [];
  const nameById = new Map(creators.map((u) => [u.id, u.name]));
  return (createdBy) => (createdBy === "system" ? "System" : nameById.get(createdBy) || "Unknown");
}

// GET /api/tenant/roles
async function listRoles(req, res) {
  const roles = await prisma.role.findMany({
    where: { tenantId: req.tenantId },
    include: { _count: { select: { rolePermissions: true, userRoles: true } } },
    orderBy: [{ isSystem: "desc" }, { createdAt: "asc" }],
  });
  const creatorName = await resolveCreatorNames(roles);

  res.json({
    roles: roles.map((r) => ({
      id: r.id,
      name: r.name,
      code: r.code,
      description: r.description,
      isSystem: r.isSystem,
      status: r.status,
      createdByName: creatorName(r.createdBy),
      createdAt: r.createdAt,
      usersAssigned: r._count.userRoles,
      permissionsCount: r._count.rolePermissions,
    })),
  });
}

// GET /api/tenant/roles/:id
async function getRole(req, res) {
  const role = await prisma.role.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: {
      rolePermissions: { include: { permission: true } },
      userRoles: { where: { isPrimary: true }, include: { user: { select: { id: true, name: true, email: true } } } },
    },
  });
  if (!role) throw new ApiError(404, "Role not found");
  const creatorName = await resolveCreatorNames([role]);

  res.json({
    role: {
      id: role.id,
      name: role.name,
      code: role.code,
      description: role.description,
      isSystem: role.isSystem,
      status: role.status,
      requiresApproval: role.requiresApproval,
      clonedFromRoleId: role.clonedFromRoleId,
      createdByName: creatorName(role.createdBy),
      createdAt: role.createdAt,
      updatedAt: role.updatedAt,
      permissionKeys: role.rolePermissions.map((rp) => rp.permission.key),
      users: role.userRoles.map((ur) => ur.user),
    },
  });
}

// GET /api/tenant/roles/permissions-catalog
// The full global Permission catalog, grouped for the matrix UI - every
// Tenant sees the same catalog, they only differ in which keys their roles
// have granted (RolePermission).
async function listPermissionCatalog(req, res) {
  const permissions = await prisma.permission.findMany({ orderBy: [{ group: "asc" }, { module: "asc" }, { sortOrder: "asc" }] });
  const moduleLabels = Object.fromEntries(MODULES.map((m) => [m.module, m.label]));
  res.json({ permissions, moduleLabels });
}

// POST /api/tenant/roles
async function createRole(req, res) {
  const { name, code, description, status, permissionKeys, cloneFromRoleId } = req.body;
  if (!name?.trim()) throw new ApiError(400, "Role name is required");
  if (!code?.trim()) throw new ApiError(400, "Short code is required");

  const normalizedCode = code.trim().toUpperCase().replace(/\s+/g, "_");
  const existing = await prisma.role.findUnique({ where: { tenantId_code: { tenantId: req.tenantId, code: normalizedCode } } });
  if (existing) throw new ApiError(409, "A role with this short code already exists");

  // cloneFromRoleId, when present, is validated and stored for provenance
  // only - it is NEVER used to re-derive permissions here. The frontend
  // fetches the source role's permissions to pre-populate the Permission
  // Matrix when "Clone Existing Role" is picked, then the user can keep
  // adjusting it before Save; permissionKeys below is always the final,
  // already-clone-seeded-if-requested set the client actually submits. If
  // this endpoint re-read the source role's CURRENT permissions instead, any
  // matrix edits made after cloning would silently be discarded.
  let clonedFromRoleId = null;
  if (cloneFromRoleId) {
    const source = await prisma.role.findFirst({ where: { id: cloneFromRoleId, tenantId: req.tenantId }, select: { id: true } });
    if (!source) throw new ApiError(404, "Role to clone not found");
    clonedFromRoleId = source.id;
  }

  const keys = Array.isArray(permissionKeys) ? permissionKeys : [];
  const permissions = keys.length > 0 ? await prisma.permission.findMany({ where: { key: { in: keys } } }) : [];

  const role = await prisma.role.create({
    data: {
      tenantId: req.tenantId,
      name: name.trim(),
      code: normalizedCode,
      description: description || null,
      status: status === "INACTIVE" ? "INACTIVE" : "ACTIVE",
      isSystem: false,
      clonedFromRoleId,
      createdBy: req.tenantUser.id,
    },
  });

  if (permissions.length > 0) {
    await prisma.rolePermission.createMany({ data: permissions.map((p) => ({ roleId: role.id, permissionId: p.id })) });
  }

  res.status(201).json({ role: { id: role.id, name: role.name, code: role.code } });
}

// PATCH /api/tenant/roles/:id
// Name/description/status only - permissions have their own endpoint below
// (a deliberately separate write path, since the matrix Save action and the
// Overview form Save action are genuinely different user intents).
async function updateRole(req, res) {
  const role = await prisma.role.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!role) throw new ApiError(404, "Role not found");

  const { name, description, status } = req.body;
  if (role.code === "OWNER" && status === "INACTIVE") {
    throw new ApiError(403, "The Owner role cannot be deactivated - a Tenant must always have an active Owner");
  }

  const updated = await prisma.role.update({
    where: { id: role.id },
    data: {
      name: name?.trim() || role.name,
      description: description !== undefined ? description : role.description,
      status: status === "INACTIVE" ? "INACTIVE" : status === "ACTIVE" ? "ACTIVE" : role.status,
    },
  });

  res.json({
    role: { id: updated.id, name: updated.name, code: updated.code, description: updated.description, status: updated.status },
  });
}

// PATCH /api/tenant/roles/:id/permissions
// Replaces the role's entire permission set with `permissionKeys` (the
// Permission Matrix always saves the full desired state, not a diff).
async function updateRolePermissions(req, res) {
  const role = await prisma.role.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!role) throw new ApiError(404, "Role not found");
  if (role.code === "OWNER") {
    throw new ApiError(403, "The Owner role always has every permission and cannot be edited");
  }

  const { permissionKeys } = req.body;
  if (!Array.isArray(permissionKeys)) throw new ApiError(400, "permissionKeys must be an array");

  const permissions = permissionKeys.length > 0 ? await prisma.permission.findMany({ where: { key: { in: permissionKeys } } }) : [];

  await prisma.$transaction([
    prisma.rolePermission.deleteMany({ where: { roleId: role.id } }),
    ...(permissions.length > 0 ? [prisma.rolePermission.createMany({ data: permissions.map((p) => ({ roleId: role.id, permissionId: p.id })) })] : []),
  ]);

  res.json({ ok: true, permissionsCount: permissions.length });
}

// DELETE /api/tenant/roles/:id
async function deleteRole(req, res) {
  const role = await prisma.role.findFirst({
    where: { id: req.params.id, tenantId: req.tenantId },
    include: { _count: { select: { userRoles: true } } },
  });
  if (!role) throw new ApiError(404, "Role not found");
  if (role.isSystem) throw new ApiError(403, "System roles cannot be deleted");
  if (role._count.userRoles > 0) throw new ApiError(409, "Reassign this role's users to a different role before deleting it");

  await prisma.role.delete({ where: { id: role.id } });
  res.json({ ok: true });
}

// POST /api/tenant/roles/:id/assign-users
// Replaces the target users' primary UserRole with this role. A user may
// only ever have one primary role (application-level constraint - the
// schema itself allows more, see UserRole's comment) - reassigning here
// means deleting their previous primary row, not adding a second one.
async function assignUsers(req, res) {
  const role = await prisma.role.findFirst({ where: { id: req.params.id, tenantId: req.tenantId } });
  if (!role) throw new ApiError(404, "Role not found");
  if (role.status !== "ACTIVE") throw new ApiError(400, "Cannot assign users to an inactive role");

  const { userIds } = req.body;
  if (!Array.isArray(userIds) || userIds.length === 0) throw new ApiError(400, "userIds must be a non-empty array");

  const users = await prisma.user.findMany({ where: { id: { in: userIds }, tenantId: req.tenantId } });
  if (users.length !== userIds.length) throw new ApiError(400, "One or more users not found in this Tenant");

  for (const user of users) {
    if (user.role === "OWNER" && role.code !== "OWNER") {
      // Guard: the Tenant's Owner can't be reassigned away from the Owner
      // role through this generic endpoint - keeps "exactly one Owner,
      // always full access" true without a separate special-case UI screen.
      throw new ApiError(403, `${user.name} is the Tenant Owner and cannot be reassigned to a different role here`);
    }
  }

  await prisma.$transaction(async (tx) => {
    for (const user of users) {
      await tx.userRole.deleteMany({ where: { userId: user.id, isPrimary: true } });
      await tx.userRole.create({ data: { userId: user.id, roleId: role.id, isPrimary: true, assignedBy: req.tenantUser.id } });
    }
  });

  res.json({ ok: true, assignedCount: users.length });
}

module.exports = {
  listRoles,
  getRole,
  listPermissionCatalog,
  createRole,
  updateRole,
  updateRolePermissions,
  deleteRole,
  assignUsers,
};
