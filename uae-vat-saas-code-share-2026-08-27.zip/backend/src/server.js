const app = require("./app");
const prisma = require("./config/prisma");

const PORT = process.env.PORT || 4000;

// Migration-engine crash recovery (2026-08-22): any ImportBatch left in
// PROCESSING when this process starts up is necessarily stale - the process
// that was running its migration loop is gone (this IS that process,
// starting fresh). Never silently auto-resume it (that would re-launch a
// potentially very large job the instant the server comes back, with no one
// aware it's running again) - flip it to PAUSED so a user (or an automated
// caller) explicitly hits Resume, which then continues from exactly the
// last checkpoint via importEngine.service.js's ImportRecord.status="VALID"
// query, with zero duplicate work. See docs on importEngine.service.js's
// runMigrationLoop/resumeMigration for the full mechanism.
async function reconcileStaleMigrations() {
  const { count } = await prisma.importBatch.updateMany({
    where: { status: "PROCESSING" },
    data: { status: "PAUSED" },
  });
  if (count > 0) {
    console.log(`Migration engine: found ${count} import batch(es) stuck in PROCESSING from a previous run - flagged PAUSED, awaiting explicit Resume.`);
  }
}

reconcileStaleMigrations()
  .catch((err) => {
    console.error("Migration engine: startup reconciliation failed - continuing to start the server anyway.", err);
  })
  .finally(() => {
    app.listen(PORT, () => {
      console.log(`UAE VAT SaaS API (Module 0) listening on port ${PORT}`);
    });
  });
