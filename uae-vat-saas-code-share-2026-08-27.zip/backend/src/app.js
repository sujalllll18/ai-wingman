require("dotenv").config();
require("express-async-errors"); // lets async controller errors reach the error handler below

const path = require("path");
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");

const platformAdminRoutes = require("./routes/platformAdmin.routes");
const tenantRoutes = require("./routes/tenant.routes");
const customerRoutes = require("./routes/customer.routes");
const materialRoutes = require("./routes/material.routes");
const taxRoutes = require("./routes/tax.routes");
const invoiceRoutes = require("./routes/invoice.routes");
const vendorRoutes = require("./routes/vendor.routes");
const purchaseRoutes = require("./routes/purchase.routes");
const vatReturnRoutes = require("./routes/vatReturn.routes");
const roleRoutes = require("./routes/role.routes");
const approvalRoutes = require("./routes/approval.routes");
const ticketRoutes = require("./routes/ticket.routes");
const creditNoteRoutes = require("./routes/creditNote.routes");
const debitNoteRoutes = require("./routes/debitNote.routes");
const salesDebitNoteRoutes = require("./routes/salesDebitNote.routes");
const importRoutes = require("./routes/import.routes");
const migrationRoutes = require("./routes/migration.routes");
const businessProfileRoutes = require("./routes/businessProfile.routes");
const paymentRoutes = require("./routes/payment.routes");
const purchasePaymentRoutes = require("./routes/purchasePayment.routes");
const bankAccountRoutes = require("./routes/bankAccount.routes");
const bankTransactionRoutes = require("./routes/bankTransaction.routes");
const reconciliationRoutes = require("./routes/reconciliation.routes");
const ApiError = require("./utils/ApiError");

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Serves uploaded purchase-bill source documents/attachments (see
// purchase.routes.js's multer disk storage) - plain static files, no auth
// gate, matching the fact that the URL itself (a random uuid filename) is
// already unguessable; not used for anything else in the app.
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/platform-admin", platformAdminRoutes);
app.use("/api/tenant", tenantRoutes);
app.use("/api/tenant/customers", customerRoutes);
app.use("/api/tenant/materials", materialRoutes);
app.use("/api/tenant/tax", taxRoutes);
app.use("/api/tenant/invoices", invoiceRoutes);
app.use("/api/tenant/vendors", vendorRoutes);
app.use("/api/tenant/purchases", purchaseRoutes);
app.use("/api/tenant/vat-returns", vatReturnRoutes);
app.use("/api/tenant/roles", roleRoutes);
app.use("/api/tenant", approvalRoutes);
app.use("/api/tenant/tickets", ticketRoutes);
app.use("/api/tenant/credit-notes", creditNoteRoutes);
app.use("/api/tenant/debit-notes", debitNoteRoutes);
app.use("/api/tenant/sales-debit-notes", salesDebitNoteRoutes);
app.use("/api/tenant/imports", importRoutes);
app.use("/api/tenant/migrations", migrationRoutes);
app.use("/api/tenant/business-profile", businessProfileRoutes);
app.use("/api/tenant/payments", paymentRoutes);
app.use("/api/tenant/purchase-payments", purchasePaymentRoutes);
app.use("/api/tenant/banking/accounts", bankAccountRoutes);
app.use("/api/tenant/banking/transactions", bankTransactionRoutes);
app.use("/api/tenant/reconciliation", reconciliationRoutes);

// 404 for anything unmatched
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Centralized error handler - every controller throws ApiError (or lets
// unexpected errors bubble up) instead of handling responses inline.
app.use((err, req, res, next) => {
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({ error: err.message });
  }

  // Prisma unique-constraint violations etc. land here if not pre-checked.
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

module.exports = app;
