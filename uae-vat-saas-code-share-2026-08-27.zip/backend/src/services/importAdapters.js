// Registry of "how do I validate/commit one row of this import type",
// keyed by importType (e.g. "SALES_INVOICE", "PURCHASE_BILL"). Mirrors
// approvalExecutors.js's registerExecutor/getExecutor shape deliberately -
// this is the ONLY per-entity-type code the Import Framework requires;
// everything else (file parsing, column mapping, batch/record bookkeeping,
// the commit transaction loop) lives once in importEngine.service.js.
//
// Every adapter's commitRow() calls the SAME creation helpers manual entry
// and OCR already use (createInvoiceTx-equivalent via
// invoice.controller.js's exports, createPurchaseBillTx/recordPurchaseTx via
// purchase.controller.js's exports) - an imported row is never written by a
// separate/parallel code path, per the Import Framework's own "must become
// REAL Ledger transactions" requirement.
const prisma = require("../config/prisma");
const { round2 } = require("./invoiceCalc");

const ADAPTERS = {};
function registerAdapter(importType, adapter) {
  ADAPTERS[importType] = adapter;
}
function getAdapter(importType) {
  return ADAPTERS[importType];
}
function listAdapters() {
  return Object.entries(ADAPTERS).map(([importType, a]) => ({ importType, label: a.label, templateFields: a.templateFields }));
}

const TRN_RE = /^\d{15}$/;

function parseDate(value) {
  if (value === undefined || value === null || value === "") return null;
  // Excel serial dates arrive as numbers when a cell was formatted as a
  // date - xlsx's own sheet_to_json(raw:false) already stringifies these
  // for us (see importEngine.service.js), so a plain Date parse is enough
  // here; kept as a small helper so both adapters stay consistent.
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}
function parseNumber(value) {
  if (value === undefined || value === null || value === "") return null;
  const n = Number(String(value).replace(/,/g, "").trim());
  return Number.isNaN(n) ? null : n;
}
function sameDay(a, b) {
  if (!a || !b) return false;
  return new Date(a).toDateString() === new Date(b).toDateString();
}

// ---------------------------------------------------------------------------
// Sales Invoice
// ---------------------------------------------------------------------------
registerAdapter("SALES_INVOICE", {
  label: "Sales Invoices",
  templateFields: [
    { key: "invoiceDate", label: "Invoice Date", required: true, type: "date" },
    { key: "customerName", label: "Customer", required: true, type: "text" },
    { key: "customerTrn", label: "Customer TRN", required: false, type: "text" },
    { key: "description", label: "Description", required: false, type: "text" },
    { key: "quantity", label: "Quantity", required: false, type: "number" },
    { key: "taxableAmount", label: "Taxable Amount", required: true, type: "number" },
    { key: "vatRate", label: "VAT Rate (%)", required: true, type: "number" },
    { key: "vatAmount", label: "VAT Amount", required: false, type: "number" },
    { key: "totalAmount", label: "Total Amount", required: false, type: "number" },
    // Optional (2026-08-22, Migration financial-reconciliation) - a header-
    // level fixed discount, folded straight into Invoice.discountType/
    // discountValue (the same fields a manually-created invoice uses) so
    // recomputeAndPersist() applies it identically. Before this field
    // existed, every imported invoice's discount was implicitly zero.
    { key: "discountAmount", label: "Discount Amount", required: false, type: "number" },
    { key: "currency", label: "Currency", required: false, type: "text" },
    { key: "dueDate", label: "Due Date", required: false, type: "date" },
    { key: "notes", label: "Notes", required: false, type: "text" },
    // Not a real Ledger column (see docs comment on the Invoice model's
    // source/importBatchId fields) - Ledger assigns its own sequential
    // INV-###### the same way every other Sent invoice gets one, so
    // FTA-relevant numbering stays gapless and means "issued through
    // Ledger." The original document's own number is preserved as a plain
    // reference note on the invoice (and verbatim in the batch's raw row
    // data), never as a second numbering scheme.
    { key: "originalInvoiceNumber", label: "Original Invoice Number (reference only)", required: false, type: "text" },
  ],

  dedupeKey(normalized) {
    if (!normalized.customerName || !normalized.invoiceDate || normalized.taxableAmount === null) return null;
    return `${normalized.customerName.toLowerCase()}|${new Date(normalized.invoiceDate).toDateString()}|${normalized.taxableAmount}`;
  },

  // Optional - short human-readable label for a failed-records report/UI.
  // Falls back to "Row {n}" in the engine if omitted.
  identify(normalized) {
    const date = normalized.invoiceDate ? new Date(normalized.invoiceDate).toISOString().slice(0, 10) : "no date";
    const amount = normalized.taxableAmount !== null && normalized.taxableAmount !== undefined ? normalized.taxableAmount.toFixed(2) : "?";
    return `${normalized.customerName || "Unknown customer"} — ${date} — ${amount}`;
  },

  async buildContext(tenantId) {
    const [taxCategories, existingInvoices, customers] = await Promise.all([
      prisma.taxCategory.findMany({ where: { tenantId }, include: { taxRate: true } }),
      prisma.invoice.findMany({
        where: { tenantId, status: { not: "VOID" } },
        select: { invoiceNumberDisplay: true, customerName: true, customerTrn: true, issueDate: true, grandTotal: true },
      }),
      prisma.customer.findMany({ where: { tenantId } }),
    ]);
    return { taxCategories, existingInvoices, customers };
  },

  validateRow(row, ctx) {
    const errors = [];

    const invoiceDate = parseDate(row.invoiceDate);
    if (!row.invoiceDate) errors.push({ field: "invoiceDate", message: "Invoice Date is required" });
    else if (!invoiceDate) errors.push({ field: "invoiceDate", message: `Invalid Invoice Date: "${row.invoiceDate}"` });

    const customerName = row.customerName?.trim();
    if (!customerName) errors.push({ field: "customerName", message: "Customer is required" });

    const customerTrn = row.customerTrn?.toString().trim() || null;
    if (customerTrn && !TRN_RE.test(customerTrn)) errors.push({ field: "customerTrn", message: "Customer TRN must be exactly 15 digits" });

    const taxableAmount = parseNumber(row.taxableAmount);
    if (taxableAmount === null) errors.push({ field: "taxableAmount", message: "Taxable Amount is required and must be numeric" });
    else if (taxableAmount < 0) errors.push({ field: "taxableAmount", message: "Taxable Amount cannot be negative" });

    const vatRate = parseNumber(row.vatRate);
    if (row.vatRate === undefined || row.vatRate === null || row.vatRate === "") errors.push({ field: "vatRate", message: "VAT Rate is required" });

    let matchedCategory = null;
    if (vatRate !== null) {
      matchedCategory = ctx.taxCategories.find((c) => c.status === "ACTIVE" && c.taxRate && Math.abs(c.taxRate.percentage - vatRate) < 0.001);
      if (!matchedCategory) errors.push({ field: "vatRate", message: `No active Tax Category resolves to ${vatRate}% VAT - check Tax Master` });
    }

    const vatAmountStated = parseNumber(row.vatAmount);
    const totalStated = parseNumber(row.totalAmount);
    if (taxableAmount !== null && vatRate !== null) {
      const expectedVat = round2((taxableAmount * vatRate) / 100);
      const expectedTotal = round2(taxableAmount + expectedVat);
      if (vatAmountStated !== null && Math.abs(vatAmountStated - expectedVat) > 0.05) {
        errors.push({ field: "vatAmount", message: `VAT calculation mismatch: file says ${vatAmountStated}, Ledger computes ${expectedVat}` });
      }
      if (totalStated !== null && Math.abs(totalStated - expectedTotal) > 0.05) {
        errors.push({ field: "totalAmount", message: `Total Amount mismatch: file says ${totalStated}, Ledger computes ${expectedTotal}` });
      }
    }

    const duplicate =
      customerName && invoiceDate && taxableAmount !== null
        ? ctx.existingInvoices.find(
            (inv) =>
              inv.customerName?.toLowerCase() === customerName.toLowerCase() &&
              sameDay(inv.issueDate, invoiceDate) &&
              Math.abs(inv.grandTotal - (totalStated ?? taxableAmount)) < 0.05
          )
        : null;
    if (duplicate) {
      // WARNING, not ERROR (2026-08-22, Migration Preview hardening) - a
      // possible duplicate is a judgment call the importing user may
      // deliberately want to override (e.g. two genuinely separate
      // invoices that happen to match on customer/date/amount), so it must
      // never silently block the row from being imported the way a real
      // data error does. See the "Duplicates" bucket in the Migration
      // Review screen - this is exactly what populates it.
      errors.push({ field: "duplicate", severity: "WARNING", message: `Possible duplicate of an existing invoice (${duplicate.invoiceNumberDisplay || "a Draft"}) - same customer, date and amount` });
    }

    let matchedCustomer = null;
    if (customerTrn) matchedCustomer = ctx.customers.find((c) => c.trn === customerTrn);
    if (!matchedCustomer && customerName) matchedCustomer = ctx.customers.find((c) => c.name.toLowerCase() === customerName.toLowerCase());

    const quantity = parseNumber(row.quantity) || 1;
    const discountAmount = parseNumber(row.discountAmount) || 0;

    const normalized = {
      invoiceDate,
      customerName,
      customerTrn,
      customerId: matchedCustomer?.id || null,
      description: row.description?.trim() || "Imported sale",
      quantity,
      taxableAmount,
      discountAmount,
      taxCategoryId: matchedCategory?.id || null,
      vatPercentage: matchedCategory?.taxRate?.percentage ?? null,
      currency: row.currency?.trim() || "AED",
      dueDate: parseDate(row.dueDate),
      notes: row.notes?.trim() || null,
      originalInvoiceNumber: row.originalInvoiceNumber?.toString().trim() || null,
    };

    return { normalized, errors };
  },

  // Optional (2026-08-22, Migration financial-reconciliation) - sums the
  // already-normalized rows a Migration Preview is about to import into one
  // Subtotal/Discount/Taxable/VAT/Grand Total block. Deliberately mirrors
  // calculateInvoiceTotals()'s own per-line discount-before-VAT math
  // (src/services/invoiceCalc.js) at the batch level, using each row's own
  // vatPercentage (resolved once already in validateRow, not re-derived
  // here) so the reconciliation total matches exactly what will actually be
  // committed, not an approximation. Only called with rows that are
  // actually VALID (will be imported); INVALID/skipped rows never
  // contribute to this reconciliation.
  summarizeFinancials(rows) {
    let subtotal = 0;
    let discountTotal = 0;
    let vatTotal = 0;
    for (const { normalized } of rows) {
      const lineSubtotal = normalized.taxableAmount || 0;
      const lineDiscount = Math.min(normalized.discountAmount || 0, lineSubtotal);
      const lineTaxable = round2(lineSubtotal - lineDiscount);
      subtotal += lineSubtotal;
      discountTotal += lineDiscount;
      vatTotal += round2((lineTaxable * (normalized.vatPercentage || 0)) / 100);
    }
    const taxableAmount = round2(subtotal - discountTotal);
    return {
      subtotal: round2(subtotal),
      discountTotal: round2(discountTotal),
      taxableAmount,
      vatTotal: round2(vatTotal),
      grandTotal: round2(taxableAmount + vatTotal),
    };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch) {
    const { resolveLineItemSnapshot, recomputeAndPersist, logActivity, sendInvoiceTx } = require("../controllers/invoice.controller");

    const unitPrice = normalized.quantity ? round2(normalized.taxableAmount / normalized.quantity) : normalized.taxableAmount;
    const lineSnapshot = await resolveLineItemSnapshot(
      tenantId,
      { description: normalized.description, unit: "unit", unitPrice, quantity: normalized.quantity, taxCategoryId: normalized.taxCategoryId, sortOrder: 0 },
      normalized.invoiceDate
    );

    const notesParts = [];
    if (normalized.originalInvoiceNumber) notesParts.push(`Original invoice #: ${normalized.originalInvoiceNumber}`);
    if (normalized.notes) notesParts.push(normalized.notes);

    const created = await tx.invoice.create({
      data: {
        tenantId,
        businessName: tenant.name,
        businessAddress: tenant.address || null,
        businessTrn: tenant.trn || null,
        businessContactEmail: tenant.contactEmail || null,
        businessContactPhone: tenant.contactPhone || null,
        customerId: normalized.customerId,
        customerName: normalized.customerName,
        customerTrn: normalized.customerTrn,
        issueDate: normalized.invoiceDate,
        dueDate: normalized.dueDate,
        currency: normalized.currency,
        discountType: normalized.discountAmount > 0 ? "FIXED" : null,
        discountValue: normalized.discountAmount || 0,
        notes: notesParts.join(" | ") || null,
        source: "IMPORT",
        importBatchId: batch.id,
        lineItems: { create: [lineSnapshot] },
      },
    });
    await logActivity(tx, created.id, "CREATED", `Imported - batch ${batch.batchNumber}`);
    await recomputeAndPersist(tx, created.id);
    const sent = await sendInvoiceTx(tx, tenantId, created.id);

    return { entityType: "Invoice", entityId: sent.id };
  },
});

// ---------------------------------------------------------------------------
// Purchase Bill
// ---------------------------------------------------------------------------
registerAdapter("PURCHASE_BILL", {
  label: "Purchase Bills",
  templateFields: [
    { key: "purchaseDate", label: "Purchase Date", required: true, type: "date" },
    { key: "vendorName", label: "Vendor", required: true, type: "text" },
    { key: "vendorTrn", label: "Vendor TRN", required: false, type: "text" },
    { key: "supplierInvoiceNumber", label: "Supplier Invoice Number", required: false, type: "text" },
    { key: "description", label: "Description", required: false, type: "text" },
    { key: "taxableAmount", label: "Taxable Amount", required: true, type: "number" },
    { key: "vatRate", label: "VAT Rate (%)", required: true, type: "number" },
    { key: "vatAmount", label: "VAT Amount", required: false, type: "number" },
    { key: "totalAmount", label: "Total Amount", required: false, type: "number" },
    { key: "currency", label: "Currency", required: false, type: "text" },
    { key: "notes", label: "Notes", required: false, type: "text" },
  ],

  dedupeKey(normalized) {
    if (normalized.supplierInvoiceNumber) return `${(normalized.vendorTrn || normalized.vendorName || "").toLowerCase()}|${normalized.supplierInvoiceNumber.toLowerCase()}`;
    if (!normalized.vendorName || !normalized.purchaseDate || normalized.taxableAmount === null) return null;
    return `${normalized.vendorName.toLowerCase()}|${new Date(normalized.purchaseDate).toDateString()}|${normalized.taxableAmount}`;
  },

  // Optional - see SALES_INVOICE.identify() above for what this is for.
  identify(normalized) {
    const date = normalized.purchaseDate ? new Date(normalized.purchaseDate).toISOString().slice(0, 10) : "no date";
    const amount = normalized.taxableAmount !== null && normalized.taxableAmount !== undefined ? normalized.taxableAmount.toFixed(2) : "?";
    return `${normalized.vendorName || "Unknown vendor"} — ${date} — ${amount}`;
  },

  async buildContext(tenantId) {
    const [taxCategories, existingBills, vendors] = await Promise.all([
      prisma.taxCategory.findMany({ where: { tenantId }, include: { taxRate: true } }),
      prisma.purchaseBill.findMany({
        where: { tenantId, status: { not: "VOID" } },
        select: { billNumberDisplay: true, vendorName: true, vendorTrn: true, supplierInvoiceNumber: true, purchaseDate: true, grandTotal: true },
      }),
      prisma.vendor.findMany({ where: { tenantId } }),
    ]);
    return { taxCategories, existingBills, vendors };
  },

  validateRow(row, ctx) {
    const errors = [];

    const purchaseDate = parseDate(row.purchaseDate);
    if (!row.purchaseDate) errors.push({ field: "purchaseDate", message: "Purchase Date is required" });
    else if (!purchaseDate) errors.push({ field: "purchaseDate", message: `Invalid Purchase Date: "${row.purchaseDate}"` });

    const vendorName = row.vendorName?.trim();
    if (!vendorName) errors.push({ field: "vendorName", message: "Vendor is required" });

    const vendorTrn = row.vendorTrn?.toString().trim() || null;
    if (vendorTrn && !TRN_RE.test(vendorTrn)) errors.push({ field: "vendorTrn", message: "Vendor TRN must be exactly 15 digits" });

    const supplierInvoiceNumber = row.supplierInvoiceNumber?.toString().trim() || null;

    const taxableAmount = parseNumber(row.taxableAmount);
    if (taxableAmount === null) errors.push({ field: "taxableAmount", message: "Taxable Amount is required and must be numeric" });
    else if (taxableAmount < 0) errors.push({ field: "taxableAmount", message: "Taxable Amount cannot be negative" });

    const vatRate = parseNumber(row.vatRate);
    if (row.vatRate === undefined || row.vatRate === null || row.vatRate === "") errors.push({ field: "vatRate", message: "VAT Rate is required" });

    let matchedCategory = null;
    if (vatRate !== null) {
      matchedCategory = ctx.taxCategories.find((c) => c.status === "ACTIVE" && c.taxRate && Math.abs(c.taxRate.percentage - vatRate) < 0.001);
      if (!matchedCategory) errors.push({ field: "vatRate", message: `No active Tax Category resolves to ${vatRate}% VAT - check Tax Master` });
    }

    const vatAmountStated = parseNumber(row.vatAmount);
    const totalStated = parseNumber(row.totalAmount);
    if (taxableAmount !== null && vatRate !== null) {
      const expectedVat = round2((taxableAmount * vatRate) / 100);
      const expectedTotal = round2(taxableAmount + expectedVat);
      if (vatAmountStated !== null && Math.abs(vatAmountStated - expectedVat) > 0.05) {
        errors.push({ field: "vatAmount", message: `VAT calculation mismatch: file says ${vatAmountStated}, Ledger computes ${expectedVat}` });
      }
      if (totalStated !== null && Math.abs(totalStated - expectedTotal) > 0.05) {
        errors.push({ field: "totalAmount", message: `Total Amount mismatch: file says ${totalStated}, Ledger computes ${expectedTotal}` });
      }
    }

    let duplicate = null;
    if (supplierInvoiceNumber) {
      duplicate = ctx.existingBills.find(
        (b) => b.supplierInvoiceNumber && b.supplierInvoiceNumber.toLowerCase() === supplierInvoiceNumber.toLowerCase() && (b.vendorTrn === vendorTrn || b.vendorName?.toLowerCase() === vendorName?.toLowerCase())
      );
    } else if (vendorName && purchaseDate && taxableAmount !== null) {
      duplicate = ctx.existingBills.find(
        (b) => b.vendorName?.toLowerCase() === vendorName.toLowerCase() && sameDay(b.purchaseDate, purchaseDate) && Math.abs(b.grandTotal - (totalStated ?? taxableAmount)) < 0.05
      );
    }
    if (duplicate) {
      // WARNING, not ERROR - see the identical reasoning on SALES_INVOICE's
      // duplicate check above.
      errors.push({ field: "duplicate", severity: "WARNING", message: `Possible duplicate of an existing purchase bill (${duplicate.billNumberDisplay || "a Draft"})` });
    }

    const normalized = {
      purchaseDate,
      vendorName,
      vendorTrn,
      supplierInvoiceNumber,
      description: row.description?.trim() || "Imported purchase",
      taxableAmount,
      taxCategoryId: matchedCategory?.id || null,
      vatPercentage: matchedCategory?.taxRate?.percentage ?? null,
      currency: row.currency?.trim() || "AED",
      notes: row.notes?.trim() || null,
    };

    return { normalized, errors };
  },

  // Optional (2026-08-22, Migration financial-reconciliation) - same shape
  // and reasoning as SALES_INVOICE.summarizeFinancials above; Purchase
  // Bills have no discount field today, so discountTotal is always 0 here.
  summarizeFinancials(rows) {
    let subtotal = 0;
    let vatTotal = 0;
    for (const { normalized } of rows) {
      const lineTaxable = normalized.taxableAmount || 0;
      subtotal += lineTaxable;
      vatTotal += round2((lineTaxable * (normalized.vatPercentage || 0)) / 100);
    }
    return {
      subtotal: round2(subtotal),
      discountTotal: 0,
      taxableAmount: round2(subtotal),
      vatTotal: round2(vatTotal),
      grandTotal: round2(subtotal + vatTotal),
    };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch) {
    const { createPurchaseBillTx, recordPurchaseTx } = require("../controllers/purchase.controller");

    const created = await createPurchaseBillTx(tx, tenantId, {
      vendorName: normalized.vendorName,
      vendorTrn: normalized.vendorTrn,
      supplierInvoiceNumber: normalized.supplierInvoiceNumber,
      invoiceDate: normalized.purchaseDate,
      purchaseDate: normalized.purchaseDate,
      currency: normalized.currency,
      notes: normalized.notes,
      lineItems: [{ description: normalized.description, quantity: 1, unitPrice: normalized.taxableAmount, taxCategoryId: normalized.taxCategoryId }],
      sourceType: "IMPORT",
      importBatchId: batch.id,
    });
    const recorded = await recordPurchaseTx(tx, tenantId, created.id);

    return { entityType: "PurchaseBill", entityId: recorded.id };
  },
});

// ---------------------------------------------------------------------------
// Customer (2026-08-22, first Migration-lifecycle adapter beyond the
// original two) - deliberately the simplest possible adapter: no tax, no
// line items, no Ledger-assigned numbering, no summarizeFinancials (a
// Customer import has no money fields at all, so its Migration Review card
// simply has no financial-reconciliation section - the engine's
// summarizeFinancials hook is entirely optional per-adapter, confirmed by
// SALES_INVOICE/PURCHASE_BILL both defining it and this one omitting it).
// ---------------------------------------------------------------------------
registerAdapter("CUSTOMER", {
  label: "Customers",
  templateFields: [
    { key: "name", label: "Customer Name", required: true, type: "text" },
    { key: "trn", label: "TRN", required: false, type: "text" },
    { key: "address", label: "Address", required: false, type: "text" },
    { key: "customerType", label: "Customer Type (Business/Individual)", required: false, type: "text" },
  ],

  dedupeKey(normalized) {
    if (normalized.trn) return `trn|${normalized.trn}`;
    if (!normalized.name) return null;
    return `name|${normalized.name.toLowerCase()}`;
  },

  identify(normalized) {
    return normalized.trn ? `${normalized.name} (${normalized.trn})` : normalized.name || "Unnamed customer";
  },

  async buildContext(tenantId) {
    const existingCustomers = await prisma.customer.findMany({
      where: { tenantId },
      select: { id: true, name: true, trn: true },
    });
    return { existingCustomers };
  },

  validateRow(row, ctx) {
    const errors = [];

    const name = row.name?.trim();
    if (!name) errors.push({ field: "name", message: "Customer Name is required" });

    const trn = row.trn?.toString().trim() || null;
    if (trn && !TRN_RE.test(trn)) {
      // WARNING, not ERROR - a customer master import is lower-stakes than
      // a financial transaction; a malformed TRN shouldn't block bringing
      // the customer record in, just flag it for the tenant to fix later
      // (unlike Invoice/Purchase, where a bad counterparty TRN on a real
      // VAT document is treated as a hard error).
      errors.push({ field: "trn", severity: "WARNING", message: "TRN should be exactly 15 digits - check this value" });
    }

    const rawType = row.customerType?.toString().trim().toUpperCase();
    const customerType = rawType === "INDIVIDUAL" ? "INDIVIDUAL" : "BUSINESS"; // defaults silently, matches the Customer model's own default

    const duplicate = trn
      ? ctx.existingCustomers.find((c) => c.trn === trn)
      : name
      ? ctx.existingCustomers.find((c) => c.name.toLowerCase() === name.toLowerCase())
      : null;
    if (duplicate) {
      errors.push({ field: "duplicate", severity: "WARNING", message: `Possible duplicate of an existing customer (${duplicate.name})` });
    }

    const normalized = {
      name,
      trn,
      address: row.address?.trim() || null,
      customerType,
    };

    return { normalized, errors };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch) {
    const created = await tx.customer.create({
      data: {
        tenantId,
        name: normalized.name,
        trn: normalized.trn,
        address: normalized.address,
        customerType: normalized.customerType,
        status: "ACTIVE",
        source: "IMPORT",
        importBatchId: batch.id,
      },
    });
    return { entityType: "Customer", entityId: created.id };
  },
});

const VALID_PAYMENT_METHODS = ["CASH", "BANK_TRANSFER", "CARD", "CHEQUE", "OTHER"];

// ---------------------------------------------------------------------------
// Payment (Phase 2 Payments module, 2026-08-22) - lets the Migration Engine
// bring in historical customer receipts. Deliberately honest about what
// import data usually looks like: an old system's payment history rarely
// carries a reliable link to Ledger's own INV-###### numbering (even an
// imported SALES_INVOICE only keeps its original number as a free-text note,
// per that adapter's own comment above - there's no structured cross-system
// key to join on). So invoiceNumber here is optional and best-effort: if it
// resolves to a real Sent invoice on this tenant, the payment is imported
// pre-allocated to it; if it's missing or doesn't match anything, the row
// still imports successfully as a fully unallocated payment (a first-class,
// explicitly supported state - see PaymentAllocation's schema comment) -
// never a hard failure just because the historical link can't be proven.
// ---------------------------------------------------------------------------
registerAdapter("PAYMENT", {
  label: "Customer Payments",
  templateFields: [
    { key: "paymentDate", label: "Payment Date", required: true, type: "date" },
    { key: "customerName", label: "Customer", required: true, type: "text" },
    { key: "customerTrn", label: "Customer TRN", required: false, type: "text" },
    { key: "amount", label: "Amount", required: true, type: "number" },
    { key: "currency", label: "Currency", required: false, type: "text" },
    { key: "method", label: "Payment Method", required: false, type: "text" },
    { key: "reference", label: "Reference Number", required: false, type: "text" },
    // Best-effort only - see comment above. Must be Ledger's own INV-######
    // (only meaningful if the invoice itself was already imported/created in
    // Ledger), not the original system's own document number.
    { key: "invoiceNumber", label: "Ledger Invoice Number (optional, e.g. INV-000012)", required: false, type: "text" },
    { key: "notes", label: "Notes", required: false, type: "text" },
  ],

  dedupeKey(normalized) {
    if (!normalized.customerName || !normalized.paymentDate || normalized.amount === null) return null;
    return `${normalized.customerName.toLowerCase()}|${new Date(normalized.paymentDate).toDateString()}|${normalized.amount}|${normalized.reference || ""}`;
  },

  identify(normalized) {
    const date = normalized.paymentDate ? new Date(normalized.paymentDate).toISOString().slice(0, 10) : "no date";
    const amount = normalized.amount !== null && normalized.amount !== undefined ? normalized.amount.toFixed(2) : "?";
    return `${normalized.customerName || "Unknown customer"} — ${date} — ${amount}`;
  },

  async buildContext(tenantId) {
    const [customers, invoices, existingPayments] = await Promise.all([
      prisma.customer.findMany({ where: { tenantId }, select: { id: true, name: true, trn: true } }),
      prisma.invoice.findMany({ where: { tenantId, status: "SENT" }, select: { id: true, invoiceNumberDisplay: true } }),
      prisma.payment.findMany({ where: { tenantId }, select: { customerName: true, paymentDate: true, amount: true, reference: true } }),
    ]);
    return { customers, invoices, existingPayments };
  },

  validateRow(row, ctx) {
    const errors = [];

    const paymentDate = parseDate(row.paymentDate);
    if (!row.paymentDate) errors.push({ field: "paymentDate", message: "Payment Date is required" });
    else if (!paymentDate) errors.push({ field: "paymentDate", message: `Invalid Payment Date: "${row.paymentDate}"` });

    const customerName = row.customerName?.trim();
    if (!customerName) errors.push({ field: "customerName", message: "Customer is required" });

    const customerTrn = row.customerTrn?.toString().trim() || null;
    if (customerTrn && !TRN_RE.test(customerTrn)) {
      errors.push({ field: "customerTrn", severity: "WARNING", message: "TRN should be exactly 15 digits - check this value" });
    }

    const amount = parseNumber(row.amount);
    if (amount === null) errors.push({ field: "amount", message: "Amount is required and must be numeric" });
    else if (amount <= 0) errors.push({ field: "amount", message: "Amount must be greater than zero" });

    const rawMethod = row.method?.toString().trim().toUpperCase().replace(/\s+/g, "_");
    const method = VALID_PAYMENT_METHODS.includes(rawMethod) ? rawMethod : "OTHER";
    if (row.method && !VALID_PAYMENT_METHODS.includes(rawMethod)) {
      errors.push({ field: "method", severity: "WARNING", message: `"${row.method}" is not a recognized payment method - imported as OTHER` });
    }

    let matchedCustomer = null;
    if (customerTrn) matchedCustomer = ctx.customers.find((c) => c.trn === customerTrn);
    if (!matchedCustomer && customerName) matchedCustomer = ctx.customers.find((c) => c.name.toLowerCase() === customerName.toLowerCase());

    const invoiceNumberRaw = row.invoiceNumber?.toString().trim() || null;
    let matchedInvoice = null;
    if (invoiceNumberRaw) {
      matchedInvoice = ctx.invoices.find((inv) => inv.invoiceNumberDisplay?.toLowerCase() === invoiceNumberRaw.toLowerCase());
      if (!matchedInvoice) {
        errors.push({ field: "invoiceNumber", severity: "WARNING", message: `"${invoiceNumberRaw}" does not match a Sent invoice on this tenant - will be imported as an unallocated payment` });
      }
    }

    const duplicate =
      customerName && paymentDate && amount !== null
        ? ctx.existingPayments.find((p) => p.customerName?.toLowerCase() === customerName.toLowerCase() && sameDay(p.paymentDate, paymentDate) && Math.abs(p.amount - amount) < 0.05)
        : null;
    if (duplicate) {
      errors.push({ field: "duplicate", severity: "WARNING", message: "Possible duplicate of an existing payment - same customer, date and amount" });
    }

    const normalized = {
      paymentDate,
      customerName,
      customerTrn,
      customerId: matchedCustomer?.id || null,
      amount,
      currency: row.currency?.trim() || "AED",
      method,
      reference: row.reference?.toString().trim() || null,
      invoiceId: matchedInvoice?.id || null,
      notes: row.notes?.trim() || null,
    };

    return { normalized, errors };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch) {
    const { recalculatePaymentFields, logActivity } = require("../controllers/invoice.controller");

    const paymentTenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextPaymentNumber: { increment: 1 } } });
    const assignedNumber = paymentTenant.nextPaymentNumber - 1;
    const display = `PAY-${String(assignedNumber).padStart(6, "0")}`;

    const created = await tx.payment.create({
      data: {
        tenantId,
        customerId: normalized.customerId,
        customerName: normalized.customerName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        amount: normalized.amount,
        currency: normalized.currency,
        paymentDate: normalized.paymentDate,
        method: normalized.method,
        reference: normalized.reference,
        notes: normalized.notes,
        source: "IMPORT",
        importBatchId: batch.id,
      },
    });
    await tx.paymentActivity.create({ data: { paymentId: created.id, type: "IMPORTED", description: `Imported - batch ${batch.batchNumber}` } });

    if (normalized.invoiceId) {
      await tx.paymentAllocation.create({ data: { paymentId: created.id, invoiceId: normalized.invoiceId, allocatedAmount: normalized.amount } });
      await recalculatePaymentFields(tx, normalized.invoiceId);
      await logActivity(tx, normalized.invoiceId, "PAYMENT_RECORDED", `${normalized.currency} ${normalized.amount.toFixed(2)} via ${normalized.method} (${display}, imported)`);
    }

    return { entityType: "Payment", entityId: created.id };
  },
});

// ---------------------------------------------------------------------------
// PurchasePayment (Phase 2 Payments module, 2026-08-22) - supplier-side
// mirror of the PAYMENT adapter above, same honest best-effort bill-matching
// reasoning.
// ---------------------------------------------------------------------------
registerAdapter("PURCHASE_PAYMENT", {
  label: "Supplier Payments",
  templateFields: [
    { key: "paymentDate", label: "Payment Date", required: true, type: "date" },
    { key: "vendorName", label: "Supplier", required: true, type: "text" },
    { key: "vendorTrn", label: "Supplier TRN", required: false, type: "text" },
    { key: "amount", label: "Amount", required: true, type: "number" },
    { key: "currency", label: "Currency", required: false, type: "text" },
    { key: "method", label: "Payment Method", required: false, type: "text" },
    { key: "reference", label: "Reference Number", required: false, type: "text" },
    { key: "billNumber", label: "Ledger Purchase Bill Number (optional, e.g. PB-000012)", required: false, type: "text" },
    { key: "notes", label: "Notes", required: false, type: "text" },
  ],

  dedupeKey(normalized) {
    if (!normalized.vendorName || !normalized.paymentDate || normalized.amount === null) return null;
    return `${normalized.vendorName.toLowerCase()}|${new Date(normalized.paymentDate).toDateString()}|${normalized.amount}|${normalized.reference || ""}`;
  },

  identify(normalized) {
    const date = normalized.paymentDate ? new Date(normalized.paymentDate).toISOString().slice(0, 10) : "no date";
    const amount = normalized.amount !== null && normalized.amount !== undefined ? normalized.amount.toFixed(2) : "?";
    return `${normalized.vendorName || "Unknown supplier"} — ${date} — ${amount}`;
  },

  async buildContext(tenantId) {
    const [vendors, bills, existingPayments] = await Promise.all([
      prisma.vendor.findMany({ where: { tenantId }, select: { id: true, name: true, trn: true } }),
      prisma.purchaseBill.findMany({ where: { tenantId, status: "RECORDED" }, select: { id: true, billNumberDisplay: true } }),
      prisma.purchasePayment.findMany({ where: { tenantId }, select: { vendorName: true, paymentDate: true, amount: true, reference: true } }),
    ]);
    return { vendors, bills, existingPayments };
  },

  validateRow(row, ctx) {
    const errors = [];

    const paymentDate = parseDate(row.paymentDate);
    if (!row.paymentDate) errors.push({ field: "paymentDate", message: "Payment Date is required" });
    else if (!paymentDate) errors.push({ field: "paymentDate", message: `Invalid Payment Date: "${row.paymentDate}"` });

    const vendorName = row.vendorName?.trim();
    if (!vendorName) errors.push({ field: "vendorName", message: "Supplier is required" });

    const vendorTrn = row.vendorTrn?.toString().trim() || null;
    if (vendorTrn && !TRN_RE.test(vendorTrn)) {
      errors.push({ field: "vendorTrn", severity: "WARNING", message: "TRN should be exactly 15 digits - check this value" });
    }

    const amount = parseNumber(row.amount);
    if (amount === null) errors.push({ field: "amount", message: "Amount is required and must be numeric" });
    else if (amount <= 0) errors.push({ field: "amount", message: "Amount must be greater than zero" });

    const rawMethod = row.method?.toString().trim().toUpperCase().replace(/\s+/g, "_");
    const method = VALID_PAYMENT_METHODS.includes(rawMethod) ? rawMethod : "OTHER";
    if (row.method && !VALID_PAYMENT_METHODS.includes(rawMethod)) {
      errors.push({ field: "method", severity: "WARNING", message: `"${row.method}" is not a recognized payment method - imported as OTHER` });
    }

    let matchedVendor = null;
    if (vendorTrn) matchedVendor = ctx.vendors.find((v) => v.trn === vendorTrn);
    if (!matchedVendor && vendorName) matchedVendor = ctx.vendors.find((v) => v.name.toLowerCase() === vendorName.toLowerCase());

    const billNumberRaw = row.billNumber?.toString().trim() || null;
    let matchedBill = null;
    if (billNumberRaw) {
      matchedBill = ctx.bills.find((b) => b.billNumberDisplay?.toLowerCase() === billNumberRaw.toLowerCase());
      if (!matchedBill) {
        errors.push({ field: "billNumber", severity: "WARNING", message: `"${billNumberRaw}" does not match a Recorded purchase bill on this tenant - will be imported as an unallocated payment` });
      }
    }

    const duplicate =
      vendorName && paymentDate && amount !== null
        ? ctx.existingPayments.find((p) => p.vendorName?.toLowerCase() === vendorName.toLowerCase() && sameDay(p.paymentDate, paymentDate) && Math.abs(p.amount - amount) < 0.05)
        : null;
    if (duplicate) {
      errors.push({ field: "duplicate", severity: "WARNING", message: "Possible duplicate of an existing payment - same supplier, date and amount" });
    }

    const normalized = {
      paymentDate,
      vendorName,
      vendorTrn,
      vendorId: matchedVendor?.id || null,
      amount,
      currency: row.currency?.trim() || "AED",
      method,
      reference: row.reference?.toString().trim() || null,
      purchaseBillId: matchedBill?.id || null,
      notes: row.notes?.trim() || null,
    };

    return { normalized, errors };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch) {
    const { recalculatePaymentFields, logActivity } = require("../controllers/purchase.controller");

    const paymentTenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextPurchasePaymentNumber: { increment: 1 } } });
    const assignedNumber = paymentTenant.nextPurchasePaymentNumber - 1;
    const display = `SPAY-${String(assignedNumber).padStart(6, "0")}`;

    const created = await tx.purchasePayment.create({
      data: {
        tenantId,
        vendorId: normalized.vendorId,
        vendorName: normalized.vendorName,
        paymentNumber: assignedNumber,
        paymentNumberDisplay: display,
        amount: normalized.amount,
        currency: normalized.currency,
        paymentDate: normalized.paymentDate,
        method: normalized.method,
        reference: normalized.reference,
        notes: normalized.notes,
        source: "IMPORT",
        importBatchId: batch.id,
      },
    });
    await tx.purchasePaymentActivity.create({ data: { purchasePaymentId: created.id, type: "IMPORTED", description: `Imported - batch ${batch.batchNumber}` } });

    if (normalized.purchaseBillId) {
      await tx.purchasePaymentAllocation.create({ data: { purchasePaymentId: created.id, purchaseBillId: normalized.purchaseBillId, allocatedAmount: normalized.amount } });
      await recalculatePaymentFields(tx, normalized.purchaseBillId);
      await logActivity(tx, normalized.purchaseBillId, "PAYMENT_RECORDED", `${normalized.currency} ${normalized.amount.toFixed(2)} via ${normalized.method} (${display}, imported)`);
    }

    return { entityType: "PurchasePayment", entityId: created.id };
  },
});

// ---------------------------------------------------------------------------
// Bank Transaction (Phase 3 Banking module, 2026-08-22) - the Bank Statement
// Connector/Adapter the brief asked for. Normalizes any bank's own column
// layout into the standard BankTransaction shape (see schema.prisma's own
// comment on that model) and feeds it through the exact same, unmodified
// commit loop every other import type uses. batch.bankAccountId (set at
// upload time, see import.controller.js's createBatch) is how this adapter
// knows which BankAccount a given batch's rows belong to - read here via the
// `batch` object the engine already threads into every adapter call, not a
// new execution-path concept.
// ---------------------------------------------------------------------------
registerAdapter("BANK_TRANSACTION", {
  label: "Bank Transactions",
  templateFields: [
    { key: "transactionDate", label: "Transaction Date", required: true, type: "date" },
    { key: "valueDate", label: "Value Date", required: false, type: "date" },
    { key: "description", label: "Description / Narration", required: false, type: "text" },
    { key: "reference", label: "Reference Number", required: false, type: "text" },
    { key: "debit", label: "Debit", required: false, type: "number" },
    { key: "credit", label: "Credit", required: false, type: "number" },
    { key: "runningBalance", label: "Balance", required: false, type: "number" },
    { key: "transactionType", label: "Transaction Type", required: false, type: "text" },
    { key: "currency", label: "Currency", required: false, type: "text" },
  ],

  // Intra-batch (two rows in the SAME file describing the same line) -
  // cross-batch/cross-upload duplicate detection (the more important case
  // for "don't import the same statement twice") happens in validateRow
  // below via ctx.existingTransactions instead, since dedupeKey only ever
  // compares rows within one file.
  dedupeKey(normalized) {
    if (!normalized.transactionDate || normalized.amount === null) return null;
    return `${new Date(normalized.transactionDate).toDateString()}|${normalized.reference || ""}|${normalized.amount}`;
  },

  identify(normalized) {
    const date = normalized.transactionDate ? new Date(normalized.transactionDate).toISOString().slice(0, 10) : "no date";
    const amount = normalized.amount !== null && normalized.amount !== undefined ? normalized.amount.toFixed(2) : "?";
    return `${date} — ${normalized.description || "Bank transaction"} — ${amount}`;
  },

  async buildContext(tenantId, batch) {
    const bankAccount = await prisma.bankAccount.findFirst({ where: { id: batch.bankAccountId, tenantId } });
    if (!bankAccount) throw new Error("This import batch's bank account no longer exists");
    // Existing ACTIVE transactions on THIS account only - duplicate
    // detection is scoped per bank account, not tenant-wide (two different
    // accounts can legitimately share a reference/amount/date by coincidence).
    const existingTransactions = await prisma.bankTransaction.findMany({
      where: { tenantId, bankAccountId: bankAccount.id, status: "ACTIVE" },
      select: { transactionDate: true, reference: true, amount: true, description: true },
    });
    return { bankAccount, existingTransactions };
  },

  validateRow(row, ctx) {
    const errors = [];

    const transactionDate = parseDate(row.transactionDate);
    if (!row.transactionDate) errors.push({ field: "transactionDate", message: "Transaction Date is required" });
    else if (!transactionDate) errors.push({ field: "transactionDate", message: `Invalid Transaction Date: "${row.transactionDate}"` });

    const valueDate = parseDate(row.valueDate);

    const debit = parseNumber(row.debit) || 0;
    const credit = parseNumber(row.credit) || 0;
    if (debit < 0 || credit < 0) {
      errors.push({ field: "amount", message: "Debit/Credit cannot be negative" });
    } else if (debit > 0 && credit > 0) {
      // Explicit brief requirement: never silently correct financial data by
      // guessing which of the two the row "really meant."
      errors.push({ field: "amount", message: "Both Debit and Credit are populated on the same row - cannot determine transaction direction" });
    } else if (debit === 0 && credit === 0) {
      errors.push({ field: "amount", message: "Either Debit or Credit must have a value" });
    }
    const amount = round2(credit - debit);

    const runningBalance = row.runningBalance !== undefined && row.runningBalance !== "" ? parseNumber(row.runningBalance) : null;
    const description = row.description?.toString().trim() || null;
    const reference = row.reference?.toString().trim() || null;
    const transactionType = row.transactionType?.toString().trim() || null;
    const currency = row.currency?.toString().trim() || ctx.bankAccount.currency;

    // Cross-upload duplicate detection - the actual "don't import the same
    // statement twice" guard. EXACT match (same day, same amount, same
    // reference when both sides have one) is flagged distinctly from a
    // PARTIAL/possible match (same day and amount, but reference differs or
    // is missing on one side) - both are WARNING severity (never blocking),
    // same "judgment call for the importer" precedent every other adapter's
    // duplicate check already established.
    if (transactionDate && debit + credit > 0) {
      const sameDayAmount = ctx.existingTransactions.filter(
        (t) => sameDay(t.transactionDate, transactionDate) && Math.abs(t.amount - amount) < 0.005
      );
      if (sameDayAmount.length > 0) {
        const exact = reference && sameDayAmount.find((t) => t.reference && t.reference.toLowerCase() === reference.toLowerCase());
        if (exact) {
          // ERROR, not WARNING - deliberately stricter than every other
          // adapter's own "possible duplicate" check (which stays a WARNING
          // that still imports). Bank Statement Import has an explicit,
          // stronger requirement: re-uploading the same statement (or an
          // overlapping period) must never silently create a second real
          // BankTransaction row for money that was already recorded. An
          // ERROR-severity issue makes the row INVALID (never committed),
          // which is exactly "classify as DUPLICATE, don't import it."
          errors.push({ field: "duplicate", severity: "ERROR", message: "Duplicate of an existing bank transaction (same date, amount and reference) - not imported" });
        } else {
          // POSSIBLE DUPLICATE stays WARNING (still imported) - the
          // reference doesn't match or is missing on one side, so this is
          // a judgment call for the importer, not a certain duplicate.
          errors.push({ field: "duplicate", severity: "WARNING", message: "Possible duplicate of an existing bank transaction (date and amount match, reference differs or is missing)" });
        }
      }
    }

    const normalized = {
      transactionDate,
      valueDate,
      description,
      reference,
      debit: round2(debit),
      credit: round2(credit),
      amount,
      transactionType,
      currency,
      runningBalance,
    };

    return { normalized, errors };
  },

  // Batch-level totals only (brief §17's balance-consistency check itself)
  // - this hook's signature (rows only, no ctx) doesn't carry the
  // BankAccount's own openingBalance, so the actual
  // "opening + credits - debits = closing" comparison against
  // statementClosingBalance happens client-side in the Preview step, where
  // the bank account (fetched separately, needed for display anyway) is
  // already available. Never invents a balance the statement didn't provide
  // - statementClosingBalance stays null when no row had one.
  summarizeFinancials(rows) {
    let totalDebits = 0;
    let totalCredits = 0;
    let lastBalance = null;
    let lastDate = null;
    for (const { normalized } of rows) {
      totalDebits += normalized.debit || 0;
      totalCredits += normalized.credit || 0;
      if (normalized.runningBalance !== null && normalized.runningBalance !== undefined) {
        if (!lastDate || new Date(normalized.transactionDate) >= lastDate) {
          lastDate = new Date(normalized.transactionDate);
          lastBalance = normalized.runningBalance;
        }
      }
    }
    return {
      totalDebits: round2(totalDebits),
      totalCredits: round2(totalCredits),
      statementClosingBalance: lastBalance,
    };
  },

  async commitRow(tx, tenantId, tenant, normalized, batch, actorId, rowNumber) {
    const created = await tx.bankTransaction.create({
      data: {
        tenantId,
        bankAccountId: batch.bankAccountId,
        transactionDate: normalized.transactionDate,
        valueDate: normalized.valueDate,
        description: normalized.description,
        reference: normalized.reference,
        debit: normalized.debit,
        credit: normalized.credit,
        amount: normalized.amount,
        transactionType: normalized.transactionType,
        currency: normalized.currency,
        runningBalance: normalized.runningBalance,
        source: "IMPORT",
        sourceFileName: batch.sourceFileName,
        sourceRow: rowNumber ?? null,
        importBatchId: batch.id,
      },
    });
    return { entityType: "BankTransaction", entityId: created.id };
  },

  // Optional engine hook (see importEngine.service.js's two call sites) -
  // logs the account-level activity entries the brief's §22 asks for that
  // only make sense once the async migration run actually reaches a
  // terminal state (a synchronous controller call site can't know this in
  // advance, since commit just starts the run and returns immediately).
  async onBatchFinished(tenantId, batch) {
    if (!batch.bankAccountId) return;
    const label = { COMPLETED: "IMPORT_COMPLETED", COMPLETED_WITH_ERRORS: "IMPORT_COMPLETED", FAILED: "IMPORT_FAILED", CANCELLED: "IMPORT_FAILED" }[batch.status];
    if (!label) return;
    const description =
      batch.status === "FAILED"
        ? `${batch.batchNumber}: ${batch.lastError || "unexpected error"}`
        : `${batch.batchNumber}: ${batch.successCount} imported, ${batch.failedCount} failed`;
    await prisma.bankAccountActivity.create({ data: { bankAccountId: batch.bankAccountId, type: label, description } });
  },
});

module.exports = { registerAdapter, getAdapter, listAdapters };
