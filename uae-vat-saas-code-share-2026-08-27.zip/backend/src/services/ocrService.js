// Placeholder OCR extraction service. This is the ONLY file a real OCR
// provider (AWS Textract, Azure Form Recognizer, Google Document AI, a
// vision-capable LLM, etc.) needs to replace - purchase.controller.js only
// ever calls extractPurchaseData(file) and trusts its return shape. No real
// OCR is implemented here by design (see Purchase Module scope) - this
// returns plausible-looking canned data with a per-field confidence score,
// deliberately not derived from the actual file bytes.
//
// Contract every future provider must honor:
//   extractPurchaseData(file: { path, mimetype, originalname }) => Promise<{
//     vendor: { name: string, trn: string|null, confidence: number },
//     supplierInvoiceNumber: { value: string, confidence: number },
//     invoiceDate: { value: string (YYYY-MM-DD), confidence: number },
//     lineItems: [{ description, quantity, unitPrice, confidence }],
//     overallConfidence: number,
//   }>

const SAMPLE_VENDORS = [
  { name: "Al Futtaim Trading LLC", trn: "100234567800003" },
  { name: "Gulf Office Supplies FZE", trn: "100345678900003" },
  { name: "Sample Trading LLC", trn: null },
];

const SAMPLE_LINE_ITEMS = [
  [
    { description: "Office Stationery Supplies", quantity: 5, unitPrice: 45 },
    { description: "A4 Paper Ream (80gsm)", quantity: 10, unitPrice: 18 },
  ],
  [
    { description: "IT Support Services - Monthly", quantity: 1, unitPrice: 850 },
  ],
  [
    { description: "Printing & Signage Services", quantity: 2, unitPrice: 320 },
    { description: "Delivery Charges", quantity: 1, unitPrice: 50 },
  ],
];

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// Confidence is randomized around a plausible base per field type - real OCR
// naturally reads some fields (totals, dates) more reliably than others
// (handwritten notes, faint print), so this keeps the placeholder honest
// about that rather than returning a flat 100% everywhere.
function confidenceAround(base) {
  return Math.max(0.4, Math.min(0.99, round2(base + (Math.random() * 0.2 - 0.1))));
}

async function extractPurchaseData(file) {
  const vendor = SAMPLE_VENDORS[Math.floor(Math.random() * SAMPLE_VENDORS.length)];
  const lineItems = SAMPLE_LINE_ITEMS[Math.floor(Math.random() * SAMPLE_LINE_ITEMS.length)];
  const invoiceNumber = `SUP-${Math.floor(1000 + Math.random() * 9000)}`;

  const extraction = {
    vendor: { name: vendor.name, trn: vendor.trn, confidence: confidenceAround(0.9) },
    supplierInvoiceNumber: { value: invoiceNumber, confidence: confidenceAround(0.85) },
    invoiceDate: { value: new Date().toISOString().slice(0, 10), confidence: confidenceAround(0.82) },
    lineItems: lineItems.map((li) => ({ ...li, confidence: confidenceAround(0.75) })),
  };

  const allConfidences = [
    extraction.vendor.confidence,
    extraction.supplierInvoiceNumber.confidence,
    extraction.invoiceDate.confidence,
    ...extraction.lineItems.map((li) => li.confidence),
  ];
  extraction.overallConfidence = round2(allConfidences.reduce((s, c) => s + c, 0) / allConfidences.length);

  return extraction;
}

module.exports = { extractPurchaseData };
