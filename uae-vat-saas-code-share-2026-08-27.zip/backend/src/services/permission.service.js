const prisma = require("../config/prisma");

// Resolves a User's effective permission set: their primary UserRole -> Role
// -> RolePermission -> Permission.key. Called once inside requireTenantUser
// (same place tenant-suspension is already checked) and cached on
// req.tenantUser.permissions for the rest of the request - every module
// checks that same Set, nothing re-derives it. An inactive Role (status =
// INACTIVE) resolves to no permissions rather than throwing, so a
// deactivated role locks its holders out immediately without needing a
// separate revocation step.
async function getEffectivePermissions(userId) {
  const userRole = await prisma.userRole.findFirst({
    where: { userId, isPrimary: true },
    include: {
      role: {
        include: {
          rolePermissions: { include: { permission: { select: { key: true } } } },
        },
      },
    },
  });

  if (!userRole || userRole.role.status !== "ACTIVE") return new Set();

  return new Set(userRole.role.rolePermissions.map((rp) => rp.permission.key));
}

function hasPermission(req, key) {
  return req.tenantUser?.permissions?.has(key) === true;
}

module.exports = { getEffectivePermissions, hasPermission };
