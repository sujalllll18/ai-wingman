const prisma = require("../config/prisma");

// Internal-only service - deliberately not exposed as an HTTP route. Future
// modules (Invoice, Product, Purchase, Credit Note, VAT Return, Reports)
// import and call this directly from their own controllers instead of ever
// hardcoding a percentage.
//
// Resolves the tax rate that applies to a given category on a given date.
// The category's `taxRateId` identifies which named rate *family* it uses;
// the actual percentage/calculationMethod for that date is found by
// matching on name + effective window across all rows sharing that name -
// never by trusting the taxRateId row in isolation. This is what lets a new
// dated rate version take effect automatically without ever touching an
// existing invoice or the category record itself.
//
// Returns null if the category has no rate linked, or no rate version
// covers the given date - callers decide how to handle that (e.g. block
// invoice creation), this service never guesses a fallback percentage.
async function resolveTax(tenantId, categoryId, asOfDate = new Date()) {
  const category = await prisma.taxCategory.findFirst({
    where: { id: categoryId, tenantId },
    include: { taxRate: true },
  });
  if (!category || !category.taxRate) return null;

  const rate = await prisma.taxRate.findFirst({
    where: {
      tenantId,
      name: category.taxRate.name,
      status: "ACTIVE",
      effectiveFrom: { lte: asOfDate },
      OR: [{ effectiveTo: null }, { effectiveTo: { gte: asOfDate } }],
    },
    orderBy: { effectiveFrom: "desc" },
  });
  if (!rate) return null;

  return { percentage: rate.percentage, calculationMethod: rate.calculationMethod, taxRateId: rate.id, taxRateName: rate.name };
}

module.exports = { resolveTax };
