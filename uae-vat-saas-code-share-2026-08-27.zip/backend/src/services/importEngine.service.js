// The one centralized Import Framework engine - mirrors
// approvalEngine.service.js's shape deliberately (generic engine + a small
// per-entity-type registry in importAdapters.js is the ONLY module-specific
// code this feature needs). Owns: file parsing, column-mapping, validation,
// preview, and the migration (commit) engine. Never writes a ledger row
// itself - every real write happens inside an adapter's commitRow(), which
// always calls each module's own existing creation transaction (see
// importAdapters.js's header comment).
//
// The migration engine (startMigration/runMigrationLoop/pauseMigration/
// cancelMigration/resumeMigration/retryFailedRecords, below) is built for
// large datasets (100,000+ records): records are processed in controlled
// chunks with per-record transaction isolation, checkpointed progress, and
// resumability across a pause or a server crash - see each function's own
// comment for how.
const XLSX = require("xlsx");
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { getAdapter, listAdapters } = require("./importAdapters");

function toJson(value) {
  return value === undefined || value === null ? null : JSON.stringify(value);
}
function fromJson(value) {
  return value ? JSON.parse(value) : null;
}

function serializeBatch(batch) {
  if (!batch) return batch;
  return { ...batch, columnMapping: fromJson(batch.columnMapping) };
}
function serializeRecord(record) {
  if (!record) return record;
  return { ...record, rawData: fromJson(record.rawData), validationErrors: fromJson(record.validationErrors) };
}

function normalizeHeader(h) {
  return String(h || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

// Parses an uploaded .xlsx/.xls/.csv buffer into { headers, rows }. xlsx
// (SheetJS) auto-detects the format from the buffer/filename - one parser
// for both formats, no separate CSV library needed.
//
// raw:true (not raw:false) - a real bug was found and fixed here (Import
// Framework verification, 2026-08-09): with cellDates:true + raw:false,
// SheetJS auto-detects an ISO-looking string like "2026-01-05" (even from a
// plain-text CSV cell) as a date, converts it to a UTC Date internally, then
// *reformats it back to a locale date string* ("1/5/2026") for raw:false's
// output. importAdapters.js's parseDate() then does `new Date("1/5/2026")`,
// which JS parses as LOCAL midnight, not UTC - on a server whose OS
// timezone is ahead of UTC, that silently shifts the stored issueDate back
// by one day (verified: a server in IST turned "2026-01-05" into
// "2026-01-04T18:30:00.000Z"). Two conversions - date to string back to
// date - through two different timezone rules. raw:true returns the
// underlying Date object directly instead (built directly from the
// UTC-parsed ISO text, never reformatted) - toJson() below then serializes
// it with the standard, unambiguous Date.prototype.toJSON() (full ISO
// 8601 with a "Z"), which parseDate() already parses correctly as UTC, no
// further change needed there.
function parseFile(buffer, filename) {
  const workbook = XLSX.read(buffer, { type: "buffer", cellDates: true });
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) throw new ApiError(400, "The uploaded file has no readable sheet/data");
  const sheet = workbook.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, { raw: true, defval: "" });
  if (rows.length === 0) throw new ApiError(400, "The uploaded file has a header row but no data rows");
  const headers = Object.keys(rows[0]);
  return { headers, rows };
}

// Best-effort auto-map by normalized header/label match - the Map step in
// the UI always shows this for the user to correct, never applied silently
// without being visible first.
function autoMapColumns(headers, templateFields) {
  const normalizedHeaders = headers.map((h) => ({ raw: h, norm: normalizeHeader(h) }));
  const mapping = {};
  for (const field of templateFields) {
    const candidates = [normalizeHeader(field.key), normalizeHeader(field.label)];
    const match = normalizedHeaders.find((h) => candidates.includes(h.norm));
    mapping[field.key] = match ? match.raw : null;
  }
  return mapping;
}

function applyMapping(rawRow, mapping, templateFields) {
  const mapped = {};
  for (const field of templateFields) {
    const header = mapping[field.key];
    mapped[field.key] = header ? rawRow[header] : undefined;
  }
  return mapped;
}

// POST /imports - upload + create batch. File parsing happens synchronously
// here so a malformed file fails fast with a clear error before anything is
// persisted (mirrors Purchase OCR's own extract-before-save pattern -
// nothing commits to the real tables until a much later, explicit step).
// bankAccountId (Bank Statement Import, Phase 3 2026-08-22) - only ever
// passed for importType BANK_TRANSACTION; undefined/omitted for every other
// caller, exactly like migrationId already was, so this is purely additive.
async function createBatch({ tenantId, userId, importType, periodFrom, periodTo, file, migrationId, bankAccountId }) {
  const adapter = getAdapter(importType);
  if (!adapter) throw new ApiError(400, `Unknown import type "${importType}"`);

  const { headers, rows } = parseFile(file.buffer, file.originalname);
  const mapping = autoMapColumns(headers, adapter.templateFields);

  const batch = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextImportNumber: { increment: 1 } } });
    const batchNumber = `IMP-${String(tenant.nextImportNumber - 1).padStart(6, "0")}`;

    const created = await tx.importBatch.create({
      data: {
        tenantId,
        // Set only when this file is one part of a multi-file Migration
        // (migrationOrchestrator.service.js) - undefined/omitted for every
        // standalone single-file import, exactly as before this field
        // existed.
        ...(migrationId ? { migrationId } : {}),
        ...(bankAccountId ? { bankAccountId } : {}),
        batchNumber,
        importType,
        periodFrom: periodFrom ? new Date(periodFrom) : null,
        periodTo: periodTo ? new Date(periodTo) : null,
        sourceFileName: file.originalname,
        sourceFileUrl: file.fileUrl,
        columnMapping: toJson(mapping),
        totalRecords: rows.length,
        status: "MAPPING",
        importedBy: userId,
      },
    });

    // Chunked to keep each createMany call reasonably sized - SQLite has no
    // practical row-count issue at CSV scale, this is just defensive.
    const CHUNK = 200;
    for (let i = 0; i < rows.length; i += CHUNK) {
      await tx.importRecord.createMany({
        data: rows.slice(i, i + CHUNK).map((row, j) => ({
          importBatchId: created.id,
          rowNumber: i + j + 1,
          rawData: toJson(row),
          status: "PENDING",
        })),
      });
    }

    return created;
  });

  return { batch: serializeBatch(batch), headers, mapping };
}

// POST /imports/:id/mapping - user-corrected mapping from the Map step.
async function setMapping({ tenantId, batchId, mapping }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (!["MAPPING", "VALIDATING", "PREVIEW"].includes(batch.status)) {
    throw new ApiError(409, `This batch is ${batch.status.toLowerCase()} and its mapping can no longer be changed`);
  }

  const updated = await prisma.importBatch.update({
    where: { id: batch.id },
    data: { columnMapping: toJson(mapping), status: "MAPPING" },
  });
  return serializeBatch(updated);
}

// A row is only INVALID (blocking, skipped at commit) if it has at least
// one ERROR-severity issue - errors.severity is "ERROR"|"WARNING", and an
// omitted/undefined severity defaults to ERROR for full backward
// compatibility with error objects pushed before this field existed
// (2026-08-22, Migration Preview hardening - see importAdapters.js's
// header comment on the "duplicate" checks for which checks are WARNING).
function isBlockingError(err) {
  return !err.severity || err.severity === "ERROR";
}

// POST /imports/:id/validate - runs every record's row through the
// adapter's validateRow(), plus a generic intra-batch duplicate pass (two
// rows in the same file describing the same transaction) the engine handles
// once rather than every adapter reimplementing it.
async function validateBatch({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const adapter = getAdapter(batch.importType);
  const mapping = fromJson(batch.columnMapping) || {};

  const ctx = await adapter.buildContext(tenantId, batch);
  const records = await prisma.importRecord.findMany({ where: { importBatchId: batch.id }, orderBy: { rowNumber: "asc" } });

  const seenKeys = new Map(); // dedupeKey -> first rowNumber that used it
  let validCount = 0;
  let invalidCount = 0;
  let warningCount = 0;

  for (const record of records) {
    const rawRow = fromJson(record.rawData) || {};
    const mappedRow = applyMapping(rawRow, mapping, adapter.templateFields);
    const { normalized, errors } = adapter.validateRow(mappedRow, ctx);

    const dedupeKey = adapter.dedupeKey?.(normalized);
    if (dedupeKey) {
      const firstRow = seenKeys.get(dedupeKey);
      if (firstRow !== undefined) {
        // WARNING, not ERROR - same reasoning as every adapter's own
        // existing-record duplicate check: an intra-batch match is a
        // judgment call for the importing user, never a hard data error.
        errors.push({ field: "duplicate", severity: "WARNING", message: `Duplicate of row ${firstRow} in this same file` });
      } else {
        seenKeys.set(dedupeKey, record.rowNumber);
      }
    }

    const hasBlockingError = errors.some(isBlockingError);
    const hasWarnings = errors.some((e) => !isBlockingError(e));
    const status = hasBlockingError ? "INVALID" : "VALID";
    if (status === "VALID") validCount += 1;
    else invalidCount += 1;
    if (hasWarnings) warningCount += 1;

    let sourceIdentifier = null;
    try {
      sourceIdentifier = adapter.identify?.(normalized) || null;
    } catch {
      sourceIdentifier = null; // identify() is a display convenience only - never let it block validation
    }

    await prisma.importRecord.update({
      where: { id: record.id },
      data: {
        status,
        hasWarnings,
        validationErrors: errors.length > 0 ? toJson(errors) : null,
        sourceIdentifier: sourceIdentifier || `Row ${record.rowNumber}`,
      },
    });
  }

  const updated = await prisma.importBatch.update({
    where: { id: batch.id },
    data: { status: "PREVIEW", successCount: validCount, failedCount: invalidCount, warningCount },
  });
  return serializeBatch(updated);
}

// GET /imports/:id/preview - re-derives each record's normalized preview
// fields on demand (deterministic given rawData + mapping, see
// importAdapters.js's header comment) rather than persisting a redundant
// copy of it.
async function previewBatch({ tenantId, batchId, status }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const adapter = getAdapter(batch.importType);
  const mapping = fromJson(batch.columnMapping) || {};
  const ctx = await adapter.buildContext(tenantId, batch);

  const records = await prisma.importRecord.findMany({
    where: { importBatchId: batch.id, ...(status ? { status } : {}) },
    orderBy: { rowNumber: "asc" },
  });

  const rows = records.map((record) => {
    const rawRow = fromJson(record.rawData) || {};
    const mappedRow = applyMapping(rawRow, mapping, adapter.templateFields);
    const { normalized } = adapter.validateRow(mappedRow, ctx);
    return {
      id: record.id,
      rowNumber: record.rowNumber,
      status: record.status,
      hasWarnings: record.hasWarnings,
      validationErrors: fromJson(record.validationErrors) || [],
      normalized,
      raw: rawRow,
    };
  });

  // Financial reconciliation (2026-08-22, Migration Preview) - only over
  // rows that will actually be imported (VALID), and only for adapters that
  // define summarizeFinancials (SALES_INVOICE/PURCHASE_BILL today; CUSTOMER
  // has no money fields and simply omits this hook - see its own comment).
  let financialSummary = null;
  if (adapter.summarizeFinancials) {
    const validRows = status === "VALID" ? rows : rows.filter((r) => r.status === "VALID");
    // If the caller asked for a specific non-VALID status (e.g. INVALID),
    // re-derive the VALID rows separately rather than reusing `rows` above,
    // so the financial summary always reflects "what will actually be
    // imported" regardless of which status filter this call used.
    const rowsForSummary =
      status && status !== "VALID"
        ? (
            await prisma.importRecord.findMany({ where: { importBatchId: batch.id, status: "VALID" }, orderBy: { rowNumber: "asc" } })
          ).map((record) => {
            const rawRow = fromJson(record.rawData) || {};
            const mappedRow = applyMapping(rawRow, mapping, adapter.templateFields);
            const { normalized } = adapter.validateRow(mappedRow, ctx);
            return { normalized };
          })
        : validRows;
    financialSummary = adapter.summarizeFinancials(rowsForSummary);
  }

  return { batch: serializeBatch(batch), rows, financialSummary };
}

// ---------------------------------------------------------------------------
// Migration engine: fault-tolerant, resumable, crash-safe commit execution.
//
// Replaces the old single-transaction executeCommit(). Every record is
// committed in its OWN transaction (real entity creation + the
// ImportRecord's own status flip, atomically together) - never a shared
// transaction spanning many records. This is what gives:
//   - true record-level error isolation: one record's failure can never
//     roll back a sibling's already-committed row, because there is no
//     shared transaction to roll back.
//   - idempotent resume for free: re-querying ImportRecord.status="VALID"
//     after a pause/crash/retry naturally excludes every record already
//     flipped to IMPORTED or FAILED in an earlier chunk - no separate
//     "resume from row X" logic is needed beyond this query.
// "Batches" here are a processing/checkpoint/pause-boundary grouping only
// (BATCH_SIZE records at a time) - they are not a DB transaction boundary.
// ---------------------------------------------------------------------------
const BATCH_SIZE = 200; // same chunk size already used for createMany() in createBatch()

const RUNNABLE_FROM = ["PREVIEW", "PENDING_APPROVAL", "PAUSED"];

function classifyError(err) {
  if (err?.code === "P2002") return "DUPLICATE_RECORD";
  const msg = String(err?.message || err || "");
  if (/tax rate|tax category/i.test(msg)) return "REFERENCE_NOT_FOUND";
  if (/mismatch/i.test(msg)) return "CALCULATION_MISMATCH";
  if (/duplicate/i.test(msg)) return "DUPLICATE_RECORD";
  if (err?.statusCode && err.statusCode < 500) return "VALIDATION_ERROR";
  return "COMMIT_ERROR";
}

// POST /imports/:id/commit's entry point (via the "ImportBatch.commit"
// Maker-Checker executor - see approvalExecutors.js) and POST .../resume and
// POST .../retry-failed all funnel through here. Transitions the batch to
// QUEUED and returns IMMEDIATELY - the real work happens in
// runMigrationLoop(), deliberately NOT awaited, so a 100,000+ row migration
// never ties up the HTTP request/executor call that started it. Callers
// must poll GET /imports/:id for progress.
async function startMigration({ tenantId, batchId, actorId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (!RUNNABLE_FROM.includes(batch.status)) {
    throw new ApiError(409, `This batch is ${batch.status.toLowerCase()} and can't be started`);
  }

  // A FRESH start (from PREVIEW/PENDING_APPROVAL) must reset successCount to
  // 0 - validateBatch() writes that same column to mean "records that
  // passed validation," a different meaning than the migration engine's
  // "records actually imported so far." Resuming from PAUSED must NOT reset
  // it - it already holds real accumulated execution progress at that
  // point. failedCount is NOT reset either way: at Preview it already means
  // "records that will never be attempted" (INVALID), which correctly
  // stays part of the final failed total once execution failures are added
  // on top of it.
  const isFreshStart = batch.status !== "PAUSED";

  const updated = await prisma.importBatch.update({
    where: { id: batch.id },
    data: {
      status: "QUEUED",
      startedAt: batch.startedAt || new Date(), // keep the original start time across a resume
      lastActivityAt: new Date(),
      pauseRequested: false,
      cancelRequested: false,
      ...(isFreshStart ? { successCount: 0 } : {}),
    },
  });

  // Fire-and-forget: intentionally not awaited. Errors inside the loop are
  // caught internally (see runMigrationLoop's own try/catch) and persisted
  // onto the batch itself (status FAILED + lastError), never thrown here -
  // there is no caller left awaiting this promise to catch anything.
  runMigrationLoop(tenantId, batchId, actorId).catch(async (err) => {
    const failedBatch = await prisma.importBatch.update({
      where: { id: batchId },
      data: { status: "FAILED", lastError: String(err?.message || err), lastActivityAt: new Date() },
    }).catch(() => null); // if even this write fails, there's nothing further we can safely do
    // Optional adapter hook (Bank Statement Import, Phase 3 2026-08-22) - see
    // its call at the end of runMigrationLoop for what this is. Only this
    // one catastrophic-failure path needs a second call site, since a normal
    // per-record failure never reaches here (runMigrationLoop's own inner
    // try/catch already handles that and keeps looping).
    if (failedBatch) {
      const adapter = getAdapter(failedBatch.importType);
      await adapter.onBatchFinished?.(tenantId, serializeBatch(failedBatch)).catch(() => {});
    }
  });

  return serializeBatch(updated);
}

// The actual chunked processing loop. Not exported - only ever entered via
// startMigration (fresh start, resume, or after retryFailedRecords resets
// FAILED rows back to VALID).
async function runMigrationLoop(tenantId, batchId, actorId) {
  await prisma.importBatch.update({ where: { id: batchId }, data: { status: "PROCESSING", lastActivityAt: new Date() } });

  const batch = await prisma.importBatch.findUnique({ where: { id: batchId } });
  const adapter = getAdapter(batch.importType);
  const mapping = fromJson(batch.columnMapping) || {};
  const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
  const ctx = await adapter.buildContext(tenantId, batch);

  let processedRecords = batch.processedRecords;
  let successCount = batch.successCount;
  let failedCount = batch.failedCount;
  let currentBatchNumber = batch.currentBatchNumber;

  for (;;) {
    const records = await prisma.importRecord.findMany({
      where: { importBatchId: batchId, status: "VALID" },
      orderBy: { rowNumber: "asc" },
      take: BATCH_SIZE,
    });
    if (records.length === 0) break; // nothing left to do - migration is complete

    for (const record of records) {
      const rawRow = fromJson(record.rawData) || {};
      const mappedRow = applyMapping(rawRow, mapping, adapter.templateFields);
      const { normalized, errors } = adapter.validateRow(mappedRow, ctx);

      // Only a re-surfaced ERROR-severity issue means data moved under us
      // since Validate (e.g. a referenced Tax Category was deactivated) -
      // a WARNING-only re-check (e.g. the same "possible duplicate" flag)
      // is not a reason to fail a row that was already accepted as VALID.
      if (errors.some(isBlockingError)) {
        await prisma.importRecord.update({
          where: { id: record.id },
          data: { status: "FAILED", validationErrors: toJson(errors), errorCode: "REFERENCE_NOT_FOUND" },
        });
        failedCount += 1;
      } else {
        try {
          await prisma.$transaction(async (tx) => {
            // rowNumber (Bank Statement Import, Phase 3 2026-08-22) - an
            // additional trailing argument every existing adapter's
            // commitRow signature simply ignores (JS doesn't error on extra
            // call-site args) - only BANK_TRANSACTION's commitRow declares
            // and uses it, to persist BankTransaction.sourceRow.
            const result = await adapter.commitRow(tx, tenantId, tenant, normalized, batch, actorId, record.rowNumber);
            await tx.importRecord.update({
              where: { id: record.id },
              data: { status: "IMPORTED", entityType: result.entityType, resultingEntityId: result.entityId },
            });
          });
          successCount += 1;
        } catch (err) {
          // Never let one record's real error abort the loop or touch any
          // other record's already-committed transaction.
          await prisma.importRecord.update({
            where: { id: record.id },
            data: {
              status: "FAILED",
              errorCode: classifyError(err),
              validationErrors: toJson([{ field: "commit", message: String(err?.message || err) }]),
            },
          });
          failedCount += 1;
        }
      }
      processedRecords += 1;
    }

    currentBatchNumber += 1;
    await prisma.importBatch.update({
      where: { id: batchId },
      data: {
        processedRecords,
        successCount,
        failedCount,
        currentBatchNumber,
        checkpointRowNumber: records[records.length - 1].rowNumber,
        lastActivityAt: new Date(),
      },
    });

    // Only checked between chunks, never mid-record - "pause/resume where
    // technically safe."
    const control = await prisma.importBatch.findUnique({ where: { id: batchId }, select: { cancelRequested: true, pauseRequested: true } });
    if (control.cancelRequested) {
      await prisma.importBatch.update({ where: { id: batchId }, data: { status: "CANCELLED", importedAt: new Date() } });
      return;
    }
    if (control.pauseRequested) {
      await prisma.importBatch.update({ where: { id: batchId }, data: { status: "PAUSED" } }); // no importedAt - not finished
      return;
    }
  }

  const finalStatus = failedCount > 0 ? "COMPLETED_WITH_ERRORS" : "COMPLETED";
  const finalBatch = await prisma.importBatch.update({ where: { id: batchId }, data: { status: finalStatus, importedAt: new Date() } });

  // Optional adapter hook (Bank Statement Import, Phase 3 2026-08-22) - lets
  // an adapter react to "this batch just reached a terminal state" (e.g.
  // logging a BankAccountActivity "Import completed/completed with errors").
  // Deliberately optional/no-op for every adapter that doesn't define it
  // (SALES_INVOICE/PURCHASE_BILL/CUSTOMER/PAYMENT/PURCHASE_PAYMENT) - zero
  // behavior change for them. Never allowed to affect the migration's own
  // outcome, matching every other per-record error-isolation rule in this
  // loop - a broken hook is swallowed, not thrown.
  await adapter.onBatchFinished?.(tenantId, serializeBatch(finalBatch)).catch(() => {});
}

async function pauseMigration({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (!["QUEUED", "PROCESSING"].includes(batch.status)) {
    throw new ApiError(409, `This batch is ${batch.status.toLowerCase()} and can't be paused`);
  }
  const updated = await prisma.importBatch.update({ where: { id: batch.id }, data: { pauseRequested: true } });
  return serializeBatch(updated); // status flips to PAUSED asynchronously, at the next chunk boundary
}

async function cancelMigration({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (["QUEUED", "PROCESSING"].includes(batch.status)) {
    const updated = await prisma.importBatch.update({ where: { id: batch.id }, data: { cancelRequested: true } });
    return serializeBatch(updated); // status flips to CANCELLED asynchronously, at the next chunk boundary
  }
  if (batch.status === "PAUSED") {
    // Nothing is actively running - safe to cancel immediately.
    const updated = await prisma.importBatch.update({ where: { id: batch.id }, data: { status: "CANCELLED", importedAt: new Date() } });
    return serializeBatch(updated);
  }
  throw new ApiError(409, `This batch is ${batch.status.toLowerCase()} and can't be cancelled`);
}

// POST /imports/:id/resume - validates PAUSED (including a batch a server
// restart flipped to PAUSED after a crash - see src/server.js's boot
// reconciliation), then re-enters the exact same start path as a fresh
// commit. The loop's own ImportRecord.status="VALID" query is what makes
// this correct with zero extra "resume from checkpoint" logic - already-
// IMPORTED/FAILED records from before the pause/crash are never re-touched.
async function resumeMigration({ tenantId, batchId, actorId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (batch.status !== "PAUSED") throw new ApiError(409, `This batch is ${batch.status.toLowerCase()}, not paused - nothing to resume`);
  return startMigration({ tenantId, batchId, actorId });
}

// POST /imports/:id/retry-failed - flips every FAILED (commit-time failure)
// record back to VALID, bumps its retry bookkeeping, then restarts the loop.
// Deliberately scoped to FAILED only, never INVALID (pre-commit validation
// failures still need the source file fixed and re-uploaded).
async function retryFailedRecords({ tenantId, batchId, actorId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  if (!["COMPLETED_WITH_ERRORS", "PAUSED", "FAILED"].includes(batch.status)) {
    throw new ApiError(409, `This batch is ${batch.status.toLowerCase()} and has nothing to retry yet`);
  }

  const { count } = await prisma.importRecord.updateMany({
    where: { importBatchId: batchId, status: "FAILED" },
    data: { status: "VALID", retryCount: { increment: 1 }, lastRetriedAt: new Date() },
  });
  if (count === 0) throw new ApiError(400, "This batch has no failed records to retry");

  // These records now count as VALID again, not FAILED - re-derive failedCount
  // so the progress counters stay honest while the retry runs.
  await prisma.importBatch.update({ where: { id: batchId }, data: { failedCount: { decrement: count }, processedRecords: { decrement: count } } });

  // A COMPLETED_WITH_ERRORS/FAILED batch never had RUNNABLE_FROM include its
  // own status - flip it to PAUSED first so startMigration's guard accepts it.
  await prisma.importBatch.update({ where: { id: batchId }, data: { status: "PAUSED" } });
  return startMigration({ tenantId, batchId, actorId });
}

// Called by import.controller.js's commitBatch when engine.dispatch()
// returns PENDING (an approval rule for imports.commit is active) - purely
// a display-status update so Import History shows "Pending Approval"
// instead of a stale "Preview". The real gate is the ApprovalRequest row
// itself; startMigration()'s own status guard already accepts either
// PREVIEW or PENDING_APPROVAL, so this is cosmetic, not load-bearing.
async function markPendingApproval({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const updated = await prisma.importBatch.update({ where: { id: batch.id }, data: { status: "PENDING_APPROVAL" } });
  return serializeBatch(updated);
}

// Attaches a human-readable importedByName - same batched-lookup pattern as
// approvalEngine.service.js's attachNames, since ImportBatch.importedBy is
// plain data (a User.id string), not a Prisma relation, same convention as
// ApprovalRequest.requestedBy.
async function attachImportedByNames(batches) {
  const userIds = [...new Set(batches.map((b) => b.importedBy).filter(Boolean))];
  const users = await prisma.user.findMany({ where: { id: { in: userIds } }, select: { id: true, name: true } });
  const nameById = new Map(users.map((u) => [u.id, u.name]));
  return batches.map((b) => ({ ...b, importedByName: nameById.get(b.importedBy) || b.importedBy }));
}

async function listBatches({ tenantId }) {
  const batches = await prisma.importBatch.findMany({ where: { tenantId }, orderBy: { createdAt: "desc" } });
  return attachImportedByNames(batches.map(serializeBatch));
}

async function getBatch({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const [enriched] = await attachImportedByNames([serializeBatch(batch)]);
  return enriched;
}

// status may be a single value ("VALID") or a comma-separated list
// ("INVALID,FAILED") - lets the frontend's "Failed" tab show both pre-commit
// (INVALID) and commit-time (FAILED) failures in one request.
// onlyWarnings (2026-08-22, Migration Review drill-in) - when true, filters
// to VALID records with hasWarnings=true, i.e. exactly the "will still be
// imported but flagged" rows the Review screen's Warnings/Duplicates counts
// come from. onlyDuplicates further narrows to just the ones carrying a
// "duplicate"-field entry in validationErrors, since Warnings and
// Duplicates are shown as two separate drill-ins even though Duplicates is
// really a subset of Warnings today (every WARNING-severity check happens
// to be a duplicate check right now, but this stays correct if a
// non-duplicate WARNING type is ever added).
async function getRecords({ tenantId, batchId, status, onlyWarnings, onlyDuplicates }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const statusList = status ? status.split(",").map((s) => s.trim()).filter(Boolean) : null;
  const records = await prisma.importRecord.findMany({
    where: {
      importBatchId: batch.id,
      ...(statusList ? (statusList.length === 1 ? { status: statusList[0] } : { status: { in: statusList } }) : {}),
      ...(onlyWarnings || onlyDuplicates ? { hasWarnings: true } : {}),
    },
    orderBy: { rowNumber: "asc" },
  });
  const serialized = records.map(serializeRecord);
  if (!onlyDuplicates) return serialized;
  return serialized.filter((r) => (r.validationErrors || []).some((e) => e.field === "duplicate"));
}

// GET /imports/:id/error-report - CSV of every INVALID (pre-commit) or
// FAILED (commit-time) row's original data plus its errors, so the user can
// fix the source file and re-upload, or use Retry Failed Records for the
// FAILED ones without re-uploading anything.
async function buildErrorReportCsv({ tenantId, batchId }) {
  const batch = await prisma.importBatch.findFirst({ where: { id: batchId, tenantId } });
  if (!batch) throw new ApiError(404, "Import batch not found");
  const records = await prisma.importRecord.findMany({
    where: { importBatchId: batch.id, status: { in: ["INVALID", "FAILED"] } },
    orderBy: { rowNumber: "asc" },
  });

  const rows = records.map((r) => {
    const raw = fromJson(r.rawData) || {};
    const errors = (fromJson(r.validationErrors) || []).map((e) => e.message).join("; ");
    return {
      "Row #": r.rowNumber,
      Status: r.status,
      "Source Identifier": r.sourceIdentifier || `Row ${r.rowNumber}`,
      ...raw,
      "Error Code": r.errorCode || "",
      "Validation Errors": errors,
      "Retry Count": r.retryCount,
      "Last Retried At": r.lastRetriedAt ? r.lastRetriedAt.toISOString() : "",
    };
  });
  const XLSXlib = require("xlsx");
  const worksheet = XLSXlib.utils.json_to_sheet(rows);
  return XLSXlib.utils.sheet_to_csv(worksheet);
}

module.exports = {
  BATCH_SIZE,
  listAdapters,
  createBatch,
  setMapping,
  validateBatch,
  previewBatch,
  startMigration,
  pauseMigration,
  cancelMigration,
  resumeMigration,
  retryFailedRecords,
  markPendingApproval,
  listBatches,
  getBatch,
  getRecords,
  buildErrorReportCsv,
};
