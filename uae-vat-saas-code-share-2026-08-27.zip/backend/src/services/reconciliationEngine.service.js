// Reconciliation Engine (Phase 4, 2026-08-23) - matches BankTransaction rows
// (Banking module, Phase 3) against Payment/PurchasePayment rows (Payments
// module, Phase 2). See prisma/schema.prisma's ReconciliationMatch comment
// for the full data-model reasoning. This file owns:
//   - candidate scoring (multi-factor, no "AI matching" - a fixed, readable
//     weighted-signal function, per the brief's explicit "no AI matching"
//     boundary for this phase)
//   - suggestion generation (creates a SUGGESTED ReconciliationMatch, never
//     a CONFIRMED one - only reconciliation.controller.js's confirmMatch/
//     manualMatch ever write CONFIRMED, always on an explicit user action)
//   - the two "recompute derived status" helpers, the ONLY writers of
//     BankTransaction.reconciliationStatus / Payment(PurchasePayment)
//     .reconciliationStatus going forward (besides the pre-existing manual
//     reconcilePayment/unreconcilePayment for a payment with no bank
//     statement involved at all).
const { round2 } = require("./invoiceCalc");

const AMOUNT_EPSILON = 0.01;
// Below this score, a candidate is not surfaced as a suggestion at all - no
// signal beyond a bare date-proximity coincidence (max 15pts alone) clears
// this, so "same week, nothing else in common" never counts as a match.
const SUGGESTION_FLOOR = 30;
// Recency window used to bound the candidate pool queried from the DB (see
// getPaymentCandidates/getPurchasePaymentCandidates) - a real, if coarse,
// server-side filter so this never becomes "load the whole ledger table and
// filter in memory" per the brief's performance requirement. Widened, not
// removed, if the narrow pass finds nothing (a reference/invoice-number
// match against an old payment should still surface even if it's outside
// the recency window - see findCandidates' two-pass fallback).
const CANDIDATE_WINDOW_DAYS = 60;
const CANDIDATE_POOL_SIZE = 150;

function normalizeText(str) {
  return String(str || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function daysBetween(a, b) {
  if (!a || !b) return Infinity;
  return Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 86400000;
}

function scoreAmount(bankAmount, ledgerAmount) {
  const diff = Math.abs(bankAmount - ledgerAmount);
  if (diff <= AMOUNT_EPSILON) return { points: 40, label: "Amount matches exactly" };
  const base = Math.max(bankAmount, ledgerAmount, 1);
  if (diff / base <= 0.02) return { points: 20, label: "Amount is very close" };
  return { points: 0, label: null };
}

function scoreDate(bankDate, ledgerDate) {
  const days = daysBetween(bankDate, ledgerDate);
  if (days <= 1) return { points: 15, label: "Date matches (same day)" };
  if (days <= 3) return { points: 10, label: "Date close (within 3 days)" };
  if (days <= 7) return { points: 5, label: "Date within a week" };
  return { points: 0, label: null };
}

function scoreIncludes(haystack, needle, points, label) {
  const h = normalizeText(haystack);
  const n = normalizeText(needle);
  if (n.length >= 3 && h.includes(n)) return { points, label };
  return { points: 0, label: null };
}

// kind: "payment" | "purchasePayment". ledger is the enriched candidate row
// from getPaymentCandidates/getPurchasePaymentCandidates below (carries
// remainingBalance + documentNumbers, not raw Prisma fields).
function scoreCandidate(bankTxn, ledger, kind) {
  const bankText = `${bankTxn.description || ""} ${bankTxn.reference || ""}`;
  const bankAmount = round2(Math.abs(bankTxn.amount));
  const reasons = [];
  let score = 0;

  const amt = scoreAmount(bankAmount, ledger.remainingBalance);
  if (amt.points) { score += amt.points; reasons.push({ signal: "amount", label: amt.label }); }

  const dt = scoreDate(bankTxn.transactionDate, ledger.paymentDate);
  if (dt.points) { score += dt.points; reasons.push({ signal: "date", label: dt.label }); }

  const partyName = kind === "payment" ? ledger.customerName : ledger.vendorName;
  const partyHit = scoreIncludes(bankText, partyName, 20, `${kind === "payment" ? "Customer" : "Supplier"} name "${partyName}" found in bank description/reference`);
  if (partyHit.points) { score += partyHit.points; reasons.push({ signal: "party", label: partyHit.label }); }

  const refHit = scoreIncludes(bankText, ledger.reference, 18, `Payment reference "${ledger.reference}" found in bank description/reference`);
  if (refHit.points) { score += refHit.points; reasons.push({ signal: "payment_reference", label: refHit.label }); }

  for (const docNumber of ledger.documentNumbers) {
    const docHit = scoreIncludes(bankText, docNumber, 25, `Document number ${docNumber} found in bank description/reference`);
    if (docHit.points) { score += docHit.points; reasons.push({ signal: "document_number", label: docHit.label }); break; }
  }

  return { score: Math.min(100, round2(score)), reasons };
}

function deriveConfidence(score) {
  if (score >= 75) return "HIGH";
  if (score >= 45) return "MEDIUM";
  return "LOW";
}

async function getPaymentCandidates(prisma, tenantId, bankTxn) {
  const from = new Date(new Date(bankTxn.transactionDate).getTime() - CANDIDATE_WINDOW_DAYS * 86400000);
  const to = new Date(new Date(bankTxn.transactionDate).getTime() + CANDIDATE_WINDOW_DAYS * 86400000);

  async function fetchPool(where) {
    const rows = await prisma.payment.findMany({
      where: { tenantId, status: "CONFIRMED", ...where },
      include: {
        allocations: { include: { invoice: { select: { invoiceNumberDisplay: true } } } },
        reconciliationLines: { where: { match: { status: "CONFIRMED" } }, select: { amount: true } },
      },
      orderBy: { paymentDate: "desc" },
      take: CANDIDATE_POOL_SIZE,
    });
    return rows;
  }

  // Two pools, always both, merged/deduped: a recency-window pool (the
  // common case - most reconciliation happens against a recent payment) AND
  // an unbounded-date pool capped at CANDIDATE_POOL_SIZE. A single "widen
  // only if the narrow pool came back small" heuristic was tried first and
  // is deliberately NOT what ships - it silently dropped a real match dated
  // outside the window whenever OTHER, unrelated recent payments happened to
  // fill the narrow pool past the widen threshold (Test scenario #5, "date
  // mismatch", must still surface the true match, just scored lower on
  // date). Both queries stay bounded (take: CANDIDATE_POOL_SIZE each), so
  // this is still never "load the whole table."
  const [narrow, wide] = await Promise.all([fetchPool({ paymentDate: { gte: from, lte: to } }), fetchPool({})]);
  const seen = new Set();
  const rows = [];
  for (const r of [...narrow, ...wide]) {
    if (seen.has(r.id)) continue;
    seen.add(r.id);
    rows.push(r);
  }

  return rows
    .map((p) => {
      const linked = round2((p.reconciliationLines || []).reduce((s, l) => s + l.amount, 0));
      return {
        id: p.id,
        paymentNumberDisplay: p.paymentNumberDisplay,
        customerName: p.customerName,
        paymentDate: p.paymentDate,
        amount: p.amount,
        currency: p.currency,
        reference: p.reference,
        method: p.method,
        remainingBalance: round2(Math.max(0, p.amount - linked)),
        documentNumbers: p.allocations.map((a) => a.invoice?.invoiceNumberDisplay).filter(Boolean),
      };
    })
    .filter((p) => p.remainingBalance > AMOUNT_EPSILON);
}

async function getPurchasePaymentCandidates(prisma, tenantId, bankTxn) {
  const from = new Date(new Date(bankTxn.transactionDate).getTime() - CANDIDATE_WINDOW_DAYS * 86400000);
  const to = new Date(new Date(bankTxn.transactionDate).getTime() + CANDIDATE_WINDOW_DAYS * 86400000);

  async function fetchPool(where) {
    return prisma.purchasePayment.findMany({
      where: { tenantId, status: "CONFIRMED", ...where },
      include: {
        allocations: { include: { purchaseBill: { select: { billNumberDisplay: true } } } },
        reconciliationLines: { where: { match: { status: "CONFIRMED" } }, select: { amount: true } },
      },
      orderBy: { paymentDate: "desc" },
      take: CANDIDATE_POOL_SIZE,
    });
  }

  // See getPaymentCandidates' identical comment - both pools always run.
  const [narrow, wide] = await Promise.all([fetchPool({ paymentDate: { gte: from, lte: to } }), fetchPool({})]);
  const seen = new Set();
  const rows = [];
  for (const r of [...narrow, ...wide]) {
    if (seen.has(r.id)) continue;
    seen.add(r.id);
    rows.push(r);
  }

  return rows
    .map((p) => {
      const linked = round2((p.reconciliationLines || []).reduce((s, l) => s + l.amount, 0));
      return {
        id: p.id,
        paymentNumberDisplay: p.paymentNumberDisplay,
        vendorName: p.vendorName,
        paymentDate: p.paymentDate,
        amount: p.amount,
        currency: p.currency,
        reference: p.reference,
        method: p.method,
        remainingBalance: round2(Math.max(0, p.amount - linked)),
        documentNumbers: p.allocations.map((a) => a.purchaseBill?.billNumberDisplay).filter(Boolean),
      };
    })
    .filter((p) => p.remainingBalance > AMOUNT_EPSILON);
}

// Returns the bank transaction's own un-matched remaining amount - full
// |amount| minus whatever is already covered by a CONFIRMED match (supports
// the "many bank transactions -> 1 payment" / "1 bank -> many payments"
// scenarios across repeated matching runs, and lets a PARTIALLY_RECONCILED
// transaction still be offered fresh suggestions for its own remainder).
async function getBankTransactionRemaining(prisma, bankTransactionId) {
  const confirmed = await prisma.reconciliationBankLine.aggregate({
    where: { bankTransactionId, match: { status: "CONFIRMED" } },
    _sum: { amount: true },
  });
  return round2(confirmed._sum.amount || 0);
}

async function getPaymentRemaining(prisma, paymentId) {
  const confirmed = await prisma.reconciliationLedgerLine.aggregate({
    where: { paymentId, match: { status: "CONFIRMED" } },
    _sum: { amount: true },
  });
  return round2(confirmed._sum.amount || 0);
}

async function getPurchasePaymentRemaining(prisma, purchasePaymentId) {
  const confirmed = await prisma.reconciliationLedgerLine.aggregate({
    where: { purchasePaymentId, match: { status: "CONFIRMED" } },
    _sum: { amount: true },
  });
  return round2(confirmed._sum.amount || 0);
}

// Ranked, scored candidates for one bank transaction - used both by the
// Review Match screen (top few, with reasons) and by generateSuggestion
// below (the single best one, if it clears the floor).
async function findCandidates(prisma, tenantId, bankTransactionId) {
  const bankTxn = await prisma.bankTransaction.findFirst({ where: { id: bankTransactionId, tenantId } });
  if (!bankTxn) return { bankTxn: null, direction: null, candidates: [] };

  const direction = bankTxn.amount >= 0 ? "CREDIT" : "DEBIT";
  const kind = direction === "CREDIT" ? "payment" : "purchasePayment";
  const alreadyLinked = await getBankTransactionRemaining(prisma, bankTransactionId);
  const remaining = round2(Math.max(0, Math.abs(bankTxn.amount) - alreadyLinked));

  if (remaining <= AMOUNT_EPSILON) return { bankTxn, direction, remaining: 0, candidates: [] };

  const pool = direction === "CREDIT"
    ? await getPaymentCandidates(prisma, tenantId, bankTxn)
    : await getPurchasePaymentCandidates(prisma, tenantId, bankTxn);

  const scored = pool
    .map((ledger) => {
      const { score, reasons } = scoreCandidate(bankTxn, ledger, kind);
      return { kind, ledger, score, reasons, confidence: deriveConfidence(score) };
    })
    .filter((c) => c.score >= SUGGESTION_FLOOR)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  return { bankTxn, direction, remaining, candidates: scored };
}

// Creates (or leaves alone, if one is already active) a SUGGESTED
// ReconciliationMatch for the single best candidate, if any clears the
// floor. Idempotent per bank transaction - never regenerates a suggestion
// while one is already pending review (the user must Reject it first, via
// the Review screen, to get a fresh one). Returns the created match, or null
// if nothing to suggest / a suggestion already exists / the transaction is
// IGNORED (sticky - see BankTransaction.reconciliationStatus schema
// comment) / already fully covered.
async function generateSuggestion(prisma, tenantId, bankTransactionId) {
  const bankTxn = await prisma.bankTransaction.findFirst({ where: { id: bankTransactionId, tenantId } });
  if (!bankTxn || bankTxn.status !== "ACTIVE") return null;
  if (bankTxn.reconciliationStatus === "RECONCILED" || bankTxn.reconciliationStatus === "IGNORED") return null;

  const existingSuggestion = await prisma.reconciliationMatch.findFirst({
    where: { tenantId, status: "SUGGESTED", bankLines: { some: { bankTransactionId } } },
  });
  if (existingSuggestion) return null;

  const { direction, remaining, candidates } = await findCandidates(prisma, tenantId, bankTransactionId);
  if (!candidates.length || remaining <= AMOUNT_EPSILON) return null;

  const best = candidates[0];
  const proposedAmount = round2(Math.min(remaining, best.ledger.remainingBalance));
  if (proposedAmount <= AMOUNT_EPSILON) return null;

  const match = await prisma.$transaction(async (tx) => {
    const created = await tx.reconciliationMatch.create({
      data: {
        tenantId,
        status: "SUGGESTED",
        direction,
        source: "SYSTEM",
        confidence: best.confidence,
        score: best.score,
        matchReasons: JSON.stringify(best.reasons),
        totalBankAmount: proposedAmount,
        totalLedgerAmount: proposedAmount,
        difference: 0,
        bankLines: { create: [{ bankTransactionId, amount: proposedAmount }] },
        ledgerLines: {
          create: [
            direction === "CREDIT"
              ? { paymentId: best.ledger.id, amount: proposedAmount }
              : { purchasePaymentId: best.ledger.id, amount: proposedAmount },
          ],
        },
      },
    });
    await tx.reconciliationActivity.create({
      data: { matchId: created.id, type: "SUGGESTED", description: `System suggested ${best.confidence.toLowerCase()}-confidence match against ${best.ledger.paymentNumberDisplay}`, newStatus: "SUGGESTED" },
    });
    await recomputeBankTransactionStatus(tx, bankTransactionId);
    return created;
  });

  return match;
}

// Runs generateSuggestion across a controlled batch of a tenant's own
// UNMATCHED/PARTIALLY_RECONCILED bank transactions (never the whole table at
// once - see BATCH_SIZE in importEngine.service.js for the same convention
// this mirrors). Returns how many transactions were scanned and how many
// suggestions were created, plus whether more remain (the caller/UI can
// re-invoke to continue - same "controlled batches" answer this codebase
// already gives for large-dataset processing elsewhere, short of standing up
// a persisted background-job queue that does not otherwise exist in this
// stack).
const RUN_BATCH_SIZE = 100;

async function runMatchingBatch(prisma, tenantId, { bankAccountId } = {}) {
  const candidates = await prisma.bankTransaction.findMany({
    where: {
      tenantId,
      status: "ACTIVE",
      reconciliationStatus: { in: ["UNMATCHED", "PARTIALLY_RECONCILED"] },
      ...(bankAccountId ? { bankAccountId } : {}),
    },
    select: { id: true },
    orderBy: { transactionDate: "desc" },
    take: RUN_BATCH_SIZE + 1,
  });

  const hasMore = candidates.length > RUN_BATCH_SIZE;
  const toProcess = candidates.slice(0, RUN_BATCH_SIZE);

  let suggested = 0;
  for (const { id } of toProcess) {
    const match = await generateSuggestion(prisma, tenantId, id);
    if (match) suggested += 1;
  }

  return { scanned: toProcess.length, suggested, hasMore };
}

async function recomputeBankTransactionStatus(tx, bankTransactionId) {
  const bankTxn = await tx.bankTransaction.findUnique({ where: { id: bankTransactionId } });
  if (!bankTxn) return null;

  const confirmedTotal = await getBankTransactionRemaining(tx, bankTransactionId);
  const fullAmount = round2(Math.abs(bankTxn.amount));

  const activeSuggested = await tx.reconciliationMatch.findFirst({
    where: { tenantId: bankTxn.tenantId, status: "SUGGESTED", bankLines: { some: { bankTransactionId } } },
  });
  const activeIgnored = await tx.reconciliationMatch.findFirst({
    where: { tenantId: bankTxn.tenantId, status: "IGNORED", bankLines: { some: { bankTransactionId } } },
    orderBy: { createdAt: "desc" },
  });

  let status;
  if (fullAmount > 0 && confirmedTotal >= fullAmount - AMOUNT_EPSILON) status = "RECONCILED";
  else if (confirmedTotal > AMOUNT_EPSILON) status = "PARTIALLY_RECONCILED";
  else if (activeSuggested) status = "SUGGESTED";
  else if (activeIgnored) status = "IGNORED";
  else status = "UNMATCHED";

  if (status !== bankTxn.reconciliationStatus) {
    await tx.bankTransaction.update({ where: { id: bankTransactionId }, data: { reconciliationStatus: status } });
  }
  return status;
}

async function recomputeLedgerReconciliation(tx, { paymentId, purchasePaymentId }) {
  const isPayment = !!paymentId;
  const id = paymentId || purchasePaymentId;
  const row = isPayment
    ? await tx.payment.findUnique({ where: { id } })
    : await tx.purchasePayment.findUnique({ where: { id } });
  if (!row) return null;

  const confirmedTotal = isPayment ? await getPaymentRemaining(tx, id) : await getPurchasePaymentRemaining(tx, id);
  const fullAmount = round2(row.amount);

  let status;
  if (fullAmount > 0 && confirmedTotal >= fullAmount - AMOUNT_EPSILON) status = "RECONCILED";
  else if (confirmedTotal > AMOUNT_EPSILON) status = "PARTIALLY_RECONCILED";
  else status = "UNRECONCILED";

  if (status !== row.reconciliationStatus) {
    if (isPayment) await tx.payment.update({ where: { id }, data: { reconciliationStatus: status } });
    else await tx.purchasePayment.update({ where: { id }, data: { reconciliationStatus: status } });
  }
  return status;
}

module.exports = {
  AMOUNT_EPSILON,
  SUGGESTION_FLOOR,
  scoreCandidate,
  deriveConfidence,
  findCandidates,
  generateSuggestion,
  runMatchingBatch,
  getBankTransactionRemaining,
  getPaymentRemaining,
  getPurchasePaymentRemaining,
  recomputeBankTransactionStatus,
  recomputeLedgerReconciliation,
};
