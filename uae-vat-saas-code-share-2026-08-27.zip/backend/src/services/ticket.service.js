const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

// Support Center (2026-08-07) - core ticketing engine. Deliberately NOT
// integrated with Maker-Checker (ApprovalRequest) anywhere in this file -
// every write here takes effect immediately, per spec ("tickets should work
// immediately"). Internal notes (TicketComment.isInternal=true) are
// filtered out of every tenant-facing read path in this file, not just
// hidden in the UI - see stripInternal()/listCommentsForTenant().

const OPEN_STATUSES = ["NEW", "ASSIGNED", "IN_PROGRESS", "WAITING_CUSTOMER", "REOPENED"];

function parseJson(json, fallback) {
  try {
    return JSON.parse(json || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

async function logActivity(tx, ticketId, type, { description, actorType, actorId } = {}) {
  return (tx || prisma).ticketActivity.create({
    data: { ticketId, type, description, actorType, actorId },
  });
}

async function computeSlaDates(priority) {
  const policy = await prisma.slaPolicy.findUnique({ where: { priority } });
  if (!policy || !policy.isActive) return { slaPolicyId: null, slaResponseDueAt: null, slaResolutionDueAt: null };
  const now = Date.now();
  return {
    slaPolicyId: policy.id,
    slaResponseDueAt: new Date(now + policy.responseTimeHours * 3600 * 1000),
    slaResolutionDueAt: new Date(now + policy.resolutionTimeHours * 3600 * 1000),
  };
}

function shapeTicket(t) {
  return { ...t, linkedTicketIds: parseJson(t.linkedTicketIds, []), tags: parseJson(t.tags, []) };
}

// --- Reference data (no dedicated admin CRUD yet - see plan.service.js-style comment) ---

async function listCategories() {
  return prisma.ticketCategory.findMany({ where: { isActive: true }, orderBy: { name: "asc" } });
}

async function listSlaPolicies() {
  return prisma.slaPolicy.findMany({ orderBy: { priority: "asc" } });
}

// Every PlatformAdmin is a potential assignee - there's no separate
// "support agent" concept yet (that's the deferred Teams feature).
async function listAssignableAdmins() {
  return prisma.platformAdmin.findMany({ select: { id: true, email: true }, orderBy: { email: "asc" } });
}

// --- Create ----------------------------------------------------------------

async function createTicket(tenantId, userId, data) {
  const { subject, module, feature, categoryId, priority = "MEDIUM", description, currentUrl, browserInfo, deviceInfo, screenResolution, appVersion } = data;
  if (!subject?.trim()) throw new ApiError(400, "Subject is required");
  if (!description?.trim()) throw new ApiError(400, "Description is required");

  const sla = await computeSlaDates(priority);

  const ticket = await prisma.$transaction(async (tx) => {
    const tenant = await tx.tenant.update({ where: { id: tenantId }, data: { nextTicketNumber: { increment: 1 } } });
    const assignedNumber = tenant.nextTicketNumber - 1;
    const ticketNumber = `TCK-${String(assignedNumber).padStart(6, "0")}`;

    const created = await tx.ticket.create({
      data: {
        tenantId,
        ticketNumber,
        subject: subject.trim(),
        module: module || null,
        feature: feature || null,
        categoryId: categoryId || null,
        priority,
        description: description.trim(),
        raisedByUserId: userId,
        currentUrl,
        browserInfo,
        deviceInfo,
        screenResolution,
        appVersion,
        capturedAt: new Date(),
        ...sla,
      },
    });

    await logActivity(tx, created.id, "CREATED", { description: `Ticket ${ticketNumber} created`, actorType: "TENANT_USER", actorId: userId });
    return created;
  });

  return shapeTicket(ticket);
}

// --- Tenant-side reads -------------------------------------------------------

async function listTicketsForTenant(tenantId, { status, priority, module, dateFrom, dateTo, search } = {}) {
  const where = { tenantId };
  if (status) where.status = status;
  if (priority) where.priority = priority;
  if (module) where.module = module;
  if (dateFrom || dateTo) {
    where.createdAt = {};
    if (dateFrom) where.createdAt.gte = new Date(dateFrom);
    if (dateTo) where.createdAt.lte = new Date(new Date(dateTo).getTime() + 86399999);
  }
  if (search) {
    where.OR = [{ subject: { contains: search } }, { ticketNumber: { contains: search } }];
  }
  const tickets = await prisma.ticket.findMany({ where, orderBy: { createdAt: "desc" }, include: { category: true } });
  return tickets.map(shapeTicket);
}

async function getTicketForTenant(tenantId, ticketId) {
  const ticket = await prisma.ticket.findFirst({ where: { id: ticketId, tenantId }, include: { category: true, slaPolicy: true } });
  if (!ticket) throw new ApiError(404, "Ticket not found");
  const [comments, attachments, activities] = await Promise.all([
    prisma.ticketComment.findMany({ where: { ticketId, isInternal: false }, orderBy: { createdAt: "asc" }, include: { attachments: true } }),
    prisma.ticketAttachment.findMany({ where: { ticketId }, orderBy: { createdAt: "desc" } }),
    // INTERNAL_NOTE_ADDED excluded - a tenant seeing "an internal note was
    // added" in their own timeline would reveal that internal discussion is
    // happening, even with the note's text already hidden. Same
    // server-side filtering discipline as the isInternal comment filter
    // above, not just a UI-level hide.
    prisma.ticketActivity.findMany({ where: { ticketId, type: { not: "INTERNAL_NOTE_ADDED" } }, orderBy: { createdAt: "desc" } }),
  ]);
  return { ticket: shapeTicket(ticket), comments, attachments, activities };
}

async function addReplyAsTenant(tenantId, userId, ticketId, body) {
  if (!body?.trim()) throw new ApiError(400, "Reply cannot be empty");
  const ticket = await prisma.ticket.findFirst({ where: { id: ticketId, tenantId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");

  return prisma.$transaction(async (tx) => {
    const comment = await tx.ticketComment.create({
      data: { ticketId, body: body.trim(), isInternal: false, authorType: "TENANT_USER", authorId: userId },
    });
    await logActivity(tx, ticketId, "REPLY_ADDED", { description: "Customer replied", actorType: "TENANT_USER", actorId: userId });
    // A customer reply on a ticket that was waiting on them moves it back
    // into the support team's queue - the one automatic status transition
    // in this module, mirroring how every real helpdesk behaves.
    if (ticket.status === "WAITING_CUSTOMER") {
      await tx.ticket.update({ where: { id: ticketId }, data: { status: "IN_PROGRESS" } });
      await logActivity(tx, ticketId, "STATUS_CHANGED", { description: "Waiting for Customer → In Progress (customer replied)", actorType: "SYSTEM" });
    }
    return comment;
  });
}

// Tenant-side Close is deliberately narrower than the admin's full
// changeStatus - a customer can only confirm a Resolved ticket is done
// (Resolved -> Closed), never arbitrarily change status, per spec
// ("Customer cannot... Change status").
async function closeTicketAsTenant(tenantId, userId, ticketId) {
  const ticket = await prisma.ticket.findFirst({ where: { id: ticketId, tenantId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");
  if (ticket.status !== "RESOLVED") throw new ApiError(409, "Only a Resolved ticket can be closed");

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { status: "CLOSED", closedAt: new Date() } });
    await logActivity(tx, ticketId, "CLOSED", { description: "Closed by customer", actorType: "TENANT_USER", actorId: userId });
    return shapeTicket(updated);
  });
}

async function reopenTicketAsTenant(tenantId, userId, ticketId) {
  const ticket = await prisma.ticket.findFirst({ where: { id: ticketId, tenantId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");
  if (!["RESOLVED", "CLOSED"].includes(ticket.status)) throw new ApiError(409, "Only a Resolved or Closed ticket can be reopened");

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { status: "REOPENED" } });
    await logActivity(tx, ticketId, "REOPENED", { actorType: "TENANT_USER", actorId: userId });
    return shapeTicket(updated);
  });
}

// --- Attachments -------------------------------------------------------------

async function addAttachment(ticketId, file, { commentId, isScreenshot, uploaderType, uploaderId }) {
  const attachment = await prisma.$transaction(async (tx) => {
    const created = await tx.ticketAttachment.create({
      data: {
        ticketId,
        commentId: commentId || null,
        fileName: file.originalname,
        fileUrl: `/uploads/tickets/${file.filename}`,
        mimeType: file.mimetype,
        fileSize: file.size,
        isScreenshot: !!isScreenshot,
        uploadedByType: uploaderType,
        uploadedById: uploaderId,
      },
    });
    await logActivity(tx, ticketId, isScreenshot ? "SCREENSHOT_UPLOADED" : "ATTACHMENT_UPLOADED", {
      description: file.originalname,
      actorType: uploaderType,
      actorId: uploaderId,
    });
    return created;
  });
  return attachment;
}

// --- Admin-side reads --------------------------------------------------------

function computeSlaStatus(ticket) {
  if (["RESOLVED", "CLOSED"].includes(ticket.status)) return "MET";
  if (!ticket.slaResolutionDueAt) return "NONE";
  return new Date(ticket.slaResolutionDueAt) < new Date() ? "BREACHED" : "ON_TRACK";
}

async function listAllTickets({ tenantId, plan, module, priority, status, assignedToAdminId, dateFrom, dateTo, search } = {}) {
  const where = {};
  if (tenantId) where.tenantId = tenantId;
  if (plan) where.tenant = { plan };
  if (module) where.module = module;
  if (priority) where.priority = priority;
  if (status) where.status = status;
  if (assignedToAdminId) where.assignedToAdminId = assignedToAdminId;
  if (dateFrom || dateTo) {
    where.createdAt = {};
    if (dateFrom) where.createdAt.gte = new Date(dateFrom);
    if (dateTo) where.createdAt.lte = new Date(new Date(dateTo).getTime() + 86399999);
  }
  if (search) {
    where.OR = [{ subject: { contains: search } }, { ticketNumber: { contains: search } }];
  }
  const tickets = await prisma.ticket.findMany({ where, orderBy: { createdAt: "desc" }, include: { category: true, tenant: { select: { id: true, name: true, plan: true } } } });

  // raisedByUserId/assignedToAdminId are plain strings, not Prisma
  // relations (see schema comment) - batch-resolved here in two queries
  // total instead of N+1 findUnique calls per ticket.
  const userIds = [...new Set(tickets.map((t) => t.raisedByUserId).filter(Boolean))];
  const adminIds = [...new Set(tickets.map((t) => t.assignedToAdminId).filter(Boolean))];
  const [users, admins] = await Promise.all([
    userIds.length ? prisma.user.findMany({ where: { id: { in: userIds } }, select: { id: true, name: true, email: true } }) : [],
    adminIds.length ? prisma.platformAdmin.findMany({ where: { id: { in: adminIds } }, select: { id: true, email: true } }) : [],
  ]);
  const userMap = new Map(users.map((u) => [u.id, u]));
  const adminMap = new Map(admins.map((a) => [a.id, a]));

  return tickets.map((t) => ({
    ...shapeTicket(t),
    raisedBy: userMap.get(t.raisedByUserId) || null,
    assignedToAdmin: adminMap.get(t.assignedToAdminId) || null,
    slaStatus: computeSlaStatus(t),
  }));
}

async function getTicketForAdmin(ticketId) {
  const ticket = await prisma.ticket.findUnique({
    where: { id: ticketId },
    include: { category: true, slaPolicy: true, tenant: { select: { id: true, name: true, plan: true, trn: true } } },
  });
  if (!ticket) throw new ApiError(404, "Ticket not found");
  const [raisedBy, assignedToAdmin, comments, attachments, activities, watchers] = await Promise.all([
    prisma.user.findUnique({ where: { id: ticket.raisedByUserId }, select: { id: true, name: true, email: true } }),
    ticket.assignedToAdminId ? prisma.platformAdmin.findUnique({ where: { id: ticket.assignedToAdminId }, select: { id: true, email: true } }) : null,
    prisma.ticketComment.findMany({ where: { ticketId }, orderBy: { createdAt: "asc" }, include: { attachments: true } }),
    prisma.ticketAttachment.findMany({ where: { ticketId }, orderBy: { createdAt: "desc" } }),
    prisma.ticketActivity.findMany({ where: { ticketId }, orderBy: { createdAt: "desc" } }),
    prisma.ticketWatcher.findMany({ where: { ticketId } }),
  ]);
  return { ticket: { ...shapeTicket(ticket), slaStatus: computeSlaStatus(ticket) }, raisedBy, assignedToAdmin, comments, attachments, activities, watchers };
}

async function addCommentAsAdmin(adminId, ticketId, { body, isInternal }) {
  if (!body?.trim()) throw new ApiError(400, "Message cannot be empty");
  const ticket = await prisma.ticket.findUnique({ where: { id: ticketId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");

  return prisma.$transaction(async (tx) => {
    const comment = await tx.ticketComment.create({
      data: { ticketId, body: body.trim(), isInternal: !!isInternal, authorType: "PLATFORM_ADMIN", authorId: adminId },
    });
    await logActivity(tx, ticketId, isInternal ? "INTERNAL_NOTE_ADDED" : "REPLY_ADDED", { actorType: "PLATFORM_ADMIN", actorId: adminId });
    if (!ticket.firstRespondedAt && !isInternal) {
      await tx.ticket.update({ where: { id: ticketId }, data: { firstRespondedAt: new Date() } });
    }
    return comment;
  });
}

async function assignTicket(adminId, ticketId, assignedToAdminId, { transfer = false } = {}) {
  const ticket = await prisma.ticket.findUnique({ where: { id: ticketId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");

  return prisma.$transaction(async (tx) => {
    const nextStatus = ticket.status === "NEW" ? "ASSIGNED" : ticket.status;
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { assignedToAdminId, status: nextStatus } });
    await logActivity(tx, ticketId, transfer ? "TRANSFERRED" : "ASSIGNED", { actorType: "PLATFORM_ADMIN", actorId: adminId });
    return shapeTicket(updated);
  });
}

async function changePriority(adminId, ticketId, priority) {
  const ticket = await prisma.ticket.findUnique({ where: { id: ticketId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");
  const sla = await computeSlaDates(priority);

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { priority, ...sla } });
    await logActivity(tx, ticketId, "PRIORITY_CHANGED", { description: `${ticket.priority} → ${priority}`, actorType: "PLATFORM_ADMIN", actorId: adminId });
    return shapeTicket(updated);
  });
}

const TERMINAL_TIMESTAMPS = {
  RESOLVED: "resolvedAt",
  CLOSED: "closedAt",
};

async function changeStatus(adminId, ticketId, status) {
  const ticket = await prisma.ticket.findUnique({ where: { id: ticketId } });
  if (!ticket) throw new ApiError(404, "Ticket not found");

  const data = { status };
  const timestampField = TERMINAL_TIMESTAMPS[status];
  if (timestampField) data[timestampField] = new Date();

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data });
    await logActivity(tx, ticketId, status === "RESOLVED" ? "RESOLVED" : status === "CLOSED" ? "CLOSED" : "STATUS_CHANGED", {
      description: `${ticket.status} → ${status}`,
      actorType: "PLATFORM_ADMIN",
      actorId: adminId,
    });
    return shapeTicket(updated);
  });
}

async function addWatcher(adminId, ticketId, { watcherType, watcherId }) {
  const watcher = await prisma.ticketWatcher.upsert({
    where: { ticketId_watcherType_watcherId: { ticketId, watcherType, watcherId } },
    create: { ticketId, watcherType, watcherId },
    update: {},
  });
  await logActivity(null, ticketId, "WATCHER_ADDED", { actorType: "PLATFORM_ADMIN", actorId: adminId });
  return watcher;
}

async function removeWatcher(ticketId, watcherId) {
  await prisma.ticketWatcher.delete({ where: { id: watcherId } }).catch(() => {});
}

async function mergeTicket(adminId, ticketId, intoTicketId) {
  if (ticketId === intoTicketId) throw new ApiError(400, "A ticket can't be merged into itself");
  const [ticket, target] = await Promise.all([prisma.ticket.findUnique({ where: { id: ticketId } }), prisma.ticket.findUnique({ where: { id: intoTicketId } })]);
  if (!ticket || !target) throw new ApiError(404, "Ticket not found");

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { mergedIntoTicketId: intoTicketId, status: "CLOSED", closedAt: new Date() } });
    await logActivity(tx, ticketId, "MERGED", { description: `Merged into ${target.ticketNumber}`, actorType: "PLATFORM_ADMIN", actorId: adminId });
    await logActivity(tx, intoTicketId, "MERGED", { description: `${ticket.ticketNumber} merged into this ticket`, actorType: "PLATFORM_ADMIN", actorId: adminId });
    return shapeTicket(updated);
  });
}

async function linkTicket(adminId, ticketId, linkedTicketId) {
  if (ticketId === linkedTicketId) throw new ApiError(400, "A ticket can't be linked to itself");
  const [ticket, target] = await Promise.all([prisma.ticket.findUnique({ where: { id: ticketId } }), prisma.ticket.findUnique({ where: { id: linkedTicketId } })]);
  if (!ticket || !target) throw new ApiError(404, "Ticket not found");

  const currentLinks = parseJson(ticket.linkedTicketIds, []);
  if (currentLinks.includes(linkedTicketId)) return shapeTicket(ticket);
  const nextLinks = [...currentLinks, linkedTicketId];

  return prisma.$transaction(async (tx) => {
    const updated = await tx.ticket.update({ where: { id: ticketId }, data: { linkedTicketIds: JSON.stringify(nextLinks) } });
    // Symmetric - linking is a two-way relationship.
    const targetLinks = parseJson(target.linkedTicketIds, []);
    if (!targetLinks.includes(ticketId)) {
      await tx.ticket.update({ where: { id: linkedTicketId }, data: { linkedTicketIds: JSON.stringify([...targetLinks, ticketId]) } });
    }
    await logActivity(tx, ticketId, "LINKED", { description: `Linked to ${target.ticketNumber}`, actorType: "PLATFORM_ADMIN", actorId: adminId });
    return shapeTicket(updated);
  });
}

// --- Dashboard ---------------------------------------------------------------

async function getDashboardStats() {
  const [open, assigned, inProgress, waitingCustomer, resolved, closed, critical, all] = await Promise.all([
    prisma.ticket.count({ where: { status: "NEW" } }),
    prisma.ticket.count({ where: { status: "ASSIGNED" } }),
    prisma.ticket.count({ where: { status: "IN_PROGRESS" } }),
    prisma.ticket.count({ where: { status: "WAITING_CUSTOMER" } }),
    prisma.ticket.count({ where: { status: "RESOLVED" } }),
    prisma.ticket.count({ where: { status: "CLOSED" } }),
    prisma.ticket.count({ where: { priority: "CRITICAL", status: { in: OPEN_STATUSES } } }),
    prisma.ticket.findMany({ where: { status: { in: OPEN_STATUSES }, slaResolutionDueAt: { not: null } }, select: { slaResolutionDueAt: true } }),
  ]);
  const slaBreached = all.filter((t) => new Date(t.slaResolutionDueAt) < new Date()).length;

  return { open, assigned, inProgress, waitingCustomer, resolved, closed, critical, slaBreached };
}

module.exports = {
  listCategories,
  listSlaPolicies,
  listAssignableAdmins,
  createTicket,
  listTicketsForTenant,
  getTicketForTenant,
  addReplyAsTenant,
  closeTicketAsTenant,
  reopenTicketAsTenant,
  addAttachment,
  listAllTickets,
  getTicketForAdmin,
  addCommentAsAdmin,
  assignTicket,
  changePriority,
  changeStatus,
  addWatcher,
  removeWatcher,
  mergeTicket,
  linkTicket,
  getDashboardStats,
};
