// Registry of "how do I actually apply this change" functions, keyed by
// "<entityType>.<action>" (e.g. "Customer.create", "Invoice.send"). This is
// the ONLY per-module code the Maker-Checker engine requires - everything
// else (rule lookup, pending state, queue, history, audit trail) lives once
// in approvalEngine.service.js. An executor is called identically whether
// the action runs immediately (no approval rule configured) or later, from a
// completely separate HTTP request, when a checker approves a pending
// request - so it can never be a closure captured at submit time, it must be
// resolvable from stored data (entityType/action/entityId/payload) alone.
//
// Each executor receives { tenantId, entityId, payload } and returns the
// resulting entity (or null for actions with no single resulting row).
// Registered here module by module as each is integrated (see
// docs/features - Maker-Checker rollout phases); empty entries throw a clear
// error rather than failing silently.
const EXECUTORS = {};

function registerExecutor(entityType, action, fn) {
  EXECUTORS[`${entityType}.${action}`] = fn;
}

function getExecutor(entityType, action) {
  return EXECUTORS[`${entityType}.${action}`];
}

// --- Pilot integration (Phase 2) ---------------------------------------
// Each function here is the same Prisma write the controller used to do
// inline, moved out so it's resolvable by name alone when a checker
// approves a request in a later, separate HTTP request. Controllers keep
// their existing validation; they just call dispatch() instead of writing
// directly. Requiring here (not at module top) avoids a require cycle,
// since these controllers don't otherwise need to know this file exists.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");

registerExecutor("Customer", "create", async ({ tenantId, payload }) => {
  return prisma.customer.create({ data: { tenantId, ...payload } });
});

registerExecutor("Customer", "update", async ({ entityId, payload }) => {
  return prisma.customer.update({ where: { id: entityId }, data: payload });
});

// invoice.controller.js requires this file (indirectly, via
// approvalEngine.service.js) to send its own actions through dispatch() -
// requiring it back at module-load time here would be a circular require
// resolved to a not-yet-populated module.exports. Requiring it lazily,
// inside the executor, sidesteps that: by the time this actually runs
// (a real request, after server startup finished), the module cache
// already holds the fully-loaded controller.
// issueDate honoring (Import Framework, 2026-08-09) now lives once in
// sendInvoiceTx (invoice.controller.js), shared with the import adapter -
// this executor is just the resolvable-by-name entry point into it, same
// pattern as the CreditNote/DebitNote executors below.
registerExecutor("Invoice", "send", async ({ tenantId, entityId }) => {
  const { sendInvoiceTx } = require("../controllers/invoice.controller");
  return prisma.$transaction((tx) => sendInvoiceTx(tx, tenantId, entityId));
});

// --- Tax Master (2026-08-06) ---------------------------------------------
// Every executor here writes its own TaxRateAuditLog entry - this is
// deliberately module-specific (the generic engine has no opinion on what
// "old value/new value" means for a tax rate), but it's still the ONE place
// per action where the real mutation happens, immediate or post-approval
// alike, so "every tax modification creates an audit entry" holds
// unconditionally. approvalStatus on the log is "APPROVED" when viaApproval
// is true (this only runs on the APPROVE branch of decide(), never REJECT),
// otherwise null (no Maker-Checker rule was active).
function taxRateSnapshot(rate) {
  return {
    name: rate.name,
    percentage: rate.percentage,
    calculationMethod: rate.calculationMethod,
    effectiveFrom: rate.effectiveFrom,
    effectiveTo: rate.effectiveTo,
    status: rate.status,
    notes: rate.notes,
  };
}

function writeTaxRateAudit(tx, { tenantId, taxRateId, taxRateName, action, oldValue, newValue, actorId, reason, applicableFrom, ipAddress, viaApproval }) {
  return tx.taxRateAuditLog.create({
    data: {
      tenantId,
      taxRateId,
      taxRateName,
      action,
      oldValue: oldValue ? JSON.stringify(oldValue) : null,
      newValue: newValue ? JSON.stringify(newValue) : null,
      changedBy: actorId,
      reason: reason || null,
      applicableFrom: applicableFrom || null,
      ipAddress: ipAddress || null,
      approvalStatus: viaApproval ? "APPROVED" : null,
    },
  });
}

registerExecutor("TaxRate", "create", async ({ tenantId, payload, actorId, ipAddress, viaApproval }) => {
  return prisma.$transaction(async (tx) => {
    const rate = await tx.taxRate.create({
      data: { tenantId, ...payload, version: 1, isCurrentVersion: true, createdBy: actorId },
    });
    await writeTaxRateAudit(tx, {
      tenantId,
      taxRateId: rate.id,
      taxRateName: rate.name,
      action: "CREATED",
      newValue: taxRateSnapshot(rate),
      actorId,
      applicableFrom: rate.effectiveFrom,
      ipAddress,
      viaApproval,
    });
    return rate;
  });
});

// "Create New Version" - never touches the old row's value fields, only
// closes its window and flips isCurrentVersion so it becomes read-only.
registerExecutor("TaxRate", "update", async ({ tenantId, entityId, payload, actorId, ipAddress, viaApproval }) => {
  return prisma.$transaction(async (tx) => {
    const old = await tx.taxRate.findFirst({ where: { id: entityId, tenantId } });
    if (!old) throw new ApiError(404, "Tax rate not found");

    const newFrom = new Date(payload.effectiveFrom);
    const shouldCloseOld = !old.effectiveTo || new Date(old.effectiveTo) > newFrom;

    await tx.taxRate.update({
      where: { id: old.id },
      data: {
        isCurrentVersion: false,
        ...(shouldCloseOld ? { effectiveTo: newFrom } : {}),
        updatedBy: actorId,
      },
    });

    const { reason, ...rateFields } = payload;
    const created = await tx.taxRate.create({
      data: {
        tenantId,
        ...rateFields,
        version: old.version + 1,
        isCurrentVersion: true,
        createdBy: actorId,
        reason: reason || null,
      },
    });

    await writeTaxRateAudit(tx, {
      tenantId,
      taxRateId: created.id,
      taxRateName: created.name,
      action: "NEW_VERSION",
      oldValue: taxRateSnapshot(old),
      newValue: taxRateSnapshot(created),
      actorId,
      reason,
      applicableFrom: created.effectiveFrom,
      ipAddress,
      viaApproval,
    });

    return created;
  });
});

function registerStatusExecutor(action, status) {
  registerExecutor("TaxRate", action, async ({ tenantId, entityId, payload, actorId, ipAddress, viaApproval }) => {
    return prisma.$transaction(async (tx) => {
      const old = await tx.taxRate.findFirst({ where: { id: entityId, tenantId } });
      if (!old) throw new ApiError(404, "Tax rate not found");

      const updated = await tx.taxRate.update({ where: { id: old.id }, data: { status, updatedBy: actorId } });

      await writeTaxRateAudit(tx, {
        tenantId,
        taxRateId: updated.id,
        taxRateName: updated.name,
        action: status === "ACTIVE" ? "ACTIVATED" : "DEACTIVATED",
        oldValue: { status: old.status },
        newValue: { status: updated.status },
        actorId,
        reason: payload?.reason,
        ipAddress,
        viaApproval,
      });

      return updated;
    });
  });
}
registerStatusExecutor("activate", "ACTIVE");
registerStatusExecutor("deactivate", "INACTIVE");

// --- Credit Notes / Debit Notes (2026-08-08) -----------------------------
// Same lazy-require pattern as "Invoice.send" above (avoids the require
// cycle: creditNote.controller.js -> approvalEngine.service.js ->
// approvalExecutors.js -> creditNote.controller.js). The controller's own
// issueCreditNoteTx()/issueDebitNoteTx() already contains the ENTIRE
// numbering-assignment + remaining-amount-recheck transaction - this
// executor is just the resolvable-by-name entry point into it, identical
// whether called immediately or from a checker's later approve() call.
registerExecutor("CreditNote", "issue", async ({ tenantId, entityId, actorId }) => {
  const { issueCreditNoteTx } = require("../controllers/creditNote.controller");
  return prisma.$transaction((tx) => issueCreditNoteTx(tx, tenantId, entityId, actorId));
});

registerExecutor("DebitNote", "issue", async ({ tenantId, entityId, actorId }) => {
  const { issueDebitNoteTx } = require("../controllers/debitNote.controller");
  return prisma.$transaction((tx) => issueDebitNoteTx(tx, tenantId, entityId, actorId));
});

// Sales Debit Note (2026-08-11) - same resolvable-by-name pattern as
// CreditNote/DebitNote above, one level newer.
registerExecutor("SalesDebitNote", "issue", async ({ tenantId, entityId, actorId }) => {
  const { issueSalesDebitNoteTx } = require("../controllers/salesDebitNote.controller");
  return prisma.$transaction((tx) => issueSalesDebitNoteTx(tx, tenantId, entityId, actorId));
});

registerExecutor("TaxRate", "delete", async ({ tenantId, entityId, payload, actorId, ipAddress, viaApproval }) => {
  return prisma.$transaction(async (tx) => {
    const old = await tx.taxRate.findFirst({ where: { id: entityId, tenantId } });
    if (!old) throw new ApiError(404, "Tax rate not found");

    await writeTaxRateAudit(tx, {
      tenantId,
      taxRateId: old.id,
      taxRateName: old.name,
      action: "DELETED",
      oldValue: taxRateSnapshot(old),
      actorId,
      reason: payload?.reason,
      ipAddress,
      viaApproval,
    });

    await tx.taxRate.delete({ where: { id: old.id } });
    return null;
  });
});

// --- Import Framework (2026-08-09, migration engine hardened 2026-08-22) --
// Batch-level approval (Phase 1 decision - see the Import Framework plan):
// one ApprovalRequest for the whole ImportBatch when imports.commit's rule
// is active, not one per row. startMigration() returns immediately (QUEUED)
// and processes the batch in the background (see importEngine.service.js's
// migration engine) - this executor is just the resolvable-by-name entry
// point into it, identical whether it runs immediately or from a checker's
// later decide() call. It does NOT await the migration finishing - only
// starting it - so a checker's approval action itself stays fast even for a
// 100,000+ row batch.
registerExecutor("ImportBatch", "commit", async ({ tenantId, entityId, actorId }) => {
  const importEngine = require("./importEngine.service");
  return importEngine.startMigration({ tenantId, batchId: entityId, actorId });
});

module.exports = { registerExecutor, getExecutor };
