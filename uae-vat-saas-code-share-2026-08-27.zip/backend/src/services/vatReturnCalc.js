const prisma = require("../config/prisma");
const { round2 } = require("./invoiceCalc");

// VAT Return is read-only and never creates accounting data - this service
// only ever aggregates existing Invoice/PurchaseBill rows for a period. Only
// SENT invoices and RECORDED purchase bills are included (matching each
// module's own "this is final" status) - Draft and Void are always excluded
// from the real numbers; see computeValidationWarnings() below for the
// separate, purely informational check that surfaces near-miss Drafts/Voids
// so the user doesn't forget about them, without ever including them here.

const CLASSIFICATIONS = ["STANDARD_RATED", "ZERO_RATED", "EXEMPT", "OUT_OF_SCOPE"];

// A line item with no taxCategoryId at all (or a category whose
// classification somehow can't be read) has no VAT Return bucket
// information - treated as Out of Scope, the closest honest fallback.
function classificationOf(taxCategory) {
  return taxCategory?.classification || "OUT_OF_SCOPE";
}

function emptyBuckets() {
  return { STANDARD_RATED: 0, ZERO_RATED: 0, EXEMPT: 0, OUT_OF_SCOPE: 0 };
}

// Computes the period boundaries + a display label from periodType + a
// reference year/month (MONTHLY) or year/quarter (QUARTERLY). Done
// server-side so the client never has to duplicate month/quarter/timezone
// boundary math.
function computePeriodBounds(periodType, year, monthOrQuarter) {
  const y = Number(year);
  if (periodType === "MONTHLY") {
    const m = Number(monthOrQuarter); // 1-12
    const periodStart = new Date(Date.UTC(y, m - 1, 1, 0, 0, 0, 0));
    const periodEnd = new Date(Date.UTC(y, m, 0, 23, 59, 59, 999)); // last day of month
    const periodLabel = periodStart.toLocaleDateString("en-US", { month: "long", year: "numeric", timeZone: "UTC" });
    return { periodStart, periodEnd, periodLabel };
  }
  if (periodType === "QUARTERLY") {
    const q = Number(monthOrQuarter); // 1-4
    const startMonth = (q - 1) * 3;
    const periodStart = new Date(Date.UTC(y, startMonth, 1, 0, 0, 0, 0));
    const periodEnd = new Date(Date.UTC(y, startMonth + 3, 0, 23, 59, 59, 999));
    const periodLabel = `Q${q} ${y}`;
    return { periodStart, periodEnd, periodLabel };
  }
  return null;
}

// The auto-generation engine - "no manual calculation." Buckets every
// eligible line item's taxable amount by its Tax Master category's
// classification, and sums VAT straight from each line's own frozen
// snapshot (never re-resolved against current Tax Master, same
// immutability principle Invoice/Purchase already follow).
async function aggregatePeriod(tenantId, periodStart, periodEnd) {
  const invoices = await prisma.invoice.findMany({
    where: { tenantId, status: "SENT", issueDate: { gte: periodStart, lte: periodEnd } },
    include: { lineItems: { include: { taxCategory: true } } },
  });
  const purchases = await prisma.purchaseBill.findMany({
    where: { tenantId, status: "RECORDED", purchaseDate: { gte: periodStart, lte: periodEnd } },
    include: { lineItems: { include: { taxCategory: true } } },
  });
  // Credit/Debit Notes (2026-08-08) - only ISSUED notes ever affect VAT
  // (DRAFT/PENDING-approval/VOID are excluded by construction, since
  // "PENDING approval" never reaches ISSUED status at all). Scoped by the
  // NOTE's own issueDate, never the original document's period - a note
  // issued in a later period than its original Invoice/Purchase affects
  // only the period it actually falls in, exactly like every other
  // date-scoped row in this aggregation. The original Invoice/Purchase
  // query above is completely untouched by this addition.
  const creditNotes = await prisma.creditNote.findMany({
    where: { tenantId, status: "ISSUED", issueDate: { gte: periodStart, lte: periodEnd } },
    include: { lineItems: { include: { taxCategory: true } } },
  });
  const debitNotes = await prisma.debitNote.findMany({
    where: { tenantId, status: "ISSUED", issueDate: { gte: periodStart, lte: periodEnd } },
    include: { lineItems: { include: { taxCategory: true } } },
  });
  // Sales Debit Note (2026-08-11) - increases an Invoice, the sales-side
  // mirror of debitNotes above (which increases a PurchaseBill). Same
  // ISSUED-only/own-issueDate scoping rule.
  const salesDebitNotes = await prisma.salesDebitNote.findMany({
    where: { tenantId, status: "ISSUED", issueDate: { gte: periodStart, lte: periodEnd } },
    include: { lineItems: { include: { taxCategory: true } } },
  });

  const salesBuckets = emptyBuckets();
  const purchaseBuckets = emptyBuckets();
  let outputVat = 0;
  let inputVat = 0;

  for (const inv of invoices) {
    for (const li of inv.lineItems) {
      const cls = classificationOf(li.taxCategory);
      salesBuckets[cls] = round2(salesBuckets[cls] + li.lineTaxableAmount);
      outputVat = round2(outputVat + li.lineTaxAmount);
    }
  }
  for (const p of purchases) {
    for (const li of p.lineItems) {
      const cls = classificationOf(li.taxCategory);
      purchaseBuckets[cls] = round2(purchaseBuckets[cls] + li.lineTaxableAmount);
      inputVat = round2(inputVat + li.lineTaxAmount);
    }
  }
  // Credit Note reduces sales/output VAT - subtracted from the same
  // classification buckets an Invoice line would have added to, using the
  // note line's own taxCategory (copied from the original Invoice line, see
  // creditNote.controller.js) so it nets against the correct bucket even if
  // Tax Master's category has since been edited.
  for (const cn of creditNotes) {
    for (const li of cn.lineItems) {
      const cls = classificationOf(li.taxCategory);
      salesBuckets[cls] = round2(salesBuckets[cls] - li.lineTaxableAmount);
      outputVat = round2(outputVat - li.lineTaxAmount);
    }
  }
  // Debit Note increases purchase/input VAT - added to the same buckets a
  // Purchase Bill line would have added to.
  for (const dn of debitNotes) {
    for (const li of dn.lineItems) {
      const cls = classificationOf(li.taxCategory);
      purchaseBuckets[cls] = round2(purchaseBuckets[cls] + li.lineTaxableAmount);
      inputVat = round2(inputVat + li.lineTaxAmount);
    }
  }
  // Sales Debit Note increases sales/output VAT - added to the same buckets
  // an Invoice line would have added to (the opposite of Credit Note above).
  for (const sdn of salesDebitNotes) {
    for (const li of sdn.lineItems) {
      const cls = classificationOf(li.taxCategory);
      salesBuckets[cls] = round2(salesBuckets[cls] + li.lineTaxableAmount);
      outputVat = round2(outputVat + li.lineTaxAmount);
    }
  }

  const creditNotesTotal = round2(creditNotes.reduce((s, c) => s + c.grandTotal, 0));
  const debitNotesTotal = round2(debitNotes.reduce((s, d) => s + d.grandTotal, 0));
  const salesDebitNotesTotal = round2(salesDebitNotes.reduce((s, d) => s + d.grandTotal, 0));
  const totalSales = round2(invoices.reduce((s, i) => s + i.grandTotal, 0) - creditNotesTotal + salesDebitNotesTotal);
  const totalPurchases = round2(purchases.reduce((s, p) => s + p.grandTotal, 0) + debitNotesTotal);
  // Recoverable VAT = Input VAT for Sprint 1 (confirmed decision - no
  // blocked-expense-category modeling yet). Kept as its own returned field
  // so a future sprint can diverge it without touching every call site.
  const recoverableVat = inputVat;
  const netVatPayable = round2(outputVat - recoverableVat);

  return {
    standardRatedSales: salesBuckets.STANDARD_RATED,
    zeroRatedSales: salesBuckets.ZERO_RATED,
    exemptSales: salesBuckets.EXEMPT,
    outOfScopeSales: salesBuckets.OUT_OF_SCOPE,
    standardRatedPurchases: purchaseBuckets.STANDARD_RATED,
    zeroRatedPurchases: purchaseBuckets.ZERO_RATED,
    exemptPurchases: purchaseBuckets.EXEMPT,
    outOfScopePurchases: purchaseBuckets.OUT_OF_SCOPE,
    outputVat,
    inputVat,
    recoverableVat,
    netVatPayable,
    totalSales,
    totalPurchases,
    salesInvoiceCount: invoices.length,
    purchaseBillCount: purchases.length,
    // Not persisted on VatReturn (no schema change) - returned here so the
    // generation response/UI can show the note counts without a new column;
    // see vatReturn.controller.js.
    creditNoteCount: creditNotes.length,
    debitNoteCount: debitNotes.length,
    salesDebitNoteCount: salesDebitNotes.length,
    creditNotesTotal,
    debitNotesTotal,
    salesDebitNotesTotal,
  };
}

// Purely informational - never blocks generation, never changes the
// aggregated totals above. Two different kinds of thing get flagged: real
// data-quality gaps *within* what's actually included (missing TRN/tax
// category/invalid mapping), and near-miss transactions that look like they
// belong to this period but were correctly excluded because they're not yet
// final (Draft) or were cancelled (Void) - surfaced so the user notices
// before filing, not because they're wrongly included.
async function computeValidationWarnings(tenantId, periodStart, periodEnd) {
  const warnings = [];

  const [invoices, purchases, draftInvoices, draftPurchases, voidInvoices, voidPurchases] = await Promise.all([
    prisma.invoice.findMany({
      where: { tenantId, status: "SENT", issueDate: { gte: periodStart, lte: periodEnd } },
      include: { lineItems: { include: { taxCategory: true } } },
    }),
    prisma.purchaseBill.findMany({
      where: { tenantId, status: "RECORDED", purchaseDate: { gte: periodStart, lte: periodEnd } },
      include: { lineItems: { include: { taxCategory: true } } },
    }),
    prisma.invoice.findMany({ where: { tenantId, status: "DRAFT", createdAt: { gte: periodStart, lte: periodEnd } } }),
    prisma.purchaseBill.findMany({ where: { tenantId, status: "DRAFT", purchaseDate: { gte: periodStart, lte: periodEnd } } }),
    prisma.invoice.findMany({ where: { tenantId, status: "VOID", issueDate: { gte: periodStart, lte: periodEnd } } }),
    prisma.purchaseBill.findMany({ where: { tenantId, status: "VOID", purchaseDate: { gte: periodStart, lte: periodEnd } } }),
  ]);

  const missingTrnInvoices = invoices.filter((i) => !i.customerTrn);
  const missingTrnPurchases = purchases.filter((p) => !p.vendorTrn);
  if (missingTrnInvoices.length > 0) {
    warnings.push({ code: "MISSING_TRN_SALES", message: `${missingTrnInvoices.length} sales invoice(s) in this period have no Customer TRN.`, count: missingTrnInvoices.length });
  }
  if (missingTrnPurchases.length > 0) {
    warnings.push({ code: "MISSING_TRN_PURCHASES", message: `${missingTrnPurchases.length} purchase bill(s) in this period have no Vendor TRN.`, count: missingTrnPurchases.length });
  }

  const missingCategorySalesLines = invoices.flatMap((i) => i.lineItems.filter((li) => !li.taxCategoryId));
  const missingCategoryPurchaseLines = purchases.flatMap((p) => p.lineItems.filter((li) => !li.taxCategoryId));
  if (missingCategorySalesLines.length > 0) {
    warnings.push({ code: "MISSING_TAX_CATEGORY_SALES", message: `${missingCategorySalesLines.length} sales line item(s) have no Tax Category assigned (treated as Out of Scope).`, count: missingCategorySalesLines.length });
  }
  if (missingCategoryPurchaseLines.length > 0) {
    warnings.push({ code: "MISSING_TAX_CATEGORY_PURCHASES", message: `${missingCategoryPurchaseLines.length} purchase line item(s) have no Tax Category assigned (treated as Out of Scope).`, count: missingCategoryPurchaseLines.length });
  }

  const invalidMappingSalesLines = invoices.flatMap((i) => i.lineItems.filter((li) => li.taxCategoryId && !li.taxCategory));
  const invalidMappingPurchaseLines = purchases.flatMap((p) => p.lineItems.filter((li) => li.taxCategoryId && !li.taxCategory));
  const invalidCount = invalidMappingSalesLines.length + invalidMappingPurchaseLines.length;
  if (invalidCount > 0) {
    warnings.push({ code: "INVALID_TAX_MAPPING", message: `${invalidCount} line item(s) reference a Tax Category that no longer exists.`, count: invalidCount });
  }

  const missingVatAmountLines = [...invoices.flatMap((i) => i.lineItems), ...purchases.flatMap((p) => p.lineItems)].filter(
    (li) => li.taxCategoryId && !li.taxRateId
  );
  if (missingVatAmountLines.length > 0) {
    warnings.push({ code: "MISSING_VAT_AMOUNT", message: `${missingVatAmountLines.length} line item(s) have a Tax Category but no resolved VAT amount.`, count: missingVatAmountLines.length });
  }

  if (draftInvoices.length > 0) {
    warnings.push({ code: "DRAFT_SALES_NEAR_PERIOD", message: `${draftInvoices.length} Draft invoice(s) created in this period are not included - send them first if they belong in this return.`, count: draftInvoices.length });
  }
  if (draftPurchases.length > 0) {
    warnings.push({ code: "DRAFT_PURCHASES_NEAR_PERIOD", message: `${draftPurchases.length} Draft purchase bill(s) dated in this period are not included - record them first if they belong in this return.`, count: draftPurchases.length });
  }
  if (voidInvoices.length > 0) {
    warnings.push({ code: "VOID_SALES_IN_PERIOD", message: `${voidInvoices.length} cancelled invoice(s) fall in this period and were correctly excluded.`, count: voidInvoices.length });
  }
  if (voidPurchases.length > 0) {
    warnings.push({ code: "VOID_PURCHASES_IN_PERIOD", message: `${voidPurchases.length} cancelled purchase bill(s) fall in this period and were correctly excluded.`, count: voidPurchases.length });
  }

  return warnings;
}

module.exports = { CLASSIFICATIONS, computePeriodBounds, aggregatePeriod, computeValidationWarnings };
