// The one centralized Maker-Checker workflow implementation - every
// integrated module's mutating controller calls dispatch() instead of
// writing directly to its own table; every approve/reject action calls
// decide(). Neither function contains any module-specific logic - the only
// per-module code in this feature is the small executor registered in
// approvalExecutors.js. See docs (Approval Workflow) for the full design.
//
// Division of responsibility with RBAC (never re-implemented here):
//   - RBAC (requireTenantUser + requirePermission) decides WHO may call an
//     endpoint at all - every route this module exposes is still gated the
//     normal way.
//   - This engine only decides WHETHER a permitted action executes
//     immediately or must wait for a second party's decision, plus the
//     maker-cannot-approve-own-request and specific-approver-role checks
//     that RBAC's route-level permission check can't express.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { getExecutor } = require("./approvalExecutors");

function toJson(value) {
  return value === undefined || value === null ? null : JSON.stringify(value);
}
function fromJson(value) {
  return value ? JSON.parse(value) : null;
}

// Serializes an ApprovalRequest row for API responses - parses the JSON
// string columns back into objects so callers never see raw JSON text.
function serialize(request) {
  if (!request) return request;
  return {
    ...request,
    payload: fromJson(request.payload),
    previousValues: fromJson(request.previousValues),
  };
}

// Looks up the tenant's rule for a permission key, or null if none is
// configured (= Immediate Execution, the default for every action until a
// tenant explicitly turns approval on). A row with isActive=false is treated
// the same as no row at all.
async function getActiveRule(tenantId, permissionKey) {
  const permission = await prisma.permission.findUnique({ where: { key: permissionKey } });
  if (!permission) return null;

  const rule = await prisma.permissionApprovalRule.findUnique({
    where: { tenantId_permissionId: { tenantId, permissionId: permission.id } },
  });
  if (!rule || !rule.isActive) return null;
  return rule;
}

// actorId/ipAddress/viaApproval are passed through so an executor that needs
// to write its own module-specific audit trail (e.g. Tax Master) can - the
// engine itself never reads or writes them. actorId is always the original
// maker (requestedBy), never the checker, so authorship attribution stays
// correct regardless of when the executor actually runs.
async function runExecutor(entityType, action, { tenantId, entityId, payload, actorId, ipAddress = null, viaApproval = false }) {
  const executor = getExecutor(entityType, action);
  if (!executor) {
    throw new ApiError(501, `No approval executor is registered for ${entityType}.${action} yet`);
  }
  return executor({ tenantId, entityId, payload, actorId, ipAddress, viaApproval });
}

async function assertNoOpenRequest(tx, { tenantId, entityType, entityId }) {
  if (!entityId) return; // pending CREATE - nothing to collide with yet
  const open = await tx.approvalRequest.findFirst({
    where: { tenantId, entityType, entityId, status: "PENDING" },
  });
  if (open) {
    throw new ApiError(409, `${entityType} ${entityId} already has a pending approval request (${open.referenceNumber})`);
  }
}

// The single entry point every integrated controller calls in place of its
// own direct mutation. Returns either the immediately-executed result or a
// newly-created PENDING ApprovalRequest - callers branch on `status`.
async function dispatch({ tenantId, userId, permissionKey, module, action, entityType, entityId = null, payload, previousValues = null, reason = null, ipAddress = null }) {
  const rule = await getActiveRule(tenantId, permissionKey);

  if (!rule || !rule.requiresApproval) {
    const entity = await runExecutor(entityType, action, { tenantId, entityId, payload, actorId: userId, ipAddress, viaApproval: false });
    return { status: "EXECUTED", entity };
  }

  const approvalRequest = await prisma.$transaction(async (tx) => {
    await assertNoOpenRequest(tx, { tenantId, entityType, entityId });

    const tenant = await tx.tenant.update({
      where: { id: tenantId },
      data: { nextApprovalNumber: { increment: 1 } },
    });
    const referenceNumber = `APR-${String(tenant.nextApprovalNumber - 1).padStart(6, "0")}`;

    const created = await tx.approvalRequest.create({
      data: {
        tenantId,
        referenceNumber,
        module,
        action,
        entityType,
        entityId,
        payload: toJson(payload),
        previousValues: toJson(previousValues),
        status: "PENDING",
        requestedBy: userId,
        reason,
        ipAddress,
      },
    });

    await tx.approvalActivity.create({
      data: { approvalRequestId: created.id, type: "SUBMITTED", actorId: userId },
    });

    return created;
  });

  return { status: "PENDING", approvalRequest: serialize(approvalRequest) };
}

// APPROVE or REJECT a PENDING request. Enforces maker != checker and (if the
// rule specifies one) a specific approver role, on top of the route-level
// requirePermission("<module>.approve"/"<module>.reject") RBAC already ran.
async function decide({ approvalRequestId, tenantId, deciderUserId, decision, comments = null }) {
  if (!["APPROVE", "REJECT"].includes(decision)) {
    throw new ApiError(400, "decision must be APPROVE or REJECT");
  }

  const request = await prisma.approvalRequest.findFirst({ where: { id: approvalRequestId, tenantId } });
  if (!request) throw new ApiError(404, "Approval request not found");
  if (request.status !== "PENDING") {
    throw new ApiError(400, `This request has already been ${request.status.toLowerCase()}`);
  }

  const permissionKey = `${request.module}.${request.action}`;
  const rule = await getActiveRule(tenantId, permissionKey);

  if ((rule?.makerCannotApproveOwn ?? true) && request.requestedBy === deciderUserId) {
    throw new ApiError(403, "You cannot approve or reject your own request");
  }

  if (rule?.approverRoleId) {
    const deciderRole = await prisma.userRole.findFirst({ where: { userId: deciderUserId, isPrimary: true } });
    if (deciderRole?.roleId !== rule.approverRoleId) {
      const approverRole = await prisma.role.findUnique({ where: { id: rule.approverRoleId } });
      throw new ApiError(403, `This request must be decided by a user with the "${approverRole?.name || "assigned"}" role`);
    }
  }

  if (decision === "REJECT") {
    const updated = await prisma.$transaction(async (tx) => {
      const result = await tx.approvalRequest.update({
        where: { id: request.id },
        data: { status: "REJECTED", decidedBy: deciderUserId, decidedAt: new Date(), decisionComments: comments },
      });
      await tx.approvalActivity.create({
        data: { approvalRequestId: request.id, type: "REJECTED", actorId: deciderUserId, comment: comments },
      });
      return result;
    });
    return serialize(updated);
  }

  // APPROVE - run the executor, then record the outcome in the same transaction context.
  // actorId is the original maker (request.requestedBy), not the checker
  // deciding right now, so authorship on the resulting record stays correct.
  const entity = await runExecutor(request.entityType, request.action, {
    tenantId,
    entityId: request.entityId,
    payload: fromJson(request.payload),
    actorId: request.requestedBy,
    ipAddress: request.ipAddress,
    viaApproval: true,
  });

  const updated = await prisma.$transaction(async (tx) => {
    const result = await tx.approvalRequest.update({
      where: { id: request.id },
      data: {
        status: "APPROVED",
        decidedBy: deciderUserId,
        decidedAt: new Date(),
        decisionComments: comments,
        resultingEntityId: request.entityId || entity?.id || null,
      },
    });
    await tx.approvalActivity.create({
      data: { approvalRequestId: request.id, type: "APPROVED", actorId: deciderUserId, comment: comments },
    });
    return result;
  });

  return serialize(updated);
}

// Lets the maker withdraw their own still-open request.
async function cancel({ approvalRequestId, tenantId, userId }) {
  const request = await prisma.approvalRequest.findFirst({ where: { id: approvalRequestId, tenantId } });
  if (!request) throw new ApiError(404, "Approval request not found");
  if (request.status !== "PENDING") throw new ApiError(400, "Only a pending request can be cancelled");
  if (request.requestedBy !== userId) throw new ApiError(403, "Only the requester can cancel their own request");

  const updated = await prisma.$transaction(async (tx) => {
    const result = await tx.approvalRequest.update({
      where: { id: request.id },
      data: { status: "CANCELLED", decidedBy: userId, decidedAt: new Date() },
    });
    await tx.approvalActivity.create({ data: { approvalRequestId: request.id, type: "CANCELLED", actorId: userId } });
    return result;
  });
  return serialize(updated);
}

// Attaches human-readable names for requestedBy/decidedBy/activity actorId -
// display-only convenience, batched into one query rather than N+1s. Falls
// back to the raw id if a user was later removed.
async function attachNames(requests) {
  const userIds = new Set();
  for (const r of requests) {
    if (r.requestedBy) userIds.add(r.requestedBy);
    if (r.decidedBy) userIds.add(r.decidedBy);
    for (const a of r.activities || []) if (a.actorId) userIds.add(a.actorId);
  }
  const users = await prisma.user.findMany({ where: { id: { in: [...userIds] } }, select: { id: true, name: true } });
  const nameById = new Map(users.map((u) => [u.id, u.name]));

  return requests.map((r) => ({
    ...r,
    requestedByName: nameById.get(r.requestedBy) || r.requestedBy,
    decidedByName: r.decidedBy ? nameById.get(r.decidedBy) || r.decidedBy : null,
    activities: r.activities?.map((a) => ({ ...a, actorName: a.actorId ? nameById.get(a.actorId) || a.actorId : null })),
  }));
}

async function listQueue({ tenantId, module, mine }) {
  const requests = await prisma.approvalRequest.findMany({
    where: {
      tenantId,
      status: "PENDING",
      ...(module ? { module } : {}),
      ...(mine ? { requestedBy: mine } : {}),
    },
    orderBy: { requestedAt: "desc" },
  });
  return attachNames(requests.map(serialize));
}

async function listHistory({ tenantId, module }) {
  const requests = await prisma.approvalRequest.findMany({
    where: {
      tenantId,
      status: { in: ["APPROVED", "REJECTED", "CANCELLED"] },
      ...(module ? { module } : {}),
    },
    orderBy: { decidedAt: "desc" },
  });
  return attachNames(requests.map(serialize));
}

async function getRequest({ tenantId, id }) {
  const request = await prisma.approvalRequest.findFirst({
    where: { id, tenantId },
    include: { activities: { orderBy: { createdAt: "asc" } } },
  });
  if (!request) throw new ApiError(404, "Approval request not found");
  const [enriched] = await attachNames([serialize(request)]);
  return enriched;
}

module.exports = { dispatch, decide, cancel, listQueue, listHistory, getRequest, getActiveRule };
