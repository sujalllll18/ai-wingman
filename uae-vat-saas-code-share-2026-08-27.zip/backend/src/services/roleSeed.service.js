// Shared by prisma/seed-rbac.js (one-time backfill for pre-RBAC Tenants) AND
// the live controllers that create Tenants/Users going forward
// (platformAdmin.controller.js's createTenant/createStaffUser) - one
// definition of "what are the 8 system roles and their default permissions,"
// never duplicated. Every function here accepts a Prisma client OR an
// active `tx` transaction client - both expose the same query API, so
// callers inside a $transaction just pass `tx`.
const { PERMISSIONS } = require("../config/permissionCatalog");

const BY_MODULE = PERMISSIONS.reduce((acc, p) => {
  (acc[p.module] ||= []).push(p.key);
  return acc;
}, {});

function all(...modules) {
  return modules.flatMap((m) => BY_MODULE[m] || []);
}
function only(module, ...actions) {
  return actions.map((a) => `${module}.${a}`);
}
function viewOnly(...modules) {
  return modules.map((m) => `${m}.view`);
}

const ALL_PERMISSION_KEYS = PERMISSIONS.map((p) => p.key);

const BUSINESS_MODULES = ["dashboard", "business_profile", "team", "customers", "products", "tax_master", "invoices", "purchases", "credit_notes", "debit_notes", "sales_debit_notes", "vat_returns", "audit_logs", "reports", "tickets", "approvals", "imports", "payments", "purchase_payments", "banking", "reconciliation"];

// See docs/features/18-rbac-module.md "Role Management" for the reasoning.
// No role-inheritance mechanism - each is a flat, independently-computed set.
const ROLE_DEFS = [
  { code: "OWNER", name: "Owner", description: "Full access to every module. Protected - always full access, cannot be deleted.", permissions: () => ALL_PERMISSION_KEYS },
  { code: "ADMIN", name: "Administrator", description: "Full operational access, same as Owner, minus Owner's special protection.", permissions: () => ALL_PERMISSION_KEYS },
  {
    code: "FINANCE_MGR",
    name: "Finance Manager",
    description: "Full control over Invoices, Purchases, VAT Returns and Tax Master.",
    permissions: () => [
      ...all("invoices", "purchases", "credit_notes", "debit_notes", "sales_debit_notes", "vat_returns", "tax_master", "imports", "payments", "purchase_payments", "banking", "reconciliation"),
      ...viewOnly("dashboard", "business_profile", "team", "customers", "products", "audit_logs", "reports", "approvals"),
      ...only("approvals", "view_history"),
    ],
  },
  {
    code: "ACCOUNTANT",
    name: "Accountant",
    description: "Day-to-day bookkeeping on Invoices, Purchases, VAT Returns and Tax Master - no approve/void/authorise actions.",
    permissions: () => [
      ...only("invoices", "view", "create", "update", "duplicate", "download_pdf", "download_excel", "export", "print"),
      ...only("purchases", "view", "create", "update", "export", "import", "download", "print"),
      ...only("credit_notes", "view", "create", "update", "download_pdf", "export", "print"),
      ...only("debit_notes", "view", "create", "update", "download_pdf", "export", "print"),
      ...only("sales_debit_notes", "view", "create", "update", "download_pdf", "export", "print"),
      ...only("vat_returns", "view", "generate", "update_draft", "export", "download", "print"),
      ...only("tax_master", "view", "create", "update", "export"),
      // imports: full operational control over a batch/migration run
      // (create/commit/cancel/pause/resume/retry) but not approve/reject -
      // mirrors the "no approve/void/authorise actions" restriction this
      // role already has on invoices/purchases; if a tenant turns on
      // imports.commit's approval rule, Accountant's Commit click still
      // just queues a pending request like everywhere else.
      ...only("imports", "view", "create", "commit", "cancel", "pause", "resume", "retry", "download_report"),
      // Bookkeeping-level payments access - can record/allocate but not
      // cancel or reconcile, same "no approve/void/authorise" restriction
      // this role already has on invoices/purchases.
      ...only("payments", "view", "create", "update", "allocate", "download_pdf", "export", "print"),
      ...only("purchase_payments", "view", "create", "update", "allocate", "download_pdf", "export", "print"),
      // Bank reconciliation prep is core bookkeeping work - full banking +
      // reconciliation access, same reasoning as this role's full imports
      // grant above.
      ...all("banking", "reconciliation"),
      ...viewOnly("dashboard", "business_profile", "team", "customers", "products", "audit_logs", "reports", "approvals"),
    ],
  },
  {
    code: "SALES_EXEC",
    name: "Sales Executive",
    description: "Customers and Invoices - no Purchases access.",
    permissions: () => [
      ...all("customers"),
      ...only("invoices", "view", "create", "update", "send", "duplicate", "download_pdf", "download_excel", "print"),
      ...only("credit_notes", "view", "create", "update", "issue", "download_pdf", "print"),
      ...only("sales_debit_notes", "view", "create", "update", "issue", "download_pdf", "print"),
      ...only("imports", "view", "create", "commit", "cancel", "pause", "resume", "retry", "download_report"),
      // Recording customer receipts is a natural part of a Sales Executive's
      // day-to-day (collecting against their own invoices) - no cancel/
      // reconcile, same restriction as Accountant's grant above.
      ...only("payments", "view", "create", "update", "allocate", "download_pdf", "print"),
      ...viewOnly("dashboard", "business_profile", "products", "reports", "approvals"),
    ],
  },
  {
    code: "PURCHASE_EXEC",
    name: "Purchase Executive",
    description: "Purchases only - no Invoices access.",
    permissions: () => [
      ...only("purchases", "view", "create", "update", "export", "import", "download", "print"),
      ...only("debit_notes", "view", "create", "update", "issue", "download_pdf", "print"),
      ...only("imports", "view", "create", "commit", "cancel", "pause", "resume", "retry", "download_report"),
      ...only("purchase_payments", "view", "create", "update", "allocate", "download_pdf", "print"),
      ...viewOnly("dashboard", "business_profile", "products", "tax_master", "reports", "approvals"),
    ],
  },
  {
    code: "AUDITOR",
    name: "Auditor",
    description: "Read-only everywhere, plus export on compliance modules.",
    permissions: () => [
      ...viewOnly(...BUSINESS_MODULES),
      ...only("vat_returns", "export"),
      ...only("audit_logs", "export"),
      ...only("reports", "export_pdf", "export_excel"),
      ...only("approvals", "view_history"),
      ...only("imports", "download_report"),
      // banking.view_transactions is a separate action from banking.view
      // (accounts) - viewOnly() above only grants the latter, but a
      // "read-only everywhere" role should genuinely see everything,
      // including the transaction list.
      ...only("banking", "view_transactions"),
    ],
  },
  {
    code: "VIEWER",
    name: "Viewer",
    description: "Read-only access to every module.",
    permissions: () => [...viewOnly(...BUSINESS_MODULES), ...only("banking", "view_transactions")],
  },
];

// Maps the legacy User.role string to the system role code a new/backfilled
// user should get. STAFF -> ADMIN is deliberate, not a typo: today's
// requireTenantUser lets Staff do everything Owner can (requireOwnerRole is
// defined but attached to zero routes), so Administrator (full access) is
// the only system role that preserves that real capability without a
// regression. A Tenant can reassign a Staff user to a narrower role
// afterward via the real Roles & Permissions UI (Phase 4/6).
function defaultRoleCodeForLegacyRole(legacyRole) {
  return legacyRole === "OWNER" ? "OWNER" : "ADMIN";
}

async function seedPermissionCatalog(client) {
  for (const p of PERMISSIONS) {
    await client.permission.upsert({
      where: { key: p.key },
      update: { module: p.module, action: p.action, group: p.group, label: p.label, sortOrder: p.sortOrder },
      create: { key: p.key, module: p.module, action: p.action, group: p.group, label: p.label, sortOrder: p.sortOrder },
    });
  }
}

// Ensures all 8 system roles exist for a Tenant with their default
// permissions granted. Idempotent - safe to call on every Tenant creation
// and safe to re-run for a Tenant that already has them. Returns
// { [roleCode]: roleId }.
async function seedSystemRolesForTenant(client, tenantId) {
  const permissions = await client.permission.findMany();
  const permissionByKey = new Map(permissions.map((p) => [p.key, p.id]));
  const roleIdByCode = {};

  for (const def of ROLE_DEFS) {
    let role = await client.role.findUnique({ where: { tenantId_code: { tenantId, code: def.code } } });
    if (!role) {
      role = await client.role.create({
        data: { tenantId, name: def.name, code: def.code, description: def.description, isSystem: true, status: "ACTIVE", createdBy: "system" },
      });
    }
    roleIdByCode[def.code] = role.id;

    const desiredKeys = def.permissions();
    const existing = await client.rolePermission.findMany({ where: { roleId: role.id }, select: { permissionId: true } });
    const existingIds = new Set(existing.map((r) => r.permissionId));
    const toCreate = desiredKeys.map((key) => permissionByKey.get(key)).filter((permissionId) => permissionId && !existingIds.has(permissionId));

    if (toCreate.length > 0) {
      // SQLite's Prisma connector doesn't support createMany's
      // skipDuplicates option - toCreate is already deduplicated above.
      await client.rolePermission.createMany({ data: toCreate.map((permissionId) => ({ roleId: role.id, permissionId })) });
    }
  }

  return roleIdByCode;
}

// Assigns a user's one primary UserRole, deriving the target system role
// from their legacy `role` string. No-op if the user already has a primary
// role (never silently reassigns an existing, possibly-customized role).
async function assignDefaultUserRole(client, { userId, tenantId, legacyRole, assignedBy = "system" }) {
  const existing = await client.userRole.findFirst({ where: { userId, isPrimary: true } });
  if (existing) return existing;

  const roleIdByCode = await seedSystemRolesForTenant(client, tenantId);
  const roleId = roleIdByCode[defaultRoleCodeForLegacyRole(legacyRole)];
  if (!roleId) return null;

  return client.userRole.create({ data: { userId, roleId, isPrimary: true, assignedBy } });
}

module.exports = { ROLE_DEFS, seedPermissionCatalog, seedSystemRolesForTenant, assignDefaultUserRole, defaultRoleCodeForLegacyRole };
