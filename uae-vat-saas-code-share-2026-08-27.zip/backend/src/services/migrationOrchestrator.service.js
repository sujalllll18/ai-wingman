// Thin orchestration layer over the existing, unmodified Import Framework
// engine (importEngine.service.js) - groups several ImportBatch rows (one
// per uploaded file/entity type) into one named, numbered Migration with a
// mandatory Preview -> Commit -> Final Summary lifecycle.
//
// Deliberately NOT a second execution engine: every function here either
// (a) fans an existing per-batch importEngine.service.js function out
// across a Migration's child batches, or (b) aggregates their already-
// persisted counters/status for display. No record is ever parsed,
// validated, or committed here - that is 100% importEngine.service.js's
// job, unchanged.
const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const importEngine = require("./importEngine.service");
const { getAdapter } = require("./importAdapters");

function toJson(value) {
  return value === undefined || value === null ? null : JSON.stringify(value);
}
function fromJson(value) {
  return value ? JSON.parse(value) : null;
}

const TERMINAL_STATUSES = new Set(["COMPLETED", "COMPLETED_WITH_ERRORS", "FAILED", "CANCELLED"]);
const PRE_COMMIT_ORDER = ["UPLOADED", "MAPPING", "VALIDATING", "PREVIEW", "PENDING_APPROVAL"];

// Rolls up N child ImportBatch statuses into one Migration-level status.
// See the file header - this is pure aggregation of already-real state,
// never a decision that changes what any batch actually does.
function aggregateStatus(batches) {
  if (batches.length === 0) return "UPLOADED";
  if (batches.some((b) => b.status === "PROCESSING")) return "PROCESSING";
  if (batches.some((b) => b.status === "QUEUED")) return "QUEUED";
  if (batches.some((b) => b.status === "PAUSED")) return "PAUSED";
  if (batches.every((b) => TERMINAL_STATUSES.has(b.status))) {
    if (batches.every((b) => b.status === "CANCELLED")) return "CANCELLED";
    if (batches.every((b) => b.status === "FAILED")) return "FAILED";
    if (batches.some((b) => b.status === "FAILED" || b.status === "CANCELLED" || b.failedCount > 0)) return "COMPLETED_WITH_ERRORS";
    return "COMPLETED";
  }
  for (const s of PRE_COMMIT_ORDER) {
    if (batches.some((b) => b.status === s)) return s;
  }
  return batches[0].status;
}

async function getMigrationWithBatches(tenantId, migrationId) {
  const migration = await prisma.migration.findFirst({ where: { id: migrationId, tenantId } });
  if (!migration) throw new ApiError(404, "Migration not found");
  const batches = await prisma.importBatch.findMany({ where: { migrationId: migration.id }, orderBy: { createdAt: "asc" } });
  return { migration, batches };
}

// POST .../migrations - one Migration row + one importEngine.createBatch()
// call per uploaded file, exactly as if each had been uploaded standalone -
// only the migrationId tag differs. files: [{ importType, file: {buffer,
// originalname, fileUrl}, periodFrom?, periodTo? }].
async function createMigration({ tenantId, source, startedByType, startedById, files }) {
  if (!files || files.length === 0) throw new ApiError(400, "At least one file is required to start a migration");

  const tenant = await prisma.tenant.update({ where: { id: tenantId }, data: { nextMigrationNumber: { increment: 1 } } });
  const migrationNumber = `MIG-${String(tenant.nextMigrationNumber - 1).padStart(6, "0")}`;

  const migration = await prisma.migration.create({
    data: { tenantId, migrationNumber, source: source || "EXCEL", startedByType, startedById },
  });

  const results = [];
  for (const f of files) {
    const result = await importEngine.createBatch({
      tenantId,
      userId: startedById, // ImportBatch.importedBy is always a plain id string regardless of who started it (tenant User or PlatformAdmin) - same "plain data, not a relation" convention as everywhere else this field is used
      importType: f.importType,
      periodFrom: f.periodFrom,
      periodTo: f.periodTo,
      file: f.file,
      migrationId: migration.id,
    });
    results.push(result);
  }

  return { migration, batches: results };
}

async function listMigrations({ tenantId }) {
  const migrations = await prisma.migration.findMany({ where: { tenantId }, orderBy: { createdAt: "desc" }, include: { batches: true } });
  return migrations.map((m) => ({
    ...m,
    batches: undefined,
    status: aggregateStatus(m.batches),
    totalRecords: m.batches.reduce((s, b) => s + b.totalRecords, 0),
    successCount: m.batches.reduce((s, b) => s + b.successCount, 0),
    failedCount: m.batches.reduce((s, b) => s + b.failedCount, 0),
    entityCount: m.batches.length,
  }));
}

async function getMigration({ tenantId, migrationId }) {
  const { migration, batches } = await getMigrationWithBatches(tenantId, migrationId);
  return { ...migration, status: aggregateStatus(batches), batches };
}

// Counts how many of a batch's warning-flagged records are specifically
// "possible duplicate" warnings, so the Migration Review screen can show a
// distinct Duplicates count rather than lumping every warning together.
async function countDuplicateWarnings(batchId) {
  const rows = await prisma.importRecord.findMany({
    where: { importBatchId: batchId, hasWarnings: true },
    select: { validationErrors: true },
  });
  return rows.filter((r) => (fromJson(r.validationErrors) || []).some((e) => e.field === "duplicate")).length;
}

// GET .../migrations/:id/preview - the "MIGRATION REVIEW" screen's data.
// Every child batch must already be validated (status PREVIEW or later) -
// the caller is responsible for driving each batch through setMapping +
// validateBatch first (see the tenant/platform-admin controllers' per-batch
// pass-through endpoints), exactly like a standalone single-file import.
async function getMigrationPreview({ tenantId, migrationId }) {
  const { migration, batches } = await getMigrationWithBatches(tenantId, migrationId);

  const entities = [];
  let totalRecords = 0;
  let readyCount = 0;
  let warningCount = 0;
  let errorCount = 0;
  let duplicateCount = 0;

  for (const batch of batches) {
    const adapter = getAdapter(batch.importType);
    const duplicatesInBatch = await countDuplicateWarnings(batch.id);

    let financialSummary = null;
    if (adapter?.summarizeFinancials && ["PREVIEW", "PENDING_APPROVAL"].includes(batch.status)) {
      const preview = await importEngine.previewBatch({ tenantId, batchId: batch.id, status: "VALID" });
      financialSummary = preview.financialSummary;
    }

    entities.push({
      batchId: batch.id,
      importType: batch.importType,
      label: adapter?.label || batch.importType,
      sourceFileName: batch.sourceFileName,
      status: batch.status,
      total: batch.totalRecords,
      ready: batch.successCount,
      warnings: batch.warningCount,
      errors: batch.failedCount,
      duplicates: duplicatesInBatch,
      financialSummary,
    });

    totalRecords += batch.totalRecords;
    readyCount += batch.successCount;
    warningCount += batch.warningCount;
    errorCount += batch.failedCount;
    duplicateCount += duplicatesInBatch;
  }

  return {
    migration,
    entities,
    totals: { totalRecords, ready: readyCount, warnings: warningCount, errors: errorCount, duplicates: duplicateCount, skipped: errorCount },
  };
}

// GET .../migrations/:id/status - the Progress-screen / Final-Summary data
// (the same shape serves both - once every child batch is terminal, this
// IS the final summary, just read again).
async function getMigrationStatus({ tenantId, migrationId }) {
  const { migration, batches } = await getMigrationWithBatches(tenantId, migrationId);
  const status = aggregateStatus(batches);

  const active = batches.find((b) => ["QUEUED", "PROCESSING"].includes(b.status));
  const adapter = active ? getAdapter(active.importType) : null;

  const perEntity = batches.map((b) => ({
    batchId: b.id,
    importType: b.importType,
    label: getAdapter(b.importType)?.label || b.importType,
    status: b.status,
    total: b.totalRecords,
    processed: b.processedRecords,
    success: b.successCount,
    failed: b.failedCount,
  }));

  const allTerminal = batches.every((b) => TERMINAL_STATUSES.has(b.status));
  const completedAt = allTerminal && batches.length > 0 ? batches.reduce((latest, b) => (b.importedAt && (!latest || b.importedAt > latest) ? b.importedAt : latest), null) : null;

  return {
    migration: { ...migration, completedAt: completedAt || migration.completedAt },
    status,
    totalRecords: batches.reduce((s, b) => s + b.totalRecords, 0),
    processedRecords: batches.reduce((s, b) => s + b.processedRecords, 0),
    successCount: batches.reduce((s, b) => s + b.successCount, 0),
    failedCount: batches.reduce((s, b) => s + b.failedCount, 0),
    currentEntity: adapter?.label || active?.importType || null,
    currentBatchNumber: active?.currentBatchNumber || 0,
    totalChunksForCurrentEntity: active ? Math.ceil(active.totalRecords / importEngine.BATCH_SIZE) : 0,
    perEntity,
  };
}

// POST .../migrations/:id/commit - fans startMigration() out to every
// committable child batch (PREVIEW/PENDING_APPROVAL). Each batch still runs
// as its own fully independent engine instance - never a shared
// transaction across entity types, matching "controlled batches, not one
// giant transaction" at the Migration level too.
//
// dispatchThroughApproval: true for the tenant self-service path (routes
// each batch's commit through the existing Maker-Checker imports.commit
// rule, exactly like a standalone single-file commit already does) / false
// for the Platform-Admin path (Platform Admin actions never route through
// the tenant-scoped Maker-Checker engine - see approvalEngine.service.js
// and the PlanChangeHistory.approvalStatus schema comment for the existing
// precedent this mirrors).
async function commitMigration({ tenantId, migrationId, actorId, dispatchThroughApproval }) {
  const { batches } = await getMigrationWithBatches(tenantId, migrationId);
  const committable = batches.filter((b) => ["PREVIEW", "PENDING_APPROVAL"].includes(b.status));
  if (committable.length === 0) throw new ApiError(409, "This migration has no files ready to commit");

  const results = [];
  for (const batch of committable) {
    if (dispatchThroughApproval) {
      const engine = require("./approvalEngine.service"); // lazy require - avoids a require cycle, same pattern already used elsewhere in this codebase for cross-service calls
      const result = await engine.dispatch({
        tenantId,
        userId: actorId,
        permissionKey: "imports.commit",
        module: "imports",
        action: "commit",
        entityType: "ImportBatch",
        entityId: batch.id,
        payload: {},
      });
      if (result.status === "PENDING") {
        await importEngine.markPendingApproval({ tenantId, batchId: batch.id });
        results.push({ batchId: batch.id, status: "PENDING_APPROVAL" });
      } else {
        results.push({ batchId: batch.id, status: result.entity.status });
      }
    } else {
      const result = await importEngine.startMigration({ tenantId, batchId: batch.id, actorId });
      results.push({ batchId: batch.id, status: result.status });
    }
  }
  return { migrationId, results };
}

// pause/resume/cancel/retry all fan out the same way: apply to whichever
// child batches are actually in a state where the action is valid, silently
// skip the rest (different files within one migration can legitimately be
// at different stages - e.g. Customers already COMPLETED while Invoices is
// still PROCESSING - "pause the migration" should only affect what's
// actually running, never error out because of an unrelated file).
async function fanOutPerBatch(tenantId, migrationId, validStatuses, action) {
  const { batches } = await getMigrationWithBatches(tenantId, migrationId);
  const targets = batches.filter((b) => validStatuses.includes(b.status));
  const results = [];
  for (const batch of targets) {
    try {
      const result = await action(batch);
      results.push({ batchId: batch.id, ok: true, status: result.status });
    } catch (err) {
      results.push({ batchId: batch.id, ok: false, error: err.message });
    }
  }
  return { migrationId, affected: results.length, results };
}

function pauseMigrationBatches({ tenantId, migrationId }) {
  return fanOutPerBatch(tenantId, migrationId, ["QUEUED", "PROCESSING"], (batch) => importEngine.pauseMigration({ tenantId, batchId: batch.id }));
}
function resumeMigrationBatches({ tenantId, migrationId, actorId }) {
  return fanOutPerBatch(tenantId, migrationId, ["PAUSED"], (batch) => importEngine.resumeMigration({ tenantId, batchId: batch.id, actorId }));
}
function cancelMigrationBatches({ tenantId, migrationId }) {
  return fanOutPerBatch(tenantId, migrationId, ["QUEUED", "PROCESSING", "PAUSED"], (batch) => importEngine.cancelMigration({ tenantId, batchId: batch.id }));
}
// A batch with zero FAILED rows (e.g. it had only pre-commit INVALID rows,
// nothing retryable) throws 400 "nothing to retry" - fanOutPerBatch's own
// try/catch already turns that into a per-batch {ok:false} result instead
// of aborting the other files in the migration, exactly the behavior we
// want for one file within a multi-file migration having nothing to retry.
function retryFailedRecordsForMigration({ tenantId, migrationId, actorId }) {
  return fanOutPerBatch(tenantId, migrationId, ["COMPLETED_WITH_ERRORS", "PAUSED", "FAILED"], (batch) =>
    importEngine.retryFailedRecords({ tenantId, batchId: batch.id, actorId })
  );
}

// GET .../migrations/:id/error-report - one combined CSV across every
// child batch's INVALID+FAILED rows, prefixed with which entity/file each
// row came from (the per-batch report already exists and still works
// standalone; this is purely an aggregation for the Migration-level "Download
// Error Report" action in the Final Summary).
async function buildMigrationErrorReportCsv({ tenantId, migrationId }) {
  const { batches } = await getMigrationWithBatches(tenantId, migrationId);
  const XLSX = require("xlsx");
  const allRows = [];
  for (const batch of batches) {
    const adapter = getAdapter(batch.importType);
    const records = await prisma.importRecord.findMany({ where: { importBatchId: batch.id, status: { in: ["INVALID", "FAILED"] } }, orderBy: { rowNumber: "asc" } });
    for (const r of records) {
      const raw = fromJson(r.rawData) || {};
      const errors = (fromJson(r.validationErrors) || []).map((e) => e.message).join("; ");
      allRows.push({
        Entity: adapter?.label || batch.importType,
        "Source File": batch.sourceFileName,
        "Row #": r.rowNumber,
        Status: r.status,
        "Source Identifier": r.sourceIdentifier || `Row ${r.rowNumber}`,
        ...raw,
        "Error Code": r.errorCode || "",
        "Validation Errors": errors,
        "Retry Count": r.retryCount,
      });
    }
  }
  const worksheet = XLSX.utils.json_to_sheet(allRows);
  return XLSX.utils.sheet_to_csv(worksheet);
}

// Used by the "this tenant already contains data" warning (section 10 of
// the spec) - shown before Preview whenever any count is non-zero, on both
// the tenant self-service and Platform-Admin migration entry points.
async function getTenantDataCounts(tenantId) {
  const [customerCount, invoiceCount, purchaseBillCount] = await Promise.all([
    prisma.customer.count({ where: { tenantId } }),
    prisma.invoice.count({ where: { tenantId } }),
    prisma.purchaseBill.count({ where: { tenantId } }),
  ]);
  return { customerCount, invoiceCount, purchaseBillCount };
}

module.exports = {
  createMigration,
  listMigrations,
  getMigration,
  getMigrationPreview,
  getMigrationStatus,
  commitMigration,
  pauseMigrationBatches,
  resumeMigrationBatches,
  cancelMigrationBatches,
  retryFailedRecordsForMigration,
  buildMigrationErrorReportCsv,
  getTenantDataCounts,
};
