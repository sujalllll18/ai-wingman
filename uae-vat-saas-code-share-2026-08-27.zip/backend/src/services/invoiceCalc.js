// Invoice calculation engine - see docs/features/17-invoice-generation.md §7.
//
// Discount is applied pro-rata per line, BEFORE VAT, so mixed-VAT-category
// invoices (e.g. one Standard Rated line + one Zero Rated line) come out
// correct - the discount doesn't just get lumped onto one line's tax base.
//
// Always the authority: recalculated server-side on every Draft save and
// again at Send. Never trusts client-submitted totals.

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// lines: [{ quantity, unitPrice, taxPercentage, taxCalculationMethod }]
// discount: { discountType: "PERCENTAGE"|"FIXED"|null, discountValue: number|null }
//
// Returns { subtotal, discountTotal, vatTotal, grandTotal, lines: [...] }
// where each returned line carries lineNetAmount/lineDiscountShare/
// lineTaxableAmount/lineTaxAmount/lineTotal alongside the original input.
function calculateInvoiceTotals(lines, discount = {}) {
  const { discountType, discountValue } = discount;

  const withNet = lines.map((line) => ({
    ...line,
    lineNetAmount: round2(Number(line.quantity) * Number(line.unitPrice)),
  }));

  const subtotal = round2(withNet.reduce((sum, l) => sum + l.lineNetAmount, 0));

  let discountTotal = 0;
  if (discountType === "PERCENTAGE") {
    discountTotal = round2((subtotal * Number(discountValue || 0)) / 100);
  } else if (discountType === "FIXED") {
    discountTotal = round2(Number(discountValue || 0));
  }
  // A fixed discount can never exceed the subtotal it's applied against.
  discountTotal = Math.min(discountTotal, subtotal);

  const computedLines = withNet.map((line) => {
    const share = subtotal === 0 ? 0 : round2((line.lineNetAmount / subtotal) * discountTotal);
    const taxableAmount = round2(line.lineNetAmount - share);
    const pct = Number(line.taxPercentage || 0);
    const method = line.taxCalculationMethod || "EXCLUSIVE";

    let taxAmount;
    let lineTotal;
    if (method === "INCLUSIVE") {
      taxAmount = round2(taxableAmount - taxableAmount / (1 + pct / 100));
      lineTotal = taxableAmount; // tax already inside the taxable amount
    } else {
      taxAmount = round2((taxableAmount * pct) / 100);
      lineTotal = round2(taxableAmount + taxAmount);
    }

    return {
      ...line,
      lineDiscountShare: share,
      lineTaxableAmount: taxableAmount,
      lineTaxAmount: taxAmount,
      lineTotal,
    };
  });

  const vatTotal = round2(computedLines.reduce((sum, l) => sum + l.lineTaxAmount, 0));
  // Summed directly from each line's own total rather than derived via
  // subtotal - discount + vat, so mixed EXCLUSIVE/INCLUSIVE invoices stay
  // correct without a special-case formula.
  const grandTotal = round2(computedLines.reduce((sum, l) => sum + l.lineTotal, 0));

  return { subtotal, discountTotal, vatTotal, grandTotal, lines: computedLines };
}

module.exports = { calculateInvoiceTotals, round2 };
