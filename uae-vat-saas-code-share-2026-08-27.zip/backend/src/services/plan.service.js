const prisma = require("../config/prisma");
const ApiError = require("../utils/ApiError");
const { MODULES: PERMISSION_MODULES } = require("../config/permissionCatalog");

// Platform Admin Phase 2 - Subscription Plans / Plan Builder (2026-08-07).
// Core business logic for Plan/PlanVersion/TenantPlanAssignment/
// PlanChangeHistory. Replaces src/config/plans.js's hardcoded PLAN_LIMITS as
// the source of truth (see getPlanLimits below) without changing that
// function's signature or return shape, so its 3 existing callers
// (platformAdmin.controller.js's updateTenantPlan/createStaffUser/
// getTenantUsage) only need `await` added, no logic changes.

// Two modules with no real functionality anywhere in the app yet (OCR is
// just an action inside Purchases today, AI Assistant doesn't exist at
// all) - included as toggleable placeholders in the Module Builder per
// Phase 2 spec, clearly not wired to any real feature gate.
const PLACEHOLDER_MODULES = [
  { module: "ocr", label: "OCR", group: "Transactions", actions: ["upload", "review"] },
  { module: "ai_assistant", label: "AI Assistant", group: "Support", actions: ["chat", "suggestions"] },
];

// The canonical module/feature catalog the Module Builder and Feature
// Builder both render from - reuses the existing RBAC permission catalog
// rather than inventing a second one, per the "do not hardcode feature
// permissions" / "do not create duplicate components" requirements.
function getModuleCatalog() {
  return [...PERMISSION_MODULES, ...PLACEHOLDER_MODULES];
}

function parseModuleAccess(json) {
  try {
    return JSON.parse(json || "{}");
  } catch {
    return {};
  }
}

function serializeVersion(v) {
  if (!v) return null;
  return { ...v, moduleAccess: parseModuleAccess(v.moduleAccess) };
}

async function getCurrentPublishedVersion(planId) {
  return prisma.planVersion.findFirst({
    where: { planId, status: "PUBLISHED" },
    orderBy: { versionNumber: "desc" },
  });
}

// Drop-in replacement for the old static PLAN_LIMITS[plan] lookup - same
// return shape { maxUsers, maxInvoicesPerMonth, features: { auditLog, ocr } }
// so existing callers don't need to change beyond adding `await`.
async function getPlanLimits(planSlug) {
  const plan = await prisma.plan.findUnique({ where: { slug: planSlug } });
  if (!plan) throw new Error(`Unknown plan: ${planSlug}`);
  const version = await getCurrentPublishedVersion(plan.id);
  if (!version) throw new Error(`Plan ${planSlug} has no published version`);
  const moduleAccess = parseModuleAccess(version.moduleAccess);
  return {
    maxUsers: version.maxUsers,
    maxInvoicesPerMonth: version.maxInvoicesPerMonth,
    features: {
      auditLog: !!moduleAccess.audit_logs?.enabled,
      ocr: !!moduleAccess.ocr?.enabled,
    },
  };
}

// Plan + RBAC combined enforcement (2026-08-09) - resolves a Tenant's
// current published PlanVersion's moduleAccess for requirePermission()/
// can() to check alongside RBAC. Deliberately fails open (returns {}) on
// ANY resolution problem - unknown plan slug, no published version, a
// tenant whose plan was archived out from under it - rather than throwing
// like getPlanLimits does. This must never be the reason a request 500s,
// and per the real data checked before writing this (every existing plan's
// moduleAccess predates the credit_notes/debit_notes/imports modules
// entirely - those keys are simply absent, not disabled), the correct
// meaning of "can't resolve an answer" is "don't block on it," not "deny."
async function getModuleAccess(planSlug) {
  try {
    const plan = await prisma.plan.findUnique({ where: { slug: planSlug } });
    if (!plan) return {};
    const version = await getCurrentPublishedVersion(plan.id);
    if (!version) return {};
    return parseModuleAccess(version.moduleAccess);
  } catch {
    return {};
  }
}

// A module/action never explicitly configured in Plan Builder is allowed by
// default - only an explicit `enabled: false` (module) or a feature key
// explicitly set to `false` denies. This is the one safe interpretation
// given moduleAccess is opt-in configuration, not a whitelist every plan is
// guaranteed to have fully filled in (see getModuleAccess's comment).
function isModuleEnabled(moduleAccess, moduleKey) {
  const entry = moduleAccess?.[moduleKey];
  if (!entry) return true;
  return entry.enabled !== false;
}

// Module-level gate first (a disabled module blocks every action inside
// it), then the optional, finer-grained per-action override - same
// fail-open rule at both levels, since features{} is empty on every real
// plan today (Module Builder's per-action checkboxes have never been used
// yet, only the module-level toggle has).
function isActionEnabled(moduleAccess, moduleKey, actionKey) {
  if (!isModuleEnabled(moduleAccess, moduleKey)) return false;
  const featureFlag = moduleAccess?.[moduleKey]?.features?.[actionKey];
  return featureFlag !== false;
}

async function getActivePlanSlugs() {
  const plans = await prisma.plan.findMany({ where: { status: "ACTIVE" }, select: { slug: true } });
  return plans.map((p) => p.slug);
}

async function listPlans() {
  const plans = await prisma.plan.findMany({ orderBy: { createdAt: "asc" }, include: { versions: true } });
  const tenantCounts = await prisma.tenantPlanAssignment.groupBy({ by: ["planVersionId"], _count: true });
  const versionIdToCount = new Map(tenantCounts.map((c) => [c.planVersionId, c._count]));

  return plans.map((plan) => {
    const published = plan.versions.filter((v) => v.status === "PUBLISHED").sort((a, b) => b.versionNumber - a.versionNumber)[0] || null;
    const latest = plan.versions.sort((a, b) => b.versionNumber - a.versionNumber)[0] || null;
    const activeTenants = plan.versions.reduce((sum, v) => sum + (versionIdToCount.get(v.id) || 0), 0);
    return {
      id: plan.id,
      slug: plan.slug,
      name: plan.name,
      description: plan.description,
      isDefault: plan.isDefault,
      status: plan.status,
      updatedAt: plan.updatedAt,
      activeTenants,
      currentVersion: serializeVersion(published || latest),
      versionCount: plan.versions.length,
    };
  });
}

async function getPlanDetail(planId) {
  const plan = await prisma.plan.findUnique({ where: { id: planId }, include: { versions: { orderBy: { versionNumber: "desc" } } } });
  if (!plan) throw new ApiError(404, "Plan not found");
  return { ...plan, versions: plan.versions.map(serializeVersion) };
}

const VERSION_FIELDS = [
  "monthlyPrice",
  "yearlyPrice",
  "trialDays",
  "gracePeriodDays",
  "autoRenewal",
  "maxUsers",
  "maxCustomers",
  "maxProducts",
  "maxInvoicesPerMonth",
  "maxPurchasesPerMonth",
  "ocrCredits",
  "apiCallsPerMonth",
  "storageGb",
  "attachmentStorageGb",
  "maxBranches",
  "maxTeamMembers",
];

function pickVersionFields(data) {
  const out = {};
  for (const key of VERSION_FIELDS) {
    if (data[key] !== undefined) out[key] = data[key];
  }
  if (data.moduleAccess !== undefined) out.moduleAccess = JSON.stringify(data.moduleAccess);
  return out;
}

// Creates Plan + its first PlanVersion (DRAFT) in one call - used by both
// "New Plan" and internally by the seed script.
async function createPlan({ slug, name, description, isDefault, versionData, createdBy }) {
  const existing = await prisma.plan.findUnique({ where: { slug } });
  if (existing) throw new ApiError(409, `A plan with slug "${slug}" already exists`);

  return prisma.$transaction(async (tx) => {
    const plan = await tx.plan.create({ data: { slug, name, description, isDefault: !!isDefault } });
    const version = await tx.planVersion.create({
      data: { planId: plan.id, versionNumber: 1, status: "DRAFT", createdBy, changeSummary: "Initial version", ...pickVersionFields(versionData || {}) },
    });
    return { plan, version: serializeVersion(version) };
  });
}

// Plans should never overwrite previous configurations: editing an existing
// plan always creates a new version (draft), never mutates a
// PUBLISHED/ARCHIVED one. If the plan's latest version is still a DRAFT,
// that draft is updated in place instead of creating yet another draft.
async function saveDraftVersion(planId, versionData, { createdBy, changeSummary }) {
  const plan = await prisma.plan.findUnique({ where: { id: planId }, include: { versions: { orderBy: { versionNumber: "desc" } } } });
  if (!plan) throw new ApiError(404, "Plan not found");

  const latest = plan.versions[0];
  if (latest && latest.status === "DRAFT") {
    const updated = await prisma.planVersion.update({
      where: { id: latest.id },
      data: { ...pickVersionFields(versionData), changeSummary: changeSummary ?? latest.changeSummary },
    });
    return serializeVersion(updated);
  }

  const nextVersionNumber = (latest?.versionNumber || 0) + 1;
  const base = latest ? { ...latest, ...pickVersionFields(versionData) } : pickVersionFields(versionData);
  const created = await prisma.planVersion.create({
    data: {
      planId,
      versionNumber: nextVersionNumber,
      status: "DRAFT",
      createdBy,
      changeSummary: changeSummary || "Updated configuration",
      monthlyPrice: base.monthlyPrice ?? 0,
      yearlyPrice: base.yearlyPrice ?? 0,
      trialDays: base.trialDays ?? 0,
      gracePeriodDays: base.gracePeriodDays ?? 0,
      autoRenewal: base.autoRenewal ?? true,
      maxUsers: base.maxUsers ?? null,
      maxCustomers: base.maxCustomers ?? null,
      maxProducts: base.maxProducts ?? null,
      maxInvoicesPerMonth: base.maxInvoicesPerMonth ?? null,
      maxPurchasesPerMonth: base.maxPurchasesPerMonth ?? null,
      ocrCredits: base.ocrCredits ?? null,
      apiCallsPerMonth: base.apiCallsPerMonth ?? null,
      storageGb: base.storageGb ?? null,
      attachmentStorageGb: base.attachmentStorageGb ?? null,
      maxBranches: base.maxBranches ?? null,
      maxTeamMembers: base.maxTeamMembers ?? null,
      moduleAccess: base.moduleAccess ?? "{}",
    },
  });
  return serializeVersion(created);
}

// Publishing is what makes a version the one getPlanLimits()/new
// assignments read - the version becomes read-only (immutable) from this
// point on; further edits create the next version instead.
async function publishVersion(versionId) {
  const version = await prisma.planVersion.findUnique({ where: { id: versionId } });
  if (!version) throw new ApiError(404, "Plan version not found");
  if (version.status === "PUBLISHED") throw new ApiError(409, "This version is already published");
  const updated = await prisma.planVersion.update({ where: { id: versionId }, data: { status: "PUBLISHED", publishedAt: new Date() } });
  return serializeVersion(updated);
}

async function archiveVersion(versionId) {
  const updated = await prisma.planVersion.update({ where: { id: versionId }, data: { status: "ARCHIVED" } });
  return serializeVersion(updated);
}

async function updatePlanMeta(planId, { name, description, isDefault }) {
  const data = {};
  if (name !== undefined) data.name = name;
  if (description !== undefined) data.description = description;
  if (isDefault !== undefined) data.isDefault = isDefault;
  const updated = await prisma.plan.update({ where: { id: planId }, data });
  return updated;
}

async function setPlanStatus(planId, status) {
  if (!["ACTIVE", "INACTIVE", "ARCHIVED"].includes(status)) throw new ApiError(400, "Invalid status");
  const updated = await prisma.plan.update({ where: { id: planId }, data: { status } });
  return updated;
}

// Clone = new Plan (new slug) seeded from the source plan's current
// published (or latest) version's configuration, as its own DRAFT v1 - a
// completely independent plan from that point on, not linked to the
// original's version history.
async function clonePlan(planId, { name, slug }) {
  const source = await prisma.plan.findUnique({ where: { id: planId }, include: { versions: { orderBy: { versionNumber: "desc" } } } });
  if (!source) throw new ApiError(404, "Plan not found");
  const sourceVersion = source.versions.find((v) => v.status === "PUBLISHED") || source.versions[0];
  return createPlan({
    slug,
    name,
    description: source.description,
    isDefault: false,
    versionData: sourceVersion ? { ...sourceVersion, moduleAccess: parseModuleAccess(sourceVersion.moduleAccess) } : {},
  });
}

// --- Tenant Plan Assignment -------------------------------------------

async function getTenantAssignment(tenantId) {
  const assignment = await prisma.tenantPlanAssignment.findUnique({
    where: { tenantId },
    include: {
      planVersion: { include: { plan: true } },
      scheduledPlanVersion: { include: { plan: true } },
    },
  });
  if (!assignment) return null;

  // previousPlanVersionId has no Prisma relation (plain FK-shaped string,
  // see schema comment) since it only exists for display, never joined
  // elsewhere - resolved with one extra lookup here instead.
  let previousPlanVersion = null;
  if (assignment.previousPlanVersionId) {
    previousPlanVersion = await prisma.planVersion.findUnique({ where: { id: assignment.previousPlanVersionId }, include: { plan: true } });
  }

  return {
    ...assignment,
    planVersion: assignment.planVersion ? serializeVersion(assignment.planVersion) : null,
    scheduledPlanVersion: assignment.scheduledPlanVersion ? serializeVersion(assignment.scheduledPlanVersion) : null,
    previousPlanVersion: previousPlanVersion ? serializeVersion(previousPlanVersion) : null,
  };
}

// Assign/Upgrade/Downgrade all funnel through here - immediate effect,
// syncs Tenant.plan (the legacy string every other module reads) to the new
// plan's slug so nothing outside Platform Admin needs to change, and logs
// to PlanChangeHistory.
async function assignPlan(tenantId, planVersionId, { changedBy, reason }) {
  const [tenant, targetVersion] = await Promise.all([
    prisma.tenant.findUnique({ where: { id: tenantId } }),
    prisma.planVersion.findUnique({ where: { id: planVersionId }, include: { plan: true } }),
  ]);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (!targetVersion) throw new ApiError(404, "Plan version not found");
  if (targetVersion.status !== "PUBLISHED") throw new ApiError(409, "Only a published plan version can be assigned");

  const existing = await prisma.tenantPlanAssignment.findUnique({ where: { tenantId } });

  const result = await prisma.$transaction(async (tx) => {
    const assignment = await tx.tenantPlanAssignment.upsert({
      where: { tenantId },
      create: { tenantId, planVersionId, previousPlanVersionId: null },
      update: { planVersionId, previousPlanVersionId: existing?.planVersionId || null, scheduledPlanVersionId: null, scheduledEffectiveDate: null },
    });
    await tx.tenant.update({ where: { id: tenantId }, data: { plan: targetVersion.plan.slug } });
    await tx.planChangeHistory.create({
      data: {
        tenantId,
        oldPlanVersionId: existing?.planVersionId || null,
        newPlanVersionId: planVersionId,
        changedBy,
        reason,
        effectiveDate: new Date(),
      },
    });
    return assignment;
  });

  return getTenantAssignment(tenantId) || result;
}

async function schedulePlanChange(tenantId, planVersionId, effectiveDate, { changedBy, reason }) {
  const [tenant, targetVersion] = await Promise.all([
    prisma.tenant.findUnique({ where: { id: tenantId } }),
    prisma.planVersion.findUnique({ where: { id: planVersionId } }),
  ]);
  if (!tenant) throw new ApiError(404, "Tenant not found");
  if (!targetVersion || targetVersion.status !== "PUBLISHED") throw new ApiError(409, "Only a published plan version can be scheduled");
  if (!effectiveDate) throw new ApiError(400, "effectiveDate is required");

  const existing = await prisma.tenantPlanAssignment.findUnique({ where: { tenantId } });
  if (!existing) throw new ApiError(409, "Tenant has no current plan assignment to schedule a change against");

  await prisma.tenantPlanAssignment.update({
    where: { tenantId },
    data: { scheduledPlanVersionId: planVersionId, scheduledEffectiveDate: new Date(effectiveDate) },
  });
  return getTenantAssignment(tenantId);
}

async function cancelScheduledChange(tenantId) {
  const existing = await prisma.tenantPlanAssignment.findUnique({ where: { tenantId } });
  if (!existing) throw new ApiError(404, "Tenant has no plan assignment");
  await prisma.tenantPlanAssignment.update({
    where: { tenantId },
    data: { scheduledPlanVersionId: null, scheduledEffectiveDate: null },
  });
  return getTenantAssignment(tenantId);
}

// Applies any scheduled changes whose effective date has passed - called
// lazily whenever a tenant's assignment is read (no cron/queue in this
// codebase), same "compute on read" pattern already used for e.g. Days
// Remaining on the Tenant list.
async function applyDueScheduledChanges(tenantId) {
  const assignment = await prisma.tenantPlanAssignment.findUnique({ where: { tenantId } });
  if (!assignment?.scheduledPlanVersionId || !assignment.scheduledEffectiveDate) return;
  if (new Date(assignment.scheduledEffectiveDate) > new Date()) return;

  const targetVersion = await prisma.planVersion.findUnique({ where: { id: assignment.scheduledPlanVersionId }, include: { plan: true } });
  if (!targetVersion) return;

  await prisma.$transaction(async (tx) => {
    await tx.tenantPlanAssignment.update({
      where: { tenantId },
      data: { planVersionId: targetVersion.id, previousPlanVersionId: assignment.planVersionId, scheduledPlanVersionId: null, scheduledEffectiveDate: null },
    });
    await tx.tenant.update({ where: { id: tenantId }, data: { plan: targetVersion.plan.slug } });
    await tx.planChangeHistory.create({
      data: {
        tenantId,
        oldPlanVersionId: assignment.planVersionId,
        newPlanVersionId: targetVersion.id,
        reason: "Scheduled plan change applied",
        effectiveDate: new Date(),
      },
    });
  });
}

async function listChangeHistory(tenantId) {
  const rows = await prisma.planChangeHistory.findMany({
    where: { tenantId },
    orderBy: { changedAt: "desc" },
    include: {
      oldPlanVersion: { include: { plan: true } },
      newPlanVersion: { include: { plan: true } },
    },
  });
  return rows;
}

module.exports = {
  getModuleCatalog,
  getPlanLimits,
  getModuleAccess,
  isModuleEnabled,
  isActionEnabled,
  getActivePlanSlugs,
  listPlans,
  getPlanDetail,
  createPlan,
  updatePlanMeta,
  saveDraftVersion,
  publishVersion,
  archiveVersion,
  setPlanStatus,
  clonePlan,
  getTenantAssignment,
  assignPlan,
  schedulePlanChange,
  cancelScheduledChange,
  applyDueScheduledChanges,
  listChangeHistory,
};
