const ApiError = require("../utils/ApiError");

// Vendor resolution - the inverse of Invoice's Customer selector. A Purchase
// Bill never starts from picking an existing Vendor; instead a vendor name
// (+ optional TRN) arrives from OCR extraction or manual entry, and this
// resolves it to a real Vendor row: TRN match wins first (a business's TRN
// is a reliable unique identifier), falling back to a case-insensitive exact
// name match, else silently creating a new Vendor. Runs inside the caller's
// transaction so the created/linked Vendor is consistent with the
// PurchaseBill it's attached to.
async function resolveVendor(tx, tenantId, { name, trn }) {
  const trimmedName = name?.trim();
  const trimmedTrn = trn?.trim() || null;

  const vendors = await tx.vendor.findMany({ where: { tenantId } });

  if (trimmedTrn) {
    const byTrn = vendors.find((v) => v.trn && v.trn === trimmedTrn);
    if (byTrn) return { vendor: byTrn, matchedBy: "trn" };
  }
  if (trimmedName) {
    const byName = vendors.find((v) => v.name.toLowerCase() === trimmedName.toLowerCase());
    if (byName) return { vendor: byName, matchedBy: "name" };
  }

  if (!trimmedName) throw new ApiError(400, "Vendor name is required");

  const created = await tx.vendor.create({
    data: { tenantId, name: trimmedName, trn: trimmedTrn },
  });
  return { vendor: created, matchedBy: "created" };
}

module.exports = { resolveVendor };
