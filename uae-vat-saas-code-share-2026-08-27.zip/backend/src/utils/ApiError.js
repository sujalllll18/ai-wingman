// Thrown intentionally from controllers; caught by the central error handler
// in app.js and turned into a clean { error: "..." } JSON response.
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
  }
}

module.exports = ApiError;
