// Single source of truth for password strength, server-side. Frontend's
// lib/validation.js isValidPassword() mirrors this rule for live UX
// feedback, but this is the one that's actually enforced - a request can
// never bypass it by skipping client-side validation.
const MIN_LENGTH = 8;

function isStrongPassword(password) {
  const value = password || "";
  if (value.length < MIN_LENGTH) return false;
  if (!/[A-Za-z]/.test(value)) return false;
  if (!/[0-9]/.test(value)) return false;
  return true;
}

const PASSWORD_REQUIREMENT_MESSAGE = "Password must be at least 8 characters and include at least one letter and one number.";

module.exports = { isStrongPassword, PASSWORD_REQUIREMENT_MESSAGE };
