const jwt = require("jsonwebtoken");

const EXPIRES_IN = process.env.JWT_EXPIRES_IN || "8h";

function signPlatformAdminToken(admin) {
  return jwt.sign(
    { sub: admin.id, email: admin.email, aud: "platform-admin" },
    process.env.PLATFORM_ADMIN_JWT_SECRET,
    { expiresIn: EXPIRES_IN }
  );
}

function verifyPlatformAdminToken(token) {
  return jwt.verify(token, process.env.PLATFORM_ADMIN_JWT_SECRET, {
    audience: "platform-admin",
  });
}

function signTenantUserToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      tenantId: user.tenantId,
      role: user.role,
      email: user.email,
      // Forced password change (2026-08-09) - baked in at sign time so
      // requireTenantUser never needs an extra DB read to enforce it. A
      // fresh token is always issued after a successful change (see
      // tenantAuth.controller.js's changePassword), so a stale token can
      // never keep claiming mustChangePassword after it's actually false.
      mustChangePassword: !!user.mustChangePassword,
      aud: "tenant-user",
    },
    process.env.TENANT_JWT_SECRET,
    { expiresIn: EXPIRES_IN }
  );
}

function verifyTenantUserToken(token) {
  return jwt.verify(token, process.env.TENANT_JWT_SECRET, {
    audience: "tenant-user",
  });
}

module.exports = {
  signPlatformAdminToken,
  verifyPlatformAdminToken,
  signTenantUserToken,
  verifyTenantUserToken,
};
