// Was the single hardcoded source of truth for subscription plan limits.
// Platform Admin Phase 2 (2026-08-07) moved that source of truth into the
// database (see src/services/plan.service.js, Plan/PlanVersion tables) so
// limits are configurable from the Plan Builder instead of being edited
// here. getPlanLimits is now async and DB-backed; PLAN_LIMITS is kept only
// as the historical reference for what prisma/seed-plans.js seeds the
// TRIAL/STANDARD/PREMIUM plans with - nothing reads this object directly
// anymore.
const PLAN_LIMITS = {
  TRIAL: {
    maxUsers: 2,
    maxInvoicesPerMonth: 20,
    features: { auditLog: false, ocr: false },
  },
  STANDARD: {
    maxUsers: 5,
    maxInvoicesPerMonth: null,
    features: { auditLog: false, ocr: false },
  },
  PREMIUM: {
    maxUsers: null,
    maxInvoicesPerMonth: null,
    features: { auditLog: true, ocr: true },
  },
};

const { getPlanLimits, getActivePlanSlugs } = require("../services/plan.service");

module.exports = { PLAN_LIMITS, getPlanLimits, getActivePlanSlugs };
