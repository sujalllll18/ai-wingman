// Single source of truth for every permission key in the system (RBAC
// module, 2026-08-06 - see docs/features/18-rbac-module.md). This IS the
// seed data for the `Permission` table (seed-rbac.js reads it verbatim) and
// the data the frontend Permission Matrix renders from - nothing here is
// ever invented separately in a controller or a component.
//
// key = "<module>.<action>", lowercase, snake_case multi-word actions.
// Built from the real backend route audit in docs/features/18 - many of
// these actions (approve/reject/authorise/export/import/bulk actions) have
// no real endpoint yet anywhere in the app. They're still defined here so
// the matrix UI is complete and forward-compatible; only modules with a
// real endpoint get requirePermission() actually wired to a route (Phase 6,
// rolled out module by module). An unenforceable permission existing in the
// catalog is not a bug - it's the same honest-placeholder discipline this
// app already uses everywhere else (e.g. Team's disabled Edit button).

const MODULES = [
  {
    module: "dashboard",
    label: "Dashboard",
    group: "Dashboard",
    actions: ["view", "export"],
  },
  {
    module: "business_profile",
    label: "Business Profile",
    group: "Masters",
    actions: [
      "view",
      "edit_contact_details",
      "edit_branding",
      "upload_logo",
      "upload_signature",
      "upload_stamp",
      "upload_documents",
      "preview_invoice",
      "approve",
      "reject",
    ],
  },
  {
    module: "team",
    label: "Team",
    group: "Masters",
    actions: ["view", "create", "edit", "delete", "invite", "activate", "deactivate", "suspend", "reset_password", "assign_role", "export", "approve", "reject"],
  },
  {
    module: "customers",
    label: "Customers",
    group: "Masters",
    actions: ["view", "create", "update", "delete", "import", "export", "activate", "deactivate", "suspend", "merge", "approve", "reject"],
  },
  {
    module: "products",
    label: "Products & Services",
    group: "Masters",
    actions: ["view", "create", "update", "delete", "import", "export", "activate", "deactivate", "archive", "approve", "reject"],
  },
  {
    module: "tax_master",
    label: "Tax Master",
    group: "Masters",
    actions: ["view", "create", "update", "delete", "import", "export", "activate", "deactivate", "approve", "reject"],
  },
  {
    module: "invoices",
    label: "Invoices",
    group: "Transactions",
    actions: [
      "view",
      "create",
      "update",
      "delete_draft",
      "send",
      "duplicate",
      "cancel",
      "void",
      "download_pdf",
      "download_excel",
      "export",
      // "import" added (Import Framework, 2026-08-09) - customers/products/
      // tax_master/purchases already had this key reserved; invoices didn't,
      // even though it's the module the framework's worked example leads
      // with. Gated the same way those already-declared-but-unenforced keys
      // were before their own real endpoint shipped.
      "import",
      "print",
      "approve",
      "reject",
      "authorise",
      "unauthorise",
    ],
  },
  {
    module: "purchases",
    label: "Purchases",
    group: "Transactions",
    actions: ["view", "create", "update", "delete_draft", "approve", "reject", "authorise", "unauthorise", "export", "import", "download", "print"],
  },
  {
    // Credit Notes (2026-08-08) - reduces an existing Sent Invoice. "issue"
    // mirrors invoices' "send"/purchases' equivalent finalizing action -
    // this is the one action routed through Maker-Checker (see
    // approvalExecutors.js). authorise/unauthorise added catalog-only for
    // symmetry with Invoices/Purchases, same "declared, unenforced" pattern
    // already used there.
    module: "credit_notes",
    label: "Credit Notes",
    group: "Transactions",
    // "import" added (Import Framework, 2026-08-09) - same reservation as
    // invoices above; not built in Phase 1 (see the Import Framework plan),
    // catalog-declared now so Phase-2 rollout needs no further catalog edit.
    actions: ["view", "create", "update", "delete_draft", "issue", "void", "download_pdf", "export", "import", "print", "approve", "reject", "authorise", "unauthorise"],
  },
  {
    // Debit Notes (2026-08-08) - increases/corrects an existing Recorded
    // Purchase Bill. Same action set as Credit Notes, mirrored.
    module: "debit_notes",
    label: "Debit Notes",
    group: "Transactions",
    actions: ["view", "create", "update", "delete_draft", "issue", "void", "download_pdf", "export", "import", "print", "approve", "reject", "authorise", "unauthorise"],
  },
  {
    // Sales Debit Note (2026-08-11) - increases an existing Sent Invoice,
    // the sales-side mirror of Credit Notes above. Distinct module key from
    // "debit_notes" (purchase-side) since it's a distinct document type -
    // see prisma/schema.prisma's SalesDebitNote model comment.
    module: "sales_debit_notes",
    label: "Debit Notes",
    group: "Transactions",
    actions: ["view", "create", "update", "delete_draft", "issue", "void", "download_pdf", "export", "import", "print", "approve", "reject", "authorise", "unauthorise"],
  },
  {
    // Customer Payments (Phase 2, 2026-08-22) - receiving money against
    // Invoices, with real allocation across one or many invoices. "allocate"
    // is its own action (distinct from "update") since changing what a
    // payment settles recomputes invoice balances and deserves its own
    // audit trail entry, same reasoning as "issue" being distinct from
    // "update" on Credit/Debit Notes. "cancel" is immediate/RBAC-only (not
    // in APPROVABLE_ACTIONS below), matching how Invoice/PurchaseBill/
    // CreditNote/DebitNote all treat their own void/cancel action.
    // "reconcile" is foundation-only today (see Payment.reconciliationStatus
    // schema comment) - no Reconciliation Engine exists yet to actually
    // match anything against.
    module: "payments",
    label: "Payments Received",
    group: "Transactions",
    actions: ["view", "create", "update", "delete", "allocate", "cancel", "reconcile", "export", "import", "download_pdf", "print", "approve", "reject"],
  },
  {
    // Supplier Payments (Phase 2, 2026-08-22) - the vendor-side mirror,
    // deliberately a separate module key (not reusing "payments") so
    // Customer Payments and Supplier Payments stay independently
    // RBAC/Plan-gateable, matching the credit_notes/debit_notes split.
    module: "purchase_payments",
    label: "Payments Made",
    group: "Transactions",
    actions: ["view", "create", "update", "delete", "allocate", "cancel", "reconcile", "export", "import", "download_pdf", "print", "approve", "reject"],
  },
  {
    // Banking (Phase 3, 2026-08-22) - Bank Accounts + Bank Transactions +
    // Statement Import. "import" mirrors invoices.import/purchases.import/
    // customers.import - a UI-affordance gate on the Banking module's own
    // "Import Statement" entry point, same as those three; the actual
    // upload/mapping/validate/commit endpoints are still gated by the
    // shared imports.* keys (Import Framework, unchanged) regardless of
    // importType. No approve/reject here - Bank Account CRUD is plain
    // RBAC-gated, not routed through Maker-Checker this phase (see
    // bankAccount.controller.js's own comment on why).
    module: "banking",
    label: "Banking",
    group: "Transactions",
    actions: ["view", "create_account", "edit_account", "import", "view_transactions", "export"],
  },
  {
    module: "vat_returns",
    label: "VAT Returns",
    group: "Compliance",
    actions: ["view", "generate", "update_draft", "delete_draft", "lock", "unlock", "approve", "reject", "file", "export", "download", "print"],
  },
  {
    module: "audit_logs",
    label: "Audit Logs",
    group: "Compliance",
    actions: ["view", "export"],
  },
  {
    module: "reports",
    label: "Reports",
    group: "Reports",
    actions: ["view", "generate", "export_pdf", "export_excel", "download", "print"],
  },
  {
    module: "tickets",
    label: "Tickets",
    group: "Support",
    // Support Center (2026-08-07) - expanded from the original 9-action stub
    // to the full set the real ticketing module needs. "update" renamed to
    // "edit" and "resolve" folded into "change_status" (resolving is just a
    // status transition) to match the module's actual action set;
    // "comment"/"internal_note"/"manage_sla" are new. Safe to rename here
    // since nothing was ever wired to the old keys (no real Ticket endpoint
    // existed until this same change) - see docs comment at top of file.
    actions: ["view", "create", "edit", "assign", "comment", "internal_note", "change_status", "close", "reopen", "delete", "export", "manage_sla"],
  },
  {
    module: "roles",
    label: "Roles & Permissions",
    group: "Administration",
    actions: ["view", "create", "update", "delete", "assign_permissions", "clone_role", "assign_users", "activate", "deactivate", "export", "approve", "reject"],
  },
  {
    module: "settings",
    label: "System Settings",
    group: "Settings",
    actions: ["view", "update"],
  },
  // Maker-Checker / Approval Workflow engine (2026-08-06) - the engine's own
  // screens (Pending Approvals queue, Approval History, Approval Rules
  // config). The actual approve/reject decision on a given request is
  // gated by that request's own module's `.approve`/`.reject` key above
  // (e.g. "customers.approve"), never by a key from this module - RBAC
  // still decides WHO per module, this module only decides WHETHER an
  // action pends at all. See src/services/approvalEngine.service.js.
  {
    module: "approvals",
    label: "Approval Workflow",
    group: "Settings",
    actions: ["view", "view_history", "configure"],
  },
  // Import Framework (2026-08-09) - the framework's own screens (Import
  // History, batch detail, the Upload/Map/Validate/Preview wizard). "commit"
  // (not "create"/"import") is the approvable action - uploading/mapping/
  // validating/previewing a batch never writes a ledger row, only Commit
  // does, so that's the one step Maker-Checker can gate. approve/reject
  // here decide the *batch* itself when imports.commit's rule is on - a
  // separate concept from each target module's own <module>.approve (which
  // still gates a normal, non-imported create/send/issue as it always has).
  // pause/resume/retry (2026-08-22, migration-engine hardening) control the
  // running commit/migration itself, once started - distinct from "cancel"
  // (already existed here, unwired to a route until now).
  {
    module: "imports",
    label: "Import Framework",
    group: "Settings",
    actions: ["view", "create", "commit", "cancel", "pause", "resume", "retry", "download_report", "approve", "reject"],
  },
  // Reconciliation Engine (Phase 4, 2026-08-23) - matches Bank Transactions
  // against Payments/Purchase Payments. "match" covers both accepting a
  // system suggestion and building a manual match (the UI affordance to open
  // the Review/Manual Match screen at all); "confirm"/"reject" decide a
  // specific SUGGESTED match; "unmatch" reverses an already-CONFIRMED one
  // (kept separate from "reject" since unmatching a real reconciliation is a
  // more consequential action - same reasoning payments.reconcile is a
  // separate key from payments.cancel); "ignore" is the "no suitable Ledger
  // transaction exists" escape hatch. No approve/reject-via-Maker-Checker
  // routing here - same "plain RBAC-gated, not Maker-Checker this phase"
  // decision bankAccount.controller.js already made for Bank Account CRUD.
  {
    module: "reconciliation",
    label: "Reconciliation",
    group: "Transactions",
    actions: ["view", "match", "confirm", "reject", "unmatch", "ignore", "export"],
  },
];

// A handful of action labels read better with specific casing than naive
// Title Case ("Pdf" -> "PDF") - everything else is derived automatically.
const LABEL_OVERRIDES = {
  download_pdf: "Download PDF",
  download_excel: "Download Excel",
  export_pdf: "Export PDF",
  export_excel: "Export Excel",
};

function actionLabel(action) {
  if (LABEL_OVERRIDES[action]) return LABEL_OVERRIDES[action];
  return action
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

// Flattened [{ key, module, action, group, label, moduleLabel, sortOrder }, ...]
// - what seed-rbac.js and the /api/tenant/roles endpoints actually consume.
const PERMISSIONS = MODULES.flatMap((m) =>
  m.actions.map((action, i) => ({
    key: `${m.module}.${action}`,
    module: m.module,
    moduleLabel: m.label,
    action,
    group: m.group,
    label: actionLabel(action),
    sortOrder: i,
  }))
);

// Actions an Approval Rule can be configured against - the write-ish verbs
// across every module's action vocabulary, deliberately module-agnostic (a
// generic allowlist, not a per-module special case) so Tax Master's
// "create"/"update" and Invoice's "send" are recognized by the same rule
// without either module being named here. Read/export/print-style actions
// (view, export, download_pdf, ...) can never require approval - approving a
// read makes no sense. Used by the Approval Rules config screen to decide
// which catalog rows are offered as configurable, and to keep the module.action
// convention (this module) working for approvalEngine.service.js's dispatch().
const APPROVABLE_ACTIONS = [
  "create",
  "update",
  "delete",
  "edit",
  "delete_draft",
  "send",
  "record",
  "issue",
  "commit",
  "lock",
  "unlock",
  "invite",
  "merge",
  "archive",
  "suspend",
  "activate",
  "deactivate",
  "assign_permissions",
  "assign_role",
  "assign_users",
  "reset_password",
  "clone_role",
  "edit_contact_details",
  "edit_branding",
];

const APPROVABLE_PERMISSIONS = PERMISSIONS.filter((p) => APPROVABLE_ACTIONS.includes(p.action));

module.exports = { MODULES, PERMISSIONS, APPROVABLE_ACTIONS, APPROVABLE_PERMISSIONS };
