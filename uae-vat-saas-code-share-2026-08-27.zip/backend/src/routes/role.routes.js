const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/role.controller");

const router = express.Router();

// Every route below requires requireTenantUser (identity + tenant scoping)
// AND requirePermission (RBAC module, 2026-08-06) - this module dogfoods the
// permission engine on itself from day one, unlike the pre-existing modules
// (Team/Customers/Invoices/etc.) which get requirePermission attached
// incrementally, module by module (see docs/features/18-rbac-module.md
// Phase 6). There is no "existing behavior to preserve" risk here since
// these routes are brand new.
router.get("/permissions-catalog", requireTenantUser, requirePermission("roles.view"), ctrl.listPermissionCatalog);

router.get("/", requireTenantUser, requirePermission("roles.view"), ctrl.listRoles);
router.post("/", requireTenantUser, requirePermission("roles.create"), ctrl.createRole);
router.get("/:id", requireTenantUser, requirePermission("roles.view"), ctrl.getRole);
router.patch("/:id", requireTenantUser, requirePermission("roles.update"), ctrl.updateRole);
router.patch("/:id/permissions", requireTenantUser, requirePermission("roles.assign_permissions"), ctrl.updateRolePermissions);
router.delete("/:id", requireTenantUser, requirePermission("roles.delete"), ctrl.deleteRole);
router.post("/:id/assign-users", requireTenantUser, requirePermission("roles.assign_users"), ctrl.assignUsers);

module.exports = router;
