const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/invoice.controller");

const router = express.Router();

// All routes require a logged-in Tenant user, same guard every other tenant
// module uses - plus the matching invoices.* permission (RBAC module Phase 6,
// 2026-08-06). Every query is still scoped by req.tenantId from the JWT.
// A few real actions here (line-item edits, payment-status, internal notes)
// have no dedicated catalog action of their own - they fall back to the
// general invoices.update permission rather than inventing a new key outside
// the approved catalog. archive/restore map to invoices.cancel as the
// closest existing "no longer active" concept in the catalog.
router.get("/", requireTenantUser, requirePermission("invoices.view"), ctrl.listInvoices);
router.post("/", requireTenantUser, requirePermission("invoices.create"), ctrl.createInvoice);
router.get("/:id", requireTenantUser, requirePermission("invoices.view"), ctrl.getInvoice);
router.patch("/:id", requireTenantUser, requirePermission("invoices.update"), ctrl.updateInvoice);
router.delete("/:id", requireTenantUser, requirePermission("invoices.delete_draft"), ctrl.deleteInvoice);

router.post("/:id/line-items", requireTenantUser, requirePermission("invoices.update"), ctrl.addLineItem);
router.patch("/:id/line-items/:lineId", requireTenantUser, requirePermission("invoices.update"), ctrl.updateLineItem);
router.delete("/:id/line-items/:lineId", requireTenantUser, requirePermission("invoices.update"), ctrl.deleteLineItem);

router.post("/:id/send", requireTenantUser, requirePermission("invoices.send"), ctrl.sendInvoice);
router.post("/:id/void", requireTenantUser, requirePermission("invoices.void"), ctrl.voidInvoice);
router.patch("/:id/payment-status", requireTenantUser, requirePermission("invoices.update"), ctrl.updatePaymentStatus);

// Sprint 3 - Invoice Operations
router.post("/:id/payments", requireTenantUser, requirePermission("invoices.update"), ctrl.recordPayment);
router.patch("/:id/internal-notes", requireTenantUser, requirePermission("invoices.update"), ctrl.updateInternalNotes);
router.post("/:id/archive", requireTenantUser, requirePermission("invoices.cancel"), ctrl.archiveInvoice);
router.post("/:id/restore", requireTenantUser, requirePermission("invoices.cancel"), ctrl.restoreInvoice);
router.post("/:id/duplicate", requireTenantUser, requirePermission("invoices.duplicate"), ctrl.duplicateInvoice);
router.post("/:id/activity", requireTenantUser, requirePermission("invoices.view"), ctrl.logInvoiceActivity);

module.exports = router;
