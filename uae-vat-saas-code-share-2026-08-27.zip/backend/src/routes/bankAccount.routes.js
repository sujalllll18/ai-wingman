const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/bankAccount.controller");

const router = express.Router();

router.get("/", requireTenantUser, requirePermission("banking.view"), ctrl.listBankAccounts);
router.post("/", requireTenantUser, requirePermission("banking.create_account"), ctrl.createBankAccount);
router.get("/:id", requireTenantUser, requirePermission("banking.view"), ctrl.getBankAccount);
router.patch("/:id", requireTenantUser, requirePermission("banking.edit_account"), ctrl.updateBankAccount);

module.exports = router;
