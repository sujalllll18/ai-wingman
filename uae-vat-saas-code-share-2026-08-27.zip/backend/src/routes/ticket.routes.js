const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ticketUpload = require("../middleware/ticketUpload");
const ctrl = require("../controllers/ticket.controller");

const router = express.Router();

router.use(requireTenantUser);

router.get("/categories", ctrl.listCategories);
router.get("/", requirePermission("tickets.view"), ctrl.listTickets);
router.post("/", requirePermission("tickets.create"), ctrl.createTicket);
router.get("/:id", requirePermission("tickets.view"), ctrl.getTicket);
router.post("/:id/reply", requirePermission("tickets.comment"), ctrl.reply);
router.post("/:id/reopen", requirePermission("tickets.reopen"), ctrl.reopen);
router.post("/:id/close", requirePermission("tickets.close"), ctrl.close);
router.post("/:id/attachments", requirePermission("tickets.comment"), ticketUpload.single("file"), ctrl.addAttachment);

module.exports = router;
