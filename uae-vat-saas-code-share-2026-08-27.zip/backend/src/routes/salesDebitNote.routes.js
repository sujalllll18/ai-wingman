const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/salesDebitNote.controller");

const router = express.Router();

// Same guard pattern as creditNote.routes.js - requireTenantUser then
// requirePermission, every query still scoped by req.tenantId from the JWT.
router.get("/", requireTenantUser, requirePermission("sales_debit_notes.view"), ctrl.listSalesDebitNotes);
router.post("/", requireTenantUser, requirePermission("sales_debit_notes.create"), ctrl.createSalesDebitNote);
router.get("/:id", requireTenantUser, requirePermission("sales_debit_notes.view"), ctrl.getSalesDebitNote);
router.patch("/:id", requireTenantUser, requirePermission("sales_debit_notes.update"), ctrl.updateSalesDebitNote);
router.delete("/:id", requireTenantUser, requirePermission("sales_debit_notes.delete_draft"), ctrl.deleteSalesDebitNote);

router.post("/:id/line-items", requireTenantUser, requirePermission("sales_debit_notes.update"), ctrl.addLineItem);
router.patch("/:id/line-items/:lineId", requireTenantUser, requirePermission("sales_debit_notes.update"), ctrl.updateLineItem);
router.delete("/:id/line-items/:lineId", requireTenantUser, requirePermission("sales_debit_notes.update"), ctrl.deleteLineItem);

router.post("/:id/issue", requireTenantUser, requirePermission("sales_debit_notes.issue"), ctrl.issueSalesDebitNote);
router.post("/:id/void", requireTenantUser, requirePermission("sales_debit_notes.void"), ctrl.voidSalesDebitNote);
router.post("/:id/activity", requireTenantUser, requirePermission("sales_debit_notes.view"), ctrl.logSalesDebitNoteActivity);

module.exports = router;
