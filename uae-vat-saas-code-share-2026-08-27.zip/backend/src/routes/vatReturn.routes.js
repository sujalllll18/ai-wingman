const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/vatReturn.controller");

const router = express.Router();

// Gated by vat_returns.* (RBAC module Phase 6, 2026-08-06). Regenerate maps
// to vat_returns.generate (same action, re-run) rather than a separate key.
router.get("/", requireTenantUser, requirePermission("vat_returns.view"), ctrl.listVatReturns);
router.post("/", requireTenantUser, requirePermission("vat_returns.generate"), ctrl.generateVatReturn);
router.get("/:id", requireTenantUser, requirePermission("vat_returns.view"), ctrl.getVatReturn);
router.post("/:id/regenerate", requireTenantUser, requirePermission("vat_returns.generate"), ctrl.regenerateVatReturn);
router.post("/:id/lock", requireTenantUser, requirePermission("vat_returns.lock"), ctrl.lockVatReturn);
router.post("/:id/unlock", requireTenantUser, requirePermission("vat_returns.unlock"), ctrl.unlockVatReturn);
router.get("/:id/drilldown", requireTenantUser, requirePermission("vat_returns.view"), ctrl.getDrilldown);
router.post("/:id/activity", requireTenantUser, requirePermission("vat_returns.view"), ctrl.logVatReturnActivity);

module.exports = router;
