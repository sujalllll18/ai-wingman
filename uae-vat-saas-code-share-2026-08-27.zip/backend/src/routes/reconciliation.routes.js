const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/reconciliation.controller");

const router = express.Router();

// Same guard convention as every other tenant module - requireTenantUser
// then the matching reconciliation.* permission (+ Plan gating, both
// resolved inside requirePermission). Literal sub-paths ("/dashboard",
// "/run", "/transactions", "/matches") are registered before any ":id"
// route so they're never swallowed by an id param.
router.get("/dashboard", requireTenantUser, requirePermission("reconciliation.view"), ctrl.getDashboard);
router.get("/transactions", requireTenantUser, requirePermission("reconciliation.view"), ctrl.listReconciliation);
router.post("/run", requireTenantUser, requirePermission("reconciliation.match"), ctrl.runMatching);

router.get("/transactions/:id", requireTenantUser, requirePermission("reconciliation.view"), ctrl.getTransactionDetail);
router.get("/transactions/:id/suggestions", requireTenantUser, requirePermission("reconciliation.view"), ctrl.getSuggestions);
router.get("/transactions/:id/search", requireTenantUser, requirePermission("reconciliation.match"), ctrl.searchLedgerCandidates);
router.post("/transactions/:id/ignore", requireTenantUser, requirePermission("reconciliation.ignore"), ctrl.ignoreTransaction);
router.post("/transactions/:id/unignore", requireTenantUser, requirePermission("reconciliation.ignore"), ctrl.unignoreTransaction);

router.post("/matches", requireTenantUser, requirePermission("reconciliation.confirm"), ctrl.confirmMatch);
router.get("/matches/:id", requireTenantUser, requirePermission("reconciliation.view"), ctrl.getMatch);
router.post("/matches/:id/reject", requireTenantUser, requirePermission("reconciliation.reject"), ctrl.rejectMatch);
router.post("/matches/:id/unmatch", requireTenantUser, requirePermission("reconciliation.unmatch"), ctrl.unmatchMatch);

module.exports = router;
