const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const { requirePlatformAdmin } = require("../middleware/auth");
const ticketUpload = require("../middleware/ticketUpload");
const ApiError = require("../utils/ApiError");
const ctrl = require("../controllers/platformAdmin.controller");
const planCtrl = require("../controllers/plan.controller");
const ticketAdminCtrl = require("../controllers/ticketAdmin.controller");
const migrationCtrl = require("../controllers/platformAdminMigration.controller");

const router = express.Router();

// Same disk-storage + mime-allowlist pattern as migration.routes.js
// (tenant side) - Platform-Admin-triggered migration uploads land in the
// same uploads/imports/ directory, indistinguishable on disk from a
// tenant-uploaded one.
const migrationUpload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "..", "..", "uploads", "imports"),
    filename: (req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = ["text/csv", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"].includes(file.mimetype);
    cb(ok ? null : new ApiError(400, "Only CSV or Excel (.xlsx/.xls) files are accepted"), ok);
  },
});

// Public
router.post("/login", ctrl.login);

// Protected - Platform Admin only
router.get("/tenants", requirePlatformAdmin, ctrl.listTenants);
router.post("/tenants", requirePlatformAdmin, ctrl.createTenant);
router.patch("/tenants/:id/plan", requirePlatformAdmin, ctrl.updateTenantPlan);
router.patch("/tenants/:id/suspend", requirePlatformAdmin, ctrl.suspendTenant);
router.patch("/tenants/:id/reactivate", requirePlatformAdmin, ctrl.reactivateTenant);
router.post("/tenants/:id/staff", requirePlatformAdmin, ctrl.createStaffUser);
router.get("/tenants/:id/users", requirePlatformAdmin, ctrl.listTenantUsers);
router.get("/tenants/:id/usage", requirePlatformAdmin, ctrl.getTenantUsage);

// Phase 2 - Subscription Plans / Plan Builder (2026-08-07)
router.get("/module-catalog", requirePlatformAdmin, planCtrl.getModuleCatalog);
router.get("/plans", requirePlatformAdmin, planCtrl.listPlans);
router.post("/plans", requirePlatformAdmin, planCtrl.createPlan);
router.get("/plans/:id", requirePlatformAdmin, planCtrl.getPlan);
router.patch("/plans/:id", requirePlatformAdmin, planCtrl.updatePlanMeta);
router.post("/plans/:id/clone", requirePlatformAdmin, planCtrl.clonePlan);
router.patch("/plans/:id/status", requirePlatformAdmin, planCtrl.setPlanStatus);
router.post("/plans/:id/versions", requirePlatformAdmin, planCtrl.saveDraftVersion);
router.post("/plan-versions/:versionId/publish", requirePlatformAdmin, planCtrl.publishVersion);
router.post("/plan-versions/:versionId/archive", requirePlatformAdmin, planCtrl.archiveVersion);

router.get("/tenants/:id/plan-assignment", requirePlatformAdmin, planCtrl.getTenantAssignment);
router.post("/tenants/:id/plan-assignment", requirePlatformAdmin, planCtrl.assignPlan);
router.post("/tenants/:id/plan-assignment/schedule", requirePlatformAdmin, planCtrl.scheduleChange);
router.delete("/tenants/:id/plan-assignment/schedule", requirePlatformAdmin, planCtrl.cancelScheduledChange);
router.get("/tenants/:id/plan-change-history", requirePlatformAdmin, planCtrl.listChangeHistory);

// Support Center (2026-08-07) - platform admin / support team side
router.get("/support/dashboard", requirePlatformAdmin, ticketAdminCtrl.getDashboard);
router.get("/support/categories", requirePlatformAdmin, ticketAdminCtrl.listCategories);
router.get("/support/sla-policies", requirePlatformAdmin, ticketAdminCtrl.listSlaPolicies);
router.get("/support/admins", requirePlatformAdmin, ticketAdminCtrl.listAdmins);
router.get("/support/tickets", requirePlatformAdmin, ticketAdminCtrl.listTickets);
router.get("/support/tickets/:id", requirePlatformAdmin, ticketAdminCtrl.getTicket);
router.post("/support/tickets/:id/comments", requirePlatformAdmin, ticketAdminCtrl.addComment);
router.post("/support/tickets/:id/assign", requirePlatformAdmin, ticketAdminCtrl.assign);
router.post("/support/tickets/:id/priority", requirePlatformAdmin, ticketAdminCtrl.changePriority);
router.post("/support/tickets/:id/status", requirePlatformAdmin, ticketAdminCtrl.changeStatus);
router.post("/support/tickets/:id/watchers", requirePlatformAdmin, ticketAdminCtrl.addWatcher);
router.delete("/support/tickets/:id/watchers/:watcherId", requirePlatformAdmin, ticketAdminCtrl.removeWatcher);
router.post("/support/tickets/:id/merge", requirePlatformAdmin, ticketAdminCtrl.merge);
router.post("/support/tickets/:id/link", requirePlatformAdmin, ticketAdminCtrl.link);
router.post("/support/tickets/:id/attachments", requirePlatformAdmin, ticketUpload.single("file"), ticketAdminCtrl.addAttachment);

// Migration (2026-08-22) - lets Platform Admin start/drive a historical
// data migration for a tenant, reusing the same importEngine.service.js +
// migrationOrchestrator.service.js as the tenant self-service "Migration
// Center" (migration.routes.js). See platformAdminMigration.controller.js's
// header comment for why this needs its own per-file pass-through routes.
router.get("/tenants/:tenantId/migrations/types", requirePlatformAdmin, migrationCtrl.listImportTypes);
router.get("/tenants/:tenantId/migrations", requirePlatformAdmin, migrationCtrl.listMigrations);
router.post("/tenants/:tenantId/migrations", requirePlatformAdmin, migrationUpload.array("files", 10), migrationCtrl.createMigration);
router.get("/tenants/:tenantId/migrations/data-counts", requirePlatformAdmin, migrationCtrl.getDataCounts);
router.get("/tenants/:tenantId/migrations/:id", requirePlatformAdmin, migrationCtrl.getMigration);
router.get("/tenants/:tenantId/migrations/:id/preview", requirePlatformAdmin, migrationCtrl.getMigrationPreview);
router.get("/tenants/:tenantId/migrations/:id/status", requirePlatformAdmin, migrationCtrl.getMigrationStatus);
router.get("/tenants/:tenantId/migrations/:id/error-report", requirePlatformAdmin, migrationCtrl.downloadErrorReport);
router.post("/tenants/:tenantId/migrations/:id/commit", requirePlatformAdmin, migrationCtrl.commitMigration);
router.post("/tenants/:tenantId/migrations/:id/pause", requirePlatformAdmin, migrationCtrl.pauseMigration);
router.post("/tenants/:tenantId/migrations/:id/resume", requirePlatformAdmin, migrationCtrl.resumeMigration);
router.post("/tenants/:tenantId/migrations/:id/cancel", requirePlatformAdmin, migrationCtrl.cancelMigration);
router.post("/tenants/:tenantId/migrations/:id/retry-failed", requirePlatformAdmin, migrationCtrl.retryFailed);
router.post("/tenants/:tenantId/migrations/batches/:batchId/mapping", requirePlatformAdmin, migrationCtrl.setBatchMapping);
router.post("/tenants/:tenantId/migrations/batches/:batchId/validate", requirePlatformAdmin, migrationCtrl.validateBatch);
router.get("/tenants/:tenantId/migrations/batches/:batchId/preview", requirePlatformAdmin, migrationCtrl.previewBatch);
router.get("/tenants/:tenantId/migrations/batches/:batchId/records", requirePlatformAdmin, migrationCtrl.getBatchRecords);

module.exports = router;
