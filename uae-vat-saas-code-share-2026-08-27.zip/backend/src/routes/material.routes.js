const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/material.controller");

const router = express.Router();

// All routes require a logged-in Tenant user, same guard as Team/Customers -
// plus the matching products.* permission (RBAC module Phase 6, 2026-08-06).
// Every query is still scoped by req.tenantId from the JWT.
router.get("/", requireTenantUser, requirePermission("products.view"), ctrl.listMaterials);
router.post("/", requireTenantUser, requirePermission("products.create"), ctrl.createMaterial);
router.get("/:id", requireTenantUser, requirePermission("products.view"), ctrl.getMaterial);
router.patch("/:id", requireTenantUser, requirePermission("products.update"), ctrl.updateMaterial);

module.exports = router;
