const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/debitNote.controller");

const router = express.Router();

router.get("/", requireTenantUser, requirePermission("debit_notes.view"), ctrl.listDebitNotes);
router.post("/", requireTenantUser, requirePermission("debit_notes.create"), ctrl.createDebitNote);
router.get("/:id", requireTenantUser, requirePermission("debit_notes.view"), ctrl.getDebitNote);
router.patch("/:id", requireTenantUser, requirePermission("debit_notes.update"), ctrl.updateDebitNote);
router.delete("/:id", requireTenantUser, requirePermission("debit_notes.delete_draft"), ctrl.deleteDebitNote);

router.post("/:id/line-items", requireTenantUser, requirePermission("debit_notes.update"), ctrl.addLineItem);
router.patch("/:id/line-items/:lineId", requireTenantUser, requirePermission("debit_notes.update"), ctrl.updateLineItem);
router.delete("/:id/line-items/:lineId", requireTenantUser, requirePermission("debit_notes.update"), ctrl.deleteLineItem);

router.post("/:id/issue", requireTenantUser, requirePermission("debit_notes.issue"), ctrl.issueDebitNote);
router.post("/:id/void", requireTenantUser, requirePermission("debit_notes.void"), ctrl.voidDebitNote);
router.post("/:id/activity", requireTenantUser, requirePermission("debit_notes.view"), ctrl.logDebitNoteActivity);

module.exports = router;
