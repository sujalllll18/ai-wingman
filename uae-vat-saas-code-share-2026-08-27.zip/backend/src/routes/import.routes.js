const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ApiError = require("../utils/ApiError");
const ctrl = require("../controllers/import.controller");

const router = express.Router();

const ALLOWED_MIME_TYPES = [
  "text/csv",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
];

// Disk storage under uploads/imports (served statically, see app.js) - same
// randomized-filename pattern as Purchase OCR's uploads/purchases.
const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "..", "uploads", "imports"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new ApiError(400, "Only CSV or Excel (.xlsx/.xls) files are accepted"));
    }
    cb(null, true);
  },
});

// All routes require a logged-in Tenant user + the matching imports.*
// permission (RBAC module, Import Framework 2026-08-09). Every query is
// still scoped by req.tenantId from the JWT.
router.get("/types", requireTenantUser, requirePermission("imports.view"), ctrl.listImportTypes);

router.get("/", requireTenantUser, requirePermission("imports.view"), ctrl.listBatches);
router.post("/", requireTenantUser, requirePermission("imports.create"), upload.single("file"), ctrl.createBatch);

router.get("/:id", requireTenantUser, requirePermission("imports.view"), ctrl.getBatch);
router.get("/:id/records", requireTenantUser, requirePermission("imports.view"), ctrl.getRecords);
router.get("/:id/preview", requireTenantUser, requirePermission("imports.view"), ctrl.previewBatch);
router.get("/:id/error-report", requireTenantUser, requirePermission("imports.download_report"), ctrl.downloadErrorReport);

router.post("/:id/mapping", requireTenantUser, requirePermission("imports.create"), ctrl.setMapping);
router.post("/:id/validate", requireTenantUser, requirePermission("imports.create"), ctrl.validateBatch);
router.post("/:id/commit", requireTenantUser, requirePermission("imports.commit"), ctrl.commitBatch);

// Migration-engine controls (fault-tolerance/resumability, 2026-08-22).
router.post("/:id/pause", requireTenantUser, requirePermission("imports.pause"), ctrl.pauseBatch);
router.post("/:id/resume", requireTenantUser, requirePermission("imports.resume"), ctrl.resumeBatch);
router.post("/:id/cancel", requireTenantUser, requirePermission("imports.cancel"), ctrl.cancelBatch);
router.post("/:id/retry-failed", requireTenantUser, requirePermission("imports.retry"), ctrl.retryFailed);

module.exports = router;
