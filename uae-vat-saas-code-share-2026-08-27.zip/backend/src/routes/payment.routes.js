const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/payment.controller");

const router = express.Router();

// Same guard convention as every other tenant module - requireTenantUser
// then the matching payments.* permission (+ Plan gating, both resolved
// inside requirePermission). "/allocatable-invoices" is registered before
// "/:id" so it's never swallowed by the id-param route.
router.get("/", requireTenantUser, requirePermission("payments.view"), ctrl.listPayments);
router.get("/allocatable-invoices", requireTenantUser, requirePermission("payments.view"), ctrl.listAllocatableInvoices);
router.post("/", requireTenantUser, requirePermission("payments.create"), ctrl.createPayment);
router.get("/:id", requireTenantUser, requirePermission("payments.view"), ctrl.getPayment);
router.patch("/:id", requireTenantUser, requirePermission("payments.update"), ctrl.updatePayment);
router.post("/:id/allocate", requireTenantUser, requirePermission("payments.allocate"), ctrl.reallocatePayment);
router.post("/:id/cancel", requireTenantUser, requirePermission("payments.cancel"), ctrl.cancelPayment);
router.delete("/:id", requireTenantUser, requirePermission("payments.delete"), ctrl.deletePayment);
router.post("/:id/reconcile", requireTenantUser, requirePermission("payments.reconcile"), ctrl.reconcilePayment);
router.post("/:id/unreconcile", requireTenantUser, requirePermission("payments.reconcile"), ctrl.unreconcilePayment);

module.exports = router;
