const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/vendor.controller");

const router = express.Router();

// Vendors are Purchases' supporting data - no standalone catalog module of
// their own, gated by purchases.view (RBAC module Phase 6, 2026-08-06).
router.get("/", requireTenantUser, requirePermission("purchases.view"), ctrl.listVendors);

module.exports = router;
