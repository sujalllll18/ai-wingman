const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/tenantAuth.controller");

const router = express.Router();

// Public
router.post("/login", ctrl.login);

// Protected - team.view (RBAC module Phase 6, 2026-08-06). /me/permissions
// stays gated by identity alone (requireTenantUser) - it answers "what can
// I do," so it can never itself be permission-gated without a lockout risk.
router.get("/team", requireTenantUser, requirePermission("team.view"), ctrl.listTeam);
// Team self-service (2026-08-09) - team.create/team.deactivate/team.activate
// were already reserved permission-catalog keys, never enforced anywhere
// until now (see permissionCatalog.js's own comment: many actions are
// declared before their first real endpoint exists).
router.post("/team", requireTenantUser, requirePermission("team.create"), ctrl.createTeamMember);
router.patch("/team/:id/deactivate", requireTenantUser, requirePermission("team.deactivate"), ctrl.deactivateTeamMember);
router.patch("/team/:id/activate", requireTenantUser, requirePermission("team.activate"), ctrl.activateTeamMember);
router.get("/me/permissions", requireTenantUser, ctrl.getMyPermissions);
// Forced password change (2026-08-09) - identity-gated only (like
// /me/permissions above), no requirePermission: every authenticated tenant
// user can always change their own password. Explicitly allowlisted inside
// requireTenantUser so it stays reachable even while mustChangePassword
// blocks every other tenant route.
router.post("/change-password", requireTenantUser, ctrl.changePassword);

module.exports = router;
