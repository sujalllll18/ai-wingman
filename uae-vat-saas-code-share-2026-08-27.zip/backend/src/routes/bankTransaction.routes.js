const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/bankTransaction.controller");

const router = express.Router();

router.get("/", requireTenantUser, requirePermission("banking.view_transactions"), ctrl.listBankTransactions);
router.get("/:id", requireTenantUser, requirePermission("banking.view_transactions"), ctrl.getBankTransaction);

module.exports = router;
