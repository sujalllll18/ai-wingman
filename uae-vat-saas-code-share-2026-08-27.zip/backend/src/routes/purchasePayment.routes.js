const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/purchasePayment.controller");

const router = express.Router();

router.get("/", requireTenantUser, requirePermission("purchase_payments.view"), ctrl.listPurchasePayments);
router.get("/allocatable-bills", requireTenantUser, requirePermission("purchase_payments.view"), ctrl.listAllocatableBills);
router.post("/", requireTenantUser, requirePermission("purchase_payments.create"), ctrl.createPurchasePayment);
router.get("/:id", requireTenantUser, requirePermission("purchase_payments.view"), ctrl.getPurchasePayment);
router.patch("/:id", requireTenantUser, requirePermission("purchase_payments.update"), ctrl.updatePurchasePayment);
router.post("/:id/allocate", requireTenantUser, requirePermission("purchase_payments.allocate"), ctrl.reallocatePurchasePayment);
router.post("/:id/cancel", requireTenantUser, requirePermission("purchase_payments.cancel"), ctrl.cancelPurchasePayment);
router.delete("/:id", requireTenantUser, requirePermission("purchase_payments.delete"), ctrl.deletePurchasePayment);
router.post("/:id/reconcile", requireTenantUser, requirePermission("purchase_payments.reconcile"), ctrl.reconcilePurchasePayment);
router.post("/:id/unreconcile", requireTenantUser, requirePermission("purchase_payments.reconcile"), ctrl.unreconcilePurchasePayment);

module.exports = router;
