const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ApiError = require("../utils/ApiError");
const ctrl = require("../controllers/migration.controller");

const router = express.Router();

// Same disk-storage + mime-allowlist pattern as import.routes.js, just
// upload.array() instead of upload.single() for the multi-file Migration
// wizard. Files land in the same uploads/imports/ directory - a Migration's
// child ImportBatch rows are otherwise indistinguishable from standalone
// ones on disk.
const ALLOWED_MIME_TYPES = [
  "text/csv",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
];
const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "..", "uploads", "imports"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB per file
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new ApiError(400, "Only CSV or Excel (.xlsx/.xls) files are accepted"));
    }
    cb(null, true);
  },
});

// All routes reuse the EXISTING imports.* permission keys (no new RBAC
// catalog entries, no backfill needed) - a Migration is just "several
// imports orchestrated together" from a permissions perspective.
router.get("/", requireTenantUser, requirePermission("imports.view"), ctrl.listMigrations);
router.post("/", requireTenantUser, requirePermission("imports.create"), upload.array("files", 10), ctrl.createMigration);
router.get("/data-counts", requireTenantUser, requirePermission("imports.view"), ctrl.getDataCounts);

router.get("/:id", requireTenantUser, requirePermission("imports.view"), ctrl.getMigration);
router.get("/:id/preview", requireTenantUser, requirePermission("imports.view"), ctrl.getMigrationPreview);
router.get("/:id/status", requireTenantUser, requirePermission("imports.view"), ctrl.getMigrationStatus);
router.get("/:id/error-report", requireTenantUser, requirePermission("imports.download_report"), ctrl.downloadErrorReport);

router.post("/:id/commit", requireTenantUser, requirePermission("imports.commit"), ctrl.commitMigration);
router.post("/:id/pause", requireTenantUser, requirePermission("imports.pause"), ctrl.pauseMigration);
router.post("/:id/resume", requireTenantUser, requirePermission("imports.resume"), ctrl.resumeMigration);
router.post("/:id/cancel", requireTenantUser, requirePermission("imports.cancel"), ctrl.cancelMigration);
router.post("/:id/retry-failed", requireTenantUser, requirePermission("imports.retry"), ctrl.retryFailed);

module.exports = router;
