const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/customer.controller");

const router = express.Router();

// All routes require a logged-in Tenant user (Owner or Staff) - same guard
// Team already uses - plus the matching customers.* permission (RBAC module
// Phase 6, 2026-08-06). Every query is still scoped by req.tenantId from the JWT.
router.get("/", requireTenantUser, requirePermission("customers.view"), ctrl.listCustomers);
router.post("/", requireTenantUser, requirePermission("customers.create"), ctrl.createCustomer);
router.get("/:id", requireTenantUser, requirePermission("customers.view"), ctrl.getCustomer);
router.patch("/:id", requireTenantUser, requirePermission("customers.update"), ctrl.updateCustomer);

module.exports = router;
