const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/tax.controller");

const router = express.Router();

// Tenant-scoped CRUD only - no /resolve route here on purpose. Tax
// resolution stays an internal backend service (src/services/taxResolver.js)
// for future modules to call directly, never a public endpoint. Gated by
// tax_master.* (RBAC module Phase 6, 2026-08-06) - Categories and Rates
// share one permission set since they're one module in the catalog.
router.get("/categories", requireTenantUser, requirePermission("tax_master.view"), ctrl.listTaxCategories);
router.post("/categories", requireTenantUser, requirePermission("tax_master.create"), ctrl.createTaxCategory);
router.get("/categories/:id", requireTenantUser, requirePermission("tax_master.view"), ctrl.getTaxCategory);
router.patch("/categories/:id", requireTenantUser, requirePermission("tax_master.update"), ctrl.updateTaxCategory);

router.get("/rates", requireTenantUser, requirePermission("tax_master.view"), ctrl.listTaxRates);
router.post("/rates", requireTenantUser, requirePermission("tax_master.create"), ctrl.createTaxRate);
router.get("/rates/:id", requireTenantUser, requirePermission("tax_master.view"), ctrl.getTaxRate);
// "Create New Version" (2026-08-06) - replaces the old in-place PATCH /rates/:id.
// A Tax Rate is never edited in place anymore; see tax.controller.js.
router.post("/rates/:id/versions", requireTenantUser, requirePermission("tax_master.update"), ctrl.createTaxRateVersion);
router.post("/rates/:id/activate", requireTenantUser, requirePermission("tax_master.activate"), ctrl.activateTaxRate);
router.post("/rates/:id/deactivate", requireTenantUser, requirePermission("tax_master.deactivate"), ctrl.deactivateTaxRate);
router.delete("/rates/:id", requireTenantUser, requirePermission("tax_master.delete"), ctrl.deleteTaxRate);

module.exports = router;
