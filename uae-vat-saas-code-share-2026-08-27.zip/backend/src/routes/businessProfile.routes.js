const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ApiError = require("../utils/ApiError");
const ctrl = require("../controllers/businessProfile.controller");

const router = express.Router();

const ALLOWED_MIME_TYPES = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"];
const ASSET_PERMISSION = { logo: "business_profile.upload_logo", stamp: "business_profile.upload_stamp", signature: "business_profile.upload_signature" };

// Disk storage under uploads/business (served statically, see app.js) - same
// randomized-filename pattern as Purchase/Import uploads. 2MB shared ceiling
// here (multer can't vary its limit by fieldname/route param); the tighter
// per-asset-type limits (1MB signature) are enforced in the controller.
const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "..", "uploads", "business"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new ApiError(400, "Only PNG, JPEG, WEBP, or SVG files are accepted"));
    }
    cb(null, true);
  },
});

// requirePermission needs a static key, but the asset-type-specific
// permission depends on req.params.assetType - this small factory resolves
// it per-request rather than adding a new, more generic permission key that
// doesn't distinguish logo/stamp/signature (the catalog already models them
// separately, so enforcement should too).
function requireAssetPermission(req, res, next) {
  const key = ASSET_PERMISSION[req.params.assetType];
  if (!key) throw new ApiError(404, "Unknown asset type");
  return requirePermission(key)(req, res, next);
}

router.get("/", requireTenantUser, requirePermission("business_profile.view"), ctrl.getBusinessProfile);
router.patch("/", requireTenantUser, requirePermission("business_profile.edit_contact_details"), ctrl.updateBusinessProfile);

router.post("/:assetType", requireTenantUser, requireAssetPermission, upload.single("file"), ctrl.uploadBusinessAsset);
router.delete("/:assetType", requireTenantUser, requireAssetPermission, ctrl.removeBusinessAsset);

module.exports = router;
