const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/creditNote.controller");

const router = express.Router();

// Same guard pattern as every other tenant module - requireTenantUser
// (identity + tenant scoping) then requirePermission (RBAC). Every query is
// still scoped by req.tenantId from the JWT, never a client-supplied id.
router.get("/", requireTenantUser, requirePermission("credit_notes.view"), ctrl.listCreditNotes);
router.post("/", requireTenantUser, requirePermission("credit_notes.create"), ctrl.createCreditNote);
router.get("/:id", requireTenantUser, requirePermission("credit_notes.view"), ctrl.getCreditNote);
router.patch("/:id", requireTenantUser, requirePermission("credit_notes.update"), ctrl.updateCreditNote);
router.delete("/:id", requireTenantUser, requirePermission("credit_notes.delete_draft"), ctrl.deleteCreditNote);

router.post("/:id/line-items", requireTenantUser, requirePermission("credit_notes.update"), ctrl.addLineItem);
router.patch("/:id/line-items/:lineId", requireTenantUser, requirePermission("credit_notes.update"), ctrl.updateLineItem);
router.delete("/:id/line-items/:lineId", requireTenantUser, requirePermission("credit_notes.update"), ctrl.deleteLineItem);

router.post("/:id/issue", requireTenantUser, requirePermission("credit_notes.issue"), ctrl.issueCreditNote);
router.post("/:id/void", requireTenantUser, requirePermission("credit_notes.void"), ctrl.voidCreditNote);
router.post("/:id/activity", requireTenantUser, requirePermission("credit_notes.view"), ctrl.logCreditNoteActivity);

module.exports = router;
