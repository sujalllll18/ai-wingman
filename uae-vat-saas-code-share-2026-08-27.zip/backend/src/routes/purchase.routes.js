const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ApiError = require("../utils/ApiError");
const ctrl = require("../controllers/purchase.controller");

const router = express.Router();

const ALLOWED_MIME_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

// Disk storage under uploads/purchases (served statically, see app.js).
// Filenames are randomized - never trust/reuse the original filename on
// disk, since it's user-supplied.
const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "..", "uploads", "purchases"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new ApiError(400, "Only PDF, JPEG, PNG, or WEBP files are accepted"));
    }
    cb(null, true);
  },
});

// All routes require a logged-in Tenant user, same guard every other tenant
// module uses - plus the matching purchases.* permission (RBAC module
// Phase 6, 2026-08-06). Every query is still scoped by req.tenantId from the
// JWT. Several real actions (record/void/line-items/attachments/etc.) have
// no dedicated catalog action of their own - they fall back to the general
// purchases.update permission rather than inventing a new key outside the
// approved catalog (unlike Invoices, the Purchases catalog has no distinct
// send/void/cancel/duplicate actions - a gap in the requested spec, not
// something this rollout can silently fix by adding keys nobody approved).
router.get("/", requireTenantUser, requirePermission("purchases.view"), ctrl.listPurchases);
router.post("/", requireTenantUser, requirePermission("purchases.create"), ctrl.createPurchase);

// OCR Upload flow - extract is stateless (no DB write beyond the file
// itself), confirm is what actually creates the Purchase Bill.
router.post("/ocr/extract", requireTenantUser, requirePermission("purchases.create"), upload.single("file"), ctrl.extractOcr);
router.post("/ocr/confirm", requireTenantUser, requirePermission("purchases.create"), ctrl.confirmOcr);

router.get("/:id", requireTenantUser, requirePermission("purchases.view"), ctrl.getPurchase);
router.patch("/:id", requireTenantUser, requirePermission("purchases.update"), ctrl.updatePurchase);
router.delete("/:id", requireTenantUser, requirePermission("purchases.delete_draft"), ctrl.deletePurchase);

router.post("/:id/line-items", requireTenantUser, requirePermission("purchases.update"), ctrl.addLineItem);
router.patch("/:id/line-items/:lineId", requireTenantUser, requirePermission("purchases.update"), ctrl.updateLineItem);
router.delete("/:id/line-items/:lineId", requireTenantUser, requirePermission("purchases.update"), ctrl.deleteLineItem);

router.post("/:id/record", requireTenantUser, requirePermission("purchases.update"), ctrl.recordPurchase);
router.post("/:id/void", requireTenantUser, requirePermission("purchases.update"), ctrl.voidPurchase);
router.patch("/:id/payment-status", requireTenantUser, requirePermission("purchases.update"), ctrl.updatePaymentStatus);
router.post("/:id/payments", requireTenantUser, requirePermission("purchases.update"), ctrl.recordPayment);
router.patch("/:id/internal-notes", requireTenantUser, requirePermission("purchases.update"), ctrl.updateInternalNotes);
router.post("/:id/archive", requireTenantUser, requirePermission("purchases.update"), ctrl.archivePurchase);
router.post("/:id/restore", requireTenantUser, requirePermission("purchases.update"), ctrl.restorePurchase);
router.post("/:id/duplicate", requireTenantUser, requirePermission("purchases.update"), ctrl.duplicatePurchase);
router.post("/:id/activity", requireTenantUser, requirePermission("purchases.view"), ctrl.logPurchaseActivity);
router.post("/:id/attachments", requireTenantUser, requirePermission("purchases.update"), upload.single("file"), ctrl.addAttachment);

module.exports = router;
