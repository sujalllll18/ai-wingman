const express = require("express");
const { requireTenantUser } = require("../middleware/auth");
const requirePermission = require("../middleware/requirePermission");
const ctrl = require("../controllers/approval.controller");

const router = express.Router();

// Queue / history / detail - approvals.view covers "see the queue, including
// my own submitted requests"; approvals.view_history is the decided-requests
// screen. Approve/reject are NOT gated here (see approval.controller.js's
// assertCanDecide) because the permission they require depends on which
// module the request belongs to, discovered only after it's loaded.
router.get("/approvals", requireTenantUser, requirePermission("approvals.view"), ctrl.listQueue);
router.get("/approvals/history", requireTenantUser, requirePermission("approvals.view_history"), ctrl.listHistory);
router.get("/approvals/:id", requireTenantUser, requirePermission("approvals.view"), ctrl.getRequest);
router.post("/approvals/:id/approve", requireTenantUser, ctrl.approveRequest);
router.post("/approvals/:id/reject", requireTenantUser, ctrl.rejectRequest);
router.post("/approvals/:id/cancel", requireTenantUser, ctrl.cancelRequest);

// Approval Rules configuration - Settings screen, Owner/Admin territory.
router.get("/approval-rules", requireTenantUser, requirePermission("approvals.configure"), ctrl.listRules);
router.put("/approval-rules/:permissionKey", requireTenantUser, requirePermission("approvals.configure"), ctrl.upsertRule);

module.exports = router;
