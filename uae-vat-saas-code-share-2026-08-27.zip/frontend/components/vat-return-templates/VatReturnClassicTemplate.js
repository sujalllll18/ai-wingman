import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

// VAT Return's equivalent of ClassicTemplate/PurchaseClassicTemplate - same
// rendering pipeline (on-screen preview, PDF, Print all read this one DOM
// node). A professional read-only summary document: Business Details, TRN,
// Tax Period, the full category breakdown, and calculated totals - "Ready
// for Review" per the Sprint 1 brief. Reads only the VatReturn's own stored
// snapshot fields, same immutability principle as Invoice/Purchase.
const VatReturnClassicTemplate = forwardRef(function VatReturnClassicTemplate({ vatReturn }, ref) {
  const watermark = vatReturn.status === "DRAFT" ? "DRAFT" : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden="true" />
          <div className="invoice-doc-business">
            <strong>{vatReturn.businessName}</strong>
            {vatReturn.businessAddress && <span>{vatReturn.businessAddress}</span>}
            {vatReturn.businessTrn && <span>TRN: {vatReturn.businessTrn}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>VAT RETURN</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Tax Period</td>
                <td>{vatReturn.periodLabel}</td>
              </tr>
              <tr>
                <td>Period Type</td>
                <td>{vatReturn.periodType === "MONTHLY" ? "Monthly" : "Quarterly"}</td>
              </tr>
              <tr>
                <td>Status</td>
                <td>{vatReturn.status === "LOCKED" ? "Locked" : "Draft"}</td>
              </tr>
              <tr>
                <td>Generated</td>
                <td>{formatDate(vatReturn.generatedAt)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Sales</th>
            <th className="num">Taxable Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Standard Rated Sales</td>
            <td className="num">{formatCurrency(vatReturn.standardRatedSales)}</td>
          </tr>
          <tr>
            <td>Zero Rated Sales</td>
            <td className="num">{formatCurrency(vatReturn.zeroRatedSales)}</td>
          </tr>
          <tr>
            <td>Exempt Sales</td>
            <td className="num">{formatCurrency(vatReturn.exemptSales)}</td>
          </tr>
          <tr>
            <td>Out of Scope Sales</td>
            <td className="num">{formatCurrency(vatReturn.outOfScopeSales)}</td>
          </tr>
        </tbody>
      </table>

      <table className="invoice-doc-lines" style={{ marginTop: 16 }}>
        <thead>
          <tr>
            <th>Purchases</th>
            <th className="num">Taxable Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Standard Rated Purchases</td>
            <td className="num">{formatCurrency(vatReturn.standardRatedPurchases)}</td>
          </tr>
          <tr>
            <td>Zero Rated Purchases</td>
            <td className="num">{formatCurrency(vatReturn.zeroRatedPurchases)}</td>
          </tr>
          <tr>
            <td>Exempt Purchases</td>
            <td className="num">{formatCurrency(vatReturn.exemptPurchases)}</td>
          </tr>
          <tr>
            <td>Out of Scope Purchases</td>
            <td className="num">{formatCurrency(vatReturn.outOfScopePurchases)}</td>
          </tr>
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Output VAT</td>
              <td className="num">{formatCurrency(vatReturn.outputVat)}</td>
            </tr>
            <tr>
              <td>Input VAT</td>
              <td className="num">{formatCurrency(vatReturn.inputVat)}</td>
            </tr>
            <tr>
              <td>Recoverable VAT</td>
              <td className="num">{formatCurrency(vatReturn.recoverableVat)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>{vatReturn.netVatPayable >= 0 ? "Net VAT Payable" : "Net VAT Refundable"}</td>
              <td className="num">{formatCurrency(Math.abs(vatReturn.netVatPayable))}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="invoice-doc-footer">
        <span>
          {vatReturn.salesInvoiceCount} sales invoice(s) · {vatReturn.purchaseBillCount} purchase bill(s) considered for this period. Internal
          record generated by Ledger - FTA submission is future scope.
        </span>
      </div>
    </div>
  );
});

export default VatReturnClassicTemplate;
