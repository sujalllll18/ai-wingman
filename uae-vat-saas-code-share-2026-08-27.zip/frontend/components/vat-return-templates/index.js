import VatReturnClassicTemplate from "./VatReturnClassicTemplate";

// Registry future templates plug into without touching the Viewer, PDF
// export, or aggregation logic - mirrors invoice-templates/index.js exactly.
export const VAT_RETURN_TEMPLATES = {
  classic: { label: "Classic", component: VatReturnClassicTemplate },
};

export const DEFAULT_VAT_RETURN_TEMPLATE = "classic";

export function getVatReturnTemplateComponent(key) {
  return VAT_RETURN_TEMPLATES[key]?.component || VAT_RETURN_TEMPLATES[DEFAULT_VAT_RETURN_TEMPLATE].component;
}
