"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import AllocationEditor from "./AllocationEditor";

const PAYMENT_METHODS = [
  { value: "CASH", label: "Cash" },
  { value: "BANK_TRANSFER", label: "Bank Transfer" },
  { value: "CARD", label: "Card" },
  { value: "CHEQUE", label: "Cheque" },
  { value: "OTHER", label: "Other" },
];

function todayInputValue() {
  return new Date().toISOString().slice(0, 10);
}

// Record Payment (Customer Payments module, Phase 2 2026-08-22) - Enter
// payment details -> Allocate amount -> Confirm, all in one modal (the
// allocation table only appears once a Customer is chosen). Supports every
// scenario the brief lists: 1-invoice, many-invoices, partial, overpayment
// (never capped), and fully unallocated (leaving every row blank is valid -
// the payment is just recorded with nothing allocated yet, allocatable later
// from its detail page).
export default function NewPaymentModal({ open, onClose, onSuccess, initialCustomerId, initialInvoiceId }) {
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState("");
  const [amount, setAmount] = useState("");
  const [paymentDate, setPaymentDate] = useState(todayInputValue());
  const [currency, setCurrency] = useState("AED");
  const [method, setMethod] = useState("BANK_TRANSFER");
  const [accountRef, setAccountRef] = useState("");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [allocatable, setAllocatable] = useState([]);
  const [amounts, setAmounts] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    const token = tenantAuth.get();
    api.listCustomers(token).then(({ customers }) => setCustomers(customers)).catch(() => {});
    setCustomerId(initialCustomerId || "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open || !customerId) {
      setAllocatable([]);
      return;
    }
    const token = tenantAuth.get();
    api
      .listAllocatableInvoices(token, customerId)
      .then(({ invoices }) => {
        const mapped = invoices.map((i) => ({ id: i.id, number: i.invoiceNumberDisplay, date: i.issueDate, currency: i.currency, grandTotal: i.grandTotal, outstandingAmount: i.outstandingAmount }));
        setAllocatable(mapped);
        // Pre-fill the "Record Payment" flow launched from an Invoice's own
        // detail page - defaults the amount and the one allocation row to
        // that invoice's outstanding balance, still fully editable.
        if (initialInvoiceId) {
          const match = mapped.find((i) => i.id === initialInvoiceId);
          if (match) {
            setAmounts((prev) => (prev[initialInvoiceId] !== undefined ? prev : { ...prev, [initialInvoiceId]: match.outstandingAmount }));
            setAmount((prev) => prev || String(match.outstandingAmount));
          }
        }
      })
      .catch(() => setAllocatable([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, customerId]);

  function resetAndClose() {
    setCustomerId("");
    setAmount("");
    setPaymentDate(todayInputValue());
    setCurrency("AED");
    setMethod("BANK_TRANSFER");
    setAccountRef("");
    setReference("");
    setNotes("");
    setAllocatable([]);
    setAmounts({});
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    const selectedCustomer = customers.find((c) => c.id === customerId);
    if (!selectedCustomer) {
      setError("Select a customer.");
      return;
    }
    if (!amount || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
      setError("Enter a valid payment amount greater than zero.");
      return;
    }
    const allocations = Object.entries(amounts)
      .filter(([, v]) => Number(v) > 0)
      .map(([invoiceId, v]) => ({ invoiceId, amount: Number(v) }));

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const { payment } = await api.createPayment(token, {
        customerId,
        customerName: selectedCustomer.name,
        paymentDate,
        amount: Number(amount),
        currency,
        method,
        accountRef: accountRef || null,
        reference: reference || null,
        notes: notes || null,
        allocations,
      });
      onSuccess(payment);
      resetAndClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} size="lg" ariaLabel="Record Payment">
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 4 }}>Record Payment</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>
          Record a customer receipt, then allocate it against one or more Sent invoices - or leave it unallocated and allocate later.
        </p>

        <ErrorBanner message={error} />

        <div className="form-grid">
          <Field id="payment-customer" label={<>Customer<span className="required-asterisk">*</span></>}>
            <Select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
              <option value="">Select a customer…</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="payment-date" label={<>Payment Date<span className="required-asterisk">*</span></>}>
            <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="payment-amount" label={<>Amount<span className="required-asterisk">*</span></>}>
            <Input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field id="payment-currency" label="Currency">
            <Input value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase())} maxLength={3} />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="payment-method" label="Payment Method">
            <Select value={method} onChange={(e) => setMethod(e.target.value)}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="payment-account-ref" label="Bank / Cash Account" helptext="Free text - no configurable account master yet.">
            <Input value={accountRef} onChange={(e) => setAccountRef(e.target.value)} placeholder="e.g. ADCB Current A/C" />
          </Field>
        </div>

        <Field id="payment-reference" label="Reference Number">
          <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Transaction / cheque number" />
        </Field>

        <Field id="payment-notes" label="Notes">
          <textarea className="inline-input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>

        {customerId && (
          <div style={{ marginTop: 8 }}>
            <h3 style={{ marginBottom: 8 }}>Allocate to Invoices</h3>
            <AllocationEditor
              items={allocatable}
              amounts={amounts}
              onChange={setAmounts}
              paymentAmount={amount}
              itemLabel="invoice"
              emptyMessage="This customer has no Sent invoices to allocate against yet - the payment will be recorded as unallocated."
            />
          </div>
        )}

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : "Confirm Payment"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
