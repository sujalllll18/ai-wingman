// Payment (Phase 2 Payments module, 2026-08-22) has two independent status
// fields, same "separate axes" convention as Invoice's status/paymentStatus -
// `status` (CONFIRMED|CANCELLED, this badge) and `reconciliationStatus`
// (UNRECONCILED|RECONCILED, ReconciliationChip below) rather than one
// combined enum.
const STATUS_BADGE = {
  CONFIRMED: { label: "Confirmed", className: "badge-success" },
  CANCELLED: { label: "Cancelled", className: "badge-danger" },
};

const RECONCILIATION_BADGE = {
  UNRECONCILED: { label: "Unreconciled", className: "badge-info" },
  RECONCILED: { label: "Reconciled", className: "badge-premium" },
};

export function PaymentStatusChip({ payment }) {
  const status = STATUS_BADGE[payment.status] || STATUS_BADGE.CONFIRMED;
  return <span className={`badge ${status.className}`}>{status.label}</span>;
}

export function ReconciliationChip({ payment }) {
  const status = RECONCILIATION_BADGE[payment.reconciliationStatus] || RECONCILIATION_BADGE.UNRECONCILED;
  return <span className={`badge ${status.className}`}>{status.label}</span>;
}

export default function PaymentStatusBadge({ payment }) {
  return (
    <span style={{ display: "inline-flex", gap: 6, flexWrap: "wrap" }}>
      <PaymentStatusChip payment={payment} />
      <ReconciliationChip payment={payment} />
    </span>
  );
}
