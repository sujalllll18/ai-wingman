"use client";

// Shared allocation-rows editor, used by both Payments Received (against
// Invoices) and Payments Made (against Purchase Bills) - the caller just
// supplies a generic `items` list ({id, number, date, currency, grandTotal,
// outstandingAmount}) and gets back a plain {id, amount} map. Deliberately
// does NOT cap a row's amount against that item's own outstandingAmount -
// overpayment (allocating more than an invoice/bill currently owes) is an
// explicitly supported scenario per the Payments module brief, not an input
// error - so this only flags it visually, never blocks it.
function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function AllocationEditor({ items, amounts, onChange, paymentAmount, itemLabel = "invoice", emptyMessage }) {
  const allocatedTotal = Object.values(amounts).reduce((sum, v) => sum + (Number(v) || 0), 0);
  const unallocated = Math.max(0, Number(paymentAmount || 0) - allocatedTotal);
  const overAllocated = allocatedTotal > Number(paymentAmount || 0) + 0.001;

  function setAmount(id, value) {
    onChange({ ...amounts, [id]: value });
  }

  if (!items || items.length === 0) {
    return <p className="helptext">{emptyMessage || `No eligible ${itemLabel}s to allocate against yet.`}</p>;
  }

  return (
    <div>
      <table className="data-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Date</th>
            <th className="num">Total</th>
            <th className="num">Outstanding</th>
            <th className="num">Allocate</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const value = amounts[item.id] ?? "";
            const overThisItem = Number(value) > item.outstandingAmount + 0.001;
            return (
              <tr key={item.id}>
                <td className="mono">{item.number}</td>
                <td>{formatDate(item.date)}</td>
                <td className="num mono">{formatCurrency(item.grandTotal, item.currency)}</td>
                <td className="num mono">{formatCurrency(item.outstandingAmount, item.currency)}</td>
                <td className="num">
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    className="inline-input"
                    style={{ width: 110, textAlign: "right" }}
                    value={value}
                    onChange={(e) => setAmount(item.id, e.target.value)}
                    placeholder="0.00"
                  />
                  {overThisItem && (
                    <div className="helptext" style={{ marginTop: 2, color: "var(--color-warning, #b45309)" }}>
                      Overpayment
                    </div>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="review-list" style={{ marginTop: 12 }}>
        <div className="review-row">
          <span className="review-label">Payment Amount</span>
          <span className="review-value mono">{formatCurrency(paymentAmount, items[0]?.currency)}</span>
        </div>
        <div className="review-row">
          <span className="review-label">Allocated</span>
          <span className="review-value mono">{formatCurrency(allocatedTotal, items[0]?.currency)}</span>
        </div>
        <div className="review-row" style={{ fontWeight: 600 }}>
          <span className="review-label">Unallocated</span>
          <span className="review-value mono">{formatCurrency(unallocated, items[0]?.currency)}</span>
        </div>
      </div>
      {overAllocated && (
        <p className="field-error" role="alert" style={{ marginTop: 8 }}>
          Total allocated cannot exceed the payment amount.
        </p>
      )}
    </div>
  );
}
