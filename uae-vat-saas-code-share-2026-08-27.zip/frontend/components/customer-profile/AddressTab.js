"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";
import AddressEditDrawer from "./AddressEditDrawer";

const NOT_TRACKED = "Not tracked as a separate field yet — see the combined Address field above";

export default function AddressTab({ customer, token, onSaved, showToast, setError }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Billing Address</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">Where invoices and correspondence are addressed.</p>
        <div className="review-list">
          <ProfileField label="Address" value={customer.address} tooltip="No address on record" />
          <ProfileField label="Address Line 1" tooltip={NOT_TRACKED} />
          <ProfileField label="Address Line 2" tooltip={NOT_TRACKED} />
          <ProfileField label="City" tooltip={NOT_TRACKED} />
          <ProfileField label="Emirate" tooltip={NOT_TRACKED} />
          <ProfileField label="Postal Code" tooltip={NOT_TRACKED} />
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Shipping Address</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Not tracked separately yet — shipping address isn&rsquo;t stored on the backend, so it isn&rsquo;t
          shown here until it is.
        </p>
      </Card>

      <AddressEditDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        customer={customer}
        token={token}
        onSaved={onSaved}
        showToast={showToast}
        setError={setError}
      />
    </>
  );
}
