"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";

// Real save: name/customerType/status are all persisted columns on Customer.
export default function BasicInfoEditDrawer({ open, onClose, customer, token, onSaved, showToast, setError }) {
  const [name, setName] = useState(customer.name || "");
  const [customerType, setCustomerType] = useState(customer.customerType);
  const [status, setStatus] = useState(customer.status);
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const nameError = touched && !name.trim() ? "Customer name is required." : "";

  function resetAndClose() {
    setName(customer.name || "");
    setCustomerType(customer.customerType);
    setStatus(customer.status);
    setTouched(false);
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setTouched(true);
    if (!name.trim()) return;

    setSubmitting(true);
    setError?.("");
    try {
      await api.updateCustomer(token, customer.id, { name: name.trim(), customerType, status });
      showToast?.("Customer updated.");
      await onSaved?.();
      onClose();
    } catch (err) {
      setError?.(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Drawer open={open} onClose={resetAndClose} ariaLabel="Edit Basic Information">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Edit Basic Information</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Update this customer&rsquo;s core identity.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="drawer-body">
          <Field
            id="basic-name"
            label={
              <>
                Customer Name<span className="required-asterisk">*</span>
              </>
            }
            error={nameError}
          >
            <Input value={name} onChange={(e) => setName(e.target.value)} onBlur={() => setTouched(true)} />
          </Field>

          <div className="field">
            <label>Customer Type</label>
            <div className="segmented-control" role="radiogroup" aria-label="Customer type">
              <button
                type="button"
                className={`segmented-option${customerType === "BUSINESS" ? " selected" : ""}`}
                onClick={() => setCustomerType("BUSINESS")}
              >
                Business
              </button>
              <button
                type="button"
                className={`segmented-option${customerType === "INDIVIDUAL" ? " selected" : ""}`}
                onClick={() => setCustomerType("INDIVIDUAL")}
              >
                Individual
              </button>
            </div>
          </div>

          <div className="field" style={{ marginBottom: 0 }}>
            <label>Status</label>
            <div className="segmented-control" role="radiogroup" aria-label="Status">
              <button
                type="button"
                className={`segmented-option${status === "ACTIVE" ? " selected" : ""}`}
                onClick={() => setStatus("ACTIVE")}
              >
                Active
              </button>
              <button
                type="button"
                className={`segmented-option${status === "INACTIVE" ? " selected" : ""}`}
                onClick={() => setStatus("INACTIVE")}
              >
                Inactive
              </button>
            </div>
            {status === "INACTIVE" && (
              <p className="helptext" style={{ marginTop: 8 }}>
                Inactive customers stay visible here but can&rsquo;t be selected by future modules (invoices,
                quotations, etc.).
              </p>
            )}
          </div>
        </div>
        <div className="drawer-actions">
          <Button type="button" variant="outline" onClick={resetAndClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Drawer>
  );
}
