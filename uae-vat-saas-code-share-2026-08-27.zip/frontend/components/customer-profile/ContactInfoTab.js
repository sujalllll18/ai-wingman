"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";
import PlaceholderFieldsDrawer from "./PlaceholderFieldsDrawer";

const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

const FIELDS = [
  { key: "contactPerson", label: "Contact Person" },
  { key: "email", label: "Email", type: "email" },
  { key: "mobileNumber", label: "Mobile Number" },
  { key: "telephone", label: "Telephone" },
  { key: "website", label: "Website" },
];

export default function ContactInfoTab() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Contact Information</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">How your team reaches this customer.</p>
        <div className="review-list">
          {FIELDS.map((f) => (
            <ProfileField key={f.key} label={f.label} tooltip={NOT_TRACKED} />
          ))}
        </div>
      </Card>

      <PlaceholderFieldsDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        ariaLabel="Edit Contact Information"
        title="Edit Contact Information"
        description="Update how your team reaches this customer."
        fields={FIELDS}
        initialValues={{}}
        integrationNote="Saving isn't connected yet — there's no backend endpoint for contact fields. This form is ready for that integration."
      />
    </>
  );
}
