"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";
import PlaceholderFieldsDrawer from "./PlaceholderFieldsDrawer";

const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

const FIELDS = [
  { key: "currency", label: "Currency" },
  { key: "paymentTerms", label: "Payment Terms" },
];

export default function FinancialTab() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Financial</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">Billing defaults for this customer.</p>
        <div className="review-list">
          {FIELDS.map((f) => (
            <ProfileField key={f.key} label={f.label} tooltip={NOT_TRACKED} />
          ))}
        </div>
      </Card>

      <PlaceholderFieldsDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        ariaLabel="Edit Financial"
        title="Edit Financial"
        description="Update billing defaults for this customer."
        fields={FIELDS}
        initialValues={{ currency: "AED", paymentTerms: "30 Days" }}
        integrationNote="Saving isn't connected yet — there's no backend endpoint for financial fields. This form is ready for that integration."
      />
    </>
  );
}
