"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";
import BasicInfoEditDrawer from "./BasicInfoEditDrawer";

function customerCode(id) {
  return `CUS-${id.slice(0, 8).toUpperCase()}`;
}

export default function BasicInfoTab({ customer, token, onSaved, showToast, setError }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Basic Information</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">Core identity for this customer.</p>
        <div className="review-list">
          <ProfileField label="Customer Name" value={customer.name} />
          <ProfileField label="Customer Code" value={customerCode(customer.id)} />
          <ProfileField label="Customer Type" value={customer.customerType === "BUSINESS" ? "Business" : "Individual"} />
          <ProfileField label="Status" value={customer.status === "ACTIVE" ? "Active" : "Inactive"} />
        </div>
      </Card>

      <BasicInfoEditDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        customer={customer}
        token={token}
        onSaved={onSaved}
        showToast={showToast}
        setError={setError}
      />
    </>
  );
}
