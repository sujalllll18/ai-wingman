import Card from "../ui/Card";
import PlaceholderNotice from "../ui/PlaceholderNotice";

export default function ActivityTab({ customer }) {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Activity</h2>
      <p className="form-section-desc">Chronological events for this customer.</p>

      {customer.createdAt && (
        <div className="timeline" style={{ marginBottom: 20 }}>
          <div className="timeline-item">
            <span className="timeline-dot" />
            <div>
              <div className="timeline-content-title">Customer Created</div>
              <div className="timeline-content-meta">{new Date(customer.createdAt).toLocaleString()}</div>
            </div>
          </div>
        </div>
      )}

      <PlaceholderNotice>
        Invoice, quotation, and payment events aren&rsquo;t logged yet — only Customer Created is known today.
      </PlaceholderNotice>
    </Card>
  );
}
