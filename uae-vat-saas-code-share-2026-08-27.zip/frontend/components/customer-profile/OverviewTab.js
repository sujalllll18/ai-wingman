"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";

function customerCode(id) {
  return `CUS-${id.slice(0, 8).toUpperCase()}`;
}

export default function OverviewTab({ customer, token, onSaved, showToast, setError }) {
  const [busy, setBusy] = useState(false);

  async function handleToggleStatus() {
    setBusy(true);
    setError?.("");
    try {
      const nextStatus = customer.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
      await api.updateCustomer(token, customer.id, { status: nextStatus });
      showToast?.(nextStatus === "ACTIVE" ? "Customer reactivated." : "Customer marked inactive.");
      await onSaved?.();
    } catch (err) {
      setError?.(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="detail-layout">
      <div className="detail-main">
        <Card>
          <h2 style={{ marginBottom: 4 }}>Summary</h2>
          <p className="form-section-desc">A quick snapshot of this customer.</p>
          <div className="review-list">
            <ProfileField label="Customer Code" value={customerCode(customer.id)} />
            <ProfileField label="Customer Name" value={customer.name} />
            <ProfileField label="Customer Type" value={customer.customerType === "BUSINESS" ? "Business" : "Individual"} />
            <ProfileField label="VAT Registered" value={customer.trn ? "Yes" : "No"} />
            <ProfileField label="Created Date" value={customer.createdAt ? new Date(customer.createdAt).toLocaleDateString() : null} />
          </div>
        </Card>
      </div>

      <div className="detail-rail">
        <Card>
          <h2 style={{ marginBottom: 4 }}>Status</h2>
          <p className="helptext" style={{ marginBottom: 16 }}>
            {customer.status === "ACTIVE"
              ? "This customer can be selected by future modules once they exist."
              : "This customer is inactive — it stays visible here but can't be selected by future modules."}
          </p>
          <Button
            variant={customer.status === "ACTIVE" ? "danger" : "primary"}
            onClick={handleToggleStatus}
            disabled={busy}
            style={{ width: "100%", justifyContent: "center" }}
          >
            {customer.status === "ACTIVE" ? "Mark Inactive" : "Mark Active"}
          </Button>
        </Card>
      </div>
    </div>
  );
}
