"use client";

import { useState } from "react";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import Tooltip from "../ui/Tooltip";
import { isValidEmail } from "../../lib/validation";

// Shared edit drawer for tabs whose fields aren't backed by any endpoint yet
// (Contact Information, Financial). Fully editable and validated, but Save
// is a clearly-marked placeholder rather than a silent no-op.
export default function PlaceholderFieldsDrawer({ open, onClose, ariaLabel, title, description, fields, initialValues, integrationNote }) {
  const [values, setValues] = useState(initialValues);
  const [touched, setTouched] = useState({});

  function update(key) {
    return (e) => setValues((v) => ({ ...v, [key]: e.target.value }));
  }

  function markTouched(key) {
    setTouched((t) => ({ ...t, [key]: true }));
  }

  const emailField = fields.find((f) => f.type === "email");
  const emailError = emailField && values[emailField.key] && !isValidEmail(values[emailField.key]) ? "Enter a valid email address." : "";

  function resetAndClose() {
    setValues(initialValues);
    setTouched({});
    onClose();
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (emailError) {
      markTouched(emailField.key);
      return;
    }
    // No-op on purpose: see integrationNote below.
  }

  return (
    <Drawer open={open} onClose={resetAndClose} ariaLabel={ariaLabel}>
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>{title}</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          {description}
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="drawer-body">
          <PlaceholderNotice>{integrationNote}</PlaceholderNotice>
          <div style={{ marginTop: 16 }}>
            {fields.map((f, i) => (
              <Field
                key={f.key}
                id={`pf-${f.key}`}
                label={f.label}
                error={f.type === "email" && touched[f.key] ? emailError : undefined}
                style={i === fields.length - 1 ? { marginBottom: 0 } : undefined}
              >
                <Input
                  type={f.type === "email" ? "email" : "text"}
                  value={values[f.key] || ""}
                  onChange={update(f.key)}
                  onBlur={() => markTouched(f.key)}
                />
              </Field>
            ))}
          </div>
        </div>
        <div className="drawer-actions">
          <Button type="button" variant="outline" onClick={resetAndClose}>
            Cancel
          </Button>
          <Tooltip label="No backend endpoint exists yet to save these fields">
            <Button disabled>Save</Button>
          </Tooltip>
        </div>
      </form>
    </Drawer>
  );
}
