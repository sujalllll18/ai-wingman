"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";

// Real save: address is a single persisted string column on Customer today
// (line1/line2/city/emirate/postal code aren't stored as separate fields
// yet, so this drawer edits the one combined string).
export default function AddressEditDrawer({ open, onClose, customer, token, onSaved, showToast, setError }) {
  const [address, setAddress] = useState(customer.address || "");
  const [submitting, setSubmitting] = useState(false);

  function resetAndClose() {
    setAddress(customer.address || "");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError?.("");
    try {
      await api.updateCustomer(token, customer.id, { address: address.trim() || null });
      showToast?.("Address updated.");
      await onSaved?.();
      onClose();
    } catch (err) {
      setError?.(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Drawer open={open} onClose={resetAndClose} ariaLabel="Edit Address">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Edit Address</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Update this customer&rsquo;s billing address.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="drawer-body">
          <PlaceholderNotice>
            Address is stored as a single field today — line 1/2, city, Emirate, and postal code aren&rsquo;t
            tracked separately yet, so they&rsquo;re combined here.
          </PlaceholderNotice>
          <Field id="address-full" label="Address" style={{ marginTop: 16, marginBottom: 0 }}>
            <textarea
              id="address-full"
              rows={3}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              style={{
                width: "100%",
                padding: "10px 12px",
                border: "1px solid var(--color-line-strong)",
                borderRadius: "var(--radius)",
                fontFamily: "var(--font-body)",
                fontSize: "14px",
                resize: "vertical",
              }}
            />
          </Field>
        </div>
        <div className="drawer-actions">
          <Button type="button" variant="outline" onClick={resetAndClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Drawer>
  );
}
