"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import ProfileField from "../tenant-profile/ProfileField";
import TaxInfoEditDrawer from "./TaxInfoEditDrawer";

const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

export default function TaxInfoTab({ customer, token, onSaved, showToast, setError }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Tax Information</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">VAT registration for this customer.</p>
        <div className="review-list">
          <ProfileField label="VAT Registered" value={customer.trn ? "Yes" : "No"} />
          <ProfileField label="TRN" value={customer.trn ? <span className="mono">{customer.trn}</span> : null} tooltip="This customer has no TRN on record" />
          <ProfileField label="Tax Treatment" tooltip={NOT_TRACKED} />
        </div>
      </Card>

      <TaxInfoEditDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        customer={customer}
        token={token}
        onSaved={onSaved}
        showToast={showToast}
        setError={setError}
      />
    </>
  );
}
