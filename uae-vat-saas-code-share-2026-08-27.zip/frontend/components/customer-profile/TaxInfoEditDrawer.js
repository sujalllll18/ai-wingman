"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { isValidTRN } from "../../lib/validation";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";

// Real save: trn is a persisted column on Customer.
export default function TaxInfoEditDrawer({ open, onClose, customer, token, onSaved, showToast, setError }) {
  const [vatRegistered, setVatRegistered] = useState(!!customer.trn);
  const [trn, setTrn] = useState(customer.trn || "");
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const trnError = touched && vatRegistered && !isValidTRN(trn) ? "TRN must be exactly 15 digits." : "";

  function resetAndClose() {
    setVatRegistered(!!customer.trn);
    setTrn(customer.trn || "");
    setTouched(false);
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setTouched(true);
    if (vatRegistered && !isValidTRN(trn)) return;

    setSubmitting(true);
    setError?.("");
    try {
      await api.updateCustomer(token, customer.id, { trn: vatRegistered ? trn : null });
      showToast?.("Tax information updated.");
      await onSaved?.();
      onClose();
    } catch (err) {
      setError?.(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Drawer open={open} onClose={resetAndClose} ariaLabel="Edit Tax Information">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Edit Tax Information</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Update this customer&rsquo;s VAT registration.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="drawer-body">
          <div className="field">
            <label>VAT Registered?</label>
            <div className="segmented-control" role="radiogroup" aria-label="VAT registered">
              <button
                type="button"
                className={`segmented-option${vatRegistered ? " selected" : ""}`}
                onClick={() => setVatRegistered(true)}
              >
                Yes
              </button>
              <button
                type="button"
                className={`segmented-option${!vatRegistered ? " selected" : ""}`}
                onClick={() => {
                  setVatRegistered(false);
                  setTrn("");
                }}
              >
                No
              </button>
            </div>
          </div>

          {vatRegistered && (
            <Field
              id="tax-trn"
              label={
                <>
                  TRN<span className="required-asterisk">*</span>
                </>
              }
              error={trnError}
              helptext={!trnError ? "Exactly 15 digits" : undefined}
              style={{ marginTop: 16, marginBottom: 0 }}
            >
              <Input
                value={trn}
                onChange={(e) => setTrn(e.target.value.replace(/\D/g, "").slice(0, 15))}
                onBlur={() => setTouched(true)}
                className="mono"
                inputMode="numeric"
              />
            </Field>
          )}
        </div>
        <div className="drawer-actions">
          <Button type="button" variant="outline" onClick={resetAndClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Drawer>
  );
}
