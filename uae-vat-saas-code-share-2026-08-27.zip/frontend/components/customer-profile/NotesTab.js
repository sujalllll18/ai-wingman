import Card from "../ui/Card";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";

export default function NotesTab() {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Notes</h2>
      <p className="form-section-desc">Internal notes about this customer.</p>
      <PlaceholderNotice>
        Not available yet — there&rsquo;s no backend model or endpoint to store notes. Left disabled rather than
        saving locally, so nothing here looks durable until it actually is.
      </PlaceholderNotice>
      <div style={{ marginTop: 16 }}>
        <textarea
          rows={4}
          disabled
          placeholder="Add a note…"
          style={{
            width: "100%",
            padding: "10px 12px",
            border: "1px solid var(--color-line-strong)",
            borderRadius: "var(--radius)",
            fontFamily: "var(--font-body)",
            fontSize: "14px",
            resize: "vertical",
            background: "var(--color-surface-sunken)",
          }}
        />
        <Button disabled style={{ marginTop: 12 }}>
          Add Note
        </Button>
      </div>
    </Card>
  );
}
