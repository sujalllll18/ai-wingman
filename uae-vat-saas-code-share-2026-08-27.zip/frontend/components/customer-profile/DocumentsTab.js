"use client";

import { useRef, useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import Tooltip from "../ui/Tooltip";
import PlaceholderNotice from "../ui/PlaceholderNotice";

const DOCUMENT_TYPES = ["Trade License", "VAT Certificate", "Other Documents"];

function DocumentRow({ label, doc, onSelectFile }) {
  const inputRef = useRef(null);

  function handleChange(e) {
    const file = e.target.files?.[0];
    if (file) onSelectFile(file);
  }

  return (
    <div className="doc-row">
      <div>
        <div className="doc-row-name">{label}</div>
        <div className="doc-row-meta">
          {doc ? (
            <>
              {doc.name} · Uploaded {doc.uploadedAt.toLocaleDateString()} by {doc.uploadedBy}
            </>
          ) : (
            "No version uploaded · Expiry: —"
          )}
        </div>
      </div>
      <div className="doc-row-actions">
        <input ref={inputRef} type="file" style={{ display: "none" }} onChange={handleChange} />
        <Button variant="outline" onClick={() => inputRef.current?.click()}>
          {doc ? "Replace" : "Upload"}
        </Button>
        <Tooltip label="Not available yet — no document storage exists on the backend">
          <Button variant="outline" disabled>
            Download
          </Button>
        </Tooltip>
      </div>
    </div>
  );
}

export default function DocumentsTab() {
  const [docs, setDocs] = useState({});

  function selectFile(type, file) {
    setDocs((d) => ({ ...d, [type]: { name: file.name, uploadedAt: new Date(), uploadedBy: "You" } }));
  }

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Documents</h2>
      <p className="form-section-desc">Trade license, VAT certificate, and other documents for this customer.</p>
      <PlaceholderNotice>
        Uploads here aren&rsquo;t saved to a backend yet — there&rsquo;s no document storage or upload endpoint.
        This shows the complete intended flow.
      </PlaceholderNotice>
      <div className="doc-list" style={{ marginTop: 16 }}>
        {DOCUMENT_TYPES.map((type) => (
          <DocumentRow key={type} label={type} doc={docs[type]} onSelectFile={(file) => selectFile(type, file)} />
        ))}
      </div>
    </Card>
  );
}
