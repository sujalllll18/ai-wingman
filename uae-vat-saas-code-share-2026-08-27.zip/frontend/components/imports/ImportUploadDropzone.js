"use client";

import { useRef, useState } from "react";

// Generalized from Purchase OCR's OcrUploadDropzone (same .ocr-dropzone CSS,
// just a different accepted-type set and copy) - reused rather than
// reinvented, per the Import Framework's own "reuse existing upload
// components" requirement.
const ACCEPTED_TYPES = ["text/csv", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"];

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function ImportUploadDropzone({ onFileSelected }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState("");

  function validateAndSet(file) {
    if (!file) return;
    const looksRight = ACCEPTED_TYPES.includes(file.type) || /\.(csv|xlsx|xls)$/i.test(file.name);
    if (!looksRight) {
      setError("Only CSV or Excel (.xlsx/.xls) files are accepted.");
      return;
    }
    setError("");
    setSelectedFile(file);
    onFileSelected(file);
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    validateAndSet(e.dataTransfer.files?.[0]);
  }

  return (
    <div>
      <div
        className={`ocr-dropzone${dragOver ? " ocr-dropzone-active" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
      >
        <svg viewBox="0 0 24 24" className="ocr-dropzone-icon" aria-hidden="true">
          <path d="M12 3.5v11M7 9l5-5.5L17 9" />
          <path d="M4 16.5v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
        </svg>
        {selectedFile ? (
          <>
            <strong>{selectedFile.name}</strong>
            <span className="helptext">{formatFileSize(selectedFile.size)} — click or drop to replace</span>
          </>
        ) : (
          <>
            <strong>Drop a CSV or Excel file here, or click to browse</strong>
            <span className="helptext">.csv, .xlsx, or .xls — up to 10MB</span>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          style={{ display: "none" }}
          onChange={(e) => validateAndSet(e.target.files?.[0])}
        />
      </div>
      {error && (
        <p className="field-error" role="alert" style={{ marginTop: 8 }}>
          {error}
        </p>
      )}
    </div>
  );
}
