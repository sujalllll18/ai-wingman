// Same map-based badge pattern as InvoiceStatusBadge/ApprovalStatusBadge -
// ImportBatch.status is UPLOADED | MAPPING | VALIDATING | PREVIEW |
// PENDING_APPROVAL | QUEUED | PROCESSING | PAUSED | COMPLETED |
// COMPLETED_WITH_ERRORS | FAILED | CANCELLED (see prisma/schema.prisma's
// ImportBatch model comment). QUEUED/PROCESSING/PAUSED are the
// migration-engine execution states (2026-08-22 hardening) - QUEUED/
// PROCESSING replace the old, never-actually-used "IMPORTING" state.
const STATUS_BADGE = {
  UPLOADED: { label: "Uploaded", className: "badge-info" },
  MAPPING: { label: "Mapping", className: "badge-info" },
  VALIDATING: { label: "Validating", className: "badge-info" },
  PREVIEW: { label: "Preview", className: "badge-premium" },
  PENDING_APPROVAL: { label: "Pending Approval", className: "badge-premium" },
  QUEUED: { label: "Queued", className: "badge-premium" },
  PROCESSING: { label: "Processing", className: "badge-premium" },
  PAUSED: { label: "Paused", className: "badge-warning" },
  COMPLETED: { label: "Completed", className: "badge-success" },
  COMPLETED_WITH_ERRORS: { label: "Completed (with errors)", className: "badge-danger" },
  FAILED: { label: "Failed", className: "badge-danger" },
  CANCELLED: { label: "Cancelled", className: "badge-danger" },
};

export default function ImportStatusBadge({ status }) {
  const s = STATUS_BADGE[status] || { label: status, className: "badge-info" };
  return <span className={`badge ${s.className}`}>{s.label}</span>;
}

export const IMPORT_TYPE_LABEL = {
  SALES_INVOICE: "Sales Invoices",
  PURCHASE_BILL: "Purchase Bills",
  CREDIT_NOTE: "Credit Notes",
  DEBIT_NOTE: "Debit Notes",
  CUSTOMER: "Customers",
  VENDOR: "Suppliers",
  PRODUCT: "Products",
  PAYMENT: "Customer Payments",
  PURCHASE_PAYMENT: "Supplier Payments",
  BANK_TRANSACTION: "Bank Transactions",
};
