import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

// Groups line items by the tax rate they actually used (name + percentage),
// straight from each line's own frozen snapshot fields - never re-resolved
// against current Tax Master. This is what UAE VAT invoices need: a
// breakdown of taxable value and tax charged per rate, not just one total.
function buildTaxBreakdown(lineItems) {
  const groups = new Map();
  for (const li of lineItems) {
    const key = `${li.taxRateName || "No tax"}|${li.taxPercentage}`;
    const existing = groups.get(key) || { name: li.taxRateName || "No tax", percentage: li.taxPercentage, taxableAmount: 0, taxAmount: 0 };
    existing.taxableAmount += li.lineTaxableAmount;
    existing.taxAmount += li.lineTaxAmount;
    groups.set(key, existing);
  }
  return Array.from(groups.values());
}

// The single rendering source for the Invoice Viewer, PDF export, PNG
// export, and Print (docs Sprint 2 requirement: "one rendering engine").
// Reads only the invoice's own stored snapshot fields - never Customer,
// Material, or Tax Master directly, matching the immutability principle
// from Sprint 1.
// businessAssets (2026-08-09) - { logoUrl, stampUrl, signatureUrl }, the
// tenant's CURRENT Business Profile assets, fetched live by each caller
// (Viewer, bulk-export) - deliberately not part of the invoice snapshot
// itself (see prisma/schema.prisma's Tenant.logoUrl comment for why: a
// logo isn't an FTA-relevant financial/legal fact the immutability
// principle protects). Optional/undefined-safe throughout so every
// existing caller that doesn't pass it (none currently do outside this
// module) keeps rendering exactly as before - the slots are simply empty.
const ClassicTemplate = forwardRef(function ClassicTemplate({ invoice, businessAssets = {} }, ref) {
  const taxBreakdown = buildTaxBreakdown(invoice.lineItems || []);
  const watermark =
    invoice.status === "VOID"
      ? "CANCELLED"
      : invoice.status === "DRAFT"
      ? "DRAFT"
      : invoice.paymentStatus === "PAID"
      ? "PAID"
      : invoice.paymentStatus === "BAD_DEBT"
      ? "BAD DEBT"
      : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden={!businessAssets.logoUrl}>
            {businessAssets.logoUrl && <img src={businessAssets.logoUrl} alt="Company logo" />}
          </div>
          <div className="invoice-doc-business">
            <strong>{invoice.businessName}</strong>
            {invoice.businessAddress && <span>{invoice.businessAddress}</span>}
            {invoice.businessTrn && <span>TRN: {invoice.businessTrn}</span>}
            {invoice.businessContactEmail && <span>{invoice.businessContactEmail}</span>}
            {invoice.businessContactPhone && <span>{invoice.businessContactPhone}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>{invoice.status === "DRAFT" ? "DRAFT INVOICE" : "TAX INVOICE"}</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Invoice #</td>
                <td className="mono">{invoice.invoiceNumberDisplay || "DRAFT"}</td>
              </tr>
              <tr>
                <td>Invoice Date</td>
                <td>{formatDate(invoice.issueDate)}</td>
              </tr>
              <tr>
                <td>Due Date</td>
                <td>{formatDate(invoice.dueDate)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="invoice-doc-parties">
        <div>
          <span className="invoice-doc-label">Bill To</span>
          <strong>{invoice.customerName}</strong>
          {invoice.customerAddress && <span>{invoice.customerAddress}</span>}
          {invoice.customerTrn && <span>TRN: {invoice.customerTrn}</span>}
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Description</th>
            <th>Unit</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(invoice.lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td>{li.unit}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, invoice.currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              {/* lineNetAmount (qty x unitPrice, before discount/VAT) - not
                  lineTotal (after discount AND VAT) - this column is headed
                  "Amount" and must sum to Subtotal below it, not to Grand
                  Total, or the Line Items -> Subtotal -> Discount -> Taxable
                  -> VAT -> Grand Total chain doesn't reconcile (2026-08-11
                  fix - was showing lineTotal, silently double-applying
                  discount+VAT into a cell that also gets discounted/taxed
                  again by the summary rows below). */}
              <td className="num">{formatCurrency(li.lineNetAmount, invoice.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        {taxBreakdown.length > 0 && (
          <table className="invoice-doc-tax-breakdown">
            <thead>
              <tr>
                <th>Tax Breakdown</th>
                <th className="num">Taxable Amount</th>
                <th className="num">Tax</th>
              </tr>
            </thead>
            <tbody>
              {taxBreakdown.map((g) => (
                <tr key={g.name}>
                  <td>
                    {g.name} ({g.percentage}%)
                  </td>
                  <td className="num">{formatCurrency(g.taxableAmount, invoice.currency)}</td>
                  <td className="num">{formatCurrency(g.taxAmount, invoice.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Subtotal</td>
              <td className="num">{formatCurrency(invoice.subtotal, invoice.currency)}</td>
            </tr>
            <tr>
              <td>Discount</td>
              <td className="num">-{formatCurrency(invoice.discountTotal, invoice.currency)}</td>
            </tr>
            <tr>
              <td>VAT</td>
              <td className="num">{formatCurrency(invoice.vatTotal, invoice.currency)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>Grand Total</td>
              <td className="num">{formatCurrency(invoice.grandTotal, invoice.currency)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {invoice.notes && (
        <div className="invoice-doc-notes">
          <span className="invoice-doc-label">Notes</span>
          <p>{invoice.notes}</p>
        </div>
      )}

      {/* Terms & Conditions: no per-tenant terms text is stored anywhere yet
          (would need a Business Profile settings field) - section is
          reserved but only renders once that data exists, rather than
          showing fabricated boilerplate on a real customer-facing document. */}

      {/* Stamp/Signature (2026-08-09) - the block InvoicePreviewModal's own
          legend already reserved ("Signature & Company Stamp... for when
          these ship"). Only rendered when at least one asset is actually
          configured, unlike the always-reserved logo slot above - no empty
          placeholder boxes on a real customer-facing document. */}
      {(businessAssets.signatureUrl || businessAssets.stampUrl) && (
        <div className="invoice-doc-signoff">
          {businessAssets.signatureUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.signatureUrl} alt="Authorized signature" />
              <span>Authorized Signatory</span>
            </div>
          )}
          {businessAssets.stampUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.stampUrl} alt="Company stamp" />
              <span>Company Stamp</span>
            </div>
          )}
        </div>
      )}

      <div className="invoice-doc-footer">
        <span>This is a computer-generated tax invoice.</span>
        {/* Reserved layout space for future QR code / digital signature /
            online payment button - intentionally not implemented (Sprint 2
            scope explicitly excludes these). */}
        <div className="invoice-doc-future-slots" aria-hidden="true">
          <div className="invoice-doc-future-slot" />
          <div className="invoice-doc-future-slot" />
          <div className="invoice-doc-future-slot" />
        </div>
      </div>
    </div>
  );
});

export default ClassicTemplate;
