import ClassicTemplate from "./ClassicTemplate";

// Registry future templates (Modern/Corporate/Minimal) plug into without
// touching the Invoice Viewer, PDF/PNG export, or any invoice calculation
// logic - they only ever consume the same read-only invoice snapshot shape
// ClassicTemplate does.
export const INVOICE_TEMPLATES = {
  classic: { label: "Classic", component: ClassicTemplate },
};

export const DEFAULT_INVOICE_TEMPLATE = "classic";

export function getInvoiceTemplateComponent(key) {
  return INVOICE_TEMPLATES[key]?.component || INVOICE_TEMPLATES[DEFAULT_INVOICE_TEMPLATE].component;
}
