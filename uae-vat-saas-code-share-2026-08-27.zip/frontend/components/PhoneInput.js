"use client";

import { useEffect, useRef, useState } from "react";
import { COUNTRIES, findCountry, flagEmoji } from "../lib/countries";

// Controlled international phone input: flag + searchable country dropdown
// (dial code) paired with a plain national-number field. The two pieces are
// combined by the caller into a single E.164-ish string for submission.
export default function PhoneInput({ id, name, countryIso2, number, onCountryChange, onNumberChange, error, autoComplete = "off" }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const containerRef = useRef(null);
  const searchRef = useRef(null);

  const country = findCountry(countryIso2);

  useEffect(() => {
    if (!open) return;
    searchRef.current?.focus();
    function handleClickOutside(e) {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    function handleEscape(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

  const filtered = COUNTRIES.filter((c) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return c.name.toLowerCase().includes(q) || c.dialCode.includes(q);
  });

  function selectCountry(iso2) {
    onCountryChange(iso2);
    setOpen(false);
    setQuery("");
  }

  return (
    <div className="phone-input" ref={containerRef}>
      <button
        type="button"
        className="phone-input-country-btn"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Select country code"
        onClick={() => setOpen((o) => !o)}
      >
        <span aria-hidden="true">{flagEmoji(country.iso2)}</span>
        <span>+{country.dialCode}</span>
      </button>
      <input
        id={id}
        name={name || id}
        type="tel"
        autoComplete={autoComplete}
        className="phone-input-number"
        value={number}
        onChange={(e) => onNumberChange(e.target.value)}
        aria-invalid={error ? "true" : undefined}
        aria-describedby={error ? `${id}-error` : undefined}
        placeholder="50 123 4567"
      />
      {open && (
        <div className="phone-input-dropdown" role="listbox">
          <input
            ref={searchRef}
            type="text"
            className="phone-input-search"
            placeholder="Search country or code…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <div className="phone-input-country-list">
            {filtered.length === 0 ? (
              <div className="phone-input-empty">No countries match.</div>
            ) : (
              filtered.map((c) => (
                <button
                  type="button"
                  key={c.iso2}
                  className={`phone-input-country-item${c.iso2 === country.iso2 ? " highlighted" : ""}`}
                  role="option"
                  aria-selected={c.iso2 === country.iso2}
                  onClick={() => selectCountry(c.iso2)}
                >
                  <span aria-hidden="true">{flagEmoji(c.iso2)}</span>
                  <span>{c.name}</span>
                  <span className="dial-code">+{c.dialCode}</span>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
