import ClassicTemplate from "./ClassicTemplate";

export const DEBIT_NOTE_TEMPLATES = {
  classic: { label: "Classic", component: ClassicTemplate },
};

export const DEFAULT_DEBIT_NOTE_TEMPLATE = "classic";

export function getDebitNoteTemplateComponent(key) {
  return DEBIT_NOTE_TEMPLATES[key]?.component || DEBIT_NOTE_TEMPLATES[DEFAULT_DEBIT_NOTE_TEMPLATE].component;
}
