import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

function buildTaxBreakdown(lineItems) {
  const groups = new Map();
  for (const li of lineItems) {
    const key = `${li.taxRateName || "No tax"}|${li.taxPercentage}`;
    const existing = groups.get(key) || { name: li.taxRateName || "No tax", percentage: li.taxPercentage, taxableAmount: 0, taxAmount: 0 };
    existing.taxableAmount += li.lineTaxableAmount;
    existing.taxAmount += li.lineTaxAmount;
    groups.set(key, existing);
  }
  return Array.from(groups.values());
}

// Mirrors credit-note-templates/ClassicTemplate.js, purchase side - "DEBIT
// NOTE" title, Original Purchase Bill reference, vendor instead of customer.
const DebitNoteClassicTemplate = forwardRef(function DebitNoteClassicTemplate({ debitNote, businessAssets = {} }, ref) {
  const taxBreakdown = buildTaxBreakdown(debitNote.lineItems || []);
  const watermark = debitNote.status === "VOID" ? "CANCELLED" : debitNote.status === "DRAFT" ? "DRAFT" : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden={!businessAssets.logoUrl}>
            {businessAssets.logoUrl && <img src={businessAssets.logoUrl} alt="Company logo" />}
          </div>
          <div className="invoice-doc-business">
            {/* Was a hardcoded "Debit Note" literal (2026-08-11 fix) - a
                Debit Note is issued BY the tenant TO the vendor, so this
                slot needs the tenant's own identity, same as Credit Note
                shows here for its own issuer. */}
            <strong>{debitNote.businessName}</strong>
            {debitNote.businessTrn && <span>TRN: {debitNote.businessTrn}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>TAX DEBIT NOTE</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Debit Note #</td>
                <td className="mono">{debitNote.debitNoteNumberDisplay || "DRAFT"}</td>
              </tr>
              <tr>
                <td>Original Purchase Bill #</td>
                <td className="mono">{debitNote.purchaseBill?.billNumberDisplay}</td>
              </tr>
              <tr>
                <td>Issue Date</td>
                <td>{formatDate(debitNote.issueDate)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="invoice-doc-parties">
        <div>
          <span className="invoice-doc-label">Vendor</span>
          <strong>{debitNote.vendorName}</strong>
          {debitNote.vendorAddress && <span>{debitNote.vendorAddress}</span>}
          {debitNote.vendorTrn && <span>TRN: {debitNote.vendorTrn}</span>}
        </div>
        <div>
          <span className="invoice-doc-label">Reason</span>
          <span>{debitNote.reason}</span>
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Description</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(debitNote.lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, debitNote.currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              {/* lineNetAmount, not lineTotal - same reconciliation fix as
                  invoice-templates/ClassicTemplate.js (2026-08-11). */}
              <td className="num">{formatCurrency(li.lineNetAmount, debitNote.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        {taxBreakdown.length > 0 && (
          <table className="invoice-doc-tax-breakdown">
            <thead>
              <tr>
                <th>Tax Breakdown</th>
                <th className="num">Taxable Amount</th>
                <th className="num">Tax</th>
              </tr>
            </thead>
            <tbody>
              {taxBreakdown.map((g) => (
                <tr key={g.name}>
                  <td>
                    {g.name} ({g.percentage}%)
                  </td>
                  <td className="num">{formatCurrency(g.taxableAmount, debitNote.currency)}</td>
                  <td className="num">{formatCurrency(g.taxAmount, debitNote.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Subtotal</td>
              <td className="num">{formatCurrency(debitNote.subtotal, debitNote.currency)}</td>
            </tr>
            <tr>
              <td>VAT</td>
              <td className="num">{formatCurrency(debitNote.vatTotal, debitNote.currency)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>Total Debit</td>
              <td className="num">{formatCurrency(debitNote.grandTotal, debitNote.currency)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {debitNote.notes && (
        <div className="invoice-doc-notes">
          <span className="invoice-doc-label">Notes</span>
          <p>{debitNote.notes}</p>
        </div>
      )}

      {(businessAssets.signatureUrl || businessAssets.stampUrl) && (
        <div className="invoice-doc-signoff">
          {businessAssets.signatureUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.signatureUrl} alt="Authorized signature" />
              <span>Authorized Signatory</span>
            </div>
          )}
          {businessAssets.stampUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.stampUrl} alt="Company stamp" />
              <span>Company Stamp</span>
            </div>
          )}
        </div>
      )}

      <div className="invoice-doc-footer">
        <span>This is a computer-generated debit note.</span>
      </div>
    </div>
  );
});

export default DebitNoteClassicTemplate;
