// Per-field confidence indicator for the OCR Review Screen. Thresholds are a
// simple, honest read of the placeholder OCR service's 0-1 score - a real
// provider would plug into the exact same three-tier display.
function tierFor(confidence) {
  if (confidence == null) return { label: "Manual", className: "badge-info" };
  if (confidence >= 0.85) return { label: "High", className: "badge-success" };
  if (confidence >= 0.65) return { label: "Medium", className: "badge-premium" };
  return { label: "Low", className: "badge-danger" };
}

export default function OcrConfidenceBadge({ confidence }) {
  const tier = tierFor(confidence);
  return (
    <span className={`badge ${tier.className} ocr-confidence-badge`} title={confidence != null ? `${Math.round(confidence * 100)}% confidence` : "Entered manually"}>
      {tier.label}
      {confidence != null && ` ${Math.round(confidence * 100)}%`}
    </span>
  );
}
