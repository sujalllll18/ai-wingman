import Card from "../ui/Card";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

// Sticky totals panel, mirrors InvoiceSummarySidebar minus the discount
// controls - discount isn't part of the confirmed Purchase scope.
export default function PurchaseSummarySidebar({ totals }) {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Summary</h3>
      <div className="summary-rows" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="helptext">Subtotal</span>
          <span className="mono">{formatCurrency(totals.subtotal)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="helptext">VAT</span>
          <span className="mono">{formatCurrency(totals.vatTotal)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid var(--color-line)", paddingTop: 8, fontWeight: 600 }}>
          <span>Grand Total</span>
          <span className="mono">{formatCurrency(totals.grandTotal)}</span>
        </div>
      </div>
    </Card>
  );
}
