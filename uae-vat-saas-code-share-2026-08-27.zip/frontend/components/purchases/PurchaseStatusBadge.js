// Two-axis status model, mirroring Invoice's InvoiceStatusBadge: `status`
// (DRAFT/RECORDED/VOID) + `paymentStatus` (UNPAID/PARTIALLY_PAID/PAID) - no
// Bad Debt (a receivables concept, doesn't apply to a payable) and no
// Overdue flag (no due-date field in this module's scope).
//
// 2026-08-06 (Purchases list redesign, matching InvoiceStatusBadge.js's
// same split): DocumentStatusChip/PaymentStatusChip as standalone chips for
// the list table's separate Status/Payment Status columns - same maps, no
// data or business-rule change. Default export kept for the detail page.
const STATUS_BADGE = {
  DRAFT: { label: "Draft", className: "badge-info" },
  RECORDED: { label: "Recorded", className: "badge-success" },
  VOID: { label: "Cancelled", className: "badge-danger" },
};

const PAYMENT_BADGE = {
  UNPAID: { label: "Unpaid", className: "badge-danger" },
  PARTIALLY_PAID: { label: "Partially Paid", className: "badge-premium" },
  PAID: { label: "Paid", className: "badge-success" },
};

export function DocumentStatusChip({ purchase }) {
  const status = STATUS_BADGE[purchase.status] || STATUS_BADGE.DRAFT;
  return <span className={`badge ${status.className}`}>{status.label}</span>;
}

export function PaymentStatusChip({ purchase }) {
  if (purchase.status !== "RECORDED") return <span style={{ color: "var(--color-ink-faint)" }}>—</span>;
  const payment = PAYMENT_BADGE[purchase.paymentStatus] || PAYMENT_BADGE.UNPAID;
  return <span className={`badge ${payment.className}`}>{payment.label}</span>;
}

export default function PurchaseStatusBadge({ purchase }) {
  return (
    <span style={{ display: "inline-flex", gap: 6, flexWrap: "wrap" }}>
      <DocumentStatusChip purchase={purchase} />
      {purchase.status === "RECORDED" && <PaymentStatusChip purchase={purchase} />}
    </span>
  );
}
