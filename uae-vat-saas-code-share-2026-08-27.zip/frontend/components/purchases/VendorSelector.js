import Select from "../ui/Select";

// Sourced from Vendor Master, same shape as Invoice's MaterialSelector -
// selecting an existing Vendor is a one-time autofill convenience, the
// parent copies name/trn onto the form, then this selector's job is done.
// Unlike Customer on Invoice, EVERY Purchase Bill ends up linked to a real
// Vendor row regardless of whether one was picked here or typed manually -
// see src/services/vendorResolver.js on the backend.
export default function VendorSelector({ vendors, value, onChange }) {
  return (
    <Select className="inline-input" value={value || ""} onChange={(e) => onChange(e.target.value)}>
      <option value="">— Type a new vendor —</option>
      {vendors.map((v) => (
        <option key={v.id} value={v.id}>
          {v.name}
        </option>
      ))}
    </Select>
  );
}
