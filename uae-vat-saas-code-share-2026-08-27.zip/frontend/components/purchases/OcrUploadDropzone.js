"use client";

import { useRef, useState } from "react";

const ACCEPTED_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Drag-and-drop + click-to-browse upload area for the primary Purchase entry
// point (Supplier Invoice PDF/Image -> OCR Extraction). Purely a file picker -
// the actual upload/extract call happens in the parent page once the user
// confirms this selection.
export default function OcrUploadDropzone({ onFileSelected }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState("");

  function validateAndSet(file) {
    if (!file) return;
    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError("Only PDF, JPEG, PNG, or WEBP files are accepted.");
      return;
    }
    setError("");
    setSelectedFile(file);
    onFileSelected(file);
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    validateAndSet(e.dataTransfer.files?.[0]);
  }

  return (
    <div>
      <div
        className={`ocr-dropzone${dragOver ? " ocr-dropzone-active" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
      >
        <svg viewBox="0 0 24 24" className="ocr-dropzone-icon" aria-hidden="true">
          <path d="M12 3.5v11M7 9l5-5.5L17 9" />
          <path d="M4 16.5v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
        </svg>
        {selectedFile ? (
          <>
            <strong>{selectedFile.name}</strong>
            <span className="helptext">{formatFileSize(selectedFile.size)} — click or drop to replace</span>
          </>
        ) : (
          <>
            <strong>Drop a supplier invoice here, or click to browse</strong>
            <span className="helptext">PDF, JPEG, PNG, or WEBP — up to 10MB</span>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.jpg,.jpeg,.png,.webp"
          style={{ display: "none" }}
          onChange={(e) => validateAndSet(e.target.files?.[0])}
        />
      </div>
      {error && (
        <p className="field-error" role="alert" style={{ marginTop: 8 }}>
          {error}
        </p>
      )}
    </div>
  );
}
