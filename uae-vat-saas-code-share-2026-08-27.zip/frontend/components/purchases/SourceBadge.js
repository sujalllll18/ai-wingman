// Compact icon+label chip for PurchaseBill.sourceType (2026-08-06 Purchases
// redesign) - same `.badge` pill shape used everywhere else in the app,
// just with a small inline icon prefix instead of text-only.
// "IMPORT" added (Import Framework, 2026-08-09) - a real bug was caught and
// fixed here during verification: sourceType gained a third value
// (purchase.controller.js/schema.prisma) but this component still only
// branched OCR vs "everything else is Manual," so every imported bill
// silently displayed as "Manual" - same class of bug the Sprint 3
// FULL_INCLUDE fix already warned about (a new value added to a shared
// field without updating every place that reads it).
const SOURCE_META = {
  OCR_UPLOAD: {
    label: "OCR",
    className: "badge-premium",
    path: "M12 16V4M12 4l-4 4M12 4l4 4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3",
  },
  IMPORT: {
    label: "Imported",
    className: "badge-success",
    path: "M12 3.5v11M7.5 10l4.5 4.5L16.5 10M4.5 16.5V19a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5v-2.5",
  },
  MANUAL: {
    label: "Manual",
    className: "badge-info",
    path: "M4 20l1.5-4.5L16 5l3 3-10.5 10.5z",
  },
};

export default function SourceBadge({ sourceType }) {
  const meta = SOURCE_META[sourceType] || SOURCE_META.MANUAL;
  return (
    <span className={`badge ${meta.className}`} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
      <svg viewBox="0 0 24 24" width="12" height="12" style={{ stroke: "currentColor", strokeWidth: 2, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" }}>
        <path d={meta.path} />
      </svg>
      {meta.label}
    </span>
  );
}
