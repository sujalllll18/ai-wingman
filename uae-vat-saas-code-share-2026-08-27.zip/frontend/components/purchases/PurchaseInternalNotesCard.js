"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Card from "../ui/Card";
import Button from "../ui/Button";

// Operational notes only, mirrors Invoice's InternalNotesCard - editable
// regardless of bill status.
export default function PurchaseInternalNotesCard({ purchase, onSaved, showToast }) {
  const [value, setValue] = useState(purchase.internalNotes || "");
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      const token = tenantAuth.get();
      const { purchase: updated } = await api.updatePurchaseInternalNotes(token, purchase.id, value);
      onSaved(updated);
      showToast("Internal notes saved.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Internal Notes</h3>
      <p className="helptext" style={{ marginTop: 0 }}>Visible to your team only.</p>
      <textarea
        className="inline-input"
        rows={3}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="e.g. Follow up with vendor about a pricing discrepancy…"
      />
      <div style={{ marginTop: 10 }}>
        <Button variant="outline" onClick={handleSave} disabled={saving || value === (purchase.internalNotes || "")}>
          {saving ? "Saving…" : "Save Notes"}
        </Button>
      </div>
    </Card>
  );
}
