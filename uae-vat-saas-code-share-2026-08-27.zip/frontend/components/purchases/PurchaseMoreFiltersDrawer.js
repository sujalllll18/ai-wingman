"use client";

import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Select from "../ui/Select";
import Input from "../ui/Input";
import Button from "../ui/Button";
import Tooltip from "../ui/Tooltip";
import PlaceholderNotice from "../ui/PlaceholderNotice";

// Advanced filter panel for the Purchases list (2026-08-06 redesign) -
// structurally identical to MoreFiltersDrawer.js (Invoices), same Drawer.js
// wrapper, same "live filter vs. honest placeholder" split. Payment Status,
// Source, Approval Status, and Supplier Invoice # are all real fields/
// already-built data (approvalStatus is cross-referenced from the existing
// Approvals module, see purchases/page.js); Created By/Amount Range/Currency
// have no corresponding field on PurchaseBill, so they stay disabled
// placeholders instead of faking a filter that can't filter anything.
export default function PurchaseMoreFiltersDrawer({
  open,
  onClose,
  paymentStatusFilter,
  onPaymentStatusChange,
  sourceFilter,
  onSourceChange,
  approvalStatusFilter,
  onApprovalStatusChange,
  supplierInvoiceFilter,
  onSupplierInvoiceFilterChange,
  archivedView,
  onToggleArchived,
  onClearAll,
}) {
  return (
    <Drawer open={open} onClose={onClose} ariaLabel="More Filters">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>More Filters</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Refine the purchase bill list beyond the toolbar's quick filters.
        </p>
      </div>

      <div className="drawer-body">
        <Field id="filter-purchase-payment-status" label="Payment Status">
          <Select value={paymentStatusFilter} onChange={(e) => onPaymentStatusChange(e.target.value)}>
            <option value="ALL">All payment statuses</option>
            <option value="UNPAID">Unpaid</option>
            <option value="PARTIALLY_PAID">Partially Paid</option>
            <option value="PAID">Paid</option>
          </Select>
        </Field>

        <Field id="filter-purchase-source" label="Source">
          <Select value={sourceFilter} onChange={(e) => onSourceChange(e.target.value)}>
            <option value="ALL">All sources</option>
            <option value="OCR_UPLOAD">OCR Upload</option>
            <option value="MANUAL">Manual</option>
          </Select>
        </Field>

        <Field
          id="filter-purchase-approval-status"
          label="Approval Status"
          helptext="Only meaningful once a Maker-Checker rule is turned on for Purchases in Settings"
        >
          <Select value={approvalStatusFilter} onChange={(e) => onApprovalStatusChange(e.target.value)}>
            <option value="ALL">All approval statuses</option>
            <option value="NOT_REQUIRED">Not Required</option>
            <option value="PENDING">Pending Approval</option>
            <option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option>
            <option value="CANCELLED">Cancelled</option>
          </Select>
        </Field>

        <Field id="filter-purchase-supplier-invoice" label="Supplier Invoice #">
          <Input
            value={supplierInvoiceFilter}
            onChange={(e) => onSupplierInvoiceFilterChange(e.target.value)}
            placeholder="e.g. INV-2026-004"
          />
        </Field>

        <label className="checkbox-row">
          <input type="checkbox" checked={archivedView} onChange={(e) => onToggleArchived(e.target.checked)} />
          Show archived purchase bills
        </label>

        <PlaceholderNotice>
          Created By, Amount Range, and Currency aren&rsquo;t tracked on purchase bills yet — these filters are
          ready for that data once it exists.
        </PlaceholderNotice>

        <div style={{ opacity: 0.55, pointerEvents: "none" }} aria-disabled="true">
          <div className="form-grid">
            <Field id="filter-purchase-created-by" label="Created By">
              <Select disabled>
                <option>Anyone</option>
              </Select>
            </Field>
            <Field id="filter-purchase-currency" label="Currency">
              <Select disabled>
                <option>AED</option>
              </Select>
            </Field>
          </div>
          <div className="form-grid">
            <Field id="filter-purchase-amount-min" label="Amount Min">
              <Input type="number" disabled placeholder="0" />
            </Field>
            <Field id="filter-purchase-amount-max" label="Amount Max">
              <Input type="number" disabled placeholder="Any" />
            </Field>
          </div>
        </div>
      </div>

      <div className="drawer-actions">
        <Button variant="outline" onClick={onClearAll}>
          Clear Filters
        </Button>
        <Tooltip label="Applies as you change each field above">
          <Button onClick={onClose}>Done</Button>
        </Tooltip>
      </div>
    </Drawer>
  );
}
