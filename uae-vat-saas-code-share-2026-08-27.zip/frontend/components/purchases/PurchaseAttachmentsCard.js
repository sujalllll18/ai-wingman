"use client";

import { useRef, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Card from "../ui/Card";
import Button from "../ui/Button";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Real file storage, unlike Invoice's AttachmentsPlaceholder - the OCR
// Upload flow needs somewhere to keep the original source document, so this
// module has actual multer-backed disk storage from day one (see
// purchase.routes.js). The source-document attachment (from OCR upload, if
// any) is called out separately; further attachments can be added manually.
export default function PurchaseAttachmentsCard({ purchase, onSaved, showToast }) {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const attachments = purchase.attachments || [];
  const sourceDoc = attachments.find((a) => a.isSourceDocument);
  const otherAttachments = attachments.filter((a) => !a.isSourceDocument);

  async function handleFileChosen(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    try {
      const token = tenantAuth.get();
      await api.addPurchaseAttachment(token, purchase.id, file);
      const { purchase: updated } = await api.getPurchase(token, purchase.id);
      onSaved(updated);
      showToast("Attachment added.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h3 style={{ margin: 0 }}>Attachments</h3>
        <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
          {uploading ? "Uploading…" : "+ Add Attachment"}
        </Button>
        <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" style={{ display: "none" }} onChange={handleFileChosen} />
      </div>

      {sourceDoc && (
        <div style={{ marginTop: 12 }}>
          <span className="helptext">Source Document (OCR Upload)</span>
          <div className="attachment-row">
            <span>{sourceDoc.fileName}</span>
            <span className="helptext">{formatFileSize(sourceDoc.fileSize)}</span>
            <a href={`${API_URL}${sourceDoc.fileUrl}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline btn-sm">
              View
            </a>
          </div>
        </div>
      )}

      {otherAttachments.length > 0 ? (
        <div style={{ marginTop: sourceDoc ? 16 : 12, display: "flex", flexDirection: "column", gap: 8 }}>
          {otherAttachments.map((a) => (
            <div className="attachment-row" key={a.id}>
              <span>{a.fileName}</span>
              <span className="helptext">{formatFileSize(a.fileSize)}</span>
              <a href={`${API_URL}${a.fileUrl}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline btn-sm">
                View
              </a>
            </div>
          ))}
        </div>
      ) : (
        !sourceDoc && <p className="helptext" style={{ marginTop: 12 }}>No attachments yet.</p>
      )}
    </Card>
  );
}
