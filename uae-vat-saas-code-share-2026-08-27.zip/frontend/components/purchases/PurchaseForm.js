"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { calculateInvoiceTotals } from "../../lib/invoiceCalc";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import VendorSelector from "./VendorSelector";
import PurchaseLineItemsTable from "./PurchaseLineItemsTable";
import PurchaseSummarySidebar from "./PurchaseSummarySidebar";

function newLineKey() {
  return `line-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function toDateInputValue(iso) {
  if (!iso) return "";
  return new Date(iso).toISOString().slice(0, 10);
}

function linesFromPurchase(purchase) {
  if (!purchase?.lineItems?.length) return [];
  return purchase.lineItems.map((li) => ({
    key: newLineKey(),
    lineId: li.id,
    description: li.description,
    quantity: String(li.quantity),
    unitPrice: String(li.unitPrice),
    taxCategoryId: li.taxCategoryId || "",
  }));
}

// Manual entry / edit-while-Draft form - the alternative path alongside OCR
// Upload. Full page, mirrors InvoiceForm's layout exactly (line items +
// sticky summary sidebar), minus discount (not in Purchase's confirmed
// scope) and with a Vendor selector/manual-entry pair instead of Customer.
export default function PurchaseForm({ mode, initialPurchase, onSaved }) {
  const router = useRouter();
  const isEdit = mode === "edit";

  const [vendors, setVendors] = useState([]);
  const [taxCategories, setTaxCategories] = useState([]);
  const [loadError, setLoadError] = useState("");

  const [vendorId, setVendorId] = useState(initialPurchase?.vendorId || "");
  const [vendorName, setVendorName] = useState(initialPurchase?.vendorName || "");
  const [vendorTrn, setVendorTrn] = useState(initialPurchase?.vendorTrn || "");
  const [vendorAddress, setVendorAddress] = useState(initialPurchase?.vendorAddress || "");
  const [supplierInvoiceNumber, setSupplierInvoiceNumber] = useState(initialPurchase?.supplierInvoiceNumber || "");
  const [invoiceDate, setInvoiceDate] = useState(toDateInputValue(initialPurchase?.invoiceDate));
  const [purchaseDate, setPurchaseDate] = useState(toDateInputValue(initialPurchase?.purchaseDate) || toDateInputValue(new Date().toISOString()));
  const [notes, setNotes] = useState(initialPurchase?.notes || "");

  const [lines, setLines] = useState(() => linesFromPurchase(initialPurchase));
  const [deletedLineIds, setDeletedLineIds] = useState([]);

  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const [{ vendors }, { categories }] = await Promise.all([api.listVendors(token), api.listTaxCategories(token)]);
        setVendors(vendors);
        setTaxCategories(categories.filter((c) => c.status === "ACTIVE"));
      } catch (err) {
        setLoadError(err.message);
      }
    })();
  }, []);

  function categoryFor(id) {
    return taxCategories.find((c) => c.id === id);
  }

  const totals = useMemo(() => {
    const calcLines = lines.map((l) => {
      const cat = categoryFor(l.taxCategoryId);
      return {
        quantity: l.quantity,
        unitPrice: l.unitPrice,
        taxPercentage: cat?.taxRate?.percentage || 0,
        taxCalculationMethod: cat?.taxRate?.calculationMethod || "EXCLUSIVE",
      };
    });
    return calculateInvoiceTotals(calcLines, {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines, taxCategories]);

  function handleVendorSelect(id) {
    setVendorId(id);
    if (!id) return;
    const vendor = vendors.find((v) => v.id === id);
    if (!vendor) return;
    setVendorName(vendor.name);
    setVendorTrn(vendor.trn || "");
    setVendorAddress(vendor.address || "");
  }

  function handleChangeLine(index, patch) {
    setLines((prev) => prev.map((l, i) => (i === index ? { ...l, ...patch } : l)));
  }

  function handleAddLine() {
    setLines((prev) => [...prev, { key: newLineKey(), lineId: null, description: "", quantity: "1", unitPrice: "0", taxCategoryId: "" }]);
  }

  function handleRemoveLine(index) {
    setLines((prev) => {
      const removed = prev[index];
      if (removed?.lineId) setDeletedLineIds((ids) => [...ids, removed.lineId]);
      return prev.filter((_, i) => i !== index);
    });
  }

  function linePayload(l) {
    return {
      description: l.description.trim(),
      quantity: Number(l.quantity),
      unitPrice: Number(l.unitPrice),
      taxCategoryId: l.taxCategoryId || null,
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (saving) return;

    if (!vendorName.trim()) {
      setError("Vendor name is required — select a Vendor or type one manually.");
      return;
    }
    if (lines.length === 0) {
      setError("Add at least one line item.");
      return;
    }
    for (const l of lines) {
      if (!l.description.trim() || !l.quantity || Number(l.quantity) <= 0) {
        setError("Every line item needs a description and a positive quantity.");
        return;
      }
    }

    setError("");
    setSaving(true);
    try {
      const token = tenantAuth.get();
      const header = {
        vendorName: vendorName.trim(),
        vendorTrn: vendorTrn || null,
        vendorAddress: vendorAddress || null,
        supplierInvoiceNumber: supplierInvoiceNumber || null,
        invoiceDate: invoiceDate || null,
        purchaseDate: purchaseDate || null,
        notes: notes || null,
      };

      let purchaseId = initialPurchase?.id;
      if (isEdit) {
        await api.updatePurchase(token, purchaseId, header);
        for (const id of deletedLineIds) {
          await api.deletePurchaseLineItem(token, purchaseId, id);
        }
        for (const l of lines) {
          if (l.lineId) {
            await api.updatePurchaseLineItem(token, purchaseId, l.lineId, linePayload(l));
          } else {
            await api.addPurchaseLineItem(token, purchaseId, linePayload(l));
          }
        }
        const { purchase } = await api.getPurchase(token, purchaseId);
        onSaved(purchase);
      } else {
        const { purchase } = await api.createPurchase(token, { ...header, lineItems: lines.map(linePayload) });
        onSaved(purchase);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <ErrorBanner message={error || loadError} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Vendor</h3>
            <Field id="purchase-vendor" label="Select an existing Vendor (optional)">
              <VendorSelector vendors={vendors} value={vendorId} onChange={handleVendorSelect} />
            </Field>
            <div className="form-grid">
              <Field id="purchase-vendor-name" label={<>Vendor Name<span className="required-asterisk">*</span></>}>
                <Input value={vendorName} onChange={(e) => setVendorName(e.target.value)} />
              </Field>
              <Field id="purchase-vendor-trn" label="Vendor TRN">
                <Input value={vendorTrn} onChange={(e) => setVendorTrn(e.target.value)} />
              </Field>
            </div>
            <Field id="purchase-vendor-address" label="Vendor Address" style={{ marginBottom: 0 }}>
              <Input value={vendorAddress} onChange={(e) => setVendorAddress(e.target.value)} />
            </Field>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <PurchaseLineItemsTable
              lines={lines}
              computedLines={totals.lines}
              taxCategories={taxCategories}
              onChangeLine={handleChangeLine}
              onAddLine={handleAddLine}
              onRemoveLine={handleRemoveLine}
            />
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Details</h3>
            <div className="form-grid">
              <Field id="purchase-supplier-invoice-number" label="Supplier Invoice #">
                <Input value={supplierInvoiceNumber} onChange={(e) => setSupplierInvoiceNumber(e.target.value)} placeholder="As printed on the vendor's document" />
              </Field>
              <Field id="purchase-invoice-date" label="Invoice Date">
                <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
              </Field>
              <Field id="purchase-date" label="Purchase Date">
                <Input type="date" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} />
              </Field>
            </div>
            <Field id="purchase-notes" label="Notes" style={{ marginBottom: 0 }}>
              <textarea className="inline-input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything worth noting about this bill." />
            </Field>
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <PurchaseSummarySidebar totals={totals} />
          <div style={{ display: "flex", gap: 8 }}>
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={saving}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : isEdit ? "Save Changes" : "Save Draft"}
            </Button>
          </div>
        </div>
      </div>
    </form>
  );
}
