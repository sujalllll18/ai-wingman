import Card from "../ui/Card";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

// Shared by Credit Note and Debit Note detail/create pages - the
// Original / Previously Adjusted / This Note / Remaining summary required
// everywhere a note references its source document. Credit Notes pass
// `remainingAmount` (capped, since a Credit Note can never exceed what's
// left to credit); Debit Notes omit it (additive, no cap - see
// debitNote.controller.js's comment on why there's no per-line remaining
// concept there).
export default function AdjustmentSummaryCard({
  currency,
  originalAmount,
  originalLabel = "Original Amount",
  previouslyAdjusted,
  previouslyLabel = "Previously Adjusted",
  currentNote,
  currentLabel = "This Note",
  remainingAmount,
  remainingLabel = "Remaining Amount",
}) {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Adjustment Summary</h3>
      <div className="review-list">
        <div className="review-row">
          <span className="review-label">{originalLabel}</span>
          <span className="review-value mono">{formatCurrency(originalAmount, currency)}</span>
        </div>
        <div className="review-row">
          <span className="review-label">{previouslyLabel}</span>
          <span className="review-value mono">{formatCurrency(previouslyAdjusted, currency)}</span>
        </div>
        <div className="review-row">
          <span className="review-label">{currentLabel}</span>
          <span className="review-value mono">{formatCurrency(currentNote, currency)}</span>
        </div>
        {remainingAmount !== undefined && (
          <div className="review-row" style={{ fontWeight: 600 }}>
            <span className="review-label">{remainingLabel}</span>
            <span className="review-value mono">{formatCurrency(remainingAmount, currency)}</span>
          </div>
        )}
      </div>
    </Card>
  );
}
