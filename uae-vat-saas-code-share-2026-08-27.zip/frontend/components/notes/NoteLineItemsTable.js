import TableScroll from "../ui/TableScroll";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

// Shared, read-only, by Credit Note and Debit Note detail/PDF views - line
// items on a note are never edited in place once created here (they're
// edited via the dedicated line-item endpoints while still Draft, and
// become fully immutable at Issue, same principle as Invoice/Purchase line
// items). Same visual shape as LineItemsTable/PurchaseLineItemsTable's
// disabled read-only mode, simplified since a note line has no discount
// share of its own.
export default function NoteLineItemsTable({ lineItems, currency }) {
  return (
    <TableScroll>
      <table className="data-table">
        <thead>
          <tr>
            <th>Description</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              <td className="num mono">{formatCurrency(li.lineTotal, currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </TableScroll>
  );
}
