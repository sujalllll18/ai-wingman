// Shared by Credit Note and Debit Note list/detail pages - both use the
// identical DRAFT | ISSUED | VOID lifecycle (see prisma/schema.prisma's
// CreditNote/DebitNote models), so one component covers both rather than
// duplicating the same three-entry map twice. Same visual language as
// InvoiceStatusBadge's DocumentStatusChip (badge classes/labels), just
// without a second payment-status axis - notes don't carry their own
// payment/receivable state, they only ever adjust the original document's.
const STATUS_BADGE = {
  DRAFT: { label: "Draft", className: "badge-info" },
  ISSUED: { label: "Issued", className: "badge-success" },
  VOID: { label: "Cancelled", className: "badge-danger" },
};

export default function NoteStatusBadge({ status }) {
  const s = STATUS_BADGE[status] || STATUS_BADGE.DRAFT;
  return <span className={`badge ${s.className}`}>{s.label}</span>;
}
