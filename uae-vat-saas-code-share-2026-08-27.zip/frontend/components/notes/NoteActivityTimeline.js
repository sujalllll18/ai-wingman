// Shared by Credit Note and Debit Note detail pages - both write the
// identical activity vocabulary (CreditNoteActivity/DebitNoteActivity share
// the same `type` values, see prisma/schema.prisma). Same visual pattern as
// invoices/ActivityTimeline.js, not reused directly since the type
// vocabulary differs (ISSUED/VOIDED here vs SENT/CANCELLED there).
const TYPE_LABEL = {
  CREATED: "Created",
  EDITED: "Edited",
  ISSUED: "Issued",
  VOIDED: "Cancelled",
  DOWNLOADED: "Downloaded",
  PREVIEWED: "Previewed",
};

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Newest first - the backend already orders activities that way.
export default function NoteActivityTimeline({ activities }) {
  if (!activities || activities.length === 0) {
    return <p className="helptext" style={{ margin: 0 }}>No activity yet.</p>;
  }

  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
      {activities.map((a) => (
        <li key={a.id} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span
            aria-hidden="true"
            style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--color-accent)", marginTop: 6, flexShrink: 0 }}
          />
          <div>
            <div style={{ fontWeight: 600, fontSize: 13 }}>{TYPE_LABEL[a.type] || a.type}</div>
            {a.description && <div className="helptext" style={{ margin: "2px 0 0" }}>{a.description}</div>}
            <div className="helptext" style={{ margin: "2px 0 0", fontSize: 11 }}>{formatDateTime(a.createdAt)}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}
