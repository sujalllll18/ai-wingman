import Link from "next/link";
import Card from "../ui/Card";

const ICONS = {
  invoice: (
    <svg viewBox="0 0 24 24">
      <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
      <path d="M8 8h8M8 12h8M8 16h5" />
    </svg>
  ),
  purchase: (
    <svg viewBox="0 0 24 24">
      <path d="M12 3.5v11M7 9l5-5.5L17 9" />
      <path d="M4 16.5v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
    </svg>
  ),
  customer: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="8" r="3" />
      <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
      <path d="M17 8v6M14 11h6" />
    </svg>
  ),
  vat: (
    <svg viewBox="0 0 24 24">
      <circle cx="7" cy="7" r="2.5" />
      <circle cx="17" cy="17" r="2.5" />
      <path d="M18 6 6 18" />
    </svg>
  ),
};

const ACTIONS = [
  { key: "invoice", label: "Create Invoice", href: "/tenant/invoices/new" },
  { key: "purchase", label: "Record Purchase", href: "/tenant/purchases/upload" },
  { key: "customer", label: "Add Customer", href: "/tenant/customers" },
  { key: "vat", label: "Generate VAT Return", href: "/tenant/vat-returns" },
];

// Real action cards (2026-08-04 UI Polish Sprint) - replaces the permanent
// disabled/"Coming Soon" buttons that predated Invoice/Purchase/Customer/VAT
// Return existing. Static links, no data dependency - renders immediately
// and stays usable even while the Dashboard's KPI cards are still loading.
export default function QuickActions() {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Quick Actions</h2>
      <p className="form-section-desc" style={{ marginBottom: 16 }}>Shortcuts for common tasks.</p>
      <div className="dashboard-action-grid">
        {ACTIONS.map((action) => (
          <Link key={action.key} href={action.href} className="dashboard-action-card">
            <span className="dashboard-action-icon">{ICONS[action.key]}</span>
            <span className="dashboard-action-label">{action.label}</span>
          </Link>
        ))}
      </div>
    </Card>
  );
}
