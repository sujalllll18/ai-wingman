import Card from "../ui/Card";
import EmptyState from "../ui/EmptyState";

export default function RecentActivity() {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Recent Activity</h2>
      <p className="form-section-desc">What's happened lately across your business.</p>
      <EmptyState
        icon={
          <svg viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="9" />
            <path d="M12 7v5l3.5 2" />
          </svg>
        }
        title="Coming Soon"
        description="Activity tracking isn't available yet — it will appear here once business modules are built."
      />
    </Card>
  );
}
