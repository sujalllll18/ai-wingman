import Card from "../ui/Card";

// "Team invited" is derived from a real signal (more than just the Owner in
// the team list) rather than fabricated; the rest are honestly unavailable
// until their modules exist.
export default function GettingStarted({ teamCount }) {
  const items = [
    { label: "Account created", done: true, available: true },
    { label: "Invite your team", done: teamCount != null && teamCount > 1, available: true },
    { label: "Add your first customer", done: false, available: false },
    { label: "Create your first invoice", done: false, available: false },
  ];

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Getting Started</h2>
      <p className="form-section-desc">A few steps to get your business up and running.</p>
      <ul className="checklist">
        {items.map((item) => (
          <li key={item.label} className={`checklist-item${item.done ? " done" : ""}`}>
            <span className="checklist-checkbox" aria-hidden="true">
              {item.done ? "✓" : ""}
            </span>
            <span>
              {item.label}
              {!item.available && <span className="checklist-soon"> — Coming Soon</span>}
            </span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
