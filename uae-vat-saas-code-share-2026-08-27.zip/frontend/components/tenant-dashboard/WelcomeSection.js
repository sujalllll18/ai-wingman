// Compact, single-line treatment (2026-08-04 UI Polish Sprint) - the
// Dashboard needs to fit on one 1920x1080 screen, and a full Card with its
// own heading took more vertical space than a welcome line needs.
export default function WelcomeSection({ userName, tenantName }) {
  return (
    <p style={{ margin: 0, fontSize: 14 }}>
      <strong style={{ color: "var(--color-ink)" }}>Welcome back{userName ? `, ${userName}` : ""}.</strong>{" "}
      {tenantName ? `Here's what's happening at ${tenantName}.` : "Here's what's happening at your business."}
    </p>
  );
}
