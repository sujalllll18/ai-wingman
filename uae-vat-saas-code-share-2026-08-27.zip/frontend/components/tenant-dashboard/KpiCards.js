import Link from "next/link";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

const ViewArrow = () => (
  <span className="dashboard-kpi-view">
    View
    <svg viewBox="0 0 24 24">
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  </span>
);

const ICONS = {
  invoices: (
    <svg viewBox="0 0 24 24">
      <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
      <path d="M8 8h8M8 12h8M8 16h5" />
    </svg>
  ),
  purchases: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="20" r="1.4" />
      <circle cx="17" cy="20" r="1.4" />
      <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
    </svg>
  ),
  revenue: (
    <svg viewBox="0 0 24 24">
      <path d="M12 3v18M17 7.5c0-2-2-3.5-5-3.5s-5 1.5-5 3.5 2 3 5 3.5 5 1.5 5 3.5-2 3.5-5 3.5-5-1.5-5-3.5" />
    </svg>
  ),
  vat: (
    <svg viewBox="0 0 24 24">
      <circle cx="7" cy="7" r="2.5" />
      <circle cx="17" cy="17" r="2.5" />
      <path d="M18 6 6 18" />
    </svg>
  ),
};

// Real, clickable KPI cards (2026-08-04 UI Polish Sprint) - replaces the
// permanent "Coming Soon" placeholders that predated Invoice/Purchase/VAT
// Return existing. Purely presentational: all data is fetched and computed
// by the Dashboard page and passed in as props, same pattern teamCount
// already used.
export default function KpiCards({ invoiceCount, purchaseCount, paidRevenue, vatPayable, vatPeriodLabel, hasLockedReturn }) {
  return (
    <div className="dashboard-kpi-grid">
      <Link href="/tenant/invoices" className="card kpi-card card-hoverable">
        <div className="kpi-card-top">
          <span className="kpi-card-label">Total Invoices</span>
          <span className="kpi-card-icon">{ICONS.invoices}</span>
        </div>
        <span className="kpi-card-value">{invoiceCount}</span>
        <ViewArrow />
      </Link>

      <Link href="/tenant/purchases" className="card kpi-card card-hoverable">
        <div className="kpi-card-top">
          <span className="kpi-card-label">Purchase Bills</span>
          <span className="kpi-card-icon">{ICONS.purchases}</span>
        </div>
        <span className="kpi-card-value">{purchaseCount}</span>
        <ViewArrow />
      </Link>

      <Link href="/tenant/invoices?paymentStatus=PAID" className="card kpi-card card-hoverable">
        <div className="kpi-card-top">
          <span className="kpi-card-label">Total Revenue</span>
          <span className="kpi-card-icon">{ICONS.revenue}</span>
        </div>
        <span className="kpi-card-value">{formatCurrency(paidRevenue)}</span>
        <ViewArrow />
      </Link>

      <Link href="/tenant/vat-returns" className="card kpi-card card-hoverable">
        <div className="kpi-card-top">
          <span className="kpi-card-label">VAT Payable</span>
          <span className="kpi-card-icon">{ICONS.vat}</span>
        </div>
        <span className="kpi-card-value">{hasLockedReturn ? formatCurrency(vatPayable) : "—"}</span>
        <span className="helptext" style={{ marginTop: 0 }}>
          {hasLockedReturn ? vatPeriodLabel : "No locked return yet"}
        </span>
        <ViewArrow />
      </Link>
    </div>
  );
}
