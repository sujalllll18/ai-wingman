"use client";

import { useState } from "react";
import Button from "../ui/Button";

const EMOJI_SET = ["👍", "👎", "🙂", "🙁", "🎉", "🚀", "✅", "❌", "⚠️", "🔥", "👀", "🙏"];

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Renders @mentions as a highlighted chip - lightweight (no autocomplete
// directory of mentionable users, this module's first pass), just visual
// recognition of the @name pattern the way Slack/Linear render them.
function renderBody(body) {
  const parts = body.split(/(@[\w.]+)/g);
  return parts.map((part, i) =>
    part.startsWith("@") ? (
      <span key={i} className="badge badge-info" style={{ margin: "0 2px" }}>
        {part}
      </span>
    ) : (
      <span key={i}>{part}</span>
    )
  );
}

function AttachmentChip({ attachment }) {
  return (
    <a
      href={`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000"}${attachment.fileUrl}`}
      target="_blank"
      rel="noreferrer"
      className="badge badge-info"
      style={{ textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 4 }}
    >
      <svg viewBox="0 0 24 24" width="11" height="11" style={{ stroke: "currentColor", strokeWidth: 2, fill: "none" }}>
        <path d="M21 10.5 12.5 19a4 4 0 0 1-5.7-5.7L15 5a2.7 2.7 0 0 1 3.8 3.8L10.6 17" />
      </svg>
      {attachment.fileName}
    </a>
  );
}

// Chat-style conversation thread (2026-08-07, Support Center) - the first
// message-thread/reply-input UI in Ledger (confirmed via audit: nothing
// like it existed before). Reused for both the tenant's Conversation tab
// and the admin's Conversation/Internal Notes tabs - `comments` is
// pre-filtered by the caller (tenant callers never receive isInternal
// comments at all, server-side), `allowInternalNote` just toggles whether
// the compose box offers the internal-note switch.
export default function ConversationThread({ comments, currentUserType, onSubmitReply, allowInternalNote = false, busy, authorLabel = () => null, emptyLabel = "No messages yet." }) {
  const [body, setBody] = useState("");
  const [isInternal, setIsInternal] = useState(false);
  const [emojiOpen, setEmojiOpen] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!body.trim()) return;
    await onSubmitReply(body, isInternal);
    setBody("");
    setIsInternal(false);
  }

  return (
    <div className="conversation-thread">
      <div className="conversation-list">
        {(!comments || comments.length === 0) && <p className="helptext" style={{ margin: 0 }}>{emptyLabel}</p>}
        {comments?.map((c) => {
          const mine = c.authorType === currentUserType;
          return (
            <div key={c.id} className={`conversation-bubble-row${mine ? " mine" : ""}`}>
              <div className={`conversation-bubble${c.isInternal ? " internal" : ""}`}>
                <div className="conversation-bubble-meta">
                  <span style={{ fontWeight: 600 }}>{authorLabel(c.authorType, c.authorId) || (c.authorType === "TENANT_USER" ? "Customer" : "Support Team")}</span>
                  {c.isInternal && <span className="badge badge-premium">Internal Note</span>}
                  <span className="helptext" style={{ margin: 0 }}>{formatDateTime(c.createdAt)}</span>
                </div>
                <div className="conversation-bubble-body">{renderBody(c.body)}</div>
                {c.attachments?.length > 0 && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 6 }}>
                    {c.attachments.map((a) => (
                      <AttachmentChip key={a.id} attachment={a} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <form onSubmit={handleSubmit} className="conversation-compose">
        <textarea
          rows={3}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={isInternal ? "Add an internal note (customer won't see this)…" : "Type a reply…"}
        />
        <div className="conversation-compose-actions">
          <div style={{ display: "flex", alignItems: "center", gap: 8, position: "relative" }}>
            <button type="button" className="btn btn-outline btn-sm" onClick={() => setEmojiOpen((v) => !v)} aria-label="Insert emoji">
              🙂
            </button>
            {emojiOpen && (
              <div className="emoji-picker">
                {EMOJI_SET.map((e) => (
                  <button
                    type="button"
                    key={e}
                    onClick={() => {
                      setBody((b) => b + e);
                      setEmojiOpen(false);
                    }}
                  >
                    {e}
                  </button>
                ))}
              </div>
            )}
            {allowInternalNote && (
              <label className="checkbox-row" style={{ margin: 0 }}>
                <input type="checkbox" checked={isInternal} onChange={(e) => setIsInternal(e.target.checked)} />
                Internal note
              </label>
            )}
          </div>
          <Button type="submit" disabled={busy || !body.trim()}>
            {busy ? "Sending…" : isInternal ? "Add Note" : "Reply"}
          </Button>
        </div>
      </form>
    </div>
  );
}
