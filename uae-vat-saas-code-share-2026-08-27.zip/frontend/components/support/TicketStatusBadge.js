const CONFIG = {
  NEW: { label: "New", className: "badge-info" },
  ASSIGNED: { label: "Assigned", className: "badge-warning" },
  IN_PROGRESS: { label: "In Progress", className: "badge-premium" },
  WAITING_CUSTOMER: { label: "Waiting for Customer", className: "badge-warning" },
  RESOLVED: { label: "Resolved", className: "badge-success" },
  CLOSED: { label: "Closed", className: "badge-info" },
  REOPENED: { label: "Reopened", className: "badge-danger" },
};

export default function TicketStatusBadge({ status }) {
  const cfg = CONFIG[status] || CONFIG.NEW;
  return <span className={`badge ${cfg.className}`}>{cfg.label}</span>;
}
