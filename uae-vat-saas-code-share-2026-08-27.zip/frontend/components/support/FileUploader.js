"use client";

import { useRef, useState } from "react";

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Generic multi-file drag-drop uploader (2026-08-07, Support Center) - the
// first reusable one in Ledger (confirmed via audit: every existing upload
// - OcrUploadDropzone, PurchaseAttachmentsCard, BrandAssetCard - is
// bespoke and single-file). Reuses the exact same .ocr-dropzone CSS the
// Purchases OCR upload already established rather than inventing a
// parallel style, even though the class name is domain-named from its
// original module. A pure file picker - the parent owns the actual upload
// call, same division of responsibility as OcrUploadDropzone.
export default function FileUploader({ onFilesSelected, accept = "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt", multiple = true, label, helptext, maxSizeMb = 10 }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [files, setFiles] = useState([]);
  const [error, setError] = useState("");

  function addFiles(fileList) {
    const incoming = Array.from(fileList || []);
    const tooBig = incoming.find((f) => f.size > maxSizeMb * 1024 * 1024);
    if (tooBig) {
      setError(`"${tooBig.name}" is larger than ${maxSizeMb}MB.`);
      return;
    }
    setError("");
    const next = multiple ? [...files, ...incoming] : incoming.slice(0, 1);
    setFiles(next);
    onFilesSelected(next);
  }

  function removeFile(index) {
    const next = files.filter((_, i) => i !== index);
    setFiles(next);
    onFilesSelected(next);
  }

  return (
    <div>
      <div
        className={`ocr-dropzone${dragOver ? " ocr-dropzone-active" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          addFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
      >
        <svg viewBox="0 0 24 24" className="ocr-dropzone-icon" aria-hidden="true">
          <path d="M12 3.5v11M7 9l5-5.5L17 9" />
          <path d="M4 16.5v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
        </svg>
        <strong>{label || (multiple ? "Drop files here, or click to browse" : "Drop a file here, or click to browse")}</strong>
        <span className="helptext">{helptext || `Up to ${maxSizeMb}MB each`}</span>
        <input ref={inputRef} type="file" accept={accept} multiple={multiple} style={{ display: "none" }} onChange={(e) => addFiles(e.target.files)} />
      </div>
      {error && (
        <p className="field-error" role="alert" style={{ marginTop: 8 }}>
          {error}
        </p>
      )}
      {files.length > 0 && (
        <ul style={{ listStyle: "none", margin: "10px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 6 }}>
          {files.map((f, i) => (
            <li key={`${f.name}-${i}`} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 13, padding: "6px 10px", background: "var(--color-surface-sunken)", borderRadius: "var(--radius)" }}>
              <span>
                {f.name} <span className="helptext" style={{ margin: 0 }}>({formatFileSize(f.size)})</span>
              </span>
              <button type="button" className="btn btn-outline btn-sm" onClick={() => removeFile(i)} aria-label={`Remove ${f.name}`}>
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
