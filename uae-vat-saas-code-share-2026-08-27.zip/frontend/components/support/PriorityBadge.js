const CONFIG = {
  LOW: { label: "Low", className: "badge-info" },
  MEDIUM: { label: "Medium", className: "badge-warning" },
  HIGH: { label: "High", className: "badge-danger" },
  CRITICAL: { label: "Critical", className: "badge-danger" },
};

// Support Center (2026-08-07) - first real 4-level Priority badge in
// Ledger. The only precedent (Approvals list) was a 2-tone HIGH/other
// inline badge, never extracted as a component - this is a genuinely new
// component, not a duplicate. Same `.badge` CSS family as
// StatusStamp/PlanTag/PlanStatusBadge.
export default function PriorityBadge({ priority }) {
  const cfg = CONFIG[priority] || CONFIG.MEDIUM;
  return (
    <span className={`badge ${cfg.className}`} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
      {priority === "CRITICAL" && (
        <svg viewBox="0 0 24 24" width="10" height="10" style={{ stroke: "currentColor", strokeWidth: 2.5, fill: "none" }}>
          <path d="M12 3.5 22 20.5H2z" />
          <path d="M12 10v4.5M12 17.5v.01" />
        </svg>
      )}
      {cfg.label}
    </span>
  );
}
