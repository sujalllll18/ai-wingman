const TYPE_LABEL = {
  CREATED: "Ticket Created",
  ASSIGNED: "Assigned",
  TRANSFERRED: "Transferred",
  PRIORITY_CHANGED: "Priority Changed",
  STATUS_CHANGED: "Status Changed",
  SCREENSHOT_UPLOADED: "Screenshot Uploaded",
  ATTACHMENT_UPLOADED: "Attachment Uploaded",
  REPLY_ADDED: "Reply Added",
  INTERNAL_NOTE_ADDED: "Internal Note Added",
  WATCHER_ADDED: "Watcher Added",
  MERGED: "Merged",
  LINKED: "Linked",
  RESOLVED: "Resolved",
  CLOSED: "Closed",
  REOPENED: "Reopened",
  SLA_BREACHED: "SLA Breached",
};

const ACTOR_LABEL = { TENANT_USER: "Customer", PLATFORM_ADMIN: "Support Team", SYSTEM: "System" };

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Same prop shape/rendering pattern as invoices/ActivityTimeline.js
// (dot-marker + label + optional description + timestamp) - reused here
// rather than building a parallel timeline component, per the audit
// finding that this exact pattern is already the Ledger convention.
export default function TicketActivityTimeline({ activities }) {
  if (!activities || activities.length === 0) {
    return <p className="helptext" style={{ margin: 0 }}>No activity yet.</p>;
  }

  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
      {activities.map((a) => (
        <li key={a.id} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span aria-hidden="true" style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--color-accent)", marginTop: 6, flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 13 }}>
              {TYPE_LABEL[a.type] || a.type}
              {a.actorType && <span className="helptext" style={{ margin: 0, marginLeft: 6 }}>by {ACTOR_LABEL[a.actorType] || a.actorType}</span>}
            </div>
            {a.description && <div className="helptext" style={{ margin: "2px 0 0" }}>{a.description}</div>}
            <div className="helptext" style={{ margin: "2px 0 0", fontSize: 11 }}>{formatDateTime(a.createdAt)}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}
