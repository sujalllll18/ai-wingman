import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

function buildTaxBreakdown(lineItems) {
  const groups = new Map();
  for (const li of lineItems) {
    const key = `${li.taxRateName || "No tax"}|${li.taxPercentage}`;
    const existing = groups.get(key) || { name: li.taxRateName || "No tax", percentage: li.taxPercentage, taxableAmount: 0, taxAmount: 0 };
    existing.taxableAmount += li.lineTaxableAmount;
    existing.taxAmount += li.lineTaxAmount;
    groups.set(key, existing);
  }
  return Array.from(groups.values());
}

// Byte-for-byte structural mirror of credit-note-templates/ClassicTemplate.js
// (2026-08-11) - "TAX DEBIT NOTE" title, "Total Debit" instead of "Total
// Credit", otherwise identical (same businessAssets pattern, same
// lineNetAmount reconciliation fix, same tax breakdown). Reads only the
// note's own frozen snapshot fields, never re-derives from a live Invoice/
// Customer/Tax Master lookup.
const SalesDebitNoteClassicTemplate = forwardRef(function SalesDebitNoteClassicTemplate({ salesDebitNote, businessAssets = {} }, ref) {
  const taxBreakdown = buildTaxBreakdown(salesDebitNote.lineItems || []);
  const watermark = salesDebitNote.status === "VOID" ? "CANCELLED" : salesDebitNote.status === "DRAFT" ? "DRAFT" : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden={!businessAssets.logoUrl}>
            {businessAssets.logoUrl && <img src={businessAssets.logoUrl} alt="Company logo" />}
          </div>
          <div className="invoice-doc-business">
            <strong>{salesDebitNote.businessName}</strong>
            {salesDebitNote.businessTrn && <span>TRN: {salesDebitNote.businessTrn}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>TAX DEBIT NOTE</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Debit Note #</td>
                <td className="mono">{salesDebitNote.salesDebitNoteNumberDisplay || "DRAFT"}</td>
              </tr>
              <tr>
                <td>Original Invoice #</td>
                <td className="mono">{salesDebitNote.invoice?.invoiceNumberDisplay}</td>
              </tr>
              <tr>
                <td>Issue Date</td>
                <td>{formatDate(salesDebitNote.issueDate)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="invoice-doc-parties">
        <div>
          <span className="invoice-doc-label">Customer</span>
          <strong>{salesDebitNote.customerName}</strong>
          {salesDebitNote.customerAddress && <span>{salesDebitNote.customerAddress}</span>}
          {salesDebitNote.customerTrn && <span>TRN: {salesDebitNote.customerTrn}</span>}
        </div>
        <div>
          <span className="invoice-doc-label">Reason</span>
          <span>{salesDebitNote.reason}</span>
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Description</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(salesDebitNote.lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, salesDebitNote.currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              <td className="num">{formatCurrency(li.lineNetAmount, salesDebitNote.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        {taxBreakdown.length > 0 && (
          <table className="invoice-doc-tax-breakdown">
            <thead>
              <tr>
                <th>Tax Breakdown</th>
                <th className="num">Taxable Amount</th>
                <th className="num">Tax</th>
              </tr>
            </thead>
            <tbody>
              {taxBreakdown.map((g) => (
                <tr key={g.name}>
                  <td>
                    {g.name} ({g.percentage}%)
                  </td>
                  <td className="num">{formatCurrency(g.taxableAmount, salesDebitNote.currency)}</td>
                  <td className="num">{formatCurrency(g.taxAmount, salesDebitNote.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Subtotal</td>
              <td className="num">{formatCurrency(salesDebitNote.subtotal, salesDebitNote.currency)}</td>
            </tr>
            <tr>
              <td>VAT</td>
              <td className="num">{formatCurrency(salesDebitNote.vatTotal, salesDebitNote.currency)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>Total Debit</td>
              <td className="num">{formatCurrency(salesDebitNote.grandTotal, salesDebitNote.currency)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {salesDebitNote.notes && (
        <div className="invoice-doc-notes">
          <span className="invoice-doc-label">Notes</span>
          <p>{salesDebitNote.notes}</p>
        </div>
      )}

      {(businessAssets.signatureUrl || businessAssets.stampUrl) && (
        <div className="invoice-doc-signoff">
          {businessAssets.signatureUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.signatureUrl} alt="Authorized signature" />
              <span>Authorized Signatory</span>
            </div>
          )}
          {businessAssets.stampUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.stampUrl} alt="Company stamp" />
              <span>Company Stamp</span>
            </div>
          )}
        </div>
      )}

      <div className="invoice-doc-footer">
        <span>This is a computer-generated debit note.</span>
      </div>
    </div>
  );
});

export default SalesDebitNoteClassicTemplate;
