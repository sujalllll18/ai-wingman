import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import TableScroll from "../ui/TableScroll";
import MaterialSelector from "./MaterialSelector";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

// Editable line-item grid for the Invoice Create/Edit page. `lines` holds the
// editable fields; `computedLines` (same length/order) holds the live
// calc-engine output (docs/features/17-invoice-generation.md §7) for display
// only - never edited directly.
export default function LineItemsTable({ lines, computedLines, materials, taxCategories, onChangeLine, onAddLine, onRemoveLine, disabled }) {
  function handleMaterialSelect(index, materialId) {
    if (!materialId) {
      onChangeLine(index, { materialId: "" });
      return;
    }
    const material = materials.find((m) => m.id === materialId);
    if (!material) return;
    onChangeLine(index, {
      materialId,
      description: material.name,
      unit: material.unit,
      unitPrice: String(material.defaultUnitPrice),
      taxCategoryId: material.defaultTaxCategoryId || "",
    });
  }

  return (
    <div>
      <TableScroll>
      <table className="data-table">
        <thead>
          <tr>
            <th>Material</th>
            <th>Description</th>
            <th>Unit</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th>Tax Category</th>
            <th className="num">Line Total</th>
            {!disabled && <th></th>}
          </tr>
        </thead>
        <tbody>
          {lines.map((line, index) => (
            <tr key={line.key}>
              <td style={{ minWidth: 160 }}>
                {disabled ? (
                  <span className="helptext">{line.materialId ? "Linked" : "Manual"}</span>
                ) : (
                  <MaterialSelector materials={materials} value={line.materialId} onChange={(id) => handleMaterialSelect(index, id)} />
                )}
              </td>
              <td style={{ minWidth: 180 }}>
                <Input
                  className="inline-input"
                  value={line.description}
                  onChange={(e) => onChangeLine(index, { description: e.target.value })}
                  placeholder="Line description"
                  disabled={disabled}
                />
              </td>
              <td style={{ minWidth: 100 }}>
                <Input className="inline-input" value={line.unit} onChange={(e) => onChangeLine(index, { unit: e.target.value })} placeholder="e.g. Piece" disabled={disabled} />
              </td>
              <td className="num" style={{ minWidth: 90 }}>
                <Input
                  className="inline-input"
                  type="number"
                  min="0"
                  step="0.01"
                  value={line.quantity}
                  onChange={(e) => onChangeLine(index, { quantity: e.target.value })}
                  disabled={disabled}
                />
              </td>
              <td className="num" style={{ minWidth: 110 }}>
                <Input
                  className="inline-input"
                  type="number"
                  min="0"
                  step="0.01"
                  value={line.unitPrice}
                  onChange={(e) => onChangeLine(index, { unitPrice: e.target.value })}
                  disabled={disabled}
                />
              </td>
              <td style={{ minWidth: 160 }}>
                {disabled ? (
                  <span>
                    {computedLines[index]?.taxRateName ? `${computedLines[index].taxRateName} (${computedLines[index].taxPercentage}%)` : "No tax"}
                  </span>
                ) : (
                  <Select className="inline-input" value={line.taxCategoryId || ""} onChange={(e) => onChangeLine(index, { taxCategoryId: e.target.value })}>
                    <option value="">No tax</option>
                    {taxCategories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.taxRate ? `(${c.taxRate.percentage}%)` : ""}
                      </option>
                    ))}
                  </Select>
                )}
              </td>
              <td className="num mono">{formatCurrency(computedLines[index]?.lineTotal)}</td>
              {!disabled && (
                <td>
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => onRemoveLine(index)}>
                    Remove
                  </button>
                </td>
              )}
            </tr>
          ))}
          {lines.length === 0 && (
            <tr>
              <td colSpan={disabled ? 7 : 8} style={{ textAlign: "center", padding: 20, color: "var(--color-ink-faint)" }}>
                No line items yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      </TableScroll>
      {!disabled && (
        <div style={{ marginTop: 12 }}>
          <Button type="button" variant="outline" onClick={onAddLine}>
            + Add Line
          </Button>
        </div>
      )}
    </div>
  );
}
