import Card from "../ui/Card";
import Tooltip from "../ui/Tooltip";

const ATTACHMENT_TYPES = ["Purchase Order", "Delivery Note", "Supporting Document"];

// Placeholder UI only, per Sprint 3 scope - backend upload/storage is future
// work. No files are actually attachable yet; this reserves the layout and
// interaction shape so a real upload can slot in later without a redesign.
export default function AttachmentsPlaceholder() {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Attachments</h3>
      <p className="helptext" style={{ marginTop: 0 }}>No attachments yet.</p>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {ATTACHMENT_TYPES.map((label) => (
          <Tooltip key={label} label="Attachment upload is planned for a future sprint">
            <button type="button" className="btn btn-outline btn-sm" disabled>
              + {label}
            </button>
          </Tooltip>
        ))}
      </div>
    </Card>
  );
}
