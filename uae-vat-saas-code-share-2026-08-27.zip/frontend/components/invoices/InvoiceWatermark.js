const COLOR_BY_LABEL = {
  DRAFT: "#9ca3af",
  CANCELLED: "#dc2626",
  PAID: "#15803d",
  "BAD DEBT": "#dc2626",
};

// Diagonal overlay for the invoice document - Draft/Cancelled/Paid, per
// Sprint 2. Purely visual, computed from invoice.status/paymentStatus by the
// caller (ClassicTemplate) - never stored as its own field.
export default function InvoiceWatermark({ label }) {
  return (
    <div className="invoice-doc-watermark" style={{ color: COLOR_BY_LABEL[label] || "#9ca3af" }} aria-hidden="true">
      {label}
    </div>
  );
}
