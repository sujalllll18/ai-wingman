"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const PAYMENT_METHODS = [
  { value: "CASH", label: "Cash" },
  { value: "BANK_TRANSFER", label: "Bank Transfer" },
  { value: "CARD", label: "Card" },
  { value: "CHEQUE", label: "Cheque" },
  { value: "OTHER", label: "Other" },
];

function todayInputValue() {
  return new Date().toISOString().slice(0, 10);
}

// Records one payment against a Sent invoice. amountPaid/outstandingAmount/
// paymentStatus are recalculated server-side from the full set of payments -
// this form only ever submits the new payment, never a status directly.
export default function PaymentFormModal({ open, onClose, invoice, onSuccess }) {
  const [amount, setAmount] = useState("");
  const [paymentDate, setPaymentDate] = useState(todayInputValue());
  const [method, setMethod] = useState("BANK_TRANSFER");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function resetAndClose() {
    setAmount("");
    setPaymentDate(todayInputValue());
    setMethod("BANK_TRANSFER");
    setReference("");
    setNotes("");
    setError("");
    onClose();
  }

  const outstanding = invoice ? invoice.outstandingAmount : 0;

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    if (!amount || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
      setError("Enter a valid payment amount greater than zero.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const { invoice: updated } = await api.recordInvoicePayment(token, invoice.id, {
        amount: Number(amount),
        paymentDate,
        method,
        reference: reference || null,
        notes: notes || null,
      });
      onSuccess(updated);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} ariaLabel="Record Payment">
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 4 }}>Record Payment</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>
          Outstanding balance: {invoice?.currency || "AED"} {Number(outstanding || 0).toFixed(2)}
        </p>

        <ErrorBanner message={error} />

        <div className="form-grid">
          <Field id="payment-amount" label={<>Amount<span className="required-asterisk">*</span></>}>
            <Input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field id="payment-date" label={<>Payment Date<span className="required-asterisk">*</span></>}>
            <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
          </Field>
        </div>

        <Field id="payment-method" label="Payment Method">
          <Select value={method} onChange={(e) => setMethod(e.target.value)}>
            {PAYMENT_METHODS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </Select>
        </Field>

        <Field id="payment-reference" label="Reference">
          <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Transaction / cheque number" />
        </Field>

        <Field id="payment-notes" label="Notes" style={{ marginBottom: 0 }}>
          <textarea className="inline-input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : "Record Payment"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
