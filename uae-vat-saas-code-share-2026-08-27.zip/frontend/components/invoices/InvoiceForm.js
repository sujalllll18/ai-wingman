"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { calculateInvoiceTotals } from "../../lib/invoiceCalc";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import LineItemsTable from "./LineItemsTable";
import InvoiceSummarySidebar from "./InvoiceSummarySidebar";

function newLineKey() {
  return `line-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function toDateInputValue(iso) {
  if (!iso) return "";
  return new Date(iso).toISOString().slice(0, 10);
}

function linesFromInvoice(invoice) {
  if (!invoice?.lineItems?.length) return [];
  return invoice.lineItems.map((li) => ({
    key: newLineKey(),
    lineId: li.id,
    materialId: li.materialId || "",
    description: li.description,
    unit: li.unit,
    quantity: String(li.quantity),
    unitPrice: String(li.unitPrice),
    taxCategoryId: li.taxCategoryId || "",
  }));
}

// Shared editor for both Create (full page) and Edit-while-Draft (full
// page). Full page, not a modal - a deliberate departure from the Customer/
// Onboarding modal-wizard pattern, per the approved design (room for a
// line-item table + sticky totals sidebar). See docs/features/17.
export default function InvoiceForm({ mode, initialInvoice, onSaved }) {
  const router = useRouter();
  const isEdit = mode === "edit";

  const [customers, setCustomers] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [taxCategories, setTaxCategories] = useState([]);
  const [loadError, setLoadError] = useState("");

  const [customerId, setCustomerId] = useState(initialInvoice?.customerId || "");
  const [customerName, setCustomerName] = useState(initialInvoice?.customerName || "");
  const [customerAddress, setCustomerAddress] = useState(initialInvoice?.customerAddress || "");
  const [customerTrn, setCustomerTrn] = useState(initialInvoice?.customerTrn || "");
  const [dueDate, setDueDate] = useState(toDateInputValue(initialInvoice?.dueDate));
  const [discountType, setDiscountType] = useState(initialInvoice?.discountType || null);
  const [discountValue, setDiscountValue] = useState(initialInvoice?.discountValue != null ? String(initialInvoice.discountValue) : "0");
  const [notes, setNotes] = useState(initialInvoice?.notes || "");

  const [lines, setLines] = useState(() => linesFromInvoice(initialInvoice));
  const [deletedLineIds, setDeletedLineIds] = useState([]);

  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const [{ customers }, { materials }, { categories }] = await Promise.all([
          api.listCustomers(token),
          api.listMaterials(token),
          api.listTaxCategories(token),
        ]);
        setCustomers(customers);
        setMaterials(materials);
        setTaxCategories(categories.filter((c) => c.status === "ACTIVE"));
      } catch (err) {
        setLoadError(err.message);
      }
    })();
  }, []);

  function categoryFor(id) {
    return taxCategories.find((c) => c.id === id);
  }

  const totals = useMemo(() => {
    const calcLines = lines.map((l) => {
      const cat = categoryFor(l.taxCategoryId);
      return {
        quantity: l.quantity,
        unitPrice: l.unitPrice,
        taxPercentage: cat?.taxRate?.percentage || 0,
        taxCalculationMethod: cat?.taxRate?.calculationMethod || "EXCLUSIVE",
      };
    });
    return calculateInvoiceTotals(calcLines, { discountType, discountValue });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines, discountType, discountValue, taxCategories]);

  function handleCustomerSelect(id) {
    setCustomerId(id);
    if (!id) return;
    const customer = customers.find((c) => c.id === id);
    if (!customer) return;
    setCustomerName(customer.name);
    setCustomerAddress(customer.address || "");
    setCustomerTrn(customer.trn || "");
  }

  function handleChangeLine(index, patch) {
    setLines((prev) => prev.map((l, i) => (i === index ? { ...l, ...patch } : l)));
  }

  function handleAddLine() {
    setLines((prev) => [...prev, { key: newLineKey(), lineId: null, materialId: "", description: "", unit: "", quantity: "1", unitPrice: "0", taxCategoryId: "" }]);
  }

  function handleRemoveLine(index) {
    setLines((prev) => {
      const removed = prev[index];
      if (removed?.lineId) setDeletedLineIds((ids) => [...ids, removed.lineId]);
      return prev.filter((_, i) => i !== index);
    });
  }

  function linePayload(l) {
    return {
      materialId: l.materialId || null,
      description: l.description.trim(),
      unit: l.unit.trim(),
      quantity: Number(l.quantity),
      unitPrice: Number(l.unitPrice),
      taxCategoryId: l.taxCategoryId || null,
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (saving) return;

    if (!customerName.trim()) {
      setError("Customer name is required — select a Customer or enter one manually.");
      return;
    }
    if (lines.length === 0) {
      setError("Add at least one line item.");
      return;
    }
    for (const l of lines) {
      if (!l.description.trim() || !l.unit.trim() || !l.quantity || Number(l.quantity) <= 0) {
        setError("Every line item needs a description, unit, and a positive quantity.");
        return;
      }
    }

    setError("");
    setSaving(true);
    try {
      const token = tenantAuth.get();
      const header = {
        customerId: customerId || null,
        customerName: customerName.trim(),
        customerAddress: customerAddress || null,
        customerTrn: customerTrn || null,
        dueDate: dueDate || null,
        discountType: discountType || null,
        discountValue: Number(discountValue || 0),
        notes: notes || null,
      };

      let invoiceId = initialInvoice?.id;
      if (isEdit) {
        await api.updateInvoice(token, invoiceId, header);
        for (const id of deletedLineIds) {
          await api.deleteInvoiceLineItem(token, invoiceId, id);
        }
        for (const l of lines) {
          if (l.lineId) {
            await api.updateInvoiceLineItem(token, invoiceId, l.lineId, linePayload(l));
          } else {
            await api.addInvoiceLineItem(token, invoiceId, linePayload(l));
          }
        }
        const { invoice } = await api.getInvoice(token, invoiceId);
        onSaved(invoice);
      } else {
        const { invoice } = await api.createInvoice(token, { ...header, lineItems: lines.map(linePayload) });
        onSaved(invoice);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <ErrorBanner message={error || loadError} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Customer</h3>
            <Field id="invoice-customer" label="Select an existing Customer (optional)">
              <Select value={customerId} onChange={(e) => handleCustomerSelect(e.target.value)}>
                <option value="">— Manual entry —</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </Field>
            <div className="form-grid">
              <Field id="invoice-customer-name" label={<>Customer Name<span className="required-asterisk">*</span></>}>
                <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
              </Field>
              <Field id="invoice-customer-trn" label="Customer TRN">
                <Input value={customerTrn} onChange={(e) => setCustomerTrn(e.target.value)} />
              </Field>
            </div>
            <Field id="invoice-customer-address" label="Customer Address" style={{ marginBottom: 0 }}>
              <Input value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)} />
            </Field>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <LineItemsTable
              lines={lines}
              computedLines={totals.lines}
              materials={materials}
              taxCategories={taxCategories}
              onChangeLine={handleChangeLine}
              onAddLine={handleAddLine}
              onRemoveLine={handleRemoveLine}
            />
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Details</h3>
            <div className="form-grid">
              <Field id="invoice-due-date" label="Due Date">
                <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </Field>
            </div>
            <Field id="invoice-notes" label="Notes" style={{ marginBottom: 0 }}>
              <textarea
                className="inline-input"
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Payment terms, delivery notes, or anything else the customer should see."
              />
            </Field>
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <InvoiceSummarySidebar
            totals={totals}
            discountType={discountType}
            discountValue={discountValue}
            onDiscountTypeChange={setDiscountType}
            onDiscountValueChange={setDiscountValue}
          />
          <div style={{ display: "flex", gap: 8 }}>
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={saving}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : isEdit ? "Save Changes" : "Save Draft"}
            </Button>
          </div>
        </div>
      </div>
    </form>
  );
}
