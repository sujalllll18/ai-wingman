"use client";

import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import Tooltip from "../ui/Tooltip";
import PlaceholderNotice from "../ui/PlaceholderNotice";

// Advanced filter panel for the Invoices list (2026-08-06 redesign) - a thin
// wrapper around the existing Drawer.js, same header/body/actions structure
// TrnChangeDrawer.js already uses. Every control here reads/writes state
// that already lives on the Invoices page (no new API calls, no new
// business logic) except Due Date, which is a pure client-side filter over
// `dueDate` - a field every invoice already carries in the list response,
// filtered the same way Issue Date already is. Invoice Type/Created By/
// Amount Range/Currency/Tags have no corresponding field anywhere in the
// Invoice schema or API response, so they stay honest, disabled
// placeholders (same "not available yet" convention used throughout Ledger)
// instead of faking a filter that can't actually filter anything.
export default function MoreFiltersDrawer({
  open,
  onClose,
  paymentStatusFilter,
  onPaymentStatusChange,
  dueDateFrom,
  onDueDateFromChange,
  dueDateTo,
  onDueDateToChange,
  archivedView,
  onToggleArchived,
  draftOnly,
  onToggleDraftOnly,
  onClearAll,
}) {
  return (
    <Drawer open={open} onClose={onClose} ariaLabel="More Filters">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>More Filters</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Refine the invoice list beyond the toolbar's quick filters.
        </p>
      </div>

      <div className="drawer-body">
        <Field id="filter-payment-status" label="Payment Status">
          <Select value={paymentStatusFilter} onChange={(e) => onPaymentStatusChange(e.target.value)}>
            <option value="ALL">All payment statuses</option>
            <option value="UNPAID">Unpaid</option>
            <option value="PARTIALLY_PAID">Partially Paid</option>
            <option value="PAID">Paid</option>
            <option value="BAD_DEBT">Bad Debt</option>
          </Select>
        </Field>

        <div className="form-grid">
          <Field id="filter-due-from" label="Due Date From">
            <Input type="date" value={dueDateFrom} onChange={(e) => onDueDateFromChange(e.target.value)} />
          </Field>
          <Field id="filter-due-to" label="Due Date To">
            <Input type="date" value={dueDateTo} onChange={(e) => onDueDateToChange(e.target.value)} />
          </Field>
        </div>

        <label className="checkbox-row">
          <input type="checkbox" checked={draftOnly} onChange={(e) => onToggleDraftOnly(e.target.checked)} />
          Draft only
        </label>
        <label className="checkbox-row">
          <input type="checkbox" checked={archivedView} onChange={(e) => onToggleArchived(e.target.checked)} />
          Show archived invoices
        </label>

        <PlaceholderNotice>
          Invoice Type, Created By, Amount Range, Currency, and Tags aren&rsquo;t tracked on invoices yet — these
          filters are ready for that data once it exists.
        </PlaceholderNotice>

        <div style={{ opacity: 0.55, pointerEvents: "none" }} aria-disabled="true">
          <div className="form-grid">
            <Field id="filter-invoice-type" label="Invoice Type">
              <Select disabled>
                <option>All types</option>
              </Select>
            </Field>
            <Field id="filter-created-by" label="Created By">
              <Select disabled>
                <option>Anyone</option>
              </Select>
            </Field>
          </div>
          <div className="form-grid">
            <Field id="filter-amount-min" label="Amount Min">
              <Input type="number" disabled placeholder="0" />
            </Field>
            <Field id="filter-amount-max" label="Amount Max">
              <Input type="number" disabled placeholder="Any" />
            </Field>
          </div>
          <div className="form-grid">
            <Field id="filter-currency" label="Currency">
              <Select disabled>
                <option>AED</option>
              </Select>
            </Field>
            <Field id="filter-tags" label="Tags">
              <Input disabled placeholder="Not tracked yet" />
            </Field>
          </div>
        </div>
      </div>

      <div className="drawer-actions">
        <Button variant="outline" onClick={onClearAll}>
          Clear Filters
        </Button>
        <Tooltip label="Applies as you change each field above">
          <Button onClick={onClose}>Done</Button>
        </Tooltip>
      </div>
    </Drawer>
  );
}
