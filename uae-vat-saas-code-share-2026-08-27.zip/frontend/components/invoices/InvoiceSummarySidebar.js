import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

// Sticky totals panel for the Invoice Create/Edit page - subtotal/discount/
// VAT/grand total, live-recalculated client-side via lib/invoiceCalc.js for
// instant feedback (docs/features/17-invoice-generation.md §9). The server
// recalculates authoritatively on save regardless.
export default function InvoiceSummarySidebar({ totals, discountType, discountValue, onDiscountTypeChange, onDiscountValueChange, disabled }) {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Summary</h3>

      <Field id="discount-type" label="Discount">
        <Select value={discountType || ""} onChange={(e) => onDiscountTypeChange(e.target.value || null)} disabled={disabled}>
          <option value="">No discount</option>
          <option value="PERCENTAGE">Percentage (%)</option>
          <option value="FIXED">Fixed amount (AED)</option>
        </Select>
      </Field>

      {discountType && (
        <Field id="discount-value" label={discountType === "PERCENTAGE" ? "Discount %" : "Discount Amount (AED)"} style={{ marginBottom: 16 }}>
          <Input
            type="number"
            min="0"
            step="0.01"
            value={discountValue}
            onChange={(e) => onDiscountValueChange(e.target.value)}
            disabled={disabled}
          />
        </Field>
      )}

      <div className="summary-rows" style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="helptext">Subtotal</span>
          <span className="mono">{formatCurrency(totals.subtotal)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="helptext">Discount</span>
          <span className="mono">-{formatCurrency(totals.discountTotal)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="helptext">VAT</span>
          <span className="mono">{formatCurrency(totals.vatTotal)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid var(--color-line)", paddingTop: 8, fontWeight: 600 }}>
          <span>Grand Total</span>
          <span className="mono">{formatCurrency(totals.grandTotal)}</span>
        </div>
      </div>
    </Card>
  );
}
