"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Card from "../ui/Card";
import Button from "../ui/Button";

// Operational notes only - never printed on the invoice (see ClassicTemplate,
// which reads `notes`, not `internalNotes`). Editable regardless of invoice
// status, unlike everything else on a Sent invoice.
export default function InternalNotesCard({ invoice, onSaved, showToast }) {
  const [value, setValue] = useState(invoice.internalNotes || "");
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      const token = tenantAuth.get();
      const { invoice: updated } = await api.updateInvoiceInternalNotes(token, invoice.id, value);
      onSaved(updated);
      showToast("Internal notes saved.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Internal Notes</h3>
      <p className="helptext" style={{ marginTop: 0 }}>Visible to your team only - never shown on the invoice document.</p>
      <textarea
        className="inline-input"
        rows={3}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="e.g. Customer requested extended terms, follow up next week…"
      />
      <div style={{ marginTop: 10 }}>
        <Button variant="outline" onClick={handleSave} disabled={saving || value === (invoice.internalNotes || "")}>
          {saving ? "Saving…" : "Save Notes"}
        </Button>
      </div>
    </Card>
  );
}
