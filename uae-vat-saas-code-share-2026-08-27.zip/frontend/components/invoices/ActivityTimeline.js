const TYPE_LABEL = {
  CREATED: "Invoice Created",
  EDITED: "Edited",
  SENT: "Sent",
  PAYMENT_RECORDED: "Payment Recorded",
  CANCELLED: "Cancelled",
  BAD_DEBT: "Marked Bad Debt",
  DOWNLOADED: "Downloaded",
  PREVIEWED: "Previewed",
  ARCHIVED: "Archived",
  RESTORED: "Restored",
};

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Newest first - the backend already orders activities that way (§ getInvoice).
export default function ActivityTimeline({ activities }) {
  if (!activities || activities.length === 0) {
    return <p className="helptext" style={{ margin: 0 }}>No activity yet.</p>;
  }

  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
      {activities.map((a) => (
        <li key={a.id} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span
            aria-hidden="true"
            style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--color-accent)", marginTop: 6, flexShrink: 0 }}
          />
          <div>
            <div style={{ fontWeight: 600, fontSize: 13 }}>{TYPE_LABEL[a.type] || a.type}</div>
            {a.description && <div className="helptext" style={{ margin: "2px 0 0" }}>{a.description}</div>}
            <div className="helptext" style={{ margin: "2px 0 0", fontSize: 11 }}>{formatDateTime(a.createdAt)}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}
