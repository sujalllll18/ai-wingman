// Renders the 3-axis status model (docs/features/17-invoice-generation.md §5).
// Sprint 3 added a 4th paymentStatus value (BAD_DEBT) and a user-facing
// "Cancelled" label for the existing VOID status - the underlying `status`
// string is still just DRAFT|SENT|VOID, unchanged since Sprint 1.
//
// 2026-08-06 (Invoices list redesign): split into two standalone chips
// (DocumentStatusChip, PaymentStatusChip) instead of one combined cluster,
// so the list table can give Status and Payment Status their own columns -
// same underlying maps/isOverdue(), no data or business-rule change.
// InvoiceStatusBadge itself is kept (still used by the detail page) and now
// just composes the two chips exactly as before.
export function isOverdue(invoice) {
  if (invoice.status !== "SENT" || invoice.paymentStatus === "PAID" || invoice.paymentStatus === "BAD_DEBT" || !invoice.dueDate) return false;
  return new Date(invoice.dueDate).getTime() < Date.now();
}

const STATUS_BADGE = {
  DRAFT: { label: "Draft", className: "badge-info" },
  SENT: { label: "Sent", className: "badge-success" },
  VOID: { label: "Cancelled", className: "badge-danger" },
};

const PAYMENT_BADGE = {
  UNPAID: { label: "Unpaid", className: "badge-danger" },
  PARTIALLY_PAID: { label: "Partially Paid", className: "badge-premium" },
  PAID: { label: "Paid", className: "badge-success" },
  BAD_DEBT: { label: "Bad Debt", className: "badge-danger" },
};

export function DocumentStatusChip({ invoice }) {
  const status = STATUS_BADGE[invoice.status] || STATUS_BADGE.DRAFT;
  return <span className={`badge ${status.className}`}>{status.label}</span>;
}

// Only meaningful once a document has been Sent (matches the existing rule
// that hid the payment badge for Draft/Void) - shows "Overdue" in place of
// "Unpaid" when isOverdue() is true, same computed flag as before, just
// folded into one chip instead of a separate third badge.
export function PaymentStatusChip({ invoice }) {
  if (invoice.status !== "SENT") return <span style={{ color: "var(--color-ink-faint)" }}>—</span>;
  const overdue = isOverdue(invoice);
  const payment = overdue ? { label: "Overdue", className: "badge-danger" } : PAYMENT_BADGE[invoice.paymentStatus] || PAYMENT_BADGE.UNPAID;
  return <span className={`badge ${payment.className}`}>{payment.label}</span>;
}

export default function InvoiceStatusBadge({ invoice }) {
  return (
    <span style={{ display: "inline-flex", gap: 6, flexWrap: "wrap" }}>
      <DocumentStatusChip invoice={invoice} />
      {invoice.status === "SENT" && <PaymentStatusChip invoice={invoice} />}
    </span>
  );
}
