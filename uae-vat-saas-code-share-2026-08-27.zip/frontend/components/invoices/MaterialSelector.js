import Select from "../ui/Select";

// Searchable-by-scanning picker sourced from Material Master, reused across
// every line-item row. Selecting a Material is a one-time autofill
// convenience (docs/features/17-invoice-generation.md §4) - the parent copies
// its fields onto the line, then this selector's job is done; the line
// itself never keeps a live dependency on the Material record.
export default function MaterialSelector({ materials, value, onChange }) {
  return (
    <Select className="inline-input" value={value || ""} onChange={(e) => onChange(e.target.value)}>
      <option value="">— Manual entry —</option>
      {materials.map((m) => (
        <option key={m.id} value={m.id}>
          {m.name} ({m.unit})
        </option>
      ))}
    </Select>
  );
}
