"use client";

import { useRouter } from "next/navigation";
import { usePermissions } from "../../hooks/usePermissions";

// Persistent banner shown for the duration of a "Preview as this Role"
// session (RBAC module, 2026-08-06). Renders nothing when not previewing.
// Sits above the page content inside .shell-main (see TenantShell in
// app/tenant/layout.js) so it stays visible - sticky, not fixed - while the
// user navigates the real app with a simulated permission set: sidebar
// items, buttons, and route guards all hide/show exactly as they would for
// a real holder of that role, because they all read from the same
// usePermissions() this banner also reads from.
export default function RolePreviewBanner() {
  const { isPreviewing, previewLabel, exitPreview } = usePermissions();
  const router = useRouter();

  if (!isPreviewing) return null;

  function handleExit() {
    exitPreview();
    router.push("/tenant/settings/roles");
  }

  return (
    <div className="role-preview-banner" role="status">
      <span>
        Previewing as: <strong>{previewLabel}</strong> - menus, buttons and pages are shown exactly as this role would see them.
      </span>
      <button type="button" className="btn btn-outline" onClick={handleExit}>
        Exit Preview
      </button>
    </div>
  );
}
