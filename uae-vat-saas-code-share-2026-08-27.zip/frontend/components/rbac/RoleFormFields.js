"use client";

import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Tooltip from "../ui/Tooltip";

// Shared Name/Short Code/Description/Clone/Status/Require Approval fields -
// used by Create Role; Role Details reuses the same shape for its editable
// Overview section. `showClone` is only true at create time (cloning an
// already-saved role doesn't make sense as an ongoing edit action).
export default function RoleFormFields({ form, onChange, cloneableRoles, showClone, disabled }) {
  function set(patch) {
    onChange({ ...form, ...patch });
  }

  return (
    <div>
      <div className="form-grid">
        <Field id="role-name" label="Role Name">
          <Input value={form.name} onChange={(e) => set({ name: e.target.value })} disabled={disabled} />
        </Field>
        <Field id="role-code" label="Short Code" helptext="Unique within this business, e.g. FIN_MGR">
          <Input value={form.code} onChange={(e) => set({ code: e.target.value })} disabled={disabled || form.isSystem} />
        </Field>
      </div>

      <Field id="role-description" label="Description" helptext="Shown in the Role List to help staff pick the right role.">
        <Input value={form.description} onChange={(e) => set({ description: e.target.value })} disabled={disabled} />
      </Field>

      {showClone && (
        <div className="role-clone-select-wrap">
          <Field id="role-clone" label="Clone Existing Role" helptext="Copies every permission from the selected role - adjust the matrix below afterward.">
            <Select value={form.cloneFromRoleId || ""} onChange={(e) => set({ cloneFromRoleId: e.target.value || null })} disabled={disabled}>
              <option value="">Start blank</option>
              {cloneableRoles.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </Select>
          </Field>
        </div>
      )}

      <div className="form-grid">
        <div className="field">
          <label>Status</label>
          <div className="segmented-control" role="radiogroup" aria-label="Role status">
            {["ACTIVE", "INACTIVE"].map((s) => (
              <button
                type="button"
                key={s}
                className={`segmented-option${form.status === s ? " selected" : ""}`}
                aria-pressed={form.status === s}
                onClick={() => set({ status: s })}
                disabled={disabled || (form.code === "OWNER" && s === "INACTIVE")}
              >
                {s === "ACTIVE" ? "Active" : "Inactive"}
              </button>
            ))}
          </div>
        </div>

        <div className="field">
          <label>Require Approval</label>
          <Tooltip label="Maker-Checker for role changes - planned for a future sprint">
            <label className="checkbox-row" style={{ marginTop: 0 }}>
              <input type="checkbox" checked={false} disabled />
              Require approval for changes to this role
            </label>
          </Tooltip>
        </div>
      </div>
    </div>
  );
}
