"use client";

import { usePermissions } from "../../hooks/usePermissions";

// Declarative permission gate - the JSX counterpart to can(). Renders
// children only if the current identity (or the active Role Preview
// override, Phase 5) holds `permission`; otherwise renders `fallback`
// (default: nothing). For a control that should stay visible-but-disabled
// with a reason instead of hidden (the pattern already used everywhere in
// this app for "not available yet" actions), check can() imperatively and
// wrap the control in the existing Tooltip component instead of using this
// component - <Can> is for hide/show, not disable/enable.
export default function Can({ permission, fallback = null, children }) {
  const { can, loading } = usePermissions();
  if (loading) return null;
  return can(permission) ? children : fallback;
}
