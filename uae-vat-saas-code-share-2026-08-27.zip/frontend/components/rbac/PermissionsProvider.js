"use client";

import { createContext, useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";

export const PermissionsContext = createContext(null);

// Plan + RBAC combined enforcement (2026-08-09) - mirrors
// isModuleEnabled/isActionEnabled in the backend's plan.service.js exactly
// (same fail-open rule: a module/action never configured in Plan Builder is
// allowed by default, only an explicit `enabled: false` denies). Small,
// pure, duplicated deliberately rather than shared - same "no shared module
// system between the two repos" precedent already established by
// lib/invoiceCalc.js mirroring the backend's own calc engine for
// client-side preview.
function isActionEnabled(moduleAccess, moduleKey, actionKey) {
  const entry = moduleAccess?.[moduleKey];
  if (!entry) return true;
  if (entry.enabled === false) return false;
  const featureFlag = entry.features?.[actionKey];
  return featureFlag !== false;
}

// One centralized permission engine (RBAC module, 2026-08-06) - fetched once
// per app session via GET /api/tenant/me/permissions, right after the tenant
// layout's own auth-gate confirms a valid token (same lifecycle moment
// tenant/layout.js already establishes tenantAuth.getSession()). Every
// sidebar item, button, dropdown action, and route guard reads from this one
// Set - nothing else ever branches on a role string again, per
// docs/master-product-specification.md §14.
//
// `preview` (Phase 5 - "Preview as this Role", set via startPreview()) takes
// precedence over the real fetched set when present. Preview mode requires
// touching nothing else in the app because every consumer already goes
// through usePermissions() here - it's a pure swap of what this hook reads
// from, not a parallel code path.
export function PermissionsProvider({ children }) {
  const [permissions, setPermissions] = useState(null); // null = still loading
  const [role, setRole] = useState(null);
  const [moduleAccess, setModuleAccess] = useState({});
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(null); // { keys: Set, label: string } | null

  const load = useCallback(async () => {
    const token = tenantAuth.get();
    if (!token) {
      setPermissions(new Set());
      return;
    }
    try {
      const { role, permissions, moduleAccess } = await api.getMyPermissions(token);
      setRole(role);
      setPermissions(new Set(permissions));
      setModuleAccess(moduleAccess || {});
      setError("");
    } catch (err) {
      // Fails safe to "no permissions" rather than leaving the app stuck on
      // a loading state - a real fetch failure should be visibly
      // restrictive, never silently permissive. moduleAccess intentionally
      // stays {} (fail-open) on a fetch failure too - RBAC's own Set is
      // already the restrictive half of the pair in this state; Plan
      // resolution failing shouldn't ALSO block on top of that.
      setPermissions(new Set());
      setError(err.message);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const effectivePermissions = preview?.keys || permissions || new Set();

  // Plan + RBAC combined (2026-08-09) - RBAC (the Set) still decides WHO,
  // Plan (moduleAccess) now also decides WHETHER the tenant's subscription
  // includes it at all. Role Preview mode only swaps the RBAC half
  // (effectivePermissions) - Plan gating applies the same regardless of
  // which role is being previewed, since it's a Tenant-level fact, not a
  // Role-level one.
  const can = useCallback(
    (key) => {
      if (!effectivePermissions.has(key)) return false;
      const [module, action] = key.split(".");
      return isActionEnabled(moduleAccess, module, action);
    },
    [effectivePermissions, moduleAccess]
  );
  const startPreview = useCallback((keys, label) => setPreview({ keys: new Set(keys), label }), []);
  const exitPreview = useCallback(() => setPreview(null), []);

  const value = useMemo(
    () => ({
      permissions: effectivePermissions,
      role,
      loading: permissions === null,
      error,
      can,
      refresh: load,
      isPreviewing: preview !== null,
      previewLabel: preview?.label || null,
      startPreview,
      exitPreview,
    }),
    [effectivePermissions, role, permissions, error, can, load, preview, startPreview, exitPreview]
  );

  return <PermissionsContext.Provider value={value}>{children}</PermissionsContext.Provider>;
}
