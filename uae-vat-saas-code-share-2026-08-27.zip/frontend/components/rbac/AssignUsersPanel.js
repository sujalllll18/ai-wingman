"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Button from "../ui/Button";
import Input from "../ui/Input";
import EmptyState from "../ui/EmptyState";
import ErrorBanner from "../ui/ErrorBanner";

// Searchable user picker for Role Details' "Assign Users" section - the
// first real payoff of the RBAC module for Team's already-stubbed, disabled
// "Assign Role" ActionMenu item (frontend/app/tenant/team/page.js), wired
// for real starting Phase 6. Reuses api.listTeam (already real) rather than
// a new endpoint - Team and Roles & Permissions share the same user list.
export default function AssignUsersPanel({ roleId, currentUserIds, onAssigned, showToast }) {
  const [users, setUsers] = useState(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(() => new Set());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const token = tenantAuth.get();
      try {
        const { users } = await api.listTeam(token);
        setUsers(users);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    if (!users) return [];
    const q = search.trim().toLowerCase();
    return users.filter((u) => !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }, [users, search]);

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function handleAssign() {
    if (selected.size === 0) return;
    setSubmitting(true);
    setError("");
    try {
      const token = tenantAuth.get();
      await api.assignUsersToRole(token, roleId, Array.from(selected));
      showToast?.(`${selected.size} user${selected.size === 1 ? "" : "s"} assigned to this role.`);
      setSelected(new Set());
      await onAssigned?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (users === null) return null;

  return (
    <div>
      <ErrorBanner message={error} />
      <Input placeholder="Search by name or email…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ marginBottom: 12, width: "100%" }} />

      {filtered.length === 0 ? (
        <EmptyState title="No matching people" description="Try a different search term." />
      ) : (
        <div className="assign-users-list">
          {filtered.map((u) => {
            const isCurrent = currentUserIds.includes(u.id);
            const isOwner = u.role === "OWNER";
            return (
              <label className="assign-users-row" key={u.id}>
                <input type="checkbox" checked={selected.has(u.id)} onChange={() => toggle(u.id)} disabled={isOwner} />
                <span>
                  <span className="assign-users-row-name">{u.name}</span> <span className="assign-users-row-email">{u.email}</span>
                </span>
                {isOwner && (
                  <span className="assign-users-row-current-role badge badge-premium">Owner</span>
                )}
                {!isOwner && isCurrent && <span className="assign-users-row-current-role badge badge-info">Currently assigned</span>}
              </label>
            );
          })}
        </div>
      )}

      <div className="dialog-actions" style={{ marginTop: 16 }}>
        <Button onClick={handleAssign} disabled={submitting || selected.size === 0}>
          {submitting ? "Assigning…" : `Assign ${selected.size || ""} Selected`.trim()}
        </Button>
      </div>
    </div>
  );
}
