"use client";

import { useMemo, useState } from "react";

const GROUP_ORDER = ["Dashboard", "Masters", "Transactions", "Compliance", "Reports", "Support", "Administration", "Settings"];

function groupCatalog(catalog, moduleLabels) {
  const byGroup = {};
  for (const p of catalog) {
    const g = (byGroup[p.group] ||= {});
    (g[p.module] ||= { module: p.module, moduleLabel: moduleLabels[p.module] || p.module, actions: [] }).actions.push(p);
  }
  const result = {};
  for (const group of Object.keys(byGroup)) {
    result[group] = Object.values(byGroup[group]).map((m) => ({ ...m, actions: [...m.actions].sort((a, b) => a.sortOrder - b.sortOrder) }));
  }
  return result;
}

// Grouped, expandable Permission Matrix (RBAC module, 2026-08-06) - the one
// widget both Create Role and Role Details reuse for editing a role's
// permission set. Rows = modules (within each expandable group), each
// module's own actions render as a wrapped checkbox row rather than a rigid
// shared column grid across unrelated modules, since not every module
// declares the same actions - avoids a mostly-empty grid.
//
// "Permission inheritance" here is UI-level implication, not a data-model
// concept: checking a non-view action for a module auto-checks that
// module's `view` action too, if it has one - you can't sensibly grant
// "Edit" without "View". Enforced here at check-time; the backend
// (role.controller.js updateRolePermissions) persists whatever the final
// set is, it doesn't re-derive this itself.
export default function PermissionMatrix({ catalog, moduleLabels, selectedKeys, onChange, disabled, readOnly }) {
  const [openGroups, setOpenGroups] = useState(() => new Set());
  const grouped = useMemo(() => groupCatalog(catalog, moduleLabels || {}), [catalog, moduleLabels]);
  const selected = selectedKeys;
  const isInteractive = !disabled && !readOnly;

  function toggleGroup(group) {
    setOpenGroups((prev) => {
      const next = new Set(prev);
      if (next.has(group)) next.delete(group);
      else next.add(group);
      return next;
    });
  }

  function emit(nextSet) {
    onChange(Array.from(nextSet));
  }

  function setKey(key, checked) {
    const next = new Set(selected);
    if (checked) {
      next.add(key);
      const [module, action] = key.split(".");
      if (action !== "view") {
        const viewKey = `${module}.view`;
        if (catalog.some((p) => p.key === viewKey)) next.add(viewKey);
      }
    } else {
      next.delete(key);
    }
    emit(next);
  }

  function setKeys(keys, checked) {
    const next = new Set(selected);
    keys.forEach((k) => (checked ? next.add(k) : next.delete(k)));
    emit(next);
  }

  function setAll(checked) {
    emit(new Set(checked ? catalog.map((p) => p.key) : []));
  }

  function toggleActionAcrossModules(action) {
    const keysForAction = catalog.filter((p) => p.action === action).map((p) => p.key);
    const allSelected = keysForAction.length > 0 && keysForAction.every((k) => selected.has(k));
    setKeys(keysForAction, !allSelected);
  }

  const totalCount = catalog.length;
  const selectedCount = catalog.filter((p) => selected.has(p.key)).length;

  return (
    <div className="permission-matrix">
      <div className="permission-matrix-toolbar">
        <label className="permission-matrix-select-all">
          <input
            type="checkbox"
            checked={totalCount > 0 && selectedCount === totalCount}
            onChange={(e) => setAll(e.target.checked)}
            disabled={!isInteractive}
          />
          Select All
          <span className="permission-matrix-count">
            {selectedCount}/{totalCount}
          </span>
        </label>
        {isInteractive && (
          <div className="permission-matrix-quick-actions">
            <span className="helptext">Quick toggle:</span>
            <button type="button" className="btn btn-outline btn-sm" onClick={() => toggleActionAcrossModules("view")}>
              View — all modules
            </button>
            <button type="button" className="btn btn-outline btn-sm" onClick={() => toggleActionAcrossModules("export")}>
              Export — all modules
            </button>
          </div>
        )}
      </div>

      {GROUP_ORDER.filter((g) => grouped[g]).map((group) => {
        const modules = grouped[group];
        const groupKeys = modules.flatMap((m) => m.actions.map((a) => a.key));
        const groupSelectedCount = groupKeys.filter((k) => selected.has(k)).length;
        const isOpen = openGroups.has(group);

        return (
          <div className="permission-matrix-group" key={group}>
            <div className="permission-matrix-group-header" onClick={() => toggleGroup(group)} role="button" tabIndex={0} aria-expanded={isOpen}>
              <span className="permission-matrix-group-chevron" aria-hidden="true">
                {isOpen ? "▾" : "▸"}
              </span>
              <span className="permission-matrix-group-title">{group}</span>
              <span className="permission-matrix-count">
                {groupSelectedCount}/{groupKeys.length}
              </span>
              {isInteractive && (
                <input
                  type="checkbox"
                  className="permission-matrix-group-checkbox"
                  checked={groupSelectedCount === groupKeys.length}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => setKeys(groupKeys, e.target.checked)}
                />
              )}
            </div>

            {isOpen && (
              <div className="permission-matrix-group-body">
                {modules.map((m) => {
                  const moduleKeys = m.actions.map((a) => a.key);
                  const moduleSelectedCount = moduleKeys.filter((k) => selected.has(k)).length;
                  return (
                    <div className="permission-matrix-row" key={m.module}>
                      <label className="permission-matrix-row-header">
                        <input
                          type="checkbox"
                          checked={moduleSelectedCount === moduleKeys.length}
                          onChange={(e) => setKeys(moduleKeys, e.target.checked)}
                          disabled={!isInteractive}
                        />
                        <span className="permission-matrix-row-label">{m.moduleLabel}</span>
                      </label>
                      <div className="permission-matrix-row-actions">
                        {m.actions.map((a) => (
                          <label className="permission-matrix-action" key={a.key}>
                            <input type="checkbox" checked={selected.has(a.key)} onChange={(e) => setKey(a.key, e.target.checked)} disabled={!isInteractive} />
                            {a.label}
                          </label>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
