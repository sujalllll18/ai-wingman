"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { isValidEmail, isValidPhoneNumber, isValidTRN } from "../../lib/validation";
import { DEFAULT_COUNTRY_ISO2, findCountry } from "../../lib/countries";
import Modal from "../ui/Modal";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import StepWizard from "../ui/StepWizard";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import PhoneInput from "../PhoneInput";

const STEPS = ["Basic Information", "Tax Information", "Contact Information", "Address", "Financial", "Review"];

const EMIRATES = ["Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Umm Al Quwain", "Ras Al Khaimah", "Fujairah"];

const PAYMENT_TERMS = ["Immediate", "15 Days", "30 Days", "45 Days", "60 Days"];

const TAX_TREATMENTS = ["Standard Rated", "Zero Rated", "Exempt", "Out of Scope"];

const initial = {
  customerType: "BUSINESS",
  name: "",
  displayName: "",
  status: "ACTIVE",

  vatRegistered: null,
  trn: "",
  taxTreatment: "",

  contactPerson: "",
  email: "",
  phoneCountryIso2: DEFAULT_COUNTRY_ISO2,
  mobileNumber: "",
  telephone: "",
  website: "",

  billingLine1: "",
  billingLine2: "",
  billingCity: "",
  billingEmirate: "",
  billingCountry: "United Arab Emirates",
  billingPostalCode: "",
  shippingSameAsBilling: true,
  shippingLine1: "",
  shippingLine2: "",
  shippingCity: "",
  shippingEmirate: "",
  shippingCountry: "United Arab Emirates",
  shippingPostalCode: "",

  currency: "AED",
  paymentTerms: "30 Days",
};

const STEP_FIELDS = {
  0: ["name"],
  1: ["vatRegistered", "trn"],
  2: ["email", "mobileNumber"],
};

function getBasicErrors(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = "Customer name is required.";
  return errors;
}

function getTaxErrors(form) {
  const errors = {};
  if (form.vatRegistered === null) errors.vatRegistered = "Please select whether this customer is VAT registered.";
  if (form.vatRegistered === true) {
    if (!form.trn.trim()) errors.trn = "TRN is required.";
    else if (!isValidTRN(form.trn)) errors.trn = "TRN must be exactly 15 digits.";
  }
  return errors;
}

function getContactErrors(form) {
  const errors = {};
  if (form.email && !isValidEmail(form.email)) errors.email = "Enter a valid email address.";
  if (form.mobileNumber && !isValidPhoneNumber(form.mobileNumber, form.phoneCountryIso2)) {
    errors.mobileNumber = "Enter a valid phone number for the selected country.";
  }
  return errors;
}

function getStepErrors(step, form) {
  if (step === 0) return getBasicErrors(form);
  if (step === 1) return getTaxErrors(form);
  if (step === 2) return getContactErrors(form);
  return {};
}

function getAllErrors(form) {
  return { ...getBasicErrors(form), ...getTaxErrors(form), ...getContactErrors(form) };
}

function firstStepWithError(errors) {
  for (const [step, fields] of Object.entries(STEP_FIELDS)) {
    if (fields.some((f) => errors[f])) return Number(step);
  }
  return 0;
}

function formatAddress(line1, line2, city, emirate, country, postalCode) {
  return [line1, line2, city, emirate, country, postalCode].filter((v) => v && v.trim()).join(", ");
}

export default function AddCustomerModal({ open, onClose, onSuccess }) {
  const [form, setForm] = useState(initial);
  const [step, setStep] = useState(0);
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const errors = getAllErrors(form);

  function reset() {
    setForm(initial);
    setStep(0);
    setTouched({});
    setError("");
    setLoading(false);
  }

  function handleClose() {
    if (loading) return;
    reset();
    onClose();
  }

  function update(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  }

  function updateLive(key) {
    return (e) => {
      const { value } = e.target;
      setForm((f) => ({ ...f, [key]: value }));
      markTouched(key);
    };
  }

  function markTouched(...keys) {
    setTouched((t) => {
      const next = { ...t };
      keys.forEach((k) => (next[k] = true));
      return next;
    });
  }

  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }

  function goNext() {
    const stepErrors = getStepErrors(step, form);
    if (Object.keys(stepErrors).length > 0) {
      markTouched(...(STEP_FIELDS[step] || []));
      return;
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  }

  function goBack() {
    setStep((s) => Math.max(s - 1, 0));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;

    if (Object.keys(errors).length > 0) {
      markTouched(...Object.values(STEP_FIELDS).flat());
      setStep(firstStepWithError(errors));
      return;
    }

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const address = formatAddress(
        form.billingLine1,
        form.billingLine2,
        form.billingCity,
        form.billingEmirate,
        form.billingCountry,
        form.billingPostalCode
      );
      const payload = {
        name: form.name.trim(),
        address: address || null,
        trn: form.vatRegistered ? form.trn.trim() : null,
        customerType: form.customerType,
        status: form.status,
      };
      const result = await api.createCustomer(token, payload);
      const createdName = form.name;
      reset();
      // Maker-Checker engine (2026-08-06): if customers.create has an
      // Approval Rule on, the backend responds 202 with an approvalRequest
      // instead of a real customer - tell the caller so it doesn't claim
      // the customer was added when it's actually still pending.
      onSuccess(createdName, result.approvalRequest || null);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={handleClose} size="lg" ariaLabel="Add Customer">
      <div className="dialog-lg-header">
        <button type="button" className="dialog-lg-close" aria-label="Close" onClick={handleClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Add Customer</h2>
        <p className="form-section-desc">Create a new customer record for your business.</p>
        <StepWizard steps={STEPS} currentStep={step} />
      </div>

      <div className="dialog-lg-body">
        <ErrorBanner message={error} />

        <form onSubmit={handleSubmit}>
          <Card>
            {step === 0 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Basic Information</h2>
                <p className="form-section-desc">Core identity for this customer.</p>

                <div className="field">
                  <label>
                    Customer Type<span className="required-asterisk">*</span>
                  </label>
                  <div className="segmented-control" role="radiogroup" aria-label="Customer type">
                    <button
                      type="button"
                      className={`segmented-option${form.customerType === "BUSINESS" ? " selected" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, customerType: "BUSINESS" }))}
                    >
                      Business
                    </button>
                    <button
                      type="button"
                      className={`segmented-option${form.customerType === "INDIVIDUAL" ? " selected" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, customerType: "INDIVIDUAL" }))}
                    >
                      Individual
                    </button>
                  </div>
                </div>

                <Field
                  id="name"
                  label={
                    <>
                      Customer Name<span className="required-asterisk">*</span>
                    </>
                  }
                  error={fieldError("name")}
                  style={{ marginTop: 16 }}
                >
                  <Input value={form.name} onChange={updateLive("name")} onBlur={() => markTouched("name")} />
                </Field>
                <Field id="displayName" label="Display Name" helptext="Optional">
                  <Input value={form.displayName} onChange={update("displayName")} />
                </Field>
                <Field id="customerCode" label="Customer Code" helptext="Assigned automatically once this customer is created">
                  <Input value="Auto-generated" disabled />
                </Field>

                <div className="field" style={{ marginBottom: 0 }}>
                  <label>Status</label>
                  <div className="segmented-control" role="radiogroup" aria-label="Status">
                    <button
                      type="button"
                      className={`segmented-option${form.status === "ACTIVE" ? " selected" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, status: "ACTIVE" }))}
                    >
                      Active
                    </button>
                    <button
                      type="button"
                      className={`segmented-option${form.status === "INACTIVE" ? " selected" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, status: "INACTIVE" }))}
                    >
                      Inactive
                    </button>
                  </div>
                </div>
              </>
            )}

            {step === 1 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Tax Information</h2>
                <p className="form-section-desc">VAT registration status for this customer.</p>

                <div className="field">
                  <label>
                    VAT Registered?<span className="required-asterisk">*</span>
                  </label>
                  <div className="segmented-control" role="radiogroup" aria-label="VAT registered">
                    <button
                      type="button"
                      className={`segmented-option${form.vatRegistered === true ? " selected" : ""}`}
                      onClick={() => {
                        setForm((f) => ({ ...f, vatRegistered: true }));
                        markTouched("vatRegistered");
                      }}
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      className={`segmented-option${form.vatRegistered === false ? " selected" : ""}`}
                      onClick={() => {
                        setForm((f) => ({ ...f, vatRegistered: false, trn: "" }));
                        markTouched("vatRegistered");
                      }}
                    >
                      No
                    </button>
                  </div>
                  {fieldError("vatRegistered") && (
                    <p className="field-error" role="alert">
                      {fieldError("vatRegistered")}
                    </p>
                  )}
                </div>

                {form.vatRegistered === true && (
                  <Field
                    id="trn"
                    label={
                      <>
                        TRN<span className="required-asterisk">*</span>
                      </>
                    }
                    error={fieldError("trn")}
                    helptext={!fieldError("trn") ? "Exactly 15 digits" : undefined}
                    style={{ marginTop: 16 }}
                  >
                    <Input
                      value={form.trn}
                      onChange={(e) => {
                        const digits = e.target.value.replace(/\D/g, "").slice(0, 15);
                        setForm((f) => ({ ...f, trn: digits }));
                        markTouched("trn");
                      }}
                      onBlur={() => markTouched("trn")}
                      className="mono"
                      placeholder="100000000000000"
                      inputMode="numeric"
                    />
                  </Field>
                )}

                <Field id="taxTreatment" label="Tax Treatment" helptext="Optional" style={{ marginBottom: 0, marginTop: 16 }}>
                  <Select value={form.taxTreatment} onChange={update("taxTreatment")}>
                    <option value="">Select tax treatment</option>
                    {TAX_TREATMENTS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </Select>
                </Field>
              </>
            )}

            {step === 2 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Contact Information</h2>
                <p className="form-section-desc">How your team reaches this customer.</p>
                <div className="form-grid">
                  <Field id="contactPerson" label="Contact Person">
                    <Input value={form.contactPerson} onChange={update("contactPerson")} />
                  </Field>
                  <Field id="email" label="Email" error={fieldError("email")}>
                    <Input type="email" value={form.email} onChange={updateLive("email")} onBlur={() => markTouched("email")} />
                  </Field>
                </div>
                <div className="form-grid">
                  <div className="field">
                    <label htmlFor="mobileNumber">Mobile Number</label>
                    <PhoneInput
                      id="mobileNumber"
                      countryIso2={form.phoneCountryIso2}
                      number={form.mobileNumber}
                      onCountryChange={(iso2) => {
                        setForm((f) => ({ ...f, phoneCountryIso2: iso2 }));
                        markTouched("mobileNumber");
                      }}
                      onNumberChange={(value) => {
                        setForm((f) => ({ ...f, mobileNumber: value }));
                        markTouched("mobileNumber");
                      }}
                      error={fieldError("mobileNumber")}
                    />
                    {fieldError("mobileNumber") && (
                      <p id="mobileNumber-error" className="field-error" role="alert">
                        {fieldError("mobileNumber")}
                      </p>
                    )}
                  </div>
                  <Field id="telephone" label="Telephone" helptext="Optional">
                    <Input value={form.telephone} onChange={update("telephone")} />
                  </Field>
                </div>
                <Field id="website" label="Website" helptext="Optional" style={{ marginBottom: 0 }}>
                  <Input value={form.website} onChange={update("website")} placeholder="https://" />
                </Field>
              </>
            )}

            {step === 3 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Address</h2>
                <p className="form-section-desc">Billing Address</p>
                <Field id="billingLine1" label="Address Line 1">
                  <Input value={form.billingLine1} onChange={update("billingLine1")} />
                </Field>
                <Field id="billingLine2" label="Address Line 2" helptext="Optional">
                  <Input value={form.billingLine2} onChange={update("billingLine2")} />
                </Field>
                <div className="form-grid">
                  <Field id="billingCity" label="City">
                    <Input value={form.billingCity} onChange={update("billingCity")} />
                  </Field>
                  <Field id="billingEmirate" label="Emirate">
                    <Select value={form.billingEmirate} onChange={update("billingEmirate")}>
                      <option value="">Select Emirate</option>
                      {EMIRATES.map((e) => (
                        <option key={e} value={e}>
                          {e}
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
                <div className="form-grid" style={{ marginBottom: 0 }}>
                  <Field id="billingCountry" label="Country">
                    <Input value={form.billingCountry} onChange={update("billingCountry")} />
                  </Field>
                  <Field id="billingPostalCode" label="Postal Code" helptext="Optional" style={{ marginBottom: 0 }}>
                    <Input value={form.billingPostalCode} onChange={update("billingPostalCode")} />
                  </Field>
                </div>

                <div className="checkbox-row">
                  <input
                    type="checkbox"
                    id="shippingSame"
                    checked={form.shippingSameAsBilling}
                    onChange={(e) => setForm((f) => ({ ...f, shippingSameAsBilling: e.target.checked }))}
                  />
                  <label htmlFor="shippingSame">Shipping Address Same as Billing</label>
                </div>

                {!form.shippingSameAsBilling && (
                  <div style={{ marginTop: 20 }}>
                    <p className="form-section-desc">Shipping Address</p>
                    <Field id="shippingLine1" label="Address Line 1">
                      <Input value={form.shippingLine1} onChange={update("shippingLine1")} />
                    </Field>
                    <Field id="shippingLine2" label="Address Line 2" helptext="Optional">
                      <Input value={form.shippingLine2} onChange={update("shippingLine2")} />
                    </Field>
                    <div className="form-grid">
                      <Field id="shippingCity" label="City">
                        <Input value={form.shippingCity} onChange={update("shippingCity")} />
                      </Field>
                      <Field id="shippingEmirate" label="Emirate">
                        <Select value={form.shippingEmirate} onChange={update("shippingEmirate")}>
                          <option value="">Select Emirate</option>
                          {EMIRATES.map((e) => (
                            <option key={e} value={e}>
                              {e}
                            </option>
                          ))}
                        </Select>
                      </Field>
                    </div>
                    <div className="form-grid" style={{ marginBottom: 0 }}>
                      <Field id="shippingCountry" label="Country">
                        <Input value={form.shippingCountry} onChange={update("shippingCountry")} />
                      </Field>
                      <Field id="shippingPostalCode" label="Postal Code" helptext="Optional" style={{ marginBottom: 0 }}>
                        <Input value={form.shippingPostalCode} onChange={update("shippingPostalCode")} />
                      </Field>
                    </div>
                  </div>
                )}
              </>
            )}

            {step === 4 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Financial</h2>
                <p className="form-section-desc">Billing defaults for this customer.</p>
                <div className="form-grid" style={{ marginBottom: 0 }}>
                  <Field id="currency" label="Currency">
                    <Select value={form.currency} onChange={update("currency")}>
                      <option value="AED">AED</option>
                    </Select>
                  </Field>
                  <Field id="paymentTerms" label="Payment Terms" style={{ marginBottom: 0 }}>
                    <Select value={form.paymentTerms} onChange={update("paymentTerms")}>
                      {PAYMENT_TERMS.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
              </>
            )}

            {step === 5 && (
              <>
                <h2 style={{ marginBottom: 4 }}>Review &amp; Create</h2>
                <p className="form-section-desc">Confirm the details below before creating this customer.</p>
                <div className="review-list">
                  <div className="review-row">
                    <span className="review-label">Customer name</span>
                    <span className="review-value">{form.name || "—"}</span>
                  </div>
                  <div className="review-row">
                    <span className="review-label">Customer type</span>
                    <span className="review-value">{form.customerType === "BUSINESS" ? "Business" : "Individual"}</span>
                  </div>
                  <div className="review-row">
                    <span className="review-label">Status</span>
                    <span className="review-value">{form.status === "ACTIVE" ? "Active" : "Inactive"}</span>
                  </div>
                  <div className="review-row">
                    <span className="review-label">VAT Registered</span>
                    <span className="review-value">{form.vatRegistered ? "Yes" : "No"}</span>
                  </div>
                  {form.vatRegistered && (
                    <div className="review-row">
                      <span className="review-label">TRN</span>
                      <span className="review-value mono">{form.trn}</span>
                    </div>
                  )}
                  <div className="review-row">
                    <span className="review-label">Contact</span>
                    <span className="review-value">
                      {form.email || "—"} · +{findCountry(form.phoneCountryIso2).dialCode} {form.mobileNumber || "—"}
                    </span>
                  </div>
                  <div className="review-row">
                    <span className="review-label">Billing Address</span>
                    <span className="review-value">
                      {formatAddress(
                        form.billingLine1,
                        form.billingLine2,
                        form.billingCity,
                        form.billingEmirate,
                        form.billingCountry,
                        form.billingPostalCode
                      ) || "—"}
                    </span>
                  </div>
                  <div className="review-row">
                    <span className="review-label">Payment Terms</span>
                    <span className="review-value">
                      {form.currency} · {form.paymentTerms}
                    </span>
                  </div>
                </div>
                <PlaceholderNotice>
                  Only Customer Name, Type, Status, Address, and TRN are saved today. Contact details, tax
                  treatment, shipping address, and financial terms are captured here but not yet stored on the
                  backend — they&rsquo;ll be added once those fields exist.
                </PlaceholderNotice>
              </>
            )}
          </Card>

          <div className="wizard-actions">
            <Button type="button" variant="outline" onClick={goBack} disabled={step === 0 || loading}>
              Back
            </Button>
            {step < STEPS.length - 1 ? (
              <Button type="button" onClick={goNext}>
                Next Step
              </Button>
            ) : (
              <Button type="submit" disabled={loading}>
                {loading ? "Creating…" : "Create Customer"}
              </Button>
            )}
          </div>
        </form>
      </div>
    </Modal>
  );
}
