"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import AdjustmentSummaryCard from "../notes/AdjustmentSummaryCard";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
function computeLine(qty, unitPrice, taxPercentage, taxCalculationMethod) {
  const lineNet = round2(qty * unitPrice);
  const taxAmount =
    taxCalculationMethod === "INCLUSIVE"
      ? round2(lineNet - lineNet / (1 + (taxPercentage || 0) / 100))
      : round2((lineNet * (taxPercentage || 0)) / 100);
  const lineTotal = taxCalculationMethod === "INCLUSIVE" ? lineNet : round2(lineNet + taxAmount);
  return { taxAmount, lineTotal };
}

// Mirrors CreditNoteForm.js/DebitNoteForm.js - same uncapped-quantity
// philosophy as DebitNoteForm (this is additive, no "remaining eligible
// amount" ceiling). One real addition neither of those forms has: a "New
// Line" section, since this document's core use case (per spec) is "forgot
// to add an item entirely" - a line that was never on the original invoice
// at all, not just an adjusted quantity of an existing one. A new line's tax
// treatment is constrained to a rate that actually appeared somewhere on the
// original invoice (backend-enforced, see salesDebitNote.controller.js's
// resolveNoteLineFromSource) - so the dropdown here is built from the
// invoice's own distinct line tax treatments, never a live Tax Master fetch.
export default function SalesDebitNoteForm({ invoiceId }) {
  const router = useRouter();
  const [invoice, setInvoice] = useState(null);
  const [previouslyAdjusted, setPreviouslyAdjusted] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");
  const [issueDate, setIssueDate] = useState("");
  const [notes, setNotes] = useState("");
  // { [lineItemId]: { checked, quantity } }
  const [selection, setSelection] = useState({});
  // Freeform lines the user adds that weren't on the original invoice.
  const [newLines, setNewLines] = useState([]);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoiceId]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const [{ invoice: inv }, { salesDebitNotes }] = await Promise.all([api.getInvoice(token, invoiceId), api.listSalesDebitNotes(token)]);
      setInvoice(inv);
      const already = round2(
        salesDebitNotes.filter((d) => d.invoiceId === invoiceId && d.status === "ISSUED").reduce((s, d) => s + d.grandTotal, 0)
      );
      setPreviouslyAdjusted(already);
      const initial = {};
      for (const li of inv.lineItems) {
        initial[li.id] = { checked: false, quantity: li.quantity };
      }
      setSelection(initial);
    } catch (err) {
      setError(err.message);
    }
  }

  // Distinct tax treatments actually used on the original invoice - the
  // only choices a new freeform line is allowed to use.
  const availableTaxTreatments = useMemo(() => {
    if (!invoice) return [];
    const seen = new Map();
    for (const li of invoice.lineItems) {
      if (!li.taxCategoryId) continue;
      if (!seen.has(li.taxCategoryId)) {
        seen.set(li.taxCategoryId, { taxCategoryId: li.taxCategoryId, taxRateName: li.taxRateName, taxPercentage: li.taxPercentage, taxCalculationMethod: li.taxCalculationMethod });
      }
    }
    return Array.from(seen.values());
  }, [invoice]);

  function toggleLine(lineId) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], checked: !s[lineId].checked } }));
  }
  function setQuantity(lineId, value) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], quantity: value } }));
  }

  function addNewLine() {
    setNewLines((lines) => [
      ...lines,
      { key: `new-${Date.now()}-${lines.length}`, description: "", quantity: 1, unitPrice: 0, taxCategoryId: availableTaxTreatments[0]?.taxCategoryId || "" },
    ]);
  }
  function updateNewLine(key, patch) {
    setNewLines((lines) => lines.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  }
  function removeNewLine(key) {
    setNewLines((lines) => lines.filter((l) => l.key !== key));
  }

  const previewExistingLines = useMemo(() => {
    if (!invoice) return [];
    return invoice.lineItems
      .filter((li) => selection[li.id]?.checked)
      .map((li) => {
        const qty = Number(selection[li.id]?.quantity || 0);
        const { taxAmount, lineTotal } = computeLine(qty, li.unitPrice, li.taxPercentage, li.taxCalculationMethod);
        return { ...li, qty, taxAmount, lineTotal, isNew: false };
      });
  }, [invoice, selection]);

  const previewNewLines = useMemo(() => {
    return newLines
      .filter((l) => l.description.trim() && Number(l.quantity) > 0)
      .map((l) => {
        const treatment = availableTaxTreatments.find((t) => t.taxCategoryId === l.taxCategoryId);
        const qty = Number(l.quantity);
        const unitPrice = Number(l.unitPrice) || 0;
        const { taxAmount, lineTotal } = computeLine(qty, unitPrice, treatment?.taxPercentage || 0, treatment?.taxCalculationMethod || "EXCLUSIVE");
        return { key: l.key, description: l.description, qty, unitPrice, taxCategoryId: l.taxCategoryId, taxRateName: treatment?.taxRateName, taxPercentage: treatment?.taxPercentage || 0, taxAmount, lineTotal, isNew: true };
      });
  }, [newLines, availableTaxTreatments]);

  const currentTotal = round2([...previewExistingLines, ...previewNewLines].reduce((s, l) => s + l.lineTotal, 0));

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!reason.trim()) {
      setError("A reason is required.");
      return;
    }
    if (previewExistingLines.length === 0 && previewNewLines.length === 0) {
      setError("Select at least one line, or add a new line item.");
      return;
    }
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const lineItems = [
        ...previewExistingLines.map((l) => ({ invoiceLineItemId: l.id, quantity: l.qty })),
        ...previewNewLines.map((l) => ({ description: l.description, quantity: l.qty, unitPrice: l.unitPrice, taxCategoryId: l.taxCategoryId || undefined })),
      ];
      const { salesDebitNote } = await api.createSalesDebitNote(token, {
        invoiceId,
        reason: reason.trim(),
        issueDate: issueDate || undefined,
        notes: notes || undefined,
        lineItems,
      });
      router.push(`/tenant/sales-debit-notes/${salesDebitNote.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  if (!invoice) {
    return (
      <>
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Original Invoice</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Invoice #</span>
                <span className="review-value mono">{invoice.invoiceNumberDisplay}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Customer</span>
                <span className="review-value">{invoice.customerName}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Invoice Date</span>
                <span className="review-value">{formatDate(invoice.issueDate)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Currency</span>
                <span className="review-value">{invoice.currency}</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Increase an Existing Line (optional)</h3>
            <p className="helptext" style={{ marginTop: -8 }}>
              Tax treatment is always inherited from the original line. Quantity may exceed the original — this is an additional
              charge, not a capped reduction.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {invoice.lineItems.map((li) => (
                <div key={li.id} className="note-line-row" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--color-border)" }}>
                  <input type="checkbox" checked={!!selection[li.id]?.checked} onChange={() => toggleLine(li.id)} />
                  <div style={{ flex: 1 }}>
                    <div>{li.description}</div>
                    <div className="helptext">
                      Original qty {li.quantity} × {formatCurrency(li.unitPrice, invoice.currency)}
                      {li.taxRateName ? ` · ${li.taxRateName} (${li.taxPercentage}%)` : " · No tax"}
                    </div>
                  </div>
                  <Input
                    type="number"
                    min="0.01"
                    step="any"
                    style={{ width: 90 }}
                    disabled={!selection[li.id]?.checked}
                    value={selection[li.id]?.quantity ?? li.quantity}
                    onChange={(e) => setQuantity(li.id, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ margin: 0 }}>New Line Items</h3>
              <Button type="button" variant="outline" onClick={addNewLine} disabled={availableTaxTreatments.length === 0 && invoice.lineItems.some((li) => li.taxCategoryId)}>
                + Add Line
              </Button>
            </div>
            <p className="helptext" style={{ marginTop: 4 }}>
              For something that wasn't on the original invoice at all — e.g. a forgotten item. Tax treatment is limited to a rate
              that actually appeared on the original invoice.
            </p>
            {newLines.length === 0 ? (
              <p className="helptext" style={{ margin: 0 }}>No new lines added.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {newLines.map((l) => (
                  <div key={l.key} style={{ display: "flex", gap: 8, alignItems: "flex-end", padding: "10px 0", borderBottom: "1px solid var(--color-border)" }}>
                    <Field id={`desc-${l.key}`} label="Description" style={{ flex: 2, marginBottom: 0 }}>
                      <Input value={l.description} onChange={(e) => updateNewLine(l.key, { description: e.target.value })} placeholder="e.g. Installation fee" />
                    </Field>
                    <Field id={`qty-${l.key}`} label="Qty" style={{ width: 80, marginBottom: 0 }}>
                      <Input type="number" min="0.01" step="any" value={l.quantity} onChange={(e) => updateNewLine(l.key, { quantity: e.target.value })} />
                    </Field>
                    <Field id={`price-${l.key}`} label="Unit Price" style={{ width: 110, marginBottom: 0 }}>
                      <Input type="number" min="0" step="0.01" value={l.unitPrice} onChange={(e) => updateNewLine(l.key, { unitPrice: e.target.value })} />
                    </Field>
                    <Field id={`tax-${l.key}`} label="Tax" style={{ width: 160, marginBottom: 0 }}>
                      <Select value={l.taxCategoryId} onChange={(e) => updateNewLine(l.key, { taxCategoryId: e.target.value })}>
                        {availableTaxTreatments.map((t) => (
                          <option key={t.taxCategoryId} value={t.taxCategoryId}>
                            {t.taxRateName} ({t.taxPercentage}%)
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Button type="button" variant="outline" onClick={() => removeNewLine(l.key)} style={{ marginBottom: 0 }}>
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <Field id="reason" label="Reason">
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Forgot to include installation charge" required />
            </Field>
            <Field id="issueDate" label="Issue Date (optional — defaults to today when issued)">
              <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} />
            </Field>
            <Field id="notes" label="Notes (customer-facing, optional)" style={{ marginBottom: 0 }}>
              <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </Field>
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <AdjustmentSummaryCard
            currency={invoice.currency}
            originalAmount={invoice.grandTotal}
            previouslyAdjusted={previouslyAdjusted}
            previouslyLabel="Previously Adjusted"
            currentNote={currentTotal}
            currentLabel="This Debit Note"
          />
          <Button type="submit" disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
            {busy ? "Saving…" : "Save Draft"}
          </Button>
        </div>
      </div>
    </form>
  );
}
