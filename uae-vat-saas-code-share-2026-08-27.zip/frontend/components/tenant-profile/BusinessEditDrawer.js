"use client";

import { useState } from "react";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import PhoneInput from "../PhoneInput";
import { isValidEmail, isValidPhoneNumber } from "../../lib/validation";
import { DEFAULT_COUNTRY_ISO2 } from "../../lib/countries";

// Flip this the moment a real PATCH endpoint exists for business-profile
// fields — everything below (validation, payload shape, toast, refresh) is
// already wired for that; only the branch inside handleSubmit needs the
// actual api.* call filled in.
// TODO(backend): PATCH /api/platform-admin/tenants/:id/business
const BUSINESS_UPDATE_ENDPOINT_AVAILABLE = false;

const SENSITIVE_FIELDS = ["name", "tradeLicenseNumber", "legalEntity"];

export default function BusinessEditDrawer({ open, onClose, tenant, onSaved, showToast, setError }) {
  const initial = {
    name: tenant.name || "",
    tradeLicenseNumber: "",
    legalEntity: "",
    contactEmail: "",
    phoneCountryIso2: DEFAULT_COUNTRY_ISO2,
    phoneNumber: "",
    address: "",
  };

  const [form, setForm] = useState(initial);
  const [reason, setReason] = useState("");
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState("");

  function update(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  }

  function markTouched(key) {
    setTouched((t) => ({ ...t, [key]: true }));
  }

  const hasSensitiveChange = SENSITIVE_FIELDS.some((key) => form[key] !== initial[key]);

  const errors = {
    contactEmail: form.contactEmail && !isValidEmail(form.contactEmail) ? "Enter a valid email address." : "",
    phoneNumber:
      form.phoneNumber && !isValidPhoneNumber(form.phoneNumber, form.phoneCountryIso2)
        ? "Enter a valid phone number for the selected country."
        : "",
    reason: hasSensitiveChange && !reason.trim() ? "A reason is required when changing Legal Name, Trade License Number, or Legal Entity Type." : "",
  };

  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }

  const hasBlockingErrors = Object.values(errors).some(Boolean);

  function resetAndClose() {
    setForm(initial);
    setReason("");
    setTouched({});
    setNotice("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;

    setTouched({ contactEmail: true, phoneNumber: true, reason: true });
    if (hasBlockingErrors) return;

    if (!BUSINESS_UPDATE_ENDPOINT_AVAILABLE) {
      setNotice("Saving isn't connected yet — this will be enabled once the business-profile update endpoint ships in a future sprint.");
      return;
    }

    setSubmitting(true);
    setError?.("");
    try {
      // TODO(backend): await api.updateTenantBusiness(token, tenantId, { ...form, reason });
      showToast?.("Business information updated.");
      await onSaved?.();
      resetAndClose();
    } catch (err) {
      setError?.(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Drawer open={open} onClose={resetAndClose} ariaLabel="Edit Business Information">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Edit Business Information</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Update this tenant&rsquo;s business profile.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="drawer-body">
          {notice && <PlaceholderNotice>{notice}</PlaceholderNotice>}

          <div style={{ marginTop: notice ? 16 : 0 }}>
            <Field
              id="edit-name"
              label={
                <>
                  Business Legal Name<span className="required-asterisk">*</span>
                </>
              }
              helptext="Sensitive field — changing this requires a reason below"
            >
              <Input required value={form.name} onChange={update("name")} />
            </Field>
            <Field
              id="edit-tradeLicenseNumber"
              label="Trade License Number"
              helptext="Sensitive field — changing this requires a reason below"
            >
              <Input value={form.tradeLicenseNumber} onChange={update("tradeLicenseNumber")} />
            </Field>
            <Field
              id="edit-legalEntity"
              label="Legal Entity Type"
              helptext="Sensitive field — changing this requires a reason below"
            >
              <Input value={form.legalEntity} onChange={update("legalEntity")} />
            </Field>

            {hasSensitiveChange && (
              <Field
                id="edit-reason"
                label={
                  <>
                    Reason for change<span className="required-asterisk">*</span>
                  </>
                }
                error={fieldError("reason")}
              >
                <textarea
                  id="edit-reason"
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  onBlur={() => markTouched("reason")}
                  style={{
                    width: "100%",
                    padding: "10px 12px",
                    border: "1px solid var(--color-line-strong)",
                    borderRadius: "var(--radius)",
                    fontFamily: "var(--font-body)",
                    fontSize: "14px",
                    resize: "vertical",
                  }}
                />
              </Field>
            )}

            <Field
              id="edit-contactEmail"
              label={
                <>
                  Contact Email<span className="required-asterisk">*</span>
                </>
              }
              error={fieldError("contactEmail")}
            >
              <Input
                type="email"
                required
                value={form.contactEmail}
                onChange={(e) => {
                  update("contactEmail")(e);
                  markTouched("contactEmail");
                }}
                onBlur={() => markTouched("contactEmail")}
              />
            </Field>

            <div className="field">
              <label htmlFor="edit-phone">
                Contact Number<span className="required-asterisk">*</span>
              </label>
              <PhoneInput
                id="edit-phone"
                countryIso2={form.phoneCountryIso2}
                number={form.phoneNumber}
                onCountryChange={(iso2) => {
                  setForm((f) => ({ ...f, phoneCountryIso2: iso2 }));
                  markTouched("phoneNumber");
                }}
                onNumberChange={(value) => {
                  setForm((f) => ({ ...f, phoneNumber: value }));
                  markTouched("phoneNumber");
                }}
                error={fieldError("phoneNumber")}
              />
              {fieldError("phoneNumber") && (
                <p id="edit-phone-error" className="field-error" role="alert">
                  {fieldError("phoneNumber")}
                </p>
              )}
            </div>

            <Field id="edit-address" label="Business Address" style={{ marginBottom: 0 }}>
              <Input value={form.address} onChange={update("address")} />
            </Field>
          </div>
        </div>

        <div className="drawer-actions">
          <Button type="button" variant="outline" onClick={resetAndClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Drawer>
  );
}
