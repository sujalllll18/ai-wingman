import Card from "../ui/Card";
import Button from "../ui/Button";
import Select from "../ui/Select";
import Field from "../ui/Field";
import Tooltip from "../ui/Tooltip";
import StatusStamp from "../StatusStamp";
import BusinessTab from "./BusinessTab";
import VatComplianceTab from "./VatComplianceTab";

// Settings tab (2026-08-06, Platform Admin Phase 1 tab remap) - composes
// the existing Business Information and VAT & Compliance sections (which
// used to be their own top-level tabs; the target tab list for this phase
// doesn't have separate tabs for them, so they're relocated here rather
// than deleted) alongside the new fields the spec asks for: Business
// Status, Timezone, Currency, Branding (already inside BusinessTab),
// Notification Settings. Timezone/Currency/Notification Settings have no
// corresponding field on Tenant yet - honest placeholders, not persisted.
export default function SettingsTab({ tenant, usage, token, tenantId, onSaved, showToast, setError, busy, onToggleStatus }) {
  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 4 }}>Business Status</h2>
        <p className="form-section-desc">Whether this tenant can currently log in and use the platform.</p>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 12 }}>
          <StatusStamp status={usage.status} />
          <Button variant={usage.status === "ACTIVE" ? "danger" : "primary"} onClick={onToggleStatus} disabled={busy}>
            {usage.status === "ACTIVE" ? "Suspend Tenant" : "Reactivate Tenant"}
          </Button>
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Regional Settings</h2>
        <p className="form-section-desc">Not yet stored on this tenant&rsquo;s record — captured here for when this becomes available.</p>
        <div className="form-grid">
          <Field id="settings-timezone" label="Timezone">
            <Select disabled defaultValue="Asia/Dubai">
              <option value="Asia/Dubai">Asia/Dubai (GST, UTC+4)</option>
            </Select>
          </Field>
          <Field id="settings-currency" label="Currency" style={{ marginBottom: 0 }}>
            <Select disabled defaultValue="AED">
              <option value="AED">AED</option>
            </Select>
          </Field>
        </div>
      </Card>

      <BusinessTab tenant={tenant} token={token} tenantId={tenantId} onSaved={onSaved} showToast={showToast} setError={setError} vatTabAvailable={false} />
      <VatComplianceTab tenant={tenant} />

      <Card>
        <h2 style={{ marginBottom: 4 }}>Notification Settings</h2>
        <p className="form-section-desc">Which platform events this tenant&rsquo;s owner is notified about.</p>
        <Tooltip label="Not available yet — no notification-preferences model exists on the backend">
          <label className="checkbox-row" style={{ opacity: 0.6, pointerEvents: "none" }}>
            <input type="checkbox" disabled checked readOnly />
            Email me about subscription renewals
          </label>
        </Tooltip>
        <Tooltip label="Not available yet — no notification-preferences model exists on the backend">
          <label className="checkbox-row" style={{ opacity: 0.6, pointerEvents: "none" }}>
            <input type="checkbox" disabled readOnly />
            Email me about usage-limit warnings
          </label>
        </Tooltip>
      </Card>
    </>
  );
}
