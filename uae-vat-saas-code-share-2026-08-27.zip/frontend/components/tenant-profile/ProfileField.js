import Tooltip from "../ui/Tooltip";

// Read-only "label: value" row shared by Business/VAT/Subscription tabs.
// When there's no value, shows an em-dash with a tooltip explaining why —
// same pattern already used on the Tenant List for untracked columns.
export default function ProfileField({ label, value, tooltip }) {
  return (
    <div className="review-row">
      <span className="review-label">{label}</span>
      {value ? (
        <span className="review-value">{value}</span>
      ) : (
        <Tooltip label={tooltip}>
          <span className="review-value" style={{ color: "var(--color-ink-faint)" }}>
            —
          </span>
        </Tooltip>
      )}
    </div>
  );
}
