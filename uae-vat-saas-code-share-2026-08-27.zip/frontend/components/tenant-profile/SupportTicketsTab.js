import Card from "../ui/Card";
import Button from "../ui/Button";
import EmptyState from "../ui/EmptyState";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import Tooltip from "../ui/Tooltip";

// Replaces the old "Support Notes" tab (2026-08-06, Platform Admin Phase 1
// tab remap) - "Support Tickets" per the target tab list, not internal
// notes. No backend model or endpoint exists for support tickets yet, same
// as notes before it — honest placeholder rather than a locally-saved list
// that would look durable but isn't.
export default function SupportTicketsTab() {
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
        <h2>Support Tickets</h2>
        <Tooltip label="Not available yet — there's no backend model or endpoint to store support tickets">
          <Button disabled>+ New Ticket</Button>
        </Tooltip>
      </div>
      <p className="form-section-desc">Every support ticket raised for this tenant.</p>
      <PlaceholderNotice>
        Not available yet — there&rsquo;s no backend model or endpoint to store support tickets. Left
        disabled rather than saving locally, so nothing here looks durable until it actually is.
      </PlaceholderNotice>
      <div style={{ marginTop: 16 }}>
        <EmptyState title="No support tickets yet" description="Ticket Number, Status, Priority, Assigned To, Created Date, and Updated Date will appear here once the backend supports it." />
      </div>
    </Card>
  );
}
