"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import Card from "../ui/Card";
import Button from "../ui/Button";
import Table from "../ui/Table";
import TableScroll from "../ui/TableScroll";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import EmptyState from "../ui/EmptyState";
import ImportStatusBadge from "../imports/ImportStatusBadge";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Platform Admin's "Migration" tab (2026-08-22) - lets an admin start/drive
// a historical data migration for this tenant, mirroring the tenant
// self-service Migration Center exactly but authorized as Platform Admin
// (see platformAdminMigration.controller.js's header comment for why this
// needs its own routes rather than reusing the tenant-side ones - Platform
// Admin has no tenant JWT). Same shared components
// (MigrationEntitySummaryTable/MigrationProgressPanel/MigrationFinalSummary)
// as the tenant pages are reused by the wizard/detail pages this links to,
// just wired to the admin api.js functions instead.
export default function MigrationTab({ token, tenantId, tenantName }) {
  const router = useRouter();
  const [migrations, setMigrations] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantId]);

  async function load() {
    try {
      const { migrations } = await api.listTenantMigrations(token, tenantId);
      setMigrations(migrations);
    } catch (err) {
      setError(err.message);
    }
  }

  const COLUMNS = [
    { key: "migrationNumber", header: "Migration ID", render: (m) => <span className="mono">{m.migrationNumber}</span> },
    { key: "entityCount", header: "Files", className: "num", render: (m) => m.entityCount },
    { key: "startedByType", header: "Started By", render: (m) => (m.startedByType === "PLATFORM_ADMIN" ? "Platform Admin" : "Tenant User") },
    { key: "startedAt", header: "Started At", render: (m) => formatDate(m.startedAt) },
    { key: "totalRecords", header: "Total", className: "num", render: (m) => m.totalRecords },
    { key: "successCount", header: "Successful", className: "num", render: (m) => m.successCount },
    { key: "failedCount", header: "Failed", className: "num", render: (m) => m.failedCount },
    { key: "status", header: "Status", render: (m) => <ImportStatusBadge status={m.status} /> },
  ];

  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
        <div>
          <h3 style={{ margin: 0 }}>Migration</h3>
          <p className="helptext" style={{ margin: 0 }}>Bring in this tenant's historical Customers, Sales Invoices, and Purchase Bills from Excel or CSV.</p>
        </div>
        <Link href={`/admin/tenants/${tenantId}/migrations/new?name=${encodeURIComponent(tenantName || "")}`} className="btn btn-primary">
          Start Migration
        </Link>
      </div>

      {error && <p className="field-error">{error}</p>}

      {migrations === null ? (
        <LoadingSkeleton columns={COLUMNS.length} />
      ) : migrations.length === 0 ? (
        <EmptyState title="No migrations yet" description="This tenant has no historical data migrations on record." />
      ) : (
        <TableScroll>
          <Table columns={COLUMNS} rows={migrations} onRowClick={(m) => router.push(`/admin/tenants/${tenantId}/migrations/${m.id}?name=${encodeURIComponent(tenantName || "")}`)} />
        </TableScroll>
      )}
    </Card>
  );
}
