"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import ProfileField from "./ProfileField";
import TrnChangeDrawer from "./TrnChangeDrawer";

const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

export default function VatComplianceTab({ tenant }) {
  const [trnDrawerOpen, setTrnDrawerOpen] = useState(false);

  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 4 }}>VAT & Compliance</h2>
        <p className="form-section-desc">Registration status and filing details.</p>
        <div className="review-list">
          <ProfileField label="VAT Status" tooltip={NOT_TRACKED} />
          <ProfileField label="TRN" value={tenant.trn} tooltip="This tenant has no TRN on record" />
          <ProfileField label="Registration Date" tooltip={NOT_TRACKED} />
          <ProfileField label="VAT Return Frequency" tooltip={NOT_TRACKED} />
          <ProfileField label="Fiscal Year" tooltip={NOT_TRACKED} />
          <ProfileField label="Free Zone / Mainland" tooltip={NOT_TRACKED} />
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>VAT Certificate</h2>
        <p className="form-section-desc">Upload the FTA VAT registration certificate.</p>
        <PlaceholderNotice>
          Document storage isn&rsquo;t wired up yet — there&rsquo;s no upload endpoint on the backend.
        </PlaceholderNotice>
        <Button variant="outline" disabled style={{ marginTop: 16 }}>
          Upload Certificate
        </Button>
      </Card>

      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>TRN Change Request</h2>
          <Button variant="outline" onClick={() => setTrnDrawerOpen(true)}>
            Request Change
          </Button>
        </div>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Changing a registered TRN requires a reason and supporting documentation.
        </p>
      </Card>

      <TrnChangeDrawer open={trnDrawerOpen} onClose={() => setTrnDrawerOpen(false)} currentTrn={tenant.trn} />
    </>
  );
}
