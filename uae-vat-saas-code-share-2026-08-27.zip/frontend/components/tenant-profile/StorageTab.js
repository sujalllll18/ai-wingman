import Card from "../ui/Card";
import EmptyState from "../ui/EmptyState";

// New tab (2026-08-06, Platform Admin Phase 1 tab remap). Storage has no
// concept anywhere in the backend schema today (confirmed absent from both
// Tenant and TenantUsage) - fully honest placeholder rather than a fake
// progress bar.
export default function StorageTab() {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Storage</h2>
      <p className="form-section-desc">Document and file storage consumed by this tenant.</p>
      <EmptyState
        icon={
          <svg viewBox="0 0 24 24" className="empty-illustration">
            <ellipse cx="12" cy="6" rx="8" ry="3" />
            <path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6" />
            <path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" />
          </svg>
        }
        title="Storage isn't tracked yet"
        description="There's no storage concept in the backend schema today — no file-size field, no quota, no usage endpoint. This tab is ready for that data once it exists."
      />
    </Card>
  );
}
