import Card from "../ui/Card";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import { getPlan } from "../../lib/plans";

const ALL_MODULES = ["Invoices", "Purchases", "Customers", "Tax Master", "VAT Returns", "Audit Log", "Maker-Checker Approvals", "OCR Upload"];

// New tab (2026-08-06, Platform Admin Phase 1 tab remap). There's no
// per-tenant module-toggle concept on the backend - a tenant's plan string
// is the only signal available, so "enabled modules" here is derived from
// the plan catalog (lib/plans.js), not a live per-tenant flag. Labeled as
// such; this is explicitly the placeholder Phase 1 asked for ("will later
// connect with the Plan Builder").
export default function ModulesTab({ usage }) {
  const plan = getPlan(usage.plan);
  const enabled = new Set(plan.modules);

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Modules</h2>
      <p className="form-section-desc">Feature availability based on the {plan.name} plan.</p>
      <PlaceholderNotice>
        Module access is derived from the tenant&rsquo;s plan, not an individually toggled per-tenant flag —
        there&rsquo;s no such concept on the backend yet. This will connect to the Plan Builder in a future
        phase.
      </PlaceholderNotice>
      <div className="review-list" style={{ marginTop: 16 }}>
        {ALL_MODULES.map((m) => (
          <div className="review-row" key={m}>
            <span className="review-label">{m}</span>
            <span className={`badge ${enabled.has(m) ? "badge-success" : "badge-info"}`}>{enabled.has(m) ? "Enabled" : "Not included"}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}
