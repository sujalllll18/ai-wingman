"use client";

import { useState } from "react";
import Drawer from "../ui/Drawer";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import Tooltip from "../ui/Tooltip";

// Fully placeholder: no backend endpoint accepts a TRN-change request today.
// Built ready for that integration (new TRN + reason + supporting document).
export default function TrnChangeDrawer({ open, onClose, currentTrn }) {
  const [newTrn, setNewTrn] = useState("");
  const [reason, setReason] = useState("");

  return (
    <Drawer open={open} onClose={onClose} ariaLabel="Request TRN Change">
      <div className="drawer-header">
        <button type="button" className="drawer-close" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Request TRN Change</h2>
        <p className="form-section-desc" style={{ marginBottom: 0 }}>
          Current TRN: <span className="mono">{currentTrn || "—"}</span>
        </p>
      </div>

      <div className="drawer-body">
        <PlaceholderNotice>
          Not available yet — there&rsquo;s no backend endpoint to submit or track TRN-change requests.
          This form is ready for that integration.
        </PlaceholderNotice>
        <div style={{ marginTop: 20 }}>
          <Field id="new-trn" label="New TRN">
            <Input
              value={newTrn}
              onChange={(e) => setNewTrn(e.target.value.replace(/\D/g, "").slice(0, 15))}
              className="mono"
              placeholder="100000000000000"
              inputMode="numeric"
            />
          </Field>
          <Field id="trn-reason" label="Reason for change">
            <textarea
              id="trn-reason"
              rows={4}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              style={{
                width: "100%",
                padding: "10px 12px",
                border: "1px solid var(--color-line-strong)",
                borderRadius: "var(--radius)",
                fontFamily: "var(--font-body)",
                fontSize: "14px",
                resize: "vertical",
              }}
            />
          </Field>
          <Field id="trn-doc" label="Supporting document" style={{ marginBottom: 0 }}>
            <input id="trn-doc" type="file" disabled />
          </Field>
        </div>
      </div>

      <div className="drawer-actions">
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Tooltip label="No backend endpoint exists yet to submit this request">
          {/* TODO(backend): wire to POST /api/platform-admin/tenants/:id/trn-change once it exists */}
          <Button disabled>Submit Request</Button>
        </Tooltip>
      </div>
    </Drawer>
  );
}
