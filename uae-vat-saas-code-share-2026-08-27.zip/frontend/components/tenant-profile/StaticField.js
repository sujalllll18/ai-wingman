"use client";

import Tooltip from "../ui/Tooltip";

// Read-only "label above value" field for a form-style grid layout
// (Business Profile, 2026-08-06 UI polish pass). Replaces the old
// review-row-style LockedField/ProfileField usage on this page only -
// ProfileField.js itself is left untouched since it's shared with the
// Admin Tenant Profile and Customer Profile pages. When `locked` is set, a
// plain lock icon sits inline with the label - the "why" is explained once
// via the section-level PlaceholderNotice banner in page.js, not repeated
// as a per-field tooltip bubble on every locked field (a later refinement;
// the original pass had one custom tooltip per lock icon, which read as
// repetitive with 6 locked fields on the page).
export default function StaticField({ label, value, locked, tooltip, mono, fullWidth }) {
  return (
    <div className={`field static-field${fullWidth ? " static-field-full" : ""}`}>
      <label className="static-field-label">
        {label}
        {locked && (
          <svg viewBox="0 0 24 24" className="locked-field-icon" aria-hidden="true">
            <title>Compliance-sensitive — managed during onboarding</title>
            <rect x="5" y="10.5" width="14" height="9.5" rx="1.5" />
            <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
          </svg>
        )}
      </label>
      {value ? (
        <div className={`static-field-value${mono ? " mono" : ""}`}>{value}</div>
      ) : (
        <Tooltip label={tooltip || "Not set yet."}>
          <div className="static-field-value static-field-empty">—</div>
        </Tooltip>
      )}
    </div>
  );
}
