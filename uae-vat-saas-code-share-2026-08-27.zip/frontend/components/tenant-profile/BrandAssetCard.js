"use client";

import { useRef, useState } from "react";
import Button from "../ui/Button";

const ACCEPTED_TYPES = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"];

// One upload/preview/replace/remove card for a single brand asset (Logo,
// Stamp, or Signature) - reused as-is for all three (2026-08-09, wired to
// real persistence). `value` is the asset's current real URL from the
// backend (null if none uploaded); `onUpload`/`onRemove` are async and do
// the actual API call - this component owns only the file picker UI and
// client-side pre-checks (type/size), matching the exact limits the
// backend itself enforces (businessProfile.controller.js's
// MAX_ASSET_BYTES) so a bad file is rejected instantly, not after a round
// trip - but the backend re-validates independently either way.
export default function BrandAssetCard({ label, recommendedFormats, accept = "image/png,image/jpeg,image/webp,image/svg+xml", maxBytes, value, onUpload, onRemove }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef(null);

  async function handleSelect(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError("");

    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError("Only PNG, JPEG, WEBP, or SVG files are accepted.");
      return;
    }
    if (maxBytes && file.size > maxBytes) {
      setError(`File must be ${Math.round(maxBytes / (1024 * 1024))}MB or smaller.`);
      return;
    }

    setBusy(true);
    try {
      await onUpload(file);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove() {
    setBusy(true);
    setError("");
    try {
      await onRemove();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="branding-item">
      <span className="branding-label">{label}</span>
      <div className="branding-upload-box">
        {value ? (
          <img src={value} alt={`${label} preview`} />
        ) : (
          <span className="branding-upload-placeholder">No {label.toLowerCase()} uploaded</span>
        )}
      </div>

      <input ref={inputRef} type="file" accept={accept} style={{ display: "none" }} onChange={handleSelect} />

      {value ? (
        <div className="branding-actions">
          <Button type="button" variant="outline" disabled={busy} onClick={() => inputRef.current?.click()}>
            {busy ? "Working…" : "Replace"}
          </Button>
          <Button type="button" variant="outline" disabled={busy} onClick={handleRemove}>
            Remove
          </Button>
        </div>
      ) : (
        <Button type="button" variant="outline" disabled={busy} style={{ width: "100%", justifyContent: "center" }} onClick={() => inputRef.current?.click()}>
          {busy ? "Uploading…" : `Upload ${label}`}
        </Button>
      )}

      {error && (
        <p className="field-error" role="alert" style={{ marginTop: 6 }}>
          {error}
        </p>
      )}
      <span className="branding-upload-hint">{recommendedFormats}</span>
    </div>
  );
}
