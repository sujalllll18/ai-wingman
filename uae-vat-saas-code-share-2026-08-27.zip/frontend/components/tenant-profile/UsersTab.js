"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import EmptyState from "../ui/EmptyState";
import ErrorBanner from "../ui/ErrorBanner";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import Table from "../ui/Table";
import ProfileField from "./ProfileField";

function formatDate(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function formatDateTime(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// User has no dedicated active/suspended status column (unlike Customer/
// Vendor/Tenant) - this derives an honest, real status from the existing
// mustChangePassword flag rather than fabricating a field nothing tracks.
// A user is "Pending First Login" only until they complete their own
// self-service password change (requireTenantUser clears the flag then,
// same check that blocks every other tenant endpoint until it happens).
function UserStatusBadge({ mustChangePassword }) {
  return mustChangePassword ? (
    <span className="badge badge-premium">Pending First Login</span>
  ) : (
    <span className="badge badge-success">Active</span>
  );
}

export default function UsersTab({ token, tenantId, onStaffAdded, showToast, setError }) {
  const [staffForm, setStaffForm] = useState({ name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);

  const [users, setUsers] = useState(null);
  const [loadError, setLoadError] = useState("");

  useEffect(() => {
    load();
  }, [tenantId]);

  async function load() {
    setLoadError("");
    try {
      const { users } = await api.listTenantUsers(token, tenantId);
      setUsers(users);
    } catch (err) {
      setLoadError(err.message);
    }
  }

  async function handleAddStaff(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await api.createStaff(token, tenantId, staffForm);
      showToast(`Added ${staffForm.name} as Staff.`);
      setStaffForm({ name: "", email: "", password: "" });
      await Promise.all([onStaffAdded(), load()]);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const owner = users?.find((u) => u.role === "OWNER") || null;
  const staff = users?.filter((u) => u.role === "STAFF") || [];

  const STAFF_COLUMNS = [
    { key: "name", header: "Name", render: (u) => u.name },
    { key: "email", header: "Email", render: (u) => u.email },
    { key: "status", header: "Status", render: (u) => <UserStatusBadge mustChangePassword={u.mustChangePassword} /> },
    { key: "createdAt", header: "Created", render: (u) => formatDate(u.createdAt) },
    { key: "lastLoginAt", header: "Last Login", render: (u) => formatDateTime(u.lastLoginAt) || "—" },
  ];

  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 4 }}>Owner</h2>
        {users === null ? (
          <LoadingSkeleton rows={1} columns={1} />
        ) : loadError ? (
          <ErrorBanner message={loadError} />
        ) : owner ? (
          <div className="review-list">
            <ProfileField label="Name" value={owner.name} />
            <ProfileField label="Email" value={owner.email} />
            <ProfileField label="Role" value="Owner" />
            <ProfileField label="Status" value={<UserStatusBadge mustChangePassword={owner.mustChangePassword} />} />
            <ProfileField label="Created Date" value={formatDate(owner.createdAt)} />
            <ProfileField label="Last Login" value={formatDateTime(owner.lastLoginAt)} tooltip="This Owner hasn't logged in yet." />
          </div>
        ) : (
          <p className="form-section-desc" style={{ marginBottom: 0 }}>
            No Owner account was found for this Tenant.
          </p>
        )}
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Staff</h2>
        <p className="form-section-desc">Every Staff account under this Tenant.</p>
        {users === null ? (
          <LoadingSkeleton columns={5} />
        ) : loadError ? null : staff.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <circle cx="9" cy="8" r="3" />
                <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
                <circle cx="17" cy="9" r="2.4" />
                <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
              </svg>
            }
            title="No Staff yet"
            description="Staff accounts you add for this Tenant will show up here."
          />
        ) : (
          <Table columns={STAFF_COLUMNS} rows={staff} />
        )}
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Add a Staff user</h2>
        <p className="helptext" style={{ marginBottom: 16 }}>
          Staff accounts are created by you, not self-service, per platform policy.
        </p>
        <form onSubmit={handleAddStaff}>
          <div className="form-grid">
            <Field id="staffName" label="Name">
              <Input required value={staffForm.name} onChange={(e) => setStaffForm((f) => ({ ...f, name: e.target.value }))} />
            </Field>
            <Field id="staffEmail" label="Email">
              <Input
                type="email"
                required
                value={staffForm.email}
                onChange={(e) => setStaffForm((f) => ({ ...f, email: e.target.value }))}
              />
            </Field>
          </div>
          <Field id="staffPassword" label="Temporary password" style={{ marginBottom: 0 }}>
            <Input
              required
              minLength={8}
              value={staffForm.password}
              onChange={(e) => setStaffForm((f) => ({ ...f, password: e.target.value }))}
            />
          </Field>
          <Button type="submit" disabled={busy} style={{ marginTop: 16 }}>
            Add Staff
          </Button>
        </form>
      </Card>
    </>
  );
}
