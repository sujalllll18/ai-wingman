import Card from "../ui/Card";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import Tooltip from "../ui/Tooltip";

// New tab (2026-08-06, Platform Admin Phase 1 tab remap). Invoices Used is
// the one real, live number here (from api.getTenantUsage); Purchases Used,
// OCR Credits, API Usage, Storage Consumption, and a monthly trend all have
// no corresponding field anywhere in the backend today, so they render as
// honest placeholders rather than invented numbers.
function Tile({ label, value, placeholder }) {
  return (
    <div className="kpi-tile">
      <div className="kpi-tile-top">
        <span className="kpi-tile-label">{label}</span>
      </div>
      {placeholder ? (
        <Tooltip label="Not tracked in the backend yet">
          <span className="kpi-tile-value placeholder">—</span>
        </Tooltip>
      ) : (
        <span className="kpi-tile-value">{value}</span>
      )}
    </div>
  );
}

export default function UsageTab({ usage }) {
  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 16 }}>Usage This Period</h2>
        <div className="kpi-tile-grid">
          <Tile label="Invoices Used" value={`${usage.invoiceCount} / ${usage.invoiceLimitPerMonth ?? "∞"}`} />
          <Tile label="Purchases Used" placeholder />
          <Tile label="OCR Credits" placeholder />
          <Tile label="API Usage" placeholder />
          <Tile label="Storage Consumption" placeholder />
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Monthly Usage Trend</h2>
        <p className="form-section-desc">Usage over time for this tenant.</p>
        <PlaceholderNotice>
          Usage isn&rsquo;t snapshotted over time on the backend yet — only the current invoice count is
          known, so a trend can&rsquo;t be charted until historical usage is recorded.
        </PlaceholderNotice>
      </Card>
    </>
  );
}
