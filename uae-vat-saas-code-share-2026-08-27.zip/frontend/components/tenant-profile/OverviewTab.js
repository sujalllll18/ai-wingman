import Card from "../ui/Card";
import Button from "../ui/Button";
import PlanTag from "../PlanTag";
import StatusStamp from "../StatusStamp";
import Tooltip from "../ui/Tooltip";
import ProfileField from "./ProfileField";
import ActivityTimelineTab from "./ActivityTimelineTab";
import { getPlan } from "../../lib/plans";

const NOT_RETURNED = "This field exists in the database but isn't returned by any current API endpoint yet";
const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toLocaleString()}`;
}

// Landing tab for the Tenant Details page (2026-08-06, Platform Admin
// Phase 1 tab remap) - expanded from the old Overview (which only had the
// Usage/Current-plan/Quick-actions cards) to also surface Business
// Information, Owner Information, Renewal Date, Storage Usage, and Revenue
// per the Phase 1 spec, plus Recent Activity (delegates to the existing
// ActivityTimelineTab rather than re-implementing its event list).
export default function OverviewTab({ tenant, usage, busy, onToggleStatus, onNavigateTab }) {
  const estimatedRevenue = getPlan(usage.plan).monthlyPrice;

  return (
    <div className="detail-layout">
      <div className="detail-main">
        <Card>
          <h2 style={{ marginBottom: 12 }}>Business Information</h2>
          <div className="review-list">
            <ProfileField label="Business Name" value={tenant.name} />
            <ProfileField label="TRN" value={tenant.trn} tooltip="This tenant has no TRN on record" />
            <ProfileField label="Address" tooltip={NOT_RETURNED} />
            <ProfileField label="Created" value={tenant.createdAt ? new Date(tenant.createdAt).toLocaleDateString() : null} />
          </div>
        </Card>

        <Card>
          <h2 style={{ marginBottom: 12 }}>Owner Information</h2>
          <div className="review-list">
            <ProfileField label="Owner Name" value={tenant.ownerName} tooltip="Owner details aren't returned by this list endpoint yet" />
            <ProfileField label="Owner Email" value={tenant.ownerEmail} tooltip="Owner details aren't returned by this list endpoint yet" />
          </div>
        </Card>

        <Card>
          <h2 style={{ marginBottom: 16 }}>Usage</h2>
          <div className="kpi-tile-grid">
            <div className="kpi-tile">
              <div className="kpi-tile-top">
                <span className="kpi-tile-label">Active Users</span>
                <span className="kpi-tile-icon">
                  <svg viewBox="0 0 24 24">
                    <circle cx="9" cy="8" r="3" />
                    <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
                    <circle cx="17" cy="9" r="2.4" />
                    <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
                  </svg>
                </span>
              </div>
              <span className="kpi-tile-value">
                {usage.userCount} / {usage.userLimit ?? "∞"}
              </span>
            </div>
            <div className="kpi-tile">
              <div className="kpi-tile-top">
                <span className="kpi-tile-label">Storage Usage</span>
              </div>
              <Tooltip label={NOT_TRACKED}>
                <span className="kpi-tile-value placeholder">—</span>
              </Tooltip>
            </div>
            <div className="kpi-tile">
              <div className="kpi-tile-top">
                <span className="kpi-tile-label">Last login</span>
                <span className="kpi-tile-icon">
                  <svg viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="9" />
                    <path d="M12 7v5l3.5 2" />
                  </svg>
                </span>
              </div>
              <span className="kpi-tile-value" style={{ fontSize: 15 }}>
                {usage.lastLoginAt ? new Date(usage.lastLoginAt).toLocaleString() : "Never"}
              </span>
            </div>
          </div>
        </Card>

        <ActivityTimelineTab tenant={tenant} usage={usage} />
      </div>

      <div className="detail-rail">
        <Card>
          <h2 style={{ marginBottom: 4 }}>Current plan</h2>
          <div style={{ marginBottom: 12 }}>
            <PlanTag plan={usage.plan} />
          </div>
          <div className="review-list" style={{ marginBottom: 12 }}>
            <ProfileField label="Subscription Status" value={<StatusStamp status={usage.status} />} />
            <ProfileField label="Renewal Date" tooltip={NOT_TRACKED} />
            <ProfileField label="Revenue" value={`${formatCurrency(estimatedRevenue)} / mo (est.)`} />
          </div>
          <Button variant="outline" onClick={() => onNavigateTab("subscription")} style={{ width: "100%", justifyContent: "center" }}>
            Manage Plan
          </Button>
        </Card>

        <Card>
          <h2 style={{ marginBottom: 4 }}>Quick actions</h2>
          <p className="helptext" style={{ marginBottom: 16 }}>
            {usage.status === "ACTIVE"
              ? "This Tenant can currently log in and use the platform."
              : "This Tenant is locked out of the platform until reactivated."}
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
            <Button
              variant={usage.status === "ACTIVE" ? "danger" : "primary"}
              onClick={onToggleStatus}
              disabled={busy}
              style={{ width: "100%", justifyContent: "center" }}
            >
              {usage.status === "ACTIVE" ? "Suspend Tenant" : "Reactivate Tenant"}
            </Button>
            <Tooltip label="Not available yet — no impersonation endpoint exists on the backend">
              <Button variant="outline" disabled style={{ width: "100%", justifyContent: "center" }}>
                Login as Tenant
              </Button>
            </Tooltip>
            <Tooltip label="Not available yet — no reset-password endpoint exists on the backend">
              <Button variant="outline" disabled style={{ width: "100%", justifyContent: "center" }}>
                Reset Owner Password
              </Button>
            </Tooltip>
            <Tooltip label="Not available yet — no archive endpoint exists on the backend">
              <Button variant="outline" disabled style={{ width: "100%", justifyContent: "center" }}>
                Archive Tenant
              </Button>
            </Tooltip>
          </div>
        </Card>
      </div>
    </div>
  );
}
