"use client";

import { useState } from "react";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import PhoneInput from "../PhoneInput";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { isValidEmail, isValidPhoneNumber } from "../../lib/validation";
import { DEFAULT_COUNTRY_ISO2 } from "../../lib/countries";

// Centered modal (2026-08-06 Business Profile polish, wired to a real
// backend 2026-08-09), replacing the old right-side drawer for the
// tenant-facing page only - the Platform Admin's own Tenant Detail
// "Business" tab keeps using its separate BusinessEditDrawer.js unchanged
// (it has a different, legitimate edit-sensitive-fields-with-a-reason flow
// that this page must never expose to a tenant user).
//
// Only Contact Email, Contact Number, and Business Address are editable -
// Business Legal Name, Trade License Number, Legal Entity Type, TRN,
// Country, and Emirate are compliance-locked and never appear here at all,
// and the backend PATCH endpoint itself has no write path for them either
// (not just hidden client-side) - see businessProfile.controller.js.

export default function BusinessProfileEditModal({ open, onClose, tenant, onSaved, showToast }) {
  const initial = {
    contactEmail: tenant?.contactEmail || "",
    phoneCountryIso2: DEFAULT_COUNTRY_ISO2,
    phoneNumber: tenant?.contactPhone || "",
    address: tenant?.address || "",
  };

  const [form, setForm] = useState(initial);
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  function markTouched(key) {
    setTouched((t) => ({ ...t, [key]: true }));
  }

  const errors = {
    contactEmail: form.contactEmail && !isValidEmail(form.contactEmail) ? "Enter a valid email address." : "",
    phoneNumber:
      form.phoneNumber && !isValidPhoneNumber(form.phoneNumber, form.phoneCountryIso2)
        ? "Enter a valid phone number for the selected country."
        : "",
  };
  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }
  const hasBlockingErrors = Object.values(errors).some(Boolean);

  function resetAndClose() {
    setForm(initial);
    setTouched({});
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setTouched({ contactEmail: true, phoneNumber: true });
    if (hasBlockingErrors) return;

    setSubmitting(true);
    setError("");
    try {
      const token = tenantAuth.get();
      await api.updateBusinessProfile(token, {
        contactEmail: form.contactEmail || null,
        contactPhone: form.phoneNumber || null,
        address: form.address || null,
      });
      showToast?.("Business information updated.");
      await onSaved?.();
      resetAndClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} size="lg" ariaLabel="Edit Business Information">
      <div className="dialog-lg-header">
        <button type="button" className="dialog-lg-close" aria-label="Close" onClick={resetAndClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Edit Business Information</h2>
        <p className="form-section-desc">
          Only contact details can be changed here. Business identity (legal name, TRN, trade license, and
          location) is locked after onboarding.
        </p>
      </div>

      <div className="dialog-lg-body">
        <ErrorBanner message={error} />

        <form onSubmit={handleSubmit}>
          <div className="form-grid" style={{ marginTop: error ? 16 : 0 }}>
            <Field id="bp-edit-email" label="Contact Email" error={fieldError("contactEmail")}>
              <Input
                type="email"
                value={form.contactEmail}
                onChange={(e) => setForm((f) => ({ ...f, contactEmail: e.target.value }))}
                onBlur={() => markTouched("contactEmail")}
              />
            </Field>

            <div className="field">
              <label htmlFor="bp-edit-phone">Contact Number</label>
              <PhoneInput
                id="bp-edit-phone"
                countryIso2={form.phoneCountryIso2}
                number={form.phoneNumber}
                onCountryChange={(iso2) => {
                  setForm((f) => ({ ...f, phoneCountryIso2: iso2 }));
                  markTouched("phoneNumber");
                }}
                onNumberChange={(value) => {
                  setForm((f) => ({ ...f, phoneNumber: value }));
                  markTouched("phoneNumber");
                }}
                error={fieldError("phoneNumber")}
              />
              {fieldError("phoneNumber") && (
                <p className="field-error" role="alert">
                  {fieldError("phoneNumber")}
                </p>
              )}
            </div>
          </div>

          <Field id="bp-edit-address" label="Business Address" style={{ marginBottom: 0 }}>
            <Input value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} />
          </Field>

          <div className="dialog-actions">
            <Button type="button" variant="outline" onClick={resetAndClose} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving…" : "Save Changes"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
