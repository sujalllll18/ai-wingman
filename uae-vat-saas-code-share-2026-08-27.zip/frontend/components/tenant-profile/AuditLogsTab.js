import Card from "../ui/Card";
import Button from "../ui/Button";
import Select from "../ui/Select";
import Field from "../ui/Field";
import EmptyState from "../ui/EmptyState";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import TableScroll from "../ui/TableScroll";
import DataTable from "../ui/DataTable";
import Tooltip from "../ui/Tooltip";

// Audit Logs tab (2026-08-06, Platform Admin Phase 1) - migrated off a
// hand-rolled <table> onto the shared DataTable component (columns: User,
// Module, Action, Timestamp per the Phase 1 spec), plus User/Module/Date
// filters and an Export action, all disabled since there's still no
// backend read/write path for audit entries (unchanged from before - an
// AuditLog table exists in the schema but nothing writes to it yet,
// including this page's own suspend/reactivate/plan-change actions).
// render() is never invoked - rows is always [] until a backend endpoint
// exists, so these column defs only need to draw the header row.
const COLUMNS = [
  { key: "user", label: "User" },
  { key: "module", label: "Module" },
  { key: "action", label: "Action" },
  { key: "timestamp", label: "Timestamp" },
];
const COLUMN_ORDER = COLUMNS.map((c) => c.key);

export default function AuditLogsTab() {
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
        <h2>Audit Logs</h2>
        <Tooltip label="Not available yet — no backend read endpoint for audit entries">
          <Button variant="outline" disabled>
            Export
          </Button>
        </Tooltip>
      </div>
      <p className="form-section-desc">Every change made to this Tenant's record.</p>
      <PlaceholderNotice>
        An AuditLog table exists in the database schema, but nothing writes to it yet — including this
        page's own real actions (plan changes, suspend/reactivate). No entries can be shown until a
        backend read endpoint and a write path are both wired up.
      </PlaceholderNotice>

      <div className="form-grid" style={{ marginTop: 16, opacity: 0.6, pointerEvents: "none" }} aria-disabled="true">
        <Field id="audit-filter-user" label="User">
          <Select disabled>
            <option>Anyone</option>
          </Select>
        </Field>
        <Field id="audit-filter-module" label="Module">
          <Select disabled>
            <option>All modules</option>
          </Select>
        </Field>
        <Field id="audit-filter-date" label="Date" style={{ marginBottom: 0 }}>
          <Select disabled>
            <option>Any time</option>
          </Select>
        </Field>
      </div>

      <TableScroll style={{ marginTop: 16 }}>
        <DataTable columns={COLUMNS} rows={[]} columnOrder={COLUMN_ORDER} hiddenColumns={[]} />
      </TableScroll>
      <div style={{ marginTop: 16 }}>
        <EmptyState title="No audit log entries yet" description="This is expected — audit logging isn't wired up on the backend." />
      </div>
    </Card>
  );
}
