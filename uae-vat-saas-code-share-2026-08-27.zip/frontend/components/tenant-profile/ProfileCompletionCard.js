import Card from "../ui/Card";
import InfoPopover from "../ui/InfoPopover";

// Completion % is always computed live from real field presence - never a
// fabricated number, same discipline as the Compliance Status card this
// replaces (2026-08-06 layout restructure). With today's thin tenant-facing
// backend (login only returns id/name/plan) most fields are honestly empty,
// so the percentage will read low until a real profile-update endpoint
// exists - that's correct behavior, not a bug to "fix" here.
const REQUIRED_FIELDS = [
  "Business Legal Name",
  "Legal Entity Type",
  "Trade License Number",
  "TRN",
  "Emirate",
  "Contact Email",
  "Contact Number",
  "Business Address",
  "Company Logo",
];

export default function ProfileCompletionCard({ tenant, logoUploaded }) {
  const fieldDone = {
    "Business Legal Name": !!tenant?.name,
    "Legal Entity Type": false,
    "Trade License Number": false,
    TRN: !!tenant?.trn,
    Emirate: false,
    "Contact Email": !!tenant?.contactEmail,
    "Contact Number": !!tenant?.contactPhone,
    "Business Address": !!tenant?.address,
    "Company Logo": !!logoUploaded,
  };

  const doneCount = REQUIRED_FIELDS.filter((f) => fieldDone[f]).length;
  const total = REQUIRED_FIELDS.length;
  const percent = Math.round((doneCount / total) * 100);

  const groups = [
    { label: "Business Information", done: !!tenant?.name },
    { label: "Contact Information", done: !!tenant?.contactEmail && !!tenant?.contactPhone },
    { label: "Address", done: !!tenant?.address },
    { label: "TRN", done: !!tenant?.trn },
    { label: "Company Logo", done: !!logoUploaded },
    { label: "Trade License", done: false },
  ];
  const completed = groups.filter((g) => g.done);
  const pending = groups.filter((g) => !g.done);

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Business Profile Completion</h2>
      <p className="form-section-desc">How ready your profile is for invoicing and compliance.</p>

      <div className="completion-meter">
        <div className="completion-meter-top">
          <span className="completion-percent">{percent}%</span>
          <InfoPopover ariaLabel="View completion breakdown">
            <div className="completion-popover">
              {completed.length > 0 && (
                <div className="completion-popover-group">
                  <span className="completion-popover-heading">Completed</span>
                  {completed.map((g) => (
                    <div className="completion-popover-item done" key={g.label}>
                      <span className="completion-popover-icon" aria-hidden="true">
                        ✓
                      </span>
                      {g.label}
                    </div>
                  ))}
                </div>
              )}
              {pending.length > 0 && (
                <div className="completion-popover-group">
                  <span className="completion-popover-heading">Pending</span>
                  {pending.map((g) => (
                    <div className="completion-popover-item pending" key={g.label}>
                      <span className="completion-popover-icon" aria-hidden="true">
                        ⚠
                      </span>
                      {g.label}
                    </div>
                  ))}
                </div>
              )}
              <p className="completion-popover-footer">Complete these fields for a fully configured business profile.</p>
            </div>
          </InfoPopover>
        </div>

        <div className="progress-bar-track">
          <div className="progress-bar-fill" style={{ width: `${percent}%` }} />
        </div>

        <p className="completion-fraction">
          {doneCount} of {total} required fields completed
        </p>
      </div>
    </Card>
  );
}
