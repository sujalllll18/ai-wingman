"use client";

import { useEffect, useRef, useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import Tooltip from "../ui/Tooltip";
import PlaceholderNotice from "../ui/PlaceholderNotice";
import BusinessEditDrawer from "./BusinessEditDrawer";
import ProfileField from "./ProfileField";

const NOT_RETURNED = "This field exists in the database but isn't returned by any current API endpoint yet";
const NOT_TRACKED = "This field doesn't exist in the backend schema yet";

function DocumentRow({ label, doc, onSelectFile }) {
  const inputRef = useRef(null);

  function handleChange(e) {
    const file = e.target.files?.[0];
    if (file) onSelectFile(file);
  }

  return (
    <div className="doc-row">
      <div>
        <div className="doc-row-name">{label}</div>
        <div className="doc-row-meta">
          {doc ? (
            <>
              {doc.name} · Uploaded {doc.uploadedAt.toLocaleDateString()} by {doc.uploadedBy}
            </>
          ) : (
            "No version uploaded · Expiry: —"
          )}
        </div>
      </div>
      <div className="doc-row-actions">
        <input ref={inputRef} type="file" style={{ display: "none" }} onChange={handleChange} />
        <Button variant="outline" onClick={() => inputRef.current?.click()}>
          {doc ? "Replace" : "Upload"}
        </Button>
        <Tooltip label="Not available yet — no document storage exists on the backend">
          <Button variant="outline" disabled>
            Download
          </Button>
        </Tooltip>
      </div>
    </div>
  );
}

export default function BusinessTab({ tenant, token, tenantId, onSaved, showToast, setError, vatTabAvailable = true }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreviewUrl, setLogoPreviewUrl] = useState(null);
  const [tradeLicenseDoc, setTradeLicenseDoc] = useState(null);

  useEffect(() => {
    return () => {
      if (logoPreviewUrl) URL.revokeObjectURL(logoPreviewUrl);
    };
  }, [logoPreviewUrl]);

  function handleLogoSelect(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (logoPreviewUrl) URL.revokeObjectURL(logoPreviewUrl);
    setLogoFile(file);
    setLogoPreviewUrl(URL.createObjectURL(file));
  }

  function handleTradeLicenseSelect(file) {
    setTradeLicenseDoc({ name: file.name, uploadedAt: new Date(), uploadedBy: "Platform Admin" });
  }

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <h2>Business Information</h2>
          <Button variant="outline" onClick={() => setDrawerOpen(true)}>
            Edit
          </Button>
        </div>
        <p className="form-section-desc">
          The single source of truth for this business's profile — used across invoices, VAT documents, and
          future compliance modules.
        </p>
        <div className="review-list">
          <ProfileField label="Business Legal Name" value={tenant.name} />
          <ProfileField label="Trade License Number" tooltip={NOT_TRACKED} />
          <ProfileField label="Legal Entity Type" tooltip={NOT_TRACKED} />
          <ProfileField label="Contact Email" tooltip={NOT_RETURNED} />
          <ProfileField label="Contact Number" tooltip={NOT_RETURNED} />
          <ProfileField label="Business Address" tooltip={NOT_RETURNED} />
          <ProfileField label="Emirate" tooltip={NOT_TRACKED} />
          <ProfileField label="Country" value="United Arab Emirates" />
          <div className="review-row">
            <span className="review-label">TRN</span>
            <span className="review-value">
              {tenant.trn ? <span className="mono">{tenant.trn}</span> : <span style={{ color: "var(--color-ink-faint)" }}>—</span>}
            </span>
          </div>
        </div>
        {vatTabAvailable && (
          <p className="helptext" style={{ marginTop: 12, marginBottom: 0 }}>
            TRN and VAT registration details are managed from the VAT &amp; Compliance tab.
          </p>
        )}
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Branding</h2>
        <p className="form-section-desc">Assets used on invoices and official documents.</p>
        <div className="branding-grid">
          <div className="branding-item">
            <span className="branding-label">Company Logo</span>
            <div className="branding-upload-box">
              {logoPreviewUrl ? (
                <img src={logoPreviewUrl} alt="Company logo preview" />
              ) : (
                <span className="branding-upload-placeholder">No logo uploaded</span>
              )}
            </div>
            <label className="btn btn-outline branding-upload-btn">
              {logoFile ? "Replace Logo" : "Upload Logo"}
              <input type="file" accept="image/*" style={{ display: "none" }} onChange={handleLogoSelect} />
            </label>
          </div>

          <div className="branding-item">
            <span className="branding-label">Company Stamp</span>
            <div className="branding-upload-box branding-upload-box-disabled">
              <span className="branding-upload-placeholder">Future Placeholder</span>
            </div>
            <Tooltip label="Not available yet — planned for a future sprint">
              <button type="button" className="btn btn-outline branding-upload-btn" disabled>
                Upload Stamp
              </button>
            </Tooltip>
          </div>

          <div className="branding-item">
            <span className="branding-label">Authorized Signature</span>
            <div className="branding-upload-box branding-upload-box-disabled">
              <span className="branding-upload-placeholder">Future Placeholder</span>
            </div>
            <Tooltip label="Not available yet — planned for a future sprint">
              <button type="button" className="btn btn-outline branding-upload-btn" disabled>
                Upload Signature
              </button>
            </Tooltip>
          </div>
        </div>
        {logoFile && (
          <PlaceholderNotice>
            This logo is only held in your browser for this session — there's no upload endpoint yet to
            store it permanently.
          </PlaceholderNotice>
        )}
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Business Documents</h2>
        <p className="form-section-desc">Trade license on file for this business.</p>
        <PlaceholderNotice>
          Uploads here aren&rsquo;t saved to a backend yet — there&rsquo;s no document storage or upload
          endpoint. This shows the complete intended flow.
        </PlaceholderNotice>
        <div className="doc-list" style={{ marginTop: 16 }}>
          <DocumentRow label="Trade License" doc={tradeLicenseDoc} onSelectFile={handleTradeLicenseSelect} />
        </div>
      </Card>

      <BusinessEditDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        tenant={tenant}
        token={token}
        tenantId={tenantId}
        onSaved={onSaved}
        showToast={showToast}
        setError={setError}
      />
    </>
  );
}
