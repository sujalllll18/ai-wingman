"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Select from "../ui/Select";
import Input from "../ui/Input";
import Button from "../ui/Button";
import PlanTag from "../PlanTag";
import PlanStatusBadge from "../PlanStatusBadge";
import ProfileField from "./ProfileField";
import EmptyState from "../ui/EmptyState";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString();
}
function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString();
}
function formatLimit(value) {
  return value === null || value === undefined ? "Unlimited" : Number(value).toLocaleString();
}

const NOT_TRACKED = "Not tracked in the current billing model yet";

// Tenant Plan Assignment + Plan Change History (2026-08-07, Platform Admin
// Phase 2) - replaces the old simple "pick a plan string, save" flow
// (api.updateTenantPlan, kept untouched and still used elsewhere/by nothing
// now) with the real Plan/PlanVersion assignment system: Assign/Schedule/
// Cancel against actual published plan versions, with every change logged
// to PlanChangeHistory and shown below.
export default function SubscriptionTab({ token, tenantId, onPlanSaved, showToast, setError }) {
  const [assignment, setAssignment] = useState(null);
  const [history, setHistory] = useState(null);
  const [availablePlans, setAvailablePlans] = useState([]);
  const [busy, setBusy] = useState(false);

  const [assignPlanVersionId, setAssignPlanVersionId] = useState("");
  const [assignReason, setAssignReason] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantId]);

  async function load() {
    try {
      const [{ assignment }, { history }, { plans }] = await Promise.all([
        api.getTenantPlanAssignment(token, tenantId),
        api.listPlanChangeHistory(token, tenantId),
        api.listPlans(token),
      ]);
      setAssignment(assignment);
      setHistory(history);
      const published = plans.filter((p) => p.status === "ACTIVE" && p.currentVersion?.status === "PUBLISHED");
      setAvailablePlans(published);
      if (!assignPlanVersionId && published.length > 0) setAssignPlanVersionId(published[0].currentVersion.id);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAssign() {
    if (!assignPlanVersionId) return;
    setBusy(true);
    setError("");
    try {
      await api.assignTenantPlan(token, tenantId, { planVersionId: assignPlanVersionId, reason: assignReason || undefined });
      showToast("Plan assigned.");
      setAssignReason("");
      await load();
      await onPlanSaved?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleSchedule() {
    if (!assignPlanVersionId || !scheduleDate) return;
    setBusy(true);
    setError("");
    try {
      await api.scheduleTenantPlanChange(token, tenantId, { planVersionId: assignPlanVersionId, effectiveDate: scheduleDate, reason: assignReason || undefined });
      showToast("Plan change scheduled.");
      setScheduleDate("");
      setAssignReason("");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleCancelScheduled() {
    setBusy(true);
    setError("");
    try {
      await api.cancelScheduledPlanChange(token, tenantId);
      showToast("Scheduled change cancelled.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (!assignment) {
    return (
      <Card>
        <h2 style={{ marginBottom: 4 }}>Subscription</h2>
        <EmptyState title="No plan assignment yet" description="This tenant predates the plan-assignment system, or hasn't been backfilled." />
      </Card>
    );
  }

  const current = assignment.planVersion;
  const scheduled = assignment.scheduledPlanVersion;

  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 12 }}>Current Plan</h2>
        <div style={{ marginBottom: 12, display: "flex", alignItems: "center", gap: 8 }}>
          <PlanTag plan={current.plan.slug} />
          <span style={{ fontWeight: 600 }}>{current.plan.name}</span>
          <span className="mono" style={{ fontSize: 12, color: "var(--color-ink-faint)" }}>v{current.versionNumber}</span>
        </div>
        <div className="review-list">
          <ProfileField label="Effective Date" value={formatDate(assignment.effectiveDate)} />
          <ProfileField label="Renewal Date" tooltip={NOT_TRACKED} />
          <ProfileField label="Previous Plan" value={assignment.previousPlanVersion?.plan.name} tooltip="No previous plan on record" />
          <ProfileField
            label="Next Plan"
            value={scheduled ? `${scheduled.plan.name} on ${formatDate(assignment.scheduledEffectiveDate)}` : null}
            tooltip="No plan change scheduled"
          />
        </div>
        {scheduled && (
          <Button variant="outline" onClick={handleCancelScheduled} disabled={busy} style={{ marginTop: 12 }}>
            Cancel Scheduled Change
          </Button>
        )}
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Assign / Upgrade / Downgrade</h2>
        <p className="form-section-desc">Immediate effect — updates the tenant's plan right away.</p>
        <div className="form-grid">
          <Field id="assign-plan" label="Plan">
            <Select value={assignPlanVersionId} onChange={(e) => setAssignPlanVersionId(e.target.value)}>
              {availablePlans.map((p) => (
                <option key={p.id} value={p.currentVersion.id}>
                  {p.name} — AED {p.currentVersion.monthlyPrice}/mo
                </option>
              ))}
            </Select>
          </Field>
          <Field id="assign-reason" label="Reason" style={{ marginBottom: 0 }}>
            <Input value={assignReason} onChange={(e) => setAssignReason(e.target.value)} placeholder="Optional" />
          </Field>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
          <Button onClick={handleAssign} disabled={busy || !assignPlanVersionId}>
            Assign Now
          </Button>
          <Input type="date" style={{ width: 160 }} value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)} />
          <Button variant="outline" onClick={handleSchedule} disabled={busy || !assignPlanVersionId || !scheduleDate}>
            Schedule Future Change
          </Button>
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Subscription Details</h2>
        <p className="form-section-desc">Usage limits from the current plan.</p>
        <div className="review-list">
          <ProfileField label="Users" value={formatLimit(current.maxUsers)} />
          <ProfileField label="Team Members" value={formatLimit(current.maxTeamMembers)} />
          <ProfileField label="Customers" value={formatLimit(current.maxCustomers)} />
          <ProfileField label="Products" value={formatLimit(current.maxProducts)} />
          <ProfileField label="Invoices / Month" value={formatLimit(current.maxInvoicesPerMonth)} />
          <ProfileField label="Purchases / Month" value={formatLimit(current.maxPurchasesPerMonth)} />
          <ProfileField label="OCR Credits" value={formatLimit(current.ocrCredits)} />
          <ProfileField label="API Calls / Month" value={formatLimit(current.apiCallsPerMonth)} />
          <ProfileField label="Storage" value={current.storageGb === null ? "Unlimited" : `${current.storageGb} GB`} />
        </div>
      </Card>

      <Card>
        <h2 style={{ marginBottom: 4 }}>Plan Change History</h2>
        <p className="form-section-desc">Every subscription change made for this tenant.</p>
        {!history || history.length === 0 ? (
          <EmptyState title="No plan changes yet" description="This tenant hasn't changed plans since being assigned." />
        ) : (
          <div className="review-list">
            {history.map((h) => (
              <div className="review-row" key={h.id}>
                <span className="review-label">
                  {h.oldPlanVersion ? h.oldPlanVersion.plan.name : "—"} → {h.newPlanVersion.plan.name}
                </span>
                <span className="review-value" style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 12, color: "var(--color-ink-faint)" }}>
                    {formatDateTime(h.changedAt)} {h.reason ? `· ${h.reason}` : ""}
                  </span>
                  <PlanStatusBadge status={h.approvalStatus === "NOT_REQUIRED" ? "ACTIVE" : h.approvalStatus} />
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </>
  );
}
