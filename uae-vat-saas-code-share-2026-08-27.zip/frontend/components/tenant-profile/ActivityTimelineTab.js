import Card from "../ui/Card";
import PlaceholderNotice from "../ui/PlaceholderNotice";

export default function ActivityTimelineTab({ tenant, usage }) {
  const events = [];
  if (tenant.createdAt) {
    events.push({ title: "Tenant Created", at: tenant.createdAt });
  }
  if (usage.lastLoginAt) {
    events.push({ title: "Last Login", at: usage.lastLoginAt });
  }
  events.sort((a, b) => new Date(b.at) - new Date(a.at));

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Activity Timeline</h2>
      <p className="form-section-desc">Chronological events for this business.</p>

      {events.length > 0 && (
        <div className="timeline" style={{ marginBottom: 20 }}>
          {events.map((e) => (
            <div className="timeline-item" key={e.title}>
              <span className="timeline-dot" />
              <div>
                <div className="timeline-content-title">{e.title}</div>
                <div className="timeline-content-meta">{new Date(e.at).toLocaleString()}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <PlaceholderNotice>
        Invoice Created, User Added, Plan Changed, and Document Uploaded events aren&rsquo;t logged
        anywhere on the backend yet — only Tenant Created and Last Login are known today.
      </PlaceholderNotice>
    </Card>
  );
}
