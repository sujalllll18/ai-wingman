"use client";

import { createContext, useCallback, useEffect, useMemo, useState } from "react";
import { api, assetUrl } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";

export const BrandingContext = createContext(null);

// Sidebar branding (2026-08-11) - reuses the existing Business Profile GET
// (no new endpoint, no new storage) to source the tenant's real name/logo
// for the sidebar instead of the name cached in the login session, which
// goes stale the moment Business Profile is edited. Fetched once per tenant
// shell mount, same lifecycle moment as PermissionsProvider's own fetch.
// Tolerant of a missing business_profile.view permission (some roles don't
// have it) - falls back to the session's tenant name and the default mark,
// exactly like today, rather than surfacing an error for a sidebar detail.
export function BrandingProvider({ children }) {
  const [name, setName] = useState(null);
  const [logoUrl, setLogoUrl] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const token = tenantAuth.get();
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const { businessProfile } = await api.getBusinessProfile(token);
      setName(businessProfile?.name || null);
      setLogoUrl(assetUrl(businessProfile?.logoUrl) || null);
    } catch (err) {
      // No business_profile.view permission, or the request failed - keep
      // the session-cached tenant name / default mark as the fallback.
      setName(null);
      setLogoUrl(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const value = useMemo(() => ({ name, logoUrl, loading, refresh: load }), [name, logoUrl, loading, load]);

  return <BrandingContext.Provider value={value}>{children}</BrandingContext.Provider>;
}
