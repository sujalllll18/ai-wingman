import Card from "../ui/Card";
import EmptyState from "../ui/EmptyState";
import PlaceholderNotice from "../ui/PlaceholderNotice";

// New tab (2026-08-06, Platform Admin Phase 1 tab remap) - platform billing
// invoices Ledger issues *to* this tenant for its subscription, a distinct
// concept from the tenant's own Invoices module (which is that tenant's
// customer-facing invoicing, unrelated). There's no platform billing/
// invoicing subsystem yet, so this is a full placeholder.
export default function InvoicesTab() {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Billing Invoices</h2>
      <p className="form-section-desc">Invoices Ledger has issued to this tenant for its subscription.</p>
      <PlaceholderNotice>
        Not available yet — there's no platform billing/invoicing subsystem on the backend. Monthly Revenue
        elsewhere in Platform Admin is an estimate from the plan catalog, not real billing history.
      </PlaceholderNotice>
      <div style={{ marginTop: 16 }}>
        <EmptyState title="No billing invoices yet" description="This is expected — platform billing isn't wired up yet." />
      </div>
    </Card>
  );
}
