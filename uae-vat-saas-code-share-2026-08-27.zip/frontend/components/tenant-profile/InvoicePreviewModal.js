"use client";

import Modal from "../ui/Modal";
import ClassicTemplate from "../invoice-templates/ClassicTemplate";

// Illustrative only - never touches Invoice's own real data or the shared
// ClassicTemplate component's markup/classes (that stays exactly as Invoice
// already relies on it - PDF/PNG/Print/Bulk export all depend on it being
// unchanged). Highlighting here is pure CSS scoped under .invoice-annotated,
// targeting only ClassicTemplate's existing top-level classes
// (.invoice-doc-logo-slot / .invoice-doc-business / .invoice-doc-future-slots) -
// no new DOM structure is injected into the template itself.
function buildSampleInvoice(tenant) {
  const lineItems = [
    {
      id: "sample-1",
      description: "Sample Product or Service",
      unit: "Piece",
      quantity: 2,
      unitPrice: 250,
      taxRateName: "UAE Standard VAT",
      taxPercentage: 5,
      lineTotal: 525,
    },
    {
      id: "sample-2",
      description: "Sample Consulting Hours",
      unit: "Hour",
      quantity: 5,
      unitPrice: 100,
      taxRateName: "UAE Standard VAT",
      taxPercentage: 5,
      lineTotal: 525,
    },
  ];

  return {
    businessName: tenant?.name || "Your Business Name",
    businessAddress: tenant?.address || "Your Business Address",
    businessTrn: tenant?.trn || "100XXXXXXXXXXX3",
    businessContactEmail: tenant?.contactEmail || "you@yourbusiness.com",
    businessContactPhone: tenant?.contactPhone || "+971 4 000 0000",
    customerName: "Sample Customer LLC",
    customerAddress: "Sample Customer Address, Dubai, UAE",
    customerTrn: "100YYYYYYYYYYY4",
    invoiceNumberDisplay: "INV-SAMPLE",
    issueDate: new Date().toISOString(),
    dueDate: new Date().toISOString(),
    currency: "AED",
    status: "SENT",
    paymentStatus: "UNPAID",
    lineItems,
    subtotal: 1000,
    discountTotal: 0,
    vatTotal: 50,
    grandTotal: 1050,
    notes: "This is a sample invoice for preview purposes only.",
  };
}

const LEGEND = [
  { key: "logo", label: "Company Logo", copy: "Printed top-left of every invoice, once uploaded under Brand Assets." },
  { key: "business", label: "Business Name, Address, Contact & TRN", copy: "Your Business Information block - shown directly beside your logo." },
  { key: "future", label: "Signature & Company Stamp", copy: "Shown in the document footer once uploaded under Brand Assets." },
];

export default function InvoicePreviewModal({ open, onClose, tenant }) {
  const sampleInvoice = buildSampleInvoice(tenant);
  // Real assets if this tenant has uploaded any (2026-08-09) - tenant.logoUrl/
  // stampUrl/signatureUrl are already fully-qualified URLs, set by the
  // Business Profile page's own fetch, same shape ClassicTemplate expects
  // from every other caller.
  const businessAssets = { logoUrl: tenant?.logoUrl || null, stampUrl: tenant?.stampUrl || null, signatureUrl: tenant?.signatureUrl || null };

  return (
    <Modal open={open} onClose={onClose} size="lg" ariaLabel="Sample Invoice Preview">
      <div className="dialog-lg-header">
        <button type="button" className="dialog-lg-close" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <h2 style={{ marginBottom: 4 }}>Sample Invoice Preview</h2>
        <p className="form-section-desc">How your Business Profile information appears on a real invoice.</p>
      </div>

      <div className="dialog-lg-body">
        <div className="invoice-preview-legend">
          {LEGEND.map((item) => (
            <div className="invoice-preview-legend-item" key={item.key}>
              <span className={`invoice-preview-legend-dot invoice-preview-legend-dot-${item.key}`} aria-hidden="true" />
              <div>
                <strong>{item.label}</strong>
                <p className="helptext" style={{ margin: 0 }}>{item.copy}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="invoice-preview-canvas">
          <div className="invoice-annotated">
            <ClassicTemplate invoice={sampleInvoice} businessAssets={businessAssets} />
          </div>
        </div>
      </div>
    </Modal>
  );
}
