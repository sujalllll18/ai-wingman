import Tooltip from "./Tooltip";

// Shared stat-card primitive (2026-08-06, Platform Admin Phase 1) - extracted
// from the identical .kpi-card markup every list page (Invoices, Purchases,
// the old admin tenant list) was hand-rolling inline. Same classes/behavior
// those pages already used (.kpi-card-grid/.kpi-card/.kpi-card-top/
// .kpi-card-value), just no longer copy-pasted. Renders as a clickable
// filter-toggle button when `onClick` is given (matching the Invoices/
// Purchases "click a KPI to filter the table" pattern), otherwise as a
// static card.
export default function KpiCard({ label, value, icon, helptext, active = false, onClick, placeholder = false, placeholderTooltip = "Not available yet" }) {
  const valueEl = placeholder ? (
    <Tooltip label={placeholderTooltip}>
      <span className="kpi-card-value placeholder">—</span>
    </Tooltip>
  ) : (
    <span className="kpi-card-value">{value}</span>
  );

  const content = (
    <>
      <div className="kpi-card-top">
        <span className="kpi-card-label">{label}</span>
        {icon && <span className="kpi-card-icon">{icon}</span>}
      </div>
      {valueEl}
      {helptext && (
        <span className="helptext" style={{ marginTop: 0 }}>
          {helptext}
        </span>
      )}
    </>
  );

  if (typeof onClick === "function") {
    return (
      <button type="button" className={`card kpi-card card-hoverable list-kpi-button${active ? " active" : ""}`} onClick={onClick}>
        {content}
      </button>
    );
  }

  return <div className="card kpi-card">{content}</div>;
}
