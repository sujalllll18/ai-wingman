// onRowClick is optional (2026-08-06 Team polish) - existing callers
// (CategoriesTab, RatesTab, etc.) don't pass it and are unaffected. When
// provided, the whole row becomes a click target (cursor + keyboard access)
// in addition to whatever the row itself renders - a cell that needs its
// own click behavior (e.g. an Actions menu) should stopPropagation in its
// own handler so it doesn't also trigger the row click.
export default function Table({ columns, rows, rowKey = (row) => row.id, onRowClick }) {
  return (
    <table className="data-table">
      <thead>
        <tr>
          {columns.map((col) => (
            <th key={col.key} className={col.className}>
              {col.header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr
            key={rowKey(row)}
            className={onRowClick ? "row-clickable" : undefined}
            onClick={onRowClick ? () => onRowClick(row) : undefined}
            tabIndex={onRowClick ? 0 : undefined}
            onKeyDown={
              onRowClick
                ? (e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      onRowClick(row);
                    }
                  }
                : undefined
            }
          >
            {columns.map((col) => (
              <td key={col.key} className={col.className} data-label={col.header}>
                {col.render ? col.render(row) : row[col.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
