"use client";

import { useEffect, useRef } from "react";

// Generic overlay dialog. Pass size="lg" for the large centered wizard modal
// (900-1000px); default matches ConfirmationDialog's existing 420px dialog.
// className is optional and additive - lets one specific modal instance
// carry its own scoped styling hook (e.g. "tax-rate-modal") without
// affecting every other Modal caller.
export default function Modal({ open, onClose, size = "md", ariaLabel, className, children }) {
  const modalRef = useRef(null);
  const previouslyFocused = useRef(null);
  // Keeps the Escape handler current without making it an effect dependency —
  // onClose is a fresh function identity on every parent render (e.g. an
  // inline arrow prop), and re-running this effect on every keystroke was
  // re-stealing focus into the dialog container after each character typed.
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement;
    modalRef.current?.focus();

    function handleKeyDown(e) {
      if (e.key === "Escape") onCloseRef.current();
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      previouslyFocused.current?.focus();
    };
  }, [open]);

  if (!open) return null;

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div
        className={`dialog${size === "lg" ? " dialog-lg" : ""}${className ? ` ${className}` : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel}
        tabIndex={-1}
        ref={modalRef}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
