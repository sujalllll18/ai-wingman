export default function DataTable({
  columns,
  rows,
  rowKey = (row) => row.id,
  columnOrder,
  hiddenColumns,
  sortKey,
  sortDirection,
  onSortChange,
  stickyHeader,
  zebra,
}) {
  const visible = columnOrder.map((key) => columns.find((c) => c.key === key)).filter((c) => c && !hiddenColumns.includes(c.key));

  const classNames = ["data-table", "no-stack"];
  if (stickyHeader) classNames.push("sticky-header");
  if (zebra) classNames.push("zebra");

  return (
    <table className={classNames.join(" ")}>
      <thead>
        <tr>
          {visible.map((col) => (
            <th
              key={col.key}
              className={[col.align === "right" ? "num" : "", col.sortable ? "sortable" : ""].filter(Boolean).join(" ")}
              onClick={col.sortable && onSortChange ? () => onSortChange(col.key) : undefined}
              tabIndex={col.sortable && onSortChange ? 0 : undefined}
              onKeyDown={
                col.sortable && onSortChange
                  ? (e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        onSortChange(col.key);
                      }
                    }
                  : undefined
              }
            >
              {col.label}
              {col.sortable && sortKey === col.key && (
                <span className="sort-indicator">{sortDirection === "asc" ? "↑" : "↓"}</span>
              )}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr key={rowKey(row)}>
            {visible.map((col) => (
              <td key={col.key} className={col.align === "right" ? "num" : ""} data-label={col.label}>
                {col.render(row)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
