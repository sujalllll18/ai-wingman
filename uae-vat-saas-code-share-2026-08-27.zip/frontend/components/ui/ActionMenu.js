"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Tooltip from "./Tooltip";

const MENU_GAP = 4; // gap between trigger and popover, matches the old `calc(100% + 4px)`
const VIEWPORT_PADDING = 8; // keep the popover clear of the viewport edge

// Kebab (⋮) dropdown menu - first use in Ledger is the Team module (2026-08-06
// polish sprint), built as a shared primitive since the module's own brief
// asked to "reuse existing dropdown/menu components" and none existed yet.
// Items: { label, onClick, danger, disabled, disabledReason }. A disabled
// item shows a Tooltip explaining why, same "honest, not hidden" pattern
// used everywhere else in Ledger for not-yet-built actions.
//
// Positioning (2026-08-11 fix): the popover used to be `position: absolute`
// inside `.action-menu` (`position: relative`), which put it in the DOM
// under whatever scroll/overflow container the table lives in - every table
// wraps its rows in `.table-scroll` (`overflow-y: hidden`, see globals.css),
// so a menu opened near the bottom of a table got its lower half clipped by
// that container's own box edge. Fix is generic to this component, not any
// one page: the popover now renders through a portal straight onto
// `document.body` and is positioned with `position: fixed` from the
// trigger's real `getBoundingClientRect()`, so no ancestor's `overflow` can
// ever clip it again, and it flips to open upward when there isn't enough
// room below. The portal call stays nested inside the same JSX subtree as
// the trigger (just rendered elsewhere in the DOM), so React's tree-based
// event bubbling - not the DOM tree - still lets the wrapping div's
// `stopPropagation()` shield row click handlers from menu-item clicks.
export default function ActionMenu({ items, ariaLabel = "Actions" }) {
  const [open, setOpen] = useState(false);
  const [style, setStyle] = useState(null); // null until first measured post-open
  const rootRef = useRef(null); // wraps the trigger (and, via the portal, the popover in the React tree)
  const popoverRef = useRef(null);

  const reposition = useCallback(() => {
    const trigger = rootRef.current;
    const popover = popoverRef.current;
    if (!trigger || !popover) return;

    const triggerRect = trigger.getBoundingClientRect();
    const popoverRect = popover.getBoundingClientRect();

    const spaceBelow = window.innerHeight - triggerRect.bottom;
    const spaceAbove = triggerRect.top;
    const openUpward = spaceBelow < popoverRect.height + MENU_GAP + VIEWPORT_PADDING && spaceAbove > spaceBelow;

    const top = openUpward
      ? Math.max(VIEWPORT_PADDING, triggerRect.top - popoverRect.height - MENU_GAP)
      : Math.min(triggerRect.bottom + MENU_GAP, window.innerHeight - popoverRect.height - VIEWPORT_PADDING);

    // Right-align to the trigger's right edge (same look as the old
    // `right: 0`), clamped so it can never run off the left edge either.
    const maxLeft = window.innerWidth - popoverRect.width - VIEWPORT_PADDING;
    const left = Math.min(Math.max(triggerRect.right - popoverRect.width, VIEWPORT_PADDING), Math.max(maxLeft, VIEWPORT_PADDING));

    setStyle({ position: "fixed", top, left, right: "auto", visibility: "visible" });
  }, []);

  useEffect(() => {
    if (!open) {
      setStyle(null);
      return;
    }
    // Measure/position on the next tick, after the (initially hidden)
    // popover has mounted and has real dimensions to read.
    reposition();

    function handleClickOutside(e) {
      if (
        rootRef.current &&
        !rootRef.current.contains(e.target) &&
        popoverRef.current &&
        !popoverRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    function handleKeyDown(e) {
      if (e.key === "Escape") setOpen(false);
    }
    // `capture: true` so scrolling any ancestor (e.g. `.table-scroll`,
    // `.shell-main`, a modal body) is caught here too - scroll events don't
    // bubble, but they do fire during the capture phase on every ancestor.
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [open, reposition]);

  return (
    <div className="action-menu" ref={rootRef} onClick={(e) => e.stopPropagation()}>
      <button
        type="button"
        className="action-menu-trigger"
        aria-label={ariaLabel}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <svg viewBox="0 0 24 24">
          <circle cx="12" cy="5" r="1.6" />
          <circle cx="12" cy="12" r="1.6" />
          <circle cx="12" cy="19" r="1.6" />
        </svg>
      </button>

      {open &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            className="action-menu-popover"
            role="menu"
            ref={popoverRef}
            // Off-screen + invisible until `reposition()` measures it and
            // supplies real fixed coordinates - never flashes in the wrong
            // spot, just appears once at the right one. `right: "auto"` here
            // matters, not just cosmetic: without it the CSS class's own
            // `right: 0` combines with this `left: -9999px` to over-constrain
            // the box, which forces the browser to stretch its computed
            // width to fill the gap between them - so the very first
            // measurement `reposition()` takes would read a huge phantom
            // width instead of the real (min-width-driven) one.
            style={style || { position: "fixed", top: -9999, left: -9999, right: "auto", visibility: "hidden" }}
          >
            {items.map((item, i) =>
              item.disabled ? (
                <Tooltip key={i} label={item.disabledReason || "Not available yet"}>
                  <span className="action-menu-item disabled" role="menuitem" aria-disabled="true">
                    {item.label}
                  </span>
                </Tooltip>
              ) : (
                <button
                  key={i}
                  type="button"
                  role="menuitem"
                  className={`action-menu-item${item.danger ? " danger" : ""}`}
                  onClick={() => {
                    setOpen(false);
                    item.onClick?.();
                  }}
                >
                  {item.label}
                </button>
              )
            )}
          </div>,
          document.body
        )}
    </div>
  );
}
