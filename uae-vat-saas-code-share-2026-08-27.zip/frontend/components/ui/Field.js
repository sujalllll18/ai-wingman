import { cloneElement } from "react";

// Wraps a single Input/Select child, wiring up aria-invalid/aria-describedby
// so the error<->field relationship survives for a screen reader user
// (UX Blueprint §10) instead of being only visually adjacent.
export default function Field({ id, label, error, helptext, children, style }) {
  const describedBy = error ? `${id}-error` : helptext ? `${id}-help` : undefined;

  const control = cloneElement(children, {
    id,
    "aria-invalid": error ? "true" : undefined,
    "aria-describedby": describedBy,
  });

  return (
    <div className="field" style={style}>
      {label && <label htmlFor={id}>{label}</label>}
      {control}
      {error && (
        <p id={`${id}-error`} className="field-error" role="alert">
          {error}
        </p>
      )}
      {!error && helptext && (
        <p id={`${id}-help`} className="helptext">
          {helptext}
        </p>
      )}
    </div>
  );
}
