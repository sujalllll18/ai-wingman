// Consistent "not available yet" marker for sections that have no backend
// support today. Keeps that messaging uniform across every placeholder
// section instead of ad hoc text per tab.
export default function PlaceholderNotice({ children }) {
  return (
    <div className="placeholder-notice">
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 8v5M12 16h.01" />
      </svg>
      <span>{children}</span>
    </div>
  );
}
