"use client";

// Mobile-only topbar (hidden on desktop, where the sidebar is fixed and
// always visible — UX Blueprint §9). Its sole job is the hamburger trigger
// for the AppShell drawer.
export default function Header({ brand, onMenuClick }) {
  return (
    <header className="shell-header">
      <button className="shell-menu-btn" onClick={onMenuClick} aria-label="Open menu">
        ☰
      </button>
      <div className="shell-header-brand">
        Ledger
        <small>{brand}</small>
      </div>
    </header>
  );
}
