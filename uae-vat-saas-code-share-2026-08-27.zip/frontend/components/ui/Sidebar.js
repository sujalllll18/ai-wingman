"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

// A nav item may declare `children` (e.g. Settings -> Roles & Permissions /
// Approval Workflow) instead of its own `href` - rendered as a small
// expandable group rather than a direct link. Auto-expands whenever the
// current route is already inside it, so refreshing a child page never
// hides its own parent group. Purely structural (no RBAC awareness) since
// this component is shared with the Admin side, same as every other prop
// here - child visibility is already filtered upstream by TenantShell.
function NavGroup({ item, pathname, onClose }) {
  const containsCurrent = item.children.some((child) => pathname === child.href);
  const [open, setOpen] = useState(containsCurrent);

  return (
    <div className="nav-expand-group">
      <button
        type="button"
        className="nav-link nav-expand-trigger"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <span className="nav-icon">{item.icon}</span>
        <span className="nav-label">{item.label}</span>
        <svg className={`nav-expand-chevron${open ? " open" : ""}`} viewBox="0 0 24 24">
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>
      {open && (
        <div className="nav-expand-children">
          {item.children.map((child) => (
            <Link
              key={child.href}
              href={child.href}
              className="nav-link nav-link-child"
              aria-current={pathname === child.href ? "page" : undefined}
              onClick={onClose}
            >
              <span className="nav-label">{child.label}</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Sidebar({
  brand,
  businessName,
  logoUrl,
  navItems,
  futureItems,
  onLogout,
  drawerOpen,
  onClose,
  collapsed,
  onToggleCollapsed,
  userProfile,
}) {
  const pathname = usePathname();

  return (
    <aside className={`shell-sidebar${drawerOpen ? " shell-sidebar-open" : ""}${collapsed ? " collapsed" : ""}`}>
      <div className="sidebar-top">
        <div className="brand">
          {logoUrl ? (
            // Business Profile logo (2026-08-11) - only the tenant shell ever
            // passes logoUrl/businessName; Admin's Sidebar call site passes
            // neither, so it keeps the plain "L" mark + Ledger-primary layout
            // below unchanged.
            <img src={logoUrl} alt="" className="brand-mark brand-logo" />
          ) : (
            <span className="brand-mark">L</span>
          )}
          <span className="brand-text">
            {businessName || "Ledger"}
            <small>{businessName ? "Ledger" : brand}</small>
          </span>
        </div>
        {onToggleCollapsed && (
          <button
            type="button"
            className="sidebar-collapse-btn"
            onClick={onToggleCollapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-pressed={collapsed}
          >
            <svg viewBox="0 0 24 24">
              <path d="M15 6l-6 6 6 6" />
            </svg>
          </button>
        )}
      </div>
      <nav>
        {navItems.map((item) =>
          item.children ? (
            <NavGroup key={item.label} item={item} pathname={pathname} onClose={onClose} />
          ) : (
            <Link
              key={item.href}
              href={item.href}
              className="nav-link"
              aria-current={pathname === item.href ? "page" : undefined}
              onClick={onClose}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </Link>
          )
        )}

        {futureItems && futureItems.length > 0 && (
          <>
            <div className="nav-group-label nav-label">Future modules</div>
            {futureItems.map((item) => (
              <span key={item.label} className="nav-link-disabled" aria-disabled="true">
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </span>
            ))}
          </>
        )}
      </nav>
      {userProfile && (
        <div className="sidebar-user-profile">
          <span className="sidebar-user-avatar" aria-hidden="true">
            {(userProfile.name || "?").charAt(0).toUpperCase()}
          </span>
          <span className="sidebar-user-info">
            <span className="sidebar-user-name">{userProfile.name}</span>
            <span className="sidebar-user-meta">{userProfile.roleLabel || userProfile.email}</span>
          </span>
        </div>
      )}
      <button className="logout" onClick={onLogout}>
        Log out
      </button>
    </aside>
  );
}
