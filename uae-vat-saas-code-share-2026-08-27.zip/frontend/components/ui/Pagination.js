// Shared pagination footer (2026-08-06) - extracted from the inline markup
// Invoices/Purchases/VAT Returns each duplicated, per the Team module
// brief's explicit "this should become the standard pagination component
// used throughout Ledger." Same classes/behavior those pages already used
// (.table-pagination/.pagination-pages/.page-btn), just no longer copy-pasted.
// Existing pages keep their own inline copy for now - not in this sprint's
// scope to retrofit them.
const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

export default function Pagination({ page, pageSize, totalItems, onPageChange, onPageSizeChange, itemLabel = "items", pageSizeOptions = PAGE_SIZE_OPTIONS }) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;

  return (
    <div className="table-pagination">
      <span>
        {totalItems === 0
          ? `No ${itemLabel}`
          : `Showing ${pageStart + 1}–${Math.min(pageStart + pageSize, totalItems)} of ${totalItems} ${itemLabel}`}
      </span>
      <div className="pagination-controls">
        <div className="rows-per-page">
          Rows per page
          <select className="select-filter" value={pageSize} onChange={(e) => onPageSizeChange(Number(e.target.value))}>
            {pageSizeOptions.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </div>
        <div className="pagination-pages">
          <button className="page-btn" disabled={currentPage === 1} onClick={() => onPageChange(1)} aria-label="First page">
            «
          </button>
          <button className="page-btn" disabled={currentPage === 1} onClick={() => onPageChange(currentPage - 1)} aria-label="Previous page">
            ‹
          </button>
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} className={`page-btn${currentPage === i + 1 ? " active" : ""}`} onClick={() => onPageChange(i + 1)}>
              {i + 1}
            </button>
          ))}
          <button className="page-btn" disabled={currentPage === totalPages} onClick={() => onPageChange(currentPage + 1)} aria-label="Next page">
            ›
          </button>
          <button className="page-btn" disabled={currentPage === totalPages} onClick={() => onPageChange(totalPages)} aria-label="Last page">
            »
          </button>
        </div>
      </div>
    </div>
  );
}
