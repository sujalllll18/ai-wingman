export default function StepWizard({ steps, currentStep }) {
  return (
    <div className="wizard-steps">
      {steps.map((label, i) => (
        <span key={label} style={{ display: "contents" }}>
          {i > 0 && <span className="wizard-sep">›</span>}
          <span className={`wizard-step ${i <= currentStep ? "active" : ""}`}>
            {i + 1}. {label}
          </span>
        </span>
      ))}
    </div>
  );
}
