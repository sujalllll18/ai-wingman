export default function EmptyState({ icon, title, description, action, children }) {
  if (!icon && !title && !action) {
    return <div className="empty-state">{children}</div>;
  }

  return (
    <div className="empty-state">
      {icon && <div className="empty-icon">{icon}</div>}
      {title && <h3>{title}</h3>}
      {description && <p>{description}</p>}
      {children}
      {action}
    </div>
  );
}
