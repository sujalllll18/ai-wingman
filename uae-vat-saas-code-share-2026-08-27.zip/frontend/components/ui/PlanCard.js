import { formatPlanPrice } from "../../lib/plans";

// Shared pricing card (2026-08-06, Platform Admin Phase 1) - replaces the
// plan-card markup that was duplicated verbatim in app/admin/tenants/new/
// page.js and components/TenantOnboardingModal.js. Same .plan-card CSS,
// just data-driven from lib/plans.js's richer catalog (monthly/yearly
// price, trial period, included modules, user/storage/OCR/API limits)
// instead of the old plain name/price/features-string shape.
export default function PlanCard({ plan, billingCycle = "monthly", selected, onSelect }) {
  const price = billingCycle === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;
  const priceSuffix = price ? (billingCycle === "yearly" ? " / year" : " / month") : "";

  return (
    <button type="button" className={`plan-card${selected ? " selected" : ""}`} onClick={onSelect}>
      <h3>{plan.name}</h3>
      <div className="plan-card-price">
        {formatPlanPrice(price)}
        {priceSuffix}
        {plan.trialDays > 0 && (
          <span className="badge badge-premium" style={{ marginLeft: 8 }}>
            {plan.trialDays}-day trial
          </span>
        )}
      </div>
      <ul>
        <li>{plan.userLimit ? `${plan.userLimit} users` : "Unlimited users"}</li>
        <li>{plan.storageLimitGb} GB storage</li>
        <li>{plan.ocrCredits.toLocaleString()} OCR credits / month</li>
        <li>{plan.apiLimitPerMonth.toLocaleString()} API calls / month</li>
        <li style={{ marginTop: 6, color: "var(--color-ink-faint)" }}>Includes: {plan.modules.join(", ")}</li>
      </ul>
      <div className="plan-card-cta">{selected ? "Selected" : "Select"}</div>
    </button>
  );
}
