// Enterprise on/off toggle (2026-08-07, Platform Admin Phase 2 Module
// Builder) - no toggle-switch primitive existed anywhere in Ledger before
// this; every other on/off control in the app is a plain checkbox
// (.checkbox-row), which doesn't read as an "enterprise toggle" for a
// module/feature access grid. New primitive, not a duplicate of anything.
export default function ToggleSwitch({ checked, onChange, disabled, ariaLabel }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      className={`toggle-switch${checked ? " on" : ""}`}
      onClick={() => onChange(!checked)}
    >
      <span className="toggle-switch-thumb" />
    </button>
  );
}
