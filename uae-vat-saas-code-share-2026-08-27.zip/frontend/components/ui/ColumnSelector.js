"use client";

import { useEffect, useRef, useState } from "react";

function moveKey(order, key, delta) {
  const idx = order.indexOf(key);
  const newIdx = idx + delta;
  if (newIdx < 0 || newIdx >= order.length) return order;
  const newOrder = [...order];
  [newOrder[idx], newOrder[newIdx]] = [newOrder[newIdx], newOrder[idx]];
  return newOrder;
}

export default function ColumnSelector({ columns, columnOrder, hiddenColumns, onToggle, onReorder }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    function handleKey(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, []);

  const ordered = columnOrder.map((key) => columns.find((c) => c.key === key)).filter(Boolean);

  function handleDrop(e, targetKey) {
    e.preventDefault();
    const draggedKey = e.dataTransfer.getData("text/plain");
    if (!draggedKey || draggedKey === targetKey) return;
    const newOrder = columnOrder.filter((k) => k !== draggedKey);
    newOrder.splice(newOrder.indexOf(targetKey), 0, draggedKey);
    onReorder(newOrder);
  }

  return (
    <div className="column-selector" ref={ref}>
      <button type="button" className="btn btn-outline btn-sm" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <svg viewBox="0 0 24 24" style={{ width: 15, height: 15 }}>
          <path d="M4 6h16M4 12h16M4 18h16" />
        </svg>
        Columns
      </button>
      {open && (
        <div className="column-selector-panel">
          <div className="column-selector-title">Show &amp; reorder columns</div>
          {ordered.map((col, i) => (
            <div
              key={col.key}
              className="column-selector-row"
              draggable={!col.alwaysVisible}
              onDragStart={(e) => e.dataTransfer.setData("text/plain", col.key)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => handleDrop(e, col.key)}
            >
              <label>
                <input
                  type="checkbox"
                  checked={!hiddenColumns.includes(col.key)}
                  disabled={col.alwaysVisible}
                  onChange={() => onToggle(col.key)}
                />
                {col.label}
              </label>
              <div className="column-selector-reorder">
                <button
                  type="button"
                  disabled={i === 0}
                  onClick={() => onReorder(moveKey(columnOrder, col.key, -1))}
                  aria-label={`Move ${col.label} up`}
                >
                  <svg viewBox="0 0 24 24">
                    <path d="M18 15l-6-6-6 6" />
                  </svg>
                </button>
                <button
                  type="button"
                  disabled={i === ordered.length - 1}
                  onClick={() => onReorder(moveKey(columnOrder, col.key, 1))}
                  aria-label={`Move ${col.label} down`}
                >
                  <svg viewBox="0 0 24 24">
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
