"use client";

import { useEffect, useState } from "react";

// Fixes the classic "0 -> type 15 -> 015" bug present anywhere a numeric
// <input type="number"> is a controlled React component whose `value` is a
// JS Number (see Plan Builder's General/Billing/Usage Limits tabs, all of
// which did `value={version.monthlyPrice}` / `onChange={(e) =>
// onVersionChange({ ...version, monthlyPrice: Number(e.target.value) })}`
// before this fix).
//
// Root cause: when React sets a controlled <input type="number">'s DOM
// value to a number that is *numerically* equal to what's already typed in
// the field (e.g. field shows "01", React sets value to 1), some browsers
// don't visibly update the displayed text, because 01 and 1 represent the
// same number to the input's own sanitization algorithm. The stale "01"
// stays on screen, so the next keystroke appends onto it instead of
// replacing it - "0" + "1" + "5" typed in sequence becomes "01" then
// "015", never correcting itself.
//
// Fix: never let the DOM value round-trip through a bare Number and back.
// This component owns its own draft STRING (so a leading zero is stripped
// the moment a further digit is typed, before it can ever accumulate) and
// only re-syncs from the external `value` prop when that prop changes for
// a reason OTHER than this component's own onChange (e.g. switching to a
// different plan version). Preserves in-progress decimal typing ("12.",
// "12.5") which a bare Number(...) round-trip would otherwise mangle by
// silently dropping the trailing ".".
export default function NumberInput({ value, onChange, allowEmpty = false, ...props }) {
  const toDraftString = (v) => (v === null || v === undefined ? "" : String(v));
  const [draft, setDraft] = useState(toDraftString(value));

  // Re-sync only when the external value doesn't match what this draft
  // already represents - keeps mid-typing states ("12.", "") alive across
  // the parent's own re-render instead of being clobbered by it.
  useEffect(() => {
    const draftNumber = draft === "" || draft === "-" ? null : Number(draft);
    if (draftNumber !== (value ?? null)) {
      setDraft(toDraftString(value));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  function handleChange(e) {
    let raw = e.target.value;
    // Strip a leading zero the instant a further digit follows it
    // (015 -> 15) - never touches a lone "0" or a "0.5"-style decimal,
    // since the lookahead requires another DIGIT, not a decimal point.
    raw = raw.replace(/^(-?)0+(?=\d)/, "$1");
    setDraft(raw);

    if (raw === "" || raw === "-" || raw === "." || raw === "-.") {
      if (allowEmpty) onChange(null);
      return;
    }
    const parsed = Number(raw);
    if (!Number.isNaN(parsed)) onChange(parsed);
  }

  // If the field is left empty on blur and empty isn't a valid state for
  // it, snap the displayed text back to the last real value instead of
  // staying blank forever - without this, a field that's cleared then
  // blurred without typing a new number shows an empty box indefinitely
  // even though the underlying value never actually changed (onChange is
  // never called for an empty, non-allowEmpty field - see handleChange).
  function handleBlur(e) {
    if (!allowEmpty && (draft === "" || draft === "-")) {
      setDraft(toDraftString(value));
    }
    props.onBlur?.(e);
  }

  return <input type="number" {...props} value={draft} onChange={handleChange} onBlur={handleBlur} />;
}
