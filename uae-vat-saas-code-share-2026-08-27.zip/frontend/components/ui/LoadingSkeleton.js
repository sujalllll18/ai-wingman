export default function LoadingSkeleton({ rows = 5, columns = 4 }) {
  return (
    <table aria-busy="true" aria-label="Loading">
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r}>
            {Array.from({ length: columns }).map((_, c) => (
              <td key={c}>
                <div className="skeleton-bar" />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
