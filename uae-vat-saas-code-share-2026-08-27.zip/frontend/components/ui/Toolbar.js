export default function Toolbar({ title, searchValue, onSearchChange, searchPlaceholder = "Search…", filters, action }) {
  return (
    <div className="table-toolbar">
      <span className="toolbar-title">{title}</span>
      {onSearchChange && (
        <div className="toolbar-search">
          <svg viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="7" />
            <path d="M21 21l-4.3-4.3" />
          </svg>
          <input type="search" placeholder={searchPlaceholder} value={searchValue} onChange={onSearchChange} />
        </div>
      )}
      {filters}
      {action}
    </div>
  );
}
