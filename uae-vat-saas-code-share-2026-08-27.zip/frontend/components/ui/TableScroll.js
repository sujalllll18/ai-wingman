// Reusable horizontal-scroll wrapper for any table/grid whose natural width
// can exceed the available content width (2026-08-06 app-wide scrolling
// fix). Every module wraps its table in this instead of hand-writing
// <div className="table-scroll"> - one component, one CSS rule (.table-scroll
// in globals.css), inherited everywhere instead of fixed per page. Scrolling
// is scoped to just the table; the page itself never scrolls horizontally.
export default function TableScroll({ children, style }) {
  return (
    <div className="table-scroll" style={style}>
      {children}
    </div>
  );
}
