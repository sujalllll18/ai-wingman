"use client";

import { useState } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { useLocalStorageState } from "../../hooks/useLocalStorageState";

// Shared shell for both the Admin and Tenant apps: fixed sidebar on desktop,
// hamburger-triggered overlay drawer below 1024px (UX Blueprint §9).
export default function AppShell({ brand, businessName, logoUrl, navItems, futureItems, onLogout, children, wide, userProfile }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [collapsed, setCollapsed] = useLocalStorageState("ledger_sidebar_collapsed", false);

  return (
    <div className="shell">
      <Header brand={brand} onMenuClick={() => setDrawerOpen(true)} />
      <Sidebar
        brand={brand}
        businessName={businessName}
        logoUrl={logoUrl}
        navItems={navItems}
        futureItems={futureItems}
        onLogout={onLogout}
        drawerOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((c) => !c)}
        userProfile={userProfile}
      />
      {drawerOpen && <div className="shell-scrim" onClick={() => setDrawerOpen(false)} />}
      <main className={`shell-main${wide ? " shell-main-wide" : ""}`}>{children}</main>
    </div>
  );
}
