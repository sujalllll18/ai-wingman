export default function Tabs({ tabs, activeKey, onChange }) {
  return (
    <div className="profile-tabs" role="tablist">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          type="button"
          role="tab"
          id={`tab-${tab.key}`}
          aria-selected={tab.key === activeKey}
          aria-controls={`tabpanel-${tab.key}`}
          className={`profile-tab${tab.key === activeKey ? " active" : ""}`}
          onClick={() => onChange(tab.key)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
