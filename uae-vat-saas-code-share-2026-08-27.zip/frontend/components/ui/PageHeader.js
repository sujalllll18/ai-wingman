// Breadcrumbs removed (2026-08-04 UI Polish Sprint) - page title only, per
// the sprint's explicit "show only the page title" requirement. `breadcrumb`
// is still accepted (every page still passes one) but deliberately ignored
// here rather than stripped from 20+ call sites for a purely cosmetic no-op.
export default function PageHeader({ title, description, action, eyebrow }) {
  return (
    <div className="page-header">
      <div>
        {eyebrow && <span className="page-eyebrow">{eyebrow}</span>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  );
}
