"use client";

import { useEffect, useRef, useState } from "react";

// Generic hover-or-click info popover (first used by Business Profile's
// completion card, 2026-08-06 UI polish pass). Hover opens it for a quick
// glance; click toggles a "pinned" open state for touch/keyboard users,
// closed by an outside click or Escape - same interaction pattern already
// established by ActionMenu.js, just for read-only content instead of actions.
export default function InfoPopover({ children, align = "end", ariaLabel = "More information" }) {
  // Hover and click are independent signals that combine with OR, not one
  // toggle shared by both - otherwise a click right after the hover-open
  // (the trigger is already hovered when clicked) immediately flips it back
  // closed. Click "pins" it open past mouseleave; hovering alone still works
  // without pinning anything.
  const [hovered, setHovered] = useState(false);
  const [pinned, setPinned] = useState(false);
  const open = hovered || pinned;
  const rootRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    function handleClickOutside(e) {
      if (rootRef.current && !rootRef.current.contains(e.target)) {
        setPinned(false);
        setHovered(false);
      }
    }
    function handleKeyDown(e) {
      if (e.key === "Escape") {
        setPinned(false);
        setHovered(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  return (
    <span className="info-popover" ref={rootRef} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
      <button
        type="button"
        className="info-popover-trigger"
        aria-label={ariaLabel}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setPinned((v) => !v)}
      >
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 10.5v6" />
          <circle cx="12" cy="7.3" r="0.75" fill="currentColor" stroke="none" />
        </svg>
      </button>
      {open && (
        <div className={`info-popover-panel info-popover-panel-${align}`} role="dialog">
          {children}
        </div>
      )}
    </span>
  );
}
