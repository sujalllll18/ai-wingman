import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

function buildTaxBreakdown(lineItems) {
  const groups = new Map();
  for (const li of lineItems) {
    const key = `${li.taxRateName || "No tax"}|${li.taxPercentage}`;
    const existing = groups.get(key) || { name: li.taxRateName || "No tax", percentage: li.taxPercentage, taxableAmount: 0, taxAmount: 0 };
    existing.taxableAmount += li.lineTaxableAmount;
    existing.taxAmount += li.lineTaxAmount;
    groups.set(key, existing);
  }
  return Array.from(groups.values());
}

// Mirrors invoice-templates/ClassicTemplate.js's structure exactly (same
// rendering source for the Viewer/PDF pipeline) - the differences are the
// "CREDIT NOTE" document title, the Original Invoice reference row, and the
// Reason field, both required by the spec. Reads only the credit note's own
// stored snapshot fields (business/customer name copied at creation,
// line-item tax snapshot copied from the source Invoice line) - never
// re-derives from a live Invoice/Customer/Tax Master lookup.
const CreditNoteClassicTemplate = forwardRef(function CreditNoteClassicTemplate({ creditNote, businessAssets = {} }, ref) {
  const taxBreakdown = buildTaxBreakdown(creditNote.lineItems || []);
  const watermark = creditNote.status === "VOID" ? "CANCELLED" : creditNote.status === "DRAFT" ? "DRAFT" : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden={!businessAssets.logoUrl}>
            {businessAssets.logoUrl && <img src={businessAssets.logoUrl} alt="Company logo" />}
          </div>
          <div className="invoice-doc-business">
            <strong>{creditNote.businessName}</strong>
            {creditNote.businessAddress && <span>{creditNote.businessAddress}</span>}
            {creditNote.businessTrn && <span>TRN: {creditNote.businessTrn}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>TAX CREDIT NOTE</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Credit Note #</td>
                <td className="mono">{creditNote.creditNoteNumberDisplay || "DRAFT"}</td>
              </tr>
              <tr>
                <td>Original Invoice #</td>
                <td className="mono">{creditNote.invoice?.invoiceNumberDisplay}</td>
              </tr>
              <tr>
                <td>Issue Date</td>
                <td>{formatDate(creditNote.issueDate)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="invoice-doc-parties">
        <div>
          <span className="invoice-doc-label">Customer</span>
          <strong>{creditNote.customerName}</strong>
          {creditNote.customerAddress && <span>{creditNote.customerAddress}</span>}
          {creditNote.customerTrn && <span>TRN: {creditNote.customerTrn}</span>}
        </div>
        <div>
          <span className="invoice-doc-label">Reason</span>
          <span>{creditNote.reason}</span>
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Description</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(creditNote.lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, creditNote.currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              {/* lineNetAmount, not lineTotal - same reconciliation fix as
                  invoice-templates/ClassicTemplate.js (2026-08-11). */}
              <td className="num">{formatCurrency(li.lineNetAmount, creditNote.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        {taxBreakdown.length > 0 && (
          <table className="invoice-doc-tax-breakdown">
            <thead>
              <tr>
                <th>Tax Breakdown</th>
                <th className="num">Taxable Amount</th>
                <th className="num">Tax</th>
              </tr>
            </thead>
            <tbody>
              {taxBreakdown.map((g) => (
                <tr key={g.name}>
                  <td>
                    {g.name} ({g.percentage}%)
                  </td>
                  <td className="num">{formatCurrency(g.taxableAmount, creditNote.currency)}</td>
                  <td className="num">{formatCurrency(g.taxAmount, creditNote.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Subtotal</td>
              <td className="num">{formatCurrency(creditNote.subtotal, creditNote.currency)}</td>
            </tr>
            <tr>
              <td>VAT</td>
              <td className="num">{formatCurrency(creditNote.vatTotal, creditNote.currency)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>Total Credit</td>
              <td className="num">{formatCurrency(creditNote.grandTotal, creditNote.currency)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {creditNote.notes && (
        <div className="invoice-doc-notes">
          <span className="invoice-doc-label">Notes</span>
          <p>{creditNote.notes}</p>
        </div>
      )}

      {(businessAssets.signatureUrl || businessAssets.stampUrl) && (
        <div className="invoice-doc-signoff">
          {businessAssets.signatureUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.signatureUrl} alt="Authorized signature" />
              <span>Authorized Signatory</span>
            </div>
          )}
          {businessAssets.stampUrl && (
            <div className="invoice-doc-signoff-item">
              <img src={businessAssets.stampUrl} alt="Company stamp" />
              <span>Company Stamp</span>
            </div>
          )}
        </div>
      )}

      <div className="invoice-doc-footer">
        <span>This is a computer-generated credit note.</span>
      </div>
    </div>
  );
});

export default CreditNoteClassicTemplate;
