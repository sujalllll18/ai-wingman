import ClassicTemplate from "./ClassicTemplate";

export const CREDIT_NOTE_TEMPLATES = {
  classic: { label: "Classic", component: ClassicTemplate },
};

export const DEFAULT_CREDIT_NOTE_TEMPLATE = "classic";

export function getCreditNoteTemplateComponent(key) {
  return CREDIT_NOTE_TEMPLATES[key]?.component || CREDIT_NOTE_TEMPLATES[DEFAULT_CREDIT_NOTE_TEMPLATE].component;
}
