// Shared status vocabulary for the Reconciliation Engine (Phase 4,
// 2026-08-23) - covers both BankTransaction.reconciliationStatus (all 6
// values) and Payment/PurchasePayment.reconciliationStatus (a 3-value
// subset of the same words), so every screen renders the same badge for the
// same word instead of each page inventing its own label/color map (the
// pre-Phase-4 pattern this replaces, see banking/transactions/page.js's old
// RECON_LABEL/RECON_CLASS constants).
export const RECON_LABEL = {
  UNMATCHED: "Unmatched",
  SUGGESTED: "Suggested",
  MATCHED: "Matched",
  RECONCILED: "Reconciled",
  PARTIALLY_RECONCILED: "Partially Reconciled",
  IGNORED: "Ignored",
  UNRECONCILED: "Unreconciled",
  NOT_RECEIVED: "Not Received",
  NOT_PAID: "Not Paid",
};

export const RECON_CLASS = {
  UNMATCHED: "badge-info",
  SUGGESTED: "badge-premium",
  MATCHED: "badge-premium",
  RECONCILED: "badge-success",
  PARTIALLY_RECONCILED: "badge-warning",
  IGNORED: "badge-danger",
  UNRECONCILED: "badge-info",
  NOT_RECEIVED: "",
  NOT_PAID: "",
};

export default function ReconciliationStatusBadge({ status }) {
  return <span className={`badge ${RECON_CLASS[status] ?? "badge-info"}`}>{RECON_LABEL[status] || status}</span>;
}
