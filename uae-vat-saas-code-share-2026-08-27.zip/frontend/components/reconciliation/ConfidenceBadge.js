// Deliberately a coarse HIGH/MEDIUM/LOW label, never the raw numeric score -
// the brief is explicit that this is not meant to read as a claimed
// precision percentage (reconciliationEngine.service.js's score is a
// heuristic weighted-signal total, not a calibrated probability).
const CLASS = { HIGH: "badge-success", MEDIUM: "badge-warning", LOW: "badge-info" };
const LABEL = { HIGH: "High confidence", MEDIUM: "Medium confidence", LOW: "Low confidence" };

export default function ConfidenceBadge({ confidence, compact = false }) {
  if (!confidence) return null;
  return <span className={`badge ${CLASS[confidence] || "badge-info"}`}>{compact ? confidence : LABEL[confidence] || confidence}</span>;
}
