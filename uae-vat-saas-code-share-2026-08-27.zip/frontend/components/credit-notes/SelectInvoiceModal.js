"use client";

import Modal from "../ui/Modal";
import Button from "../ui/Button";
import EligibleInvoicePicker from "./EligibleInvoicePicker";

// Modal chrome around EligibleInvoicePicker, used by the Credit Notes list
// page's "+ New Credit Note" CTA. The same picker is also used un-wrapped
// (inline, no modal) on /tenant/credit-notes/new when it's reached without
// an ?invoiceId - one picker component, two presentations.
export default function SelectInvoiceModal({ open, onClose, onSelect }) {
  return (
    <Modal open={open} onClose={onClose} size="lg" ariaLabel="Select Original Invoice">
      <h2 style={{ marginBottom: 4 }}>Select Original Invoice</h2>
      <p className="helptext" style={{ marginBottom: 20 }}>
        Choose the Sent invoice this Credit Note should reduce.
      </p>
      <div style={{ maxHeight: "60vh", overflowY: "auto" }}>
        <EligibleInvoicePicker onSelect={onSelect} />
      </div>
      <div className="dialog-actions">
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
      </div>
    </Modal>
  );
}
