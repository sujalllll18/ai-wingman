"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { computeCreditEligibilityMap } from "../../lib/creditNoteEligibility";
import ErrorBanner from "../ui/ErrorBanner";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import EmptyState from "../ui/EmptyState";
import Toolbar from "../ui/Toolbar";
import Table from "../ui/Table";
import TableScroll from "../ui/TableScroll";
import Button from "../ui/Button";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Step 1 of the Credit Note creation wizard: "Select Original Invoice".
// Only ever lists Sent invoices with a positive remaining creditable amount
// - Draft/Cancelled invoices and fully-credited Sent invoices are never
// shown, per spec. Reuses listInvoices/listCreditNotes exactly as every
// other traceability surface in this module already does (no new endpoint).
export default function EligibleInvoicePicker({ onSelect }) {
  const [invoices, setInvoices] = useState(null);
  const [creditNotes, setCreditNotes] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [creditStatusFilter, setCreditStatusFilter] = useState("ALL"); // ALL | UNCREDITED | PARTIAL
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(() => {
    (async () => {
      setError("");
      try {
        const token = tenantAuth.get();
        const [{ invoices }, { creditNotes }] = await Promise.all([api.listInvoices(token, { archived: false }), api.listCreditNotes(token)]);
        setInvoices(invoices);
        setCreditNotes(creditNotes);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  const eligibilityMap = useMemo(() => computeCreditEligibilityMap(invoices || [], creditNotes || []), [invoices, creditNotes]);

  const eligible = useMemo(() => {
    if (!invoices) return [];
    return invoices
      .filter((i) => i.status === "SENT")
      .map((i) => ({ ...i, ...eligibilityMap.get(i.id) }))
      .filter((i) => i.remaining > 0.01);
  }, [invoices, eligibilityMap]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return eligible.filter((i) => {
      const matchesSearch =
        !q || (i.invoiceNumberDisplay || "").toLowerCase().includes(q) || i.customerName.toLowerCase().includes(q) || (i.customerTrn || "").toLowerCase().includes(q);
      const matchesCreditStatus =
        creditStatusFilter === "ALL" ||
        (creditStatusFilter === "UNCREDITED" && i.credited <= 0.01) ||
        (creditStatusFilter === "PARTIAL" && i.credited > 0.01);
      const issueTime = i.issueDate ? new Date(i.issueDate).getTime() : null;
      const matchesFrom = !dateFrom || (issueTime !== null && issueTime >= new Date(dateFrom).getTime());
      const matchesTo = !dateTo || (issueTime !== null && issueTime <= new Date(dateTo).getTime() + 86399999);
      return matchesSearch && matchesCreditStatus && matchesFrom && matchesTo;
    });
  }, [eligible, search, creditStatusFilter, dateFrom, dateTo]);

  const COLUMNS = useMemo(
    () => [
      { key: "invoiceNumberDisplay", header: "Invoice #", render: (i) => <span className="mono" style={{ fontWeight: 600 }}>{i.invoiceNumberDisplay}</span> },
      { key: "customerName", header: "Customer", render: (i) => i.customerName },
      { key: "issueDate", header: "Date", render: (i) => formatDate(i.issueDate) },
      { key: "status", header: "Status", render: () => <span className="badge badge-success">Sent</span> },
      { key: "grandTotal", header: "Invoice Total", className: "num", render: (i) => formatCurrency(i.grandTotal, i.currency) },
      { key: "credited", header: "Already Credited", className: "num", render: (i) => formatCurrency(i.credited, i.currency) },
      { key: "remaining", header: "Available to Credit", className: "num", render: (i) => <strong>{formatCurrency(i.remaining, i.currency)}</strong> },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (i) => (
          <Button variant="outline" onClick={() => onSelect(i)}>
            Select
          </Button>
        ),
      },
    ],
    [onSelect]
  );

  if (error) return <ErrorBanner message={error} />;
  if (invoices === null) return <LoadingSkeleton columns={6} />;

  if (eligible.length === 0) {
    return (
      <EmptyState
        icon={
          <svg viewBox="0 0 24 24">
            <path d="M21 3 3 10.5l7.5 3L14 21z" />
            <path d="M21 3 10.5 13.5" />
          </svg>
        }
        title="No eligible invoices"
        description="Only Sent invoices with a remaining creditable amount can have a Credit Note raised against them. Draft, Cancelled, and fully-credited invoices never appear here."
      />
    );
  }

  return (
    <div className="table-block">
      <Toolbar
        title="Select Original Invoice"
        searchValue={search}
        onSearchChange={(e) => setSearch(e.target.value)}
        searchPlaceholder="Search by invoice #, customer, or TRN…"
        filters={
          <>
            <select className="select-filter" value={creditStatusFilter} onChange={(e) => setCreditStatusFilter(e.target.value)}>
              <option value="ALL">All eligible invoices</option>
              <option value="UNCREDITED">Not yet credited</option>
              <option value="PARTIAL">Partially credited</option>
            </select>
            <input type="date" className="select-filter" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} aria-label="Issue date from" />
            <input type="date" className="select-filter" value={dateTo} onChange={(e) => setDateTo(e.target.value)} aria-label="Issue date to" />
          </>
        }
      />

      {filtered.length === 0 ? (
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="7" />
              <path d="M21 21l-4.3-4.3" />
            </svg>
          }
          title="No matching invoices"
          description="Try a different search term or clear the filters."
        />
      ) : (
        <TableScroll>
          <Table columns={COLUMNS} rows={filtered} onRowClick={(i) => onSelect(i)} />
        </TableScroll>
      )}
    </div>
  );
}
