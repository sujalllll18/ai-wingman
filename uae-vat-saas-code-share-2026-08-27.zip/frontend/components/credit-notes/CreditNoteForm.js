"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { useToast } from "../../hooks/useToast";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import StepWizard from "../ui/StepWizard";
import AdjustmentSummaryCard from "../notes/AdjustmentSummaryCard";
import NoteLineItemsTable from "../notes/NoteLineItemsTable";
import EligibleInvoicePicker from "./EligibleInvoicePicker";

const STEP_LABELS = ["Select Invoice", "Review", "Create Adjustment", "Review & Issue"];

const REASON_OPTIONS = [
  "Customer return",
  "Pricing correction",
  "Quantity correction",
  "Invoice cancellation/adjustment",
  "VAT correction",
  "Other",
];

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// Full creation wizard: Select Original Invoice -> Review -> Create
// Adjustment -> Review & Issue. Reached two ways: with no invoiceId (the
// Credit Notes list page's "+ New Credit Note" CTA / bare /new URL), which
// starts at step 0's invoice picker; or with an invoiceId already supplied
// (Invoice detail's "Issue Credit Note" button, or the Invoice list row
// menu's "Create Credit Note"), which skips straight to step 1 - same
// destination flow either way, just a different entry point.
export default function CreditNoteForm({ invoiceId: initialInvoiceId }) {
  const router = useRouter();
  const { showToast } = useToast();

  const [invoiceId, setInvoiceId] = useState(initialInvoiceId || null);
  const [step, setStep] = useState(initialInvoiceId ? 1 : 0);
  const [invoice, setInvoice] = useState(null);
  const [previouslyCredited, setPreviouslyCredited] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reasonChoice, setReasonChoice] = useState("");
  const [reasonOther, setReasonOther] = useState("");
  const [issueDate, setIssueDate] = useState("");
  const [notes, setNotes] = useState("");
  // { [lineItemId]: { checked, quantity } }
  const [selection, setSelection] = useState({});

  useEffect(() => {
    if (invoiceId) load(invoiceId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoiceId]);

  async function load(id) {
    setError("");
    setInvoice(null);
    try {
      const token = tenantAuth.get();
      const [{ invoice: inv }, { creditNotes }] = await Promise.all([api.getInvoice(token, id), api.listCreditNotes(token)]);
      setInvoice(inv);
      const already = round2(
        creditNotes.filter((c) => c.invoiceId === id && c.status === "ISSUED").reduce((s, c) => s + c.grandTotal, 0)
      );
      setPreviouslyCredited(already);
      const initial = {};
      for (const li of inv.lineItems) {
        initial[li.id] = { checked: false, quantity: li.quantity };
      }
      setSelection(initial);
    } catch (err) {
      setError(err.message);
    }
  }

  function handleSelectInvoice(inv) {
    setError("");
    setInvoiceId(inv.id);
    setStep(1);
    router.replace(`/tenant/credit-notes/new?invoiceId=${inv.id}`);
  }

  function toggleLine(lineId) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], checked: !s[lineId].checked } }));
  }
  function setQuantity(lineId, value) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], quantity: value } }));
  }

  const previewLines = useMemo(() => {
    if (!invoice) return [];
    return invoice.lineItems
      .filter((li) => selection[li.id]?.checked)
      .map((li) => {
        const qty = Number(selection[li.id]?.quantity || 0);
        const lineNet = round2(qty * li.unitPrice);
        const taxAmount =
          li.taxCalculationMethod === "INCLUSIVE"
            ? round2(lineNet - lineNet / (1 + (li.taxPercentage || 0) / 100))
            : round2((lineNet * (li.taxPercentage || 0)) / 100);
        const lineTotal = li.taxCalculationMethod === "INCLUSIVE" ? lineNet : round2(lineNet + taxAmount);
        // quantity is overridden to the adjusted qty (not the original
        // invoice line's quantity) so NoteLineItemsTable's review render
        // in step 3 shows what's actually being credited.
        return { ...li, quantity: qty, qty, taxAmount, lineTotal };
      });
  }, [invoice, selection]);

  const currentTotal = round2(previewLines.reduce((s, l) => s + l.lineTotal, 0));
  const remaining = invoice ? round2(invoice.grandTotal - previouslyCredited) : 0;
  const remainingAfter = round2(remaining - currentTotal);
  const reasonValue = reasonChoice === "Other" ? reasonOther.trim() : reasonChoice;

  function validateAdjustment() {
    if (!reasonChoice) return "A reason is required.";
    if (reasonChoice === "Other" && !reasonOther.trim()) return "Please describe the reason.";
    if (previewLines.length === 0) return "Select at least one line item to credit.";
    if (currentTotal <= 0) return "The credit amount must be greater than zero.";
    if (currentTotal > remaining + 0.01) return `This exceeds the remaining eligible amount (${formatCurrency(remaining, invoice.currency)}).`;
    return "";
  }

  function handleContinueToReview(e) {
    e.preventDefault();
    const msg = validateAdjustment();
    if (msg) {
      setError(msg);
      return;
    }
    setError("");
    setStep(3);
  }

  async function persistDraft() {
    const token = tenantAuth.get();
    const { creditNote } = await api.createCreditNote(token, {
      invoiceId,
      reason: reasonValue,
      issueDate: issueDate || undefined,
      notes: notes || undefined,
      lineItems: previewLines.map((l) => ({ invoiceLineItemId: l.id, quantity: l.qty })),
    });
    return creditNote;
  }

  async function handleSaveDraft() {
    setBusy(true);
    setError("");
    try {
      const creditNote = await persistDraft();
      showToast("Draft saved.");
      router.push(`/tenant/credit-notes/${creditNote.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  async function handleIssueNow() {
    setBusy(true);
    setError("");
    try {
      const creditNote = await persistDraft();
      const token = tenantAuth.get();
      const result = await api.issueCreditNote(token, creditNote.id);
      if (result.approvalRequest) {
        showToast(`Issuing requires approval - submitted as ${result.approvalRequest.referenceNumber}. Saved as a Draft until a checker decides.`);
      } else {
        showToast(`${result.creditNote.creditNoteNumberDisplay} was issued.`);
      }
      router.push(`/tenant/credit-notes/${creditNote.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  const wizardHeader = (
    <div style={{ marginBottom: 20 }}>
      <StepWizard steps={STEP_LABELS} currentStep={step} />
    </div>
  );

  // --- Step 0: Select Original Invoice ---
  if (step === 0) {
    return (
      <div>
        {wizardHeader}
        <ErrorBanner message={error} />
        <EligibleInvoicePicker onSelect={handleSelectInvoice} />
      </div>
    );
  }

  if (!invoice) {
    return (
      <div>
        {wizardHeader}
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  // --- Step 1: Review original invoice ---
  if (step === 1) {
    return (
      <div>
        {wizardHeader}
        <ErrorBanner message={error} />
        <div className="detail-layout">
          <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <Card>
              <h3 style={{ marginTop: 0 }}>Original Invoice</h3>
              <div className="review-list">
                <div className="review-row">
                  <span className="review-label">Invoice #</span>
                  <span className="review-value mono">{invoice.invoiceNumberDisplay}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Customer</span>
                  <span className="review-value">{invoice.customerName}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Invoice Date</span>
                  <span className="review-value">{formatDate(invoice.issueDate)}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Currency</span>
                  <span className="review-value">{invoice.currency}</span>
                </div>
              </div>
            </Card>
            <Card>
              <h3 style={{ marginTop: 0 }}>Line Items</h3>
              <NoteLineItemsTable lineItems={invoice.lineItems} currency={invoice.currency} />
            </Card>
          </div>
          <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
            <AdjustmentSummaryCard
              currency={invoice.currency}
              originalAmount={invoice.grandTotal}
              previouslyAdjusted={previouslyCredited}
              previouslyLabel="Previously Credited"
              currentNote={0}
              currentLabel="Current Credit Note"
              remainingAmount={remaining}
              remainingLabel="Available to Credit"
            />
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <Button onClick={() => setStep(2)} disabled={remaining <= 0.01} style={{ width: "100%", justifyContent: "center" }}>
                Continue
              </Button>
              <Button variant="outline" onClick={() => setStep(0)} style={{ width: "100%", justifyContent: "center" }}>
                Change Invoice
              </Button>
            </div>
            {remaining <= 0.01 && <p className="helptext" style={{ marginTop: 8 }}>No creditable amount remains on this invoice.</p>}
          </div>
        </div>
      </div>
    );
  }

  // --- Step 2: Create Adjustment ---
  if (step === 2) {
    return (
      <form onSubmit={handleContinueToReview}>
        {wizardHeader}
        <ErrorBanner message={error} />
        <div className="detail-layout">
          <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <Card>
              <h3 style={{ marginTop: 0 }}>Select Lines to Credit</h3>
              <p className="helptext" style={{ marginTop: -8 }}>
                Tax treatment is always inherited from the original line - it's never re-resolved from current Tax Master rates.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {invoice.lineItems.map((li) => (
                  <div key={li.id} className="note-line-row" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--color-border)" }}>
                    <input type="checkbox" checked={!!selection[li.id]?.checked} onChange={() => toggleLine(li.id)} />
                    <div style={{ flex: 1 }}>
                      <div>{li.description}</div>
                      <div className="helptext">
                        Original qty {li.quantity} × {formatCurrency(li.unitPrice, invoice.currency)}
                        {li.taxRateName ? ` · ${li.taxRateName} (${li.taxPercentage}%)` : " · No tax"}
                      </div>
                    </div>
                    <Input
                      type="number"
                      min="0.01"
                      max={li.quantity}
                      step="any"
                      style={{ width: 90 }}
                      disabled={!selection[li.id]?.checked}
                      value={selection[li.id]?.quantity ?? li.quantity}
                      onChange={(e) => setQuantity(li.id, e.target.value)}
                    />
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <Field id="reason" label="Reason">
                <Select value={reasonChoice} onChange={(e) => setReasonChoice(e.target.value)} required>
                  <option value="" disabled>
                    Select a reason…
                  </option>
                  {REASON_OPTIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </Select>
              </Field>
              {reasonChoice === "Other" && (
                <Field id="reasonOther" label="Describe the reason">
                  <Input value={reasonOther} onChange={(e) => setReasonOther(e.target.value)} placeholder="e.g. Goodwill adjustment" required />
                </Field>
              )}
              <Field id="issueDate" label="Issue Date (optional — defaults to today when issued)">
                <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} />
              </Field>
              <Field id="notes" label="Notes (customer-facing, optional)" style={{ marginBottom: 0 }}>
                <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
              </Field>
            </Card>
          </div>

          <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
            <AdjustmentSummaryCard
              currency={invoice.currency}
              originalAmount={invoice.grandTotal}
              previouslyAdjusted={previouslyCredited}
              previouslyLabel="Previously Credited"
              currentNote={currentTotal}
              currentLabel="Current Credit Note"
              remainingAmount={remaining}
              remainingLabel="Available to Credit"
            />
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <Button type="submit" style={{ width: "100%", justifyContent: "center" }}>
                Review
              </Button>
              <Button type="button" variant="outline" onClick={() => setStep(1)} style={{ width: "100%", justifyContent: "center" }}>
                Back
              </Button>
            </div>
          </div>
        </div>
      </form>
    );
  }

  // --- Step 3: Review & Issue ---
  return (
    <div>
      {wizardHeader}
      <ErrorBanner message={error} />
      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Summary</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Original Invoice</span>
                <span className="review-value mono">{invoice.invoiceNumberDisplay}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Customer</span>
                <span className="review-value">{invoice.customerName}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Reason</span>
                <span className="review-value">{reasonValue}</span>
              </div>
              {issueDate && (
                <div className="review-row">
                  <span className="review-label">Issue Date</span>
                  <span className="review-value">{formatDate(issueDate)}</span>
                </div>
              )}
            </div>
          </Card>
          <Card>
            <h3 style={{ marginTop: 0 }}>Lines Being Credited</h3>
            <NoteLineItemsTable lineItems={previewLines} currency={invoice.currency} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <AdjustmentSummaryCard
            currency={invoice.currency}
            originalAmount={invoice.grandTotal}
            previouslyAdjusted={previouslyCredited}
            previouslyLabel="Previously Credited"
            currentNote={currentTotal}
            currentLabel="This Credit Note"
            remainingAmount={remainingAfter}
            remainingLabel="Remaining After Credit"
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <Button onClick={handleIssueNow} disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
              {busy ? "Issuing…" : "Issue Now"}
            </Button>
            <Button variant="outline" onClick={handleSaveDraft} disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
              {busy ? "Saving…" : "Save as Draft"}
            </Button>
            <Button variant="outline" onClick={() => setStep(2)} disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
              Back
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
