"use client";

import { useMemo } from "react";
import Modal from "../ui/Modal";
import Table from "../ui/Table";
import TableScroll from "../ui/TableScroll";
import { calculationMethodLabel } from "../../lib/taxCalculationMethods";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Every row sharing `rateName`, newest version first - no separate network
// call, just re-slicing the same list the main table already fetched (the
// full listTaxRates response includes every version of every rate, the main
// table just filters to isCurrentVersion for its own display).
export default function RateHistoryModal({ open, onClose, rateName, rates }) {
  const versions = useMemo(
    () => (rates || []).filter((r) => r.name === rateName).sort((a, b) => b.version - a.version),
    [rates, rateName]
  );

  const COLUMNS = [
    { key: "version", header: "Version", render: (r) => `v${r.version}` },
    { key: "percentage", header: "Rate", className: "num", render: (r) => `${r.percentage}%` },
    { key: "calc", header: "Calculation", render: (r) => calculationMethodLabel(r.calculationMethod) },
    { key: "from", header: "Applicable From", render: (r) => formatDate(r.effectiveFrom) },
    { key: "to", header: "Applicable To", render: (r) => formatDate(r.effectiveTo) },
    {
      key: "status",
      header: "Status",
      render: (r) => (
        <span className={`badge ${r.isCurrentVersion ? (r.status === "ACTIVE" ? "badge-success" : "badge-danger") : "badge-info"}`}>
          {r.isCurrentVersion ? (r.status === "ACTIVE" ? "Active" : "Inactive") : "Historical"}
        </span>
      ),
    },
    { key: "createdBy", header: "Created By", render: (r) => r.createdByName || "—" },
    { key: "createdOn", header: "Created On", render: (r) => formatDateTime(r.createdAt) },
    { key: "modifiedBy", header: "Modified By", render: (r) => r.updatedByName || "—" },
    { key: "modifiedOn", header: "Modified On", render: (r) => formatDateTime(r.updatedAt) },
    { key: "reason", header: "Reason for Change", render: (r) => r.reason || "—" },
    { key: "audit", header: "Audit Ref", render: (r) => r.auditRef || "—" },
  ];

  return (
    <Modal open={open} onClose={onClose} size="lg" ariaLabel={`Version history for ${rateName}`}>
      <h2 style={{ marginBottom: 4 }}>Version History</h2>
      <p className="helptext" style={{ marginBottom: 20 }}>
        {rateName} — {versions.length} version{versions.length === 1 ? "" : "s"}, newest first. Historical versions are read-only.
      </p>
      <TableScroll>
        <Table columns={COLUMNS} rows={versions} />
      </TableScroll>
      <div className="dialog-actions">
        <button type="button" className="btn btn-outline" onClick={onClose}>
          Close
        </button>
      </div>
    </Modal>
  );
}
