"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import { CALCULATION_METHODS } from "../../lib/taxCalculationMethods";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const FORM_ID = "tax-rate-form";

function toDateInput(iso) {
  return iso ? new Date(iso).toISOString().slice(0, 10) : "";
}

// One modal, three modes - a Tax Rate is never edited in place, so there is
// no generic "Edit" anymore:
//   - "create": blank form (+ Add Tax Rate), or pre-filled from `rate` with
//     Name/Applicable From cleared (Duplicate) - always POSTs a brand-new
//     rate family.
//   - "version": Name is locked to `rate.name` (a version can never rename
//     its family) - POSTs a new version of `rate.id`, adds Reason for Change.
//   - "view": every field disabled, no submit - just a read-only look.
//
// UI-only pass (2026-08-06): scoped to className="tax-rate-modal" so the
// spacing/sizing refinements below (globals.css, "Tax Rate modal" section)
// never touch the shared Modal/.form-grid/.field/.segmented-control styles
// every other modal in the app relies on. No field, validation, or API
// change in this file versus the previous version.
export default function RateFormModal({ open, onClose, mode = "create", rate, onSuccess }) {
  const isView = mode === "view";
  const isVersion = mode === "version";
  const isDuplicate = mode === "create" && !!rate;

  const [name, setName] = useState(isVersion ? rate?.name || "" : isDuplicate ? "" : rate?.name || "");
  const [percentage, setPercentage] = useState(rate?.percentage != null ? String(rate.percentage) : "");
  const [calculationMethod, setCalculationMethod] = useState(rate?.calculationMethod || "EXCLUSIVE");
  const [effectiveFrom, setEffectiveFrom] = useState(isDuplicate ? "" : toDateInput(rate?.effectiveFrom) || new Date().toISOString().slice(0, 10));
  const [effectiveTo, setEffectiveTo] = useState(isDuplicate ? "" : toDateInput(rate?.effectiveTo));
  const [status, setStatus] = useState(rate?.status || "ACTIVE");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState(isDuplicate ? "" : rate?.notes || "");
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Background page must never scroll while this modal is open (enterprise
  // modal convention) - purely a viewport-behavior detail, not app logic,
  // and scoped to this component only so no other modal's behavior changes.
  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  const errors = {
    name: !name.trim() ? "Tax name is required." : "",
    percentage: !percentage.trim() ? "Rate is required." : Number.isNaN(Number(percentage)) || Number(percentage) < 0 ? "Enter a valid, non-negative rate." : "",
    effectiveFrom: !effectiveFrom ? "Applicable From is required." : "",
    effectiveTo: effectiveTo && effectiveFrom && effectiveTo <= effectiveFrom ? "Applicable To must be after Applicable From." : "",
  };

  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }

  function resetAndClose() {
    setTouched({});
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading || isView) return;
    setTouched({ name: true, percentage: true, effectiveFrom: true, effectiveTo: true });
    if (Object.values(errors).some(Boolean)) return;

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      // Maker-Checker engine: either call resolves fine on a 202 Pending
      // (fetch treats it as ok) - result.approvalRequest tells the caller
      // whether this was actually applied or is still awaiting a decision,
      // so the toast never claims something happened when it didn't.
      const result = isVersion
        ? await api.createTaxRateVersion(token, rate.id, {
            percentage: Number(percentage),
            calculationMethod,
            effectiveFrom,
            effectiveTo: effectiveTo || null,
            status,
            notes: notes.trim() || null,
            reason: reason.trim() || null,
          })
        : await api.createTaxRate(token, {
            name: name.trim(),
            percentage: Number(percentage),
            calculationMethod,
            effectiveFrom,
            effectiveTo: effectiveTo || null,
            status,
            notes: notes.trim() || null,
          });
      onSuccess(name.trim(), result.approvalRequest || null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const title = isView ? "View Tax Rate" : isVersion ? "Create New Version" : isDuplicate ? "Duplicate Tax Rate" : "Add Tax Rate";
  const description = isView
    ? `Version ${rate?.version} of "${rate?.name}" - read-only.`
    : isVersion
    ? `A new version of "${rate?.name}" - the previous version becomes historical and stays available under View History.`
    : isDuplicate
    ? "Pre-filled from the source rate - pick a new name and Applicable From."
    : "Creates a new named tax rate, starting at version 1.";

  return (
    <Modal open={open} onClose={resetAndClose} size="lg" ariaLabel={title} className="tax-rate-modal">
      <div className="dialog-lg-header">
        <h2>{title}</h2>
        <p className="helptext">{description}</p>
      </div>

      <div className="dialog-lg-body">
        <ErrorBanner message={error} />

        <form id={FORM_ID} onSubmit={handleSubmit}>
          <div className="tax-rate-form-rows">
            <div className="form-grid">
              <Field id="rate-name" label={<>Tax Name<span className="required-asterisk">*</span></>} error={fieldError("name")} helptext={isVersion ? "Fixed for this rate's version history" : undefined}>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                  placeholder="e.g. UAE Standard VAT"
                  disabled={isView || isVersion}
                />
              </Field>
              <Field id="rate-percentage" label={<>Rate (%)<span className="required-asterisk">*</span></>} error={fieldError("percentage")}>
                <Input type="number" min="0" step="0.01" value={percentage} onChange={(e) => setPercentage(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, percentage: true }))} disabled={isView} />
              </Field>
            </div>

            <div className="form-grid">
              <Field id="rate-calc" label="Calculation Type">
                <Select value={calculationMethod} onChange={(e) => setCalculationMethod(e.target.value)} disabled={isView}>
                  {CALCULATION_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </Select>
              </Field>
              <div className="field">
                <label>Status</label>
                <div className="segmented-control" role="radiogroup" aria-label="Status">
                  <button type="button" className={`segmented-option${status === "ACTIVE" ? " selected" : ""}`} onClick={() => !isView && setStatus("ACTIVE")} disabled={isView}>
                    Active
                  </button>
                  <button type="button" className={`segmented-option${status === "INACTIVE" ? " selected" : ""}`} onClick={() => !isView && setStatus("INACTIVE")} disabled={isView}>
                    Inactive
                  </button>
                </div>
              </div>
            </div>

            <div className="form-grid">
              <Field id="rate-from" label={<>Applicable From<span className="required-asterisk">*</span></>} error={fieldError("effectiveFrom")} helptext={!fieldError("effectiveFrom") ? "Future dates are allowed - schedule a change ahead of time" : undefined}>
                <Input type="date" value={effectiveFrom} onChange={(e) => setEffectiveFrom(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, effectiveFrom: true }))} disabled={isView} />
              </Field>
              <Field id="rate-to" label="Applicable To" helptext={!fieldError("effectiveTo") ? "Optional — leave blank if still open-ended" : undefined} error={fieldError("effectiveTo")}>
                <Input type="date" value={effectiveTo} onChange={(e) => setEffectiveTo(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, effectiveTo: true }))} disabled={isView} />
              </Field>
            </div>

            {(isVersion || isView) && (
              <Field id="rate-reason" label="Reason for Change" helptext="Optional — shown in this rate's audit history">
                <Input value={isView ? rate?.reason || "" : reason} onChange={(e) => setReason(e.target.value)} disabled={isView} placeholder="e.g. Federal Tax Authority rate change effective next quarter" />
              </Field>
            )}

            <Field id="rate-notes" label="Notes" helptext="Optional">
              <textarea className="tax-rate-notes" value={notes} onChange={(e) => setNotes(e.target.value)} disabled={isView} />
            </Field>
          </div>
        </form>
      </div>

      <div className="tax-rate-modal-footer">
        <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
          {isView ? "Close" : "Cancel"}
        </Button>
        {!isView && (
          <Button type="submit" form={FORM_ID} disabled={loading}>
            {loading ? "Saving…" : isVersion ? "Create New Version" : "Add Tax Rate"}
          </Button>
        )}
      </div>
    </Modal>
  );
}
