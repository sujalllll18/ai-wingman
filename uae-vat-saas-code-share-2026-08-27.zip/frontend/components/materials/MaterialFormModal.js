"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

// Shared for both Add and Edit — pass `material` to prefill/edit an
// existing one, omit it to create a new one.
export default function MaterialFormModal({ open, onClose, material, onSuccess }) {
  const isEdit = !!material;

  const [name, setName] = useState(material?.name || "");
  const [unit, setUnit] = useState(material?.unit || "");
  const [price, setPrice] = useState(material?.defaultUnitPrice != null ? String(material.defaultUnitPrice) : "");
  const [taxCategoryId, setTaxCategoryId] = useState(material?.defaultTaxCategoryId || "");
  const [taxCategories, setTaxCategories] = useState([]);
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Live Tax Category list — replaces the old hardcoded VAT_CATEGORIES
  // dropdown now that Tax Master's categories are real, user-creatable
  // per-tenant records (see docs/features/17-invoice-generation.md §2).
  useEffect(() => {
    if (!open) return;
    (async () => {
      try {
        const token = tenantAuth.get();
        const { categories } = await api.listTaxCategories(token);
        const active = categories.filter((c) => c.status === "ACTIVE");
        setTaxCategories(active);
        if (!taxCategoryId && !isEdit && active.length > 0) {
          const standard = active.find((c) => c.name === "Standard Rated");
          setTaxCategoryId(standard ? standard.id : active[0].id);
        }
      } catch (err) {
        setError(err.message);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const errors = {
    name: !name.trim() ? "Description is required." : "",
    unit: !unit.trim() ? "Unit is required." : "",
    price: !price.trim() ? "Selling price is required." : Number.isNaN(Number(price)) || Number(price) < 0 ? "Enter a valid, non-negative price." : "",
  };

  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }

  function resetAndClose() {
    setName(material?.name || "");
    setUnit(material?.unit || "");
    setPrice(material?.defaultUnitPrice != null ? String(material.defaultUnitPrice) : "");
    setTaxCategoryId(material?.defaultTaxCategoryId || "");
    setTouched({});
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    setTouched({ name: true, unit: true, price: true });
    if (Object.values(errors).some(Boolean)) return;

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const payload = { name: name.trim(), unit: unit.trim(), defaultUnitPrice: Number(price), defaultTaxCategoryId: taxCategoryId || null };
      if (isEdit) {
        await api.updateMaterial(token, material.id, payload);
      } else {
        await api.createMaterial(token, payload);
      }
      onSuccess(name.trim());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} ariaLabel={isEdit ? "Edit Material" : "Add Material"}>
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 4 }}>{isEdit ? "Edit Material" : "Add Material"}</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>
          {isEdit ? "Update this catalog item." : "Add an item to your material catalog for reuse on invoices."}
        </p>

        <ErrorBanner message={error} />

        <Field
          id="material-name"
          label={
            <>
              Description<span className="required-asterisk">*</span>
            </>
          }
          error={fieldError("name")}
        >
          <Input value={name} onChange={(e) => setName(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, name: true }))} />
        </Field>

        <div className="form-grid">
          <Field
            id="material-unit"
            label={
              <>
                Unit<span className="required-asterisk">*</span>
              </>
            }
            error={fieldError("unit")}
          >
            <Input value={unit} onChange={(e) => setUnit(e.target.value)} onBlur={() => setTouched((t) => ({ ...t, unit: true }))} placeholder="e.g. Piece, Kg, Hour" />
          </Field>
          <Field
            id="material-price"
            label={
              <>
                Selling Price (AED)<span className="required-asterisk">*</span>
              </>
            }
            error={fieldError("price")}
          >
            <Input
              type="number"
              min="0"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              onBlur={() => setTouched((t) => ({ ...t, price: true }))}
            />
          </Field>
        </div>

        <Field
          id="material-vat"
          label={
            <>
              Default Tax Category<span className="required-asterisk">*</span>
            </>
          }
          style={{ marginBottom: 0 }}
        >
          <Select value={taxCategoryId} onChange={(e) => setTaxCategoryId(e.target.value)}>
            {taxCategories.length === 0 && <option value="">No tax categories yet</option>}
            {taxCategories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </Field>

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : isEdit ? "Save Changes" : "Add Material"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
