"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import LoadingSkeleton from "../ui/LoadingSkeleton";
import AdjustmentSummaryCard from "../notes/AdjustmentSummaryCard";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// Mirrors CreditNoteForm.js exactly, one level down (Purchase side). The one
// real difference: quantity here has no upper `max` tied to the original
// line - a Debit Note's most common use case (supplier undercharged) is an
// ADDITIONAL amount, not a cap-constrained reduction, matching
// debitNote.controller.js's deliberate no-per-line-cap design.
export default function DebitNoteForm({ purchaseBillId }) {
  const router = useRouter();
  const [purchase, setPurchase] = useState(null);
  const [previouslyDebited, setPreviouslyDebited] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");
  const [issueDate, setIssueDate] = useState("");
  const [notes, setNotes] = useState("");
  const [selection, setSelection] = useState({});

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [purchaseBillId]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const [{ purchase: p }, { debitNotes }] = await Promise.all([api.getPurchase(token, purchaseBillId), api.listDebitNotes(token)]);
      setPurchase(p);
      const already = round2(
        debitNotes.filter((d) => d.purchaseBillId === purchaseBillId && d.status === "ISSUED").reduce((s, d) => s + d.grandTotal, 0)
      );
      setPreviouslyDebited(already);
      const initial = {};
      for (const li of p.lineItems) {
        initial[li.id] = { checked: false, quantity: li.quantity };
      }
      setSelection(initial);
    } catch (err) {
      setError(err.message);
    }
  }

  function toggleLine(lineId) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], checked: !s[lineId].checked } }));
  }
  function setQuantity(lineId, value) {
    setSelection((s) => ({ ...s, [lineId]: { ...s[lineId], quantity: value } }));
  }

  const previewLines = useMemo(() => {
    if (!purchase) return [];
    return purchase.lineItems
      .filter((li) => selection[li.id]?.checked)
      .map((li) => {
        const qty = Number(selection[li.id]?.quantity || 0);
        const lineNet = round2(qty * li.unitPrice);
        const taxAmount =
          li.taxCalculationMethod === "INCLUSIVE"
            ? round2(lineNet - lineNet / (1 + (li.taxPercentage || 0) / 100))
            : round2((lineNet * (li.taxPercentage || 0)) / 100);
        const lineTotal = li.taxCalculationMethod === "INCLUSIVE" ? lineNet : round2(lineNet + taxAmount);
        return { ...li, qty, taxAmount, lineTotal };
      });
  }, [purchase, selection]);

  const currentTotal = round2(previewLines.reduce((s, l) => s + l.lineTotal, 0));

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!reason.trim()) {
      setError("A reason is required.");
      return;
    }
    if (previewLines.length === 0) {
      setError("Select or add at least one line item.");
      return;
    }
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { debitNote } = await api.createDebitNote(token, {
        purchaseBillId,
        reason: reason.trim(),
        issueDate: issueDate || undefined,
        notes: notes || undefined,
        lineItems: previewLines.map((l) => ({ purchaseLineItemId: l.id, quantity: l.qty })),
      });
      router.push(`/tenant/debit-notes/${debitNote.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  if (!purchase) {
    return (
      <>
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Original Purchase Bill</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Bill #</span>
                <span className="review-value mono">{purchase.billNumberDisplay}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Vendor</span>
                <span className="review-value">{purchase.vendorName}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Purchase Date</span>
                <span className="review-value">{formatDate(purchase.purchaseDate)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Currency</span>
                <span className="review-value">{purchase.currency}</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Select Lines to Debit</h3>
            <p className="helptext" style={{ marginTop: -8 }}>
              Tax treatment is always inherited from the original line - it's never re-resolved from current Tax Master rates. Quantity
              may exceed the original (e.g. a supplier undercharge correction).
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {purchase.lineItems.map((li) => (
                <div key={li.id} className="note-line-row" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--color-border)" }}>
                  <input type="checkbox" checked={!!selection[li.id]?.checked} onChange={() => toggleLine(li.id)} />
                  <div style={{ flex: 1 }}>
                    <div>{li.description}</div>
                    <div className="helptext">
                      Original qty {li.quantity} × {formatCurrency(li.unitPrice, purchase.currency)}
                      {li.taxRateName ? ` · ${li.taxRateName} (${li.taxPercentage}%)` : " · No tax"}
                    </div>
                  </div>
                  <Input
                    type="number"
                    min="0.01"
                    step="any"
                    style={{ width: 90 }}
                    disabled={!selection[li.id]?.checked}
                    value={selection[li.id]?.quantity ?? li.quantity}
                    onChange={(e) => setQuantity(li.id, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <Field id="reason" label="Reason">
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Supplier undercharged - 5 additional units" required />
            </Field>
            <Field id="issueDate" label="Issue Date (optional — defaults to today when issued)">
              <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} />
            </Field>
            <Field id="notes" label="Notes (optional)" style={{ marginBottom: 0 }}>
              <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </Field>
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <AdjustmentSummaryCard
            currency={purchase.currency}
            originalAmount={purchase.grandTotal}
            previouslyAdjusted={previouslyDebited}
            previouslyLabel="Previously Debited"
            currentNote={currentTotal}
            currentLabel="This Debit Note"
          />
          <Button type="submit" disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
            {busy ? "Saving…" : "Save Draft"}
          </Button>
        </div>
      </div>
    </form>
  );
}
