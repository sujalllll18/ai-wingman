"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const ACCOUNT_TYPES = [
  { value: "CURRENT", label: "Current" },
  { value: "SAVINGS", label: "Savings" },
  { value: "OTHER", label: "Other" },
];

const EMPTY = { accountName: "", bankName: "", accountType: "CURRENT", currency: "AED", accountNumber: "", openingBalance: "", status: "ACTIVE" };

// Shared create/edit modal - editingAccount null means "create new".
export default function BankAccountFormModal({ open, onClose, onSuccess, editingAccount }) {
  const [fields, setFields] = useState(EMPTY);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setFields(
      editingAccount
        ? {
            accountName: editingAccount.accountName,
            bankName: editingAccount.bankName,
            accountType: editingAccount.accountType,
            currency: editingAccount.currency,
            accountNumber: editingAccount.accountNumber || "",
            openingBalance: editingAccount.openingBalance ?? "",
            status: editingAccount.status,
          }
        : EMPTY
    );
    setError("");
  }, [open, editingAccount]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    if (!fields.accountName.trim() || !fields.bankName.trim()) {
      setError("Account name and Bank name are both required.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const payload = {
        accountName: fields.accountName.trim(),
        bankName: fields.bankName.trim(),
        accountType: fields.accountType,
        currency: fields.currency.trim() || "AED",
        accountNumber: fields.accountNumber || null,
        openingBalance: fields.openingBalance === "" ? null : Number(fields.openingBalance),
        status: fields.status,
      };
      const { bankAccount } = editingAccount
        ? await api.updateBankAccount(token, editingAccount.id, payload)
        : await api.createBankAccount(token, payload);
      onSuccess(bankAccount);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} ariaLabel={editingAccount ? "Edit Bank Account" : "New Bank Account"}>
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 20 }}>{editingAccount ? "Edit Bank Account" : "New Bank Account"}</h2>

        <ErrorBanner message={error} />

        <div className="form-grid">
          <Field id="ba-name" label={<>Account Name<span className="required-asterisk">*</span></>}>
            <Input value={fields.accountName} onChange={(e) => setFields({ ...fields, accountName: e.target.value })} placeholder="e.g. Operating Account" />
          </Field>
          <Field id="ba-bank" label={<>Bank Name<span className="required-asterisk">*</span></>}>
            <Input value={fields.bankName} onChange={(e) => setFields({ ...fields, bankName: e.target.value })} placeholder="e.g. ADCB" />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="ba-type" label="Account Type">
            <Select value={fields.accountType} onChange={(e) => setFields({ ...fields, accountType: e.target.value })}>
              {ACCOUNT_TYPES.map((t) => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </Select>
          </Field>
          <Field id="ba-currency" label="Currency">
            <Input value={fields.currency} onChange={(e) => setFields({ ...fields, currency: e.target.value.toUpperCase() })} maxLength={3} />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="ba-number" label="Account / Reference Number" helptext="As printed on the statement - not a login credential.">
            <Input value={fields.accountNumber} onChange={(e) => setFields({ ...fields, accountNumber: e.target.value })} />
          </Field>
          <Field id="ba-opening" label="Opening Balance">
            <Input type="number" step="0.01" value={fields.openingBalance} onChange={(e) => setFields({ ...fields, openingBalance: e.target.value })} placeholder="Optional" />
          </Field>
        </div>

        {editingAccount && (
          <Field id="ba-status" label="Status">
            <Select value={fields.status} onChange={(e) => setFields({ ...fields, status: e.target.value })}>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </Select>
          </Field>
        )}

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : editingAccount ? "Save Changes" : "Create Bank Account"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
