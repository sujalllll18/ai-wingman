const LABELS = {
  TRIAL: "Trial",
  STANDARD: "Standard",
  PREMIUM: "Premium",
};

const BADGE_CLASS = {
  TRIAL: "badge-warning",
  STANDARD: "badge-info",
  PREMIUM: "badge-premium",
};

// Falls back to a title-cased version of the raw slug for any plan created
// via the Phase 2 Plan Builder (Starter/Growth/Business/Enterprise/Custom/
// any future custom slug) - the 3 legacy plans above keep their original
// exact labels/colors for continuity.
function titleCase(slug) {
  return slug.toLowerCase().replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export default function PlanTag({ plan }) {
  return <span className={`badge ${BADGE_CLASS[plan] || "badge-info"}`}>{LABELS[plan] || titleCase(plan)}</span>;
}
