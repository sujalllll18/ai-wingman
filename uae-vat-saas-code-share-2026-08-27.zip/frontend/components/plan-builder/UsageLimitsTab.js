import Card from "../ui/Card";
import NumberInput from "../ui/NumberInput";

// Exported for PlanVersionSummary.js (Versions tab detail panel + PDF) -
// one source of truth for which limits exist and their display labels.
export const LIMITS = [
  { key: "maxUsers", label: "Maximum Users" },
  { key: "maxTeamMembers", label: "Team Members" },
  { key: "maxCustomers", label: "Maximum Customers" },
  { key: "maxProducts", label: "Maximum Products" },
  { key: "maxInvoicesPerMonth", label: "Maximum Invoices / Month" },
  { key: "maxPurchasesPerMonth", label: "Maximum Purchases / Month" },
  { key: "ocrCredits", label: "OCR Credits" },
  { key: "apiCallsPerMonth", label: "API Calls / Month" },
  { key: "storageGb", label: "Storage (GB)" },
  { key: "attachmentStorageGb", label: "Attachment Storage (GB)" },
  { key: "maxBranches", label: "Branches" },
];

function LimitRow({ label, value, onChange, readOnly }) {
  const unlimited = value === null || value === undefined;
  return (
    <div className="review-row" style={{ alignItems: "center" }}>
      <span className="review-label">{label}</span>
      <span style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <label className="checkbox-row" style={{ marginTop: 0 }}>
          <input type="checkbox" checked={unlimited} disabled={readOnly} onChange={(e) => onChange(e.target.checked ? null : 0)} />
          Unlimited
        </label>
        <NumberInput
          min="0"
          step="1"
          style={{ width: 120 }}
          value={unlimited ? null : value}
          placeholder={unlimited ? "Unlimited" : "0"}
          disabled={readOnly || unlimited}
          onChange={(v) => onChange(v ?? 0)}
        />
      </span>
    </div>
  );
}

export default function UsageLimitsTab({ version, onVersionChange, readOnly }) {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Usage Limits</h2>
      <p className="form-section-desc">Every limit supports Unlimited or a numeric cap.</p>
      <div className="review-list" style={{ marginTop: 12 }}>
        {LIMITS.map(({ key, label }) => (
          <LimitRow key={key} label={label} value={version[key]} readOnly={readOnly} onChange={(v) => onVersionChange({ ...version, [key]: v })} />
        ))}
      </div>
    </Card>
  );
}
