import Card from "../ui/Card";
import ToggleSwitch from "../ui/ToggleSwitch";
import PlaceholderNotice from "../ui/PlaceholderNotice";

const NOT_REAL_YET = new Set(["ocr", "ai_assistant"]);

function toTitle(key) {
  return key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Module Builder + Feature Builder, combined into one tab (2026-08-07,
// Plan Builder). The spec lists these as separate deliverables, but a
// feature only ever exists nested inside its module, so a single
// module -> feature tree (matching how Stripe/Zoho/HubSpot present this)
// serves both without forcing an artificial duplicate flat list. Sourced
// entirely from the RBAC permission catalog (via GET /module-catalog) -
// not a second hardcoded catalog. Enforcement (sidebar generated from
// these settings) is explicitly a later phase per the spec; this tab only
// configures and persists.
export default function ModulesFeaturesTab({ catalog, moduleAccess, onChange, readOnly }) {
  const groups = {};
  for (const mod of catalog) {
    (groups[mod.group] = groups[mod.group] || []).push(mod);
  }

  function moduleState(moduleKey) {
    return moduleAccess[moduleKey] || { enabled: false, features: {} };
  }

  function setModuleEnabled(moduleKey, enabled) {
    onChange({ ...moduleAccess, [moduleKey]: { ...moduleState(moduleKey), enabled } });
  }

  function setFeatureEnabled(moduleKey, actionKey, enabled) {
    const current = moduleState(moduleKey);
    onChange({ ...moduleAccess, [moduleKey]: { ...current, features: { ...current.features, [actionKey]: enabled } } });
  }

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Modules &amp; Features</h2>
      <p className="form-section-desc">Which Ledger modules this plan includes, and which individual actions within each module.</p>
      <PlaceholderNotice>
        These toggles configure and persist plan access. The sidebar/route gating that enforces them per-tenant is a
        later phase — today this is the source of truth to build that against.
      </PlaceholderNotice>

      <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 20 }}>
        {Object.entries(groups).map(([groupName, modules]) => (
          <div key={groupName}>
            <h3 style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--color-ink-faint)", marginBottom: 8 }}>{groupName}</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {modules.map((mod) => {
                const state = moduleState(mod.module);
                return (
                  <details key={mod.module} className="card" style={{ padding: "12px 16px", marginBottom: 0 }}>
                    <summary style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", listStyle: "none" }}>
                      <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontWeight: 600 }}>{mod.label}</span>
                        {NOT_REAL_YET.has(mod.module) && <span className="badge badge-info">Placeholder</span>}
                        <span className="helptext" style={{ marginTop: 0 }}>
                          {mod.actions.length} features
                        </span>
                      </span>
                      <span onClick={(e) => e.preventDefault()}>
                        <ToggleSwitch checked={!!state.enabled} onChange={(v) => setModuleEnabled(mod.module, v)} disabled={readOnly} ariaLabel={`Enable ${mod.label} module`} />
                      </span>
                    </summary>
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--color-line)", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 8 }}>
                      {mod.actions.map((action) => (
                        <label key={action} className="checkbox-row" style={{ marginTop: 0, opacity: state.enabled ? 1 : 0.5 }}>
                          <input
                            type="checkbox"
                            checked={!!state.features?.[action]}
                            disabled={readOnly || !state.enabled}
                            onChange={(e) => setFeatureEnabled(mod.module, action, e.target.checked)}
                          />
                          {toTitle(action)}
                        </label>
                      ))}
                    </div>
                  </details>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
