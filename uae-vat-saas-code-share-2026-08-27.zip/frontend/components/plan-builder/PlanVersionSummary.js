import PlanStatusBadge from "../PlanStatusBadge";
import { LIMITS } from "./UsageLimitsTab";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toLocaleString()}`;
}
function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function toTitle(key) {
  return key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Pure content, no Card/document chrome of its own - reused two ways:
// 1. VersionsTab wraps this in a <Card> for the inline "Version Details"
//    panel (requirement: see everything about the selected version without
//    clicking through 4 separate tabs).
// 2. PlanVersionPdfDocument wraps the exact same sections in print-document
//    chrome for the client-facing PDF (requirement: PDF must show the same
//    facts as the on-screen detail view, for whichever version is selected).
// One source of truth for "what does a plan version actually contain" -
// never invents a field that isn't really on the version/catalog data.
export default function PlanVersionSummary({ plan, version, catalog }) {
  const moduleAccess = version.moduleAccess || {};
  const includedModules = catalog.filter((m) => moduleAccess[m.module]?.enabled);
  const excludedModules = catalog.filter((m) => !moduleAccess[m.module]?.enabled);

  return (
    <div className="plan-version-summary">
      <section className="plan-summary-section">
        <h3 className="plan-summary-heading">Plan Information</h3>
        <div className="review-list">
          <div className="review-row">
            <span className="review-label">Plan Name</span>
            <span className="review-value">{plan.name}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Slug</span>
            <span className="review-value mono">{plan.slug}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Version</span>
            <span className="review-value mono">v{version.versionNumber}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Status</span>
            <span className="review-value">
              <PlanStatusBadge status={version.status} />
            </span>
          </div>
          <div className="review-row">
            <span className="review-label">Published</span>
            <span className="review-value">{version.status === "PUBLISHED" ? formatDateTime(version.publishedAt) : "Not yet published"}</span>
          </div>
        </div>
      </section>

      <section className="plan-summary-section">
        <h3 className="plan-summary-heading">Billing</h3>
        <div className="review-list">
          <div className="review-row">
            <span className="review-label">Monthly Price</span>
            <span className="review-value mono">{formatCurrency(version.monthlyPrice)}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Annual Price</span>
            <span className="review-value mono">{formatCurrency(version.yearlyPrice)}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Free Trial</span>
            <span className="review-value">{version.trialDays > 0 ? `${version.trialDays} days` : "None"}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Grace Period</span>
            <span className="review-value">{version.gracePeriodDays > 0 ? `${version.gracePeriodDays} days` : "None"}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Auto-Renewal</span>
            <span className="review-value">{version.autoRenewal ? "Enabled" : "Disabled"}</span>
          </div>
        </div>
      </section>

      <section className="plan-summary-section">
        <h3 className="plan-summary-heading">Modules &amp; Features</h3>
        <div className="plan-summary-module-grid">
          {includedModules.map((m) => {
            const enabledFeatures = m.actions.filter((a) => moduleAccess[m.module]?.features?.[a]);
            return (
              <div key={m.module} className="plan-summary-module-row">
                <div className="plan-summary-module-name">
                  <span className="badge badge-success">Included</span>
                  <strong>{m.label}</strong>
                </div>
                {enabledFeatures.length > 0 && (
                  <p className="helptext" style={{ margin: "4px 0 0" }}>
                    {enabledFeatures.map(toTitle).join(", ")}
                  </p>
                )}
              </div>
            );
          })}
          {excludedModules.map((m) => (
            <div key={m.module} className="plan-summary-module-row plan-summary-module-excluded">
              <div className="plan-summary-module-name">
                <span className="badge badge-danger">Not Included</span>
                <strong>{m.label}</strong>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="plan-summary-section">
        <h3 className="plan-summary-heading">Usage Limits</h3>
        <div className="review-list">
          {LIMITS.map(({ key, label }) => {
            const raw = version[key];
            const unlimited = raw === null || raw === undefined;
            return (
              <div key={key} className="review-row">
                <span className="review-label">{label}</span>
                <span className="review-value mono">{unlimited ? "Unlimited" : raw}</span>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
