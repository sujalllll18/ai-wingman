import Card from "../ui/Card";
import Field from "../ui/Field";
import Input from "../ui/Input";
import NumberInput from "../ui/NumberInput";
import Select from "../ui/Select";

// General Information tab (2026-08-07, Plan Builder) - mixes Plan-level
// fields (name/description/status/default) with PlanVersion-level fields
// (pricing/trial days) in one section per the Phase 2 spec; the parent page
// tracks them as two separate pieces of state (planMeta vs versionDraft)
// and this tab just renders both, calling back into whichever changed.
export default function GeneralTab({ planMeta, onPlanMetaChange, version, onVersionChange, readOnly }) {
  // Plan-level fields (name/description/status/default) are never tied to a
  // specific version's read-only state - only the pricing/trial fields
  // below (which live on PlanVersion) are locked once that version is
  // published.
  const planReadOnly = false;
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>General Information</h2>
      <p className="form-section-desc">The identity and headline pricing for this plan.</p>

      <Field id="plan-name" label="Plan Name">
        <Input value={planMeta.name} onChange={(e) => onPlanMetaChange({ ...planMeta, name: e.target.value })} disabled={planReadOnly} />
      </Field>
      <Field id="plan-description" label="Description" style={{ marginBottom: 0 }}>
        <textarea
          rows={2}
          value={planMeta.description || ""}
          onChange={(e) => onPlanMetaChange({ ...planMeta, description: e.target.value })}
          disabled={planReadOnly}
        />
      </Field>

      <div className="form-grid" style={{ marginTop: 16 }}>
        <Field id="monthly-price" label="Monthly Price (AED)">
          <NumberInput min="0" step="0.01" value={version.monthlyPrice} onChange={(v) => onVersionChange({ ...version, monthlyPrice: v ?? 0 })} disabled={readOnly} />
        </Field>
        <Field id="yearly-price" label="Yearly Price (AED)">
          <NumberInput min="0" step="0.01" value={version.yearlyPrice} onChange={(v) => onVersionChange({ ...version, yearlyPrice: v ?? 0 })} disabled={readOnly} />
        </Field>
      </div>
      <div className="form-grid">
        <Field id="trial-days" label="Trial Days">
          <NumberInput min="0" step="1" value={version.trialDays} onChange={(v) => onVersionChange({ ...version, trialDays: v ?? 0 })} disabled={readOnly} />
        </Field>
        <Field id="plan-status" label="Status">
          <Select value={planMeta.status} onChange={(e) => onPlanMetaChange({ ...planMeta, status: e.target.value })} disabled={planReadOnly}>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
            <option value="ARCHIVED">Archived</option>
          </Select>
        </Field>
      </div>

      <label className="checkbox-row" style={{ marginTop: 8 }}>
        <input type="checkbox" checked={!!planMeta.isDefault} onChange={(e) => onPlanMetaChange({ ...planMeta, isDefault: e.target.checked })} disabled={planReadOnly} />
        Default plan — new tenants are assigned this plan unless another is chosen
      </label>
    </Card>
  );
}
