import { forwardRef } from "react";
import PlanVersionSummary from "./PlanVersionSummary";

// Client-facing "what's included in this plan" summary, downloadable per
// version (2026-08-09). Reuses .invoice-document's exact A4 page sizing/
// print styling (210mm, 16mm padding, print-only display rules) rather
// than inventing a second page-chrome convention - only this file's own
// .plan-pdf-* classes (header/footer) are new, the section content itself
// is PlanVersionSummary, shared verbatim with the Versions tab's inline
// detail panel so the PDF can never drift from what's shown on screen.
const PlanVersionPdfDocument = forwardRef(function PlanVersionPdfDocument({ plan, version, catalog }, ref) {
  return (
    <div className="invoice-document" ref={ref}>
      <div className="plan-pdf-header">
        <span className="plan-pdf-brand">Ledger</span>
        <h1>Plan Summary</h1>
      </div>
      <PlanVersionSummary plan={plan} version={version} catalog={catalog} />
      <div className="invoice-doc-footer" style={{ marginTop: 24 }}>
        <span>This is a computer-generated plan summary.</span>
      </div>
    </div>
  );
});

export default PlanVersionPdfDocument;
