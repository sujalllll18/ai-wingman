import Card from "../ui/Card";
import Field from "../ui/Field";
import NumberInput from "../ui/NumberInput";

export default function BillingTab({ version, onVersionChange, readOnly }) {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Billing</h2>
      <p className="form-section-desc">How this plan bills and renews.</p>

      <div className="form-grid">
        <div className="field">
          <label>Monthly Billing</label>
          <p className="helptext" style={{ marginTop: 0 }}>
            AED {Number(version.monthlyPrice || 0).toLocaleString()} charged every month.
          </p>
        </div>
        <div className="field">
          <label>Annual Billing</label>
          <p className="helptext" style={{ marginTop: 0 }}>
            AED {Number(version.yearlyPrice || 0).toLocaleString()} charged every year.
          </p>
        </div>
      </div>

      <div className="form-grid">
        <Field id="grace-period" label="Grace Period (days)" helptext="How long an overdue tenant keeps access before suspension">
          <NumberInput min="0" step="1" value={version.gracePeriodDays} onChange={(v) => onVersionChange({ ...version, gracePeriodDays: v ?? 0 })} disabled={readOnly} />
        </Field>
        <Field id="trial-days-billing" label="Free Trial (days)" style={{ marginBottom: 0 }}>
          <NumberInput min="0" step="1" value={version.trialDays} onChange={(v) => onVersionChange({ ...version, trialDays: v ?? 0 })} disabled={readOnly} />
        </Field>
      </div>

      <label className="checkbox-row" style={{ marginTop: 8 }}>
        <input type="checkbox" checked={!!version.autoRenewal} onChange={(e) => onVersionChange({ ...version, autoRenewal: e.target.checked })} disabled={readOnly} />
        Auto-renewal — subscription renews automatically at the end of each billing cycle
      </label>
    </Card>
  );
}
