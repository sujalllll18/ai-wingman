"use client";

import { useState } from "react";
import Card from "../ui/Card";
import Button from "../ui/Button";
import PlanStatusBadge from "../PlanStatusBadge";
import PlanVersionSummary from "./PlanVersionSummary";
import PlanVersionPdfDocument from "./PlanVersionPdfDocument";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString();
}

// Plan Versioning (2026-08-07; Version Details + PDF added 2026-08-09) - a
// published version is immutable (enforced server-side by
// plan.service.js's saveDraftVersion/publishVersion, never re-implemented
// here). The version list stays a compact table; selecting a row now also
// renders that version's complete configuration inline via
// PlanVersionSummary (shared verbatim with the PDF) instead of forcing the
// admin to click through General/Billing/Modules/Limits separately.
export default function VersionsTab({ plan, catalog, versions, selectedVersionId, selectedVersion, onSelectVersion }) {
  const [downloading, setDownloading] = useState(false);

  // Same jsPDF `.html()` technique as every other document export in this
  // app (Invoice/Purchase/Credit Note/Debit Note Viewers) - off-screen
  // render of PlanVersionPdfDocument, never a second PDF pipeline. Always
  // renders `selectedVersion` (whatever the admin is currently viewing),
  // never the live draft-editing state, so a historical version's PDF
  // stays accurate even while a newer draft is being edited elsewhere in
  // the same page.
  async function handleDownloadPdf() {
    setDownloading(true);
    try {
      const node = document.getElementById("plan-version-pdf-source");
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      await doc.html(node, { x: 0, y: 0, width: 210, windowWidth: node.offsetWidth, autoPaging: "text" });
      doc.save(`${plan.slug}-v${selectedVersion.versionNumber}-plan-summary.pdf`);
    } finally {
      setDownloading(false);
    }
  }

  return (
    <>
      <Card>
        <h2 style={{ marginBottom: 4 }}>Versions</h2>
        <p className="form-section-desc">Every configuration this plan has ever had. Published versions are permanent and read-only.</p>

        <div className="review-list" style={{ marginTop: 12 }}>
          {versions.map((v) => (
            <div key={v.id} className="review-row" style={{ alignItems: "center" }}>
              <span className="review-label" style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span className="mono">v{v.versionNumber}</span>
                <PlanStatusBadge status={v.status} />
                {v.id === selectedVersionId && <span className="badge badge-info">Viewing</span>}
              </span>
              <span className="review-value" style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: 12, color: "var(--color-ink-faint)" }}>
                  {v.changeSummary || "—"} · {formatDate(v.createdAt)}
                </span>
                <Button variant="outline" onClick={() => onSelectVersion(v.id)} disabled={v.id === selectedVersionId}>
                  View
                </Button>
              </span>
            </div>
          ))}
        </div>
      </Card>

      {selectedVersion && (
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
            <div>
              <h2 style={{ marginBottom: 4 }}>Version {selectedVersion.versionNumber} Details</h2>
              <p className="form-section-desc" style={{ marginBottom: 0 }}>
                Complete configuration for the version currently selected above.
              </p>
            </div>
            <Button variant="outline" onClick={handleDownloadPdf} disabled={downloading}>
              {downloading ? "Preparing…" : "Download PDF"}
            </Button>
          </div>
          <div style={{ marginTop: 16 }}>
            <PlanVersionSummary plan={plan} version={selectedVersion} catalog={catalog} />
          </div>
        </Card>
      )}

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        <div id="plan-version-pdf-source">
          {selectedVersion && <PlanVersionPdfDocument plan={plan} version={selectedVersion} catalog={catalog} />}
        </div>
      </div>
    </>
  );
}
