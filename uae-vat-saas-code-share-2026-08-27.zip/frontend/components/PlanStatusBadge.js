const LABELS = { ACTIVE: "Active", INACTIVE: "Inactive", ARCHIVED: "Archived", DRAFT: "Draft", PUBLISHED: "Published" };
const BADGE_CLASS = { ACTIVE: "badge-success", INACTIVE: "badge-warning", ARCHIVED: "badge-info", DRAFT: "badge-premium", PUBLISHED: "badge-success" };

// Same badge-family convention as StatusStamp.js/PlanTag.js - covers both a
// Plan's own status (ACTIVE/INACTIVE/ARCHIVED) and a PlanVersion's status
// (DRAFT/PUBLISHED/ARCHIVED), so Plan Builder screens don't need a second
// near-identical component.
export default function PlanStatusBadge({ status }) {
  return <span className={`badge ${BADGE_CLASS[status] || "badge-info"}`}>{LABELS[status] || status}</span>;
}
