import PurchaseClassicTemplate from "./PurchaseClassicTemplate";

// Registry future templates plug into without touching the Purchase Viewer,
// PDF/PNG export, or calculation logic - mirrors invoice-templates/index.js exactly.
export const PURCHASE_TEMPLATES = {
  classic: { label: "Classic", component: PurchaseClassicTemplate },
};

export const DEFAULT_PURCHASE_TEMPLATE = "classic";

export function getPurchaseTemplateComponent(key) {
  return PURCHASE_TEMPLATES[key]?.component || PURCHASE_TEMPLATES[DEFAULT_PURCHASE_TEMPLATE].component;
}
