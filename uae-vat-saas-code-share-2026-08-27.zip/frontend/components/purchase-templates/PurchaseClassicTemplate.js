import { forwardRef } from "react";
import InvoiceWatermark from "../invoices/InvoiceWatermark";

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
}

// Same tax-breakdown-by-rate grouping as ClassicTemplate, reading only each
// line's own frozen snapshot fields.
function buildTaxBreakdown(lineItems) {
  const groups = new Map();
  for (const li of lineItems) {
    const key = `${li.taxRateName || "No tax"}|${li.taxPercentage}`;
    const existing = groups.get(key) || { name: li.taxRateName || "No tax", percentage: li.taxPercentage, taxableAmount: 0, taxAmount: 0 };
    existing.taxableAmount += li.lineTaxableAmount;
    existing.taxAmount += li.lineTaxAmount;
    groups.set(key, existing);
  }
  return Array.from(groups.values());
}

// Purchase's equivalent of ClassicTemplate - same rendering pipeline (on-
// screen preview, PDF, PNG, Print all read this one DOM node), same
// immutability principle (only the bill's own stored snapshot fields, never
// Vendor/Tax Master directly). This is Ledger's own internal record of the
// bill, not a recreation of the vendor's original document - the real
// source document (if uploaded via OCR) is available separately as an
// attachment.
const PurchaseClassicTemplate = forwardRef(function PurchaseClassicTemplate({ purchase }, ref) {
  const taxBreakdown = buildTaxBreakdown(purchase.lineItems || []);
  const watermark =
    purchase.status === "VOID"
      ? "CANCELLED"
      : purchase.status === "DRAFT"
      ? "DRAFT"
      : purchase.paymentStatus === "PAID"
      ? "PAID"
      : null;

  return (
    <div className="invoice-document" ref={ref}>
      {watermark && <InvoiceWatermark label={watermark} />}

      <div className="invoice-doc-header">
        <div className="invoice-doc-brand">
          <div className="invoice-doc-logo-slot" aria-hidden="true" />
          <div className="invoice-doc-business">
            <span className="invoice-doc-label">Bill From</span>
            <strong>{purchase.vendorName}</strong>
            {purchase.vendorAddress && <span>{purchase.vendorAddress}</span>}
            {purchase.vendorTrn && <span>TRN: {purchase.vendorTrn}</span>}
          </div>
        </div>
        <div className="invoice-doc-meta">
          <h1>PURCHASE BILL</h1>
          <table className="invoice-doc-meta-table">
            <tbody>
              <tr>
                <td>Bill #</td>
                <td className="mono">{purchase.billNumberDisplay || "DRAFT"}</td>
              </tr>
              <tr>
                <td>Supplier Invoice #</td>
                <td className="mono">{purchase.supplierInvoiceNumber || "—"}</td>
              </tr>
              <tr>
                <td>Invoice Date</td>
                <td>{formatDate(purchase.invoiceDate)}</td>
              </tr>
              <tr>
                <td>Purchase Date</td>
                <td>{formatDate(purchase.purchaseDate)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <table className="invoice-doc-lines">
        <thead>
          <tr>
            <th>Description</th>
            <th className="num">Qty</th>
            <th className="num">Unit Price</th>
            <th className="num">Tax</th>
            <th className="num">Amount</th>
          </tr>
        </thead>
        <tbody>
          {(purchase.lineItems || []).map((li) => (
            <tr key={li.id}>
              <td>{li.description}</td>
              <td className="num">{li.quantity}</td>
              <td className="num">{formatCurrency(li.unitPrice, purchase.currency)}</td>
              <td className="num">{li.taxRateName ? `${li.taxPercentage}%` : "—"}</td>
              <td className="num">{formatCurrency(li.lineTotal, purchase.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="invoice-doc-totals-row">
        {taxBreakdown.length > 0 && (
          <table className="invoice-doc-tax-breakdown">
            <thead>
              <tr>
                <th>Tax Breakdown</th>
                <th className="num">Taxable Amount</th>
                <th className="num">Tax</th>
              </tr>
            </thead>
            <tbody>
              {taxBreakdown.map((g) => (
                <tr key={g.name}>
                  <td>
                    {g.name} ({g.percentage}%)
                  </td>
                  <td className="num">{formatCurrency(g.taxableAmount, purchase.currency)}</td>
                  <td className="num">{formatCurrency(g.taxAmount, purchase.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <table className="invoice-doc-summary">
          <tbody>
            <tr>
              <td>Subtotal</td>
              <td className="num">{formatCurrency(purchase.subtotal, purchase.currency)}</td>
            </tr>
            <tr>
              <td>VAT</td>
              <td className="num">{formatCurrency(purchase.vatTotal, purchase.currency)}</td>
            </tr>
            <tr className="invoice-doc-grand-total">
              <td>Grand Total</td>
              <td className="num">{formatCurrency(purchase.grandTotal, purchase.currency)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {purchase.notes && (
        <div className="invoice-doc-notes">
          <span className="invoice-doc-label">Notes</span>
          <p>{purchase.notes}</p>
        </div>
      )}

      <div className="invoice-doc-footer">
        <span>Internal record generated by Ledger - not the supplier&apos;s original document.</span>
      </div>
    </div>
  );
});

export default PurchaseClassicTemplate;
