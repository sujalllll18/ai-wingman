"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Table from "../ui/Table";
import TableScroll from "../ui/TableScroll";
import EmptyState from "../ui/EmptyState";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// "Clicking any summary value opens the supporting transactions" - fetches
// live from the drilldown endpoint (never a stored snapshot list) whenever
// it's opened for a new type/category, reusing the plain Table component
// rather than navigating away from the VAT Return page.
export default function VatDrilldownModal({ open, onClose, vatReturnId, type, category, label }) {
  const [transactions, setTransactions] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open || !vatReturnId || !type || !category) return;
    setTransactions(null);
    setError("");
    (async () => {
      try {
        const token = tenantAuth.get();
        const { transactions } = await api.getVatReturnDrilldown(token, vatReturnId, type, category);
        setTransactions(transactions);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, [open, vatReturnId, type, category]);

  const COLUMNS = [
    { key: "reference", header: type === "sales" ? "Invoice #" : "Bill #", render: (t) => <span className="mono">{t.reference || "Draft"}</span> },
    { key: "counterparty", header: type === "sales" ? "Customer" : "Vendor", render: (t) => t.counterparty },
    { key: "date", header: "Date", render: (t) => formatDate(t.date) },
    { key: "subtotal", header: "Subtotal", render: (t) => formatCurrency(t.subtotal) },
    { key: "vatTotal", header: "VAT", render: (t) => formatCurrency(t.vatTotal) },
    { key: "grandTotal", header: "Total", render: (t) => formatCurrency(t.grandTotal) },
    {
      key: "actions",
      header: "",
      render: (t) => (
        <Link href={type === "sales" ? `/tenant/invoices/${t.id}` : `/tenant/purchases/${t.id}`} className="btn btn-outline btn-sm" target="_blank" rel="noopener noreferrer">
          View
        </Link>
      ),
    },
  ];

  return (
    <Modal open={open} onClose={onClose} ariaLabel={`Transactions for ${label}`} size="lg">
      <h2 style={{ marginBottom: 4 }}>{label}</h2>
      <p className="helptext" style={{ marginBottom: 20 }}>
        {type === "sales" ? "Sent invoices" : "Recorded purchase bills"} contributing to this value.
      </p>

      {error && <p className="field-error" role="alert">{error}</p>}

      {transactions === null && !error ? (
        <p className="helptext">Loading…</p>
      ) : transactions && transactions.length === 0 ? (
        <EmptyState title="No transactions" description="Nothing contributed to this value in the selected period." />
      ) : (
        transactions && (
          <TableScroll>
            <Table columns={COLUMNS} rows={transactions} rowKey={(t) => t.id} />
          </TableScroll>
        )
      )}
    </Modal>
  );
}
