// Single-axis status - Draft -> Locked, mirroring the badge pattern from
// Invoice/Purchase but simpler since VAT Return has no payment axis.
const STATUS_BADGE = {
  DRAFT: { label: "Draft", className: "badge-info" },
  LOCKED: { label: "Locked", className: "badge-success" },
};

export default function VatReturnStatusBadge({ vatReturn }) {
  const status = STATUS_BADGE[vatReturn.status] || STATUS_BADGE.DRAFT;
  return <span className={`badge ${status.className}`}>{status.label}</span>;
}
