import Card from "../ui/Card";

// Non-blocking, purely informational - "Do not block the return. Only warn
// the user." Computed live server-side every time the return is loaded
// (never stored), so it always reflects the current state of Invoice/
// Purchase data even for an old Draft return.
export default function ValidationPanel({ warnings }) {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Validation</h3>
      {!warnings || warnings.length === 0 ? (
        <p className="helptext" style={{ margin: 0 }}>No issues found for this period.</p>
      ) : (
        <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 10 }}>
          {warnings.map((w) => (
            <li key={w.code} className="validation-warning-row">
              <svg viewBox="0 0 24 24" className="validation-warning-icon" aria-hidden="true">
                <path d="M12 3.5 21.5 20h-19L12 3.5z" />
                <path d="M12 9.5v5M12 17.5h.01" />
              </svg>
              <span>{w.message}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
