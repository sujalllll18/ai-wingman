const TYPE_LABEL = {
  GENERATED: "VAT Return Generated",
  REGENERATED: "Regenerated",
  LOCKED: "Locked",
  UNLOCKED: "Unlocked",
  EXPORTED: "Exported",
  VIEWED: "Viewed",
};

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Mirrors Invoice/Purchase ActivityTimeline exactly.
export default function VatReturnActivityTimeline({ activities }) {
  if (!activities || activities.length === 0) {
    return <p className="helptext" style={{ margin: 0 }}>No activity yet.</p>;
  }

  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
      {activities.map((a) => (
        <li key={a.id} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span
            aria-hidden="true"
            style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--color-accent)", marginTop: 6, flexShrink: 0 }}
          />
          <div>
            <div style={{ fontWeight: 600, fontSize: 13 }}>{TYPE_LABEL[a.type] || a.type}</div>
            {a.description && <div className="helptext" style={{ margin: "2px 0 0" }}>{a.description}</div>}
            <div className="helptext" style={{ margin: "2px 0 0", fontSize: 11 }}>{formatDateTime(a.createdAt)}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}
