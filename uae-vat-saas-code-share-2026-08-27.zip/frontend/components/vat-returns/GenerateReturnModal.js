"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function currentYear() {
  return new Date().getFullYear();
}

// Period Type is a free choice every time a return is generated (confirmed
// decision) - no Tenant-level filing-frequency setting, so both Monthly and
// Quarterly are always offered.
export default function GenerateReturnModal({ open, onClose, onSuccess }) {
  const [periodType, setPeriodType] = useState("MONTHLY");
  const [year, setYear] = useState(currentYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [quarter, setQuarter] = useState(Math.floor(new Date().getMonth() / 3) + 1);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const years = Array.from({ length: 6 }, (_, i) => currentYear() - 4 + i);

  function resetAndClose() {
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const { vatReturn } = await api.generateVatReturn(token, {
        periodType,
        year,
        ...(periodType === "MONTHLY" ? { month } : { quarter }),
      });
      onSuccess(vatReturn);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} ariaLabel="Generate VAT Return">
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 4 }}>Generate VAT Return</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>
          Ledger will automatically aggregate all Sent invoices and Recorded purchase bills in this period - nothing is calculated manually.
        </p>

        <ErrorBanner message={error} />

        <div className="field" style={{ marginBottom: 16 }}>
          <label>Tax Period</label>
          <div className="segmented-control" role="radiogroup" aria-label="Tax Period">
            <button type="button" className={`segmented-option${periodType === "MONTHLY" ? " selected" : ""}`} onClick={() => setPeriodType("MONTHLY")}>
              Monthly
            </button>
            <button type="button" className={`segmented-option${periodType === "QUARTERLY" ? " selected" : ""}`} onClick={() => setPeriodType("QUARTERLY")}>
              Quarterly
            </button>
          </div>
        </div>

        <div className="form-grid">
          <Field id="vat-return-year" label="Year">
            <Select value={year} onChange={(e) => setYear(Number(e.target.value))}>
              {years.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </Select>
          </Field>

          {periodType === "MONTHLY" ? (
            <Field id="vat-return-month" label="Month">
              <Select value={month} onChange={(e) => setMonth(Number(e.target.value))}>
                {MONTHS.map((m, i) => (
                  <option key={m} value={i + 1}>
                    {m}
                  </option>
                ))}
              </Select>
            </Field>
          ) : (
            <Field id="vat-return-quarter" label="Quarter">
              <Select value={quarter} onChange={(e) => setQuarter(Number(e.target.value))}>
                <option value={1}>Q1 (Jan - Mar)</option>
                <option value={2}>Q2 (Apr - Jun)</option>
                <option value={3}>Q3 (Jul - Sep)</option>
                <option value={4}>Q4 (Oct - Dec)</option>
              </Select>
            </Field>
          )}
        </div>

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Generating…" : "Generate Return"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
