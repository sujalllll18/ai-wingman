import Card from "../ui/Card";
import TableScroll from "../ui/TableScroll";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

const SALES_ROWS = [
  { key: "STANDARD_RATED", label: "Standard Rated Sales", field: "standardRatedSales" },
  { key: "ZERO_RATED", label: "Zero Rated Sales", field: "zeroRatedSales" },
  { key: "EXEMPT", label: "Exempt Sales", field: "exemptSales" },
  { key: "OUT_OF_SCOPE", label: "Out of Scope Sales", field: "outOfScopeSales" },
];

const PURCHASE_ROWS = [
  { key: "STANDARD_RATED", label: "Standard Rated Purchases", field: "standardRatedPurchases" },
  { key: "ZERO_RATED", label: "Zero Rated Purchases", field: "zeroRatedPurchases" },
  { key: "EXEMPT", label: "Exempt Purchases", field: "exemptPurchases" },
  { key: "OUT_OF_SCOPE", label: "Out of Scope Purchases", field: "outOfScopePurchases" },
];

// "Clicking any summary value opens the supporting transactions" - every
// value row here is a button that hands (type, category, label) up to the
// parent, which drives VatDrilldownModal. Generated automatically from
// recorded transactions; nothing here is editable.
export default function VatSummaryTable({ vatReturn, onDrilldown }) {
  return (
    <>
      <Card>
        <h3 style={{ marginTop: 0 }}>Sales (Output VAT)</h3>
        <TableScroll>
          <table className="data-table">
            <tbody>
              {SALES_ROWS.map((row) => (
                <tr key={row.key}>
                  <td>{row.label}</td>
                  <td className="num">
                    <button type="button" className="vat-summary-value-btn" onClick={() => onDrilldown("sales", row.key, row.label)}>
                      {formatCurrency(vatReturn[row.field])}
                    </button>
                  </td>
                </tr>
              ))}
              <tr>
                <td style={{ fontWeight: 600 }}>Output VAT</td>
                <td className="num" style={{ fontWeight: 600 }}>
                  <button type="button" className="vat-summary-value-btn" onClick={() => onDrilldown("sales", "OUTPUT_VAT", "Output VAT")}>
                    {formatCurrency(vatReturn.outputVat)}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </TableScroll>
      </Card>

      <Card>
        <h3 style={{ marginTop: 0 }}>Purchases (Input VAT)</h3>
        <TableScroll>
          <table className="data-table">
            <tbody>
              {PURCHASE_ROWS.map((row) => (
                <tr key={row.key}>
                  <td>{row.label}</td>
                  <td className="num">
                    <button type="button" className="vat-summary-value-btn" onClick={() => onDrilldown("purchases", row.key, row.label)}>
                      {formatCurrency(vatReturn[row.field])}
                    </button>
                  </td>
                </tr>
              ))}
              <tr>
                <td style={{ fontWeight: 600 }}>Input VAT</td>
                <td className="num" style={{ fontWeight: 600 }}>
                  <button type="button" className="vat-summary-value-btn" onClick={() => onDrilldown("purchases", "INPUT_VAT", "Input VAT")}>
                    {formatCurrency(vatReturn.inputVat)}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </TableScroll>
      </Card>

      <Card>
        <h3 style={{ marginTop: 0 }}>Calculated Totals</h3>
        <div className="summary-rows" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="helptext">Output VAT</span>
            <span className="mono">{formatCurrency(vatReturn.outputVat)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="helptext">Input VAT</span>
            <span className="mono">{formatCurrency(vatReturn.inputVat)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="helptext">Recoverable VAT</span>
            <span className="mono">{formatCurrency(vatReturn.recoverableVat)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid var(--color-line)", paddingTop: 8, fontWeight: 600 }}>
            <span>{vatReturn.netVatPayable >= 0 ? "Net VAT Payable" : "Net VAT Refundable"}</span>
            <span className="mono">{formatCurrency(Math.abs(vatReturn.netVatPayable))}</span>
          </div>
        </div>
      </Card>
    </>
  );
}
