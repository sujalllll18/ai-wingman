import Card from "../ui/Card";
import ProfileField from "../tenant-profile/ProfileField";
import ApprovalStatusBadge from "../approvals/ApprovalStatusBadge";

function formatDateTime(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function OverviewTab({ request }) {
  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Summary</h2>
      <div className="review-list">
        <ProfileField label="Status" value={<ApprovalStatusBadge status={request.status} />} />
        <ProfileField label="Module" value={request.module.replace(/_/g, " ")} />
        <ProfileField label="Action" value={request.action.replace(/_/g, " ")} />
        <ProfileField
          label="Entity"
          value={request.entityType}
          tooltip="—"
        />
        <ProfileField label="Record ID" value={request.entityId} tooltip="Not created yet - this is a pending Create request." />
        <ProfileField label="Priority" value={request.priority} />
        <ProfileField label="Requested By" value={request.requestedByName} />
        <ProfileField label="Requested On" value={formatDateTime(request.requestedAt)} />
        <ProfileField label="Reason" value={request.reason} tooltip="No reason was given." />
        {request.status !== "PENDING" && (
          <>
            <ProfileField label="Decided By" value={request.decidedByName} />
            <ProfileField label="Decided On" value={formatDateTime(request.decidedAt)} />
            <ProfileField label="Decision Comments" value={request.decisionComments} tooltip="No comments were left." />
          </>
        )}
      </div>
    </Card>
  );
}
