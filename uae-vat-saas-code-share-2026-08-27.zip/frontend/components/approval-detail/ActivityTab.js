import Card from "../ui/Card";

const TYPE_LABEL = {
  SUBMITTED: "Submitted for Approval",
  APPROVED: "Approved",
  REJECTED: "Rejected",
  CANCELLED: "Cancelled",
  COMMENTED: "Comment Added",
};

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// Same append-only-timeline shape as ActivityTimeline.js (Invoices) /
// PurchaseActivityTimeline.js / VatReturnActivityTimeline.js - oldest first
// here since a decision trail (submit -> decide) reads naturally top-to-bottom.
export default function ActivityTab({ request }) {
  const activities = request.activities || [];

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Activity</h2>
      {activities.length === 0 ? (
        <p className="helptext" style={{ margin: 0 }}>No activity yet.</p>
      ) : (
        <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
          {activities.map((a) => (
            <li key={a.id} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <span
                aria-hidden="true"
                style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--color-accent)", marginTop: 6, flexShrink: 0 }}
              />
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>
                  {TYPE_LABEL[a.type] || a.type} <span style={{ fontWeight: 400, color: "var(--color-ink-faint)" }}>· {a.actorName || "System"}</span>
                </div>
                {a.comment && <div className="helptext" style={{ margin: "2px 0 0" }}>{a.comment}</div>}
                <div className="helptext" style={{ margin: "2px 0 0", fontSize: 11 }}>{formatDateTime(a.createdAt)}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
