import Card from "../ui/Card";

function displayValue(v) {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

// Renders the proposed change as an old-value/new-value table. For a CREATE
// (no previousValues) every payload field is simply "new". For an
// update/delete, only fields that actually differ are highlighted.
export default function ChangesTab({ request }) {
  const payload = request.payload || {};
  const previous = request.previousValues || {};
  const keys = Array.from(new Set([...Object.keys(previous), ...Object.keys(payload)]));

  if (keys.length === 0) {
    return (
      <Card>
        <p className="helptext" style={{ margin: 0 }}>No field-level changes were recorded with this request.</p>
      </Card>
    );
  }

  return (
    <Card>
      <h2 style={{ marginBottom: 4 }}>Proposed Changes</h2>
      <p className="form-section-desc">
        {Object.keys(previous).length === 0 ? "New record - every field below is being created." : "Fields that differ from the current record are highlighted."}
      </p>
      <table className="data-table">
        <thead>
          <tr>
            <th>Field</th>
            <th>Current Value</th>
            <th>Proposed Value</th>
          </tr>
        </thead>
        <tbody>
          {keys.map((key) => {
            const oldVal = previous[key];
            const newVal = payload[key];
            const changed = Object.keys(previous).length === 0 || JSON.stringify(oldVal) !== JSON.stringify(newVal);
            return (
              <tr key={key}>
                <td>{key}</td>
                <td>{displayValue(oldVal)}</td>
                <td style={changed ? { fontWeight: 600, color: "var(--color-sidebar-accent)" } : undefined}>{displayValue(newVal)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </Card>
  );
}
