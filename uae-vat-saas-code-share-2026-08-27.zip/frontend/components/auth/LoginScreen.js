"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../lib/api";
import { adminAuth, tenantAuth } from "../../lib/auth";
import { isValidEmail } from "../../lib/validation";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import PasswordInput from "../PasswordInput";
import Tooltip from "../ui/Tooltip";

const ROLES = [
  { value: "tenant", label: "Business User" },
  { value: "admin", label: "Platform Admin" },
];

const DEMO_CREDENTIALS = [
  { role: "Business User", email: "admin@testbusiness.test" },
  { role: "Platform Admin", email: "admin@platform.local" },
];

// Icons reused verbatim from the tenant sidebar (app/tenant/layout.js) where
// they already represent Invoices / Purchases / VAT Returns - same visual
// vocabulary, not a new icon set invented for this page.
const FEATURES = [
  {
    label: "UAE VAT Compliant",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 3.5 5 6v6c0 4.2 2.9 7.4 7 8.5 4.1-1.1 7-4.3 7-8.5V6l-7-2.5z" />
        <path d="M8.5 12.2 11 14.7l4.5-4.9" />
      </svg>
    ),
  },
  {
    label: "Invoice Management",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
        <path d="M8 8h8M8 12h8M8 16h5" />
      </svg>
    ),
  },
  {
    label: "Purchase Tracking",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="20" r="1.4" />
        <circle cx="17" cy="20" r="1.4" />
        <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
      </svg>
    ),
  },
  {
    label: "VAT Return Generation",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="7" cy="7" r="2.5" />
        <circle cx="17" cy="17" r="2.5" />
        <path d="M18 6 6 18" />
      </svg>
    ),
  },
];

const TRUST_ITEMS = ["Secure Authentication", "Role-Based Access", "Multi-Tenant SaaS", "Encrypted Data"];

// Single implementation shared by both entry points ("/" and "/login") so
// there is exactly one authentication screen in the app, per the 2026-08-06
// UI/UX sprint that retired the separate marketing-style home page. Auth
// logic (role switch, validation, submit, remember-me, forgot-password
// placeholder) is unchanged from the previous /login page - this pass only
// restyles the surrounding layout into a split screen and adds the demo
// credentials/product-showcase content.
export default function LoginScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialRole = searchParams.get("role") === "admin" ? "admin" : "tenant";

  const [role, setRole] = useState(initialRole);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const emailError = !email.trim() ? "Email is required." : !isValidEmail(email) ? "Enter a valid email address." : "";
  const passwordError = !password ? "Password is required." : "";

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ email: true, password: true });
    if (emailError || passwordError) return;

    setError("");
    setLoading(true);
    try {
      if (role === "admin") {
        const { token } = await api.adminLogin(email, password);
        adminAuth.save(token, remember);
        router.push("/admin/dashboard");
      } else {
        const { token, user, tenant } = await api.tenantLogin(email, password);
        tenantAuth.save(token, user, tenant, remember);
        // Forced password change (2026-08-09) - a temporary-password
        // account is sent straight to the change-password screen instead
        // of the dashboard; every other tenant endpoint is also blocked
        // server-side until they change it (see requireTenantUser).
        router.push(user.mustChangePassword ? "/tenant/change-password" : "/tenant/dashboard");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="auth-split">
      <div className="auth-split-left">
        <form className="auth-form" onSubmit={handleSubmit} noValidate>
          <div className="auth-brand-mark">L</div>
          <span className="eyebrow">UAE VAT Invoice &amp; Management</span>
          <h1 className="auth-heading">Welcome Back</h1>
          <p className="auth-sub">Sign in to manage invoices, purchases, VAT returns and compliance.</p>

          <div className="segmented-control" role="radiogroup" aria-label="Sign in as">
            {ROLES.map((r) => (
              <button
                type="button"
                key={r.value}
                className={`segmented-option${role === r.value ? " selected" : ""}`}
                aria-pressed={role === r.value}
                onClick={() => setRole(r.value)}
              >
                {r.label}
              </button>
            ))}
          </div>

          <ErrorBanner message={error} />

          <Field id="email" label="Email" error={touched.email ? emailError : undefined}>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onBlur={() => setTouched((t) => ({ ...t, email: true }))}
              autoComplete="username"
            />
          </Field>

          <div className="field">
            <label htmlFor="password">Password</label>
            <PasswordInput
              id="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onBlur={() => setTouched((t) => ({ ...t, password: true }))}
              error={touched.password ? passwordError : undefined}
            />
            {touched.password && passwordError && (
              <p id="password-error" className="field-error" role="alert">
                {passwordError}
              </p>
            )}
          </div>

          <div className="auth-remember-row">
            <label className="remember-me-row">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              Remember me
            </label>
            <Tooltip label="Not available yet">
              <button type="button" className="link-btn" disabled>
                Forgot password?
              </button>
            </Tooltip>
          </div>

          <Button type="submit" disabled={loading} style={{ width: "100%", justifyContent: "center" }}>
            {loading ? "Signing in…" : "Sign In"}
          </Button>

          <div className="auth-demo-creds">
            <span className="auth-demo-heading">Demo Accounts</span>
            {DEMO_CREDENTIALS.map((d) => (
              <div className="auth-demo-row" key={d.role}>
                <span className="auth-demo-role">{d.role}</span>
                <span className="auth-demo-email mono">{d.email}</span>
              </div>
            ))}
          </div>
        </form>
      </div>

      <div className="auth-split-right" aria-hidden="true">
        <div className="auth-mockup">
          <svg viewBox="0 0 600 500" preserveAspectRatio="xMidYMid slice">
            <rect x="0" y="0" width="120" height="500" fill="#ffffff" opacity="0.14" />
            <rect x="150" y="30" width="140" height="70" rx="10" fill="#ffffff" opacity="0.16" />
            <rect x="304" y="30" width="140" height="70" rx="10" fill="#ffffff" opacity="0.12" />
            <rect x="458" y="30" width="120" height="70" rx="10" fill="#ffffff" opacity="0.16" />
            <rect x="150" y="130" width="428" height="150" rx="10" fill="#ffffff" opacity="0.1" />
            <rect x="176" y="220" width="24" height="46" fill="#ffffff" opacity="0.22" />
            <rect x="216" y="190" width="24" height="76" fill="#ffffff" opacity="0.22" />
            <rect x="256" y="160" width="24" height="106" fill="#ffffff" opacity="0.28" />
            <rect x="296" y="200" width="24" height="66" fill="#ffffff" opacity="0.22" />
            <rect x="336" y="175" width="24" height="91" fill="#ffffff" opacity="0.24" />
            <rect x="376" y="210" width="24" height="56" fill="#ffffff" opacity="0.2" />
            <rect x="150" y="310" width="428" height="150" rx="10" fill="#ffffff" opacity="0.09" />
            <rect x="176" y="336" width="376" height="12" rx="4" fill="#ffffff" opacity="0.22" />
            <rect x="176" y="368" width="340" height="12" rx="4" fill="#ffffff" opacity="0.16" />
            <rect x="176" y="400" width="360" height="12" rx="4" fill="#ffffff" opacity="0.16" />
            <rect x="176" y="432" width="300" height="12" rx="4" fill="#ffffff" opacity="0.16" />
          </svg>
        </div>
        <div className="auth-split-right-scrim" />

        <div className="auth-split-right-content">
          <h2 className="auth-showcase-heading">Manage UAE VAT with confidence.</h2>
          <p className="auth-showcase-desc">
            Generate compliant invoices.
            <br />
            Record purchases.
            <br />
            Track VAT automatically.
            <br />
            Prepare VAT Returns.
          </p>

          <div className="auth-feature-grid">
            {FEATURES.map((f) => (
              <div className="auth-feature-card" key={f.label}>
                <span className="auth-feature-icon">{f.icon}</span>
                <span>{f.label}</span>
              </div>
            ))}
          </div>

          <div className="auth-trust-row">
            {TRUST_ITEMS.map((t) => (
              <span className="auth-trust-item" key={t}>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <circle cx="12" cy="12" r="9" />
                  <path d="M8.5 12.2 11 14.7l4.5-4.9" />
                </svg>
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
