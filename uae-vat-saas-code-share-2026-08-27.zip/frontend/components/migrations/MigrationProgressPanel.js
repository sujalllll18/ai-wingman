import Card from "../ui/Card";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// "Migration in Progress" panel - generalizes the per-batch progress card
// already proven on app/tenant/imports/[id]/page.js to the aggregated,
// multi-entity shape migrationOrchestrator.service.js's getMigrationStatus
// returns. Same live-polling pattern: the caller re-fetches status every
// ~2s while isRunning and passes the fresh object back in as props.
export default function MigrationProgressPanel({ status, isRunning }) {
  if (!status) return null;
  const progressPct = status.totalRecords > 0 ? Math.min(100, Math.round((status.processedRecords / status.totalRecords) * 100)) : 0;

  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, flexWrap: "wrap", gap: 8 }}>
        <strong>
          {isRunning ? "Migration in Progress" : status.status === "PAUSED" ? "Migration Paused" : "Migration"} — {status.processedRecords} / {status.totalRecords}
        </strong>
        <span>{progressPct}%</span>
      </div>
      <div style={{ height: 10, borderRadius: 5, background: "var(--color-surface-sunken)", overflow: "hidden" }}>
        <div
          style={{
            height: "100%",
            width: `${progressPct}%`,
            background: status.failedCount > 0 ? "var(--color-danger)" : "var(--color-accent)",
            transition: "width 0.3s ease",
          }}
        />
      </div>

      <div style={{ display: "flex", gap: 32, flexWrap: "wrap", marginTop: 16 }}>
        <div>
          <div className="helptext">Successful</div>
          <div style={{ fontSize: 18, fontWeight: 600, color: "var(--color-success)" }}>{status.successCount}</div>
        </div>
        <div>
          <div className="helptext">Failed</div>
          <div style={{ fontSize: 18, fontWeight: 600, color: status.failedCount > 0 ? "var(--color-danger)" : "inherit" }}>{status.failedCount}</div>
        </div>
        {status.currentEntity && (
          <div>
            <div className="helptext">Current Entity</div>
            <div style={{ fontSize: 18, fontWeight: 600 }}>{status.currentEntity}</div>
          </div>
        )}
        {status.currentEntity && (
          <div>
            <div className="helptext">Current Batch</div>
            <div style={{ fontSize: 18, fontWeight: 600 }}>
              {status.currentBatchNumber} / {status.totalChunksForCurrentEntity}
            </div>
          </div>
        )}
      </div>

      {status.perEntity?.length > 1 && (
        <div style={{ marginTop: 16, paddingTop: 16, borderTop: "1px solid var(--color-line)" }}>
          {status.perEntity.map((e) => (
            <div key={e.batchId} className="review-row">
              <span>{e.label}</span>
              <span className="mono">
                {e.processed} / {e.total} {e.failed > 0 ? `(${e.failed} failed)` : ""}
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="helptext" style={{ marginTop: 12 }}>
        Started {formatDate(status.migration?.startedAt)}
        {status.migration?.completedAt ? ` · Completed ${formatDate(status.migration.completedAt)}` : ""}
      </div>
    </Card>
  );
}
