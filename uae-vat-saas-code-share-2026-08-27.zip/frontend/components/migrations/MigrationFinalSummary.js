import Link from "next/link";
import Card from "../ui/Card";
import Button from "../ui/Button";

const STATUS_LABEL = {
  COMPLETED: "Migration Completed",
  COMPLETED_WITH_ERRORS: "Migration Completed With Errors",
  FAILED: "Migration Failed",
  CANCELLED: "Migration Cancelled",
};

function formatDuration(startedAt, completedAt) {
  if (!startedAt || !completedAt) return "—";
  const ms = new Date(completedAt) - new Date(startedAt);
  if (ms < 0) return "—";
  const totalSeconds = Math.round(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
}

// The terminal-state view of a Migration - Total/Success/Failed/Skipped/
// Duration + one row per entity + the required action set. Reads the exact
// same aggregated `status` shape MigrationProgressPanel does (they're two
// views of the same migrationOrchestrator.getMigrationStatus() response),
// so a historical (already-completed) Migration and a just-finished one
// render identically.
export default function MigrationFinalSummary({ status, onViewFailed, onDownloadErrorReport, onDownloadMigrationReport, onRetryFailed, canRetry, goToTenantHref }) {
  if (!status) return null;
  const skipped = status.perEntity?.reduce((sum, e) => sum + Math.max(0, e.total - e.processed), 0) || 0;

  return (
    <Card>
      <h2 style={{ marginTop: 0 }}>{STATUS_LABEL[status.status] || status.status}</h2>

      <div style={{ display: "flex", gap: 32, flexWrap: "wrap", margin: "16px 0" }}>
        <SummaryNumber label="Total Records" value={status.totalRecords} />
        <SummaryNumber label="Successfully Imported" value={status.successCount} tone="success" />
        <SummaryNumber label="Failed" value={status.failedCount} tone={status.failedCount > 0 ? "danger" : undefined} />
        <SummaryNumber label="Skipped" value={skipped} />
        <SummaryNumber label="Duration" value={formatDuration(status.migration?.startedAt, status.migration?.completedAt)} isText />
      </div>

      <div style={{ borderTop: "1px solid var(--color-line)", paddingTop: 16 }}>
        {status.perEntity?.map((e) => (
          <div key={e.batchId} className="review-row">
            <span>{e.label}</span>
            <span className="mono">
              {e.success} / {e.total}
              {e.failed > 0 ? ` · ${e.failed} failed` : ""}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 24 }}>
        {status.failedCount > 0 && onViewFailed && (
          <Button variant="outline" onClick={onViewFailed}>
            View Failed Records
          </Button>
        )}
        {status.failedCount > 0 && onDownloadErrorReport && (
          <Button variant="outline" onClick={onDownloadErrorReport}>
            Download Error Report
          </Button>
        )}
        {onDownloadMigrationReport && (
          <Button variant="outline" onClick={onDownloadMigrationReport}>
            Download Migration Report
          </Button>
        )}
        {status.status === "COMPLETED_WITH_ERRORS" && status.failedCount > 0 && canRetry && onRetryFailed && (
          <Button onClick={onRetryFailed}>Retry Failed Records</Button>
        )}
        {goToTenantHref && (
          <Link href={goToTenantHref} className="btn btn-outline">
            Go to Tenant
          </Link>
        )}
      </div>
    </Card>
  );
}

function SummaryNumber({ label, value, tone, isText }) {
  const toneVar = tone === "success" ? "var(--color-success)" : tone === "danger" ? "var(--color-danger)" : "inherit";
  return (
    <div>
      <div className="helptext">{label}</div>
      <div style={{ fontSize: isText ? 18 : 22, fontWeight: 600, color: toneVar }}>{value}</div>
    </div>
  );
}
