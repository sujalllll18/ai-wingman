import Card from "../ui/Card";

function formatMoney(amount, currency = "AED") {
  if (amount === null || amount === undefined) return "—";
  return `${currency} ${Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// One card per entity/file in a Migration - Total/Ready/Warnings/Errors/
// Duplicates counts, plus the financial reconciliation block when the
// entity's adapter defines one (see importAdapters.js's optional
// summarizeFinancials hook - Customers has none, Invoices/Purchases do).
// Reused by the Migration Review (pre-commit) screen and, read-only, by the
// Final Summary / History detail screens.
export default function MigrationEntitySummaryTable({ entities, onViewErrors, onViewWarnings, onViewDuplicates }) {
  if (!entities || entities.length === 0) return null;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {entities.map((e) => (
        <Card key={e.batchId}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 8 }}>
            <h3 style={{ margin: 0 }}>{e.label}</h3>
            <span className="helptext">{e.sourceFileName}</span>
          </div>

          <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginTop: 12 }}>
            <SummaryStat label="Total" value={e.total} />
            <SummaryStat label="Ready" value={e.ready} tone="success" />
            <SummaryStat label="Warnings" value={e.warnings} tone="warning" onClick={e.warnings > 0 ? () => onViewWarnings?.(e) : undefined} />
            <SummaryStat label="Errors" value={e.errors} tone="danger" onClick={e.errors > 0 ? () => onViewErrors?.(e) : undefined} />
            <SummaryStat label="Duplicates" value={e.duplicates} tone="warning" onClick={e.duplicates > 0 ? () => onViewDuplicates?.(e) : undefined} />
          </div>

          {e.financialSummary && (
            <div style={{ marginTop: 16, paddingTop: 16, borderTop: "1px solid var(--color-line)" }}>
              <h4 style={{ margin: "0 0 8px" }}>Financial Impact</h4>
              <div className="review-list">
                <div className="review-row">
                  <span>Subtotal</span>
                  <span className="mono">{formatMoney(e.financialSummary.subtotal)}</span>
                </div>
                <div className="review-row">
                  <span>Discount</span>
                  <span className="mono">{formatMoney(e.financialSummary.discountTotal)}</span>
                </div>
                <div className="review-row">
                  <span>Taxable Amount</span>
                  <span className="mono">{formatMoney(e.financialSummary.taxableAmount)}</span>
                </div>
                <div className="review-row">
                  <span>VAT</span>
                  <span className="mono">{formatMoney(e.financialSummary.vatTotal)}</span>
                </div>
                <div className="review-row" style={{ fontWeight: 600 }}>
                  <span>Grand Total</span>
                  <span className="mono">{formatMoney(e.financialSummary.grandTotal)}</span>
                </div>
              </div>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

function SummaryStat({ label, value, tone, onClick }) {
  const toneVar = tone === "success" ? "var(--color-success)" : tone === "warning" ? "var(--color-warning)" : tone === "danger" ? "var(--color-danger)" : "inherit";
  const content = (
    <>
      <div style={{ fontSize: "var(--text-small)", color: "var(--color-ink-soft)" }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 600, color: value > 0 ? toneVar : "inherit" }}>{value}</div>
    </>
  );
  if (!onClick) return <div>{content}</div>;
  return (
    <button type="button" onClick={onClick} style={{ background: "none", border: "none", padding: 0, textAlign: "left", cursor: "pointer" }}>
      {content}
    </button>
  );
}
