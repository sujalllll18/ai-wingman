// Shown before the Preview step whenever a tenant already has any existing
// data (section 10 of the Migration spec) - a plain informational banner,
// never a hard block. The actual duplicate-vs-existing-record detection
// still happens per-row during Validate (each adapter's own buildContext/
// validateRow, unchanged) - this is purely the up-front heads-up.
export default function ExistingTenantDataWarning({ counts }) {
  if (!counts) return null;
  const { customerCount = 0, invoiceCount = 0, purchaseBillCount = 0 } = counts;
  if (customerCount === 0 && invoiceCount === 0 && purchaseBillCount === 0) return null;

  return (
    <div className="card" style={{ borderColor: "var(--color-amber, var(--color-warning))", background: "var(--color-warning-soft, var(--color-surface-sunken))", marginBottom: 20 }}>
      <strong>This tenant already contains data.</strong>
      <p className="helptext" style={{ marginTop: 4, marginBottom: 8 }}>
        Imported records will be checked against existing records for duplicates. Records flagged as possible
        duplicates are still imported by default but shown as warnings for your review — they are never silently
        overwritten.
      </p>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
        <span>
          <strong>{customerCount}</strong> existing Customer{customerCount === 1 ? "" : "s"}
        </span>
        <span>
          <strong>{invoiceCount}</strong> existing Invoice{invoiceCount === 1 ? "" : "s"}
        </span>
        <span>
          <strong>{purchaseBillCount}</strong> existing Purchase Bill{purchaseBillCount === 1 ? "" : "s"}
        </span>
      </div>
    </div>
  );
}
