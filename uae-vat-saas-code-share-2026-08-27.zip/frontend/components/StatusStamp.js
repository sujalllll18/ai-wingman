export default function StatusStamp({ status }) {
  const isActive = status === "ACTIVE";
  return (
    <span className={`badge ${isActive ? "badge-success" : "badge-danger"}`} aria-label={`Status: ${status}`}>
      {isActive ? "Active" : "Suspended"}
    </span>
  );
}
