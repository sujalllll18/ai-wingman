"use client";

import { useState } from "react";
import { api } from "../../lib/api";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";

const EMPTY_FORM = { name: "", email: "", password: "" };

// Add Member (Team self-service module, 2026-08-09). Deliberately never
// blocks itself from opening or being filled in on any plan-limit
// consideration - the ONLY point this checks the limit at all is the real
// POST request fired by "Create Member", because that's the only point the
// backend itself checks it (see tenantAuth.controller.js's
// createTeamMember). A 409 with code "USER_LIMIT_REACHED" swaps this same
// modal into the "limit reached" view instead of a generic error banner;
// any other failure (weak password, duplicate email, etc.) stays a normal
// inline error on the form.
export default function AddMemberModal({ open, onClose, token, onCreated, onUpgradeRequested }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [limitInfo, setLimitInfo] = useState(null); // { plan, maxUsers, activeUserCount } once hit

  function handleClose() {
    setForm(EMPTY_FORM);
    setError("");
    setLimitInfo(null);
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { user } = await api.createTeamMember(token, form);
      setForm(EMPTY_FORM);
      onClose();
      onCreated(user);
    } catch (err) {
      if (err.data?.code === "USER_LIMIT_REACHED") {
        setLimitInfo({ plan: err.data.plan, maxUsers: err.data.maxUsers, activeUserCount: err.data.activeUserCount });
      } else {
        setError(err.message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={handleClose} ariaLabel={limitInfo ? "User limit reached" : "Add a team member"}>
      {limitInfo ? (
        <>
          <h2 id="dialog-title">User limit reached</h2>
          <p className="helptext" id="dialog-message">
            Your current plan allows up to {limitInfo.maxUsers} users. You currently have {limitInfo.activeUserCount} active users.
          </p>
          <p className="helptext">Upgrade your plan to add another team member.</p>
          <div className="dialog-actions">
            <button className="btn btn-outline" onClick={handleClose}>
              Cancel
            </button>
            <button
              className="btn btn-primary"
              onClick={() => {
                handleClose();
                onUpgradeRequested?.();
              }}
            >
              Upgrade Plan
            </button>
          </div>
        </>
      ) : (
        <>
          <h2 id="dialog-title" style={{ marginBottom: 4 }}>
            Add a team member
          </h2>
          <p className="helptext" style={{ marginBottom: 16 }}>
            They'll receive a temporary password and be asked to set their own on first login.
          </p>
          <ErrorBanner message={error} />
          <form onSubmit={handleSubmit}>
            <Field id="memberName" label="Name">
              <Input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            </Field>
            <Field id="memberEmail" label="Email">
              <Input type="email" required value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
            </Field>
            <Field id="memberPassword" label="Temporary password" style={{ marginBottom: 0 }}>
              <Input required minLength={8} value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
            </Field>
            <div className="dialog-actions">
              <button type="button" className="btn btn-outline" onClick={handleClose} disabled={busy}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={busy}>
                {busy ? "Creating…" : "Create Member"}
              </button>
            </div>
          </form>
        </>
      )}
    </Modal>
  );
}
