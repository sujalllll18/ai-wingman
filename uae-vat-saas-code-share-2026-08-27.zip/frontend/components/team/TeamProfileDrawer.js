import Drawer from "../ui/Drawer";
import Card from "../ui/Card";
import PlaceholderNotice from "../ui/PlaceholderNotice";

// Same readable-datetime convention already used by Invoice/Purchase/VAT
// Return Activity Timelines (toLocaleString with short month + 2-digit time).
function formatLastLogin(iso) {
  if (!iso) return "Never";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

const ROLE_LABEL = { OWNER: "Owner", STAFF: "Staff" };

// Future-expansion sections, per the Team polish brief - UI only, no data
// wired up (no backend support exists yet for any of these on a per-member
// basis). Every future module that adds real per-member history slots into
// one of these cards without touching the drawer's structure.
const FUTURE_SECTIONS = [
  { key: "activity", label: "Activity", copy: "A log of this member's actions across Ledger will appear here." },
  { key: "invoices", label: "Invoices", copy: "Invoices created or sent by this member will appear here." },
  { key: "purchases", label: "Purchase Bills", copy: "Purchase bills recorded by this member will appear here." },
  { key: "vatReturns", label: "VAT Returns", copy: "VAT Returns generated or locked by this member will appear here." },
  { key: "audit", label: "Audit History", copy: "A detailed audit trail for this member will appear here." },
];

export default function TeamProfileDrawer({ open, onClose, user }) {
  if (!user) return null;

  return (
    <Drawer open={open} onClose={onClose} ariaLabel={`${user.name}'s profile`}>
      <div className="drawer-header">
        <button className="drawer-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        <div className="profile-drawer-header">
          <span className="profile-drawer-avatar" aria-hidden="true">
            {(user.name || "?").charAt(0).toUpperCase()}
          </span>
          <div>
            <p className="profile-drawer-name">{user.name}</p>
            <span className={`badge ${user.role === "OWNER" ? "badge-premium" : "badge-info"}`}>{ROLE_LABEL[user.role] || user.role}</span>
          </div>
        </div>
      </div>

      <div className="drawer-body">
        <div className="profile-drawer-fields">
          <div className="profile-drawer-field">
            <span className="profile-drawer-field-label">Email</span>
            <span className="profile-drawer-field-value">{user.email}</span>
          </div>
          <div className="profile-drawer-field">
            <span className="profile-drawer-field-label">Role</span>
            <span className="profile-drawer-field-value">{ROLE_LABEL[user.role] || user.role}</span>
          </div>
          <div className="profile-drawer-field">
            <span className="profile-drawer-field-label">Last Login</span>
            <span className="profile-drawer-field-value">{formatLastLogin(user.lastLoginAt)}</span>
          </div>
        </div>

        {FUTURE_SECTIONS.map((section) => (
          <div className="profile-drawer-section" key={section.key}>
            <Card style={{ marginBottom: 0 }}>
              <h3 style={{ marginTop: 0 }}>{section.label}</h3>
              <PlaceholderNotice>{section.copy}</PlaceholderNotice>
            </Card>
          </div>
        ))}
      </div>
    </Drawer>
  );
}
