"use client";

import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { tenantAuth } from "../../lib/auth";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Input from "../ui/Input";
import Select from "../ui/Select";
import Button from "../ui/Button";
import ErrorBanner from "../ui/ErrorBanner";
import AllocationEditor from "../payments/AllocationEditor";

const PAYMENT_METHODS = [
  { value: "CASH", label: "Cash" },
  { value: "BANK_TRANSFER", label: "Bank Transfer" },
  { value: "CARD", label: "Card" },
  { value: "CHEQUE", label: "Cheque" },
  { value: "OTHER", label: "Other" },
];

function todayInputValue() {
  return new Date().toISOString().slice(0, 10);
}

// Record Payment (Supplier Payments module, Phase 2 2026-08-22) - vendor-side
// mirror of components/payments/NewPaymentModal.js. Kept a fully separate
// component (not a parameterized shared one) per the brief's explicit
// "keep Customer Payments and Supplier Payments logically separated"
// requirement - only the generic AllocationEditor is actually shared.
export default function NewSupplierPaymentModal({ open, onClose, onSuccess, initialVendorId, initialPurchaseBillId }) {
  const [vendors, setVendors] = useState([]);
  const [vendorId, setVendorId] = useState("");
  const [amount, setAmount] = useState("");
  const [paymentDate, setPaymentDate] = useState(todayInputValue());
  const [currency, setCurrency] = useState("AED");
  const [method, setMethod] = useState("BANK_TRANSFER");
  const [accountRef, setAccountRef] = useState("");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [allocatable, setAllocatable] = useState([]);
  const [amounts, setAmounts] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    const token = tenantAuth.get();
    api.listVendors(token).then(({ vendors }) => setVendors(vendors)).catch(() => {});
    setVendorId(initialVendorId || "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open || !vendorId) {
      setAllocatable([]);
      return;
    }
    const token = tenantAuth.get();
    api
      .listAllocatableBills(token, vendorId)
      .then(({ purchaseBills }) => {
        const mapped = purchaseBills.map((b) => ({ id: b.id, number: b.billNumberDisplay, date: b.purchaseDate, currency: b.currency, grandTotal: b.grandTotal, outstandingAmount: b.outstandingAmount }));
        setAllocatable(mapped);
        if (initialPurchaseBillId) {
          const match = mapped.find((b) => b.id === initialPurchaseBillId);
          if (match) {
            setAmounts((prev) => (prev[initialPurchaseBillId] !== undefined ? prev : { ...prev, [initialPurchaseBillId]: match.outstandingAmount }));
            setAmount((prev) => prev || String(match.outstandingAmount));
          }
        }
      })
      .catch(() => setAllocatable([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, vendorId]);

  function resetAndClose() {
    setVendorId("");
    setAmount("");
    setPaymentDate(todayInputValue());
    setCurrency("AED");
    setMethod("BANK_TRANSFER");
    setAccountRef("");
    setReference("");
    setNotes("");
    setAllocatable([]);
    setAmounts({});
    setError("");
    onClose();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;
    const selectedVendor = vendors.find((v) => v.id === vendorId);
    if (!selectedVendor) {
      setError("Select a supplier.");
      return;
    }
    if (!amount || Number.isNaN(Number(amount)) || Number(amount) <= 0) {
      setError("Enter a valid payment amount greater than zero.");
      return;
    }
    const allocations = Object.entries(amounts)
      .filter(([, v]) => Number(v) > 0)
      .map(([purchaseBillId, v]) => ({ purchaseBillId, amount: Number(v) }));

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const { payment } = await api.createSupplierPayment(token, {
        vendorId,
        vendorName: selectedVendor.name,
        paymentDate,
        amount: Number(amount),
        currency,
        method,
        accountRef: accountRef || null,
        reference: reference || null,
        notes: notes || null,
        allocations,
      });
      onSuccess(payment);
      resetAndClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} size="lg" ariaLabel="Record Supplier Payment">
      <form onSubmit={handleSubmit}>
        <h2 style={{ marginBottom: 4 }}>Record Payment</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>
          Record a payment made to a supplier, then allocate it against one or more Recorded purchase bills - or leave it unallocated and allocate later.
        </p>

        <ErrorBanner message={error} />

        <div className="form-grid">
          <Field id="spayment-vendor" label={<>Supplier<span className="required-asterisk">*</span></>}>
            <Select value={vendorId} onChange={(e) => setVendorId(e.target.value)}>
              <option value="">Select a supplier…</option>
              {vendors.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="spayment-date" label={<>Payment Date<span className="required-asterisk">*</span></>}>
            <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="spayment-amount" label={<>Amount<span className="required-asterisk">*</span></>}>
            <Input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field id="spayment-currency" label="Currency">
            <Input value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase())} maxLength={3} />
          </Field>
        </div>

        <div className="form-grid">
          <Field id="spayment-method" label="Payment Method">
            <Select value={method} onChange={(e) => setMethod(e.target.value)}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="spayment-account-ref" label="Bank / Cash Account" helptext="Free text - no configurable account master yet.">
            <Input value={accountRef} onChange={(e) => setAccountRef(e.target.value)} placeholder="e.g. ADCB Current A/C" />
          </Field>
        </div>

        <Field id="spayment-reference" label="Reference Number">
          <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Transaction / cheque number" />
        </Field>

        <Field id="spayment-notes" label="Notes">
          <textarea className="inline-input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>

        {vendorId && (
          <div style={{ marginTop: 8 }}>
            <h3 style={{ marginBottom: 8 }}>Allocate to Purchase Bills</h3>
            <AllocationEditor
              items={allocatable}
              amounts={amounts}
              onChange={setAmounts}
              paymentAmount={amount}
              itemLabel="purchase bill"
              emptyMessage="This supplier has no Recorded purchase bills to allocate against yet - the payment will be recorded as unallocated."
            />
          </div>
        )}

        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={resetAndClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving…" : "Confirm Payment"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
