"use client";

import { useState } from "react";
import Modal from "../ui/Modal";
import Field from "../ui/Field";
import Button from "../ui/Button";

// Approve/Reject with an optional comment - one modal for both decisions,
// since the shape is identical and only the verb/variant changes.
export default function DecisionModal({ open, decision, request, onClose, onConfirm }) {
  const [comments, setComments] = useState("");
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  const isApprove = decision === "APPROVE";

  async function handleConfirm() {
    setBusy(true);
    try {
      await onConfirm(comments);
    } finally {
      setBusy(false);
      setComments("");
    }
  }

  return (
    <Modal open={open} onClose={onClose} ariaLabel={`${isApprove ? "Approve" : "Reject"} request`}>
      <h2 style={{ marginTop: 0 }}>{isApprove ? "Approve" : "Reject"} Request</h2>
      <p className="helptext" style={{ marginTop: 0 }}>
        {request?.referenceNumber} - {request?.entityType} {request?.action}
      </p>
      <Field
        id="decision-comments"
        label="Comments"
        helptext={isApprove ? "Optional - shown in this request's Activity trail." : "Recommended - lets the maker know why this was rejected."}
      >
        <textarea
          className="inline-input"
          rows={3}
          value={comments}
          onChange={(e) => setComments(e.target.value)}
          placeholder={isApprove ? "e.g. Verified against the source document." : "e.g. TRN does not match the supporting document."}
        />
      </Field>
      <div className="dialog-actions">
        <Button variant="outline" onClick={onClose} disabled={busy}>
          Cancel
        </Button>
        <Button variant={isApprove ? "primary" : "danger"} onClick={handleConfirm} disabled={busy}>
          {busy ? "Working…" : isApprove ? "Approve" : "Reject"}
        </Button>
      </div>
    </Modal>
  );
}
