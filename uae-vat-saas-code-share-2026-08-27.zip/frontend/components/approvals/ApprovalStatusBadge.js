// Same map-based badge shape as InvoiceStatusBadge.js - one lookup object
// keyed by the backend's plain-string status, spread into the shared
// `badge` class + a modifier.
const STATUS_BADGE = {
  PENDING: { label: "Pending", className: "badge-premium" },
  APPROVED: { label: "Approved", className: "badge-success" },
  REJECTED: { label: "Rejected", className: "badge-danger" },
  CANCELLED: { label: "Cancelled", className: "badge-info" },
};

export default function ApprovalStatusBadge({ status }) {
  const badge = STATUS_BADGE[status] || STATUS_BADGE.PENDING;
  return <span className={`badge ${badge.className}`}>{badge.label}</span>;
}
