"use client";

import { useEffect, useState } from "react";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import WelcomeSection from "../../../components/tenant-dashboard/WelcomeSection";
import KpiCards from "../../../components/tenant-dashboard/KpiCards";
import QuickActions from "../../../components/tenant-dashboard/QuickActions";

// Deliberately NOT gated with useRequirePermission (RBAC module Phase 6,
// 2026-08-06) - every other page's guard redirects here on denial, so
// gating this page the same way risks an infinite redirect loop for any
// hypothetical custom role missing dashboard.view. Every seeded system role
// has it; the per-module KPI fetches below are still independently gated by
// their own module's view permission via Promise.allSettled.

// GettingStarted/RecentActivity intentionally not imported here anymore
// (2026-08-04 UI Polish Sprint - "remove from the Dashboard only, don't
// delete the components"). They're still real files, just unused by this page.

function KpiSkeleton() {
  return (
    <div className="dashboard-kpi-grid">
      {Array.from({ length: 4 }).map((_, i) => (
        <div className="kpi-card-skeleton" key={i}>
          <div className="skeleton-bar" style={{ width: "60%", height: 11 }} />
          <div className="skeleton-bar" style={{ width: "40%", height: 24 }} />
          <div className="skeleton-bar" style={{ width: "50%", height: 11 }} />
        </div>
      ))}
    </div>
  );
}

export default function TenantDashboardPage() {
  const [data, setData] = useState(null); // null while loading
  const [error, setError] = useState("");
  const session = typeof window !== "undefined" ? tenantAuth.getSession() : null;

  useEffect(() => {
    // RBAC module Phase 6 (2026-08-06): this page only needs dashboard.view
    // itself, but it aggregates data from three other modules
    // (invoices/purchases/vat_returns), each independently gated by its own
    // view permission now. A role can legitimately hold dashboard.view
    // without all three (e.g. Sales Executive has no purchases.view) - a
    // "Missing permission" rejection on any one of them is an expected,
    // per-role outcome, not a page error, so each fetch is settled
    // independently and simply contributes a 0/empty KPI rather than
    // failing the whole page. A genuinely unexpected failure (network,
    // 500) still surfaces via the error banner.
    async function load() {
      const token = tenantAuth.get();
      const [invoicesRes, purchasesRes, vatReturnsRes] = await Promise.allSettled([
        api.listInvoices(token),
        api.listPurchases(token),
        api.listVatReturns(token),
      ]);

      for (const res of [invoicesRes, purchasesRes, vatReturnsRes]) {
        // Plan + RBAC combined enforcement (2026-08-09) - a per-widget fetch
        // can now also be rejected because the tenant's Plan doesn't
        // include that module ("This feature isn't included in your
        // current plan: ..."), not just because the Role lacks the
        // permission ("Missing permission: ..."). Both are the exact same
        // "expected, per-role-or-plan outcome, degrade to 0" case this
        // check already existed for - a Plan rejection isn't a page error
        // any more than an RBAC one is.
        const isExpectedAccessRejection =
          res.reason?.message?.startsWith("Missing permission") || res.reason?.message?.includes("isn't included in your current plan");
        if (res.status === "rejected" && !isExpectedAccessRejection) {
          setError(res.reason.message);
        }
      }

      const invoices = invoicesRes.status === "fulfilled" ? invoicesRes.value.invoices : [];
      const purchases = purchasesRes.status === "fulfilled" ? purchasesRes.value.purchases : [];
      const vatReturns = vatReturnsRes.status === "fulfilled" ? vatReturnsRes.value.vatReturns : [];

      const paidRevenue = invoices
        .filter((i) => i.status === "SENT" && i.paymentStatus === "PAID")
        .reduce((sum, i) => sum + (i.grandTotal || 0), 0);

      const lockedReturns = vatReturns
        .filter((r) => r.status === "LOCKED")
        .sort((a, b) => new Date(b.lockedAt || b.generatedAt) - new Date(a.lockedAt || a.generatedAt));
      const currentReturn = lockedReturns[0] || null;

      setData({
        invoiceCount: invoices.length,
        purchaseCount: purchases.length,
        paidRevenue,
        hasLockedReturn: !!currentReturn,
        vatPayable: currentReturn?.netVatPayable ?? 0,
        vatPeriodLabel: currentReturn?.periodLabel ?? "",
      });
    }
    load();
  }, []);

  return (
    <div>
      <PageHeader eyebrow={session?.tenant?.name || "Your business"} title="Dashboard" />

      <ErrorBanner message={error} />

      <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
        <WelcomeSection userName={session?.user?.name} tenantName={session?.tenant?.name} />

        {data ? (
          <KpiCards
            invoiceCount={data.invoiceCount}
            purchaseCount={data.purchaseCount}
            paidRevenue={data.paidRevenue}
            vatPayable={data.vatPayable}
            vatPeriodLabel={data.vatPeriodLabel}
            hasLockedReturn={data.hasLockedReturn}
          />
        ) : (
          !error && <KpiSkeleton />
        )}

        <QuickActions />
      </div>
    </div>
  );
}
