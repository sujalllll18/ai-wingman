"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import { useRequirePermission } from "../../../../../hooks/useRequirePermission";
import PageHeader from "../../../../../components/ui/PageHeader";
import Card from "../../../../../components/ui/Card";
import Field from "../../../../../components/ui/Field";
import Input from "../../../../../components/ui/Input";
import Select from "../../../../../components/ui/Select";
import Button from "../../../../../components/ui/Button";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import FileUploader from "../../../../../components/support/FileUploader";

const MODULES = ["Dashboard", "Business Profile", "Team", "Customers", "Products & Services", "Tax Master", "Invoices", "Purchases", "VAT Returns", "Approvals", "Other"];
const PRIORITIES = [
  { value: "LOW", label: "Low" },
  { value: "MEDIUM", label: "Medium" },
  { value: "HIGH", label: "High" },
  { value: "CRITICAL", label: "Critical" },
];
const APP_VERSION = "1.0.0";

function detectDeviceInfo() {
  if (typeof navigator === "undefined") return "";
  const ua = navigator.userAgent;
  const platform = navigator.platform || "";
  const isMobile = /Mobile|Android|iP(hone|ad)/.test(ua);
  return `${platform || "Unknown platform"} · ${isMobile ? "Mobile" : "Desktop"}`;
}

function detectBrowserInfo() {
  if (typeof navigator === "undefined") return "";
  return navigator.userAgent;
}

// Raise Ticket (2026-08-07, Support Center) - the tenant user only fills
// in the fields that describe their problem; every technical field
// (currentUrl/browserInfo/deviceInfo/screenResolution/appVersion) is
// gathered here via navigator/window/screen at mount and submit time, per
// the "user should not have to provide technical details manually" spec.
export default function RaiseTicketPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("tickets.create");
  const { showToast } = useToast();

  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ subject: "", module: "Invoices", feature: "", categoryId: "", priority: "MEDIUM", description: "" });
  const [screenshotFiles, setScreenshotFiles] = useState([]);
  const [attachmentFiles, setAttachmentFiles] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const { categories } = await api.listTicketCategories(token);
        setCategories(categories);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  function update(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.subject.trim() || !form.description.trim()) {
      setError("Subject and Description are required.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const context = {
        currentUrl: typeof window !== "undefined" ? window.location.href : "",
        browserInfo: detectBrowserInfo(),
        deviceInfo: detectDeviceInfo(),
        screenResolution: typeof screen !== "undefined" ? `${screen.width}x${screen.height}` : "",
        appVersion: APP_VERSION,
      };
      const { ticket } = await api.createTicket(token, { ...form, categoryId: form.categoryId || undefined, ...context });

      for (const file of screenshotFiles) {
        await api.addTicketAttachment(token, ticket.id, file, { isScreenshot: true });
      }
      for (const file of attachmentFiles) {
        await api.addTicketAttachment(token, ticket.id, file, { isScreenshot: false });
      }

      showToast(`${ticket.ticketNumber} created.`);
      router.push(`/tenant/support/tickets/${ticket.id}`);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  if (permLoading || !allowed) return null;

  return (
    <div className="page-narrow">
      <PageHeader title="Raise a Support Ticket" description="Tell us what's wrong — we'll capture the technical details automatically." />
      <ErrorBanner message={error} />
      <form onSubmit={handleSubmit}>
        <Card>
          <Field id="subject" label={<>Subject<span className="required-asterisk">*</span></>}>
            <Input required value={form.subject} onChange={update("subject")} placeholder="Short summary of the issue" />
          </Field>
          <div className="form-grid">
            <Field id="module" label="Module">
              <Select value={form.module} onChange={update("module")}>
                {MODULES.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </Select>
            </Field>
            <Field id="feature" label="Feature" helptext="Optional — e.g. Bulk Export, Credit Note">
              <Input value={form.feature} onChange={update("feature")} />
            </Field>
          </div>
          <div className="form-grid">
            <Field id="category" label="Category">
              <Select value={form.categoryId} onChange={update("categoryId")}>
                <option value="">Select a category</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </Select>
            </Field>
            <Field id="priority" label="Priority">
              <Select value={form.priority} onChange={update("priority")}>
                {PRIORITIES.map((p) => (
                  <option key={p.value} value={p.value}>{p.label}</option>
                ))}
              </Select>
            </Field>
          </div>
          <Field id="description" label={<>Description<span className="required-asterisk">*</span></>} style={{ marginBottom: 0 }}>
            <textarea required rows={6} value={form.description} onChange={update("description")} placeholder="What happened? What did you expect instead?" />
          </Field>
        </Card>

        <Card>
          <h2 style={{ marginBottom: 4 }}>Screenshot</h2>
          <p className="form-section-desc">A picture of the issue helps us fix it faster.</p>
          <FileUploader onFilesSelected={setScreenshotFiles} multiple={false} accept="image/*" label="Drop a screenshot here, or click to browse" />
        </Card>

        <Card>
          <h2 style={{ marginBottom: 4 }}>Attachments</h2>
          <p className="form-section-desc">Any other documents that help explain the issue.</p>
          <FileUploader onFilesSelected={setAttachmentFiles} multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt" />
        </Card>

        <div className="wizard-actions">
          <Button type="button" variant="outline" onClick={() => router.push("/tenant/support/tickets")} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Submitting…" : "Submit Ticket"}
          </Button>
        </div>
      </form>
    </div>
  );
}
