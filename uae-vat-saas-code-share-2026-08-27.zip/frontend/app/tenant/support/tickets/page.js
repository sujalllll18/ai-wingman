"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { useLocalStorageState } from "../../../../hooks/useLocalStorageState";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import DataTable from "../../../../components/ui/DataTable";
import TableScroll from "../../../../components/ui/TableScroll";
import ColumnSelector from "../../../../components/ui/ColumnSelector";
import Toolbar from "../../../../components/ui/Toolbar";
import Button from "../../../../components/ui/Button";
import ActionMenu from "../../../../components/ui/ActionMenu";
import Pagination from "../../../../components/ui/Pagination";
import PriorityBadge from "../../../../components/support/PriorityBadge";
import TicketStatusBadge from "../../../../components/support/TicketStatusBadge";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

const MODULES = ["Dashboard", "Business Profile", "Team", "Customers", "Products & Services", "Tax Master", "Invoices", "Purchases", "VAT Returns", "Approvals", "Other"];

export default function MyTicketsPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("tickets.view");
  const { showToast } = useToast();

  const [tickets, setTickets] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [priorityFilter, setPriorityFilter] = useState("ALL");
  const [moduleFilter, setModuleFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { tickets } = await api.listTickets(token);
      setTickets(tickets);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  async function handleClose(ticket) {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.closeTicket(token, ticket.id);
      showToast(`${ticket.ticketNumber} closed.`);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleReopen(ticket) {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.reopenTicket(token, ticket.id);
      showToast(`${ticket.ticketNumber} reopened.`);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  const COLUMN_DEFS = useMemo(
    () => [
      { key: "ticketNumber", label: "Ticket Number", alwaysVisible: true, sortable: true, render: (t) => <span className="mono" style={{ fontWeight: 600 }}>{t.ticketNumber}</span> },
      { key: "subject", label: "Subject", alwaysVisible: true, render: (t) => t.subject },
      { key: "module", label: "Module", render: (t) => t.module || "—" },
      { key: "priority", label: "Priority", render: (t) => <PriorityBadge priority={t.priority} /> },
      { key: "status", label: "Status", render: (t) => <TicketStatusBadge status={t.status} /> },
      { key: "assignedTo", label: "Assigned To", render: (t) => (t.assignedToAdminId ? "Support Team" : <span style={{ color: "var(--color-ink-faint)" }}>Unassigned</span>) },
      { key: "createdAt", label: "Created On", sortable: true, render: (t) => formatDate(t.createdAt) },
      { key: "updatedAt", label: "Last Updated", render: (t) => formatDate(t.updatedAt) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (t) => (
          <ActionMenu
            ariaLabel={`Actions for ${t.ticketNumber}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/support/tickets/${t.id}`) },
              { label: "Reply", onClick: () => router.push(`/tenant/support/tickets/${t.id}?tab=conversation`) },
              {
                label: "Close",
                onClick: () => handleClose(t),
                disabled: busy || t.status !== "RESOLVED",
                disabledReason: "Only a Resolved ticket can be closed.",
              },
              {
                label: "Reopen",
                onClick: () => handleReopen(t),
                disabled: busy || !["RESOLVED", "CLOSED"].includes(t.status),
                disabledReason: "Only a Resolved or Closed ticket can be reopened.",
              },
            ]}
          />
        ),
      },
    ],
    [router, busy]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_ticket_list_column_order", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_ticket_list_hidden_columns", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const filtered = useMemo(() => {
    if (!tickets) return [];
    const q = search.trim().toLowerCase();
    return tickets.filter((t) => {
      const matchesSearch = !q || t.subject.toLowerCase().includes(q) || t.ticketNumber.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || t.status === statusFilter;
      const matchesPriority = priorityFilter === "ALL" || t.priority === priorityFilter;
      const matchesModule = moduleFilter === "ALL" || t.module === moduleFilter;
      const createdTime = new Date(t.createdAt).getTime();
      const matchesFrom = !dateFrom || createdTime >= new Date(dateFrom).getTime();
      const matchesTo = !dateTo || createdTime <= new Date(dateTo).getTime() + 86399999;
      return matchesSearch && matchesStatus && matchesPriority && matchesModule && matchesFrom && matchesTo;
    });
  }, [tickets, search, statusFilter, priorityFilter, moduleFilter, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        title="My Tickets"
        description="Every support ticket you've raised, in one place."
        action={
          <Link href="/tenant/support/tickets/new">
            <Button>+ Raise Ticket</Button>
          </Link>
        }
      />

      <ErrorBanner message={error} />

      <div className="card" style={{ padding: 0 }}>
        {tickets === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={7} />
          </div>
        ) : tickets.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <circle cx="12" cy="12" r="9" />
                <path d="M12 16v.01M12 8a2.5 2.5 0 0 1 2.5 2.5c0 1.5-1.5 2-2 2.5-.3.3-.5.7-.5 1" />
              </svg>
            }
            title="No tickets yet"
            description="Raise a ticket if you run into a problem — our support team will pick it up."
            action={
              <Link href="/tenant/support/tickets/new">
                <Button>+ Raise Ticket</Button>
              </Link>
            }
          />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search by ticket # or subject…"
                filters={
                  <>
                    <select
                      className="select-filter"
                      value={statusFilter}
                      onChange={(e) => {
                        setStatusFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All statuses</option>
                      <option value="NEW">New</option>
                      <option value="ASSIGNED">Assigned</option>
                      <option value="IN_PROGRESS">In Progress</option>
                      <option value="WAITING_CUSTOMER">Waiting for Customer</option>
                      <option value="RESOLVED">Resolved</option>
                      <option value="CLOSED">Closed</option>
                      <option value="REOPENED">Reopened</option>
                    </select>
                    <select
                      className="select-filter"
                      value={priorityFilter}
                      onChange={(e) => {
                        setPriorityFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All priorities</option>
                      <option value="LOW">Low</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="HIGH">High</option>
                      <option value="CRITICAL">Critical</option>
                    </select>
                    <select
                      className="select-filter"
                      value={moduleFilter}
                      onChange={(e) => {
                        setModuleFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All modules</option>
                      {MODULES.map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                    <input
                      type="date"
                      className="select-filter"
                      value={dateFrom}
                      onChange={(e) => {
                        setDateFrom(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Created from"
                    />
                    <input
                      type="date"
                      className="select-filter"
                      value={dateTo}
                      onChange={(e) => {
                        setDateTo(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Created to"
                    />
                    <ColumnSelector columns={COLUMN_DEFS} columnOrder={columnOrder} hiddenColumns={hiddenColumns} onToggle={handleToggleColumn} onReorder={setColumnOrder} />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching tickets"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable columns={COLUMN_DEFS} rows={pageItems} columnOrder={columnOrder} hiddenColumns={hiddenColumns} stickyHeader zebra />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="tickets"
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
