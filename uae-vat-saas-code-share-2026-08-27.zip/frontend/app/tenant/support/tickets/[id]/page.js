"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import Tabs from "../../../../../components/ui/Tabs";
import ConfirmationDialog from "../../../../../components/ui/ConfirmationDialog";
import PriorityBadge from "../../../../../components/support/PriorityBadge";
import TicketStatusBadge from "../../../../../components/support/TicketStatusBadge";
import ConversationThread from "../../../../../components/support/ConversationThread";
import TicketActivityTimeline from "../../../../../components/support/TicketActivityTimeline";
import FileUploader from "../../../../../components/support/FileUploader";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "conversation", label: "Conversation" },
  { key: "attachments", label: "Attachments" },
  { key: "timeline", label: "Timeline" },
];
const TAB_KEYS = new Set(TABS.map((t) => t.key));

function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString();
}

export default function TenantTicketDetailPage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { showToast } = useToast();
  const requestedTab = searchParams.get("tab");

  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [activeTab, setActiveTab] = useState(TAB_KEYS.has(requestedTab) ? requestedTab : "overview");
  const [reopenConfirmOpen, setReopenConfirmOpen] = useState(false);
  const [newFiles, setNewFiles] = useState([]);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const result = await api.getTicket(token, id);
      setData(result);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleReply(body) {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.replyToTicket(token, id, body);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirmReopen() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.reopenTicket(token, id);
      showToast("Ticket reopened.");
      setReopenConfirmOpen(false);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleClose() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.closeTicket(token, id);
      showToast("Ticket closed.");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleUploadFiles() {
    if (newFiles.length === 0) return;
    setBusy(true);
    try {
      const token = tenantAuth.get();
      for (const file of newFiles) {
        await api.addTicketAttachment(token, id, file, { isScreenshot: file.type?.startsWith("image/") });
      }
      showToast("Uploaded.");
      setNewFiles([]);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  function handleTabChange(key) {
    setActiveTab(key);
    router.replace(`/tenant/support/tickets/${id}?tab=${key}`);
  }

  if (error && !data) {
    return (
      <div>
        <PageHeader title="Ticket" />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!data) return <p>Loading…</p>;

  const { ticket, comments, attachments, activities } = data;
  const canReopen = ["RESOLVED", "CLOSED"].includes(ticket.status);
  const canClose = ticket.status === "RESOLVED";

  return (
    <div>
      <PageHeader
        title={ticket.subject}
        description={`${ticket.ticketNumber} · Raised ${formatDateTime(ticket.createdAt)}`}
        action={
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <PriorityBadge priority={ticket.priority} />
            <TicketStatusBadge status={ticket.status} />
            {canClose && (
              <Button variant="outline" onClick={handleClose} disabled={busy}>
                Close Ticket
              </Button>
            )}
            {canReopen && (
              <Button variant="outline" onClick={() => setReopenConfirmOpen(true)} disabled={busy}>
                Reopen
              </Button>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={handleTabChange} />

      <div role="tabpanel">
        {activeTab === "overview" && (
          <Card>
            <h2 style={{ marginBottom: 4 }}>Overview</h2>
            <div className="review-list" style={{ marginTop: 12 }}>
              <div className="review-row">
                <span className="review-label">Module</span>
                <span className="review-value">{ticket.module || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Feature</span>
                <span className="review-value">{ticket.feature || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Category</span>
                <span className="review-value">{ticket.category?.name || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Description</span>
                <span className="review-value" style={{ whiteSpace: "pre-wrap" }}>{ticket.description}</span>
              </div>
            </div>

            <h2 style={{ margin: "20px 0 4px" }}>Automatically Captured</h2>
            <p className="form-section-desc">Gathered automatically when you submitted this ticket — you didn&rsquo;t need to type any of this.</p>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Page URL</span>
                <span className="review-value mono" style={{ fontSize: 12, wordBreak: "break-all" }}>{ticket.currentUrl || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Browser</span>
                <span className="review-value" style={{ fontSize: 12 }}>{ticket.browserInfo || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Device</span>
                <span className="review-value">{ticket.deviceInfo || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Screen Resolution</span>
                <span className="review-value">{ticket.screenResolution || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">App Version</span>
                <span className="review-value">{ticket.appVersion || "—"}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Captured</span>
                <span className="review-value">{formatDateTime(ticket.capturedAt)}</span>
              </div>
            </div>
          </Card>
        )}

        {activeTab === "conversation" && (
          <Card>
            <h2 style={{ marginBottom: 12 }}>Conversation</h2>
            <ConversationThread
              comments={comments}
              currentUserType="TENANT_USER"
              onSubmitReply={handleReply}
              allowInternalNote={false}
              busy={busy}
              emptyLabel="No replies yet — the support team will respond here."
            />
          </Card>
        )}

        {activeTab === "attachments" && (
          <Card>
            <h2 style={{ marginBottom: 4 }}>Attachments</h2>
            <p className="form-section-desc">Screenshots and documents attached to this ticket.</p>
            {attachments.length === 0 ? (
              <p className="helptext">No attachments yet.</p>
            ) : (
              <ul style={{ listStyle: "none", margin: "12px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
                {attachments.map((a) => (
                  <li key={a.id}>
                    <a
                      href={`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000"}${a.fileUrl}`}
                      target="_blank"
                      rel="noreferrer"
                      style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "var(--color-surface-sunken)", borderRadius: "var(--radius)", textDecoration: "none", color: "inherit" }}
                    >
                      <span>{a.isScreenshot ? "🖼️" : "📎"}</span>
                      <span style={{ flex: 1 }}>{a.fileName}</span>
                      <span className="helptext" style={{ margin: 0 }}>{formatDateTime(a.createdAt)}</span>
                    </a>
                  </li>
                ))}
              </ul>
            )}

            <h2 style={{ margin: "20px 0 4px" }}>Add More</h2>
            <FileUploader onFilesSelected={setNewFiles} multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt" />
            <Button onClick={handleUploadFiles} disabled={busy || newFiles.length === 0} style={{ marginTop: 12 }}>
              {busy ? "Uploading…" : "Upload"}
            </Button>
          </Card>
        )}

        {activeTab === "timeline" && (
          <Card>
            <h2 style={{ marginBottom: 12 }}>Timeline</h2>
            <TicketActivityTimeline activities={activities} />
          </Card>
        )}
      </div>

      <ConfirmationDialog
        open={reopenConfirmOpen}
        title="Reopen this ticket?"
        message={`"${ticket.ticketNumber}" will go back to the support team's queue.`}
        confirmLabel="Reopen"
        busy={busy}
        onConfirm={handleConfirmReopen}
        onCancel={() => setReopenConfirmOpen(false)}
      />
    </div>
  );
}
