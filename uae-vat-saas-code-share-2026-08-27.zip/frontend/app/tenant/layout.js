"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { tenantAuth } from "../../lib/auth";
import AppShell from "../../components/ui/AppShell";
import { PermissionsProvider } from "../../components/rbac/PermissionsProvider";
import { BrandingProvider } from "../../components/tenant-profile/BrandingProvider";
import RolePreviewBanner from "../../components/rbac/RolePreviewBanner";
import { usePermissions } from "../../hooks/usePermissions";
import { useBranding } from "../../hooks/useBranding";

const NAV_ITEMS = [
  {
    href: "/tenant/dashboard",
    label: "Dashboard",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
      </svg>
    ),
  },
  {
    href: "/tenant/team",
    label: "Team",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="8" r="3" />
        <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
        <circle cx="17" cy="9" r="2.4" />
        <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
      </svg>
    ),
  },
  {
    href: "/tenant/business-profile",
    label: "Business Profile",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M6 3.5h9l4.5 4.5V20a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1z" />
        <path d="M14.5 3.5V8h4.5" />
      </svg>
    ),
  },
  {
    href: "/tenant/customers",
    label: "Customers",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="8" r="3" />
        <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
        <circle cx="17" cy="9" r="2.4" />
        <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
      </svg>
    ),
  },
  {
    href: "/tenant/materials",
    label: "Products & Services",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M4 7.5 12 3.5l8 4v9l-8 4-8-4v-9z" />
        <path d="M4 7.5 12 11.5l8-4M12 11.5V20.5" />
      </svg>
    ),
  },
  {
    href: "/tenant/tax-master",
    label: "Tax Master",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M4 6h16M4 12h10M4 18h13" />
        <circle cx="19" cy="12" r="1.6" />
        <circle cx="20" cy="18" r="1.6" />
      </svg>
    ),
  },
  {
    href: "/tenant/invoices",
    label: "Invoices",
    // Plan + RBAC combined enforcement (2026-08-09) - was never gated at
    // all before (an existing gap this rollout closes for the 6 modules the
    // brief explicitly named), so a plan that disables Invoices left the
    // link visible with nothing behind it. can() now checks both, same
    // gating pattern Credit Notes/Debit Notes/Imports/Approvals below
    // already established.
    permission: "invoices.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
        <path d="M8 8h8M8 12h8M8 16h5" />
      </svg>
    ),
  },
  {
    href: "/tenant/purchases",
    label: "Purchases",
    permission: "purchases.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="20" r="1.4" />
        <circle cx="17" cy="20" r="1.4" />
        <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
      </svg>
    ),
  },
  {
    href: "/tenant/credit-notes",
    label: "Credit Notes",
    // Credit/Debit Notes (2026-08-08) - top-level like Invoices/Purchases
    // rather than nested under them, since they're their own numbered
    // document series with their own lifecycle/RBAC/approvals, matching how
    // Invoices/Purchases/VAT Returns are each their own nav item.
    permission: "credit_notes.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
        <path d="M8 12h8M12 8v8" transform="rotate(45 12 12)" />
      </svg>
    ),
  },
  {
    href: "/tenant/sales-debit-notes",
    label: "Debit Notes",
    // Sales Debit Note (2026-08-11) - increases an issued Invoice, the
    // sales-side mirror of Credit Note right above it. Deliberately a
    // distinct module/route/permission namespace from the purchase-side
    // "Supplier Debit Notes" entry below (opposite VAT direction, different
    // counterparty) - see prisma/schema.prisma's SalesDebitNote comment.
    permission: "sales_debit_notes.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
        <path d="M8 12h8M12 8v8" />
      </svg>
    ),
  },
  {
    href: "/tenant/debit-notes",
    // Relabeled from "Debit Notes" (2026-08-11) only to disambiguate from
    // the new sales-side "Debit Notes" entry above - route, permission key,
    // backend, and everything else about this module is untouched.
    label: "Supplier Debit Notes",
    permission: "debit_notes.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
        <path d="M8 12h8" />
      </svg>
    ),
  },
  {
    href: "/tenant/payments",
    label: "Payments Received",
    // Customer Payments (Phase 2, 2026-08-22) - real allocation-aware module,
    // distinct from the simple single-invoice "Record Payment" quick action
    // still on the Invoice detail page (which now also feeds this module's
    // data, see PaymentAllocation).
    permission: "payments.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9" />
        <path d="M8 12.5l2.5 2.5L16 9.5" />
      </svg>
    ),
  },
  {
    href: "/tenant/purchase-payments",
    label: "Payments Made",
    // Supplier Payments (Phase 2, 2026-08-22) - vendor-side mirror, kept a
    // distinct module/route/permission namespace, same split as
    // Invoices/Credit Notes vs Purchases/Supplier Debit Notes above.
    permission: "purchase_payments.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="20" r="1.4" />
        <circle cx="17" cy="20" r="1.4" />
        <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
        <path d="M9 9.5l1.6 1.6L14 7.5" />
      </svg>
    ),
  },
  {
    label: "Banking",
    // Bank Statement Import (Phase 3, 2026-08-22) - grouped nav item, same
    // pattern as Support/Settings below. Import Statement is gated by
    // banking.import (mirrors invoices.import/purchases.import/
    // customers.import - a UI-affordance gate; the framework's own
    // imports.* endpoints are unchanged, see permissionCatalog.js).
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="3.5" y="6" width="17" height="13" rx="1.5" />
        <path d="M3.5 10h17M7 14h4" />
      </svg>
    ),
    children: [
      { href: "/tenant/banking/accounts", label: "Bank Accounts", permission: "banking.view" },
      { href: "/tenant/banking/transactions", label: "Transactions", permission: "banking.view_transactions" },
      { href: "/tenant/banking/import", label: "Import Statement", permission: "banking.import" },
      // Reconciliation Engine (Phase 4, 2026-08-23) - matches these
      // Transactions against Payments Received/Made.
      { href: "/tenant/banking/reconciliation", label: "Reconciliation", permission: "reconciliation.view" },
    ],
  },
  // "Imports" top-level nav item deliberately removed (2026-08-09, second
  // pass) - even with its own "+ New Import" button gone (see
  // /tenant/imports/page.js), the sidebar entry itself still read as a
  // second place imports live, next to Invoices/Purchases' own Import
  // buttons. The route/page/API/ImportBatch data are all still fully
  // intact and reachable directly at /tenant/imports - only the sidebar
  // link is gone.
  //
  // "Migration Center" (2026-08-22) is a genuinely different, first-class
  // entry point, not a re-add of the above - it starts a multi-file
  // Migration (Preview -> Commit -> Final Summary across several entity
  // types at once), a distinct workflow from a single Invoice/Purchase's
  // own "Import" button, so it gets its own real nav item and Start button.
  {
    href: "/tenant/migrations",
    label: "Migration Center",
    permission: "imports.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 3.5v11M7.5 10l4.5 4.5L16.5 10" />
        <path d="M4.5 16.5V19a1.5 1.5 0 0 0 1.5 1.5h12A1.5 1.5 0 0 0 19.5 19v-2.5" />
      </svg>
    ),
  },
  {
    href: "/tenant/vat-returns",
    label: "VAT Returns",
    permission: "vat_returns.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="7" cy="7" r="2.5" />
        <circle cx="17" cy="17" r="2.5" />
        <path d="M18 6 6 18" />
      </svg>
    ),
  },
  {
    href: "/tenant/approvals",
    label: "Approvals",
    // Maker-Checker module (2026-08-06) - the cross-module worklist a
    // Checker visits daily, so it's a top-level item like Invoices/Purchases
    // rather than buried in Settings. Gated the same way Roles & Permissions
    // already is - invisible to a role without approvals.view.
    permission: "approvals.view",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M9 11.5l2 2 4-4.5" />
        <rect x="3.5" y="3.5" width="17" height="17" rx="2.5" />
      </svg>
    ),
  },
  {
    label: "Support",
    // Support Center (2026-08-07) - grouped nav item, same pattern as
    // Settings below (icon + children, filtered by permission).
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 16v.01M12 8a2.5 2.5 0 0 1 2.5 2.5c0 1.5-1.5 2-2 2.5-.3.3-.5.7-.5 1" />
      </svg>
    ),
    children: [
      { href: "/tenant/support/tickets", label: "My Tickets", permission: "tickets.view" },
      { href: "/tenant/support/tickets/new", label: "Raise Ticket", permission: "tickets.create" },
    ],
  },
  {
    label: "Settings",
    // A real Settings shell (2026-08-06), replacing the old disabled
    // FUTURE_ITEMS placeholder - Roles & Permissions moves here as its first
    // real sub-item and Approval Workflow (rules config) is the second.
    // TenantShell filters group children the same way it filters flat items
    // below, so a role with neither roles.view nor approvals.configure sees
    // no Settings entry at all (see the visibleNavItems filter below).
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 13a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V19a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H4a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H10a1.6 1.6 0 0 0 1-1.5V4a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V10a1.6 1.6 0 0 0 1.5 1H20a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z" />
      </svg>
    ),
    children: [
      { href: "/tenant/settings/roles", label: "Roles & Permissions", permission: "roles.view" },
      { href: "/tenant/settings/approval-rules", label: "Approval Workflow", permission: "approvals.configure" },
    ],
  },
];

const FUTURE_ITEMS = [];

export default function TenantLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState(null);
  const isLoginPage = pathname === "/tenant/login";
  const isChangePasswordPage = pathname === "/tenant/change-password";

  useEffect(() => {
    if (isLoginPage) {
      setReady(true);
      return;
    }
    const token = tenantAuth.get();
    if (!token) {
      router.replace("/login?role=tenant");
      return;
    }
    // change-password itself is exempt from the shell/redirect logic below
    // (see the early return right after this effect) - it's a standalone
    // auth-adjacent screen, same as login, not a normal app page with
    // sidebar chrome the user could navigate away from mid-forced-change.
    if (isChangePasswordPage) {
      setReady(true);
      return;
    }
    const currentSession = tenantAuth.getSession();
    // Forced password change (2026-08-09) - catches direct navigation/deep
    // links, not just the post-login redirect in LoginScreen.js. The
    // backend enforces the same rule on every other endpoint regardless
    // (see requireTenantUser), so this is a UX redirect, not the real gate.
    if (currentSession?.user?.mustChangePassword) {
      router.replace("/tenant/change-password");
      return;
    }
    setSession(currentSession);
    setReady(true);
  }, [isLoginPage, isChangePasswordPage, router]);

  if (isLoginPage || isChangePasswordPage) return children;
  if (!ready) return null;

  function handleLogout() {
    tenantAuth.clear();
    router.push("/tenant/login");
  }

  return (
    <PermissionsProvider>
      <BrandingProvider>
        <TenantShell session={session} onLogout={handleLogout}>
          {children}
        </TenantShell>
      </BrandingProvider>
    </PermissionsProvider>
  );
}

// Split out so it can call usePermissions() - which requires being inside
// the PermissionsProvider it's wrapped by above. Resolves the sidebar's
// role label from the real, data-driven Role name (RBAC module, 2026-08-06)
// instead of the old hardcoded `role === "OWNER" ? "Owner" : "Staff"` -
// falls back to that same legacy computation only for the brief window
// before the permission fetch resolves, so there's no label flash/blank.
function TenantShell({ session, onLogout, children }) {
  const { role, loading, can } = usePermissions();
  const { name: brandingName, logoUrl } = useBranding();
  const roleLabel = !loading && role ? role.name : session?.user?.role === "OWNER" ? "Owner" : "Staff";

  // NAV_ITEMS entries may declare an optional `permission` key (RBAC module,
  // 2026-08-06) - filtered here, before Sidebar/AppShell ever see them, so
  // those shared components (also used by the Admin side, which has no
  // PermissionsProvider) never need to know RBAC exists. Items without a
  // `permission` key always pass through. A `children` group (Settings) is
  // filtered one level deeper and dropped entirely once empty, so a role
  // with neither roles.view nor approvals.configure never sees a Settings
  // entry that leads nowhere.
  const visibleNavItems = NAV_ITEMS.filter((item) => !item.permission || can(item.permission))
    .map((item) => (item.children ? { ...item, children: item.children.filter((c) => !c.permission || can(c.permission)) } : item))
    .filter((item) => !item.children || item.children.length > 0);

  return (
    <AppShell
      brand={session?.tenant?.name || "Tenant Portal"}
      businessName={brandingName || session?.tenant?.name || "Tenant Portal"}
      logoUrl={logoUrl}
      navItems={visibleNavItems}
      futureItems={FUTURE_ITEMS}
      onLogout={onLogout}
      userProfile={session?.user ? { name: session.user.name, email: session.user.email, roleLabel } : undefined}
    >
      <RolePreviewBanner />
      {children}
    </AppShell>
  );
}
