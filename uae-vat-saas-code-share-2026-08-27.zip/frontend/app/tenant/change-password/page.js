"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { isValidPassword, PASSWORD_REQUIREMENT_MESSAGE } from "../../../lib/validation";
import Field from "../../../components/ui/Field";
import Button from "../../../components/ui/Button";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import PasswordInput from "../../../components/PasswordInput";

// Reached two ways: redirected here straight after a temporary-password
// login (LoginScreen.js), or by tenant/layout.js on any other direct
// navigation while mustChangePassword is still true. Every other tenant
// endpoint 403s until this succeeds (requireTenantUser), so this page has
// to work standalone - no permissions fetch, no dashboard chrome dependency.
export default function ChangePasswordPage() {
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  // Read after mount, not during render (2026-08-09 fix) - a
  // `typeof window !== "undefined"` ternary evaluated at render time
  // returns null on the server and real data on the client, which is a
  // guaranteed hydration mismatch on a direct/hard navigation to this
  // route (as opposed to a client-side redirect into it, which never runs
  // a fresh SSR pass). Starting at null on both sides and filling it in via
  // an effect keeps the first render identical everywhere.
  const [session, setSession] = useState(null);
  useEffect(() => {
    setSession(tenantAuth.getSession());
  }, []);

  const currentPasswordError = !currentPassword ? "Enter your temporary password." : "";
  const newPasswordError = !newPassword
    ? "Enter a new password."
    : !isValidPassword(newPassword)
    ? PASSWORD_REQUIREMENT_MESSAGE
    : newPassword === currentPassword
    ? "New password must be different from your temporary password."
    : "";
  const confirmError = confirmPassword !== newPassword ? "Passwords do not match." : "";

  function markTouched(key) {
    setTouched((t) => ({ ...t, [key]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ currentPassword: true, newPassword: true, confirmPassword: true });
    if (currentPasswordError || newPasswordError || confirmError) return;

    setError("");
    setLoading(true);
    try {
      const token = tenantAuth.get();
      const { token: freshToken, user } = await api.changePassword(token, { currentPassword, newPassword });
      // Same tenant, fresh token+user (mustChangePassword now false) - the
      // old token would otherwise keep claiming mustChangePassword true for
      // the rest of its 8h lifetime, since JWT claims are fixed at signing.
      tenantAuth.save(freshToken, user, session?.tenant, true);
      router.push("/tenant/dashboard");
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <main className="auth-split" style={{ gridTemplateColumns: "1fr" }}>
      <div className="auth-split-left" style={{ margin: "0 auto" }}>
        <form className="auth-form" onSubmit={handleSubmit} noValidate>
          <div className="auth-brand-mark">L</div>
          <span className="eyebrow">{session?.tenant?.name || "Your business"}</span>
          <h1 className="auth-heading">Set a New Password</h1>
          <p className="auth-sub">
            You&rsquo;re signing in with a temporary password. Set a new one to continue — you won&rsquo;t be able to use Ledger until you do.
          </p>

          <ErrorBanner message={error} />

          <Field id="currentPassword" label="Temporary Password" error={touched.currentPassword ? currentPasswordError : undefined}>
            <PasswordInput
              id="currentPassword"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              onBlur={() => markTouched("currentPassword")}
              error={touched.currentPassword ? currentPasswordError : undefined}
            />
          </Field>

          <Field id="newPassword" label="New Password" error={touched.newPassword ? newPasswordError : undefined}>
            <PasswordInput
              id="newPassword"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              onBlur={() => markTouched("newPassword")}
              error={touched.newPassword ? newPasswordError : undefined}
            />
          </Field>

          <Field id="confirmPassword" label="Confirm New Password" error={touched.confirmPassword ? confirmError : undefined}>
            <PasswordInput
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              onBlur={() => markTouched("confirmPassword")}
              error={touched.confirmPassword ? confirmError : undefined}
            />
          </Field>

          <Button type="submit" disabled={loading} style={{ width: "100%", justifyContent: "center" }}>
            {loading ? "Setting password…" : "Set New Password"}
          </Button>
        </form>
      </div>
    </main>
  );
}
