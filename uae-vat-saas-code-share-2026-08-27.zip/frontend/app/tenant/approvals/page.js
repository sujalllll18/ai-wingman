"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ApprovalStatusBadge from "../../../components/approvals/ApprovalStatusBadge";
import DecisionModal from "../../../components/approvals/DecisionModal";

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function ApprovalQueuePage() {
  const { allowed, loading: permLoading } = useRequirePermission("approvals.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [requests, setRequests] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [moduleFilter, setModuleFilter] = useState("ALL");
  const [decisionModal, setDecisionModal] = useState(null); // { decision, request } | null

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { approvalRequests } = await api.listApprovalQueue(token);
      setRequests(approvalRequests);
    } catch (err) {
      setError(err.message);
    }
  }

  const modules = useMemo(() => {
    if (!requests) return [];
    return Array.from(new Set(requests.map((r) => r.module))).sort();
  }, [requests]);

  const filtered = useMemo(() => {
    if (!requests) return [];
    const q = search.trim().toLowerCase();
    return requests.filter((r) => {
      const matchesSearch = !q || r.referenceNumber.toLowerCase().includes(q) || r.entityType.toLowerCase().includes(q);
      const matchesModule = moduleFilter === "ALL" || r.module === moduleFilter;
      return matchesSearch && matchesModule;
    });
  }, [requests, search, moduleFilter]);

  async function handleDecision(comments) {
    const { decision, request } = decisionModal;
    try {
      const token = tenantAuth.get();
      if (decision === "APPROVE") await api.approveApprovalRequest(token, request.id, comments);
      else await api.rejectApprovalRequest(token, request.id, comments);
      showToast(`${request.referenceNumber} ${decision === "APPROVE" ? "approved" : "rejected"}.`);
      setDecisionModal(null);
      await load();
    } catch (err) {
      showToast(err.message);
    }
  }

  const COLUMNS = [
    { key: "referenceNumber", header: "Reference", render: (r) => <Link href={`/tenant/approvals/${r.id}`}>{r.referenceNumber}</Link> },
    { key: "module", header: "Module", render: (r) => r.module.replace(/_/g, " ") },
    { key: "action", header: "Action", render: (r) => r.action.replace(/_/g, " ") },
    { key: "entityType", header: "Entity", render: (r) => r.entityType },
    { key: "requestedBy", header: "Requested By", render: (r) => r.requestedByName || r.requestedBy },
    { key: "requestedAt", header: "Requested On", render: (r) => formatDateTime(r.requestedAt) },
    { key: "priority", header: "Priority", render: (r) => <span className={`badge ${r.priority === "HIGH" ? "badge-danger" : "badge-info"}`}>{r.priority}</span> },
    { key: "status", header: "Status", render: (r) => <ApprovalStatusBadge status={r.status} /> },
    {
      key: "actions",
      header: "",
      className: "num",
      render: (r) =>
        can(`${r.module}.approve`) || can(`${r.module}.reject`) ? (
          <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
            {can(`${r.module}.approve`) && (
              <Button variant="outline" onClick={() => setDecisionModal({ decision: "APPROVE", request: r })}>
                Approve
              </Button>
            )}
            {can(`${r.module}.reject`) && (
              <Button variant="outline" onClick={() => setDecisionModal({ decision: "REJECT", request: r })}>
                Reject
              </Button>
            )}
          </div>
        ) : (
          <Link href={`/tenant/approvals/${r.id}`}>View</Link>
        ),
    },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        title="Pending Approvals"
        description="Actions across every module that are waiting on a second-party decision before they take effect."
        action={
          <Link href="/tenant/approvals/history">
            <Button variant="outline">View History</Button>
          </Link>
        }
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {requests === null ? (
          <LoadingSkeleton columns={9} />
        ) : (
          <>
            <Toolbar
              title="Queue"
              searchValue={search}
              onSearchChange={(e) => setSearch(e.target.value)}
              searchPlaceholder="Search by reference or entity…"
              filters={
                <select className="select-filter" value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)}>
                  <option value="ALL">All modules</option>
                  {modules.map((m) => (
                    <option key={m} value={m}>
                      {m.replace(/_/g, " ")}
                    </option>
                  ))}
                </select>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <path d="M9 11.5l2 2 4-4.5" />
                    <rect x="3.5" y="3.5" width="17" height="17" rx="2.5" />
                  </svg>
                }
                title="Nothing waiting on a decision"
                description="Actions gated by an Approval Rule will show up here as soon as someone submits one."
              />
            ) : (
              <TableScroll>
                <Table columns={COLUMNS} rows={filtered} />
              </TableScroll>
            )}
          </>
        )}
      </div>

      <DecisionModal
        open={!!decisionModal}
        decision={decisionModal?.decision}
        request={decisionModal?.request}
        onClose={() => setDecisionModal(null)}
        onConfirm={handleDecision}
      />
    </div>
  );
}
