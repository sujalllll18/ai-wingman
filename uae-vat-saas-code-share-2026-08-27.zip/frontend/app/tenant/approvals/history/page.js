"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Button from "../../../../components/ui/Button";
import ApprovalStatusBadge from "../../../../components/approvals/ApprovalStatusBadge";

function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function ApprovalHistoryPage() {
  const { allowed, loading: permLoading } = useRequirePermission("approvals.view_history");

  const [requests, setRequests] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { approvalRequests } = await api.listApprovalHistory(token);
      setRequests(approvalRequests);
    } catch (err) {
      setError(err.message);
    }
  }

  const filtered = useMemo(() => {
    if (!requests) return [];
    const q = search.trim().toLowerCase();
    return requests.filter((r) => {
      const matchesSearch = !q || r.referenceNumber.toLowerCase().includes(q) || r.entityType.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [requests, search, statusFilter]);

  const COLUMNS = [
    { key: "referenceNumber", header: "Reference", render: (r) => <Link href={`/tenant/approvals/${r.id}`}>{r.referenceNumber}</Link> },
    { key: "module", header: "Module", render: (r) => r.module.replace(/_/g, " ") },
    { key: "entityType", header: "Entity", render: (r) => r.entityType },
    { key: "requestedByName", header: "Maker", render: (r) => r.requestedByName },
    { key: "decidedByName", header: "Checker", render: (r) => r.decidedByName || "—" },
    { key: "decidedAt", header: "Decided On", render: (r) => formatDateTime(r.decidedAt) },
    { key: "decisionComments", header: "Comments", render: (r) => r.decisionComments || <span style={{ color: "var(--color-ink-faint)" }}>—</span> },
    { key: "status", header: "Status", render: (r) => <ApprovalStatusBadge status={r.status} /> },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        title="Approval History"
        description="Every decided request - approved, rejected, or cancelled - with who made it and why."
        action={
          <Link href="/tenant/approvals">
            <Button variant="outline">Back to Queue</Button>
          </Link>
        }
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {requests === null ? (
          <LoadingSkeleton columns={8} />
        ) : (
          <>
            <Toolbar
              title="History"
              searchValue={search}
              onSearchChange={(e) => setSearch(e.target.value)}
              searchPlaceholder="Search by reference or entity…"
              filters={
                <select className="select-filter" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                  <option value="ALL">All outcomes</option>
                  <option value="APPROVED">Approved</option>
                  <option value="REJECTED">Rejected</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="9" />
                    <path d="M12 7v5l3 3" />
                  </svg>
                }
                title="No decided requests yet"
                description="Approved, rejected, and cancelled requests will show up here."
              />
            ) : (
              <TableScroll>
                <Table columns={COLUMNS} rows={filtered} />
              </TableScroll>
            )}
          </>
        )}
      </div>
    </div>
  );
}
