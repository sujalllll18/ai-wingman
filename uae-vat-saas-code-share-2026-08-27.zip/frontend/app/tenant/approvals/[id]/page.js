"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import { usePermissions } from "../../../../hooks/usePermissions";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Tabs from "../../../../components/ui/Tabs";
import Button from "../../../../components/ui/Button";
import ApprovalStatusBadge from "../../../../components/approvals/ApprovalStatusBadge";
import DecisionModal from "../../../../components/approvals/DecisionModal";
import OverviewTab from "../../../../components/approval-detail/OverviewTab";
import ChangesTab from "../../../../components/approval-detail/ChangesTab";
import ActivityTab from "../../../../components/approval-detail/ActivityTab";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "changes", label: "Changes" },
  { key: "activity", label: "Activity" },
];

export default function ApprovalRequestDetailPage() {
  const { id } = useParams();
  const { allowed, loading: permLoading } = useRequirePermission("approvals.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [request, setRequest] = useState(null);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("overview");
  const [decisionModal, setDecisionModal] = useState(null); // "APPROVE" | "REJECT" | null

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { approvalRequest } = await api.getApprovalRequest(token, id);
      setRequest(approvalRequest);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDecision(comments) {
    try {
      const token = tenantAuth.get();
      if (decisionModal === "APPROVE") await api.approveApprovalRequest(token, id, comments);
      else await api.rejectApprovalRequest(token, id, comments);
      showToast(`Request ${decisionModal === "APPROVE" ? "approved" : "rejected"}.`);
      setDecisionModal(null);
      await load();
    } catch (err) {
      showToast(err.message);
    }
  }

  const breadcrumb = [{ label: "Ledger" }, { label: "Approvals", href: "/tenant/approvals" }, { label: request?.referenceNumber || "Request" }];

  if (permLoading || !allowed) return null;

  if (error && !request) {
    return (
      <div>
        <PageHeader breadcrumb={breadcrumb} title="Approval Request" />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!request) return <p>Loading…</p>;

  const canDecide = request.status === "PENDING" && (can(`${request.module}.approve`) || can(`${request.module}.reject`));

  return (
    <div>
      <PageHeader
        breadcrumb={breadcrumb}
        title={request.referenceNumber}
        description={`${request.entityType} · ${request.action.replace(/_/g, " ")}`}
        action={
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <ApprovalStatusBadge status={request.status} />
            {canDecide && (
              <>
                {can(`${request.module}.reject`) && (
                  <Button variant="outline" onClick={() => setDecisionModal("REJECT")}>
                    Reject
                  </Button>
                )}
                {can(`${request.module}.approve`) && <Button onClick={() => setDecisionModal("APPROVE")}>Approve</Button>}
              </>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={setActiveTab} />

      <div role="tabpanel" id={`tabpanel-${activeTab}`} aria-labelledby={`tab-${activeTab}`}>
        {activeTab === "overview" && <OverviewTab request={request} />}
        {activeTab === "changes" && <ChangesTab request={request} />}
        {activeTab === "activity" && <ActivityTab request={request} />}
      </div>

      <DecisionModal
        open={!!decisionModal}
        decision={decisionModal}
        request={request}
        onClose={() => setDecisionModal(null)}
        onConfirm={handleDecision}
      />
    </div>
  );
}
