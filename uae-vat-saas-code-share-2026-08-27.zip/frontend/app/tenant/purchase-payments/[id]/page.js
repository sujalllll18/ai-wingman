"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { usePermissions } from "../../../../hooks/usePermissions";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import Field from "../../../../components/ui/Field";
import Input from "../../../../components/ui/Input";
import Select from "../../../../components/ui/Select";
import Modal from "../../../../components/ui/Modal";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import NoteActivityTimeline from "../../../../components/notes/NoteActivityTimeline";
import PaymentStatusBadge from "../../../../components/payments/PaymentStatusBadge";
import AllocationEditor from "../../../../components/payments/AllocationEditor";
import ReconciliationStatusBadge from "../../../../components/reconciliation/ReconciliationStatusBadge";

const PAYMENT_METHODS = [
  { value: "CASH", label: "Cash" },
  { value: "BANK_TRANSFER", label: "Bank Transfer" },
  { value: "CARD", label: "Card" },
  { value: "CHEQUE", label: "Cheque" },
  { value: "OTHER", label: "Other" },
];

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function SupplierPaymentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();
  const { can } = usePermissions();

  const [payment, setPayment] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editFields, setEditFields] = useState({ paymentDate: "", method: "CASH", accountRef: "", reference: "", notes: "" });
  const [allocateOpen, setAllocateOpen] = useState(false);
  const [allocatable, setAllocatable] = useState([]);
  const [amounts, setAmounts] = useState({});
  const [confirmAction, setConfirmAction] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { payment } = await api.getSupplierPayment(token, params.id);
      setPayment(payment);
    } catch (err) {
      setError(err.message);
    }
  }

  function openEdit() {
    setEditFields({
      paymentDate: payment.paymentDate.slice(0, 10),
      method: payment.method,
      accountRef: payment.accountRef || "",
      reference: payment.reference || "",
      notes: payment.notes || "",
    });
    setEditOpen(true);
  }

  async function handleSaveEdit(e) {
    e.preventDefault();
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { payment: updated } = await api.updateSupplierPayment(token, payment.id, editFields);
      setPayment(updated);
      setEditOpen(false);
      showToast("Payment updated.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function openAllocate() {
    try {
      const token = tenantAuth.get();
      const { purchaseBills } = await api.listAllocatableBills(token, payment.vendorId);
      const seeded = {};
      payment.allocations.forEach((a) => {
        seeded[a.purchaseBillId] = a.allocatedAmount;
      });
      const merged = [...purchaseBills];
      payment.allocations.forEach((a) => {
        if (!merged.find((b) => b.id === a.purchaseBillId)) {
          merged.push({ id: a.purchaseBillId, billNumberDisplay: a.purchaseBill.billNumberDisplay, purchaseDate: null, currency: a.purchaseBill.currency, grandTotal: a.purchaseBill.grandTotal, outstandingAmount: a.purchaseBill.outstandingAmount });
        }
      });
      setAllocatable(merged.map((b) => ({ id: b.id, number: b.billNumberDisplay, date: b.purchaseDate, currency: b.currency, grandTotal: b.grandTotal, outstandingAmount: b.outstandingAmount })));
      setAmounts(seeded);
      setAllocateOpen(true);
    } catch (err) {
      showToast(err.message);
    }
  }

  async function handleSaveAllocation() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const allocations = Object.entries(amounts)
        .filter(([, v]) => Number(v) > 0)
        .map(([purchaseBillId, v]) => ({ purchaseBillId, amount: Number(v) }));
      const { payment: updated } = await api.reallocateSupplierPayment(token, payment.id, allocations);
      setPayment(updated);
      setAllocateOpen(false);
      showToast("Allocation updated.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirmAction() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      if (confirmAction === "cancel") {
        const { payment: updated } = await api.cancelSupplierPayment(token, payment.id);
        setPayment(updated);
        showToast("Payment cancelled.");
      } else if (confirmAction === "delete") {
        await api.deleteSupplierPayment(token, payment.id);
        showToast("Payment deleted.");
        router.push("/tenant/purchase-payments");
        return;
      } else if (confirmAction === "reconcile") {
        const { payment: updated } = await api.reconcileSupplierPayment(token, payment.id);
        setPayment(updated);
        showToast("Marked as reconciled.");
      } else if (confirmAction === "unreconcile") {
        const { payment: updated } = await api.unreconcileSupplierPayment(token, payment.id);
        setPayment(updated);
        showToast("Marked as unreconciled.");
      }
      setConfirmAction(null);
    } catch (err) {
      showToast(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  if (!payment) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Payments Made", href: "/tenant/purchase-payments" }, { label: "…" }]} title="Payment" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const editable = payment.status === "CONFIRMED" && payment.reconciliationStatus === "UNRECONCILED";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Payments Made", href: "/tenant/purchase-payments" }, { label: payment.paymentNumberDisplay }]}
        title={payment.paymentNumberDisplay}
        eyebrow={<PaymentStatusBadge payment={payment} />}
        description={`Paid to ${payment.vendorName} on ${formatDate(payment.paymentDate)}`}
        action={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {can("purchase_payments.update") && (
              <Button variant="outline" onClick={openEdit} disabled={!editable}>
                Edit
              </Button>
            )}
            {can("purchase_payments.allocate") && (
              <Button variant="outline" onClick={openAllocate} disabled={!editable}>
                Allocate
              </Button>
            )}
            {can("purchase_payments.reconcile") && payment.reconciliationStatus !== "PARTIALLY_RECONCILED" &&
              (payment.reconciliationStatus === "RECONCILED" ? (
                <Button variant="outline" onClick={() => setConfirmAction("unreconcile")}>
                  Unreconcile
                </Button>
              ) : (
                <Button variant="outline" onClick={() => setConfirmAction("reconcile")} disabled={payment.status === "CANCELLED"}>
                  Reconcile
                </Button>
              ))}
            {can("purchase_payments.cancel") && payment.status !== "CANCELLED" && (
              <Button variant="outline" onClick={() => setConfirmAction("cancel")} disabled={payment.reconciliationStatus === "RECONCILED"}>
                Cancel
              </Button>
            )}
            {can("purchase_payments.delete") && payment.allocatedTotal === 0 && payment.status !== "CANCELLED" && (
              <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                Delete
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Payment Details</h3>
            <div className="review-list">
              <div className="review-row"><span className="review-label">Payment Number</span><span className="review-value mono">{payment.paymentNumberDisplay}</span></div>
              <div className="review-row"><span className="review-label">Supplier</span><span className="review-value">{payment.vendorName}</span></div>
              <div className="review-row"><span className="review-label">Date</span><span className="review-value">{formatDate(payment.paymentDate)}</span></div>
              <div className="review-row"><span className="review-label">Amount</span><span className="review-value mono">{formatCurrency(payment.amount, payment.currency)}</span></div>
              <div className="review-row"><span className="review-label">Method</span><span className="review-value">{PAYMENT_METHODS.find((m) => m.value === payment.method)?.label || payment.method}</span></div>
              <div className="review-row"><span className="review-label">Bank / Cash Account</span><span className="review-value">{payment.accountRef || "—"}</span></div>
              <div className="review-row"><span className="review-label">Reference</span><span className="review-value">{payment.reference || "—"}</span></div>
              {payment.source === "IMPORT" && <div className="review-row"><span className="review-label">Source</span><span className="review-value">Imported</span></div>}
            </div>
            {payment.notes && (
              <>
                <h4 style={{ marginBottom: 4 }}>Notes</h4>
                <p style={{ margin: 0 }}>{payment.notes}</p>
              </>
            )}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Allocation</h3>
            {payment.allocations.length === 0 ? (
              <p className="helptext">Fully unallocated - not yet applied to any purchase bill.</p>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Bill #</th>
                    <th>Bill Date</th>
                    <th className="num">Bill Total</th>
                    <th className="num">Allocated Amount</th>
                    <th className="num">Remaining Outstanding</th>
                  </tr>
                </thead>
                <tbody>
                  {payment.allocations.map((a) => (
                    <tr key={a.id}>
                      <td>
                        <Link href={`/tenant/purchases/${a.purchaseBill.id}`} className="mono">
                          {a.purchaseBill.billNumberDisplay}
                        </Link>
                      </td>
                      <td>—</td>
                      <td className="num mono">{formatCurrency(a.purchaseBill.grandTotal, a.purchaseBill.currency)}</td>
                      <td className="num mono">{formatCurrency(a.allocatedAmount, payment.currency)}</td>
                      <td className="num mono">{formatCurrency(a.purchaseBill.outstandingAmount, a.purchaseBill.currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>History / Audit</h3>
            <NoteActivityTimeline activities={payment.activities} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Totals</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Payment Amount</span>
                <span className="review-value mono">{formatCurrency(payment.amount, payment.currency)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Allocated</span>
                <span className="review-value mono">{formatCurrency(payment.allocatedTotal, payment.currency)}</span>
              </div>
              <div className="review-row" style={{ fontWeight: 600 }}>
                <span className="review-label">Unallocated</span>
                <span className="review-value mono">{formatCurrency(payment.unallocatedAmount, payment.currency)}</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Bank Reconciliation</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Status</span>
                <ReconciliationStatusBadge status={payment.reconciliationStatus} />
              </div>
            </div>
            {payment.reconciliationLines?.length > 0 ? (
              <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
                {payment.reconciliationLines.map((l) => (
                  <div key={l.id} className="review-row">
                    <span className="review-label">{l.match.status === "CONFIRMED" ? "Matched" : "Suggested"}</span>
                    <span className="review-value">
                      <Link href={l.match.status === "CONFIRMED" ? `/tenant/banking/reconciliation/matches/${l.match.id}` : `/tenant/banking/reconciliation/${l.match.bankLines[0]?.bankTransaction?.id}`}>
                        {l.match.bankLines[0]?.bankTransaction?.description || "Bank transaction"}
                      </Link>
                      <span className="helptext" style={{ display: "block" }}>{formatCurrency(l.amount, payment.currency)}</span>
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="helptext" style={{ marginTop: 10 }}>Not yet matched to a bank transaction.</p>
            )}
          </Card>
        </div>
      </div>

      <Modal open={editOpen} onClose={() => setEditOpen(false)} ariaLabel="Edit Payment">
        <form onSubmit={handleSaveEdit}>
          <h2 style={{ marginBottom: 20 }}>Edit Payment</h2>
          <Field id="sedit-date" label="Payment Date">
            <Input type="date" value={editFields.paymentDate} onChange={(e) => setEditFields({ ...editFields, paymentDate: e.target.value })} />
          </Field>
          <Field id="sedit-method" label="Payment Method">
            <Select value={editFields.method} onChange={(e) => setEditFields({ ...editFields, method: e.target.value })}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </Select>
          </Field>
          <Field id="sedit-account-ref" label="Bank / Cash Account">
            <Input value={editFields.accountRef} onChange={(e) => setEditFields({ ...editFields, accountRef: e.target.value })} />
          </Field>
          <Field id="sedit-reference" label="Reference Number">
            <Input value={editFields.reference} onChange={(e) => setEditFields({ ...editFields, reference: e.target.value })} />
          </Field>
          <Field id="sedit-notes" label="Notes" style={{ marginBottom: 0 }}>
            <textarea className="inline-input" rows={2} value={editFields.notes} onChange={(e) => setEditFields({ ...editFields, notes: e.target.value })} />
          </Field>
          <div className="dialog-actions">
            <Button type="button" variant="outline" onClick={() => setEditOpen(false)} disabled={busy}>Cancel</Button>
            <Button type="submit" disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
          </div>
        </form>
      </Modal>

      <Modal open={allocateOpen} onClose={() => setAllocateOpen(false)} size="lg" ariaLabel="Allocate Payment">
        <h2 style={{ marginBottom: 4 }}>Allocate Payment</h2>
        <p className="helptext" style={{ marginBottom: 20 }}>Changing this replaces the payment&rsquo;s entire allocation set - every affected purchase bill&rsquo;s balance recalculates immediately.</p>
        <AllocationEditor items={allocatable} amounts={amounts} onChange={setAmounts} paymentAmount={payment.amount} itemLabel="purchase bill" />
        <div className="dialog-actions">
          <Button type="button" variant="outline" onClick={() => setAllocateOpen(false)} disabled={busy}>Cancel</Button>
          <Button type="button" onClick={handleSaveAllocation} disabled={busy}>{busy ? "Saving…" : "Save Allocation"}</Button>
        </div>
      </Modal>

      <ConfirmationDialog
        open={confirmAction === "cancel"}
        title="Cancel this payment?"
        message="Every purchase bill this payment is allocated to recalculates its balance immediately. The payment record and its history are preserved, not deleted. This can't be undone."
        confirmLabel="Cancel Payment"
        variant="danger"
        busy={busy}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "delete"}
        title="Delete this payment?"
        message="This payment has no allocations, so nothing else is affected. This can't be undone."
        confirmLabel="Delete"
        variant="danger"
        busy={busy}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "reconcile"}
        title="Mark as reconciled?"
        message="A reconciled payment can't be edited, reallocated, or cancelled until it's unreconciled first."
        confirmLabel="Mark Reconciled"
        busy={busy}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "unreconcile"}
        title="Mark as unreconciled?"
        message="This restores the ability to edit, reallocate, or cancel this payment."
        confirmLabel="Mark Unreconciled"
        busy={busy}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmAction(null)}
      />
    </div>
  );
}
