"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import MaterialFormModal from "../../../components/materials/MaterialFormModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

function formatCurrency(value) {
  return `AED ${Number(value).toFixed(2)}`;
}

export default function MaterialsPage() {
  const { allowed, loading: permLoading } = useRequirePermission("products.view");
  const { showToast } = useToast();
  const [materials, setMaterials] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { materials } = await api.listMaterials(token);
      setMaterials(materials);
    } catch (err) {
      setError(err.message);
    }
  }

  const filtered = useMemo(() => {
    if (!materials) return [];
    const q = search.trim().toLowerCase();
    if (!q) return materials;
    return materials.filter((m) => m.name.toLowerCase().includes(q) || m.unit.toLowerCase().includes(q));
  }, [materials, search]);

  const COLUMNS = [
    { key: "name", header: "Description", render: (m) => m.name },
    { key: "unit", header: "Unit", render: (m) => m.unit },
    { key: "price", header: "Selling Price", className: "num", render: (m) => formatCurrency(m.defaultUnitPrice) },
    { key: "vat", header: "Default Tax Category", render: (m) => m.defaultTaxCategory?.name || "—" },
    {
      key: "actions",
      header: "",
      render: (m) => (
        <button
          type="button"
          className="btn btn-outline btn-sm"
          onClick={() => {
            setEditingMaterial(m);
            setFormOpen(true);
          }}
        >
          Edit
        </button>
      ),
    },
  ];

  function openAdd() {
    setEditingMaterial(null);
    setFormOpen(true);
  }

  function handleSuccess(name) {
    setFormOpen(false);
    showToast(editingMaterial ? `"${name}" was updated.` : `"${name}" was added to your catalog.`);
    setEditingMaterial(null);
    load();
  }

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Products & Services" }]}
        title="Products & Services"
        description="Your material and service catalog — reused when adding invoice line items."
        action={<Button onClick={openAdd}>+ Add Material</Button>}
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {materials === null ? (
          <LoadingSkeleton columns={COLUMNS.length} />
        ) : materials.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <path d="M4 7.5 12 3.5l8 4v9l-8 4-8-4v-9z" />
                <path d="M4 7.5 12 11.5l8-4M12 11.5V20.5" />
              </svg>
            }
            title="No materials yet"
            description="Create your first material or service."
            action={<Button onClick={openAdd}>+ Add Material</Button>}
          />
        ) : (
          <>
            <Toolbar
              title="Products & Services"
              searchValue={search}
              onSearchChange={(e) => setSearch(e.target.value)}
              searchPlaceholder="Search by description or unit…"
            />
            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching materials"
                description="Try a different search term."
              />
            ) : (
              <TableScroll>
                <Table columns={COLUMNS} rows={filtered} />
              </TableScroll>
            )}
          </>
        )}
      </div>

      <MaterialFormModal
        key={editingMaterial?.id || "new"}
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditingMaterial(null);
        }}
        material={editingMaterial}
        onSuccess={handleSuccess}
      />
    </div>
  );
}
