"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import NoteStatusBadge from "../../../components/notes/NoteStatusBadge";
import Can from "../../../components/rbac/Can";
import SelectInvoiceModal from "../../../components/credit-notes/SelectInvoiceModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Same enterprise list pattern as Invoices/Purchases (Table, Toolbar,
// Pagination, ActionMenu, status badges, Empty/Loading states) - a
// deliberately simpler variant (no DataTable column reordering/hiding, no
// bulk-PDF batch rendering) since those weren't required for a correct v1.
export default function CreditNotesPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("credit_notes.view");
  const { showToast } = useToast();

  const [notes, setNotes] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [pickerOpen, setPickerOpen] = useState(false);

  function handleSelectInvoice(invoice) {
    setPickerOpen(false);
    router.push(`/tenant/credit-notes/new?invoiceId=${invoice.id}`);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { creditNotes } = await api.listCreditNotes(token);
      setNotes(creditNotes);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function handleExport() {
    const rows = [
      ["Credit Note #", "Original Invoice", "Customer", "Issue Date", "Status", "Subtotal", "VAT", "Total"],
      ...filtered.map((n) => [
        n.creditNoteNumberDisplay || "Draft",
        n.invoice?.invoiceNumberDisplay || "",
        n.customerName,
        n.issueDate ? formatDate(n.issueDate) : "",
        n.status,
        n.subtotal,
        n.vatTotal,
        n.grandTotal,
      ]),
    ];
    downloadCsv(`credit-notes-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  }

  const customers = useMemo(() => {
    if (!notes) return [];
    return Array.from(new Set(notes.map((n) => n.customerName))).sort();
  }, [notes]);
  const [customerFilter, setCustomerFilter] = useState("ALL");

  // KPI summary cards (2026-08-11) - same pattern as the new Sales Debit
  // Notes list page's own summary row.
  const kpis = useMemo(() => {
    if (!notes) return null;
    const draft = notes.filter((n) => n.status === "DRAFT");
    const issued = notes.filter((n) => n.status === "ISSUED");
    const cancelled = notes.filter((n) => n.status === "VOID");
    return {
      total: notes.length,
      draft: draft.length,
      issued: issued.length,
      cancelled: cancelled.length,
      totalValue: issued.reduce((s, n) => s + n.grandTotal, 0),
      totalVat: issued.reduce((s, n) => s + n.vatTotal, 0),
    };
  }, [notes]);

  const filtered = useMemo(() => {
    if (!notes) return [];
    const q = search.trim().toLowerCase();
    return notes.filter((n) => {
      const matchesSearch =
        !q ||
        (n.creditNoteNumberDisplay || "").toLowerCase().includes(q) ||
        (n.invoice?.invoiceNumberDisplay || "").toLowerCase().includes(q) ||
        n.customerName.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || n.status === statusFilter;
      const matchesCustomer = customerFilter === "ALL" || n.customerName === customerFilter;
      return matchesSearch && matchesStatus && matchesCustomer;
    });
  }, [notes, search, statusFilter, customerFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  const COLUMNS = useMemo(
    () => [
      {
        key: "creditNoteNumberDisplay",
        header: "Credit Note #",
        render: (n) => <span className="mono" style={{ fontWeight: 600 }}>{n.creditNoteNumberDisplay || "Draft"}</span>,
      },
      { key: "invoice", header: "Original Invoice", render: (n) => <span className="mono">{n.invoice?.invoiceNumberDisplay || "—"}</span> },
      { key: "customerName", header: "Customer", render: (n) => n.customerName },
      { key: "issueDate", header: "Issue Date", render: (n) => formatDate(n.issueDate) },
      { key: "status", header: "Status", render: (n) => <NoteStatusBadge status={n.status} /> },
      { key: "subtotal", header: "Subtotal", className: "num", render: (n) => formatCurrency(n.subtotal) },
      { key: "vatTotal", header: "VAT", className: "num", render: (n) => formatCurrency(n.vatTotal) },
      { key: "grandTotal", header: "Total", className: "num", render: (n) => formatCurrency(n.grandTotal) },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (n) => (
          <ActionMenu
            ariaLabel={`Actions for ${n.creditNoteNumberDisplay || "draft credit note"}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/credit-notes/${n.id}`) },
              { label: "History", onClick: () => router.push(`/tenant/credit-notes/${n.id}`) },
            ]}
          />
        ),
      },
    ],
    [router]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Credit Notes" }]}
        title="Credit Notes"
        description="Every reduction issued against a Sent invoice, in one place."
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {notes && notes.length > 0 && (
              <Button variant="outline" onClick={handleExport}>
                Export
              </Button>
            )}
            <Can permission="credit_notes.create">
              <Button onClick={() => setPickerOpen(true)}>+ New Credit Note</Button>
            </Can>
          </div>
        }
      />

      <ErrorBanner message={error} />

      {kpis && (
        <div className="kpi-card-grid">
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Credit Notes</span>
            </div>
            <span className="kpi-card-value">{kpis.total}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Draft</span>
            </div>
            <span className="kpi-card-value">{kpis.draft}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Issued</span>
            </div>
            <span className="kpi-card-value">{kpis.issued}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Cancelled</span>
            </div>
            <span className="kpi-card-value">{kpis.cancelled}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Credit Value</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalValue)}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total VAT Adjustment</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalVat)}</span>
          </div>
        </div>
      )}

      <div className="table-block">
        {notes === null ? (
          <LoadingSkeleton columns={7} />
        ) : notes.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
                <path d="M8 8h8M8 12h8M8 16h5" />
              </svg>
            }
            title="No credit notes yet"
            description="Start a new Credit Note by picking the Sent invoice it should reduce, or browse your invoices first."
            action={
              <div style={{ display: "flex", gap: 8 }}>
                <Can permission="credit_notes.create">
                  <Button onClick={() => setPickerOpen(true)}>+ New Credit Note</Button>
                </Can>
                <Link href="/tenant/invoices">
                  <Button variant="outline">Go to Invoices</Button>
                </Link>
              </div>
            }
          />
        ) : (
          <>
            <Toolbar
              title="Credit Notes"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by credit note #, invoice #, or customer…"
              filters={
                <>
                  <select
                    className="select-filter"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All statuses</option>
                    <option value="DRAFT">Draft</option>
                    <option value="ISSUED">Issued</option>
                    <option value="VOID">Cancelled</option>
                  </select>
                  <select
                    className="select-filter"
                    value={customerFilter}
                    onChange={(e) => {
                      setCustomerFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All customers</option>
                    {customers.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching credit notes"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} onRowClick={(n) => router.push(`/tenant/credit-notes/${n.id}`)} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Credit Notes"
                />
              </>
            )}
          </>
        )}
      </div>

      <SelectInvoiceModal open={pickerOpen} onClose={() => setPickerOpen(false)} onSelect={handleSelectInvoice} />
    </div>
  );
}
