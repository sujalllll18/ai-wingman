"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api, assetUrl } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import NoteStatusBadge from "../../../../components/notes/NoteStatusBadge";
import NoteActivityTimeline from "../../../../components/notes/NoteActivityTimeline";
import NoteLineItemsTable from "../../../../components/notes/NoteLineItemsTable";
import AdjustmentSummaryCard from "../../../../components/notes/AdjustmentSummaryCard";
import CreditNoteClassicTemplate from "../../../../components/credit-note-templates/ClassicTemplate";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function CreditNoteDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [creditNote, setCreditNote] = useState(null);
  const [adjustment, setAdjustment] = useState(null);
  const [businessAssets, setBusinessAssets] = useState({});
  const [error, setError] = useState("");
  const [confirmAction, setConfirmAction] = useState(null); // "issue" | "delete" | "void"
  const [busy, setBusy] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { creditNote, adjustment } = await api.getCreditNote(token, params.id);
      setCreditNote(creditNote);
      setAdjustment(adjustment);
      // Live Business Profile assets for the PDF (2026-08-11) - same
      // deliberate live-read, not-part-of-the-snapshot pattern the Invoice
      // Viewer already uses. Best-effort: a failure just leaves the logo/
      // stamp/signature slots empty, never blocks viewing the note itself.
      api
        .getBusinessProfile(token)
        .then(({ businessProfile }) =>
          setBusinessAssets({ logoUrl: assetUrl(businessProfile.logoUrl), stampUrl: assetUrl(businessProfile.stampUrl), signatureUrl: assetUrl(businessProfile.signatureUrl) })
        )
        .catch(() => {});
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleIssue() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const result = await api.issueCreditNote(token, params.id);
      setConfirmAction(null);
      if (result.approvalRequest) {
        showToast(`Issuing requires approval - submitted as ${result.approvalRequest.referenceNumber}. This stays a Draft until a checker decides.`);
        await load();
      } else {
        setCreditNote(result.creditNote);
        showToast(`${result.creditNote.creditNoteNumberDisplay} was issued.`);
        await load();
      }
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deleteCreditNote(token, params.id);
      showToast("Draft deleted.");
      router.push("/tenant/credit-notes");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
      setBusy(false);
    }
  }

  async function handleVoid() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { creditNote } = await api.voidCreditNote(token, params.id);
      setCreditNote(creditNote);
      setConfirmAction(null);
      showToast("Credit note cancelled.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  // Same jsPDF `.html()` technique as the Invoice/Purchase Viewer
  // (`doc.html(documentRef.current, {...})`) - not a manual
  // html2canvas+addImage reimplementation. `.html()` uses html2canvas
  // internally and paginates automatically via autoPaging:"text", which a
  // manual single-image approach wouldn't handle for a note with many lines.
  async function handleDownloadPdf() {
    setDownloading(true);
    try {
      const node = document.getElementById("credit-note-pdf-source");
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      await doc.html(node, { x: 0, y: 0, width: 210, windowWidth: node.offsetWidth, autoPaging: "text" });
      doc.save(`${creditNote.creditNoteNumberDisplay || "Draft-CreditNote"}.pdf`);
      const token = tenantAuth.get();
      api.logCreditNoteActivity(token, creditNote.id, "DOWNLOADED", "PDF").catch(() => {});
      showToast(`Downloaded ${creditNote.creditNoteNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setDownloading(false);
    }
  }

  if (!creditNote) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Credit Notes", href: "/tenant/credit-notes" }, { label: "…" }]} title="Credit Note" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const title = creditNote.creditNoteNumberDisplay || "Draft Credit Note";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Credit Notes", href: "/tenant/credit-notes" }, { label: title }]}
        title={title}
        eyebrow={<NoteStatusBadge status={creditNote.status} />}
        description={
          creditNote.status === "DRAFT"
            ? "This credit note hasn't been issued — it isn't numbered and has no VAT effect yet."
            : `Issued ${formatDate(creditNote.issueDate)}`
        }
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="outline" onClick={handleDownloadPdf} disabled={downloading}>
              Download PDF
            </Button>
            {creditNote.status === "DRAFT" && (
              <>
                <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                  Delete Draft
                </Button>
                <Button onClick={() => setConfirmAction("issue")}>Issue Credit Note</Button>
              </>
            )}
            {creditNote.status === "ISSUED" && (
              <Button variant="outline" onClick={() => setConfirmAction("void")}>
                Cancel Credit Note
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Original Invoice</h3>
            <p style={{ margin: 0 }}>
              <Link href={`/tenant/invoices/${creditNote.invoice.id}`} className="mono">
                {creditNote.invoice.invoiceNumberDisplay}
              </Link>
            </p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Customer</h3>
            <p style={{ margin: 0 }}>{creditNote.customerName}</p>
            {creditNote.customerAddress && <p className="helptext" style={{ margin: 0 }}>{creditNote.customerAddress}</p>}
            {creditNote.customerTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {creditNote.customerTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Reason</h3>
            <p style={{ margin: 0 }}>{creditNote.reason}</p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <NoteLineItemsTable lineItems={creditNote.lineItems} currency={creditNote.currency} />
          </Card>

          {creditNote.notes && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Notes</h3>
              <p style={{ margin: 0 }}>{creditNote.notes}</p>
            </Card>
          )}

          <Card>
            <h3 style={{ marginTop: 0 }}>Activity</h3>
            <NoteActivityTimeline activities={creditNote.activities} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          {adjustment && (
            <AdjustmentSummaryCard
              currency={creditNote.currency}
              originalAmount={adjustment.originalAmount}
              previouslyAdjusted={adjustment.previouslyAdjusted}
              previouslyLabel="Previously Credited"
              currentNote={adjustment.currentNote ?? creditNote.grandTotal}
              currentLabel="This Credit Note"
              remainingAmount={adjustment.remainingAmount}
            />
          )}
          <Card>
            <h3 style={{ marginTop: 0 }}>Totals</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Subtotal</span>
                <span className="review-value mono">{creditNote.currency} {Number(creditNote.subtotal).toFixed(2)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">VAT</span>
                <span className="review-value mono">{creditNote.currency} {Number(creditNote.vatTotal).toFixed(2)}</span>
              </div>
              <div className="review-row" style={{ fontWeight: 600 }}>
                <span className="review-label">Grand Total</span>
                <span className="review-value mono">{creditNote.currency} {Number(creditNote.grandTotal).toFixed(2)}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <ConfirmationDialog
        open={confirmAction === "issue"}
        title="Issue this credit note?"
        message="This assigns a permanent credit note number, freezes the document, and reduces output VAT for the period containing this issue date. This can't be undone."
        confirmLabel="Issue Credit Note"
        busy={busy}
        onConfirm={handleIssue}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "delete"}
        title="Delete this draft?"
        message="This draft has never been issued, so no credit note number has been consumed. This can't be undone."
        confirmLabel="Delete Draft"
        variant="danger"
        busy={busy}
        onConfirm={handleDelete}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "void"}
        title="Cancel this credit note?"
        message="A cancelled credit note's number is never reused, and its VAT effect is reversed from this point forward. This can't be undone."
        confirmLabel="Cancel Credit Note"
        variant="danger"
        busy={busy}
        onConfirm={handleVoid}
        onCancel={() => setConfirmAction(null)}
      />

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        <div id="credit-note-pdf-source">
          <CreditNoteClassicTemplate creditNote={creditNote} businessAssets={businessAssets} />
        </div>
      </div>
    </div>
  );
}
