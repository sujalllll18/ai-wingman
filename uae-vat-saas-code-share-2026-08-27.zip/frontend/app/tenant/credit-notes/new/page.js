"use client";

import { useSearchParams } from "next/navigation";
import PageHeader from "../../../../components/ui/PageHeader";
import CreditNoteForm from "../../../../components/credit-notes/CreditNoteForm";

export default function NewCreditNotePage() {
  const searchParams = useSearchParams();
  const invoiceId = searchParams.get("invoiceId");

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Credit Notes", href: "/tenant/credit-notes" }, { label: "New Credit Note" }]}
        title="New Credit Note"
        description="Build a draft against a Sent invoice — nothing is numbered or VAT-effective until you issue it."
      />
      <CreditNoteForm invoiceId={invoiceId} />
    </div>
  );
}
