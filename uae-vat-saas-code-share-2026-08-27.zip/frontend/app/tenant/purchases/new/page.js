"use client";

import { useRouter } from "next/navigation";
import PageHeader from "../../../../components/ui/PageHeader";
import PurchaseForm from "../../../../components/purchases/PurchaseForm";

export default function NewPurchasePage() {
  const router = useRouter();

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Purchases", href: "/tenant/purchases" }, { label: "New Purchase Bill" }]}
        title="New Purchase Bill"
        description="Manual entry — the alternative to OCR Upload. Nothing is numbered until you Record it."
      />
      <PurchaseForm mode="create" onSaved={(purchase) => router.push(`/tenant/purchases/${purchase.id}`)} />
    </div>
  );
}
