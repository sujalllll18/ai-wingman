"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import PurchaseForm from "../../../../components/purchases/PurchaseForm";
import PurchaseStatusBadge from "../../../../components/purchases/PurchaseStatusBadge";
import PurchaseLineItemsTable from "../../../../components/purchases/PurchaseLineItemsTable";
import TableScroll from "../../../../components/ui/TableScroll";
import PurchaseSummarySidebar from "../../../../components/purchases/PurchaseSummarySidebar";
import PurchasePaymentFormModal from "../../../../components/purchases/PurchasePaymentFormModal";
import PurchaseActivityTimeline from "../../../../components/purchases/PurchaseActivityTimeline";
import PurchaseInternalNotesCard from "../../../../components/purchases/PurchaseInternalNotesCard";
import PurchaseAttachmentsCard from "../../../../components/purchases/PurchaseAttachmentsCard";
import Can from "../../../../components/rbac/Can";
import ReconciliationStatusBadge from "../../../../components/reconciliation/ReconciliationStatusBadge";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

const PAYMENT_METHOD_LABEL = {
  CASH: "Cash",
  BANK_TRANSFER: "Bank Transfer",
  CARD: "Card",
  CHEQUE: "Cheque",
  OTHER: "Other",
};

export default function PurchaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [purchase, setPurchase] = useState(null);
  const [error, setError] = useState("");
  const [confirmAction, setConfirmAction] = useState(null); // "record" | "delete" | "void" | "archive" | "restore" | "duplicate"
  const [busy, setBusy] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.getPurchase(token, params.id);
      setPurchase(purchase);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRecord() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.recordPurchase(token, params.id);
      setPurchase(purchase);
      setConfirmAction(null);
      showToast(`${purchase.billNumberDisplay} was recorded.`);
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deletePurchase(token, params.id);
      showToast("Draft deleted.");
      router.push("/tenant/purchases");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
      setBusy(false);
    }
  }

  async function handleVoid() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.voidPurchase(token, params.id);
      setPurchase(purchase);
      setConfirmAction(null);
      showToast("Purchase bill cancelled.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleArchive() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.archivePurchase(token, params.id);
      setPurchase(purchase);
      setConfirmAction(null);
      showToast("Purchase bill archived.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleRestore() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.restorePurchase(token, params.id);
      setPurchase(purchase);
      showToast("Purchase bill restored.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleDuplicate() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { purchase: newPurchase } = await api.duplicatePurchase(token, params.id);
      showToast("Draft created from this purchase bill.");
      router.push(`/tenant/purchases/${newPurchase.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
      setConfirmAction(null);
    }
  }

  if (!purchase) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Purchases", href: "/tenant/purchases" }, { label: "…" }]} title="Purchase Bill" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const title = purchase.billNumberDisplay || "Draft Purchase Bill";

  const operationalExtras = (
    <>
      <Card>
        <h3 style={{ marginTop: 0 }}>Activity</h3>
        <PurchaseActivityTimeline activities={purchase.activities} />
      </Card>
      <PurchaseInternalNotesCard purchase={purchase} onSaved={setPurchase} showToast={showToast} />
      <PurchaseAttachmentsCard purchase={purchase} onSaved={setPurchase} showToast={showToast} />
    </>
  );

  const archiveRestoreDuplicate = (
    <Card>
      <h3 style={{ marginTop: 0 }}>Record Actions</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <Button variant="outline" onClick={() => setConfirmAction("duplicate")} disabled={busy}>
          Duplicate Purchase Bill
        </Button>
        {purchase.archivedAt ? (
          <Button variant="outline" onClick={handleRestore} disabled={busy}>
            Restore from Archive
          </Button>
        ) : (
          <Button variant="outline" onClick={() => setConfirmAction("archive")} disabled={busy}>
            Archive Purchase Bill
          </Button>
        )}
      </div>
      {purchase.archivedAt && <p className="helptext" style={{ marginTop: 8, marginBottom: 0 }}>Archived {formatDate(purchase.archivedAt)}</p>}
    </Card>
  );

  const duplicateDialog = (
    <ConfirmationDialog
      open={confirmAction === "duplicate"}
      title="Duplicate this purchase bill?"
      message="Creates a new Draft with the same vendor and line items, with tax re-resolved fresh from current Tax Master data. A new bill number is only assigned if you Record it."
      confirmLabel="Create Draft"
      busy={busy}
      onConfirm={handleDuplicate}
      onCancel={() => setConfirmAction(null)}
    />
  );
  const archiveDialog = (
    <ConfirmationDialog
      open={confirmAction === "archive"}
      title="Archive this purchase bill?"
      message="Archived purchase bills are hidden from the main list but never deleted - restore them anytime from the Archived view."
      confirmLabel="Archive"
      busy={busy}
      onConfirm={handleArchive}
      onCancel={() => setConfirmAction(null)}
    />
  );

  if (purchase.status === "DRAFT") {
    return (
      <div>
        <PageHeader
          breadcrumb={[{ label: "Ledger" }, { label: "Purchases", href: "/tenant/purchases" }, { label: title }]}
          title={title}
          description="This purchase bill hasn't been recorded — everything here is still editable."
          action={
            <div style={{ display: "flex", gap: 8 }}>
              <Link href={`/tenant/purchases/${purchase.id}/view`}>
                <Button variant="outline">Preview</Button>
              </Link>
              <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                Delete Draft
              </Button>
              <Button onClick={() => setConfirmAction("record")}>Record Purchase</Button>
            </div>
          }
        />
        <ErrorBanner message={error} />
        <PurchaseForm
          mode="edit"
          initialPurchase={purchase}
          onSaved={(updated) => {
            setPurchase(updated);
            showToast("Draft saved.");
          }}
        />

        <div className="detail-layout" style={{ marginTop: 20 }}>
          <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>{operationalExtras}</div>
          <div className="detail-rail">{archiveRestoreDuplicate}</div>
        </div>

        <ConfirmationDialog
          open={confirmAction === "record"}
          title="Record this purchase bill?"
          message="This assigns a permanent bill number and locks the vendor, line item, and tax details as they stand right now. Future changes to Vendor or Tax Master records will never affect it again."
          confirmLabel="Record Purchase"
          busy={busy}
          onConfirm={handleRecord}
          onCancel={() => setConfirmAction(null)}
        />
        <ConfirmationDialog
          open={confirmAction === "delete"}
          title="Delete this draft?"
          message="This draft has never been recorded, so no bill number has been consumed. This can't be undone. (Prefer Archive if you'd rather keep the record.)"
          confirmLabel="Delete Draft"
          variant="danger"
          busy={busy}
          onConfirm={handleDelete}
          onCancel={() => setConfirmAction(null)}
        />
        {duplicateDialog}
        {archiveDialog}
      </div>
    );
  }

  // RECORDED or VOID - read-only snapshot view, same immutability principle as Invoice.
  const readOnlyLines = purchase.lineItems.map((li) => ({ ...li, key: li.id }));

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Purchases", href: "/tenant/purchases" }, { label: title }]}
        title={title}
        eyebrow={<PurchaseStatusBadge purchase={purchase} />}
        description={`Purchase Date ${formatDate(purchase.purchaseDate)}${purchase.invoiceDate ? ` · Invoice Date ${formatDate(purchase.invoiceDate)}` : ""}`}
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Link href={`/tenant/purchases/${purchase.id}/view`}>
              <Button variant="outline">Preview</Button>
            </Link>
            {purchase.status === "RECORDED" && (
              <Can permission="debit_notes.create">
                <Link href={`/tenant/debit-notes/new?purchaseBillId=${purchase.id}`}>
                  <Button variant="outline">Issue Debit Note</Button>
                </Link>
              </Can>
            )}
            {purchase.status === "RECORDED" && (
              <Button variant="outline" onClick={() => setConfirmAction("void")}>
                Cancel Purchase Bill
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Vendor</h3>
            <p style={{ margin: 0 }}>{purchase.vendorName}</p>
            {purchase.vendorAddress && <p className="helptext" style={{ margin: 0 }}>{purchase.vendorAddress}</p>}
            {purchase.vendorTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {purchase.vendorTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <PurchaseLineItemsTable lines={readOnlyLines} computedLines={purchase.lineItems} taxCategories={[]} onChangeLine={() => {}} disabled />
          </Card>

          {purchase.notes && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Notes</h3>
              <p style={{ margin: 0 }}>{purchase.notes}</p>
            </Card>
          )}

          {purchase.status === "RECORDED" && (
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <h3 style={{ margin: 0 }}>Payments</h3>
                  {purchase.reconciliationSummary && <ReconciliationStatusBadge status={purchase.reconciliationSummary} />}
                </div>
                <Button variant="outline" onClick={() => setPaymentModalOpen(true)}>
                  Record Payment
                </Button>
              </div>
              {/* Sourced from purchasePaymentAllocations (Phase 2 Payments
                  module, 2026-08-22), not the legacy `payments` relation -
                  see invoices/[id]/page.js's identical comment. */}
              {purchase.purchasePaymentAllocations && purchase.purchasePaymentAllocations.length > 0 ? (
                <TableScroll style={{ marginTop: 12 }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Payment #</th>
                        <th>Date</th>
                        <th>Method</th>
                        <th>Reference</th>
                        <th className="num">Amount Allocated</th>
                      </tr>
                    </thead>
                    <tbody>
                      {purchase.purchasePaymentAllocations.map((a) => (
                        <tr key={a.id}>
                          <td>
                            <Link href={`/tenant/purchase-payments/${a.purchasePayment.id}`} className="mono">
                              {a.purchasePayment.paymentNumberDisplay}
                            </Link>
                            {a.purchasePayment.status === "CANCELLED" && <span className="badge badge-danger" style={{ marginLeft: 6 }}>Cancelled</span>}
                          </td>
                          <td>{formatDate(a.purchasePayment.paymentDate)}</td>
                          <td>{PAYMENT_METHOD_LABEL[a.purchasePayment.method] || a.purchasePayment.method}</td>
                          <td>{a.purchasePayment.reference || "—"}</td>
                          <td className="num mono">{formatCurrency(a.allocatedAmount, a.purchasePayment.currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </TableScroll>
              ) : (
                <p className="helptext" style={{ marginTop: 12 }}>No payments recorded yet.</p>
              )}
              <p className="helptext" style={{ marginTop: 12 }}>
                <Link href={`/tenant/purchase-payments?vendorId=${purchase.vendorId || ""}`}>View all payments to this supplier →</Link>
              </p>
            </Card>
          )}

          {purchase.status === "RECORDED" && <DebitNotesAgainstPurchase purchaseBillId={purchase.id} />}

          {operationalExtras}
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <PurchaseSummarySidebar totals={purchase} />

          {purchase.status === "RECORDED" && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Payment Status</h3>
              <PurchaseStatusBadge purchase={purchase} />
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12, fontSize: 13 }}>
                <span className="helptext">Amount Paid</span>
                <span className="mono">{formatCurrency(purchase.amountPaid, purchase.currency)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, fontSize: 13 }}>
                <span className="helptext">Outstanding</span>
                <span className="mono">{formatCurrency(purchase.outstandingAmount, purchase.currency)}</span>
              </div>
            </Card>
          )}

          {archiveRestoreDuplicate}
        </div>
      </div>

      <ConfirmationDialog
        open={confirmAction === "void"}
        title="Cancel this purchase bill?"
        message="A cancelled purchase bill's number is never reused. This can't be undone."
        confirmLabel="Cancel Purchase Bill"
        variant="danger"
        busy={busy}
        onConfirm={handleVoid}
        onCancel={() => setConfirmAction(null)}
      />
      {duplicateDialog}
      {archiveDialog}

      <PurchasePaymentFormModal
        open={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        purchase={purchase}
        onSuccess={(updated) => {
          setPurchase(updated);
          setPaymentModalOpen(false);
          showToast("Payment recorded.");
        }}
      />
    </div>
  );
}

// Traceability: Purchase -> Debit Notes, mirrors CreditNotesAgainstInvoice
// on the Invoice detail page - same "reuse the existing list endpoint,
// filtered client-side" pattern, no new per-purchase GET needed.
function DebitNotesAgainstPurchase({ purchaseBillId }) {
  const [notes, setNotes] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const token = tenantAuth.get();
        const { debitNotes } = await api.listDebitNotes(token);
        if (!cancelled) setNotes(debitNotes.filter((n) => n.purchaseBillId === purchaseBillId));
      } catch {
        if (!cancelled) setNotes([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [purchaseBillId]);

  if (!notes || notes.length === 0) return null;

  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Debit Notes</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {notes.map((n) => (
          <Link key={n.id} href={`/tenant/debit-notes/${n.id}`} className="review-row" style={{ textDecoration: "none" }}>
            <span className="mono">{n.debitNoteNumberDisplay || "Draft"}</span>
            <span>{formatCurrency(n.grandTotal, n.currency)}</span>
          </Link>
        ))}
      </div>
    </Card>
  );
}
