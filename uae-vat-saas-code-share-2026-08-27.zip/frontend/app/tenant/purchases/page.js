"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import { useLocalStorageState } from "../../../hooks/useLocalStorageState";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import DataTable from "../../../components/ui/DataTable";
import TableScroll from "../../../components/ui/TableScroll";
import ColumnSelector from "../../../components/ui/ColumnSelector";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import { DocumentStatusChip, PaymentStatusChip } from "../../../components/purchases/PurchaseStatusBadge";
import SourceBadge from "../../../components/purchases/SourceBadge";
import PurchaseMoreFiltersDrawer from "../../../components/purchases/PurchaseMoreFiltersDrawer";
import { getPurchaseTemplateComponent, DEFAULT_PURCHASE_TEMPLATE } from "../../../components/purchase-templates";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function sortPurchases(list, key, direction) {
  const sorted = [...list];
  sorted.sort((a, b) => {
    let av = a[key];
    let bv = b[key];
    if (key === "createdAt" || key === "purchaseDate") {
      av = av ? new Date(av).getTime() : 0;
      bv = bv ? new Date(bv).getTime() : 0;
    } else if (key === "grandTotal" || key === "outstandingAmount" || key === "vatTotal") {
      av = Number(av || 0);
      bv = Number(bv || 0);
    } else {
      av = (av || "").toString().toLowerCase();
      bv = (bv || "").toString().toLowerCase();
    }
    if (av < bv) return direction === "asc" ? -1 : 1;
    if (av > bv) return direction === "asc" ? 1 : -1;
    return 0;
  });
  return sorted;
}

function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function exportPurchasesToCsv(list) {
  const rows = [
    ["Bill #", "Vendor", "Vendor TRN", "Supplier Invoice #", "Purchase Date", "Source", "Status", "Payment Status", "Subtotal", "VAT", "Total", "Outstanding"],
    ...list.map((p) => [
      p.billNumberDisplay || "Draft",
      p.vendorName,
      p.vendorTrn || "",
      p.supplierInvoiceNumber || "",
      p.purchaseDate ? formatDate(p.purchaseDate) : "",
      p.sourceType === "OCR_UPLOAD" ? "OCR Upload" : "Manual",
      p.status,
      p.paymentStatus,
      p.subtotal,
      p.vatTotal,
      p.grandTotal,
      p.outstandingAmount,
    ]),
  ];
  downloadCsv(`purchases-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
}

// Approvals module data drives this - real values, cross-referenced from
// the already-built api.listApprovalQueue/listApprovalHistory (module:
// "purchases"), not fabricated. Today it will read "Not Required" for every
// row since no Approval Rule is active for purchases.* yet (Purchases isn't
// wired into approvalExecutors.js) - the moment one is turned on in
// Settings, this starts showing real data with zero code change.
const APPROVAL_STATUS_BADGE = {
  PENDING: { label: "Pending Approval", className: "badge-premium" },
  APPROVED: { label: "Approved", className: "badge-success" },
  REJECTED: { label: "Rejected", className: "badge-danger" },
  CANCELLED: { label: "Cancelled", className: "badge-info" },
  NOT_REQUIRED: { label: "Not Required", className: "badge-info" },
};

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

const KPI_ICONS = {
  total: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="20" r="1.4" />
      <circle cx="17" cy="20" r="1.4" />
      <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
    </svg>
  ),
  draft: (
    <svg viewBox="0 0 24 24">
      <path d="M14.5 4.5l5 5L8 21H3v-5z" />
    </svg>
  ),
  recorded: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12.5l2.5 2.5L16 9.5" />
    </svg>
  ),
  inputVat: (
    <svg viewBox="0 0 24 24">
      <path d="M4 6h16M4 12h10M4 18h13" />
      <circle cx="19" cy="12" r="1.6" />
      <circle cx="20" cy="18" r="1.6" />
    </svg>
  ),
  outstanding: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
};

const FilterFunnelIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" style={{ stroke: "currentColor", strokeWidth: 1.8, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" }}>
    <path d="M4 5h16l-6 7.5V19l-4 2v-8.5z" />
  </svg>
);

export default function PurchasesPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("purchases.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [purchases, setPurchases] = useState(null);
  const [error, setError] = useState("");
  const [archivedView, setArchivedView] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkRenderPurchase, setBulkRenderPurchase] = useState(null);
  const bulkRenderRef = useRef(null);
  const bulkRenderResolveRef = useRef(null);
  // entityId -> "PENDING" | "APPROVED" | "REJECTED" | "CANCELLED" - see
  // loadApprovalStatuses(). Empty map (not an error) if the Approvals
  // module can't be reached, e.g. the current role lacks approvals.view.
  const [approvalStatusById, setApprovalStatusById] = useState(() => new Map());

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [paymentStatusFilter, setPaymentStatusFilter] = useState("ALL");
  const [vendorFilter, setVendorFilter] = useState("ALL");
  const [sourceFilter, setSourceFilter] = useState("ALL");
  const [approvalStatusFilter, setApprovalStatusFilter] = useState("ALL");
  const [supplierInvoiceFilter, setSupplierInvoiceFilter] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [moreFiltersOpen, setMoreFiltersOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [attachmentTarget, setAttachmentTarget] = useState(null);
  const attachmentInputRef = useRef(null);
  const [sortKey, setSortKey] = useState("createdAt");
  const [sortDirection, setSortDirection] = useState("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedIds, setSelectedIds] = useState(() => new Set());
  const pageItemsRef = useRef([]);

  useEffect(() => {
    load();
    loadApprovalStatuses();
    setSelectedIds(new Set());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [archivedView]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { purchases } = await api.listPurchases(token, { archived: archivedView });
      setPurchases(purchases);
    } catch (err) {
      setError(err.message);
    }
  }

  // Cross-references the already-built Approvals module (never modified
  // here) instead of adding any new backend endpoint - see the module-level
  // comment above APPROVAL_STATUS_BADGE.
  async function loadApprovalStatuses() {
    try {
      const token = tenantAuth.get();
      const [{ approvalRequests: pending }, { approvalRequests: decided }] = await Promise.all([
        api.listApprovalQueue(token, { module: "purchases" }),
        api.listApprovalHistory(token, { module: "purchases" }),
      ]);
      const map = new Map();
      for (const r of decided) {
        if (r.entityId && !map.has(r.entityId)) map.set(r.entityId, r.status);
      }
      for (const r of pending) {
        if (r.entityId) map.set(r.entityId, "PENDING");
      }
      setApprovalStatusById(map);
    } catch {
      setApprovalStatusById(new Map());
    }
  }

  function approvalStatusFor(id) {
    return approvalStatusById.get(id) || "NOT_REQUIRED";
  }

  function resetToPageOne() {
    setPage(1);
  }

  function toggleSelected(id) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const COLUMN_DEFS = useMemo(
    () => [
      {
        key: "select",
        label: (
          <input
            type="checkbox"
            aria-label="Select all on this page"
            checked={pageItemsRef.current.length > 0 && pageItemsRef.current.every((p) => selectedIds.has(p.id))}
            onChange={(e) => {
              setSelectedIds((prev) => {
                const next = new Set(prev);
                pageItemsRef.current.forEach((p) => (e.target.checked ? next.add(p.id) : next.delete(p.id)));
                return next;
              });
            }}
          />
        ),
        alwaysVisible: true,
        render: (p) => <input type="checkbox" aria-label={`Select ${p.billNumberDisplay || "draft"}`} checked={selectedIds.has(p.id)} onChange={() => toggleSelected(p.id)} />,
      },
      {
        key: "billNumberDisplay",
        label: "Bill #",
        alwaysVisible: true,
        sortable: true,
        render: (p) => (
          <div>
            <div className="mono" style={{ fontWeight: 600 }}>
              {p.billNumberDisplay || "Draft"}
            </div>
            {p.status === "VOID" && <div style={{ fontSize: 12, color: "var(--color-ink-faint)", marginTop: 2 }}>Cancelled</div>}
          </div>
        ),
      },
      {
        key: "vendorName",
        label: "Vendor",
        alwaysVisible: true,
        sortable: true,
        render: (p) => (
          <div>
            <div>{p.vendorName}</div>
            {p.vendorTrn && (
              <div className="mono" style={{ fontSize: 12, color: "var(--color-ink-faint)", marginTop: 2 }}>
                {p.vendorTrn}
              </div>
            )}
          </div>
        ),
      },
      { key: "supplierInvoiceNumber", label: "Supplier Invoice #", render: (p) => (p.supplierInvoiceNumber ? <span className="mono">{p.supplierInvoiceNumber}</span> : "—") },
      { key: "purchaseDate", label: "Purchase Date", sortable: true, render: (p) => formatDate(p.purchaseDate) },
      { key: "sourceType", label: "Source", render: (p) => <SourceBadge sourceType={p.sourceType} /> },
      {
        key: "approvalStatus",
        label: "Approval Status",
        render: (p) => {
          const badge = APPROVAL_STATUS_BADGE[approvalStatusFor(p.id)] || APPROVAL_STATUS_BADGE.NOT_REQUIRED;
          return <span className={`badge ${badge.className}`}>{badge.label}</span>;
        },
      },
      { key: "paymentStatus", label: "Payment Status", sortable: true, render: (p) => <PaymentStatusChip purchase={p} /> },
      { key: "grandTotal", label: "Total", sortable: true, align: "right", render: (p) => formatCurrency(p.grandTotal) },
      { key: "vatTotal", label: "Input VAT", sortable: true, align: "right", render: (p) => formatCurrency(p.vatTotal) },
      { key: "outstandingAmount", label: "Outstanding", sortable: true, align: "right", render: (p) => formatCurrency(p.outstandingAmount) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (p) => (
          <ActionMenu
            ariaLabel={`Actions for ${p.billNumberDisplay || "draft purchase bill"}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/purchases/${p.id}`) },
              {
                label: "Edit",
                onClick: () => router.push(`/tenant/purchases/${p.id}`),
                disabled: p.status !== "DRAFT",
                disabledReason: "Only Draft purchase bills can be edited.",
              },
              { label: "Upload Attachment", onClick: () => openAttachmentPicker(p), disabled: bulkBusy },
              {
                label: "Mark Paid",
                onClick: () => handleMarkPaidSingle(p),
                disabled: bulkBusy || p.status !== "RECORDED" || p.outstandingAmount <= 0,
                disabledReason: p.status !== "RECORDED" ? "Only Recorded bills can be marked paid." : "This bill has no outstanding balance.",
              },
              { label: "Duplicate", onClick: () => handleDuplicateSingle(p), disabled: bulkBusy },
              { label: archivedView ? "Restore" : "Archive", onClick: () => handleArchiveRestoreSingle(p), disabled: bulkBusy },
              {
                label: "Delete",
                danger: true,
                onClick: () => setDeleteTarget(p),
                disabled: p.status !== "DRAFT",
                disabledReason: "Only Draft purchase bills can be deleted.",
              },
              { label: "Export PDF", onClick: () => downloadPurchasePdf(p), disabled: bulkBusy },
              { label: "Audit History", onClick: () => router.push(`/tenant/purchases/${p.id}`) },
            ]}
          />
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedIds, archivedView, bulkBusy, approvalStatusById]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_purchase_list_column_order_v2", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_purchase_list_hidden_columns_v2", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const vendors = useMemo(() => {
    if (!purchases) return [];
    return Array.from(new Set(purchases.map((p) => p.vendorName))).sort();
  }, [purchases]);

  const stats = useMemo(() => {
    if (!purchases) return null;
    const recorded = purchases.filter((p) => p.status === "RECORDED");
    return {
      total: purchases.length,
      draft: purchases.filter((p) => p.status === "DRAFT").length,
      recorded: recorded.length,
      inputVat: recorded.reduce((sum, p) => sum + (p.vatTotal || 0), 0),
      outstanding: recorded.reduce((sum, p) => sum + (p.outstandingAmount || 0), 0),
    };
  }, [purchases]);

  const filtered = useMemo(() => {
    if (!purchases) return [];
    const q = search.trim().toLowerCase();
    let list = purchases.filter((p) => {
      const matchesSearch =
        !q ||
        (p.billNumberDisplay || "").toLowerCase().includes(q) ||
        p.vendorName.toLowerCase().includes(q) ||
        (p.supplierInvoiceNumber || "").toLowerCase().includes(q) ||
        (p.vendorTrn || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || p.status === statusFilter;
      const matchesPaymentStatus = paymentStatusFilter === "ALL" || p.paymentStatus === paymentStatusFilter;
      const matchesVendor = vendorFilter === "ALL" || p.vendorName === vendorFilter;
      const matchesSource = sourceFilter === "ALL" || p.sourceType === sourceFilter;
      const matchesApprovalStatus = approvalStatusFilter === "ALL" || approvalStatusFor(p.id) === approvalStatusFilter;
      const matchesSupplierInvoice =
        !supplierInvoiceFilter.trim() || (p.supplierInvoiceNumber || "").toLowerCase().includes(supplierInvoiceFilter.trim().toLowerCase());
      const purchaseTime = p.purchaseDate ? new Date(p.purchaseDate).getTime() : null;
      const matchesFrom = !dateFrom || (purchaseTime !== null && purchaseTime >= new Date(dateFrom).getTime());
      const matchesTo = !dateTo || (purchaseTime !== null && purchaseTime <= new Date(dateTo).getTime() + 86399999);
      return (
        matchesSearch &&
        matchesStatus &&
        matchesPaymentStatus &&
        matchesVendor &&
        matchesSource &&
        matchesApprovalStatus &&
        matchesSupplierInvoice &&
        matchesFrom &&
        matchesTo
      );
    });
    return sortPurchases(list, sortKey, sortDirection);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [purchases, search, statusFilter, paymentStatusFilter, vendorFilter, sourceFilter, approvalStatusFilter, supplierInvoiceFilter, dateFrom, dateTo, sortKey, sortDirection, approvalStatusById]);

  function handleSortChange(key) {
    if (sortKey === key) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDirection("asc");
    }
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);
  pageItemsRef.current = pageItems;

  const selectedPurchases = useMemo(() => purchases?.filter((p) => selectedIds.has(p.id)) || [], [purchases, selectedIds]);

  // Off-screen render, one bill at a time, using the exact same
  // purchase-templates + jsPDF pipeline as the Viewer page.
  function renderPurchaseOffscreen(purchase) {
    return new Promise((resolve) => {
      bulkRenderResolveRef.current = resolve;
      setBulkRenderPurchase(purchase);
    });
  }
  useEffect(() => {
    if (!bulkRenderPurchase) return;
    const t = setTimeout(() => bulkRenderResolveRef.current?.(), 150);
    return () => clearTimeout(t);
  }, [bulkRenderPurchase]);

  async function downloadOnePurchasePdf(jsPDFCtor, token, summary, activityNote) {
    const { purchase } = await api.getPurchase(token, summary.id);
    await renderPurchaseOffscreen(purchase);
    const doc = new jsPDFCtor({ orientation: "p", unit: "mm", format: "a4" });
    await doc.html(bulkRenderRef.current, { x: 0, y: 0, width: 210, windowWidth: bulkRenderRef.current.offsetWidth, autoPaging: "text" });
    doc.save(`${purchase.billNumberDisplay || "Draft-Purchase"}.pdf`);
    api.logPurchaseActivity(token, purchase.id, "DOWNLOADED", activityNote).catch(() => {});
  }

  async function downloadPurchasePdf(purchase) {
    setBulkBusy(true);
    try {
      const { jsPDF } = await import("jspdf");
      const token = tenantAuth.get();
      await downloadOnePurchasePdf(jsPDF, token, purchase, "PDF");
      showToast(`Downloaded ${purchase.billNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkRenderPurchase(null);
      setBulkBusy(false);
    }
  }

  async function handleBulkDownloadPdf() {
    setBulkBusy(true);
    try {
      const { jsPDF } = await import("jspdf");
      const token = tenantAuth.get();
      for (const summary of selectedPurchases) {
        await downloadOnePurchasePdf(jsPDF, token, summary, "PDF (bulk)");
      }
      showToast(`Downloaded ${selectedPurchases.length} purchase bill PDF(s).`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkRenderPurchase(null);
      setBulkBusy(false);
    }
  }

  async function handleBulkArchiveOrRestore() {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      for (const p of selectedPurchases) {
        if (archivedView) await api.restorePurchase(token, p.id);
        else await api.archivePurchase(token, p.id);
      }
      showToast(archivedView ? `Restored ${selectedPurchases.length} purchase bill(s).` : `Archived ${selectedPurchases.length} purchase bill(s).`);
      setSelectedIds(new Set());
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleBulkMarkPaid() {
    const payable = selectedPurchases.filter((p) => p.status === "RECORDED" && p.outstandingAmount > 0);
    if (payable.length === 0) {
      showToast("No Recorded bills with an outstanding balance selected.");
      return;
    }
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      const today = new Date().toISOString().slice(0, 10);
      for (const p of payable) {
        await api.recordPurchasePayment(token, p.id, {
          amount: p.outstandingAmount,
          paymentDate: today,
          method: "OTHER",
          reference: null,
          notes: "Bulk marked as paid",
        });
      }
      showToast(`Marked ${payable.length} purchase bill(s) as paid.`);
      setSelectedIds(new Set());
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  function handleBulkExport() {
    exportPurchasesToCsv(selectedPurchases);
  }

  function handleHeaderExport() {
    exportPurchasesToCsv(selectedIds.size > 0 ? selectedPurchases : filtered);
  }

  async function handleDuplicateSingle(purchase) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      await api.duplicatePurchase(token, purchase.id);
      showToast("Duplicated as a new Draft.");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleArchiveRestoreSingle(purchase) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      if (archivedView) await api.restorePurchase(token, purchase.id);
      else await api.archivePurchase(token, purchase.id);
      showToast(archivedView ? "Purchase bill restored." : "Purchase bill archived.");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleMarkPaidSingle(purchase) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      const today = new Date().toISOString().slice(0, 10);
      await api.recordPurchasePayment(token, purchase.id, {
        amount: purchase.outstandingAmount,
        paymentDate: today,
        method: "OTHER",
        reference: null,
        notes: "Marked as paid from the Purchases list",
      });
      showToast(`${purchase.billNumberDisplay} marked paid.`);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  function openAttachmentPicker(purchase) {
    setAttachmentTarget(purchase);
    attachmentInputRef.current?.click();
  }

  async function handleAttachmentSelected(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !attachmentTarget) return;
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      await api.addPurchaseAttachment(token, attachmentTarget.id, file);
      showToast(`Attached ${file.name} to ${attachmentTarget.billNumberDisplay || "the draft"}.`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setAttachmentTarget(null);
      setBulkBusy(false);
    }
  }

  async function handleConfirmDelete() {
    if (!deleteTarget) return;
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deletePurchase(token, deleteTarget.id);
      showToast(`${deleteTarget.billNumberDisplay || "Draft"} deleted.`);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  function handleClearAdvancedFilters() {
    setPaymentStatusFilter("ALL");
    setSourceFilter("ALL");
    setApprovalStatusFilter("ALL");
    setSupplierInvoiceFilter("");
    resetToPageOne();
  }

  if (permLoading || !allowed) return null;

  const Template = getPurchaseTemplateComponent(DEFAULT_PURCHASE_TEMPLATE);

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Purchases" }]}
        title="Purchases"
        description={archivedView ? "Archived purchase bills — restore anytime, nothing here is ever permanently deleted." : "Every supplier invoice you've uploaded or entered, in one place."}
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {purchases && purchases.length > 0 && (
              <Button variant="outline" onClick={handleHeaderExport}>
                Export
              </Button>
            )}
            {!archivedView && (
              <>
                <Link href="/tenant/purchases/new">
                  <Button variant="outline">Enter Manually</Button>
                </Link>
                {can("purchases.import") && (
                  <Link href="/tenant/imports/new?type=PURCHASE_BILL">
                    <Button variant="outline">Import</Button>
                  </Link>
                )}
                <Link href="/tenant/purchases/upload">
                  <Button>+ Upload Supplier Invoice</Button>
                </Link>
              </>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      {stats && !archivedView && (
        <div className="kpi-card-grid">
          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "ALL" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("ALL");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Purchases</span>
              <span className="kpi-card-icon">{KPI_ICONS.total}</span>
            </div>
            <span className="kpi-card-value">{stats.total}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Every purchase bill, any status
            </span>
          </button>

          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "DRAFT" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("DRAFT");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Draft</span>
              <span className="kpi-card-icon">{KPI_ICONS.draft}</span>
            </div>
            <span className="kpi-card-value">{stats.draft}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Not yet recorded
            </span>
          </button>

          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "RECORDED" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("RECORDED");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Recorded</span>
              <span className="kpi-card-icon">{KPI_ICONS.recorded}</span>
            </div>
            <span className="kpi-card-value">{stats.recorded}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Posted to your books
            </span>
          </button>

          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Input VAT</span>
              <span className="kpi-card-icon">{KPI_ICONS.inputVat}</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(stats.inputVat)}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Recoverable, Recorded bills
            </span>
          </div>

          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Outstanding Amount</span>
              <span className="kpi-card-icon">{KPI_ICONS.outstanding}</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(stats.outstanding)}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Across all Recorded bills
            </span>
          </div>
        </div>
      )}

      {selectedIds.size > 0 && (
        <div className="invoice-bulk-toolbar">
          <span>{selectedIds.size} selected</span>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Button variant="outline" onClick={handleBulkDownloadPdf} disabled={bulkBusy}>
              Download PDF
            </Button>
            {!archivedView && (
              <Button variant="outline" onClick={handleBulkMarkPaid} disabled={bulkBusy}>
                Mark Paid
              </Button>
            )}
            <Button variant="outline" onClick={handleBulkExport} disabled={bulkBusy}>
              Export CSV
            </Button>
            <Button variant="outline" onClick={handleBulkArchiveOrRestore} disabled={bulkBusy}>
              {archivedView ? "Restore" : "Archive"}
            </Button>
          </div>
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        {purchases === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={7} />
          </div>
        ) : purchases.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <circle cx="9" cy="20" r="1.4" />
                <circle cx="17" cy="20" r="1.4" />
                <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
              </svg>
            }
            title={archivedView ? "No archived purchase bills" : "No purchase bills yet"}
            description={archivedView ? "Purchase bills you archive will show up here." : "Upload a supplier invoice to get started — OCR will extract the details for you to review."}
            action={
              !archivedView && (
                <Link href="/tenant/purchases/upload">
                  <Button>+ Upload Supplier Invoice</Button>
                </Link>
              )
            }
          />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search purchase bills…"
                filters={
                  <>
                    <select
                      className="select-filter"
                      value={statusFilter}
                      onChange={(e) => {
                        setStatusFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All statuses</option>
                      <option value="DRAFT">Draft</option>
                      <option value="RECORDED">Recorded</option>
                      <option value="VOID">Cancelled</option>
                    </select>
                    <select
                      className="select-filter"
                      value={vendorFilter}
                      onChange={(e) => {
                        setVendorFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All vendors</option>
                      {vendors.map((v) => (
                        <option key={v} value={v}>
                          {v}
                        </option>
                      ))}
                    </select>
                    <input
                      type="date"
                      className="select-filter"
                      value={dateFrom}
                      onChange={(e) => {
                        setDateFrom(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Purchase date from"
                    />
                    <input
                      type="date"
                      className="select-filter"
                      value={dateTo}
                      onChange={(e) => {
                        setDateTo(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Purchase date to"
                    />
                    <Button variant="outline" onClick={() => setMoreFiltersOpen(true)}>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <FilterFunnelIcon />
                        More Filters
                      </span>
                    </Button>
                    <ColumnSelector
                      columns={COLUMN_DEFS}
                      columnOrder={columnOrder}
                      hiddenColumns={hiddenColumns}
                      onToggle={handleToggleColumn}
                      onReorder={setColumnOrder}
                    />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching purchase bills"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable
                    columns={COLUMN_DEFS}
                    rows={pageItems}
                    columnOrder={columnOrder}
                    hiddenColumns={hiddenColumns}
                    sortKey={sortKey}
                    sortDirection={sortDirection}
                    onSortChange={handleSortChange}
                    stickyHeader
                    zebra
                  />
                </TableScroll>
                <div className="table-pagination">
                  <span>
                    Showing {pageStart + 1}–{Math.min(pageStart + pageSize, filtered.length)} of {filtered.length} purchase bills
                  </span>
                  <div className="pagination-controls">
                    <div className="rows-per-page">
                      Rows per page
                      <select
                        className="select-filter"
                        value={pageSize}
                        onChange={(e) => {
                          setPageSize(Number(e.target.value));
                          resetToPageOne();
                        }}
                      >
                        {PAGE_SIZE_OPTIONS.map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="pagination-pages">
                      <button className="page-btn" disabled={currentPage === 1} onClick={() => setPage(1)} aria-label="First page">
                        «
                      </button>
                      <button className="page-btn" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)} aria-label="Previous page">
                        ‹
                      </button>
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <button key={i} className={`page-btn${currentPage === i + 1 ? " active" : ""}`} onClick={() => setPage(i + 1)}>
                          {i + 1}
                        </button>
                      ))}
                      <button className="page-btn" disabled={currentPage === totalPages} onClick={() => setPage(currentPage + 1)} aria-label="Next page">
                        ›
                      </button>
                      <button className="page-btn" disabled={currentPage === totalPages} onClick={() => setPage(totalPages)} aria-label="Last page">
                        »
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>

      <PurchaseMoreFiltersDrawer
        open={moreFiltersOpen}
        onClose={() => setMoreFiltersOpen(false)}
        paymentStatusFilter={paymentStatusFilter}
        onPaymentStatusChange={(v) => {
          setPaymentStatusFilter(v);
          resetToPageOne();
        }}
        sourceFilter={sourceFilter}
        onSourceChange={(v) => {
          setSourceFilter(v);
          resetToPageOne();
        }}
        approvalStatusFilter={approvalStatusFilter}
        onApprovalStatusChange={(v) => {
          setApprovalStatusFilter(v);
          resetToPageOne();
        }}
        supplierInvoiceFilter={supplierInvoiceFilter}
        onSupplierInvoiceFilterChange={(v) => {
          setSupplierInvoiceFilter(v);
          resetToPageOne();
        }}
        archivedView={archivedView}
        onToggleArchived={(checked) => setArchivedView(checked)}
        onClearAll={handleClearAdvancedFilters}
      />

      <ConfirmationDialog
        open={!!deleteTarget}
        title="Delete this draft?"
        message={`"${deleteTarget?.billNumberDisplay || "This draft"}" has never been recorded, so no bill number has been consumed. This can't be undone.`}
        confirmLabel="Delete"
        variant="danger"
        busy={bulkBusy}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <input ref={attachmentInputRef} type="file" style={{ display: "none" }} onChange={handleAttachmentSelected} />

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        {bulkRenderPurchase && <Template purchase={bulkRenderPurchase} ref={bulkRenderRef} />}
      </div>
    </div>
  );
}
