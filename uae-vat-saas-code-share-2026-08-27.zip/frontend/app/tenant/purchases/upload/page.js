"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { calculateInvoiceTotals } from "../../../../lib/invoiceCalc";
import PageHeader from "../../../../components/ui/PageHeader";
import Card from "../../../../components/ui/Card";
import Field from "../../../../components/ui/Field";
import Input from "../../../../components/ui/Input";
import Button from "../../../../components/ui/Button";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import OcrUploadDropzone from "../../../../components/purchases/OcrUploadDropzone";
import OcrConfidenceBadge from "../../../../components/purchases/OcrConfidenceBadge";
import PurchaseLineItemsTable from "../../../../components/purchases/PurchaseLineItemsTable";
import PurchaseSummarySidebar from "../../../../components/purchases/PurchaseSummarySidebar";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

const PROCESSING_STAGES = [
  "Uploading document…",
  "Reading text from document…",
  "Extracting vendor & line items…",
  "Calculating confidence…",
];

function newLineKey() {
  return `line-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function todayInputValue() {
  return new Date().toISOString().slice(0, 10);
}

// The primary Purchase entry point (per the AI-first Purchase Module scope):
// Upload -> OCR Extraction -> Review & Correct -> Save. Manual entry
// (app/tenant/purchases/new) remains available as the alternative path.
//
// OCR itself is a placeholder (see backend src/services/ocrService.js) -
// this page's job is the upload/processing/review UX around whatever that
// service returns, built so a real provider swaps in without any change here.
export default function PurchaseOcrUploadPage() {
  const router = useRouter();
  const [step, setStep] = useState("upload"); // upload | processing | review
  const [selectedFile, setSelectedFile] = useState(null);
  const [processingStage, setProcessingStage] = useState(0);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const [taxCategories, setTaxCategories] = useState([]);
  const [extraction, setExtraction] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);

  const [vendorName, setVendorName] = useState("");
  const [vendorTrn, setVendorTrn] = useState("");
  const [supplierInvoiceNumber, setSupplierInvoiceNumber] = useState("");
  const [invoiceDate, setInvoiceDate] = useState("");
  const [purchaseDate, setPurchaseDate] = useState(todayInputValue());
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState([]);
  const [vendorConfidence, setVendorConfidence] = useState(null);
  const [invoiceNumberConfidence, setInvoiceNumberConfidence] = useState(null);
  const [invoiceDateConfidence, setInvoiceDateConfidence] = useState(null);

  const stageTimerRef = useRef(null);

  useEffect(() => {
    return () => clearInterval(stageTimerRef.current);
  }, []);

  function categoryFor(id) {
    return taxCategories.find((c) => c.id === id);
  }

  const totals = calculateInvoiceTotals(
    lines.map((l) => {
      const cat = categoryFor(l.taxCategoryId);
      return {
        quantity: l.quantity,
        unitPrice: l.unitPrice,
        taxPercentage: cat?.taxRate?.percentage || 0,
        taxCalculationMethod: cat?.taxRate?.calculationMethod || "EXCLUSIVE",
      };
    }),
    {}
  );

  async function handleExtract() {
    if (!selectedFile) return;
    setError("");
    setStep("processing");
    setProcessingStage(0);

    stageTimerRef.current = setInterval(() => {
      setProcessingStage((s) => Math.min(s + 1, PROCESSING_STAGES.length - 1));
    }, 550);

    try {
      const token = tenantAuth.get();
      const [{ categories }, extractResult] = await Promise.all([
        api.listTaxCategories(token),
        api.extractPurchaseOcr(token, selectedFile),
        new Promise((resolve) => setTimeout(resolve, PROCESSING_STAGES.length * 550)), // let the stage animation play out
      ]);
      clearInterval(stageTimerRef.current);
      setTaxCategories(categories.filter((c) => c.status === "ACTIVE"));

      const { extraction, file } = extractResult;
      setExtraction(extraction);
      setUploadedFile(file);
      setVendorName(extraction.vendor.name);
      setVendorTrn(extraction.vendor.trn || "");
      setVendorConfidence(extraction.vendor.confidence);
      setSupplierInvoiceNumber(extraction.supplierInvoiceNumber.value);
      setInvoiceNumberConfidence(extraction.supplierInvoiceNumber.confidence);
      setInvoiceDate(extraction.invoiceDate.value);
      setInvoiceDateConfidence(extraction.invoiceDate.confidence);
      setLines(
        extraction.lineItems.map((li) => ({
          key: newLineKey(),
          description: li.description,
          quantity: String(li.quantity),
          unitPrice: String(li.unitPrice),
          taxCategoryId: "",
          confidence: li.confidence,
        }))
      );
      setStep("review");
    } catch (err) {
      clearInterval(stageTimerRef.current);
      setError(err.message);
      setStep("upload");
    }
  }

  function handleChangeLine(index, patch) {
    setLines((prev) => prev.map((l, i) => (i === index ? { ...l, ...patch } : l)));
  }
  function handleAddLine() {
    setLines((prev) => [...prev, { key: newLineKey(), description: "", quantity: "1", unitPrice: "0", taxCategoryId: "", confidence: null }]);
  }
  function handleRemoveLine(index) {
    setLines((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleConfirm() {
    if (!vendorName.trim()) {
      setError("Vendor name is required.");
      return;
    }
    if (lines.length === 0) {
      setError("Add at least one line item.");
      return;
    }
    setError("");
    setSaving(true);
    try {
      const token = tenantAuth.get();
      const { purchase } = await api.confirmPurchaseOcr(token, {
        vendorName: vendorName.trim(),
        vendorTrn: vendorTrn || null,
        supplierInvoiceNumber: supplierInvoiceNumber || null,
        invoiceDate: invoiceDate || null,
        purchaseDate: purchaseDate || null,
        notes: notes || null,
        lineItems: lines.map((l) => ({
          description: l.description.trim(),
          quantity: Number(l.quantity),
          unitPrice: Number(l.unitPrice),
          taxCategoryId: l.taxCategoryId || null,
        })),
        overallConfidence: extraction.overallConfidence,
        rawExtraction: extraction,
        file: uploadedFile,
      });
      router.push(`/tenant/purchases/${purchase.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Purchases", href: "/tenant/purchases" }, { label: "Upload Supplier Invoice" }]}
        title="Upload Supplier Invoice"
        description="Upload a PDF or photo of a supplier invoice — Ledger extracts the details for you to review before anything is saved."
      />

      <ErrorBanner message={error} />

      {step === "upload" && (
        <Card>
          <OcrUploadDropzone onFileSelected={setSelectedFile} />
          <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
            <Button variant="outline" onClick={() => router.push("/tenant/purchases/new")}>
              Enter Manually Instead
            </Button>
            <Button onClick={handleExtract} disabled={!selectedFile}>
              Upload &amp; Extract
            </Button>
          </div>
        </Card>
      )}

      {step === "processing" && (
        <Card>
          <div className="ocr-processing">
            <div className="ocr-processing-spinner" aria-hidden="true" />
            <strong>{PROCESSING_STAGES[processingStage]}</strong>
            <div className="ocr-progress-track">
              <div className="ocr-progress-fill" style={{ width: `${((processingStage + 1) / PROCESSING_STAGES.length) * 100}%` }} />
            </div>
            <span className="helptext">This is simulated for the placeholder OCR service — a real provider plugs in without changing this screen.</span>
          </div>
        </Card>
      )}

      {step === "review" && extraction && (
        <div className="detail-layout">
          <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3 style={{ margin: 0 }}>Review Extracted Data</h3>
                <OcrConfidenceBadge confidence={extraction.overallConfidence} />
              </div>
              <p className="helptext" style={{ marginTop: 4 }}>Correct anything the extraction got wrong before saving — nothing is recorded until you confirm.</p>
            </Card>

            {uploadedFile && (
              <Card>
                <h3 style={{ marginTop: 0 }}>Source Document</h3>
                {uploadedFile.mimeType.startsWith("image/") ? (
                  <img src={`${API_URL}${uploadedFile.fileUrl}`} alt="Uploaded supplier invoice" className="ocr-source-preview" />
                ) : (
                  <a href={`${API_URL}${uploadedFile.fileUrl}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline btn-sm">
                    View Uploaded PDF
                  </a>
                )}
              </Card>
            )}

            <Card>
              <h3 style={{ marginTop: 0 }}>Vendor</h3>
              <div className="form-grid">
                <Field id="ocr-vendor-name" label={<>Vendor Name<span className="required-asterisk">*</span></>}>
                  <Input value={vendorName} onChange={(e) => setVendorName(e.target.value)} />
                </Field>
                <Field id="ocr-vendor-trn" label="Vendor TRN">
                  <Input value={vendorTrn} onChange={(e) => setVendorTrn(e.target.value)} />
                </Field>
              </div>
              <OcrConfidenceBadge confidence={vendorConfidence} />
            </Card>

            <Card>
              <h3 style={{ marginTop: 0 }}>Bill Details</h3>
              <div className="form-grid">
                <Field id="ocr-supplier-invoice-number" label="Supplier Invoice #">
                  <Input value={supplierInvoiceNumber} onChange={(e) => setSupplierInvoiceNumber(e.target.value)} />
                </Field>
                <Field id="ocr-invoice-date" label="Invoice Date">
                  <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
                </Field>
                <Field id="ocr-purchase-date" label="Purchase Date">
                  <Input type="date" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} />
                </Field>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <OcrConfidenceBadge confidence={invoiceNumberConfidence} />
                <OcrConfidenceBadge confidence={invoiceDateConfidence} />
              </div>
              <Field id="ocr-notes" label="Notes" style={{ marginBottom: 0, marginTop: 12 }}>
                <textarea className="inline-input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
              </Field>
            </Card>

            <Card>
              <h3 style={{ marginTop: 0 }}>Line Items</h3>
              <PurchaseLineItemsTable
                lines={lines}
                computedLines={totals.lines}
                taxCategories={taxCategories}
                onChangeLine={handleChangeLine}
                onAddLine={handleAddLine}
                onRemoveLine={handleRemoveLine}
                showConfidence
              />
            </Card>
          </div>

          <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
            <PurchaseSummarySidebar totals={totals} />
            <div style={{ display: "flex", gap: 8 }}>
              <Button variant="outline" onClick={() => setStep("upload")} disabled={saving}>
                Start Over
              </Button>
              <Button onClick={handleConfirm} disabled={saving}>
                {saving ? "Saving…" : "Confirm & Save"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
