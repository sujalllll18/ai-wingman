"use client";

import { useEffect, useState } from "react";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import Card from "../../../components/ui/Card";
import Button from "../../../components/ui/Button";
import EmptyState from "../../../components/ui/EmptyState";
import PlaceholderNotice from "../../../components/ui/PlaceholderNotice";
import StaticField from "../../../components/tenant-profile/StaticField";
import ProfileCompletionCard from "../../../components/tenant-profile/ProfileCompletionCard";
import BusinessProfileEditModal from "../../../components/tenant-profile/BusinessProfileEditModal";
import BrandAssetCard from "../../../components/tenant-profile/BrandAssetCard";
import InvoicePreviewModal from "../../../components/tenant-profile/InvoicePreviewModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";
import { useBranding } from "../../../hooks/useBranding";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
// Backend returns a relative /uploads/... path (see businessProfile.controller.js) -
// same "prefix with the API origin" pattern already used for the Import
// batch detail page's original-file link.
function assetUrl(path) {
  return path ? `${API_URL}${path}` : null;
}

const ASSET_MAX_BYTES = { logo: 2 * 1024 * 1024, stamp: 2 * 1024 * 1024, signature: 1 * 1024 * 1024 };

// Tenant-only page. Real Business Profile GET/PATCH + brand asset upload/
// remove (2026-08-09) - previously this page hardcoded every field to null
// and the Edit modal/Brand Asset cards were session-only placeholders (see
// BusinessProfileEditModal.js/BrandAssetCard.js for the backend routes now
// backing them). Still deliberately does NOT reuse
// components/tenant-profile/BusinessTab.js/BusinessEditDrawer.js - those
// stay shared with the Platform Admin's own Tenant Detail "Business" tab,
// which has a separate, legitimate edit-sensitive-fields-with-a-reason flow
// a tenant user must never see or trigger.
export default function BusinessProfilePage() {
  const { allowed, loading: permLoading } = useRequirePermission("business_profile.view");
  const { can } = usePermissions();
  const { refresh: refreshBranding } = useBranding();
  const { showToast } = useToast();
  const [error, setError] = useState("");
  const [editOpen, setEditOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [profile, setProfile] = useState(null); // null = loading
  const session = typeof window !== "undefined" ? tenantAuth.getSession() : null;

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { businessProfile } = await api.getBusinessProfile(token);
      setProfile(businessProfile);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAssetUpload(assetType, file) {
    const token = tenantAuth.get();
    const { businessProfile } = await api.uploadBusinessAsset(token, assetType, file);
    setProfile(businessProfile);
    if (assetType === "logo") refreshBranding();
    showToast(`${assetType[0].toUpperCase()}${assetType.slice(1)} updated.`);
  }

  async function handleAssetRemove(assetType) {
    const token = tenantAuth.get();
    const { businessProfile } = await api.removeBusinessAsset(token, assetType);
    setProfile(businessProfile);
    if (assetType === "logo") refreshBranding();
    showToast(`${assetType[0].toUpperCase()}${assetType.slice(1)} removed.`);
  }

  // tenant shape kept identical to what InvoicePreviewModal/StaticField
  // already expect, now sourced from the real fetch instead of hardcoded
  // nulls - name/plan still come from the session (unchanged), everything
  // else from the new endpoint.
  const tenant = {
    id: session?.tenant?.id || null,
    name: session?.tenant?.name || "",
    plan: session?.tenant?.plan || null,
    trn: profile?.trn ?? null,
    address: profile?.address ?? null,
    contactEmail: profile?.contactEmail ?? null,
    contactPhone: profile?.contactPhone ?? null,
    logoUrl: assetUrl(profile?.logoUrl),
    stampUrl: assetUrl(profile?.stampUrl),
    signatureUrl: assetUrl(profile?.signatureUrl),
  };

  if (permLoading || !allowed) return null;

  const canEdit = can("business_profile.edit_contact_details");
  const canEditBranding = can("business_profile.edit_branding") || can("business_profile.upload_logo");

  return (
    <div>
      <PageHeader
        eyebrow={session?.tenant?.name || "Your business"}
        title="Business Profile"
        description="Manage your company information used across invoices, VAT returns and business documents."
      />

      <ErrorBanner message={error} />

      <div className="content-wide">
        <div className="bp-summary-grid">
          <ProfileCompletionCard tenant={tenant} logoUploaded={!!tenant.logoUrl} />

          <Card>
            <h2 style={{ marginBottom: 4 }}>Invoice Preview</h2>
            <p className="form-section-desc">See how your business information appears on invoices.</p>
            <Button variant="outline" onClick={() => setPreviewOpen(true)} style={{ marginTop: "auto" }}>
              Preview Sample Invoice
            </Button>
          </Card>
        </div>

        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <h2 style={{ marginBottom: 4 }}>Business Information</h2>
              <p className="form-section-desc">Your legal identity, compliance, and contact details.</p>
            </div>
            {canEdit && (
              <Button variant="outline" onClick={() => setEditOpen(true)}>
                Edit
              </Button>
            )}
          </div>

          <div style={{ marginTop: 12 }}>
            <PlaceholderNotice>
              Legal identity fields (name, TRN, trade license, location) are compliance-sensitive and managed
              during onboarding. Contact details below can be updated from Edit above.
            </PlaceholderNotice>
          </div>

          <div className="bp-field-grid" style={{ marginTop: 16 }}>
            <StaticField label="Business Legal Name" value={tenant.name} locked />
            <StaticField label="Trade License Number" locked />
            <StaticField label="Legal Entity Type" locked />
            <StaticField label="TRN" value={tenant.trn ? <span className="mono">{tenant.trn}</span> : null} locked />
            <StaticField label="Country" value="United Arab Emirates" locked />
            <StaticField label="Emirate" locked />
            <StaticField label="Contact Email" value={tenant.contactEmail} tooltip="Not set yet — add it from Edit above." />
            <StaticField label="Contact Number" value={tenant.contactPhone} tooltip="Not set yet — add it from Edit above." />
            <StaticField
              label="Business Address"
              value={tenant.address}
              tooltip="Not set yet — add it from Edit above."
              fullWidth
            />
          </div>
        </Card>

        <Card>
          <h2 style={{ marginBottom: 4 }}>Brand Assets</h2>
          <p className="form-section-desc">Used on invoices and official documents.</p>
          {profile === null ? (
            <p className="helptext" style={{ marginTop: 16 }}>
              Loading…
            </p>
          ) : canEditBranding ? (
            <div className="branding-grid" style={{ marginTop: 16 }}>
              <BrandAssetCard
                label="Company Logo"
                recommendedFormats="PNG or SVG, transparent background, up to 2MB"
                maxBytes={ASSET_MAX_BYTES.logo}
                value={tenant.logoUrl}
                onUpload={(file) => handleAssetUpload("logo", file)}
                onRemove={() => handleAssetRemove("logo")}
              />
              <BrandAssetCard
                label="Company Stamp"
                recommendedFormats="PNG, transparent background, up to 2MB"
                maxBytes={ASSET_MAX_BYTES.stamp}
                value={tenant.stampUrl}
                onUpload={(file) => handleAssetUpload("stamp", file)}
                onRemove={() => handleAssetRemove("stamp")}
              />
              <BrandAssetCard
                label="Authorized Signature"
                recommendedFormats="PNG, transparent background, up to 1MB"
                maxBytes={ASSET_MAX_BYTES.signature}
                value={tenant.signatureUrl}
                onUpload={(file) => handleAssetUpload("signature", file)}
                onRemove={() => handleAssetRemove("signature")}
              />
            </div>
          ) : (
            <div className="branding-grid" style={{ marginTop: 16 }}>
              {[
                { label: "Company Logo", url: tenant.logoUrl },
                { label: "Company Stamp", url: tenant.stampUrl },
                { label: "Authorized Signature", url: tenant.signatureUrl },
              ].map((a) => (
                <div className="branding-item" key={a.label}>
                  <span className="branding-label">{a.label}</span>
                  <div className="branding-upload-box">
                    {a.url ? <img src={a.url} alt={`${a.label} preview`} /> : <span className="branding-upload-placeholder">No {a.label.toLowerCase()} uploaded</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <h2 style={{ marginBottom: 4 }}>Business Documents</h2>
          <p className="form-section-desc">Trade license, VAT certificate, and other compliance documents.</p>
          <EmptyState
            title="No documents uploaded yet"
            description="Document storage isn't connected yet — this section will hold your Trade License, VAT Certificate, and other compliance documents. Coming Soon."
          />
        </Card>
      </div>

      <BusinessProfileEditModal open={editOpen} onClose={() => setEditOpen(false)} tenant={tenant} showToast={showToast} onSaved={load} />
      <InvoicePreviewModal open={previewOpen} onClose={() => setPreviewOpen(false)} tenant={tenant} />
    </div>
  );
}
