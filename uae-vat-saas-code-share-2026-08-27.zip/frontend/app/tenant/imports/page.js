"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import ImportStatusBadge, { IMPORT_TYPE_LABEL } from "../../../components/imports/ImportStatusBadge";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function formatPeriod(batch) {
  if (!batch.periodFrom || !batch.periodTo) return "—";
  return `${formatDate(batch.periodFrom)} – ${formatDate(batch.periodTo)}`;
}

export default function ImportsPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.view");
  const router = useRouter();
  const [batches, setBatches] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { batches } = await api.listImportBatches(token);
      setBatches(batches);
    } catch (err) {
      setError(err.message);
    }
  }

  const COLUMNS = [
    { key: "batchNumber", header: "Batch", render: (b) => <span className="mono">{b.batchNumber}</span> },
    { key: "importType", header: "Type", render: (b) => IMPORT_TYPE_LABEL[b.importType] || b.importType },
    { key: "period", header: "Period", render: (b) => formatPeriod(b) },
    { key: "totalRecords", header: "Records", className: "num", render: (b) => b.totalRecords },
    { key: "successCount", header: "Successful", className: "num", render: (b) => b.successCount },
    { key: "failedCount", header: "Failed", className: "num", render: (b) => b.failedCount },
    { key: "status", header: "Status", render: (b) => <ImportStatusBadge status={b.status} /> },
    { key: "importedByName", header: "Imported By", render: (b) => b.importedByName || "—" },
    { key: "createdAt", header: "Imported Date", render: (b) => formatDate(b.createdAt) },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      {/* Central Import Management/History only (2026-08-09) - starting a new
          import is deliberately NOT offered here. Invoices/Purchases each
          already have their own "Import" entry point that deep-links into
          the shared /tenant/imports/new wizard with the correct type
          preset - a second, type-picker entry point here would just be a
          duplicate of that same flow. */}
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Imports" }]}
        title="Imports"
        description="Every import batch you've run, its status, and its errors - start a new import from Invoices or Purchases."
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {batches === null ? (
          <LoadingSkeleton columns={COLUMNS.length} />
        ) : batches.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <path d="M12 3.5v11M7.5 10l4.5 4.5L16.5 10" />
                <path d="M4.5 16.5V19a1.5 1.5 0 0 0 1.5 1.5h12A1.5 1.5 0 0 0 19.5 19v-2.5" />
              </svg>
            }
            title="No imports yet"
            description="Bring in historical Sales Invoices or Purchase Bills from a spreadsheet - use the Import button on the Invoices or Purchases page to get started."
          />
        ) : (
          <TableScroll>
            <Table columns={COLUMNS} rows={batches} onRowClick={(b) => router.push(`/tenant/imports/${b.id}`)} />
          </TableScroll>
        )}
      </div>
    </div>
  );
}
