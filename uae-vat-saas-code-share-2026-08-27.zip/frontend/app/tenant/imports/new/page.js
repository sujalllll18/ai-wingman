"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Card from "../../../../components/ui/Card";
import Field from "../../../../components/ui/Field";
import Input from "../../../../components/ui/Input";
import Select from "../../../../components/ui/Select";
import Button from "../../../../components/ui/Button";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import StepWizard from "../../../../components/ui/StepWizard";
import Tabs from "../../../../components/ui/Tabs";
import ImportUploadDropzone from "../../../../components/imports/ImportUploadDropzone";
import { IMPORT_TYPE_LABEL } from "../../../../components/imports/ImportStatusBadge";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";

const STEPS = ["Select & Upload", "Map Columns", "Validate & Preview", "Import"];

export default function NewImportPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.create");
  const router = useRouter();
  const searchParams = useSearchParams();
  const { showToast } = useToast();

  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [importTypes, setImportTypes] = useState(null);
  const [importType, setImportType] = useState(searchParams.get("type") || "SALES_INVOICE");
  const [periodFrom, setPeriodFrom] = useState("");
  const [periodTo, setPeriodTo] = useState("");
  const [file, setFile] = useState(null);

  const [batch, setBatch] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [mapping, setMapping] = useState({});

  const [previewTab, setPreviewTab] = useState("VALID");
  const [previewRows, setPreviewRows] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const { importTypes } = await api.listImportTypes(token);
        setImportTypes(importTypes);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  const templateFields = importTypes?.find((t) => t.importType === importType)?.templateFields || [];

  async function handleUpload() {
    if (!file) {
      setError("Choose a file to upload first.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { batch, headers, mapping } = await api.createImportBatch(token, { file, importType, periodFrom: periodFrom || undefined, periodTo: periodTo || undefined });
      setBatch(batch);
      setHeaders(headers);
      setMapping(mapping);
      setStep(1);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveMappingAndValidate() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.setImportMapping(token, batch.id, mapping);
      const { batch: validated } = await api.validateImportBatch(token, batch.id);
      setBatch(validated);
      setStep(2);
      await loadPreview("VALID", token, validated.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function loadPreview(status, tokenArg, batchIdArg) {
    const token = tokenArg || tenantAuth.get();
    const { rows } = await api.previewImportBatch(token, batchIdArg || batch.id, { status });
    setPreviewTab(status);
    setPreviewRows(rows);
  }

  async function handleCommit() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const res = await api.commitImportBatch(token, batch.id);
      if (res.approvalRequest) {
        showToast(`Batch ${batch.batchNumber} submitted for approval.`);
      } else {
        showToast(`Batch ${batch.batchNumber} imported — ${res.batch.successCount} record(s) created.`);
      }
      router.push(`/tenant/imports/${batch.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Imports", href: "/tenant/imports" }, { label: "New Import" }]}
        title="New Import"
        description="Upload → Map → Validate → Preview → Import — historical transactions become real Ledger records, dated as they actually happened."
      />

      <ErrorBanner message={error} />

      <div style={{ marginBottom: 20 }}>
        <StepWizard steps={STEPS} currentStep={step} />
      </div>

      {step === 0 && (
        <Card>
          <h3 style={{ marginTop: 0 }}>What are you importing?</h3>
          <div className="form-grid">
            <Field id="importType" label="Import Type">
              <Select id="importType" value={importType} onChange={(e) => setImportType(e.target.value)} disabled={!importTypes}>
                {(importTypes || [{ importType, label: IMPORT_TYPE_LABEL[importType] || importType }]).map((t) => (
                  <option key={t.importType} value={t.importType}>
                    {t.label}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <h3>Historical period (optional)</h3>
          <p className="helptext" style={{ marginTop: -8 }}>
            Purely descriptive — each row's own date (from the file) is what actually determines its VAT period, not this range.
          </p>
          <div className="form-grid">
            <Field id="periodFrom" label="From Date">
              <Input id="periodFrom" type="date" value={periodFrom} onChange={(e) => setPeriodFrom(e.target.value)} />
            </Field>
            <Field id="periodTo" label="To Date">
              <Input id="periodTo" type="date" value={periodTo} onChange={(e) => setPeriodTo(e.target.value)} />
            </Field>
          </div>

          <h3>Upload file</h3>
          <ImportUploadDropzone onFileSelected={setFile} />

          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 20 }}>
            <Button onClick={handleUpload} disabled={busy || !file}>
              {busy ? "Uploading…" : "Upload & Continue"}
            </Button>
          </div>
        </Card>
      )}

      {step === 1 && batch && (
        <Card>
          <h3 style={{ marginTop: 0 }}>Map your columns</h3>
          <p className="helptext" style={{ marginTop: -8 }}>
            Ledger auto-detected the mapping below from your file's headers — review and correct anything that's wrong before validating.
          </p>

          <TableScroll>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Ledger Field</th>
                  <th>Your Column</th>
                </tr>
              </thead>
              <tbody>
                {templateFields.map((f) => (
                  <tr key={f.key}>
                    <td data-label="Ledger Field">
                      {f.label}
                      {f.required && <span className="required-asterisk"> *</span>}
                    </td>
                    <td data-label="Your Column">
                      <Select
                        value={mapping[f.key] || ""}
                        onChange={(e) => setMapping((m) => ({ ...m, [f.key]: e.target.value || null }))}
                      >
                        <option value="">— Not mapped —</option>
                        {headers.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableScroll>

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(0)} disabled={busy}>
              Back
            </Button>
            <Button onClick={handleSaveMappingAndValidate} disabled={busy}>
              {busy ? "Validating…" : "Save Mapping & Validate"}
            </Button>
          </div>
        </Card>
      )}

      {step === 2 && batch && (
        <Card>
          <h3 style={{ marginTop: 0 }}>
            {batch.totalRecords} record{batch.totalRecords === 1 ? "" : "s"} detected — {batch.successCount} Ready to Import, {batch.failedCount} Need Attention
          </h3>

          <Tabs
            tabs={[
              { key: "VALID", label: `Ready (${batch.successCount})` },
              { key: "INVALID", label: `Need Attention (${batch.failedCount})` },
            ]}
            activeKey={previewTab}
            onChange={(key) => loadPreview(key)}
          />

          <div style={{ marginTop: 16 }}>
            {previewRows === null ? (
              <p className="helptext">Loading…</p>
            ) : previewRows.length === 0 ? (
              <p className="helptext">Nothing here.</p>
            ) : (
              <TableScroll>
                <Table
                  columns={[
                    { key: "rowNumber", header: "Row #" },
                    ...(previewTab === "VALID"
                      ? [
                          { key: "summary", header: "Summary", render: (r) => summarizeRow(importType, r.normalized) },
                        ]
                      : [
                          { key: "summary", header: "Summary", render: (r) => summarizeRow(importType, r.normalized) },
                          {
                            key: "errors",
                            header: "Issues",
                            render: (r) => (
                              <span style={{ color: "var(--color-danger)" }}>
                                {r.validationErrors.map((e) => e.message).join("; ")}
                              </span>
                            ),
                          },
                        ]),
                  ]}
                  rows={previewRows}
                  rowKey={(r) => r.id}
                />
              </TableScroll>
            )}
          </div>

          {batch.failedCount > 0 && (
            <div style={{ marginTop: 16 }}>
              <Button variant="outline" onClick={() => api.downloadImportErrorReport(tenantAuth.get(), batch.id)}>
                Download Error Report
              </Button>
              <p className="helptext">Fix the flagged rows in your source file and start a new import for just those rows — Ready rows below can still be imported now.</p>
            </div>
          )}

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(1)} disabled={busy}>
              Back
            </Button>
            <Button onClick={handleCommit} disabled={busy || batch.successCount === 0}>
              {busy ? "Importing…" : `Import ${batch.successCount} Ready Record${batch.successCount === 1 ? "" : "s"}`}
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}

function summarizeRow(importType, normalized) {
  if (!normalized) return "—";
  if (importType === "SALES_INVOICE") {
    return `${normalized.customerName || "—"} · ${normalized.invoiceDate ? new Date(normalized.invoiceDate).toLocaleDateString() : "—"} · ${normalized.taxableAmount ?? "—"}`;
  }
  if (importType === "PURCHASE_BILL") {
    return `${normalized.vendorName || "—"} · ${normalized.purchaseDate ? new Date(normalized.purchaseDate).toLocaleDateString() : "—"} · ${normalized.taxableAmount ?? "—"}`;
  }
  return JSON.stringify(normalized);
}
