"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import Tabs from "../../../../components/ui/Tabs";
import ProfileField from "../../../../components/tenant-profile/ProfileField";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import EmptyState from "../../../../components/ui/EmptyState";
import ImportStatusBadge, { IMPORT_TYPE_LABEL } from "../../../../components/imports/ImportStatusBadge";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import { usePermissions } from "../../../../hooks/usePermissions";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function formatDateOnly(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

const ENTITY_ROUTE = {
  Invoice: (id) => `/tenant/invoices/${id}`,
  PurchaseBill: (id) => `/tenant/purchases/${id}`,
  Payment: (id) => `/tenant/payments/${id}`,
  PurchasePayment: (id) => `/tenant/purchase-payments/${id}`,
  BankTransaction: (id) => `/tenant/banking/transactions/${id}`,
};

// Statuses the migration engine can be actively running in - the detail
// page polls GET /:id every 2s while the batch is in one of these, so the
// progress bar / counters update live without a manual refresh.
const RUNNING_STATUSES = ["QUEUED", "PROCESSING"];
const POLL_INTERVAL_MS = 2000;

export default function ImportBatchDetailPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.view");
  const { can } = usePermissions();
  const { id } = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [batch, setBatch] = useState(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("OVERVIEW");
  const [records, setRecords] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    load();
  }, [id]);

  // Live progress: while the migration engine is actively running this
  // batch, poll for updated counters/status. Cleared as soon as the batch
  // leaves QUEUED/PROCESSING (paused, completed, failed, cancelled) or the
  // component unmounts - never leaves a stray interval running.
  useEffect(() => {
    if (!batch || !RUNNING_STATUSES.includes(batch.status)) return undefined;
    const timer = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [batch?.status, id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { batch } = await api.getImportBatch(token, id);
      setBatch(batch);
    } catch (err) {
      setError(err.message);
    }
  }

  async function loadRecords(status) {
    setRecords(null);
    const token = tenantAuth.get();
    const { records } = await api.getImportRecords(token, id, { status });
    setRecords(records);
  }

  function handleTabChange(key) {
    setTab(key);
    if (key === "IMPORTED") loadRecords("IMPORTED");
    // "Failed" covers both pre-commit (INVALID) and commit-time (FAILED)
    // rows in one list - see importEngine.service.js's getRecords comment.
    if (key === "FAILED") loadRecords("INVALID,FAILED");
  }

  async function handleCommit() {
    setBusy(true);
    setError("");
    try {
      const token = tenantAuth.get();
      const res = await api.commitImportBatch(token, id);
      if (res.approvalRequest) {
        showToast("Submitted for approval.");
      } else {
        showToast("Migration started — tracking progress below.");
      }
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handlePause() {
    setBusy(true);
    setError("");
    try {
      await api.pauseImportBatch(tenantAuth.get(), id);
      showToast("Pause requested — will stop after the current chunk.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleResume() {
    setBusy(true);
    setError("");
    try {
      await api.resumeImportBatch(tenantAuth.get(), id);
      showToast("Resumed from the last checkpoint.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleCancel() {
    if (!window.confirm("Cancel this migration? Records already imported will not be undone.")) return;
    setBusy(true);
    setError("");
    try {
      await api.cancelImportBatch(tenantAuth.get(), id);
      showToast("Migration cancelled.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleRetryFailed() {
    setBusy(true);
    setError("");
    try {
      await api.retryFailedImportRecords(tenantAuth.get(), id);
      showToast("Retrying failed records.");
      await load();
      if (tab === "FAILED") await loadRecords("INVALID,FAILED");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;
  if (!batch) {
    return (
      <div>
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const canResumeCommit = can("imports.commit") && batch.status === "PREVIEW";
  const canPause = can("imports.pause") && ["QUEUED", "PROCESSING"].includes(batch.status);
  const canResume = can("imports.resume") && batch.status === "PAUSED";
  const canCancel = can("imports.cancel") && ["QUEUED", "PROCESSING", "PAUSED"].includes(batch.status);
  const canRetryFailed = can("imports.retry") && batch.status === "COMPLETED_WITH_ERRORS" && batch.failedCount > 0;
  const isRunning = RUNNING_STATUSES.includes(batch.status);
  const progressPct = batch.totalRecords > 0 ? Math.min(100, Math.round((batch.processedRecords / batch.totalRecords) * 100)) : 0;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Imports", href: "/tenant/imports" }, { label: batch.batchNumber }]}
        title={batch.batchNumber}
        description={`${IMPORT_TYPE_LABEL[batch.importType] || batch.importType} — ${batch.sourceFileName}`}
        action={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {(batch.failedCount > 0 || batch.status === "PREVIEW") && (
              <Button variant="outline" onClick={() => api.downloadImportErrorReport(tenantAuth.get(), batch.id)}>
                Download Error Report
              </Button>
            )}
            {canResumeCommit && (
              <Button onClick={handleCommit} disabled={busy}>
                {busy ? "Starting…" : `Import ${batch.successCount} Ready Record${batch.successCount === 1 ? "" : "s"}`}
              </Button>
            )}
            {canPause && (
              <Button variant="outline" onClick={handlePause} disabled={busy}>
                Pause
              </Button>
            )}
            {canResume && (
              <Button onClick={handleResume} disabled={busy}>
                Resume
              </Button>
            )}
            {canRetryFailed && (
              <Button onClick={handleRetryFailed} disabled={busy}>
                Retry {batch.failedCount} Failed Record{batch.failedCount === 1 ? "" : "s"}
              </Button>
            )}
            {canCancel && (
              <Button variant="danger" onClick={handleCancel} disabled={busy}>
                Cancel
              </Button>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />
      {batch.status === "FAILED" && batch.lastError && <ErrorBanner message={`Migration stopped unexpectedly: ${batch.lastError}`} />}

      <div className="kpi-card-grid">
        <div className="card kpi-card">
          <span className="kpi-card-label">Status</span>
          <div style={{ marginTop: 8 }}>
            <ImportStatusBadge status={batch.status} />
          </div>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Total Records</span>
          <span className="kpi-card-value">{batch.totalRecords}</span>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Successful</span>
          <span className="kpi-card-value">{batch.successCount}</span>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Failed</span>
          <span className="kpi-card-value">{batch.failedCount}</span>
        </div>
      </div>

      {(isRunning || batch.status === "PAUSED") && (
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <strong>
              {isRunning ? "Migration in progress" : "Migration paused"} — {batch.processedRecords} / {batch.totalRecords} records processed
              {isRunning ? " (updating live)" : ""}
            </strong>
            <span>{progressPct}%</span>
          </div>
          <div style={{ height: 8, borderRadius: 4, background: "var(--color-surface-sunken)", overflow: "hidden" }}>
            <div
              style={{
                height: "100%",
                width: `${progressPct}%`,
                background: batch.failedCount > 0 ? "var(--color-danger)" : "var(--color-accent)",
                transition: "width 0.3s ease",
              }}
            />
          </div>
          <div style={{ marginTop: 8, fontSize: "var(--text-small)", color: "var(--color-ink-soft)" }}>
            Chunk {batch.currentBatchNumber} · checkpoint at row {batch.checkpointRowNumber} · last activity {formatDate(batch.lastActivityAt)}
          </div>
        </Card>
      )}

      <Card>
        <Tabs
          tabs={[
            { key: "OVERVIEW", label: "Overview" },
            { key: "IMPORTED", label: "Successful" },
            { key: "FAILED", label: "Failed" },
          ]}
          activeKey={tab}
          onChange={handleTabChange}
        />

        <div style={{ marginTop: 16 }}>
          {tab === "OVERVIEW" && (
            <div className="review-list">
              <ProfileField label="Import Type" value={IMPORT_TYPE_LABEL[batch.importType] || batch.importType} />
              <ProfileField
                label="Period"
                value={batch.periodFrom && batch.periodTo ? `${formatDateOnly(batch.periodFrom)} – ${formatDateOnly(batch.periodTo)}` : null}
                tooltip="No period was specified for this batch."
              />
              <ProfileField
                label="Original File"
                value={
                  <a href={`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000"}${batch.sourceFileUrl}`} target="_blank" rel="noreferrer">
                    {batch.sourceFileName}
                  </a>
                }
              />
              <ProfileField label="Imported By" value={batch.importedByName} tooltip="Not resolved." />
              <ProfileField label="Imported At" value={batch.importedAt ? formatDate(batch.importedAt) : null} tooltip="Not committed yet." />
              <ProfileField label="Created" value={formatDate(batch.createdAt)} />
            </div>
          )}

          {tab === "IMPORTED" &&
            (records === null ? (
              <LoadingSkeleton columns={3} />
            ) : records.length === 0 ? (
              <EmptyState title="Nothing imported yet" description="Successful records will appear here once this batch is committed." />
            ) : (
              <TableScroll>
                <Table
                  columns={[
                    { key: "rowNumber", header: "Row #" },
                    { key: "entityType", header: "Type", render: (r) => r.entityType || "—" },
                    {
                      key: "link",
                      header: "Record",
                      render: (r) =>
                        r.entityType && r.resultingEntityId && ENTITY_ROUTE[r.entityType] ? (
                          <Link href={ENTITY_ROUTE[r.entityType](r.resultingEntityId)}>View</Link>
                        ) : (
                          "—"
                        ),
                    },
                  ]}
                  rows={records}
                  rowKey={(r) => r.id}
                />
              </TableScroll>
            ))}

          {tab === "FAILED" &&
            (records === null ? (
              <LoadingSkeleton columns={3} />
            ) : records.length === 0 ? (
              <EmptyState title="No failed records" description="Every row in this batch either imported cleanly or hasn't been validated yet." />
            ) : (
              <TableScroll>
                <Table
                  columns={[
                    { key: "rowNumber", header: "Row #" },
                    { key: "sourceIdentifier", header: "Record", render: (r) => r.sourceIdentifier || `Row ${r.rowNumber}` },
                    {
                      key: "status",
                      header: "Stage",
                      render: (r) => (r.status === "FAILED" ? "Commit" : "Validation"),
                    },
                    { key: "errorCode", header: "Error Code", render: (r) => r.errorCode || "—" },
                    {
                      key: "errors",
                      header: "Issues",
                      render: (r) => <span style={{ color: "var(--color-danger)" }}>{(r.validationErrors || []).map((e) => e.message).join("; ")}</span>,
                    },
                    {
                      key: "retryCount",
                      header: "Retries",
                      render: (r) => (r.retryCount > 0 ? `${r.retryCount} (last ${formatDate(r.lastRetriedAt)})` : "—"),
                    },
                  ]}
                  rows={records}
                  rowKey={(r) => r.id}
                />
              </TableScroll>
            ))}
        </div>
      </Card>
    </div>
  );
}
