"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

// Admin and Tenant login were merged into one shared page. Kept as a thin
// redirect (rather than deleted) so any existing bookmark/link still works.
export default function TenantLoginRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace("/login?role=tenant");
  }, [router]);

  return null;
}
