"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import { PaymentStatusChip, ReconciliationChip } from "../../../components/payments/PaymentStatusBadge";
import NewPaymentModal from "../../../components/payments/NewPaymentModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";

const PAYMENT_METHOD_LABEL = { CASH: "Cash", BANK_TRANSFER: "Bank Transfer", CARD: "Card", CHEQUE: "Cheque", OTHER: "Other" };

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Same enterprise list pattern as Credit Notes/Sales Debit Notes - Table,
// Toolbar, Pagination, ActionMenu, status badges, Empty/Loading states.
export default function PaymentsPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("payments.view");
  const { can } = usePermissions();
  const { showToast } = useToast();
  const searchParams = useSearchParams();
  // Seeds an optional customer filter from a query param (e.g. an Invoice's
  // own "View all payments from this customer" link) - read once on mount,
  // same pattern the Invoices list already uses for its own paymentStatus param.
  const initialCustomerId = searchParams.get("customerId") || "";

  const [payments, setPayments] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [newPaymentOpen, setNewPaymentOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { payments } = await api.listPayments(token, initialCustomerId ? { customerId: initialCustomerId } : {});
      setPayments(payments);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function handleExport() {
    const rows = [
      ["Payment #", "Customer", "Payment Date", "Amount", "Method", "Allocated", "Unallocated", "Status", "Reference"],
      ...filtered.map((p) => [
        p.paymentNumberDisplay || p.id,
        p.customerName,
        formatDate(p.paymentDate),
        p.amount,
        PAYMENT_METHOD_LABEL[p.method] || p.method,
        p.allocatedTotal,
        p.unallocatedAmount,
        p.status,
        p.reference || "",
      ]),
    ];
    downloadCsv(`payments-received-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  }

  const kpis = useMemo(() => {
    if (!payments) return null;
    const confirmed = payments.filter((p) => p.status === "CONFIRMED");
    return {
      total: payments.length,
      confirmed: confirmed.length,
      cancelled: payments.filter((p) => p.status === "CANCELLED").length,
      totalReceived: confirmed.reduce((s, p) => s + p.amount, 0),
      totalUnallocated: confirmed.reduce((s, p) => s + p.unallocatedAmount, 0),
    };
  }, [payments]);

  const filtered = useMemo(() => {
    if (!payments) return [];
    const q = search.trim().toLowerCase();
    return payments.filter((p) => {
      const matchesSearch =
        !q || (p.paymentNumberDisplay || "").toLowerCase().includes(q) || p.customerName.toLowerCase().includes(q) || (p.reference || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [payments, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  async function handleDelete() {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deletePayment(token, deleteTarget.id);
      showToast(`${deleteTarget.paymentNumberDisplay} deleted.`);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
      setDeleteTarget(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleCancel() {
    if (!cancelTarget) return;
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.cancelPayment(token, cancelTarget.id);
      showToast(`${cancelTarget.paymentNumberDisplay} cancelled.`);
      setCancelTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
      setCancelTarget(null);
    } finally {
      setBusy(false);
    }
  }

  const COLUMNS = useMemo(
    () => [
      { key: "paymentNumberDisplay", header: "Payment #", render: (p) => <span className="mono" style={{ fontWeight: 600 }}>{p.paymentNumberDisplay}</span> },
      { key: "customerName", header: "Customer", render: (p) => p.customerName },
      { key: "paymentDate", header: "Payment Date", render: (p) => formatDate(p.paymentDate) },
      { key: "amount", header: "Amount", className: "num", render: (p) => formatCurrency(p.amount, p.currency) },
      { key: "method", header: "Method", render: (p) => PAYMENT_METHOD_LABEL[p.method] || p.method },
      { key: "allocatedTotal", header: "Allocated", className: "num", render: (p) => formatCurrency(p.allocatedTotal, p.currency) },
      { key: "unallocatedAmount", header: "Unallocated", className: "num", render: (p) => formatCurrency(p.unallocatedAmount, p.currency) },
      { key: "status", header: "Status", render: (p) => <span style={{ display: "flex", gap: 6, flexWrap: "wrap" }}><PaymentStatusChip payment={p} /><ReconciliationChip payment={p} /></span> },
      { key: "reference", header: "Reference", render: (p) => p.reference || "—" },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (p) => (
          <ActionMenu
            ariaLabel={`Actions for ${p.paymentNumberDisplay}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/payments/${p.id}`) },
              { label: "Edit", onClick: () => router.push(`/tenant/payments/${p.id}`), disabled: !can("payments.update") || p.status === "CANCELLED", disabledReason: p.status === "CANCELLED" ? "This payment is cancelled." : "Not permitted." },
              { label: "Allocate", onClick: () => router.push(`/tenant/payments/${p.id}`), disabled: !can("payments.allocate") || p.status === "CANCELLED" },
              { label: "History / Audit", onClick: () => router.push(`/tenant/payments/${p.id}`) },
              {
                label: "Cancel",
                danger: true,
                onClick: () => setCancelTarget(p),
                disabled: !can("payments.cancel") || p.status === "CANCELLED" || p.reconciliationStatus === "RECONCILED",
                disabledReason: p.reconciliationStatus === "RECONCILED" ? "Unreconcile it first." : p.status === "CANCELLED" ? "Already cancelled." : "Not permitted.",
              },
              {
                label: "Delete",
                danger: true,
                onClick: () => setDeleteTarget(p),
                disabled: !can("payments.delete") || p.allocatedTotal > 0,
                disabledReason: p.allocatedTotal > 0 ? "Has allocations - cancel instead." : "Not permitted.",
              },
            ]}
          />
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [router, can]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Payments Received" }]}
        title="Payments Received"
        description="Every customer payment recorded, with its allocation across one or more invoices."
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {payments && payments.length > 0 && (
              <Button variant="outline" onClick={handleExport}>
                Export
              </Button>
            )}
            {can("payments.create") && <Button onClick={() => setNewPaymentOpen(true)}>+ Record Payment</Button>}
          </div>
        }
      />

      <ErrorBanner message={error} />

      {kpis && (
        <div className="kpi-card-grid">
          <div className="card kpi-card">
            <div className="kpi-card-top"><span className="kpi-card-label">Total Payments</span></div>
            <span className="kpi-card-value">{kpis.total}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top"><span className="kpi-card-label">Confirmed</span></div>
            <span className="kpi-card-value">{kpis.confirmed}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top"><span className="kpi-card-label">Cancelled</span></div>
            <span className="kpi-card-value">{kpis.cancelled}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top"><span className="kpi-card-label">Total Received</span></div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalReceived)}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top"><span className="kpi-card-label">Unallocated</span></div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalUnallocated)}</span>
          </div>
        </div>
      )}

      <div className="table-block">
        {payments === null ? (
          <LoadingSkeleton columns={9} />
        ) : payments.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
                <path d="M8 8h8M8 12h8M8 16h5" />
              </svg>
            }
            title="No payments recorded yet"
            description="Record a customer receipt and allocate it against one or more Sent invoices."
            action={can("payments.create") && <Button onClick={() => setNewPaymentOpen(true)}>+ Record Payment</Button>}
          />
        ) : (
          <>
            <Toolbar
              title="Payments Received"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by payment #, customer, or reference…"
              filters={
                <select
                  className="select-filter"
                  value={statusFilter}
                  onChange={(e) => {
                    setStatusFilter(e.target.value);
                    resetToPageOne();
                  }}
                >
                  <option value="ALL">All statuses</option>
                  <option value="CONFIRMED">Confirmed</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching payments"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} onRowClick={(p) => router.push(`/tenant/payments/${p.id}`)} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Payments"
                />
              </>
            )}
          </>
        )}
      </div>

      <NewPaymentModal
        open={newPaymentOpen}
        onClose={() => setNewPaymentOpen(false)}
        onSuccess={(payment) => {
          showToast(`${payment.paymentNumberDisplay} recorded.`);
          load();
        }}
      />

      <ConfirmationDialog
        open={!!deleteTarget}
        title="Delete this payment?"
        message={`"${deleteTarget?.paymentNumberDisplay}" has no allocations, so nothing else is affected. This can't be undone.`}
        confirmLabel="Delete"
        variant="danger"
        busy={busy}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
      <ConfirmationDialog
        open={!!cancelTarget}
        title="Cancel this payment?"
        message={`"${cancelTarget?.paymentNumberDisplay}" will be reversed - every invoice it was allocated to recalculates its balance immediately. The payment record and its history are preserved, not deleted. This can't be undone.`}
        confirmLabel="Cancel Payment"
        variant="danger"
        busy={busy}
        onConfirm={handleCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
}
