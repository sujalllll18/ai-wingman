"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api, assetUrl } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import NoteStatusBadge from "../../../../components/notes/NoteStatusBadge";
import NoteActivityTimeline from "../../../../components/notes/NoteActivityTimeline";
import NoteLineItemsTable from "../../../../components/notes/NoteLineItemsTable";
import AdjustmentSummaryCard from "../../../../components/notes/AdjustmentSummaryCard";
import DebitNoteClassicTemplate from "../../../../components/debit-note-templates/ClassicTemplate";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function DebitNoteDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [debitNote, setDebitNote] = useState(null);
  const [adjustment, setAdjustment] = useState(null);
  const [businessAssets, setBusinessAssets] = useState({});
  const [error, setError] = useState("");
  const [confirmAction, setConfirmAction] = useState(null); // "issue" | "delete" | "void"
  const [busy, setBusy] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { debitNote, adjustment } = await api.getDebitNote(token, params.id);
      setDebitNote(debitNote);
      setAdjustment(adjustment);
      // Live Business Profile assets for the PDF (2026-08-11) - mirrors the
      // Invoice Viewer's same deliberate live-read pattern.
      api
        .getBusinessProfile(token)
        .then(({ businessProfile }) =>
          setBusinessAssets({ logoUrl: assetUrl(businessProfile.logoUrl), stampUrl: assetUrl(businessProfile.stampUrl), signatureUrl: assetUrl(businessProfile.signatureUrl) })
        )
        .catch(() => {});
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleIssue() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const result = await api.issueDebitNote(token, params.id);
      setConfirmAction(null);
      if (result.approvalRequest) {
        showToast(`Issuing requires approval - submitted as ${result.approvalRequest.referenceNumber}. This stays a Draft until a checker decides.`);
        await load();
      } else {
        setDebitNote(result.debitNote);
        showToast(`${result.debitNote.debitNoteNumberDisplay} was issued.`);
        await load();
      }
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deleteDebitNote(token, params.id);
      showToast("Draft deleted.");
      router.push("/tenant/debit-notes");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
      setBusy(false);
    }
  }

  async function handleVoid() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { debitNote } = await api.voidDebitNote(token, params.id);
      setDebitNote(debitNote);
      setConfirmAction(null);
      showToast("Debit note cancelled.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDownloadPdf() {
    setDownloading(true);
    try {
      const node = document.getElementById("debit-note-pdf-source");
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      await doc.html(node, { x: 0, y: 0, width: 210, windowWidth: node.offsetWidth, autoPaging: "text" });
      doc.save(`${debitNote.debitNoteNumberDisplay || "Draft-DebitNote"}.pdf`);
      const token = tenantAuth.get();
      api.logDebitNoteActivity(token, debitNote.id, "DOWNLOADED", "PDF").catch(() => {});
      showToast(`Downloaded ${debitNote.debitNoteNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setDownloading(false);
    }
  }

  if (!debitNote) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/debit-notes" }, { label: "…" }]} title="Debit Note" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const title = debitNote.debitNoteNumberDisplay || "Draft Debit Note";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/debit-notes" }, { label: title }]}
        title={title}
        eyebrow={<NoteStatusBadge status={debitNote.status} />}
        description={
          debitNote.status === "DRAFT"
            ? "This debit note hasn't been issued — it isn't numbered and has no VAT effect yet."
            : `Issued ${formatDate(debitNote.issueDate)}`
        }
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="outline" onClick={handleDownloadPdf} disabled={downloading}>
              Download PDF
            </Button>
            {debitNote.status === "DRAFT" && (
              <>
                <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                  Delete Draft
                </Button>
                <Button onClick={() => setConfirmAction("issue")}>Issue Debit Note</Button>
              </>
            )}
            {debitNote.status === "ISSUED" && (
              <Button variant="outline" onClick={() => setConfirmAction("void")}>
                Cancel Debit Note
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Original Purchase Bill</h3>
            <p style={{ margin: 0 }}>
              <Link href={`/tenant/purchases/${debitNote.purchaseBill.id}`} className="mono">
                {debitNote.purchaseBill.billNumberDisplay}
              </Link>
            </p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Vendor</h3>
            <p style={{ margin: 0 }}>{debitNote.vendorName}</p>
            {debitNote.vendorAddress && <p className="helptext" style={{ margin: 0 }}>{debitNote.vendorAddress}</p>}
            {debitNote.vendorTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {debitNote.vendorTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Reason</h3>
            <p style={{ margin: 0 }}>{debitNote.reason}</p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <NoteLineItemsTable lineItems={debitNote.lineItems} currency={debitNote.currency} />
          </Card>

          {debitNote.notes && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Notes</h3>
              <p style={{ margin: 0 }}>{debitNote.notes}</p>
            </Card>
          )}

          <Card>
            <h3 style={{ marginTop: 0 }}>Activity</h3>
            <NoteActivityTimeline activities={debitNote.activities} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          {adjustment && (
            <AdjustmentSummaryCard
              currency={debitNote.currency}
              originalAmount={adjustment.originalAmount}
              previouslyAdjusted={adjustment.previouslyAdjusted}
              previouslyLabel="Previously Debited"
              currentNote={adjustment.currentNote ?? debitNote.grandTotal}
              currentLabel="This Debit Note"
            />
          )}
          <Card>
            <h3 style={{ marginTop: 0 }}>Totals</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Subtotal</span>
                <span className="review-value mono">{debitNote.currency} {Number(debitNote.subtotal).toFixed(2)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">VAT</span>
                <span className="review-value mono">{debitNote.currency} {Number(debitNote.vatTotal).toFixed(2)}</span>
              </div>
              <div className="review-row" style={{ fontWeight: 600 }}>
                <span className="review-label">Grand Total</span>
                <span className="review-value mono">{debitNote.currency} {Number(debitNote.grandTotal).toFixed(2)}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <ConfirmationDialog
        open={confirmAction === "issue"}
        title="Issue this debit note?"
        message="This assigns a permanent debit note number, freezes the document, and increases input VAT for the period containing this issue date. This can't be undone."
        confirmLabel="Issue Debit Note"
        busy={busy}
        onConfirm={handleIssue}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "delete"}
        title="Delete this draft?"
        message="This draft has never been issued, so no debit note number has been consumed. This can't be undone."
        confirmLabel="Delete Draft"
        variant="danger"
        busy={busy}
        onConfirm={handleDelete}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "void"}
        title="Cancel this debit note?"
        message="A cancelled debit note's number is never reused, and its VAT effect is reversed from this point forward. This can't be undone."
        confirmLabel="Cancel Debit Note"
        variant="danger"
        busy={busy}
        onConfirm={handleVoid}
        onCancel={() => setConfirmAction(null)}
      />

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        <div id="debit-note-pdf-source">
          <DebitNoteClassicTemplate debitNote={debitNote} businessAssets={businessAssets} />
        </div>
      </div>
    </div>
  );
}
