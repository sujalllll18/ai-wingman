"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import NoteStatusBadge from "../../../components/notes/NoteStatusBadge";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Mirrors credit-notes/page.js exactly, one level down (Purchase side).
export default function DebitNotesPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("debit_notes.view");

  const [notes, setNotes] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [vendorFilter, setVendorFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { debitNotes } = await api.listDebitNotes(token);
      setNotes(debitNotes);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function handleExport() {
    const rows = [
      ["Debit Note #", "Original Purchase Bill", "Vendor", "Issue Date", "Status", "Subtotal", "VAT", "Total"],
      ...filtered.map((n) => [
        n.debitNoteNumberDisplay || "Draft",
        n.purchaseBill?.billNumberDisplay || "",
        n.vendorName,
        n.issueDate ? formatDate(n.issueDate) : "",
        n.status,
        n.subtotal,
        n.vatTotal,
        n.grandTotal,
      ]),
    ];
    downloadCsv(`debit-notes-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  }

  const vendors = useMemo(() => {
    if (!notes) return [];
    return Array.from(new Set(notes.map((n) => n.vendorName))).sort();
  }, [notes]);

  const filtered = useMemo(() => {
    if (!notes) return [];
    const q = search.trim().toLowerCase();
    return notes.filter((n) => {
      const matchesSearch =
        !q ||
        (n.debitNoteNumberDisplay || "").toLowerCase().includes(q) ||
        (n.purchaseBill?.billNumberDisplay || "").toLowerCase().includes(q) ||
        n.vendorName.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || n.status === statusFilter;
      const matchesVendor = vendorFilter === "ALL" || n.vendorName === vendorFilter;
      return matchesSearch && matchesStatus && matchesVendor;
    });
  }, [notes, search, statusFilter, vendorFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  const COLUMNS = useMemo(
    () => [
      {
        key: "debitNoteNumberDisplay",
        header: "Debit Note #",
        render: (n) => <span className="mono" style={{ fontWeight: 600 }}>{n.debitNoteNumberDisplay || "Draft"}</span>,
      },
      { key: "purchaseBill", header: "Original Purchase Bill", render: (n) => <span className="mono">{n.purchaseBill?.billNumberDisplay || "—"}</span> },
      { key: "vendorName", header: "Vendor", render: (n) => n.vendorName },
      { key: "issueDate", header: "Issue Date", render: (n) => formatDate(n.issueDate) },
      { key: "status", header: "Status", render: (n) => <NoteStatusBadge status={n.status} /> },
      { key: "subtotal", header: "Subtotal", className: "num", render: (n) => formatCurrency(n.subtotal) },
      { key: "vatTotal", header: "VAT", className: "num", render: (n) => formatCurrency(n.vatTotal) },
      { key: "grandTotal", header: "Total", className: "num", render: (n) => formatCurrency(n.grandTotal) },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (n) => (
          <ActionMenu
            ariaLabel={`Actions for ${n.debitNoteNumberDisplay || "draft debit note"}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/debit-notes/${n.id}`) },
              { label: "History", onClick: () => router.push(`/tenant/debit-notes/${n.id}`) },
            ]}
          />
        ),
      },
    ],
    [router]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes" }]}
        title="Debit Notes"
        description="Every increase/correction issued against a Recorded purchase bill, in one place. Start a new one from the original bill."
        action={
          notes &&
          notes.length > 0 && (
            <Button variant="outline" onClick={handleExport}>
              Export
            </Button>
          )
        }
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {notes === null ? (
          <LoadingSkeleton columns={7} />
        ) : notes.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <circle cx="9" cy="20" r="1.4" />
                <circle cx="17" cy="20" r="1.4" />
                <path d="M2.5 3.5h2.5l2.6 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6l1.6-8.4H6" />
              </svg>
            }
            title="No debit notes yet"
            description="Issue a Debit Note from a purchase bill's detail page when a Recorded bill needs to be increased or corrected."
            action={
              <Link href="/tenant/purchases">
                <Button>Go to Purchases</Button>
              </Link>
            }
          />
        ) : (
          <>
            <Toolbar
              title="Debit Notes"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by debit note #, bill #, or vendor…"
              filters={
                <>
                  <select
                    className="select-filter"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All statuses</option>
                    <option value="DRAFT">Draft</option>
                    <option value="ISSUED">Issued</option>
                    <option value="VOID">Cancelled</option>
                  </select>
                  <select
                    className="select-filter"
                    value={vendorFilter}
                    onChange={(e) => {
                      setVendorFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All vendors</option>
                    {vendors.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching debit notes"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} onRowClick={(n) => router.push(`/tenant/debit-notes/${n.id}`)} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Debit Notes"
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
