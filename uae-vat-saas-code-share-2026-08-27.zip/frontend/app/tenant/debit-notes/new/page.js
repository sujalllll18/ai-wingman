"use client";

import { useSearchParams } from "next/navigation";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import DebitNoteForm from "../../../../components/debit-notes/DebitNoteForm";

export default function NewDebitNotePage() {
  const searchParams = useSearchParams();
  const purchaseBillId = searchParams.get("purchaseBillId");

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/debit-notes" }, { label: "New Debit Note" }]}
        title="New Debit Note"
        description="Build a draft against a Recorded purchase bill — nothing is numbered or VAT-effective until you issue it."
      />
      {purchaseBillId ? (
        <DebitNoteForm purchaseBillId={purchaseBillId} />
      ) : (
        <ErrorBanner message="No purchase bill selected. Start a Debit Note from a purchase bill's detail page." />
      )}
    </div>
  );
}
