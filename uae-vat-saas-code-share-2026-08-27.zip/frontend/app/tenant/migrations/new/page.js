"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Card from "../../../../components/ui/Card";
import Select from "../../../../components/ui/Select";
import Button from "../../../../components/ui/Button";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import StepWizard from "../../../../components/ui/StepWizard";
import Modal from "../../../../components/ui/Modal";
import ImportUploadDropzone from "../../../../components/imports/ImportUploadDropzone";
import { IMPORT_TYPE_LABEL } from "../../../../components/imports/ImportStatusBadge";
import ExistingTenantDataWarning from "../../../../components/migrations/ExistingTenantDataWarning";
import MigrationEntitySummaryTable from "../../../../components/migrations/MigrationEntitySummaryTable";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";

const STEPS = ["Select Files", "Map Columns", "Migration Review", "Confirm & Commit"];

export default function NewMigrationPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.create");
  const router = useRouter();
  const { showToast } = useToast();

  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [importTypes, setImportTypes] = useState(null);
  const [stagedFiles, setStagedFiles] = useState([]); // [{file, importType}]
  const [dataCounts, setDataCounts] = useState(null);

  const [migration, setMigration] = useState(null);
  const [batches, setBatches] = useState([]); // [{batch, headers, mapping}]
  const [mappings, setMappings] = useState({}); // batchId -> mapping object

  const [preview, setPreview] = useState(null);
  const [drillIn, setDrillIn] = useState(null); // {label, mode, rows}

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const [{ importTypes }, counts] = await Promise.all([api.listImportTypes(token), api.getTenantDataCounts(token)]);
        setImportTypes(importTypes);
        setDataCounts(counts);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  function addFile(file) {
    setStagedFiles((prev) => [...prev, { file, importType: importTypes?.[0]?.importType || "SALES_INVOICE" }]);
  }
  function updateFileType(index, importType) {
    setStagedFiles((prev) => prev.map((f, i) => (i === index ? { ...f, importType } : f)));
  }
  function removeFile(index) {
    setStagedFiles((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleCreateMigration() {
    if (stagedFiles.length === 0) {
      setError("Add at least one file to migrate.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { migration, batches } = await api.createMigration(token, {
        files: stagedFiles.map((f) => f.file),
        fileMeta: stagedFiles.map((f) => ({ importType: f.importType })),
      });
      setMigration(migration);
      setBatches(batches);
      const initialMappings = {};
      batches.forEach((b) => {
        initialMappings[b.batch.id] = b.mapping;
      });
      setMappings(initialMappings);
      setStep(1);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleValidateAll() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      for (const b of batches) {
        await api.setImportMapping(token, b.batch.id, mappings[b.batch.id]);
        await api.validateImportBatch(token, b.batch.id);
      }
      const previewData = await api.getMigrationPreview(token, migration.id);
      setPreview(previewData);
      setStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function openDrillIn(entity, mode) {
    const token = tenantAuth.get();
    let rows;
    if (mode === "errors") rows = (await api.getImportRecords(token, entity.batchId, { status: "INVALID,FAILED" })).records;
    else if (mode === "warnings") rows = (await api.getImportRecords(token, entity.batchId, { status: "VALID", onlyWarnings: true })).records;
    else rows = (await api.getImportRecords(token, entity.batchId, { status: "VALID", onlyDuplicates: true })).records;
    setDrillIn({ label: entity.label, mode, rows });
  }

  async function handleCommit() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const res = await api.commitMigration(token, migration.id);
      showToast(`${migration.migrationNumber} — migration started.`);
      router.push(`/tenant/migrations/${migration.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Migration Center", href: "/tenant/migrations" }, { label: "New Migration" }]}
        title="New Migration"
        description="Upload → Map → Review → Confirm → Commit — historical data from one or more files becomes real Ledger records, dated as it actually happened."
      />

      <ErrorBanner message={error} />

      <div style={{ marginBottom: 20 }}>
        <StepWizard steps={STEPS} currentStep={step} />
      </div>

      {step === 0 && (
        <Card>
          <h3 style={{ marginTop: 0 }}>What are you migrating?</h3>
          <p className="helptext" style={{ marginTop: -8 }}>
            Add one file per entity type (e.g. a Customers file and a Sales Invoices file) — every file becomes part of
            this same migration and is reviewed together before anything is committed.
          </p>

          {stagedFiles.length > 0 && (
            <TableScroll>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>File</th>
                    <th>Entity Type</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {stagedFiles.map((f, i) => (
                    <tr key={i}>
                      <td data-label="File">{f.file.name}</td>
                      <td data-label="Entity Type">
                        <Select value={f.importType} onChange={(e) => updateFileType(i, e.target.value)}>
                          {(importTypes || []).map((t) => (
                            <option key={t.importType} value={t.importType}>
                              {t.label}
                            </option>
                          ))}
                        </Select>
                      </td>
                      <td>
                        <Button variant="ghost" onClick={() => removeFile(i)}>
                          Remove
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </TableScroll>
          )}

          <div style={{ marginTop: 16 }}>
            <ImportUploadDropzone onFileSelected={addFile} />
          </div>

          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 20 }}>
            <Button onClick={handleCreateMigration} disabled={busy || stagedFiles.length === 0}>
              {busy ? "Uploading…" : `Upload ${stagedFiles.length} File${stagedFiles.length === 1 ? "" : "s"} & Continue`}
            </Button>
          </div>
        </Card>
      )}

      {step === 1 && batches.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {batches.map((b) => {
            const templateFields = importTypes?.find((t) => t.importType === b.batch.importType)?.templateFields || [];
            return (
              <Card key={b.batch.id}>
                <h3 style={{ marginTop: 0 }}>
                  {IMPORT_TYPE_LABEL[b.batch.importType] || b.batch.importType} — {b.batch.sourceFileName}
                </h3>
                <TableScroll>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Ledger Field</th>
                        <th>Your Column</th>
                      </tr>
                    </thead>
                    <tbody>
                      {templateFields.map((f) => (
                        <tr key={f.key}>
                          <td data-label="Ledger Field">
                            {f.label}
                            {f.required && <span className="required-asterisk"> *</span>}
                          </td>
                          <td data-label="Your Column">
                            <Select
                              value={mappings[b.batch.id]?.[f.key] || ""}
                              onChange={(e) =>
                                setMappings((m) => ({ ...m, [b.batch.id]: { ...m[b.batch.id], [f.key]: e.target.value || null } }))
                              }
                            >
                              <option value="">— Not mapped —</option>
                              {b.headers.map((h) => (
                                <option key={h} value={h}>
                                  {h}
                                </option>
                              ))}
                            </Select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </TableScroll>
              </Card>
            );
          })}

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
            <Button variant="outline" onClick={() => setStep(0)} disabled={busy}>
              Back
            </Button>
            <Button onClick={handleValidateAll} disabled={busy}>
              {busy ? "Validating…" : "Validate All & Continue"}
            </Button>
          </div>
        </div>
      )}

      {step === 2 && preview && (
        <div>
          <h2 style={{ marginTop: 0 }}>Migration Review</h2>
          <div className="review-list" style={{ marginBottom: 20 }}>
            <div className="review-row">
              <span>Source</span>
              <span>Excel / CSV</span>
            </div>
            <div className="review-row">
              <span>Files</span>
              <span>{batches.map((b) => b.batch.sourceFileName).join(", ")}</span>
            </div>
          </div>

          <ExistingTenantDataWarning counts={dataCounts} />

          <div className="kpi-card-grid" style={{ marginBottom: 20 }}>
            <div className="card kpi-card">
              <span className="kpi-card-label">Total Records</span>
              <span className="kpi-card-value">{preview.totals.totalRecords}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Ready to Import</span>
              <span className="kpi-card-value">{preview.totals.ready}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Warnings</span>
              <span className="kpi-card-value">{preview.totals.warnings}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Errors</span>
              <span className="kpi-card-value">{preview.totals.errors}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Duplicates</span>
              <span className="kpi-card-value">{preview.totals.duplicates}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Skipped</span>
              <span className="kpi-card-value">{preview.totals.skipped}</span>
            </div>
          </div>

          {preview.totals.errors > 0 && (
            <p className="helptext" style={{ marginBottom: 16 }}>
              Records with errors will not be imported.
            </p>
          )}

          <MigrationEntitySummaryTable
            entities={preview.entities}
            onViewErrors={(e) => openDrillIn(e, "errors")}
            onViewWarnings={(e) => openDrillIn(e, "warnings")}
            onViewDuplicates={(e) => openDrillIn(e, "duplicates")}
          />

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(1)} disabled={busy}>
              Back
            </Button>
            <Button onClick={() => setStep(3)} disabled={busy}>
              Continue to Confirm
            </Button>
          </div>
        </div>
      )}

      {step === 3 && preview && (
        <Card>
          <h2 style={{ marginTop: 0 }}>Ready to import</h2>
          <p>
            <strong>{preview.totals.ready}</strong> record{preview.totals.ready === 1 ? "" : "s"} will be imported.
          </p>
          {preview.totals.errors > 0 && (
            <p>
              <strong>{preview.totals.errors}</strong> record{preview.totals.errors === 1 ? "" : "s"} contain errors and
              will be skipped.
            </p>
          )}
          <p className="helptext">
            Once committed, successfully imported financial records cannot be rolled back through this screen.
          </p>

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(2)} disabled={busy}>
              Back to Review
            </Button>
            <Button onClick={handleCommit} disabled={busy || preview.totals.ready === 0}>
              {busy ? "Starting…" : "Commit Migration"}
            </Button>
          </div>
        </Card>
      )}

      {drillIn && (
        <Modal open onClose={() => setDrillIn(null)} size="lg" ariaLabel={`${drillIn.label} issues`}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0 }}>
              {drillIn.label} — {drillIn.mode === "errors" ? "Errors" : drillIn.mode === "warnings" ? "Warnings" : "Duplicates"}
            </h3>
            <Button variant="ghost" onClick={() => setDrillIn(null)}>
              Close
            </Button>
          </div>
          {drillIn.rows.length === 0 ? (
            <p className="helptext">Nothing here.</p>
          ) : (
            <TableScroll>
              <Table
                columns={[
                  { key: "rowNumber", header: "Row #" },
                  { key: "sourceIdentifier", header: "Source ID", render: (r) => r.sourceIdentifier || `Row ${r.rowNumber}` },
                  {
                    key: "issues",
                    header: "Problem",
                    render: (r) => <span style={{ color: drillIn.mode === "errors" ? "var(--color-danger)" : "var(--color-warning)" }}>{(r.validationErrors || []).map((e) => e.message).join("; ")}</span>,
                  },
                ]}
                rows={drillIn.rows}
                rowKey={(r) => r.id}
              />
            </TableScroll>
          )}
        </Modal>
      )}
    </div>
  );
}
