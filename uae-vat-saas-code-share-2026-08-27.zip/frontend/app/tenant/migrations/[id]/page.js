"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Button from "../../../../components/ui/Button";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Modal from "../../../../components/ui/Modal";
import MigrationProgressPanel from "../../../../components/migrations/MigrationProgressPanel";
import MigrationFinalSummary from "../../../../components/migrations/MigrationFinalSummary";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import { usePermissions } from "../../../../hooks/usePermissions";

const RUNNING_STATUSES = ["QUEUED", "PROCESSING"];
const TERMINAL_STATUSES = ["COMPLETED", "COMPLETED_WITH_ERRORS", "FAILED", "CANCELLED"];
const POLL_INTERVAL_MS = 2000;

export default function MigrationDetailPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.view");
  const { can } = usePermissions();
  const { id } = useParams();
  const { showToast } = useToast();

  const [status, setStatus] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [failedRows, setFailedRows] = useState(null); // shown in a modal via "View Failed Records"

  useEffect(() => {
    load();
  }, [id]);

  useEffect(() => {
    if (!status || !RUNNING_STATUSES.includes(status.status)) return undefined;
    const timer = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [status?.status, id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const data = await api.getMigrationStatus(token, id);
      setStatus(data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function withBusy(fn, successMessage) {
    setError("");
    setBusy(true);
    try {
      await fn();
      if (successMessage) showToast(successMessage);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleViewFailed() {
    const token = tenantAuth.get();
    const allFailed = [];
    for (const e of status.perEntity) {
      if (e.failed === 0) continue;
      const { records } = await api.getImportRecords(token, e.batchId, { status: "INVALID,FAILED" });
      allFailed.push(...records.map((r) => ({ ...r, entityLabel: e.label })));
    }
    setFailedRows(allFailed);
  }

  if (permLoading || !allowed) return null;
  if (!status) {
    return (
      <div>
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const isRunning = RUNNING_STATUSES.includes(status.status);
  const isTerminal = TERMINAL_STATUSES.includes(status.status);
  const isPaused = status.status === "PAUSED";
  const isPreCommit = !isRunning && !isTerminal && !isPaused;

  const canPause = can("imports.pause") && isRunning;
  const canResume = can("imports.resume") && isPaused;
  const canCancel = can("imports.cancel") && (isRunning || isPaused);
  const canRetry = can("imports.retry") && status.status === "COMPLETED_WITH_ERRORS" && status.failedCount > 0;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Migration Center", href: "/tenant/migrations" }, { label: status.migration?.migrationNumber || "Migration" }]}
        title={status.migration?.migrationNumber || "Migration"}
        action={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {canPause && (
              <Button variant="outline" onClick={() => withBusy(() => api.pauseMigration(tenantAuth.get(), id), "Pause requested.")} disabled={busy}>
                Pause
              </Button>
            )}
            {canResume && (
              <Button onClick={() => withBusy(() => api.resumeMigration(tenantAuth.get(), id), "Resumed.")} disabled={busy}>
                Resume
              </Button>
            )}
            {canCancel && (
              <Button
                variant="danger"
                onClick={() => {
                  if (window.confirm("Cancel this migration? Records already imported will not be undone.")) {
                    withBusy(() => api.cancelMigration(tenantAuth.get(), id), "Migration cancelled.");
                  }
                }}
                disabled={busy}
              >
                Cancel
              </Button>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      {isPreCommit && (
        <p className="helptext">
          This migration hasn't been committed yet — go back to <a href="/tenant/migrations/new">New Migration</a> to finish reviewing and commit it.
        </p>
      )}

      {(isRunning || isPaused) && <MigrationProgressPanel status={status} isRunning={isRunning} />}

      {isTerminal && (
        <MigrationFinalSummary
          status={status}
          canRetry={canRetry}
          onViewFailed={status.failedCount > 0 ? handleViewFailed : undefined}
          onDownloadErrorReport={status.failedCount > 0 ? () => api.downloadMigrationErrorReport(tenantAuth.get(), id) : undefined}
          onDownloadMigrationReport={() => api.downloadMigrationErrorReport(tenantAuth.get(), id)}
          onRetryFailed={() => withBusy(() => api.retryFailedMigrationRecords(tenantAuth.get(), id), "Retrying failed records.")}
          goToTenantHref="/tenant/dashboard"
        />
      )}

      {failedRows && (
        <Modal open onClose={() => setFailedRows(null)} size="lg" ariaLabel="Failed records">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0 }}>Failed Records</h3>
            <Button variant="ghost" onClick={() => setFailedRows(null)}>
              Close
            </Button>
          </div>
          {failedRows.length === 0 ? (
            <p className="helptext">Nothing here.</p>
          ) : (
            <TableScroll>
              <Table
                columns={[
                  { key: "entityLabel", header: "Entity" },
                  { key: "rowNumber", header: "Row #" },
                  { key: "sourceIdentifier", header: "Record", render: (r) => r.sourceIdentifier || `Row ${r.rowNumber}` },
                  { key: "errorCode", header: "Error Code", render: (r) => r.errorCode || "—" },
                  {
                    key: "issues",
                    header: "Problem",
                    render: (r) => <span style={{ color: "var(--color-danger)" }}>{(r.validationErrors || []).map((e) => e.message).join("; ")}</span>,
                  },
                ]}
                rows={failedRows}
                rowKey={(r) => r.id}
              />
            </TableScroll>
          )}
        </Modal>
      )}
    </div>
  );
}
