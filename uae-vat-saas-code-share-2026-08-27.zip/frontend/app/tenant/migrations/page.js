"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Button from "../../../components/ui/Button";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import ImportStatusBadge from "../../../components/imports/ImportStatusBadge";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Migration History - one row per Migration (a Migration groups several
// ImportBatch files together, see migrationOrchestrator.service.js). The
// underlying per-file Import History still exists unchanged at
// /tenant/imports for the older single-file deep-links from Invoices/
// Purchases - this is the newer, multi-file "Migration Center."
export default function MigrationsPage() {
  const { allowed, loading: permLoading } = useRequirePermission("imports.view");
  const { can } = usePermissions();
  const router = useRouter();
  const [migrations, setMigrations] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { migrations } = await api.listMigrations(token);
      setMigrations(migrations);
    } catch (err) {
      setError(err.message);
    }
  }

  const COLUMNS = [
    { key: "migrationNumber", header: "Migration ID", render: (m) => <span className="mono">{m.migrationNumber}</span> },
    { key: "source", header: "Source", render: (m) => (m.source === "EXCEL" ? "Excel" : m.source) },
    { key: "entityCount", header: "Files", className: "num", render: (m) => m.entityCount },
    { key: "startedAt", header: "Started At", render: (m) => formatDate(m.startedAt) },
    { key: "totalRecords", header: "Total", className: "num", render: (m) => m.totalRecords },
    { key: "successCount", header: "Successful", className: "num", render: (m) => m.successCount },
    { key: "failedCount", header: "Failed", className: "num", render: (m) => m.failedCount },
    { key: "status", header: "Status", render: (m) => <ImportStatusBadge status={m.status} /> },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Migration Center" }]}
        title="Migration Center"
        description="Bring in historical Customers, Sales Invoices, and Purchase Bills from Excel or CSV - each Migration groups the files you upload together and walks through Preview, Commit, and a Final Summary."
        action={can("imports.create") && <Link href="/tenant/migrations/new" className="btn btn-primary">Start Migration</Link>}
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {migrations === null ? (
          <LoadingSkeleton columns={COLUMNS.length} />
        ) : migrations.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <path d="M12 3.5v11M7.5 10l4.5 4.5L16.5 10" />
                <path d="M4.5 16.5V19a1.5 1.5 0 0 0 1.5 1.5h12A1.5 1.5 0 0 0 19.5 19v-2.5" />
              </svg>
            }
            title="No migrations yet"
            description="Bring in historical data from Excel or CSV to get this tenant's records up to date."
            action={can("imports.create") && <Link href="/tenant/migrations/new" className="btn btn-primary">Start Migration</Link>}
          />
        ) : (
          <TableScroll>
            <Table columns={COLUMNS} rows={migrations} onRowClick={(m) => router.push(`/tenant/migrations/${m.id}`)} />
          </TableScroll>
        )}
      </div>
    </div>
  );
}
