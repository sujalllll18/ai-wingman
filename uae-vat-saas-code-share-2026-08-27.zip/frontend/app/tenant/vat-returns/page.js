"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import VatReturnStatusBadge from "../../../components/vat-returns/VatReturnStatusBadge";
import GenerateReturnModal from "../../../components/vat-returns/GenerateReturnModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

// List + Dashboard Filters (Tax Period/Status/Return Type/Financial Year) -
// each individual return's own Dashboard/Summary/Drilldown/Validation/
// Lock/Export/Activity lives on its detail page, mirroring the Invoice/
// Purchase List-vs-Detail split.
export default function VatReturnsPage() {
  const { allowed, loading: permLoading } = useRequirePermission("vat_returns.view");
  const [vatReturns, setVatReturns] = useState(null);
  const [error, setError] = useState("");
  const [generateOpen, setGenerateOpen] = useState(false);

  const [periodTypeFilter, setPeriodTypeFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [returnTypeFilter, setReturnTypeFilter] = useState("ALL");
  const [yearFilter, setYearFilter] = useState("ALL");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { vatReturns } = await api.listVatReturns(token);
      setVatReturns(vatReturns);
    } catch (err) {
      setError(err.message);
    }
  }

  const years = useMemo(() => {
    if (!vatReturns) return [];
    return Array.from(new Set(vatReturns.map((r) => new Date(r.periodStart).getFullYear()))).sort((a, b) => b - a);
  }, [vatReturns]);

  const returnTypes = useMemo(() => {
    if (!vatReturns) return [];
    return Array.from(new Set(vatReturns.map((r) => r.returnType)));
  }, [vatReturns]);

  const filtered = useMemo(() => {
    if (!vatReturns) return [];
    return vatReturns.filter((r) => {
      const matchesPeriodType = periodTypeFilter === "ALL" || r.periodType === periodTypeFilter;
      const matchesStatus = statusFilter === "ALL" || r.status === statusFilter;
      const matchesReturnType = returnTypeFilter === "ALL" || r.returnType === returnTypeFilter;
      const matchesYear = yearFilter === "ALL" || new Date(r.periodStart).getFullYear() === Number(yearFilter);
      return matchesPeriodType && matchesStatus && matchesReturnType && matchesYear;
    });
  }, [vatReturns, periodTypeFilter, statusFilter, returnTypeFilter, yearFilter]);

  const COLUMNS = [
    { key: "periodLabel", header: "Tax Period", render: (r) => r.periodLabel },
    { key: "periodType", header: "Type", render: (r) => (r.periodType === "MONTHLY" ? "Monthly" : "Quarterly") },
    { key: "returnType", header: "Return Type", render: (r) => r.returnType },
    { key: "status", header: "Status", render: (r) => <VatReturnStatusBadge vatReturn={r} /> },
    { key: "outputVat", header: "Output VAT", render: (r) => formatCurrency(r.outputVat) },
    { key: "inputVat", header: "Input VAT", render: (r) => formatCurrency(r.inputVat) },
    { key: "netVatPayable", header: "Net VAT", render: (r) => (r.netVatPayable >= 0 ? formatCurrency(r.netVatPayable) : `(${formatCurrency(Math.abs(r.netVatPayable))} refundable)`) },
    {
      key: "actions",
      header: "",
      render: (r) => (
        <Link href={`/tenant/vat-returns/${r.id}`} className="btn btn-outline btn-sm">
          View
        </Link>
      ),
    },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "VAT Returns" }]}
        title="VAT Returns"
        description="Automatically generated from your Sent invoices and Recorded purchase bills — read-only, nothing here is calculated manually."
        action={<Button onClick={() => setGenerateOpen(true)}>+ Generate Return</Button>}
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {vatReturns === null ? (
          <LoadingSkeleton columns={6} />
        ) : vatReturns.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <path d="M4 6h16M4 12h10M4 18h13" />
                <circle cx="19" cy="12" r="1.6" />
                <circle cx="20" cy="18" r="1.6" />
              </svg>
            }
            title="No VAT Returns yet"
            description="Generate your first VAT Return for a tax period."
            action={<Button onClick={() => setGenerateOpen(true)}>+ Generate Return</Button>}
          />
        ) : (
          <>
            <Toolbar
              title="VAT Returns"
              filters={
                <>
                  <select className="select-filter" value={periodTypeFilter} onChange={(e) => setPeriodTypeFilter(e.target.value)}>
                    <option value="ALL">All period types</option>
                    <option value="MONTHLY">Monthly</option>
                    <option value="QUARTERLY">Quarterly</option>
                  </select>
                  <select className="select-filter" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                    <option value="ALL">All statuses</option>
                    <option value="DRAFT">Draft</option>
                    <option value="LOCKED">Locked</option>
                  </select>
                  <select className="select-filter" value={returnTypeFilter} onChange={(e) => setReturnTypeFilter(e.target.value)}>
                    <option value="ALL">All return types</option>
                    {returnTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  <select className="select-filter" value={yearFilter} onChange={(e) => setYearFilter(e.target.value)}>
                    <option value="ALL">All financial years</option>
                    {years.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState title="No matching VAT Returns" description="Try clearing a filter." />
            ) : (
              <TableScroll>
                <Table columns={COLUMNS} rows={filtered} />
              </TableScroll>
            )}
          </>
        )}
      </div>

      <GenerateReturnModal
        open={generateOpen}
        onClose={() => setGenerateOpen(false)}
        onSuccess={() => {
          setGenerateOpen(false);
          load();
        }}
      />
    </div>
  );
}
