"use client";

import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Button from "../../../../../components/ui/Button";
import { getVatReturnTemplateComponent, DEFAULT_VAT_RETURN_TEMPLATE } from "../../../../../components/vat-return-templates";

// Same constants/rationale as the Invoice/Purchase Viewer - A4 at 96dpi,
// `zoom` CSS property (never `transform: scale`, which hangs html2canvas),
// setTimeout instead of requestAnimationFrame for reflow waits.
const A4_WIDTH_PX = 794;
const PAGE_HEIGHT_PX = 1123;
const MIN_ZOOM = 0.3;
const MAX_ZOOM = 2.5;
const ZOOM_STEP = 0.1;
const CANVAS_PADDING = 48;

function clampZoom(z) {
  return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(z * 100) / 100));
}

function waitForReflow() {
  return new Promise((resolve) => setTimeout(resolve, 50));
}

// VAT Return's equivalent of the Invoice/Purchase Viewer - identical
// architecture, reused per "reuse existing Viewer... wherever possible".
// Only PDF + Print are wired here (no PNG) per this sprint's explicit scope.
// Reads the one getVatReturn snapshot only, no live Invoice/Purchase/Tax
// Master calls.
export default function VatReturnViewerPage() {
  const params = useParams();
  const router = useRouter();
  const documentRef = useRef(null);
  const scrollRef = useRef(null);
  const outerRef = useRef(null);
  const hasAutoFit = useRef(false);

  const [vatReturn, setVatReturn] = useState(null);
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);

  const [zoom, setZoom] = useState(1);
  const [naturalHeight, setNaturalHeight] = useState(PAGE_HEIGHT_PX);
  const [currentPage, setCurrentPage] = useState(1);
  const [fullScreen, setFullScreen] = useState(false);
  const [capturing, setCapturing] = useState(false);

  const pageCount = Math.max(1, Math.ceil(naturalHeight / PAGE_HEIGHT_PX));

  useEffect(() => {
    (async () => {
      setError("");
      try {
        const token = tenantAuth.get();
        const { vatReturn } = await api.getVatReturn(token, params.id);
        setVatReturn(vatReturn);
        api.logVatReturnActivity(token, params.id, "VIEWED", null).catch(() => {});
      } catch (err) {
        setError(err.message);
      }
    })();
  }, [params.id]);

  useEffect(() => {
    if (!documentRef.current) return;
    const el = documentRef.current;
    const measure = () => setNaturalHeight(el.offsetHeight / (zoom || 1));
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    measure();
    return () => observer.disconnect();
  }, [vatReturn, zoom]);

  useEffect(() => {
    if (hasAutoFit.current) return;
    if (!vatReturn || !scrollRef.current) return;
    hasAutoFit.current = true;
    fitToWidth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vatReturn, naturalHeight]);

  useEffect(() => {
    function handleFsChange() {
      if (!document.fullscreenElement) setFullScreen(false);
    }
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  function zoomIn() {
    setZoom((z) => clampZoom(z + ZOOM_STEP));
  }
  function zoomOut() {
    setZoom((z) => clampZoom(z - ZOOM_STEP));
  }
  function fitToWidth() {
    if (!scrollRef.current) return;
    const available = scrollRef.current.clientWidth - CANVAS_PADDING;
    setZoom(clampZoom(available / A4_WIDTH_PX));
  }
  function fitToPage() {
    if (!scrollRef.current) return;
    const availableW = scrollRef.current.clientWidth - CANVAS_PADDING;
    const availableH = scrollRef.current.clientHeight - CANVAS_PADDING;
    setZoom(clampZoom(Math.min(availableW / A4_WIDTH_PX, availableH / PAGE_HEIGHT_PX)));
  }

  function goToPage(n) {
    const target = Math.min(pageCount, Math.max(1, n));
    if (!scrollRef.current) return;
    scrollRef.current.scrollTop = (target - 1) * PAGE_HEIGHT_PX * zoom;
    setCurrentPage(target);
  }

  function handleScroll() {
    if (!scrollRef.current) return;
    const p = Math.floor(scrollRef.current.scrollTop / (PAGE_HEIGHT_PX * zoom)) + 1;
    setCurrentPage(Math.min(pageCount, Math.max(1, p)));
  }

  async function toggleFullScreen() {
    const next = !fullScreen;
    setFullScreen(next);
    try {
      if (next && outerRef.current?.requestFullscreen) {
        await outerRef.current.requestFullscreen();
      } else if (!next && document.fullscreenElement) {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen API unavailable/blocked - CSS-driven full-screen layout still applies.
    }
  }

  async function withNaturalZoom(action) {
    const previousZoom = zoom;
    setCapturing(true);
    setZoom(1);
    await waitForReflow();
    try {
      await action();
    } finally {
      setZoom(previousZoom);
      setCapturing(false);
    }
  }

  async function handleDownloadPdf() {
    if (!documentRef.current || exporting) return;
    setExporting(true);
    try {
      await withNaturalZoom(async () => {
        const { jsPDF } = await import("jspdf");
        const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
        await doc.html(documentRef.current, {
          x: 0,
          y: 0,
          width: 210,
          windowWidth: documentRef.current.offsetWidth,
          autoPaging: "text",
        });
        doc.save(`${vatReturn.periodLabel.replace(/\s+/g, "-")}-VAT-Return.pdf`);
      });
      const token = tenantAuth.get();
      api.logVatReturnActivity(token, params.id, "EXPORTED", "PDF").catch(() => {});
    } catch (err) {
      setError(`Could not generate PDF: ${err.message}`);
    } finally {
      setExporting(false);
    }
  }

  async function handlePrint() {
    await withNaturalZoom(async () => {
      window.print();
    });
  }

  if (!vatReturn) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "VAT Returns", href: "/tenant/vat-returns" }, { label: "…" }]} title="VAT Return Preview" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const Template = getVatReturnTemplateComponent(DEFAULT_VAT_RETURN_TEMPLATE);
  const title = vatReturn.periodLabel;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "VAT Returns", href: "/tenant/vat-returns" }, { label: title }, { label: "Preview" }]}
        title="VAT Return Preview"
        description="Ready for review — a professional, read-only summary of this return."
      />

      <ErrorBanner message={error} />

      <div ref={outerRef} className={`invoice-viewer-root${fullScreen ? " invoice-viewer-fullscreen" : ""}`}>
        <div className="invoice-viewer-toolbar">
          <div className="invoice-viewer-toolbar-group">
            <Button variant="outline" onClick={() => router.back()}>
              Back
            </Button>
            <Link href={`/tenant/vat-returns/${vatReturn.id}`}>
              <Button variant="outline">Back to Return</Button>
            </Link>
          </div>

          <div className="invoice-viewer-toolbar-group">
            <button type="button" className="btn btn-outline btn-sm" onClick={zoomOut} disabled={zoom <= MIN_ZOOM} aria-label="Zoom out">
              −
            </button>
            <span className="invoice-viewer-zoom-value">{Math.round(zoom * 100)}%</span>
            <button type="button" className="btn btn-outline btn-sm" onClick={zoomIn} disabled={zoom >= MAX_ZOOM} aria-label="Zoom in">
              +
            </button>
            <button type="button" className="btn btn-outline btn-sm" onClick={fitToWidth}>
              Fit Width
            </button>
            <button type="button" className="btn btn-outline btn-sm" onClick={fitToPage}>
              Fit Page
            </button>
          </div>

          {pageCount > 1 && (
            <div className="invoice-viewer-toolbar-group">
              <button type="button" className="btn btn-outline btn-sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage <= 1} aria-label="Previous page">
                ‹
              </button>
              <span className="invoice-viewer-page-indicator">
                Page {currentPage} of {pageCount}
              </span>
              <button type="button" className="btn btn-outline btn-sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage >= pageCount} aria-label="Next page">
                ›
              </button>
            </div>
          )}

          <div className="invoice-viewer-toolbar-group invoice-viewer-toolbar-actions">
            <button type="button" className="btn btn-outline btn-sm" onClick={toggleFullScreen}>
              {fullScreen ? "Exit Full Screen" : "Full Screen"}
            </button>
            <Button variant="outline" onClick={handlePrint} disabled={exporting}>
              Print
            </Button>
            <Button onClick={handleDownloadPdf} disabled={exporting}>
              {exporting ? "Working…" : "Download PDF"}
            </Button>
          </div>
        </div>

        <div className="invoice-viewer-canvas" ref={scrollRef} onScroll={handleScroll}>
          <div className="invoice-doc-zoom-wrap" style={{ zoom }}>
            {!capturing && pageCount > 1 && (
              <div className="invoice-doc-page-guides" aria-hidden="true">
                {Array.from({ length: pageCount - 1 }).map((_, i) => (
                  <div key={i} className="invoice-doc-page-guide" style={{ top: (i + 1) * PAGE_HEIGHT_PX }}>
                    <span>Page {i + 2}</span>
                  </div>
                ))}
              </div>
            )}
            <Template vatReturn={vatReturn} ref={documentRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
