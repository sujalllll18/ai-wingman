"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { downloadVatReturnExcel } from "../../../../lib/exportVatReturnExcel";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import VatReturnStatusBadge from "../../../../components/vat-returns/VatReturnStatusBadge";
import VatSummaryTable from "../../../../components/vat-returns/VatSummaryTable";
import VatDrilldownModal from "../../../../components/vat-returns/VatDrilldownModal";
import ValidationPanel from "../../../../components/vat-returns/ValidationPanel";
import VatReturnActivityTimeline from "../../../../components/vat-returns/VatReturnActivityTimeline";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

export default function VatReturnDetailPage() {
  const params = useParams();
  const { showToast } = useToast();

  const [vatReturn, setVatReturn] = useState(null);
  const [warnings, setWarnings] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmAction, setConfirmAction] = useState(null); // "lock" | "unlock" | "regenerate"
  const [drilldown, setDrilldown] = useState(null); // { type, category, label }
  const [exportingExcel, setExportingExcel] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { vatReturn, warnings } = await api.getVatReturn(token, params.id);
      setVatReturn(vatReturn);
      setWarnings(warnings);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRegenerate() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { vatReturn } = await api.regenerateVatReturn(token, params.id);
      setVatReturn(vatReturn);
      setConfirmAction(null);
      showToast("VAT Return recalculated from the latest data.");
      load();
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleLock() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { vatReturn } = await api.lockVatReturn(token, params.id);
      setVatReturn(vatReturn);
      setConfirmAction(null);
      showToast("VAT Return locked. It's now read-only until unlocked.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleUnlock() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { vatReturn } = await api.unlockVatReturn(token, params.id);
      setVatReturn(vatReturn);
      setConfirmAction(null);
      showToast("VAT Return unlocked and editable again.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleExportExcel() {
    setExportingExcel(true);
    try {
      await downloadVatReturnExcel(vatReturn);
      const token = tenantAuth.get();
      api.logVatReturnActivity(token, params.id, "EXPORTED", "Excel").catch(() => {});
      showToast("Excel file downloaded.");
    } catch (err) {
      showToast(err.message);
    } finally {
      setExportingExcel(false);
    }
  }

  if (!vatReturn) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "VAT Returns", href: "/tenant/vat-returns" }, { label: "…" }]} title="VAT Return" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const isDraft = vatReturn.status === "DRAFT";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "VAT Returns", href: "/tenant/vat-returns" }, { label: vatReturn.periodLabel }]}
        title={vatReturn.periodLabel}
        eyebrow={<VatReturnStatusBadge vatReturn={vatReturn} />}
        description={`${vatReturn.periodType === "MONTHLY" ? "Monthly" : "Quarterly"} return · ${vatReturn.salesInvoiceCount} sales invoice(s) · ${vatReturn.purchaseBillCount} purchase bill(s)`}
        action={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Link href={`/tenant/vat-returns/${vatReturn.id}/view`}>
              <Button variant="outline">Preview</Button>
            </Link>
            <Button variant="outline" onClick={handleExportExcel} disabled={exportingExcel}>
              {exportingExcel ? "Working…" : "Export Excel"}
            </Button>
            {isDraft ? (
              <>
                <Button variant="outline" onClick={() => setConfirmAction("regenerate")} disabled={busy}>
                  Regenerate
                </Button>
                <Button onClick={() => setConfirmAction("lock")} disabled={busy}>
                  Lock Return
                </Button>
              </>
            ) : (
              <Button variant="outline" onClick={() => setConfirmAction("unlock")} disabled={busy}>
                Unlock Return
              </Button>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      <div className="kpi-card-grid">
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Output VAT</span></div>
          <span className="kpi-card-value">{formatCurrency(vatReturn.outputVat)}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Input VAT</span></div>
          <span className="kpi-card-value">{formatCurrency(vatReturn.inputVat)}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">{vatReturn.netVatPayable >= 0 ? "Net VAT Payable" : "Net VAT Refundable"}</span></div>
          <span className="kpi-card-value">{formatCurrency(Math.abs(vatReturn.netVatPayable))}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Total Sales</span></div>
          <span className="kpi-card-value">{formatCurrency(vatReturn.totalSales)}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Total Purchases</span></div>
          <span className="kpi-card-value">{formatCurrency(vatReturn.totalPurchases)}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Sales Invoices</span></div>
          <span className="kpi-card-value">{vatReturn.salesInvoiceCount}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Purchase Bills</span></div>
          <span className="kpi-card-value">{vatReturn.purchaseBillCount}</span>
        </div>
        <div className="kpi-card">
          <div className="kpi-card-top"><span className="kpi-card-label">Tax Period</span></div>
          <span className="kpi-card-value" style={{ fontSize: 18 }}>{vatReturn.periodLabel}</span>
        </div>
      </div>

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <VatSummaryTable vatReturn={vatReturn} onDrilldown={(type, category, label) => setDrilldown({ type, category, label })} />
        </div>

        <div className="detail-rail">
          <ValidationPanel warnings={warnings} />
          <Card>
            <h3 style={{ marginTop: 0 }}>Activity</h3>
            <VatReturnActivityTimeline activities={vatReturn.activities} />
          </Card>
        </div>
      </div>

      <VatDrilldownModal
        open={!!drilldown}
        onClose={() => setDrilldown(null)}
        vatReturnId={vatReturn.id}
        type={drilldown?.type}
        category={drilldown?.category}
        label={drilldown?.label}
      />

      <ConfirmationDialog
        open={confirmAction === "regenerate"}
        title="Regenerate this VAT Return?"
        message="Recalculates every figure from the current Sent invoices and Recorded purchase bills in this period. Any transactions added or changed since it was last generated will now be reflected."
        confirmLabel="Regenerate"
        busy={busy}
        onConfirm={handleRegenerate}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "lock"}
        title="Lock this VAT Return?"
        message="A locked return becomes fully read-only - no regenerating, no edits - until you unlock it again."
        confirmLabel="Lock Return"
        busy={busy}
        onConfirm={handleLock}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "unlock"}
        title="Unlock this VAT Return?"
        message="Makes this return editable and regeneratable again."
        confirmLabel="Unlock Return"
        variant="danger"
        busy={busy}
        onConfirm={handleUnlock}
        onCancel={() => setConfirmAction(null)}
      />
    </div>
  );
}
