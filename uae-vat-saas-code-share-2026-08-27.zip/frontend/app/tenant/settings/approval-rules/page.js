"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Select from "../../../../components/ui/Select";

export default function ApprovalRulesPage() {
  const { allowed, loading: permLoading } = useRequirePermission("approvals.configure");
  const { showToast } = useToast();

  const [rules, setRules] = useState(null);
  const [roles, setRoles] = useState([]);
  const [error, setError] = useState("");
  const [moduleFilter, setModuleFilter] = useState("ALL");
  const [savingKey, setSavingKey] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const [{ rules }, { roles }] = await Promise.all([api.listApprovalRules(token), api.listRoles(token)]);
      setRules(rules);
      setRoles(roles.filter((r) => r.status === "ACTIVE"));
    } catch (err) {
      setError(err.message);
    }
  }

  const modules = useMemo(() => {
    if (!rules) return [];
    return Array.from(new Set(rules.map((r) => r.module))).sort();
  }, [rules]);

  const filtered = useMemo(() => {
    if (!rules) return [];
    return moduleFilter === "ALL" ? rules : rules.filter((r) => r.module === moduleFilter);
  }, [rules, moduleFilter]);

  async function persist(permissionKey, patch) {
    const current = rules.find((r) => r.permissionKey === permissionKey);
    const next = { ...current, ...patch };
    setSavingKey(permissionKey);
    try {
      const token = tenantAuth.get();
      const { rule } = await api.upsertApprovalRule(token, permissionKey, {
        requiresApproval: next.requiresApproval,
        approverRoleId: next.approverRoleId,
        makerCannotApproveOwn: next.makerCannotApproveOwn,
        isActive: next.isActive,
      });
      setRules((prev) =>
        prev.map((r) =>
          r.permissionKey === permissionKey
            ? { ...r, requiresApproval: rule.requiresApproval, approverRoleId: rule.approverRoleId, approverRoleName: rule.approverRole?.name ?? null, makerCannotApproveOwn: rule.makerCannotApproveOwn, isActive: rule.isActive }
            : r
        )
      );
      showToast(`${current.label} rule updated.`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setSavingKey(null);
    }
  }

  const COLUMNS = [
    { key: "moduleLabel", header: "Module", render: (r) => r.moduleLabel },
    { key: "label", header: "Action", render: (r) => r.label },
    {
      key: "requiresApproval",
      header: "Behavior",
      render: (r) => (
        <label className="checkbox-row" style={{ marginTop: 0 }}>
          <input
            type="checkbox"
            checked={r.requiresApproval}
            disabled={savingKey === r.permissionKey}
            onChange={(e) => persist(r.permissionKey, { requiresApproval: e.target.checked })}
          />
          {r.requiresApproval ? "Maker-Checker" : "Immediate Execution"}
        </label>
      ),
    },
    {
      key: "approverRoleId",
      header: "Approver Role",
      render: (r) => (
        <Select
          value={r.approverRoleId || ""}
          disabled={!r.requiresApproval || savingKey === r.permissionKey}
          onChange={(e) => persist(r.permissionKey, { approverRoleId: e.target.value || null })}
        >
          <option value="">Any role with {r.module}.approve</option>
          {roles.map((role) => (
            <option key={role.id} value={role.id}>
              {role.name}
            </option>
          ))}
        </Select>
      ),
    },
    {
      key: "makerCannotApproveOwn",
      header: "Maker ≠ Checker",
      render: (r) => (
        <label className="checkbox-row" style={{ marginTop: 0 }}>
          <input
            type="checkbox"
            checked={r.makerCannotApproveOwn}
            disabled={!r.requiresApproval || savingKey === r.permissionKey}
            onChange={(e) => persist(r.permissionKey, { makerCannotApproveOwn: e.target.checked })}
          />
          Required
        </label>
      ),
    },
    {
      key: "isActive",
      header: "Active",
      render: (r) => (
        <label className="checkbox-row" style={{ marginTop: 0 }}>
          <input
            type="checkbox"
            checked={r.isActive}
            disabled={!r.requiresApproval || savingKey === r.permissionKey}
            onChange={(e) => persist(r.permissionKey, { isActive: e.target.checked })}
          />
        </label>
      ),
    },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        title="Approval Workflow"
        description="Choose which actions across Ledger require a second person's approval before they take effect. Everything defaults to Immediate Execution until turned on here."
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {rules === null ? (
          <LoadingSkeleton columns={5} />
        ) : (
          <>
            <Toolbar
              title="Approval Rules"
              filters={
                <select className="select-filter" value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)}>
                  <option value="ALL">All modules</option>
                  {modules.map((m) => (
                    <option key={m} value={m}>
                      {filtered.find((r) => r.module === m)?.moduleLabel || m}
                    </option>
                  ))}
                </select>
              }
            />
            <TableScroll>
              <Table columns={COLUMNS} rows={filtered} rowKey={(r) => r.permissionKey} />
            </TableScroll>
          </>
        )}
      </div>
    </div>
  );
}
