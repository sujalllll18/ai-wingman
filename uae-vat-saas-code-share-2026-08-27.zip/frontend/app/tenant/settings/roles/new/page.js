"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import RoleFormFields from "../../../../../components/rbac/RoleFormFields";
import PermissionMatrix from "../../../../../components/rbac/PermissionMatrix";
import { usePermissions } from "../../../../../hooks/usePermissions";
import { useRequirePermission } from "../../../../../hooks/useRequirePermission";

export default function CreateRolePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const cloneParam = searchParams.get("clone");
  const { allowed, loading: permLoading } = useRequirePermission("roles.create");
  const { showToast } = useToast();
  const { startPreview } = usePermissions();

  const [catalog, setCatalog] = useState(null);
  const [moduleLabels, setModuleLabels] = useState({});
  const [roles, setRoles] = useState([]);
  const [form, setForm] = useState({ name: "", code: "", description: "", status: "ACTIVE", cloneFromRoleId: cloneParam || null });
  const [selectedKeys, setSelectedKeys] = useState(new Set());
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      const token = tenantAuth.get();
      try {
        const [catalogRes, rolesRes] = await Promise.all([api.getPermissionCatalog(token), api.listRoles(token)]);
        setCatalog(catalogRes.permissions);
        setModuleLabels(catalogRes.moduleLabels || {});
        setRoles(rolesRes.roles);

        if (cloneParam) {
          const { role } = await api.getRole(token, cloneParam);
          setSelectedKeys(new Set(role.permissionKeys));
        }
      } catch (err) {
        setError(err.message);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-seeds the matrix from the newly-picked clone source's CURRENT
  // permissions - only fires on an explicit dropdown change, never
  // overwrites in-progress matrix edits on its own (see the effect above,
  // which only runs once on mount from the ?clone= query param).
  async function handleCloneChange(roleId) {
    setForm((f) => ({ ...f, cloneFromRoleId: roleId }));
    if (!roleId) return;
    try {
      const token = tenantAuth.get();
      const { role } = await api.getRole(token, roleId);
      setSelectedKeys(new Set(role.permissionKeys));
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.code.trim()) {
      setError("Role Name and Short Code are required.");
      return;
    }

    setSubmitting(true);
    setError("");
    try {
      const token = tenantAuth.get();
      const { role } = await api.createRole(token, {
        name: form.name.trim(),
        code: form.code.trim(),
        description: form.description || null,
        status: form.status,
        cloneFromRoleId: form.cloneFromRoleId || null,
        permissionKeys: Array.from(selectedKeys),
      });
      showToast(`${role.name} created.`);
      router.push(`/tenant/settings/roles/${role.id}`);
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Roles & Permissions", href: "/tenant/settings/roles" }, { label: "Create Role" }]}
        title="Create Role"
        description="Define who this role is for and exactly what it can do."
      />

      <ErrorBanner message={error} />

      {catalog === null ? (
        <LoadingSkeleton columns={4} />
      ) : (
        <form onSubmit={handleSubmit} className="content-narrow">
          <Card>
            <h2 style={{ marginBottom: 4 }}>Role Details</h2>
            <p className="form-section-desc">Start blank, or clone an existing role to copy its permissions as a starting point.</p>
            <div style={{ marginTop: 16 }}>
              <RoleFormFields
                form={form}
                onChange={(next) => {
                  if (next.cloneFromRoleId !== form.cloneFromRoleId) {
                    handleCloneChange(next.cloneFromRoleId);
                    setForm((f) => ({ ...f, ...next, cloneFromRoleId: next.cloneFromRoleId }));
                  } else {
                    setForm(next);
                  }
                }}
                cloneableRoles={roles}
                showClone
                disabled={submitting}
              />
            </div>
          </Card>

          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h2 style={{ marginBottom: 4 }}>Permission Matrix</h2>
                <p className="form-section-desc">Grouped by area - expand a group to see and set individual module permissions.</p>
              </div>
              <Button
                type="button"
                variant="outline"
                disabled={selectedKeys.size === 0}
                onClick={() => {
                  startPreview(Array.from(selectedKeys), form.name || "This Role");
                  router.push("/tenant/dashboard");
                }}
              >
                Preview as this Role
              </Button>
            </div>
            <div style={{ marginTop: 16 }}>
              <PermissionMatrix catalog={catalog} moduleLabels={moduleLabels} selectedKeys={selectedKeys} onChange={(keys) => setSelectedKeys(new Set(keys))} disabled={submitting} />
            </div>
          </Card>

          <div className="dialog-actions" style={{ justifyContent: "flex-start" }}>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Creating…" : "Create Role"}
            </Button>
            <Button type="button" variant="outline" onClick={() => router.push("/tenant/settings/roles")} disabled={submitting}>
              Cancel
            </Button>
          </div>
        </form>
      )}
    </div>
  );
}
