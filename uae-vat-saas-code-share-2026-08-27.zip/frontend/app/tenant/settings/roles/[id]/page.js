"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Tabs from "../../../../../components/ui/Tabs";
import Tooltip from "../../../../../components/ui/Tooltip";
import EmptyState from "../../../../../components/ui/EmptyState";
import RoleFormFields from "../../../../../components/rbac/RoleFormFields";
import PermissionMatrix from "../../../../../components/rbac/PermissionMatrix";
import AssignUsersPanel from "../../../../../components/rbac/AssignUsersPanel";
import { usePermissions } from "../../../../../hooks/usePermissions";
import { useRequirePermission } from "../../../../../hooks/useRequirePermission";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "permissions", label: "Permissions" },
  { key: "users", label: "Assigned Users" },
];

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function RoleDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("roles.view");
  const { showToast } = useToast();
  const { startPreview } = usePermissions();

  const [role, setRole] = useState(null);
  const [catalog, setCatalog] = useState(null);
  const [moduleLabels, setModuleLabels] = useState({});
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("overview");

  const [form, setForm] = useState(null);
  const [selectedKeys, setSelectedKeys] = useState(new Set());
  const [savingOverview, setSavingOverview] = useState(false);
  const [savingPermissions, setSavingPermissions] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const [roleRes, catalogRes] = await Promise.all([api.getRole(token, params.id), api.getPermissionCatalog(token)]);
      setRole(roleRes.role);
      setForm({ name: roleRes.role.name, code: roleRes.role.code, description: roleRes.role.description || "", status: roleRes.role.status, isSystem: roleRes.role.isSystem });
      setSelectedKeys(new Set(roleRes.role.permissionKeys));
      setCatalog(catalogRes.permissions);
      setModuleLabels(catalogRes.moduleLabels || {});
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleSaveOverview() {
    setSavingOverview(true);
    setError("");
    try {
      const token = tenantAuth.get();
      await api.updateRole(token, role.id, { name: form.name, description: form.description, status: form.status });
      showToast("Role details saved.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingOverview(false);
    }
  }

  async function handleSavePermissions() {
    setSavingPermissions(true);
    setError("");
    try {
      const token = tenantAuth.get();
      await api.updateRolePermissions(token, role.id, Array.from(selectedKeys));
      showToast("Permissions saved.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingPermissions(false);
    }
  }

  if (permLoading || !allowed) return null;

  if (role === null || catalog === null) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Roles & Permissions", href: "/tenant/settings/roles" }, { label: "…" }]} title="Role Details" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const isOwnerRole = role.code === "OWNER";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Roles & Permissions", href: "/tenant/settings/roles" }, { label: role.name }]}
        title={role.name}
        description={role.description || "No description."}
        action={<span className={`badge ${role.status === "ACTIVE" ? "badge-success" : "badge-info"}`}>{role.status === "ACTIVE" ? "Active" : "Inactive"}</span>}
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={setActiveTab} />

      <div className="content-narrow" style={{ marginTop: 20 }}>
        {activeTab === "overview" && (
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
              <h2>Role Details</h2>
              {role.isSystem && (
                <Tooltip label="System roles' names and codes are fixed - description and status can still be adjusted.">
                  <span className="badge badge-info">System Role</span>
                </Tooltip>
              )}
            </div>
            <div className="review-list" style={{ marginBottom: 16 }}>
              <div className="review-row">
                <span className="review-label">Created By</span>
                <span className="review-value">{role.createdByName}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Created Date</span>
                <span className="review-value">{formatDate(role.createdAt)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Permissions</span>
                <span className="review-value">{role.permissionKeys.length}</span>
              </div>
              <div className="review-row">
                <span className="review-label">Users Assigned</span>
                <span className="review-value">{role.users.length}</span>
              </div>
            </div>

            <RoleFormFields form={form} onChange={setForm} cloneableRoles={[]} showClone={false} disabled={savingOverview || role.isSystem} />
            {role.isSystem && <p className="helptext">This is a system role - name and short code are fixed. Description and status can still be changed.</p>}

            <div className="dialog-actions" style={{ justifyContent: "flex-start", marginTop: 8 }}>
              <Button onClick={handleSaveOverview} disabled={savingOverview}>
                {savingOverview ? "Saving…" : "Save Changes"}
              </Button>
            </div>
          </Card>
        )}

        {activeTab === "permissions" && (
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h2 style={{ marginBottom: 4 }}>Permission Matrix</h2>
                <p className="form-section-desc">
                  {isOwnerRole ? "The Owner role always has every permission and can't be edited - shown here read-only." : "Grouped by area - expand a group to adjust individual module permissions."}
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  startPreview(Array.from(selectedKeys), role.name);
                  router.push("/tenant/dashboard");
                }}
              >
                Preview as this Role
              </Button>
            </div>
            <div style={{ marginTop: 16 }}>
              <PermissionMatrix
                catalog={catalog}
                moduleLabels={moduleLabels}
                selectedKeys={selectedKeys}
                onChange={(keys) => setSelectedKeys(new Set(keys))}
                disabled={savingPermissions}
                readOnly={isOwnerRole}
              />
            </div>
            {!isOwnerRole && (
              <div className="dialog-actions" style={{ justifyContent: "flex-start", marginTop: 16 }}>
                <Button onClick={handleSavePermissions} disabled={savingPermissions}>
                  {savingPermissions ? "Saving…" : "Save Permissions"}
                </Button>
              </div>
            )}
          </Card>
        )}

        {activeTab === "users" && (
          <>
            <Card>
              <h2 style={{ marginBottom: 4 }}>Currently Assigned</h2>
              <p className="form-section-desc">Everyone whose primary role is {role.name}.</p>
              <div style={{ marginTop: 16 }}>
                {role.users.length === 0 ? (
                  <EmptyState title="No one has this role yet" description="Assign someone below." />
                ) : (
                  <div className="review-list">
                    {role.users.map((u) => (
                      <div className="review-row" key={u.id}>
                        <span className="review-label">{u.name}</span>
                        <span className="review-value" style={{ fontWeight: 400, color: "var(--color-ink-soft)" }}>
                          {u.email}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>

            {role.status === "ACTIVE" ? (
              <Card>
                <h2 style={{ marginBottom: 4 }}>Assign Users</h2>
                <p className="form-section-desc">Assigning someone here replaces their current primary role - each person has exactly one at a time.</p>
                <div style={{ marginTop: 16 }}>
                  <AssignUsersPanel roleId={role.id} currentUserIds={role.users.map((u) => u.id)} onAssigned={load} showToast={showToast} />
                </div>
              </Card>
            ) : (
              <Card>
                <p className="helptext">This role is inactive - activate it from the Overview tab before assigning users.</p>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
