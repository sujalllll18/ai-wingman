"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Button from "../../../../components/ui/Button";
import Tooltip from "../../../../components/ui/Tooltip";
import ActionMenu from "../../../../components/ui/ActionMenu";
import Pagination from "../../../../components/ui/Pagination";
import Can from "../../../../components/rbac/Can";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function RolesListPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("roles.view");
  const { showToast } = useToast();
  const [roles, setRoles] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { roles } = await api.listRoles(token);
      setRoles(roles);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  async function handleToggleStatus(role) {
    try {
      const token = tenantAuth.get();
      await api.updateRole(token, role.id, { status: role.status === "ACTIVE" ? "INACTIVE" : "ACTIVE" });
      showToast(`${role.name} ${role.status === "ACTIVE" ? "deactivated" : "activated"}.`);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(role) {
    try {
      const token = tenantAuth.get();
      await api.deleteRole(token, role.id);
      showToast(`${role.name} deleted.`);
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  const filtered = useMemo(() => {
    if (!roles) return [];
    const q = search.trim().toLowerCase();
    return roles.filter((r) => {
      const matchesSearch = !q || r.name.toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [roles, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  const COLUMNS = [
    { key: "name", header: "Role Name", render: (r) => <Link href={`/tenant/settings/roles/${r.id}`}>{r.name}</Link> },
    { key: "description", header: "Description", render: (r) => r.description || <span style={{ color: "var(--color-ink-faint)" }}>—</span> },
    { key: "usersAssigned", header: "Users", className: "num", render: (r) => r.usersAssigned },
    { key: "permissionsCount", header: "Permissions", className: "num", render: (r) => r.permissionsCount },
    { key: "createdByName", header: "Created By", render: (r) => r.createdByName },
    { key: "createdAt", header: "Created Date", render: (r) => formatDate(r.createdAt) },
    { key: "status", header: "Status", render: (r) => <span className={`badge ${r.status === "ACTIVE" ? "badge-success" : "badge-info"}`}>{r.status === "ACTIVE" ? "Active" : "Inactive"}</span> },
    {
      key: "actions",
      header: "",
      className: "num",
      render: (r) => (
        <ActionMenu
          ariaLabel={`Actions for ${r.name}`}
          items={[
            { label: "View Details", onClick: () => router.push(`/tenant/settings/roles/${r.id}`) },
            { label: "Clone Role", onClick: () => router.push(`/tenant/settings/roles/new?clone=${r.id}`) },
            {
              label: r.status === "ACTIVE" ? "Deactivate" : "Activate",
              onClick: () => handleToggleStatus(r),
              disabled: r.code === "OWNER",
              disabledReason: "The Owner role must always stay active.",
            },
            {
              label: "Delete",
              danger: true,
              onClick: () => handleDelete(r),
              disabled: r.isSystem || r.usersAssigned > 0,
              disabledReason: r.isSystem ? "System roles cannot be deleted." : "Reassign this role's users before deleting it.",
            },
          ]}
        />
      ),
    },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        title="Roles & Permissions"
        description="Control who can do what across your business - roles are the single source of truth every module checks."
        action={
          <Can permission="roles.create">
            <Link href="/tenant/settings/roles/new">
              <Button>+ Create Role</Button>
            </Link>
          </Can>
        }
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {roles === null ? (
          <LoadingSkeleton columns={7} />
        ) : (
          <>
            <Toolbar
              title="Roles"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by name or description…"
              filters={
                <select
                  className="select-filter"
                  value={statusFilter}
                  onChange={(e) => {
                    setStatusFilter(e.target.value);
                    resetToPageOne();
                  }}
                >
                  <option value="ALL">All statuses</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching roles"
                description="Try a different search term or clear the status filter."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Roles"
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
