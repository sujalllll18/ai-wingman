"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useLocalStorageState } from "../../../hooks/useLocalStorageState";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import DataTable from "../../../components/ui/DataTable";
import TableScroll from "../../../components/ui/TableScroll";
import ColumnSelector from "../../../components/ui/ColumnSelector";
import Toolbar from "../../../components/ui/Toolbar";
import Tooltip from "../../../components/ui/Tooltip";
import Button from "../../../components/ui/Button";
import AddCustomerModal from "../../../components/customers/AddCustomerModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";

const NOT_TRACKED = "Not tracked on customer records yet";

function customerCode(id) {
  return `CUS-${id.slice(0, 8).toUpperCase()}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function NotTracked({ label }) {
  return (
    <Tooltip label={label}>
      <span style={{ color: "var(--color-ink-faint)" }}>—</span>
    </Tooltip>
  );
}

function sortCustomers(list, key, direction) {
  const sorted = [...list];
  sorted.sort((a, b) => {
    let av = a[key];
    let bv = b[key];
    if (key === "createdAt") {
      av = new Date(av).getTime();
      bv = new Date(bv).getTime();
    } else {
      av = (av || "").toString().toLowerCase();
      bv = (bv || "").toString().toLowerCase();
    }
    if (av < bv) return direction === "asc" ? -1 : 1;
    if (av > bv) return direction === "asc" ? 1 : -1;
    return 0;
  });
  return sorted;
}

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

export default function CustomersPage() {
  const { allowed, loading: permLoading } = useRequirePermission("customers.view");
  const { showToast } = useToast();

  const [customers, setCustomers] = useState(null);
  const [error, setError] = useState("");
  const [addOpen, setAddOpen] = useState(false);

  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [vatFilter, setVatFilter] = useState("ALL");
  const [sortKey, setSortKey] = useState("createdAt");
  const [sortDirection, setSortDirection] = useState("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { customers } = await api.listCustomers(token);
      setCustomers(customers);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  const COLUMN_DEFS = useMemo(
    () => [
      { key: "code", label: "Customer Code", alwaysVisible: true, render: (c) => <span className="mono">{customerCode(c.id)}</span> },
      { key: "name", label: "Customer Name", alwaysVisible: true, sortable: true, render: (c) => c.name },
      {
        key: "customerType",
        label: "Customer Type",
        sortable: true,
        render: (c) => <span className={`badge ${c.customerType === "BUSINESS" ? "badge-info" : "badge-premium"}`}>{c.customerType === "BUSINESS" ? "Business" : "Individual"}</span>,
      },
      { key: "trn", label: "TRN", render: (c) => (c.trn ? <span className="mono">{c.trn}</span> : "—") },
      { key: "contactPerson", label: "Contact Person", render: () => <NotTracked label={NOT_TRACKED} /> },
      { key: "email", label: "Email", render: () => <NotTracked label={NOT_TRACKED} /> },
      { key: "phone", label: "Phone", render: () => <NotTracked label={NOT_TRACKED} /> },
      { key: "emirate", label: "Emirate", render: () => <NotTracked label={NOT_TRACKED} /> },
      {
        key: "status",
        label: "Status",
        sortable: true,
        render: (c) => <span className={`badge ${c.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{c.status === "ACTIVE" ? "Active" : "Inactive"}</span>,
      },
      { key: "createdAt", label: "Created Date", sortable: true, render: (c) => formatDate(c.createdAt) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (c) => (
          <Link href={`/tenant/customers/${c.id}?name=${encodeURIComponent(c.name)}`} className="btn btn-outline btn-sm">
            Manage
          </Link>
        ),
      },
    ],
    []
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_customer_list_column_order", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_customer_list_hidden_columns", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const stats = useMemo(() => {
    if (!customers) return null;
    return {
      total: customers.length,
      active: customers.filter((c) => c.status === "ACTIVE").length,
      inactive: customers.filter((c) => c.status === "INACTIVE").length,
      business: customers.filter((c) => c.customerType === "BUSINESS").length,
      individual: customers.filter((c) => c.customerType === "INDIVIDUAL").length,
    };
  }, [customers]);

  const filtered = useMemo(() => {
    if (!customers) return [];
    const q = search.trim().toLowerCase();
    let list = customers.filter((c) => {
      const matchesSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        customerCode(c.id).toLowerCase().includes(q) ||
        (c.trn || "").toLowerCase().includes(q);
      const matchesType = typeFilter === "ALL" || c.customerType === typeFilter;
      const matchesStatus = statusFilter === "ALL" || c.status === statusFilter;
      const matchesVat = vatFilter === "ALL" || (vatFilter === "REGISTERED" ? !!c.trn : !c.trn);
      return matchesSearch && matchesType && matchesStatus && matchesVat;
    });
    return sortCustomers(list, sortKey, sortDirection);
  }, [customers, search, typeFilter, statusFilter, vatFilter, sortKey, sortDirection]);

  function handleSortChange(key) {
    if (sortKey === key) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDirection("asc");
    }
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  function handleCustomerCreated(name, approvalRequest) {
    setAddOpen(false);
    if (approvalRequest) {
      showToast(`"${name}" requires approval before it's added - submitted as ${approvalRequest.referenceNumber}.`);
    } else {
      showToast(`"${name}" was added successfully.`);
    }
    load();
  }

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Customers" }]}
        title="Customers"
        description="Every customer your business bills or ships to, in one place."
        action={
          <Button onClick={() => setAddOpen(true)}>+ Add Customer</Button>
        }
      />

      <ErrorBanner message={error} />

      {stats && (
        <div className="kpi-card-grid">
          <div className="kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Customers</span>
            </div>
            <span className="kpi-card-value">{stats.total}</span>
          </div>
          <div className="kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Active</span>
            </div>
            <span className="kpi-card-value">{stats.active}</span>
          </div>
          <div className="kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Inactive</span>
            </div>
            <span className="kpi-card-value">{stats.inactive}</span>
          </div>
          <div className="kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Business</span>
            </div>
            <span className="kpi-card-value">{stats.business}</span>
          </div>
          <div className="kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Individual</span>
            </div>
            <span className="kpi-card-value">{stats.individual}</span>
          </div>
        </div>
      )}

      <div className="table-block">
        {customers === null ? (
          <LoadingSkeleton columns={8} />
        ) : customers.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <circle cx="9" cy="8" r="3" />
                <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
                <circle cx="17" cy="9" r="2.4" />
                <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
              </svg>
            }
            title="No customers yet"
            description="Create your first customer."
            action={<Button onClick={() => setAddOpen(true)}>+ Add Customer</Button>}
          />
        ) : (
          <>
            <Toolbar
              title="Customers"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by name, code, or TRN…"
              filters={
                <>
                  <select
                    className="select-filter"
                    value={typeFilter}
                    onChange={(e) => {
                      setTypeFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All types</option>
                    <option value="BUSINESS">Business</option>
                    <option value="INDIVIDUAL">Individual</option>
                  </select>
                  <select
                    className="select-filter"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All statuses</option>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                  <select
                    className="select-filter"
                    value={vatFilter}
                    onChange={(e) => {
                      setVatFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">VAT: All</option>
                    <option value="REGISTERED">VAT Registered</option>
                    <option value="NOT_REGISTERED">Not VAT Registered</option>
                  </select>
                  <Tooltip label="Not available yet — Emirate isn't tracked on customer records">
                    <select className="select-filter" disabled>
                      <option>All Emirates</option>
                    </select>
                  </Tooltip>
                  <Tooltip label="Not available yet — planned for a future sprint">
                    <button type="button" className="btn btn-outline btn-sm" disabled>
                      Export
                    </button>
                  </Tooltip>
                  <Tooltip label="Not available yet — planned for a future sprint">
                    <button type="button" className="btn btn-outline btn-sm" disabled>
                      Import CSV
                    </button>
                  </Tooltip>
                  <ColumnSelector
                    columns={COLUMN_DEFS}
                    columnOrder={columnOrder}
                    hiddenColumns={hiddenColumns}
                    onToggle={handleToggleColumn}
                    onReorder={setColumnOrder}
                  />
                </>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching customers"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable
                    columns={COLUMN_DEFS}
                    rows={pageItems}
                    columnOrder={columnOrder}
                    hiddenColumns={hiddenColumns}
                    sortKey={sortKey}
                    sortDirection={sortDirection}
                    onSortChange={handleSortChange}
                    stickyHeader
                  />
                </TableScroll>
                <div className="table-pagination">
                  <span>
                    Showing {pageStart + 1}–{Math.min(pageStart + pageSize, filtered.length)} of {filtered.length} customers
                  </span>
                  <div className="pagination-controls">
                    <div className="rows-per-page">
                      Rows per page
                      <select
                        className="select-filter"
                        value={pageSize}
                        onChange={(e) => {
                          setPageSize(Number(e.target.value));
                          resetToPageOne();
                        }}
                      >
                        {PAGE_SIZE_OPTIONS.map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="pagination-pages">
                      <button className="page-btn" disabled={currentPage === 1} onClick={() => setPage(1)} aria-label="First page">
                        «
                      </button>
                      <button
                        className="page-btn"
                        disabled={currentPage === 1}
                        onClick={() => setPage(currentPage - 1)}
                        aria-label="Previous page"
                      >
                        ‹
                      </button>
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <button
                          key={i}
                          className={`page-btn${currentPage === i + 1 ? " active" : ""}`}
                          onClick={() => setPage(i + 1)}
                        >
                          {i + 1}
                        </button>
                      ))}
                      <button
                        className="page-btn"
                        disabled={currentPage === totalPages}
                        onClick={() => setPage(currentPage + 1)}
                        aria-label="Next page"
                      >
                        ›
                      </button>
                      <button
                        className="page-btn"
                        disabled={currentPage === totalPages}
                        onClick={() => setPage(totalPages)}
                        aria-label="Last page"
                      >
                        »
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>

      <AddCustomerModal open={addOpen} onClose={() => setAddOpen(false)} onSuccess={handleCustomerCreated} />
    </div>
  );
}
