"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Tabs from "../../../../components/ui/Tabs";
import OverviewTab from "../../../../components/customer-profile/OverviewTab";
import BasicInfoTab from "../../../../components/customer-profile/BasicInfoTab";
import TaxInfoTab from "../../../../components/customer-profile/TaxInfoTab";
import ContactInfoTab from "../../../../components/customer-profile/ContactInfoTab";
import AddressTab from "../../../../components/customer-profile/AddressTab";
import FinancialTab from "../../../../components/customer-profile/FinancialTab";
import DocumentsTab from "../../../../components/customer-profile/DocumentsTab";
import NotesTab from "../../../../components/customer-profile/NotesTab";
import ActivityTab from "../../../../components/customer-profile/ActivityTab";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "basic", label: "Basic Information" },
  { key: "tax", label: "Tax Information" },
  { key: "contact", label: "Contact Information" },
  { key: "address", label: "Address" },
  { key: "financial", label: "Financial" },
  { key: "documents", label: "Documents" },
  { key: "notes", label: "Notes" },
  { key: "activity", label: "Activity" },
];

export default function CustomerProfilePage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const customerName = searchParams.get("name") || "This Customer";
  const { showToast } = useToast();

  const [customer, setCustomer] = useState(null);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { customer } = await api.getCustomer(token, id);
      setCustomer(customer);
    } catch (err) {
      setError(err.message);
    }
  }

  const breadcrumb = [
    { label: "Ledger" },
    { label: "Customers", href: "/tenant/customers" },
    { label: customerName },
  ];

  if (error && !customer) {
    return (
      <div>
        <PageHeader breadcrumb={breadcrumb} title={customerName} />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!customer) return <p>Loading…</p>;

  const token = tenantAuth.get();
  const tabProps = { customer, token, onSaved: load, showToast, setError };

  return (
    <div>
      <PageHeader
        breadcrumb={breadcrumb}
        title={customer.name}
        description="Customer Profile — the single source of truth for this customer."
        action={<span className={`badge ${customer.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{customer.status === "ACTIVE" ? "Active" : "Inactive"}</span>}
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={setActiveTab} />

      <div role="tabpanel" id={`tabpanel-${activeTab}`} aria-labelledby={`tab-${activeTab}`}>
        {activeTab === "overview" && <OverviewTab {...tabProps} />}
        {activeTab === "basic" && <BasicInfoTab {...tabProps} />}
        {activeTab === "tax" && <TaxInfoTab {...tabProps} />}
        {activeTab === "contact" && <ContactInfoTab />}
        {activeTab === "address" && <AddressTab {...tabProps} />}
        {activeTab === "financial" && <FinancialTab />}
        {activeTab === "documents" && <DocumentsTab />}
        {activeTab === "notes" && <NotesTab />}
        {activeTab === "activity" && <ActivityTab customer={customer} />}
      </div>
    </div>
  );
}
