"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import TeamProfileDrawer from "../../../components/team/TeamProfileDrawer";
import AddMemberModal from "../../../components/team/AddMemberModal";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";

// Same readable-datetime convention already used by Invoice/Purchase/VAT
// Return Activity Timelines, instead of a raw toLocaleString() dump.
function formatLastLogin(iso) {
  if (!iso) return "Never";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Edit / Reset Password stay disabled with an honest tooltip - there is
// still no tenant-side API for either today. Add Member and Deactivate/
// Activate became real (Team self-service module, 2026-08-09) - see
// tenant.routes.js's POST /team and PATCH /team/:id/(de)activate.
const NOT_BUILT_YET_REASON = "Not available here yet.";
const CANNOT_DEACTIVATE_OWNER_REASON = "The Owner account can't be deactivated.";
const CANNOT_DEACTIVATE_SELF_REASON = "You can't deactivate your own account.";

export default function TeamPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("team.view");
  const { can } = usePermissions();
  const { showToast } = useToast();
  const [users, setUsers] = useState(null);
  const [usage, setUsage] = useState(null); // { activeCount, maxUsers } - informational only, never gates Add Member
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [drawerUser, setDrawerUser] = useState(null);
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [statusAction, setStatusAction] = useState(null); // { user, nextStatus } while the confirm dialog is open
  const [statusBusy, setStatusBusy] = useState(false);
  const session = typeof window !== "undefined" ? tenantAuth.getSession() : null;

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { users, usage } = await api.listTeam(token);
      setUsers(users);
      setUsage(usage);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRefresh() {
    await load();
    showToast("Team refreshed.");
  }

  function handleMemberCreated(user) {
    showToast(`Added ${user.name} to your team.`);
    load();
  }

  async function handleConfirmStatusChange() {
    const { user, nextStatus } = statusAction;
    setStatusBusy(true);
    try {
      const token = tenantAuth.get();
      if (nextStatus === "INACTIVE") await api.deactivateTeamMember(token, user.id);
      else await api.activateTeamMember(token, user.id);
      showToast(nextStatus === "INACTIVE" ? `${user.name} was deactivated.` : `${user.name} was reactivated.`);
      setStatusAction(null);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setStatusBusy(false);
    }
  }

  function handleExport() {
    const rows = [
      ["Name", "Email", "Role", "Status", "Last Login"],
      ...filtered.map((u) => [u.name, u.email, u.role, u.status, u.lastLoginAt ? formatLastLogin(u.lastLoginAt) : "Never"]),
    ];
    downloadCsv(`team-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  }

  function resetToPageOne() {
    setPage(1);
  }

  const filtered = useMemo(() => {
    if (!users) return [];
    const q = search.trim().toLowerCase();
    return users.filter((u) => {
      const matchesSearch = !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
      const matchesRole = roleFilter === "ALL" || u.role === roleFilter;
      return matchesSearch && matchesRole;
    });
  }, [users, search, roleFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  const COLUMNS = useMemo(
    () => [
      { key: "name", header: "Name", render: (u) => <span className="team-name-link">{u.name}</span> },
      { key: "email", header: "Email", render: (u) => u.email },
      {
        key: "role",
        header: "Role",
        render: (u) => <span className={`badge ${u.role === "OWNER" ? "badge-premium" : "badge-info"}`}>{u.role === "OWNER" ? "Owner" : "Staff"}</span>,
      },
      {
        key: "status",
        header: "Status",
        render: (u) => <span className={`badge ${u.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{u.status === "ACTIVE" ? "Active" : "Inactive"}</span>,
      },
      { key: "lastLoginAt", header: "Last Login", render: (u) => formatLastLogin(u.lastLoginAt) },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (u) => {
          const isOwner = u.role === "OWNER";
          const isSelf = u.id === session?.user?.id;
          const deactivateDisabledReason = isOwner ? CANNOT_DEACTIVATE_OWNER_REASON : isSelf ? CANNOT_DEACTIVATE_SELF_REASON : null;

          return (
            <ActionMenu
              ariaLabel={`Actions for ${u.name}`}
              items={[
                { label: "View Profile", onClick: () => setDrawerUser(u) },
                // Real, not disabled (RBAC module, 2026-08-06) - the first
                // concrete payoff of Roles & Permissions for Team. Links to
                // the Role List rather than deep-linking a specific role/user
                // pair - Team's own per-member real Role display (replacing
                // the legacy OWNER/STAFF badge two columns up) is Phase 6
                // scope, once listTeam itself returns resolved role data.
                { label: "Assign Role", onClick: () => router.push("/tenant/settings/roles") },
                { label: "Edit", disabled: true, disabledReason: NOT_BUILT_YET_REASON },
                { label: "Reset Password", disabled: true, disabledReason: NOT_BUILT_YET_REASON },
                u.status === "ACTIVE"
                  ? {
                      label: "Deactivate",
                      danger: true,
                      disabled: !!deactivateDisabledReason,
                      disabledReason: deactivateDisabledReason,
                      onClick: () => setStatusAction({ user: u, nextStatus: "INACTIVE" }),
                    }
                  : { label: "Reactivate", onClick: () => setStatusAction({ user: u, nextStatus: "ACTIVE" }) },
              ]}
            />
          );
        },
      },
    ],
    [session?.user?.id]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        eyebrow={session?.tenant?.name || "Your business"}
        title="Team"
        description={
          <>
            Everyone with access to your business.
            {usage && (
              <span className="helptext" style={{ marginLeft: 8 }}>
                {/* Informational only (Team self-service module, 2026-08-09) - never disables Add Member, see AddMemberModal's own comment for where the real limit check actually lives. */}
                {usage.activeCount} of {usage.maxUsers === null ? "unlimited" : usage.maxUsers} users
              </span>
            )}
          </>
        }
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {users === null ? (
          <LoadingSkeleton columns={5} />
        ) : (
          <>
            <Toolbar
              title="Team"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by name or email…"
              filters={
                <select
                  className="select-filter"
                  value={roleFilter}
                  onChange={(e) => {
                    setRoleFilter(e.target.value);
                    resetToPageOne();
                  }}
                >
                  <option value="ALL">All roles</option>
                  <option value="OWNER">Owner</option>
                  <option value="STAFF">Staff</option>
                </select>
              }
              action={
                <div style={{ display: "flex", gap: 8 }}>
                  <Button variant="outline" onClick={handleRefresh}>
                    Refresh
                  </Button>
                  <Button variant="outline" onClick={handleExport} disabled={filtered.length === 0}>
                    Export
                  </Button>
                  {can("team.create") && (
                    <Button onClick={() => setAddMemberOpen(true)}>+ Add Member</Button>
                  )}
                </div>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching people"
                description="Try a different search term or clear the role filter."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} onRowClick={(u) => setDrawerUser(u)} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Members"
                />
              </>
            )}
          </>
        )}
      </div>

      <TeamProfileDrawer open={!!drawerUser} onClose={() => setDrawerUser(null)} user={drawerUser} />

      <AddMemberModal
        open={addMemberOpen}
        onClose={() => setAddMemberOpen(false)}
        token={tenantAuth.get()}
        onCreated={handleMemberCreated}
        onUpgradeRequested={() => showToast("Contact your platform administrator to upgrade your plan.")}
      />

      <ConfirmationDialog
        open={!!statusAction}
        title={statusAction?.nextStatus === "INACTIVE" ? "Deactivate team member" : "Reactivate team member"}
        message={
          statusAction?.nextStatus === "INACTIVE"
            ? `${statusAction?.user.name} will no longer be able to sign in, but their history and audit trail are kept. This frees up one seat toward your plan's user limit.`
            : `${statusAction?.user.name} will be reactivated and count toward your plan's user limit again.`
        }
        confirmLabel={statusAction?.nextStatus === "INACTIVE" ? "Deactivate" : "Reactivate"}
        variant={statusAction?.nextStatus === "INACTIVE" ? "danger" : "primary"}
        busy={statusBusy}
        onConfirm={handleConfirmStatusChange}
        onCancel={() => setStatusAction(null)}
      />
    </div>
  );
}
