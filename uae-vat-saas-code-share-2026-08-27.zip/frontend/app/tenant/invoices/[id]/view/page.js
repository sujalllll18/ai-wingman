"use client";

import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Button from "../../../../../components/ui/Button";
import Tooltip from "../../../../../components/ui/Tooltip";
import { getInvoiceTemplateComponent, DEFAULT_INVOICE_TEMPLATE } from "../../../../../components/invoice-templates";

// A4 at 96dpi - matches the .invoice-document CSS (210mm/297mm). Only used
// for on-screen zoom/pagination math; never sent to the PDF/PNG/Print
// engines, which always capture the document at its true, unscaled size.
const A4_WIDTH_PX = 794;
const PAGE_HEIGHT_PX = 1123;
const MIN_ZOOM = 0.3;
const MAX_ZOOM = 2.5;
const ZOOM_STEP = 0.1;
const CANVAS_PADDING = 48;
const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
function assetUrl(path) {
  return path ? `${API_URL}${path}` : null;
}

function clampZoom(z) {
  return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(z * 100) / 100));
}

// Gives the browser time to reflow after resetting zoom to 1 before a
// capture starts. A setTimeout, not requestAnimationFrame - rAF only fires
// on a visible/compositing tab, and can stall indefinitely in a backgrounded
// or non-visible one, which would hang every export in that situation.
function waitForReflow() {
  return new Promise((resolve) => setTimeout(resolve, 50));
}

// Preview page: "exactly what the customer will receive." Fetches the
// invoice once via the existing read endpoint and renders it from that
// snapshot alone - no Customer/Material/Tax Master calls here at all, per
// the Sprint 2 brief and the immutability principle it builds on.
//
// The zoom/pagination/full-screen chrome below is purely a viewer-only
// presentational layer on top of the same ClassicTemplate DOM node used by
// PDF/PNG/Print (docs Sprint 2 "one rendering engine" requirement) - none of
// it changes what gets exported. Every export path resets zoom to natural
// 1:1 size immediately before capturing and restores it after, so the
// downloaded/printed output is always true-to-size regardless of whatever
// zoom the user was viewing at.
export default function InvoiceViewerPage() {
  const params = useParams();
  const router = useRouter();
  const documentRef = useRef(null);
  const scrollRef = useRef(null);
  const outerRef = useRef(null);
  const hasAutoFit = useRef(false);

  const [invoice, setInvoice] = useState(null);
  const [businessAssets, setBusinessAssets] = useState({});
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);

  const [zoom, setZoom] = useState(1);
  const [naturalHeight, setNaturalHeight] = useState(PAGE_HEIGHT_PX);
  const [currentPage, setCurrentPage] = useState(1);
  const [fullScreen, setFullScreen] = useState(false);
  const [capturing, setCapturing] = useState(false);

  const pageCount = Math.max(1, Math.ceil(naturalHeight / PAGE_HEIGHT_PX));

  useEffect(() => {
    (async () => {
      setError("");
      try {
        const token = tenantAuth.get();
        const { invoice } = await api.getInvoice(token, params.id);
        setInvoice(invoice);
        // Fire-and-forget activity log - never blocks or fails the preview itself.
        api.logInvoiceActivity(token, params.id, "PREVIEWED", null).catch(() => {});
        // Live Business Profile assets (2026-08-09) - fetched alongside the
        // invoice snapshot but deliberately NOT part of it (see
        // ClassicTemplate.js's businessAssets comment). Best-effort: a
        // failure here shouldn't block viewing the invoice itself, the
        // logo/stamp/signature just stay empty.
        api
          .getBusinessProfile(token)
          .then(({ businessProfile }) =>
            setBusinessAssets({ logoUrl: assetUrl(businessProfile.logoUrl), stampUrl: assetUrl(businessProfile.stampUrl), signatureUrl: assetUrl(businessProfile.signatureUrl) })
          )
          .catch(() => {});
      } catch (err) {
        setError(err.message);
      }
    })();
  }, [params.id]);

  // Tracks the template's true (unscaled) height. Zoom is applied via the
  // CSS `zoom` property (not `transform: scale`) on an ancestor - unlike
  // transform, `zoom` changes the element's own offsetHeight too, so the
  // measurement is divided back out to get the true 1:1 height.
  useEffect(() => {
    if (!documentRef.current) return;
    const el = documentRef.current;
    const measure = () => setNaturalHeight(el.offsetHeight / (zoom || 1));
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    measure();
    return () => observer.disconnect();
  }, [invoice, zoom]);

  // Default to Fit Width once, the first time we have real measurements.
  useEffect(() => {
    if (hasAutoFit.current) return;
    if (!invoice || !scrollRef.current) return;
    hasAutoFit.current = true;
    fitToWidth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoice, naturalHeight]);

  useEffect(() => {
    function handleFsChange() {
      if (!document.fullscreenElement) setFullScreen(false);
    }
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  function zoomIn() {
    setZoom((z) => clampZoom(z + ZOOM_STEP));
  }
  function zoomOut() {
    setZoom((z) => clampZoom(z - ZOOM_STEP));
  }
  function fitToWidth() {
    if (!scrollRef.current) return;
    const available = scrollRef.current.clientWidth - CANVAS_PADDING;
    setZoom(clampZoom(available / A4_WIDTH_PX));
  }
  function fitToPage() {
    if (!scrollRef.current) return;
    const availableW = scrollRef.current.clientWidth - CANVAS_PADDING;
    const availableH = scrollRef.current.clientHeight - CANVAS_PADDING;
    setZoom(clampZoom(Math.min(availableW / A4_WIDTH_PX, availableH / PAGE_HEIGHT_PX)));
  }

  function goToPage(n) {
    const target = Math.min(pageCount, Math.max(1, n));
    if (!scrollRef.current) return;
    scrollRef.current.scrollTop = (target - 1) * PAGE_HEIGHT_PX * zoom;
    setCurrentPage(target);
  }

  function handleScroll() {
    if (!scrollRef.current) return;
    const p = Math.floor(scrollRef.current.scrollTop / (PAGE_HEIGHT_PX * zoom)) + 1;
    setCurrentPage(Math.min(pageCount, Math.max(1, p)));
  }

  async function toggleFullScreen() {
    const next = !fullScreen;
    setFullScreen(next);
    try {
      if (next && outerRef.current?.requestFullscreen) {
        await outerRef.current.requestFullscreen();
      } else if (!next && document.fullscreenElement) {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen API unavailable/blocked in this environment - the CSS-
      // driven full-screen layout still applies regardless.
    }
  }

  // Every export path funnels through here: drop to true 1:1 size, let the
  // browser reflow, run the actual PDF/PNG/Print engine unchanged, then
  // restore whatever zoom the user had.
  async function withNaturalZoom(action) {
    const previousZoom = zoom;
    setCapturing(true);
    setZoom(1);
    await waitForReflow();
    try {
      await action();
    } finally {
      setZoom(previousZoom);
      setCapturing(false);
    }
  }

  async function handleDownloadPdf() {
    if (!documentRef.current || exporting) return;
    setExporting(true);
    try {
      await withNaturalZoom(async () => {
        const { jsPDF } = await import("jspdf");
        const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
        await doc.html(documentRef.current, {
          x: 0,
          y: 0,
          width: 210,
          windowWidth: documentRef.current.offsetWidth,
          autoPaging: "text",
        });
        doc.save(`${invoice.invoiceNumberDisplay || "Draft-Invoice"}.pdf`);
      });
      const token = tenantAuth.get();
      api.logInvoiceActivity(token, params.id, "DOWNLOADED", "PDF").catch(() => {});
    } catch (err) {
      setError(`Could not generate PDF: ${err.message}`);
    } finally {
      setExporting(false);
    }
  }

  async function handleDownloadPng() {
    if (!documentRef.current || exporting) return;
    setExporting(true);
    try {
      await withNaturalZoom(async () => {
        const { default: html2canvas } = await import("html2canvas");
        const canvas = await html2canvas(documentRef.current, { scale: 2, backgroundColor: "#ffffff" });
        const link = document.createElement("a");
        link.href = canvas.toDataURL("image/png");
        link.download = `${invoice.invoiceNumberDisplay || "Draft-Invoice"}.png`;
        link.click();
      });
      const token = tenantAuth.get();
      api.logInvoiceActivity(token, params.id, "DOWNLOADED", "PNG").catch(() => {});
    } catch (err) {
      setError(`Could not generate PNG: ${err.message}`);
    } finally {
      setExporting(false);
    }
  }

  async function handlePrint() {
    await withNaturalZoom(async () => {
      window.print();
    });
  }

  if (!invoice) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: "…" }]} title="Invoice Preview" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const Template = getInvoiceTemplateComponent(DEFAULT_INVOICE_TEMPLATE);
  const title = invoice.invoiceNumberDisplay || "Draft Invoice";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: title }, { label: "Preview" }]}
        title="Invoice Preview"
        description="Exactly what your customer will receive."
      />

      <ErrorBanner message={error} />

      <div ref={outerRef} className={`invoice-viewer-root${fullScreen ? " invoice-viewer-fullscreen" : ""}`}>
        <div className="invoice-viewer-toolbar">
          <div className="invoice-viewer-toolbar-group">
            <Button variant="outline" onClick={() => router.back()}>
              Back
            </Button>
            {invoice.status === "DRAFT" && (
              <Link href={`/tenant/invoices/${invoice.id}`}>
                <Button variant="outline">Edit Draft</Button>
              </Link>
            )}
          </div>

          <div className="invoice-viewer-toolbar-group">
            <button type="button" className="btn btn-outline btn-sm" onClick={zoomOut} disabled={zoom <= MIN_ZOOM} aria-label="Zoom out">
              −
            </button>
            <span className="invoice-viewer-zoom-value">{Math.round(zoom * 100)}%</span>
            <button type="button" className="btn btn-outline btn-sm" onClick={zoomIn} disabled={zoom >= MAX_ZOOM} aria-label="Zoom in">
              +
            </button>
            <button type="button" className="btn btn-outline btn-sm" onClick={fitToWidth}>
              Fit Width
            </button>
            <button type="button" className="btn btn-outline btn-sm" onClick={fitToPage}>
              Fit Page
            </button>
          </div>

          {pageCount > 1 && (
            <div className="invoice-viewer-toolbar-group">
              <button type="button" className="btn btn-outline btn-sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage <= 1} aria-label="Previous page">
                ‹
              </button>
              <span className="invoice-viewer-page-indicator">
                Page {currentPage} of {pageCount}
              </span>
              <button type="button" className="btn btn-outline btn-sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage >= pageCount} aria-label="Next page">
                ›
              </button>
            </div>
          )}

          <div className="invoice-viewer-toolbar-group invoice-viewer-toolbar-actions">
            <button type="button" className="btn btn-outline btn-sm" onClick={toggleFullScreen}>
              {fullScreen ? "Exit Full Screen" : "Full Screen"}
            </button>
            <Button variant="outline" onClick={handlePrint} disabled={exporting}>
              Print
            </Button>
            <Button variant="outline" onClick={handleDownloadPng} disabled={exporting}>
              {exporting ? "Working…" : "Download PNG"}
            </Button>
            <Button onClick={handleDownloadPdf} disabled={exporting}>
              {exporting ? "Working…" : "Download PDF"}
            </Button>
            <Tooltip label="Not available yet — planned for a future sprint">
              <button type="button" className="btn btn-outline btn-sm" disabled>
                Share
              </button>
            </Tooltip>
            <Tooltip label="Not available yet — planned for a future sprint">
              <button type="button" className="btn btn-outline btn-sm" disabled>
                Email
              </button>
            </Tooltip>
            <Tooltip label="Not available yet — planned for a future sprint">
              <button type="button" className="btn btn-outline btn-sm" disabled>
                WhatsApp
              </button>
            </Tooltip>
          </div>
        </div>

        {/* Zoom uses the CSS `zoom` property, not `transform: scale` -
            `transform` on an ancestor is a known trigger for html2canvas
            (which both PDF and PNG export use under the hood) to hang or
            mis-measure, even at scale(1). `zoom` doesn't create a stacking
            context, affects real layout so the scroll container sizes
            itself correctly with no extra sizer math needed, and is fully
            inert at 1 - exactly what every export path resets it to. */}
        <div className="invoice-viewer-canvas" ref={scrollRef} onScroll={handleScroll}>
          <div className="invoice-doc-zoom-wrap" style={{ zoom }}>
            {!capturing && pageCount > 1 && (
              <div className="invoice-doc-page-guides" aria-hidden="true">
                {Array.from({ length: pageCount - 1 }).map((_, i) => (
                  <div key={i} className="invoice-doc-page-guide" style={{ top: (i + 1) * PAGE_HEIGHT_PX }}>
                    <span>Page {i + 2}</span>
                  </div>
                ))}
              </div>
            )}
            <Template invoice={invoice} businessAssets={businessAssets} ref={documentRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
