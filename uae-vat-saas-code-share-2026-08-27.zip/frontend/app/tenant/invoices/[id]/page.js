"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import InvoiceForm from "../../../../components/invoices/InvoiceForm";
import InvoiceStatusBadge from "../../../../components/invoices/InvoiceStatusBadge";
import LineItemsTable from "../../../../components/invoices/LineItemsTable";
import TableScroll from "../../../../components/ui/TableScroll";
import InvoiceSummarySidebar from "../../../../components/invoices/InvoiceSummarySidebar";
import PaymentFormModal from "../../../../components/invoices/PaymentFormModal";
import ActivityTimeline from "../../../../components/invoices/ActivityTimeline";
import InternalNotesCard from "../../../../components/invoices/InternalNotesCard";
import AttachmentsPlaceholder from "../../../../components/invoices/AttachmentsPlaceholder";
import Can from "../../../../components/rbac/Can";
import ReconciliationStatusBadge from "../../../../components/reconciliation/ReconciliationStatusBadge";
import { computeCreditEligibilityMap } from "../../../../lib/creditNoteEligibility";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function formatCurrency(value, currency) {
  return `${currency || "AED"} ${Number(value || 0).toFixed(2)}`;
}

const PAYMENT_METHOD_LABEL = {
  CASH: "Cash",
  BANK_TRANSFER: "Bank Transfer",
  CARD: "Card",
  CHEQUE: "Cheque",
  OTHER: "Other",
};

export default function InvoiceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [invoice, setInvoice] = useState(null);
  const [error, setError] = useState("");
  const [confirmAction, setConfirmAction] = useState(null); // "send" | "delete" | "void" | "badDebt" | "archive" | "restore" | "duplicate"
  const [busy, setBusy] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [creditRemaining, setCreditRemaining] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  // Gates the "Issue Credit Note" button on remaining creditable amount, not
  // just status - same client-side compute as the Invoices list row menu
  // and EligibleInvoicePicker, no new endpoint. Best-effort: while this is
  // still loading (null), the button stays visible rather than flashing
  // hidden/shown; a failure leaves it visible too (fails open, same as
  // every other best-effort fetch on this page).
  useEffect(() => {
    if (!invoice || invoice.status !== "SENT") return;
    const token = tenantAuth.get();
    api
      .listCreditNotes(token)
      .then(({ creditNotes }) => {
        const map = computeCreditEligibilityMap([invoice], creditNotes);
        setCreditRemaining(map.get(invoice.id)?.remaining ?? invoice.grandTotal);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoice?.id, invoice?.status]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { invoice } = await api.getInvoice(token, params.id);
      setInvoice(invoice);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleSend() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const result = await api.sendInvoice(token, params.id);
      setConfirmAction(null);
      // Maker-Checker engine (2026-08-06): if an Approval Rule is on for
      // invoices.send, the backend responds 202 with an approvalRequest
      // instead of the sent invoice - the Draft is untouched until a
      // checker decides. Reload rather than setInvoice(undefined), which
      // would crash the rest of this page's invoice.* reads.
      if (result.approvalRequest) {
        showToast(`Sending requires approval - submitted as ${result.approvalRequest.referenceNumber}. This stays a Draft until a checker decides.`);
        await load();
      } else {
        setInvoice(result.invoice);
        // Email integration is future scope (Sprint 3 brief, item 2) - this is
        // a deliberate placeholder message, not a claim that anything was emailed.
        showToast(`${result.invoice.invoiceNumberDisplay} was sent. (Email delivery isn't wired up yet — share it manually for now.)`);
      }
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deleteInvoice(token, params.id);
      showToast("Draft deleted.");
      router.push("/tenant/invoices");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
      setBusy(false);
    }
  }

  async function handleVoid() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { invoice } = await api.voidInvoice(token, params.id);
      setInvoice(invoice);
      setConfirmAction(null);
      showToast("Invoice cancelled.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleMarkBadDebt() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { invoice } = await api.updateInvoicePaymentStatus(token, params.id, "BAD_DEBT");
      setInvoice(invoice);
      setConfirmAction(null);
      showToast("Invoice marked as Bad Debt.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleArchive() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { invoice } = await api.archiveInvoice(token, params.id);
      setInvoice(invoice);
      setConfirmAction(null);
      showToast("Invoice archived.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleRestore() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { invoice } = await api.restoreInvoice(token, params.id);
      setInvoice(invoice);
      showToast("Invoice restored.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleDuplicate() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { invoice: newInvoice } = await api.duplicateInvoice(token, params.id);
      showToast("Draft created from this invoice.");
      router.push(`/tenant/invoices/${newInvoice.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
      setConfirmAction(null);
    }
  }

  if (!invoice) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: "…" }]} title="Invoice" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const title = invoice.invoiceNumberDisplay || "Draft Invoice";
  const canMarkBadDebt = invoice.status === "SENT" && invoice.paymentStatus !== "PAID" && invoice.paymentStatus !== "BAD_DEBT";

  const operationalExtras = (
    <>
      <ActivitySection invoice={invoice} />
      <InternalNotesCard invoice={invoice} onSaved={setInvoice} showToast={showToast} />
      <AttachmentsPlaceholder />
    </>
  );

  const archiveRestoreDuplicate = (
    <Card>
      <h3 style={{ marginTop: 0 }}>Record Actions</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <Button variant="outline" onClick={() => setConfirmAction("duplicate")} disabled={busy}>
          Duplicate Invoice
        </Button>
        {invoice.archivedAt ? (
          <Button variant="outline" onClick={handleRestore} disabled={busy}>
            Restore from Archive
          </Button>
        ) : (
          <Button variant="outline" onClick={() => setConfirmAction("archive")} disabled={busy}>
            Archive Invoice
          </Button>
        )}
      </div>
      {invoice.archivedAt && <p className="helptext" style={{ marginTop: 8, marginBottom: 0 }}>Archived {formatDate(invoice.archivedAt)}</p>}
    </Card>
  );

  const duplicateDialog = (
    <ConfirmationDialog
      open={confirmAction === "duplicate"}
      title="Duplicate this invoice?"
      message="Creates a new Draft with the same customer and line items, priced fresh from current Material and Tax Master data. A new invoice number is only assigned if you Send it."
      confirmLabel="Create Draft"
      busy={busy}
      onConfirm={handleDuplicate}
      onCancel={() => setConfirmAction(null)}
    />
  );
  const archiveDialog = (
    <ConfirmationDialog
      open={confirmAction === "archive"}
      title="Archive this invoice?"
      message="Archived invoices are hidden from the main list but never deleted - restore them anytime from the Archived view."
      confirmLabel="Archive"
      busy={busy}
      onConfirm={handleArchive}
      onCancel={() => setConfirmAction(null)}
    />
  );

  if (invoice.status === "DRAFT") {
    return (
      <div>
        <PageHeader
          breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: title }]}
          title={title}
          description="This invoice hasn't been sent — everything here is still editable."
          action={
            <div style={{ display: "flex", gap: 8 }}>
              <Link href={`/tenant/invoices/${invoice.id}/view`}>
                <Button variant="outline">Preview Invoice</Button>
              </Link>
              <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                Delete Draft
              </Button>
              <Button onClick={() => setConfirmAction("send")}>Send Invoice</Button>
            </div>
          }
        />
        <ErrorBanner message={error} />
        <InvoiceForm
          mode="edit"
          initialInvoice={invoice}
          onSaved={(updated) => {
            setInvoice(updated);
            showToast("Draft saved.");
          }}
        />

        <div className="detail-layout" style={{ marginTop: 20 }}>
          <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>{operationalExtras}</div>
          <div className="detail-rail">{archiveRestoreDuplicate}</div>
        </div>

        <ConfirmationDialog
          open={confirmAction === "send"}
          title="Send this invoice?"
          message="This assigns a permanent invoice number and locks the customer, line item, material, tax, and business details as they stand right now. Future changes to Customer, Product & Service, Tax, or Business Profile records will never affect it again."
          confirmLabel="Send Invoice"
          busy={busy}
          onConfirm={handleSend}
          onCancel={() => setConfirmAction(null)}
        />
        <ConfirmationDialog
          open={confirmAction === "delete"}
          title="Delete this draft?"
          message="This draft has never been sent, so no invoice number has been consumed. This can't be undone. (Prefer Archive if you'd rather keep the record.)"
          confirmLabel="Delete Draft"
          variant="danger"
          busy={busy}
          onConfirm={handleDelete}
          onCancel={() => setConfirmAction(null)}
        />
        {duplicateDialog}
        {archiveDialog}
      </div>
    );
  }

  // SENT or VOID - read-only snapshot view. Every value below was copied
  // once, at Send, per the snapshot/immutability principle - none of it is
  // re-read from Customer/Material/Tax Master/Business Profile now.
  const readOnlyLines = invoice.lineItems.map((li) => ({ ...li, key: li.id }));

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: title }]}
        title={title}
        eyebrow={<InvoiceStatusBadge invoice={invoice} />}
        description={`Issued ${formatDate(invoice.issueDate)} · Due ${formatDate(invoice.dueDate)}`}
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Link href={`/tenant/invoices/${invoice.id}/view`}>
              <Button variant="outline">Preview Invoice</Button>
            </Link>
            {invoice.status === "SENT" && (creditRemaining === null || creditRemaining > 0.01) && (
              <Can permission="credit_notes.create">
                <Link href={`/tenant/credit-notes/new?invoiceId=${invoice.id}`}>
                  <Button variant="outline">Issue Credit Note</Button>
                </Link>
              </Can>
            )}
            {invoice.status === "SENT" && (
              <Can permission="sales_debit_notes.create">
                <Link href={`/tenant/sales-debit-notes/new?invoiceId=${invoice.id}`}>
                  <Button variant="outline">Create Debit Note</Button>
                </Link>
              </Can>
            )}
            {invoice.status === "SENT" && (
              <Button variant="outline" onClick={() => setConfirmAction("void")}>
                Cancel Invoice
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Business</h3>
            <p style={{ margin: 0 }}>{invoice.businessName}</p>
            {invoice.businessAddress && <p className="helptext" style={{ margin: 0 }}>{invoice.businessAddress}</p>}
            {invoice.businessTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {invoice.businessTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Customer</h3>
            <p style={{ margin: 0 }}>{invoice.customerName}</p>
            {invoice.customerAddress && <p className="helptext" style={{ margin: 0 }}>{invoice.customerAddress}</p>}
            {invoice.customerTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {invoice.customerTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <LineItemsTable lines={readOnlyLines} computedLines={invoice.lineItems} materials={[]} taxCategories={[]} onChangeLine={() => {}} disabled />
          </Card>

          {invoice.notes && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Notes</h3>
              <p style={{ margin: 0 }}>{invoice.notes}</p>
            </Card>
          )}

          {invoice.status === "SENT" && (
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <h3 style={{ margin: 0 }}>Payments</h3>
                  {invoice.reconciliationSummary && <ReconciliationStatusBadge status={invoice.reconciliationSummary} />}
                </div>
                <Button variant="outline" onClick={() => setPaymentModalOpen(true)}>
                  Record Payment
                </Button>
              </div>
              {/* Sourced from paymentAllocations (Phase 2 Payments module,
                  2026-08-22), not the legacy `payments` relation - this is the
                  real allocation-based source, so a payment recorded/allocated
                  here from the full Payments module (possibly split across
                  several invoices) shows up correctly too, not just one
                  created via this page's own quick action. */}
              {invoice.paymentAllocations && invoice.paymentAllocations.length > 0 ? (
                <TableScroll style={{ marginTop: 12 }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Payment #</th>
                        <th>Date</th>
                        <th>Method</th>
                        <th>Reference</th>
                        <th className="num">Amount Allocated</th>
                      </tr>
                    </thead>
                    <tbody>
                      {invoice.paymentAllocations.map((a) => (
                        <tr key={a.id}>
                          <td>
                            <Link href={`/tenant/payments/${a.payment.id}`} className="mono">
                              {a.payment.paymentNumberDisplay}
                            </Link>
                            {a.payment.status === "CANCELLED" && <span className="badge badge-danger" style={{ marginLeft: 6 }}>Cancelled</span>}
                          </td>
                          <td>{formatDate(a.payment.paymentDate)}</td>
                          <td>{PAYMENT_METHOD_LABEL[a.payment.method] || a.payment.method}</td>
                          <td>{a.payment.reference || "—"}</td>
                          <td className="num mono">{formatCurrency(a.allocatedAmount, a.payment.currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </TableScroll>
              ) : (
                <p className="helptext" style={{ marginTop: 12 }}>No payments recorded yet.</p>
              )}
              <p className="helptext" style={{ marginTop: 12 }}>
                <Link href={`/tenant/payments?customerId=${invoice.customerId || ""}`}>View all payments from this customer →</Link>
              </p>
            </Card>
          )}

          {invoice.status === "SENT" && <RelatedDocumentsAndReconciliation invoice={invoice} />}

          {operationalExtras}
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <InvoiceSummarySidebar
            totals={invoice}
            discountType={invoice.discountType}
            discountValue={invoice.discountValue}
            onDiscountTypeChange={() => {}}
            onDiscountValueChange={() => {}}
            disabled
          />

          {invoice.status === "SENT" && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Payment Status</h3>
              <InvoiceStatusBadge invoice={invoice} />
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12, fontSize: 13 }}>
                <span className="helptext">Amount Paid</span>
                <span className="mono">{formatCurrency(invoice.amountPaid, invoice.currency)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, fontSize: 13 }}>
                <span className="helptext">Outstanding</span>
                <span className="mono">{formatCurrency(invoice.outstandingAmount, invoice.currency)}</span>
              </div>
              {canMarkBadDebt && (
                <Button variant="outline" onClick={() => setConfirmAction("badDebt")} disabled={busy} style={{ marginTop: 12, width: "100%" }}>
                  Mark as Bad Debt
                </Button>
              )}
              {invoice.paymentStatus === "BAD_DEBT" && (
                <p className="helptext" style={{ marginTop: 8, marginBottom: 0 }}>Recording a payment will clear Bad Debt automatically.</p>
              )}
            </Card>
          )}

          {archiveRestoreDuplicate}
        </div>
      </div>

      <ConfirmationDialog
        open={confirmAction === "void"}
        title="Cancel this invoice?"
        message="A cancelled invoice's number is never reused. This can't be undone."
        confirmLabel="Cancel Invoice"
        variant="danger"
        busy={busy}
        onConfirm={handleVoid}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "badDebt"}
        title="Mark as Bad Debt?"
        message="This flags the outstanding balance as unlikely to be collected. Recording a new payment against this invoice will automatically clear the Bad Debt flag."
        confirmLabel="Mark as Bad Debt"
        variant="danger"
        busy={busy}
        onConfirm={handleMarkBadDebt}
        onCancel={() => setConfirmAction(null)}
      />
      {duplicateDialog}
      {archiveDialog}

      <PaymentFormModal
        open={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        invoice={invoice}
        onSuccess={(updated) => {
          setInvoice(updated);
          setPaymentModalOpen(false);
          showToast("Payment recorded.");
        }}
      />
    </div>
  );
}

function ActivitySection({ invoice }) {
  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Activity</h3>
      <ActivityTimeline activities={invoice.activities} />
    </Card>
  );
}

// Traceability + reconciliation: Invoice -> Credit Notes + Sales Debit
// Notes (the reverse of each note's own "Original Invoice" reference).
// Reuses the existing listCreditNotes/listSalesDebitNotes endpoints filtered
// client-side, same "no new endpoint needed" pattern already used by
// CreditNoteForm - there's no per-invoice GET yet, and one isn't needed for
// a list this size. IMPORTANT: this never writes anything back to the
// invoice - Original/Net Adjusted/True Outstanding here are a pure display
// computation over the invoice's own already-loaded grandTotal/amountPaid
// plus these notes, never persisted, matching "do not change the original
// invoice's stored total" - invoice.outstandingAmount itself (shown in the
// Payment Status card) intentionally stays Payment-only/note-unaware, this
// card is the one place the fuller picture is shown.
function RelatedDocumentsAndReconciliation({ invoice }) {
  const [creditNotes, setCreditNotes] = useState(null);
  const [debitNotes, setDebitNotes] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const token = tenantAuth.get();
      try {
        const { creditNotes } = await api.listCreditNotes(token);
        if (!cancelled) setCreditNotes(creditNotes.filter((n) => n.invoiceId === invoice.id));
      } catch {
        if (!cancelled) setCreditNotes([]);
      }
      try {
        const { salesDebitNotes } = await api.listSalesDebitNotes(token);
        if (!cancelled) setDebitNotes(salesDebitNotes.filter((n) => n.invoiceId === invoice.id));
      } catch {
        if (!cancelled) setDebitNotes([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [invoice.id]);

  if (creditNotes === null || debitNotes === null) return null;
  if (creditNotes.length === 0 && debitNotes.length === 0) return null;

  const issuedCredits = creditNotes.filter((n) => n.status === "ISSUED");
  const issuedDebits = debitNotes.filter((n) => n.status === "ISSUED");
  const creditTotal = issuedCredits.reduce((s, n) => s + n.grandTotal, 0);
  const debitTotal = issuedDebits.reduce((s, n) => s + n.grandTotal, 0);
  const netAdjusted = invoice.grandTotal - creditTotal + debitTotal;
  const trueOutstanding = netAdjusted - (invoice.amountPaid || 0);

  return (
    <Card>
      <h3 style={{ marginTop: 0 }}>Related Documents</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
        <div className="review-row">
          <span className="review-label mono">{invoice.invoiceNumberDisplay}</span>
          <span>{formatCurrency(invoice.grandTotal, invoice.currency)}</span>
        </div>
        {creditNotes.map((n) => (
          <Link key={n.id} href={`/tenant/credit-notes/${n.id}`} className="review-row" style={{ textDecoration: "none" }}>
            <span className="mono">{n.creditNoteNumberDisplay || "Draft"} {n.status !== "ISSUED" && `(${n.status.toLowerCase()})`}</span>
            <span>-{formatCurrency(n.grandTotal, n.currency)}</span>
          </Link>
        ))}
        {debitNotes.map((n) => (
          <Link key={n.id} href={`/tenant/sales-debit-notes/${n.id}`} className="review-row" style={{ textDecoration: "none" }}>
            <span className="mono">{n.salesDebitNoteNumberDisplay || "Draft"} {n.status !== "ISSUED" && `(${n.status.toLowerCase()})`}</span>
            <span>+{formatCurrency(n.grandTotal, n.currency)}</span>
          </Link>
        ))}
      </div>

      {(issuedCredits.length > 0 || issuedDebits.length > 0) && (
        <div className="review-list" style={{ borderTop: "1px solid var(--color-line)", paddingTop: 12 }}>
          <div className="review-row" style={{ fontWeight: 600 }}>
            <span className="review-label">Net Adjusted Amount</span>
            <span className="review-value mono">{formatCurrency(netAdjusted, invoice.currency)}</span>
          </div>
          <div className="review-row">
            <span className="review-label">Paid</span>
            <span className="review-value mono">-{formatCurrency(invoice.amountPaid, invoice.currency)}</span>
          </div>
          <div className="review-row" style={{ fontWeight: 600 }}>
            <span className="review-label">Outstanding (adjusted)</span>
            <span className="review-value mono">{formatCurrency(trueOutstanding, invoice.currency)}</span>
          </div>
        </div>
      )}
    </Card>
  );
}
