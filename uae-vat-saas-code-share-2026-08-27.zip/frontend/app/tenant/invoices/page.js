"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import { useLocalStorageState } from "../../../hooks/useLocalStorageState";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import DataTable from "../../../components/ui/DataTable";
import TableScroll from "../../../components/ui/TableScroll";
import ColumnSelector from "../../../components/ui/ColumnSelector";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import { DocumentStatusChip, PaymentStatusChip } from "../../../components/invoices/InvoiceStatusBadge";
import MoreFiltersDrawer from "../../../components/invoices/MoreFiltersDrawer";
import ClassicTemplate from "../../../components/invoice-templates/ClassicTemplate";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";
import { computeCreditEligibilityMap } from "../../../lib/creditNoteEligibility";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function sortInvoices(list, key, direction) {
  const sorted = [...list];
  sorted.sort((a, b) => {
    let av = a[key];
    let bv = b[key];
    if (key === "createdAt" || key === "dueDate") {
      av = av ? new Date(av).getTime() : 0;
      bv = bv ? new Date(bv).getTime() : 0;
    } else if (key === "grandTotal" || key === "outstandingAmount") {
      av = Number(av || 0);
      bv = Number(bv || 0);
    } else {
      av = (av || "").toString().toLowerCase();
      bv = (bv || "").toString().toLowerCase();
    }
    if (av < bv) return direction === "asc" ? -1 : 1;
    if (av > bv) return direction === "asc" ? 1 : -1;
    return 0;
  });
  return sorted;
}

function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function exportInvoicesToCsv(list) {
  const rows = [
    ["Invoice #", "Customer", "Customer TRN", "Issue Date", "Due Date", "Status", "Payment Status", "Subtotal", "VAT", "Total", "Outstanding"],
    ...list.map((i) => [
      i.invoiceNumberDisplay || "Draft",
      i.customerName,
      i.customerTrn || "",
      i.issueDate ? formatDate(i.issueDate) : "",
      i.dueDate ? formatDate(i.dueDate) : "",
      i.status,
      i.paymentStatus,
      i.subtotal,
      i.vatTotal,
      i.grandTotal,
      i.outstandingAmount,
    ]),
  ];
  downloadCsv(`invoices-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
}

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

const KPI_ICONS = {
  total: (
    <svg viewBox="0 0 24 24">
      <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
      <path d="M8 8h8M8 12h8M8 16h5" />
    </svg>
  ),
  draft: (
    <svg viewBox="0 0 24 24">
      <path d="M14.5 4.5l5 5L8 21H3v-5z" />
    </svg>
  ),
  sent: (
    <svg viewBox="0 0 24 24">
      <path d="M21 3 3 10.5l7.5 3L14 21z" />
      <path d="M21 3 10.5 13.5" />
    </svg>
  ),
  paid: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12.5l2.5 2.5L16 9.5" />
    </svg>
  ),
  outstanding: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
};

const FilterFunnelIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" style={{ stroke: "currentColor", strokeWidth: 1.8, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" }}>
    <path d="M4 5h16l-6 7.5V19l-4 2v-8.5z" />
  </svg>
);

export default function InvoicesPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("invoices.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [invoices, setInvoices] = useState(null);
  const [creditNotes, setCreditNotes] = useState([]);
  const [businessAssets, setBusinessAssets] = useState({});
  const [error, setError] = useState("");
  const [archivedView, setArchivedView] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkRenderInvoice, setBulkRenderInvoice] = useState(null);
  const bulkRenderRef = useRef(null);
  const bulkRenderResolveRef = useRef(null);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const searchParams = useSearchParams();
  // Seeds the initial filter from a query param (e.g. Dashboard's "Total
  // Revenue" card links here with ?paymentStatus=PAID) - read once on
  // mount, same as any other initial-state default; doesn't keep syncing
  // with the URL afterward.
  const [paymentStatusFilter, setPaymentStatusFilter] = useState(() => searchParams.get("paymentStatus") || "ALL");
  const [customerFilter, setCustomerFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [dueDateFrom, setDueDateFrom] = useState("");
  const [dueDateTo, setDueDateTo] = useState("");
  const [moreFiltersOpen, setMoreFiltersOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [sortKey, setSortKey] = useState("createdAt");
  const [sortDirection, setSortDirection] = useState("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedIds, setSelectedIds] = useState(() => new Set());
  // COLUMN_DEFS' select-all checkbox needs "current page" without forcing a
  // recompute of the whole column list every pagination change - populated
  // below, right after `pageItems` itself is computed each render.
  const pageItemsRef = useRef([]);

  useEffect(() => {
    load();
    setSelectedIds(new Set());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [archivedView]);

  // Live Business Profile assets (2026-08-09) - fetched once, independent
  // of archivedView, for the bulk-PDF hidden ClassicTemplate render below
  // (same reasoning as the Invoice Viewer's own fetch - not part of the
  // invoice snapshot, best-effort, never blocks the list itself).
  useEffect(() => {
    const token = tenantAuth.get();
    api
      .getBusinessProfile(token)
      .then(({ businessProfile }) =>
        setBusinessAssets({
          logoUrl: businessProfile.logoUrl ? `${API_URL}${businessProfile.logoUrl}` : null,
          stampUrl: businessProfile.stampUrl ? `${API_URL}${businessProfile.stampUrl}` : null,
          signatureUrl: businessProfile.signatureUrl ? `${API_URL}${businessProfile.signatureUrl}` : null,
        })
      )
      .catch(() => {});
  }, []);

  // Eligibility for the row menu's "Create Credit Note" action - same
  // client-side compute as EligibleInvoicePicker/RelatedDocumentsAndReconciliation,
  // no new endpoint. Best-effort: a failure just leaves creditNotes empty,
  // which (correctly) hides the action rather than crashing the list.
  useEffect(() => {
    const token = tenantAuth.get();
    api
      .listCreditNotes(token)
      .then(({ creditNotes }) => setCreditNotes(creditNotes))
      .catch(() => {});
  }, []);

  const creditEligibilityMap = useMemo(() => computeCreditEligibilityMap(invoices || [], creditNotes), [invoices, creditNotes]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { invoices } = await api.listInvoices(token, { archived: archivedView });
      setInvoices(invoices);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function toggleSelected(id) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const COLUMN_DEFS = useMemo(
    () => [
      {
        key: "select",
        label: (
          <input
            type="checkbox"
            aria-label="Select all on this page"
            checked={pageItemsRef.current.length > 0 && pageItemsRef.current.every((i) => selectedIds.has(i.id))}
            onChange={(e) => {
              setSelectedIds((prev) => {
                const next = new Set(prev);
                pageItemsRef.current.forEach((i) => (e.target.checked ? next.add(i.id) : next.delete(i.id)));
                return next;
              });
            }}
          />
        ),
        alwaysVisible: true,
        render: (i) => <input type="checkbox" aria-label={`Select ${i.invoiceNumberDisplay || "draft"}`} checked={selectedIds.has(i.id)} onChange={() => toggleSelected(i.id)} />,
      },
      {
        key: "invoiceNumberDisplay",
        label: "Invoice #",
        alwaysVisible: true,
        sortable: true,
        render: (i) => (
          <div>
            <div className="mono" style={{ fontWeight: 600 }}>
              {i.invoiceNumberDisplay || "Draft"}
            </div>
            {i.status === "VOID" && (
              <div style={{ fontSize: 12, color: "var(--color-ink-faint)", marginTop: 2 }}>Cancelled</div>
            )}
          </div>
        ),
      },
      {
        key: "customerName",
        label: "Customer",
        alwaysVisible: true,
        sortable: true,
        render: (i) => (
          <div>
            <div>{i.customerName}</div>
            {i.customerTrn && (
              <div className="mono" style={{ fontSize: 12, color: "var(--color-ink-faint)", marginTop: 2 }}>
                {i.customerTrn}
              </div>
            )}
          </div>
        ),
      },
      { key: "issueDate", label: "Issue Date", sortable: true, render: (i) => formatDate(i.issueDate) },
      { key: "dueDate", label: "Due Date", sortable: true, render: (i) => formatDate(i.dueDate) },
      { key: "status", label: "Status", sortable: true, render: (i) => <DocumentStatusChip invoice={i} /> },
      { key: "paymentStatus", label: "Payment Status", sortable: true, render: (i) => <PaymentStatusChip invoice={i} /> },
      { key: "grandTotal", label: "Total", sortable: true, align: "right", render: (i) => formatCurrency(i.grandTotal) },
      { key: "outstandingAmount", label: "Outstanding", sortable: true, align: "right", render: (i) => formatCurrency(i.outstandingAmount) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (i) => {
          const remaining = creditEligibilityMap.get(i.id)?.remaining ?? 0;
          const items = [
            { label: "View", onClick: () => router.push(`/tenant/invoices/${i.id}`) },
            {
              label: "Edit",
              onClick: () => router.push(`/tenant/invoices/${i.id}`),
              disabled: i.status !== "DRAFT",
              disabledReason: "Only Draft invoices can be edited.",
            },
            { label: "Duplicate", onClick: () => handleDuplicateSingle(i), disabled: bulkBusy },
            { label: "Download PDF", onClick: () => downloadInvoicePdf(i), disabled: bulkBusy },
            {
              label: "Send",
              onClick: () => handleSendSingle(i),
              disabled: bulkBusy || archivedView || i.status !== "DRAFT",
              disabledReason: archivedView ? "Restore this invoice first." : "Only Draft invoices can be sent.",
            },
          ];
          // Only ever shown for Sent invoices with a remaining creditable
          // amount, and only if the user actually holds the permission -
          // never rendered disabled-but-visible for someone unauthorized.
          if (can("credit_notes.create")) {
            items.push({
              label: "Create Credit Note",
              onClick: () => router.push(`/tenant/credit-notes/new?invoiceId=${i.id}`),
              disabled: archivedView || i.status !== "SENT" || remaining <= 0.01,
              disabledReason: i.status !== "SENT" ? "Only Sent invoices can be credited." : "No creditable amount remains on this invoice.",
            });
          }
          items.push(
            { label: archivedView ? "Restore" : "Archive", onClick: () => handleArchiveRestoreSingle(i), disabled: bulkBusy },
            {
              label: "Delete",
              danger: true,
              onClick: () => setDeleteTarget(i),
              disabled: i.status !== "DRAFT",
              disabledReason: "Only Draft invoices can be deleted.",
            },
            { label: "History", onClick: () => router.push(`/tenant/invoices/${i.id}`) },
            { label: "Audit", disabled: true, disabledReason: "Not available yet." }
          );
          return <ActionMenu ariaLabel={`Actions for ${i.invoiceNumberDisplay || "draft invoice"}`} items={items} />;
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedIds, archivedView, bulkBusy, creditEligibilityMap, can]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  // _v2 (2026-08-06 redesign): the column set itself changed (customerTrn
  // merged into customerName, paymentStatus split out as its own column) -
  // same total count as before, so the old length-mismatch fallback below
  // wouldn't have caught a stale saved order still referencing the removed
  // key/missing the new one. A fresh storage key sidesteps that instead of
  // trying to migrate an old array in place.
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_invoice_list_column_order_v2", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_invoice_list_hidden_columns_v2", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const customers = useMemo(() => {
    if (!invoices) return [];
    return Array.from(new Set(invoices.map((i) => i.customerName))).sort();
  }, [invoices]);

  const stats = useMemo(() => {
    if (!invoices) return null;
    const sentNonVoid = invoices.filter((i) => i.status === "SENT");
    const paidSent = sentNonVoid.filter((i) => i.paymentStatus === "PAID");
    return {
      total: invoices.length,
      draft: invoices.filter((i) => i.status === "DRAFT").length,
      sent: sentNonVoid.length,
      paid: paidSent.length,
      outstanding: sentNonVoid.reduce((sum, i) => sum + (i.outstandingAmount || 0), 0),
    };
  }, [invoices]);

  const filtered = useMemo(() => {
    if (!invoices) return [];
    const q = search.trim().toLowerCase();
    let list = invoices.filter((i) => {
      const matchesSearch =
        !q ||
        (i.invoiceNumberDisplay || "").toLowerCase().includes(q) ||
        i.customerName.toLowerCase().includes(q) ||
        (i.customerTrn || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || i.status === statusFilter;
      const matchesPaymentStatus = paymentStatusFilter === "ALL" || i.paymentStatus === paymentStatusFilter;
      const matchesCustomer = customerFilter === "ALL" || i.customerName === customerFilter;
      const issueTime = i.issueDate ? new Date(i.issueDate).getTime() : null;
      const matchesFrom = !dateFrom || (issueTime !== null && issueTime >= new Date(dateFrom).getTime());
      const matchesTo = !dateTo || (issueTime !== null && issueTime <= new Date(dateTo).getTime() + 86399999);
      const dueTime = i.dueDate ? new Date(i.dueDate).getTime() : null;
      const matchesDueFrom = !dueDateFrom || (dueTime !== null && dueTime >= new Date(dueDateFrom).getTime());
      const matchesDueTo = !dueDateTo || (dueTime !== null && dueTime <= new Date(dueDateTo).getTime() + 86399999);
      return matchesSearch && matchesStatus && matchesPaymentStatus && matchesCustomer && matchesFrom && matchesTo && matchesDueFrom && matchesDueTo;
    });
    return sortInvoices(list, sortKey, sortDirection);
  }, [invoices, search, statusFilter, paymentStatusFilter, customerFilter, dateFrom, dateTo, dueDateFrom, dueDateTo, sortKey, sortDirection]);

  function handleSortChange(key) {
    if (sortKey === key) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDirection("asc");
    }
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);
  pageItemsRef.current = pageItems;

  const selectedInvoices = useMemo(() => invoices?.filter((i) => selectedIds.has(i.id)) || [], [invoices, selectedIds]);

  // Off-screen render, one invoice at a time, using the exact same
  // ClassicTemplate + jsPDF pipeline as the Viewer (Sprint 2) - not a second
  // PDF engine, just this page driving it for one or many invoices in a row.
  function renderInvoiceOffscreen(invoice) {
    return new Promise((resolve) => {
      bulkRenderResolveRef.current = resolve;
      setBulkRenderInvoice(invoice);
    });
  }
  useEffect(() => {
    if (!bulkRenderInvoice) return;
    const t = setTimeout(() => bulkRenderResolveRef.current?.(), 150);
    return () => clearTimeout(t);
  }, [bulkRenderInvoice]);

  // Shared by the bulk toolbar and the row-level "Download PDF" action -
  // same jsPDF/ClassicTemplate pipeline either way, just called once vs in
  // a loop, with a different InvoiceActivity note for the audit trail.
  async function downloadOneInvoicePdf(jsPDFCtor, token, summary, activityNote) {
    const { invoice } = await api.getInvoice(token, summary.id);
    await renderInvoiceOffscreen(invoice);
    const doc = new jsPDFCtor({ orientation: "p", unit: "mm", format: "a4" });
    await doc.html(bulkRenderRef.current, { x: 0, y: 0, width: 210, windowWidth: bulkRenderRef.current.offsetWidth, autoPaging: "text" });
    doc.save(`${invoice.invoiceNumberDisplay || "Draft-Invoice"}.pdf`);
    api.logInvoiceActivity(token, invoice.id, "DOWNLOADED", activityNote).catch(() => {});
  }

  async function downloadInvoicePdf(invoice) {
    setBulkBusy(true);
    try {
      const { jsPDF } = await import("jspdf");
      const token = tenantAuth.get();
      await downloadOneInvoicePdf(jsPDF, token, invoice, "PDF");
      showToast(`Downloaded ${invoice.invoiceNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkRenderInvoice(null);
      setBulkBusy(false);
    }
  }

  async function handleBulkDownloadPdf() {
    setBulkBusy(true);
    try {
      const { jsPDF } = await import("jspdf");
      const token = tenantAuth.get();
      for (const summary of selectedInvoices) {
        await downloadOneInvoicePdf(jsPDF, token, summary, "PDF (bulk)");
      }
      showToast(`Downloaded ${selectedInvoices.length} invoice PDF(s).`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkRenderInvoice(null);
      setBulkBusy(false);
    }
  }

  async function handleBulkMarkSent() {
    const drafts = selectedInvoices.filter((i) => i.status === "DRAFT");
    if (drafts.length === 0) {
      showToast("No Draft invoices selected.");
      return;
    }
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      for (const inv of drafts) {
        await api.sendInvoice(token, inv.id);
      }
      showToast(`Sent ${drafts.length} invoice(s).`);
      setSelectedIds(new Set());
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleBulkMarkPaid() {
    const payable = selectedInvoices.filter((i) => i.status === "SENT" && i.outstandingAmount > 0);
    if (payable.length === 0) {
      showToast("No Sent invoices with an outstanding balance selected.");
      return;
    }
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      const today = new Date().toISOString().slice(0, 10);
      for (const inv of payable) {
        await api.recordInvoicePayment(token, inv.id, {
          amount: inv.outstandingAmount,
          paymentDate: today,
          method: "OTHER",
          reference: null,
          notes: "Bulk marked as paid",
        });
      }
      showToast(`Marked ${payable.length} invoice(s) as paid.`);
      setSelectedIds(new Set());
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleBulkArchiveOrRestore() {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      for (const inv of selectedInvoices) {
        if (archivedView) await api.restoreInvoice(token, inv.id);
        else await api.archiveInvoice(token, inv.id);
      }
      showToast(archivedView ? `Restored ${selectedInvoices.length} invoice(s).` : `Archived ${selectedInvoices.length} invoice(s).`);
      setSelectedIds(new Set());
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  function handleBulkExport() {
    exportInvoicesToCsv(selectedInvoices);
  }

  function handleHeaderExport() {
    exportInvoicesToCsv(selectedIds.size > 0 ? selectedInvoices : filtered);
  }

  async function handleDuplicateSingle(invoice) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      await api.duplicateInvoice(token, invoice.id);
      showToast("Duplicated as a new Draft.");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleSendSingle(invoice) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      const result = await api.sendInvoice(token, invoice.id);
      if (result.approvalRequest) {
        showToast(`Sending requires approval - submitted as ${result.approvalRequest.referenceNumber}.`);
      } else {
        showToast(`${result.invoice.invoiceNumberDisplay} sent.`);
      }
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleArchiveRestoreSingle(invoice) {
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      if (archivedView) await api.restoreInvoice(token, invoice.id);
      else await api.archiveInvoice(token, invoice.id);
      showToast(archivedView ? "Invoice restored." : "Invoice archived.");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  async function handleConfirmDelete() {
    if (!deleteTarget) return;
    setBulkBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deleteInvoice(token, deleteTarget.id);
      showToast(`${deleteTarget.invoiceNumberDisplay || "Draft"} deleted.`);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBulkBusy(false);
    }
  }

  function handleClearAdvancedFilters() {
    setPaymentStatusFilter("ALL");
    setDueDateFrom("");
    setDueDateTo("");
    setStatusFilter("ALL");
    resetToPageOne();
  }

  if (permLoading || !allowed) return null;

  const draftOnly = statusFilter === "DRAFT";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Invoices" }]}
        title="Invoices"
        description={archivedView ? "Archived invoices — restore anytime, nothing here is ever permanently deleted." : "Every invoice you've drafted or sent, in one place."}
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="outline" onClick={() => setArchivedView((v) => !v)}>
              {archivedView ? "Back to Invoices" : "View Archived"}
            </Button>
            {invoices && invoices.length > 0 && (
              <Button variant="outline" onClick={handleHeaderExport}>
                Export
              </Button>
            )}
            {!archivedView && can("invoices.import") && (
              <Link href="/tenant/imports/new?type=SALES_INVOICE">
                <Button variant="outline">Import</Button>
              </Link>
            )}
            {!archivedView && (
              <Link href="/tenant/invoices/new">
                <Button>+ New Invoice</Button>
              </Link>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      {stats && !archivedView && (
        <div className="kpi-card-grid">
          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "ALL" && paymentStatusFilter === "ALL" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("ALL");
              setPaymentStatusFilter("ALL");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Invoices</span>
              <span className="kpi-card-icon">{KPI_ICONS.total}</span>
            </div>
            <span className="kpi-card-value">{stats.total}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Every invoice, any status
            </span>
          </button>

          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "DRAFT" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("DRAFT");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Draft</span>
              <span className="kpi-card-icon">{KPI_ICONS.draft}</span>
            </div>
            <span className="kpi-card-value">{stats.draft}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Not yet sent
            </span>
          </button>

          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${statusFilter === "SENT" && paymentStatusFilter === "ALL" ? " active" : ""}`}
            onClick={() => {
              setStatusFilter("SENT");
              setPaymentStatusFilter("ALL");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Sent</span>
              <span className="kpi-card-icon">{KPI_ICONS.sent}</span>
            </div>
            <span className="kpi-card-value">{stats.sent}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Awaiting or received payment
            </span>
          </button>

          <button
            type="button"
            className={`card kpi-card card-hoverable list-kpi-button${paymentStatusFilter === "PAID" ? " active" : ""}`}
            onClick={() => {
              setPaymentStatusFilter("PAID");
              resetToPageOne();
            }}
          >
            <div className="kpi-card-top">
              <span className="kpi-card-label">Paid</span>
              <span className="kpi-card-icon">{KPI_ICONS.paid}</span>
            </div>
            <span className="kpi-card-value">{stats.paid}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Fully settled
            </span>
          </button>

          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Outstanding Amount</span>
              <span className="kpi-card-icon">{KPI_ICONS.outstanding}</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(stats.outstanding)}</span>
            <span className="helptext" style={{ marginTop: 0 }}>
              Across all Sent invoices
            </span>
          </div>
        </div>
      )}

      {selectedIds.size > 0 && (
        <div className="invoice-bulk-toolbar">
          <span>{selectedIds.size} selected</span>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Button variant="outline" onClick={handleBulkDownloadPdf} disabled={bulkBusy}>
              Download PDF
            </Button>
            {!archivedView && (
              <>
                <Button variant="outline" onClick={handleBulkMarkSent} disabled={bulkBusy}>
                  Mark Sent
                </Button>
                <Button variant="outline" onClick={handleBulkMarkPaid} disabled={bulkBusy}>
                  Mark Paid
                </Button>
              </>
            )}
            <Button variant="outline" onClick={handleBulkExport} disabled={bulkBusy}>
              Export CSV
            </Button>
            <Button variant="outline" onClick={handleBulkArchiveOrRestore} disabled={bulkBusy}>
              {archivedView ? "Restore" : "Archive"}
            </Button>
          </div>
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        {invoices === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={7} />
          </div>
        ) : invoices.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
                <path d="M8 8h8M8 12h8M8 16h5" />
              </svg>
            }
            title={archivedView ? "No archived invoices" : "No invoices yet"}
            description={archivedView ? "Invoices you archive will show up here." : "Create your first invoice, or import historical ones from a spreadsheet."}
            action={
              !archivedView && (
                <div style={{ display: "flex", gap: 8 }}>
                  <Link href="/tenant/invoices/new">
                    <Button>+ New Invoice</Button>
                  </Link>
                  {can("invoices.import") && (
                    <Link href="/tenant/imports/new?type=SALES_INVOICE">
                      <Button variant="outline">Import</Button>
                    </Link>
                  )}
                </div>
              )
            }
          />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search by invoice #, customer, or TRN…"
                filters={
                  <>
                    <select
                      className="select-filter"
                      value={statusFilter}
                      onChange={(e) => {
                        setStatusFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All statuses</option>
                      <option value="DRAFT">Draft</option>
                      <option value="SENT">Sent</option>
                      <option value="VOID">Cancelled</option>
                    </select>
                    <select
                      className="select-filter"
                      value={customerFilter}
                      onChange={(e) => {
                        setCustomerFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All customers</option>
                      {customers.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                    <input
                      type="date"
                      className="select-filter"
                      value={dateFrom}
                      onChange={(e) => {
                        setDateFrom(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Issue date from"
                    />
                    <input
                      type="date"
                      className="select-filter"
                      value={dateTo}
                      onChange={(e) => {
                        setDateTo(e.target.value);
                        resetToPageOne();
                      }}
                      aria-label="Issue date to"
                    />
                    <Button variant="outline" onClick={() => setMoreFiltersOpen(true)}>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <FilterFunnelIcon />
                        More Filters
                      </span>
                    </Button>
                    <ColumnSelector
                      columns={COLUMN_DEFS}
                      columnOrder={columnOrder}
                      hiddenColumns={hiddenColumns}
                      onToggle={handleToggleColumn}
                      onReorder={setColumnOrder}
                    />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching invoices"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable
                    columns={COLUMN_DEFS}
                    rows={pageItems}
                    columnOrder={columnOrder}
                    hiddenColumns={hiddenColumns}
                    sortKey={sortKey}
                    sortDirection={sortDirection}
                    onSortChange={handleSortChange}
                    stickyHeader
                    zebra
                  />
                </TableScroll>
                <div className="table-pagination">
                  <span>
                    Showing {pageStart + 1}–{Math.min(pageStart + pageSize, filtered.length)} of {filtered.length} invoices
                  </span>
                  <div className="pagination-controls">
                    <div className="rows-per-page">
                      Rows per page
                      <select
                        className="select-filter"
                        value={pageSize}
                        onChange={(e) => {
                          setPageSize(Number(e.target.value));
                          resetToPageOne();
                        }}
                      >
                        {PAGE_SIZE_OPTIONS.map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="pagination-pages">
                      <button className="page-btn" disabled={currentPage === 1} onClick={() => setPage(1)} aria-label="First page">
                        «
                      </button>
                      <button className="page-btn" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)} aria-label="Previous page">
                        ‹
                      </button>
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <button key={i} className={`page-btn${currentPage === i + 1 ? " active" : ""}`} onClick={() => setPage(i + 1)}>
                          {i + 1}
                        </button>
                      ))}
                      <button
                        className="page-btn"
                        disabled={currentPage === totalPages}
                        onClick={() => setPage(currentPage + 1)}
                        aria-label="Next page"
                      >
                        ›
                      </button>
                      <button className="page-btn" disabled={currentPage === totalPages} onClick={() => setPage(totalPages)} aria-label="Last page">
                        »
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>

      <MoreFiltersDrawer
        open={moreFiltersOpen}
        onClose={() => setMoreFiltersOpen(false)}
        paymentStatusFilter={paymentStatusFilter}
        onPaymentStatusChange={(v) => {
          setPaymentStatusFilter(v);
          resetToPageOne();
        }}
        dueDateFrom={dueDateFrom}
        onDueDateFromChange={(v) => {
          setDueDateFrom(v);
          resetToPageOne();
        }}
        dueDateTo={dueDateTo}
        onDueDateToChange={(v) => {
          setDueDateTo(v);
          resetToPageOne();
        }}
        archivedView={archivedView}
        onToggleArchived={(checked) => setArchivedView(checked)}
        draftOnly={draftOnly}
        onToggleDraftOnly={(checked) => {
          setStatusFilter(checked ? "DRAFT" : "ALL");
          resetToPageOne();
        }}
        onClearAll={handleClearAdvancedFilters}
      />

      <ConfirmationDialog
        open={!!deleteTarget}
        title="Delete this draft?"
        message={`"${deleteTarget?.invoiceNumberDisplay || "This draft"}" has never been sent, so no invoice number has been consumed. This can't be undone.`}
        confirmLabel="Delete"
        variant="danger"
        busy={bulkBusy}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        {bulkRenderInvoice && <ClassicTemplate invoice={bulkRenderInvoice} businessAssets={businessAssets} ref={bulkRenderRef} />}
      </div>
    </div>
  );
}
