"use client";

import { useRouter } from "next/navigation";
import PageHeader from "../../../../components/ui/PageHeader";
import InvoiceForm from "../../../../components/invoices/InvoiceForm";

export default function NewInvoicePage() {
  const router = useRouter();

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Invoices", href: "/tenant/invoices" }, { label: "New Invoice" }]}
        title="New Invoice"
        description="Build a draft — nothing is numbered or sent until you're ready."
      />
      <InvoiceForm mode="create" onSaved={(invoice) => router.push(`/tenant/invoices/${invoice.id}`)} />
    </div>
  );
}
