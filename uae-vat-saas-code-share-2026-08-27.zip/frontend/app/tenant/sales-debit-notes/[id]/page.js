"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api, assetUrl } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import NoteStatusBadge from "../../../../components/notes/NoteStatusBadge";
import NoteActivityTimeline from "../../../../components/notes/NoteActivityTimeline";
import NoteLineItemsTable from "../../../../components/notes/NoteLineItemsTable";
import AdjustmentSummaryCard from "../../../../components/notes/AdjustmentSummaryCard";
import SalesDebitNoteClassicTemplate from "../../../../components/sales-debit-note-templates/ClassicTemplate";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Mirrors credit-notes/[id]/page.js exactly - same lifecycle (Draft ->
// Issue/Delete, Issued -> Cancel), same PDF-download technique, same
// businessAssets live-fetch. Terminology adjusted for an increase rather
// than a reduction (no "remaining eligible amount" - this document is
// additive, matching debit-notes/[id]/page.js's own no-cap framing).
export default function SalesDebitNoteDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [note, setNote] = useState(null);
  const [adjustment, setAdjustment] = useState(null);
  const [businessAssets, setBusinessAssets] = useState({});
  const [error, setError] = useState("");
  const [confirmAction, setConfirmAction] = useState(null); // "issue" | "delete" | "void"
  const [busy, setBusy] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { salesDebitNote, adjustment } = await api.getSalesDebitNote(token, params.id);
      setNote(salesDebitNote);
      setAdjustment(adjustment);
      api
        .getBusinessProfile(token)
        .then(({ businessProfile }) =>
          setBusinessAssets({ logoUrl: assetUrl(businessProfile.logoUrl), stampUrl: assetUrl(businessProfile.stampUrl), signatureUrl: assetUrl(businessProfile.signatureUrl) })
        )
        .catch(() => {});
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleIssue() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const result = await api.issueSalesDebitNote(token, params.id);
      setConfirmAction(null);
      if (result.approvalRequest) {
        showToast(`Issuing requires approval - submitted as ${result.approvalRequest.referenceNumber}. This stays a Draft until a checker decides.`);
        await load();
      } else {
        setNote(result.salesDebitNote);
        showToast(`${result.salesDebitNote.salesDebitNoteNumberDisplay} was issued.`);
        await load();
      }
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.deleteSalesDebitNote(token, params.id);
      showToast("Draft deleted.");
      router.push("/tenant/sales-debit-notes");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
      setBusy(false);
    }
  }

  async function handleVoid() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { salesDebitNote } = await api.voidSalesDebitNote(token, params.id);
      setNote(salesDebitNote);
      setConfirmAction(null);
      showToast("Debit note cancelled.");
    } catch (err) {
      setError(err.message);
      setConfirmAction(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleDownloadPdf() {
    setDownloading(true);
    try {
      const node = document.getElementById("sales-debit-note-pdf-source");
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      await doc.html(node, { x: 0, y: 0, width: 210, windowWidth: node.offsetWidth, autoPaging: "text" });
      doc.save(`${note.salesDebitNoteNumberDisplay || "Draft-DebitNote"}.pdf`);
      const token = tenantAuth.get();
      api.logSalesDebitNoteActivity(token, note.id, "DOWNLOADED", "PDF").catch(() => {});
      showToast(`Downloaded ${note.salesDebitNoteNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setDownloading(false);
    }
  }

  if (!note) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/sales-debit-notes" }, { label: "…" }]} title="Debit Note" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const title = note.salesDebitNoteNumberDisplay || "Draft Debit Note";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/sales-debit-notes" }, { label: title }]}
        title={title}
        eyebrow={<NoteStatusBadge status={note.status} />}
        description={
          note.status === "DRAFT"
            ? "This debit note hasn't been issued — it isn't numbered and has no VAT effect yet."
            : `Issued ${formatDate(note.issueDate)}`
        }
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="outline" onClick={handleDownloadPdf} disabled={downloading}>
              Download PDF
            </Button>
            {note.status === "DRAFT" && (
              <>
                <Button variant="outline" onClick={() => setConfirmAction("delete")}>
                  Delete Draft
                </Button>
                <Button onClick={() => setConfirmAction("issue")}>Issue Debit Note</Button>
              </>
            )}
            {note.status === "ISSUED" && (
              <Button variant="outline" onClick={() => setConfirmAction("void")}>
                Cancel Debit Note
              </Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Original Invoice</h3>
            <p style={{ margin: 0 }}>
              <Link href={`/tenant/invoices/${note.invoice.id}`} className="mono">
                {note.invoice.invoiceNumberDisplay}
              </Link>
            </p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Customer</h3>
            <p style={{ margin: 0 }}>{note.customerName}</p>
            {note.customerAddress && <p className="helptext" style={{ margin: 0 }}>{note.customerAddress}</p>}
            {note.customerTrn && <p className="helptext mono" style={{ margin: 0 }}>TRN: {note.customerTrn}</p>}
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Reason</h3>
            <p style={{ margin: 0 }}>{note.reason}</p>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Line Items</h3>
            <NoteLineItemsTable lineItems={note.lineItems} currency={note.currency} />
          </Card>

          {note.notes && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Notes</h3>
              <p style={{ margin: 0 }}>{note.notes}</p>
            </Card>
          )}

          <Card>
            <h3 style={{ marginTop: 0 }}>Activity</h3>
            <NoteActivityTimeline activities={note.activities} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          {adjustment && (
            <AdjustmentSummaryCard
              currency={note.currency}
              originalAmount={adjustment.originalAmount}
              previouslyAdjusted={adjustment.previouslyAdjusted}
              previouslyLabel="Previously Adjusted"
              currentNote={adjustment.currentNote ?? note.grandTotal}
              currentLabel="This Debit Note"
            />
          )}
          <Card>
            <h3 style={{ marginTop: 0 }}>Totals</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Subtotal</span>
                <span className="review-value mono">{note.currency} {Number(note.subtotal).toFixed(2)}</span>
              </div>
              <div className="review-row">
                <span className="review-label">VAT</span>
                <span className="review-value mono">{note.currency} {Number(note.vatTotal).toFixed(2)}</span>
              </div>
              <div className="review-row" style={{ fontWeight: 600 }}>
                <span className="review-label">Grand Total</span>
                <span className="review-value mono">{note.currency} {Number(note.grandTotal).toFixed(2)}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <ConfirmationDialog
        open={confirmAction === "issue"}
        title="Issue this debit note?"
        message="This assigns a permanent debit note number, freezes the document, and increases output VAT for the period containing this issue date. This can't be undone."
        confirmLabel="Issue Debit Note"
        busy={busy}
        onConfirm={handleIssue}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "delete"}
        title="Delete this draft?"
        message="This draft has never been issued, so no debit note number has been consumed. This can't be undone."
        confirmLabel="Delete Draft"
        variant="danger"
        busy={busy}
        onConfirm={handleDelete}
        onCancel={() => setConfirmAction(null)}
      />
      <ConfirmationDialog
        open={confirmAction === "void"}
        title="Cancel this debit note?"
        message="A cancelled debit note's number is never reused, and its VAT effect is reversed from this point forward. This can't be undone."
        confirmLabel="Cancel Debit Note"
        variant="danger"
        busy={busy}
        onConfirm={handleVoid}
        onCancel={() => setConfirmAction(null)}
      />

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        <div id="sales-debit-note-pdf-source">
          <SalesDebitNoteClassicTemplate salesDebitNote={note} businessAssets={businessAssets} />
        </div>
      </div>
    </div>
  );
}
