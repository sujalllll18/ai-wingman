"use client";

import { useSearchParams } from "next/navigation";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import SalesDebitNoteForm from "../../../../components/sales-debit-notes/SalesDebitNoteForm";

export default function NewSalesDebitNotePage() {
  const searchParams = useSearchParams();
  const invoiceId = searchParams.get("invoiceId");

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes", href: "/tenant/sales-debit-notes" }, { label: "New Debit Note" }]}
        title="New Debit Note"
        description="Build a draft against a Sent invoice — nothing is numbered or VAT-effective until you issue it."
      />
      {invoiceId ? (
        <SalesDebitNoteForm invoiceId={invoiceId} />
      ) : (
        <ErrorBanner message="No invoice selected. Start a Debit Note from an invoice's detail page." />
      )}
    </div>
  );
}
