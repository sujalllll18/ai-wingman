"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, assetUrl } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import NoteStatusBadge from "../../../components/notes/NoteStatusBadge";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import SalesDebitNoteClassicTemplate from "../../../components/sales-debit-note-templates/ClassicTemplate";

function formatCurrency(value) {
  return `AED ${Number(value || 0).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Sales Debit Note list page (2026-08-11) - same enterprise list pattern as
// Credit Notes/Invoices/Purchases (Table, Toolbar, Pagination, ActionMenu,
// status badges, Empty/Loading states, KPI summary cards). Row-level
// "Download PDF" reuses the exact off-screen-render + jsPDF.html() technique
// the Invoices list page's bulk-export already established - not a second
// PDF pipeline.
export default function SalesDebitNotesPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("sales_debit_notes.view");
  const { showToast } = useToast();

  const [notes, setNotes] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [customerFilter, setCustomerFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [businessAssets, setBusinessAssets] = useState({});
  const [renderNote, setRenderNote] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const docRef = useRef(null);
  const resolveRef = useRef(null);

  useEffect(() => {
    load();
    const token = tenantAuth.get();
    api
      .getBusinessProfile(token)
      .then(({ businessProfile }) =>
        setBusinessAssets({ logoUrl: assetUrl(businessProfile.logoUrl), stampUrl: assetUrl(businessProfile.stampUrl), signatureUrl: assetUrl(businessProfile.signatureUrl) })
      )
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { salesDebitNotes } = await api.listSalesDebitNotes(token);
      setNotes(salesDebitNotes);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function handleExport() {
    const rows = [
      ["Debit Note #", "Original Invoice", "Customer", "Issue Date", "Status", "Subtotal", "VAT", "Total"],
      ...filtered.map((n) => [
        n.salesDebitNoteNumberDisplay || "Draft",
        n.invoice?.invoiceNumberDisplay || "",
        n.customerName,
        n.issueDate ? formatDate(n.issueDate) : "",
        n.status,
        n.subtotal,
        n.vatTotal,
        n.grandTotal,
      ]),
    ];
    downloadCsv(`debit-notes-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  }

  function renderOffscreen(note) {
    return new Promise((resolve) => {
      resolveRef.current = resolve;
      setRenderNote(note);
    });
  }
  useEffect(() => {
    if (!renderNote) return;
    const t = setTimeout(() => resolveRef.current?.(), 150);
    return () => clearTimeout(t);
  }, [renderNote]);

  async function handleDownloadPdf(summary) {
    setDownloading(true);
    try {
      const token = tenantAuth.get();
      const { salesDebitNote } = await api.getSalesDebitNote(token, summary.id);
      await renderOffscreen(salesDebitNote);
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      await doc.html(docRef.current, { x: 0, y: 0, width: 210, windowWidth: docRef.current.offsetWidth, autoPaging: "text" });
      doc.save(`${salesDebitNote.salesDebitNoteNumberDisplay || "Draft-DebitNote"}.pdf`);
      api.logSalesDebitNoteActivity(token, salesDebitNote.id, "DOWNLOADED", "PDF").catch(() => {});
      showToast(`Downloaded ${salesDebitNote.salesDebitNoteNumberDisplay || "Draft"}.pdf`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setRenderNote(null);
      setDownloading(false);
    }
  }

  const customers = useMemo(() => {
    if (!notes) return [];
    return Array.from(new Set(notes.map((n) => n.customerName))).sort();
  }, [notes]);

  const filtered = useMemo(() => {
    if (!notes) return [];
    const q = search.trim().toLowerCase();
    return notes.filter((n) => {
      const matchesSearch =
        !q ||
        (n.salesDebitNoteNumberDisplay || "").toLowerCase().includes(q) ||
        (n.invoice?.invoiceNumberDisplay || "").toLowerCase().includes(q) ||
        n.customerName.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || n.status === statusFilter;
      const matchesCustomer = customerFilter === "ALL" || n.customerName === customerFilter;
      return matchesSearch && matchesStatus && matchesCustomer;
    });
  }, [notes, search, statusFilter, customerFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  const kpis = useMemo(() => {
    if (!notes) return null;
    const draft = notes.filter((n) => n.status === "DRAFT");
    const issued = notes.filter((n) => n.status === "ISSUED");
    const cancelled = notes.filter((n) => n.status === "VOID");
    return {
      total: notes.length,
      draft: draft.length,
      issued: issued.length,
      cancelled: cancelled.length,
      totalValue: issued.reduce((s, n) => s + n.grandTotal, 0),
      totalVat: issued.reduce((s, n) => s + n.vatTotal, 0),
    };
  }, [notes]);

  const COLUMNS = useMemo(
    () => [
      {
        key: "salesDebitNoteNumberDisplay",
        header: "Debit Note #",
        render: (n) => <span className="mono" style={{ fontWeight: 600 }}>{n.salesDebitNoteNumberDisplay || "Draft"}</span>,
      },
      { key: "invoice", header: "Original Invoice", render: (n) => <span className="mono">{n.invoice?.invoiceNumberDisplay || "—"}</span> },
      { key: "customerName", header: "Customer", render: (n) => n.customerName },
      { key: "issueDate", header: "Date", render: (n) => formatDate(n.issueDate) },
      { key: "status", header: "Status", render: (n) => <NoteStatusBadge status={n.status} /> },
      { key: "vatTotal", header: "VAT", className: "num", render: (n) => formatCurrency(n.vatTotal) },
      { key: "grandTotal", header: "Total", className: "num", render: (n) => formatCurrency(n.grandTotal) },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (n) => (
          <ActionMenu
            ariaLabel={`Actions for ${n.salesDebitNoteNumberDisplay || "draft debit note"}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/sales-debit-notes/${n.id}`) },
              { label: "Download PDF", onClick: () => handleDownloadPdf(n), disabled: downloading },
            ]}
          />
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [router, downloading]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Debit Notes" }]}
        title="Debit Notes"
        description="Every increase issued against a Sent invoice, in one place. Start a new one from the original invoice."
        action={
          notes &&
          notes.length > 0 && (
            <Button variant="outline" onClick={handleExport}>
              Export
            </Button>
          )
        }
      />

      <ErrorBanner message={error} />

      {kpis && (
        <div className="kpi-card-grid">
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Debit Notes</span>
            </div>
            <span className="kpi-card-value">{kpis.total}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Draft</span>
            </div>
            <span className="kpi-card-value">{kpis.draft}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Issued</span>
            </div>
            <span className="kpi-card-value">{kpis.issued}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Cancelled</span>
            </div>
            <span className="kpi-card-value">{kpis.cancelled}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total Value</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalValue)}</span>
          </div>
          <div className="card kpi-card">
            <div className="kpi-card-top">
              <span className="kpi-card-label">Total VAT Adjustment</span>
            </div>
            <span className="kpi-card-value">{formatCurrency(kpis.totalVat)}</span>
          </div>
        </div>
      )}

      <div className="table-block">
        {notes === null ? (
          <LoadingSkeleton columns={7} />
        ) : notes.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <rect x="4" y="3.5" width="16" height="17" rx="1.5" />
                <path d="M8 12h8" />
              </svg>
            }
            title="No debit notes yet"
            description="Issue a Debit Note from an invoice's detail page when a Sent invoice needs to be increased — for example, a forgotten line item."
            action={
              <Link href="/tenant/invoices">
                <Button>Go to Invoices</Button>
              </Link>
            }
          />
        ) : (
          <>
            <Toolbar
              title="Debit Notes"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by debit note #, invoice #, or customer…"
              filters={
                <>
                  <select
                    className="select-filter"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All statuses</option>
                    <option value="DRAFT">Draft</option>
                    <option value="ISSUED">Issued</option>
                    <option value="VOID">Cancelled</option>
                  </select>
                  <select
                    className="select-filter"
                    value={customerFilter}
                    onChange={(e) => {
                      setCustomerFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All customers</option>
                    {customers.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </>
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching debit notes"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} onRowClick={(n) => router.push(`/tenant/sales-debit-notes/${n.id}`)} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Debit Notes"
                />
              </>
            )}
          </>
        )}
      </div>

      <div style={{ position: "fixed", top: -10000, left: -10000, zIndex: -1 }} aria-hidden="true">
        {renderNote && <SalesDebitNoteClassicTemplate salesDebitNote={renderNote} businessAssets={businessAssets} ref={docRef} />}
      </div>
    </div>
  );
}
