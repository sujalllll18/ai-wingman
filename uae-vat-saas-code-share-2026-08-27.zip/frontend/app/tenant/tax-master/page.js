"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../../lib/api";
import { tenantAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import { useRequirePermission } from "../../../hooks/useRequirePermission";
import { usePermissions } from "../../../hooks/usePermissions";
import PageHeader from "../../../components/ui/PageHeader";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Table from "../../../components/ui/Table";
import TableScroll from "../../../components/ui/TableScroll";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import EmptyState from "../../../components/ui/EmptyState";
import ActionMenu from "../../../components/ui/ActionMenu";
import Pagination from "../../../components/ui/Pagination";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import RateFormModal from "../../../components/tax-master/RateFormModal";
import RateHistoryModal from "../../../components/tax-master/RateHistoryModal";
import { calculationMethodLabel, CALCULATION_METHODS } from "../../../lib/taxCalculationMethods";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function TaxMasterPage() {
  const { allowed, loading: permLoading } = useRequirePermission("tax_master.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [rates, setRates] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [calcFilter, setCalcFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [formModal, setFormModal] = useState(null); // { mode, rate } | null
  const [historyRateName, setHistoryRateName] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { rates } = await api.listTaxRates(token);
      setRates(rates);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  function handleFormSuccess(name, approvalRequest) {
    setFormModal(null);
    if (approvalRequest) {
      showToast(`"${name}" requires approval - submitted as ${approvalRequest.referenceNumber}.`);
    } else {
      showToast(`"${name}" saved.`);
    }
    load();
  }

  async function handleStatusChange(rate, targetStatus) {
    setBusyId(rate.id);
    try {
      const token = tenantAuth.get();
      const result = targetStatus === "ACTIVE" ? await api.activateTaxRate(token, rate.id) : await api.deactivateTaxRate(token, rate.id);
      if (result.approvalRequest) {
        showToast(`Requires approval - submitted as ${result.approvalRequest.referenceNumber}.`);
      } else {
        showToast(`"${rate.name}" ${targetStatus === "ACTIVE" ? "activated" : "deactivated"}.`);
      }
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setBusyId(deleteTarget.id);
    try {
      const token = tenantAuth.get();
      const result = await api.deleteTaxRate(token, deleteTarget.id);
      if (result.approvalRequest) {
        showToast(`Deletion requires approval - submitted as ${result.approvalRequest.referenceNumber}.`);
      } else {
        showToast(`"${deleteTarget.name}" deleted.`);
      }
      setDeleteTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
      setDeleteTarget(null);
    } finally {
      setBusyId(null);
    }
  }

  // The main screen only ever shows the current (latest) version of each
  // named rate - full history (including superseded rows) lives behind
  // "View History" per row, not cluttering the primary list.
  const currentRates = useMemo(() => (rates || []).filter((r) => r.isCurrentVersion), [rates]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return currentRates.filter((r) => {
      const matchesSearch = !q || r.name.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || r.status === statusFilter;
      const matchesCalc = calcFilter === "ALL" || r.calculationMethod === calcFilter;
      return matchesSearch && matchesStatus && matchesCalc;
    });
  }, [currentRates, search, statusFilter, calcFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * pageSize, (currentPage - 1) * pageSize + pageSize);

  const COLUMNS = [
    { key: "name", header: "Tax Name", render: (r) => r.name },
    { key: "percentage", header: "Rate", className: "num", render: (r) => `${r.percentage}%` },
    { key: "calc", header: "Calculation", render: (r) => calculationMethodLabel(r.calculationMethod) },
    { key: "from", header: "Applicable From", render: (r) => formatDate(r.effectiveFrom) },
    { key: "to", header: "Applicable To", render: (r) => formatDate(r.effectiveTo) },
    { key: "status", header: "Current Status", render: (r) => <span className={`badge ${r.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{r.status === "ACTIVE" ? "Active" : "Inactive"}</span> },
    { key: "modified", header: "Last Modified", render: (r) => formatDate(r.updatedAt) },
    { key: "modifiedBy", header: "Modified By", render: (r) => r.updatedByName || r.createdByName || "—" },
    {
      key: "actions",
      header: "",
      className: "num",
      render: (r) => (
        <ActionMenu
          ariaLabel={`Actions for ${r.name}`}
          items={[
            { label: "View", onClick: () => setFormModal({ mode: "view", rate: r }) },
            can("tax_master.update") && { label: "Create New Version", onClick: () => setFormModal({ mode: "version", rate: r }) },
            { label: "View History", onClick: () => setHistoryRateName(r.name) },
            can("tax_master.activate") && {
              label: "Activate",
              onClick: () => handleStatusChange(r, "ACTIVE"),
              disabled: r.status === "ACTIVE" || busyId === r.id,
              disabledReason: r.status === "ACTIVE" ? "This rate is already active." : undefined,
            },
            can("tax_master.deactivate") && {
              label: "Deactivate",
              onClick: () => handleStatusChange(r, "INACTIVE"),
              disabled: r.status === "INACTIVE" || busyId === r.id,
              disabledReason: r.status === "INACTIVE" ? "This rate is already inactive." : undefined,
            },
            can("tax_master.create") && { label: "Duplicate", onClick: () => setFormModal({ mode: "create", rate: r }) },
            can("tax_master.delete") && {
              label: "Delete",
              danger: true,
              onClick: () => setDeleteTarget(r),
              disabled: r.isUsed || r.version > 1,
              disabledReason: r.isUsed
                ? "This tax rate has already been used on invoices or purchases."
                : r.version > 1
                ? "This rate has version history - deactivate it instead."
                : undefined,
            },
          ].filter(Boolean)}
        />
      ),
    },
  ];

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Tax Master" }]}
        title="Tax Master"
        description="The single source of truth for every tax percentage used across Ledger."
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {rates === null ? (
          <LoadingSkeleton columns={9} />
        ) : (
          <>
            <Toolbar
              title="Tax Rates"
              searchValue={search}
              onSearchChange={(e) => {
                setSearch(e.target.value);
                resetToPageOne();
              }}
              searchPlaceholder="Search by tax name…"
              filters={
                <>
                  <select
                    className="select-filter"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All statuses</option>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                  <select
                    className="select-filter"
                    value={calcFilter}
                    onChange={(e) => {
                      setCalcFilter(e.target.value);
                      resetToPageOne();
                    }}
                  >
                    <option value="ALL">All calculation types</option>
                    {CALCULATION_METHODS.map((m) => (
                      <option key={m.value} value={m.value}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                </>
              }
              action={
                can("tax_master.create") && (
                  <Button onClick={() => setFormModal({ mode: "create", rate: null })}>+ Add Tax Rate</Button>
                )
              }
            />

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <path d="M4 6h16M4 12h10M4 18h13" />
                    <circle cx="19" cy="12" r="1.6" />
                    <circle cx="20" cy="18" r="1.6" />
                  </svg>
                }
                title="No tax rates yet"
                description="Add your first tax rate to start pricing invoices and purchases."
                action={can("tax_master.create") && <Button onClick={() => setFormModal({ mode: "create", rate: null })}>+ Add Tax Rate</Button>}
              />
            ) : (
              <>
                <TableScroll>
                  <Table columns={COLUMNS} rows={pageItems} />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="Tax Rates"
                />
              </>
            )}
          </>
        )}
      </div>

      <RateFormModal
        key={formModal ? `${formModal.mode}-${formModal.rate?.id || "new"}` : "closed"}
        open={!!formModal}
        onClose={() => setFormModal(null)}
        mode={formModal?.mode || "create"}
        rate={formModal?.rate || null}
        onSuccess={handleFormSuccess}
      />

      <RateHistoryModal open={!!historyRateName} onClose={() => setHistoryRateName(null)} rateName={historyRateName} rates={rates || []} />

      <ConfirmationDialog
        open={!!deleteTarget}
        title="Delete this tax rate?"
        message={`"${deleteTarget?.name}" has never been used and has no version history, so this can be removed completely. This can't be undone.`}
        confirmLabel="Delete"
        variant="danger"
        busy={busyId === deleteTarget?.id}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
