"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import { usePermissions } from "../../../../../hooks/usePermissions";
import ReconciliationStatusBadge from "../../../../../components/reconciliation/ReconciliationStatusBadge";

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export default function BankTransactionDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { can } = usePermissions();
  const [transaction, setTransaction] = useState(null);
  const [importBatch, setImportBatch] = useState(null);
  const [matches, setMatches] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      setError("");
      try {
        const token = tenantAuth.get();
        const { transaction, importBatch } = await api.getBankTransaction(token, params.id);
        setTransaction(transaction);
        setImportBatch(importBatch);
      } catch (err) {
        setError(err.message);
        return;
      }
      // Reconciliation is a separate, RBAC-gated fetch - a 403 here (a role
      // with no reconciliation.view at all) shouldn't blank the whole page,
      // it should just leave the Reconciliation card showing nothing.
      try {
        const token = tenantAuth.get();
        const reconciliation = await api.getReconciliationTransaction(token, params.id);
        setMatches(reconciliation.matches.filter((m) => m.status === "CONFIRMED" || m.status === "SUGGESTED"));
      } catch (err) {
        setMatches([]);
      }
    })();
  }, [params.id]);

  if (!transaction) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Transactions", href: "/tenant/banking/transactions" }, { label: "…" }]} title="Bank Transaction" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Transactions", href: "/tenant/banking/transactions" }, { label: formatDate(transaction.transactionDate) }]}
        title={transaction.description || "Bank Transaction"}
        eyebrow={<ReconciliationStatusBadge status={transaction.reconciliationStatus} />}
        description={`${transaction.bankAccount.accountName} · ${transaction.bankAccount.bankName}`}
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Transaction Details</h3>
            <div className="review-list">
              <div className="review-row"><span className="review-label">Transaction Date</span><span className="review-value">{formatDate(transaction.transactionDate)}</span></div>
              <div className="review-row"><span className="review-label">Value Date</span><span className="review-value">{formatDate(transaction.valueDate)}</span></div>
              <div className="review-row">
                <span className="review-label">Bank Account</span>
                <span className="review-value">
                  <Link href={`/tenant/banking/accounts/${transaction.bankAccount.id}`}>{transaction.bankAccount.accountName}</Link>
                </span>
              </div>
              <div className="review-row"><span className="review-label">Description</span><span className="review-value">{transaction.description || "—"}</span></div>
              <div className="review-row"><span className="review-label">Reference</span><span className="review-value">{transaction.reference || "—"}</span></div>
              <div className="review-row"><span className="review-label">Debit</span><span className="review-value mono">{transaction.debit > 0 ? formatCurrency(transaction.debit, transaction.currency) : "—"}</span></div>
              <div className="review-row"><span className="review-label">Credit</span><span className="review-value mono">{transaction.credit > 0 ? formatCurrency(transaction.credit, transaction.currency) : "—"}</span></div>
              <div className="review-row" style={{ fontWeight: 600 }}><span className="review-label">Balance</span><span className="review-value mono">{formatCurrency(transaction.runningBalance, transaction.currency)}</span></div>
              {transaction.transactionType && <div className="review-row"><span className="review-label">Transaction Type</span><span className="review-value">{transaction.transactionType}</span></div>}
            </div>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Source</h3>
            <div className="review-list">
              <div className="review-row"><span className="review-label">Source</span><span className="review-value">{transaction.source === "IMPORT" ? "Imported" : transaction.source}</span></div>
              <div className="review-row"><span className="review-label">Source File</span><span className="review-value">{transaction.sourceFileName || "—"}</span></div>
              <div className="review-row"><span className="review-label">Source Row</span><span className="review-value">{transaction.sourceRow ?? "—"}</span></div>
              {importBatch && (
                <div className="review-row">
                  <span className="review-label">Import Batch</span>
                  <span className="review-value">
                    <Link href={`/tenant/imports/${importBatch.id}`} className="mono">{importBatch.batchNumber}</Link>
                  </span>
                </div>
              )}
            </div>
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Reconciliation</h3>
            <div className="review-list">
              <div className="review-row">
                <span className="review-label">Status</span>
                <ReconciliationStatusBadge status={transaction.reconciliationStatus} />
              </div>
            </div>

            {matches.length > 0 ? (
              <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
                {matches.map((m) => {
                  const partyLabel = m.ledgerLines.map((l) => l.payment?.customerName || l.purchasePayment?.vendorName).filter(Boolean).join(", ");
                  const numberLabel = m.ledgerLines.map((l) => l.payment?.paymentNumberDisplay || l.purchasePayment?.paymentNumberDisplay).filter(Boolean).join(", ");
                  return (
                    <div key={m.id} className="review-row">
                      <span className="review-label">{m.status === "CONFIRMED" ? "Matched Payment" : "Suggested"}</span>
                      <span className="review-value">
                        <Link href={m.status === "CONFIRMED" ? `/tenant/banking/reconciliation/matches/${m.id}` : `/tenant/banking/reconciliation/${transaction.id}`}>
                          {numberLabel || "View"}
                        </Link>
                        {partyLabel && <span className="helptext" style={{ display: "block" }}>{partyLabel}</span>}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="helptext" style={{ marginTop: 12 }}>No reconciliation match yet.</p>
            )}

            {can("reconciliation.view") && transaction.reconciliationStatus !== "RECONCILED" && (
              <Button variant="outline" style={{ marginTop: 12, width: "100%" }} onClick={() => router.push(`/tenant/banking/reconciliation/${transaction.id}`)}>
                {transaction.reconciliationStatus === "SUGGESTED" ? "Review Match" : "Find Match"}
              </Button>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
