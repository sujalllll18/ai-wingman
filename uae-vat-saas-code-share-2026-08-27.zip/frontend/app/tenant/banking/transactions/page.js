"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Pagination from "../../../../components/ui/Pagination";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import ReconciliationStatusBadge from "../../../../components/reconciliation/ReconciliationStatusBadge";

function formatCurrency(value, currency) {
  if (!value) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Server-side filtered/paginated - this table is designed to hold
// 100,000+ rows (Migration Engine's own scale target), so unlike Invoices/
// Purchases this page never fetches "everything" and filters client-side.
export default function BankTransactionsPage() {
  const { allowed, loading: permLoading } = useRequirePermission("banking.view_transactions");
  const router = useRouter();
  const searchParams = useSearchParams();

  const [accounts, setAccounts] = useState([]);
  const [bankAccountId, setBankAccountId] = useState(searchParams.get("bankAccountId") || "");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [direction, setDirection] = useState("ALL");
  const [status, setStatus] = useState("ALL");
  const [reconciliationStatus, setReconciliationStatus] = useState("ALL");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = tenantAuth.get();
    api.listBankAccounts(token).then(({ bankAccounts }) => setAccounts(bankAccounts)).catch(() => {});
  }, []);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bankAccountId, dateFrom, dateTo, direction, status, reconciliationStatus, search, page, pageSize]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const res = await api.listBankTransactions(token, {
        bankAccountId: bankAccountId || undefined,
        dateFrom: dateFrom || undefined,
        dateTo: dateTo || undefined,
        direction: direction !== "ALL" ? direction : undefined,
        status: status !== "ALL" ? status : undefined,
        reconciliationStatus: reconciliationStatus !== "ALL" ? reconciliationStatus : undefined,
        search: search || undefined,
        page,
        pageSize,
      });
      setResult(res);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  if (permLoading || !allowed) return null;

  const transactions = result?.transactions || [];
  const total = result?.total || 0;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Transactions" }]}
        title="Bank Transactions"
        description="Every normalized transaction imported from a bank statement."
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        <Toolbar
          title="Bank Transactions"
          searchValue={search}
          onSearchChange={(e) => {
            setSearch(e.target.value);
            resetToPageOne();
          }}
          searchPlaceholder="Search description or reference…"
          filters={
            <>
              <select
                className="select-filter"
                value={bankAccountId}
                onChange={(e) => {
                  setBankAccountId(e.target.value);
                  resetToPageOne();
                }}
              >
                <option value="">All bank accounts</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>{a.accountName}</option>
                ))}
              </select>
              <input
                type="date"
                className="select-filter"
                value={dateFrom}
                onChange={(e) => { setDateFrom(e.target.value); resetToPageOne(); }}
                aria-label="Date from"
              />
              <input
                type="date"
                className="select-filter"
                value={dateTo}
                onChange={(e) => { setDateTo(e.target.value); resetToPageOne(); }}
                aria-label="Date to"
              />
              <select className="select-filter" value={direction} onChange={(e) => { setDirection(e.target.value); resetToPageOne(); }}>
                <option value="ALL">Debit &amp; Credit</option>
                <option value="DEBIT">Debit only</option>
                <option value="CREDIT">Credit only</option>
              </select>
              <select className="select-filter" value={status} onChange={(e) => { setStatus(e.target.value); resetToPageOne(); }}>
                <option value="ALL">All statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="VOID">Void</option>
              </select>
              <select className="select-filter" value={reconciliationStatus} onChange={(e) => { setReconciliationStatus(e.target.value); resetToPageOne(); }}>
                <option value="ALL">All reconciliation statuses</option>
                <option value="UNMATCHED">Unmatched</option>
                <option value="SUGGESTED">Suggested</option>
                <option value="PARTIALLY_RECONCILED">Partially Reconciled</option>
                <option value="RECONCILED">Reconciled</option>
                <option value="IGNORED">Ignored</option>
              </select>
            </>
          }
        />

        {result === null ? (
          <LoadingSkeleton columns={8} />
        ) : transactions.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <rect x="3.5" y="6" width="17" height="13" rx="1.5" />
                <path d="M3.5 10h17M7 14h4" />
              </svg>
            }
            title="No bank transactions found"
            description="Import a bank statement, or try a different filter."
          />
        ) : (
          <>
            <TableScroll>
              <Table
                columns={[
                  { key: "transactionDate", header: "Date", render: (t) => formatDate(t.transactionDate) },
                  { key: "description", header: "Description", render: (t) => t.description || "—" },
                  { key: "reference", header: "Reference", render: (t) => t.reference || "—" },
                  { key: "debit", header: "Debit", className: "num", render: (t) => (t.debit > 0 ? formatCurrency(t.debit, t.currency) : "—") },
                  { key: "credit", header: "Credit", className: "num", render: (t) => (t.credit > 0 ? formatCurrency(t.credit, t.currency) : "—") },
                  { key: "runningBalance", header: "Balance", className: "num", render: (t) => formatCurrency(t.runningBalance, t.currency) },
                  { key: "bankAccount", header: "Bank Account", render: (t) => t.bankAccount?.accountName || "—" },
                  { key: "status", header: "Status", render: (t) => <span className={`badge ${t.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{t.status === "ACTIVE" ? "Active" : "Void"}</span> },
                  {
                    key: "reconciliationStatus",
                    header: "Reconciliation",
                    render: (t) => <ReconciliationStatusBadge status={t.reconciliationStatus} />,
                  },
                ]}
                rows={transactions}
                rowKey={(t) => t.id}
                onRowClick={(t) => router.push(`/tenant/banking/transactions/${t.id}`)}
              />
            </TableScroll>
            <Pagination page={page} pageSize={pageSize} totalItems={total} onPageChange={setPage} onPageSizeChange={(n) => { setPageSize(n); resetToPageOne(); }} itemLabel="Transactions" />
          </>
        )}
      </div>
    </div>
  );
}
