"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import { usePermissions } from "../../../../../hooks/usePermissions";
import { useRequirePermission } from "../../../../../hooks/useRequirePermission";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import Select from "../../../../../components/ui/Select";
import ReconciliationStatusBadge from "../../../../../components/reconciliation/ReconciliationStatusBadge";
import ConfidenceBadge from "../../../../../components/reconciliation/ConfidenceBadge";

const DIFFERENCE_TYPES = [
  { value: "", label: "Select a reason…" },
  { value: "BANK_CHARGE", label: "Bank Charge" },
  { value: "ADJUSTMENT", label: "Adjustment" },
  { value: "OTHER", label: "Other Difference" },
];

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function round2(n) {
  return Math.round((Number(n) + Number.EPSILON) * 100) / 100;
}

// Review Match + Manual Match workspace for one Bank Transaction (Phase 4,
// 2026-08-23). One combined screen rather than two separate ones: "Review
// Match" (brief §7) is just this same Match Builder pre-filled from the
// engine's top suggestion, and "Manual Match" (brief §8) is the same builder
// with the user adding/removing lines themselves via search - the
// side-by-side bank-vs-ledger comparison, the running difference, and the
// Confirm/Reject actions are identical either way, so duplicating the screen
// would only duplicate the invalid-allocation guards too.
export default function ReconciliationReviewPage() {
  const { allowed, loading: permLoading } = useRequirePermission("reconciliation.view");
  const { can } = usePermissions();
  const { showToast } = useToast();
  const router = useRouter();
  const params = useParams();

  const [detail, setDetail] = useState(null); // { transaction, matches, remaining }
  const [suggestions, setSuggestions] = useState(null); // { direction, remaining, candidates, activeMatch }
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  // Match builder state
  const [bankLines, setBankLines] = useState([]); // [{ id, amount, transaction }]
  const [ledgerLines, setLedgerLines] = useState([]); // [{ id, kind, amount, ledger }]
  const [bankSearch, setBankSearch] = useState("");
  const [bankResults, setBankResults] = useState([]);
  const [ledgerSearch, setLedgerSearch] = useState("");
  const [ledgerResults, setLedgerResults] = useState([]);
  const [differenceType, setDifferenceType] = useState("");
  const [differenceNotes, setDifferenceNotes] = useState("");
  const [rejectReason, setRejectReason] = useState("");
  const [showReject, setShowReject] = useState(false);

  const load = useCallback(async () => {
    setError("");
    try {
      const token = tenantAuth.get();
      const [d, s] = await Promise.all([api.getReconciliationTransaction(token, params.id), api.getReconciliationSuggestions(token, params.id)]);
      setDetail(d);
      setSuggestions(s);
      // Seed the builder: current transaction on the bank side (full
      // remaining amount), and the active suggestion (if any) on the ledger
      // side - matches confirming a suggestion "as is" being the common,
      // zero-typing path.
      setBankLines([{ id: d.transaction.id, amount: s.remaining, transaction: d.transaction }]);
      if (s.activeMatch) {
        setLedgerLines(
          s.activeMatch.ledgerLines.map((l) => ({
            id: l.paymentId || l.purchasePaymentId,
            kind: l.paymentId ? "payment" : "purchasePayment",
            amount: l.amount,
            ledger: l.payment
              ? { id: l.payment.id, paymentNumberDisplay: l.payment.paymentNumberDisplay, customerName: l.payment.customerName, remainingBalance: l.amount, documentNumbers: [] }
              : { id: l.purchasePayment.id, paymentNumberDisplay: l.purchasePayment.paymentNumberDisplay, vendorName: l.purchasePayment.vendorName, remainingBalance: l.amount, documentNumbers: [] },
          }))
        );
      } else {
        setLedgerLines([]);
      }
    } catch (err) {
      setError(err.message);
    }
  }, [params.id]);

  useEffect(() => {
    if (!allowed) return;
    load();
  }, [allowed, load]);

  async function runBankSearch(q) {
    setBankSearch(q);
    if (!q || q.length < 2) return setBankResults([]);
    try {
      const token = tenantAuth.get();
      const res = await api.listReconciliation(token, { bankAccountId: detail.transaction.bankAccountId, search: q, pageSize: 10 });
      const direction = detail.transaction.amount >= 0 ? "CREDIT" : "DEBIT";
      setBankResults(
        res.transactions.filter((t) => t.id !== detail.transaction.id && (t.amount >= 0 ? "CREDIT" : "DEBIT") === direction && ["UNMATCHED", "SUGGESTED", "PARTIALLY_RECONCILED"].includes(t.reconciliationStatus))
      );
    } catch (err) {
      setBankResults([]);
    }
  }

  async function runLedgerSearch(q) {
    setLedgerSearch(q);
    try {
      const token = tenantAuth.get();
      const res = await api.searchReconciliationLedger(token, params.id, q);
      setLedgerResults(res.results);
    } catch (err) {
      setLedgerResults([]);
    }
  }

  function addBankLine(t) {
    if (bankLines.some((l) => l.id === t.id)) return;
    const remaining = round2(Math.abs(t.amount)); // best-effort - server re-validates the real remaining at confirm time
    setBankLines((prev) => [...prev, { id: t.id, amount: remaining, transaction: t }]);
    setBankSearch("");
    setBankResults([]);
  }
  function removeBankLine(id) {
    if (id === detail.transaction.id) return; // the transaction this page is about can't be removed, only the match rejected
    setBankLines((prev) => prev.filter((l) => l.id !== id));
  }
  function updateBankAmount(id, value) {
    setBankLines((prev) => prev.map((l) => (l.id === id ? { ...l, amount: value } : l)));
  }

  function addLedgerLine(candidate, kind) {
    if (ledgerLines.some((l) => l.id === candidate.id)) return;
    setLedgerLines((prev) => [...prev, { id: candidate.id, kind, amount: candidate.remainingBalance, ledger: candidate }]);
    setLedgerSearch("");
    setLedgerResults([]);
  }
  function removeLedgerLine(id) {
    setLedgerLines((prev) => prev.filter((l) => l.id !== id));
  }
  function updateLedgerAmount(id, value) {
    setLedgerLines((prev) => prev.map((l) => (l.id === id ? { ...l, amount: value } : l)));
  }

  function applySuggestionCandidate(candidate) {
    addLedgerLine(candidate.ledger, candidate.kind);
  }

  const totalBank = round2(bankLines.reduce((s, l) => s + (Number(l.amount) || 0), 0));
  const totalLedger = round2(ledgerLines.reduce((s, l) => s + (Number(l.amount) || 0), 0));
  const difference = round2(totalBank - totalLedger);
  const needsClassification = Math.abs(difference) > 0.01;

  async function handleConfirm() {
    if (ledgerLines.length === 0) return showToast("Select at least one Payment/Purchase Payment to match against.");
    if (needsClassification && !differenceType) return showToast("Classify the difference before confirming.");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.confirmReconciliationMatch(token, {
        matchId: suggestions?.activeMatch?.id || undefined,
        bankLines: bankLines.map((l) => ({ bankTransactionId: l.id, amount: Number(l.amount) })),
        ledgerLines: ledgerLines.map((l) => (l.kind === "payment" ? { paymentId: l.id, amount: Number(l.amount) } : { purchasePaymentId: l.id, amount: Number(l.amount) })),
        differenceType: needsClassification ? differenceType : undefined,
        differenceNotes: needsClassification ? differenceNotes || undefined : undefined,
      });
      showToast("Match confirmed and reconciled.");
      router.push("/tenant/banking/reconciliation");
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleReject() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.rejectReconciliationMatch(token, suggestions.activeMatch.id, rejectReason || undefined);
      showToast("Suggestion rejected.");
      setShowReject(false);
      setRejectReason("");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  if (!detail || !suggestions) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Reconciliation", href: "/tenant/banking/reconciliation" }, { label: "…" }]} title="Review Match" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const { transaction } = detail;
  const direction = transaction.amount >= 0 ? "Incoming (Credit)" : "Outgoing (Debit)";
  const alreadyReconciled = transaction.reconciliationStatus === "RECONCILED";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Reconciliation", href: "/tenant/banking/reconciliation" }, { label: formatDate(transaction.transactionDate) }]}
        title={transaction.description || "Bank Transaction"}
        eyebrow={<ReconciliationStatusBadge status={transaction.reconciliationStatus} />}
        description={`${transaction.bankAccount.accountName} · ${direction} · ${formatCurrency(Math.abs(transaction.amount), transaction.currency)}`}
      />
      <ErrorBanner message={error} />

      {alreadyReconciled && (
        <Card>
          <p className="helptext" style={{ margin: 0 }}>
            This transaction is fully reconciled. Use the transaction&rsquo;s matched reconciliation record to Unmatch it if it needs to be corrected.
          </p>
        </Card>
      )}

      {!alreadyReconciled && (
        <>
          <div className="detail-layout">
            <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <Card>
                <h3 style={{ marginTop: 0 }}>Suggested Matches</h3>
                {suggestions.candidates.length === 0 ? (
                  <p className="helptext">No confident automatic match was found. Use Manual Match below to search for the right Payment/Purchase Payment.</p>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {suggestions.candidates.map((c) => (
                      <div key={c.ledger.id} className="card" style={{ padding: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                          <div>
                            <strong>{c.ledger.paymentNumberDisplay}</strong> · {c.ledger.customerName || c.ledger.vendorName} · {formatCurrency(c.ledger.remainingBalance, c.ledger.currency)}
                          </div>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <ConfidenceBadge confidence={c.confidence} />
                            <Button variant="outline" onClick={() => applySuggestionCandidate(c)}>Use This Match</Button>
                          </div>
                        </div>
                        <ul className="helptext" style={{ margin: "8px 0 0", paddingLeft: 18 }}>
                          {c.reasons.map((r, i) => (
                            <li key={i}>{r.label}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </Card>

              <Card>
                <h3 style={{ marginTop: 0 }}>Match Builder</h3>
                <p className="helptext" style={{ marginTop: -6 }}>
                  Combine multiple bank transactions or multiple payments where needed - e.g. one bank credit settling two invoices&rsquo; payments, or two bank credits together settling one payment.
                </p>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
                  <div>
                    <h4>Bank Transaction(s)</h4>
                    {bankLines.map((l) => (
                      <div key={l.id} className="review-row" style={{ alignItems: "center" }}>
                        <span className="review-label" style={{ maxWidth: 220 }}>
                          {formatDate(l.transaction.transactionDate)} · {l.transaction.description || l.transaction.reference || "Bank line"}
                        </span>
                        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <input type="number" step="0.01" min="0" className="inline-input" style={{ width: 100, textAlign: "right" }} value={l.amount} onChange={(e) => updateBankAmount(l.id, e.target.value)} />
                          {l.id !== transaction.id && (
                            <button type="button" aria-label="Remove" onClick={() => removeBankLine(l.id)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 16, lineHeight: 1, color: "var(--color-ink-soft)" }}>×</button>
                          )}
                        </span>
                      </div>
                    ))}
                    <input
                      type="search"
                      className="inline-input"
                      style={{ width: "100%", marginTop: 8 }}
                      placeholder="Add another bank transaction (same account, same direction)…"
                      value={bankSearch}
                      onChange={(e) => runBankSearch(e.target.value)}
                    />
                    {bankResults.length > 0 && (
                      <div className="card" style={{ marginTop: 6, padding: 8 }}>
                        {bankResults.map((t) => (
                          <button key={t.id} type="button" className="action-menu-item" style={{ width: "100%", textAlign: "left" }} onClick={() => addBankLine(t)}>
                            {formatDate(t.transactionDate)} · {t.description || t.reference} · {formatCurrency(Math.abs(t.amount), t.currency)}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <h4>Payment(s) / Purchase Payment(s)</h4>
                    {ledgerLines.length === 0 && <p className="helptext">Pick a suggestion above, or search below.</p>}
                    {ledgerLines.map((l) => (
                      <div key={l.id} className="review-row" style={{ alignItems: "center" }}>
                        <span className="review-label" style={{ maxWidth: 220 }}>
                          {l.ledger.paymentNumberDisplay} · {l.ledger.customerName || l.ledger.vendorName}
                        </span>
                        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <input type="number" step="0.01" min="0" className="inline-input" style={{ width: 100, textAlign: "right" }} value={l.amount} onChange={(e) => updateLedgerAmount(l.id, e.target.value)} />
                          <button type="button" aria-label="Remove" onClick={() => removeLedgerLine(l.id)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 16, lineHeight: 1, color: "var(--color-ink-soft)" }}>×</button>
                        </span>
                      </div>
                    ))}
                    <input
                      type="search"
                      className="inline-input"
                      style={{ width: "100%", marginTop: 8 }}
                      placeholder={`Search ${suggestions.direction === "CREDIT" ? "customer, payment ref, invoice #" : "supplier, payment ref, bill #"}…`}
                      value={ledgerSearch}
                      onChange={(e) => runLedgerSearch(e.target.value)}
                    />
                    {ledgerResults.length > 0 && (
                      <div className="card" style={{ marginTop: 6, padding: 8 }}>
                        {ledgerResults.map((r) => (
                          <button
                            key={r.id}
                            type="button"
                            className="action-menu-item"
                            style={{ width: "100%", textAlign: "left" }}
                            onClick={() => addLedgerLine(r, suggestions.direction === "CREDIT" ? "payment" : "purchasePayment")}
                          >
                            {r.paymentNumberDisplay} · {r.customerName || r.vendorName} · {formatCurrency(r.remainingBalance, r.currency)} remaining
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </div>

            <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
              <Card>
                <h3 style={{ marginTop: 0 }}>Difference</h3>
                <div className="review-list">
                  <div className="review-row"><span className="review-label">Bank Amount</span><span className="review-value mono">{formatCurrency(totalBank, transaction.currency)}</span></div>
                  <div className="review-row"><span className="review-label">Matched Amount</span><span className="review-value mono">{formatCurrency(totalLedger, transaction.currency)}</span></div>
                  <div className="review-row" style={{ fontWeight: 600 }}>
                    <span className="review-label">Difference</span>
                    <span className="review-value mono">{formatCurrency(difference, transaction.currency)}</span>
                  </div>
                </div>

                {needsClassification && (
                  <div style={{ marginTop: 12 }}>
                    <label htmlFor="diff-type" style={{ display: "block", marginBottom: 4, fontWeight: 600, fontSize: 13 }}>Classify the difference</label>
                    <Select id="diff-type" value={differenceType} onChange={(e) => setDifferenceType(e.target.value)}>
                      {DIFFERENCE_TYPES.map((d) => (
                        <option key={d.value} value={d.value}>{d.label}</option>
                      ))}
                    </Select>
                    <textarea className="inline-input" rows={2} placeholder="Notes (optional)" value={differenceNotes} onChange={(e) => setDifferenceNotes(e.target.value)} style={{ width: "100%", marginTop: 8 }} />
                  </div>
                )}

                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 16 }}>
                  {can("reconciliation.confirm") && (
                    <Button onClick={handleConfirm} disabled={busy || ledgerLines.length === 0}>
                      {busy ? "Confirming…" : "Confirm Match"}
                    </Button>
                  )}
                  {suggestions.activeMatch && can("reconciliation.reject") && (
                    <Button variant="outline" onClick={() => setShowReject(true)} disabled={busy}>Reject Suggestion</Button>
                  )}
                </div>
              </Card>
            </div>
          </div>
        </>
      )}

      {detail.matches.length > 0 && (
        <Card style={{ marginTop: 20 }}>
          <h3 style={{ marginTop: 0 }}>Match History</h3>
          <table className="data-table">
            <thead>
              <tr><th>Match</th><th>Status</th><th className="num">Amount</th><th>Confirmed By</th><th></th></tr>
            </thead>
            <tbody>
              {detail.matches.map((m) => (
                <tr key={m.id}>
                  <td className="mono">{m.matchNumberDisplay || "—"}</td>
                  <td><ReconciliationStatusBadge status={m.status} /></td>
                  <td className="num mono">{formatCurrency(m.totalBankAmount, transaction.currency)}</td>
                  <td>{m.matchedAt ? formatDate(m.matchedAt) : "—"}</td>
                  <td><Link href={`/tenant/banking/reconciliation/matches/${m.id}`}>View</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {showReject && (
        <div className="dialog-overlay" onClick={() => setShowReject(false)}>
          <div className="dialog" role="alertdialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
            <h2>Reject this suggestion?</h2>
            <p className="helptext">The transaction returns to Unmatched. You can search for a different match afterward.</p>
            <textarea className="inline-input" rows={2} placeholder="Reason (optional)" value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} style={{ width: "100%", marginBottom: 12 }} />
            <div className="dialog-actions">
              <button className="btn btn-outline" onClick={() => setShowReject(false)} disabled={busy}>Cancel</button>
              <button className="btn btn-danger" onClick={handleReject} disabled={busy}>{busy ? "Working…" : "Reject"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
