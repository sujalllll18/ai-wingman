"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../../lib/api";
import { tenantAuth } from "../../../../../../lib/auth";
import { useToast } from "../../../../../../hooks/useToast";
import { usePermissions } from "../../../../../../hooks/usePermissions";
import { useRequirePermission } from "../../../../../../hooks/useRequirePermission";
import PageHeader from "../../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../../components/ui/LoadingSkeleton";
import Card from "../../../../../../components/ui/Card";
import Button from "../../../../../../components/ui/Button";
import NoteActivityTimeline from "../../../../../../components/notes/NoteActivityTimeline";
import ReconciliationStatusBadge from "../../../../../../components/reconciliation/ReconciliationStatusBadge";
import ConfidenceBadge from "../../../../../../components/reconciliation/ConfidenceBadge";

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Reconciliation Detail (brief §15) - the full relationship chain: Bank
// Transaction(s) -> this Match -> Payment(s)/Purchase Payment(s) -> their own
// Invoice/Purchase Bill allocations. Also doubles as the target for Unmatch
// (§12) on a CONFIRMED match - a real, permission-gated, audited reversal,
// never a delete (see reconciliation.controller.js's unmatchMatch).
export default function ReconciliationMatchDetailPage() {
  const { allowed, loading: permLoading } = useRequirePermission("reconciliation.view");
  const { can } = usePermissions();
  const { showToast } = useToast();
  const router = useRouter();
  const params = useParams();

  const [match, setMatch] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showUnmatch, setShowUnmatch] = useState(false);
  const [reason, setReason] = useState("");

  useEffect(() => {
    if (!allowed) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed, params.matchId]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { match } = await api.getReconciliationMatch(token, params.matchId);
      setMatch(match);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleUnmatch() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.unmatchReconciliationMatch(token, match.id, reason || undefined);
      showToast("Match reversed. Both sides return to their prior reconciliation status.");
      setShowUnmatch(false);
      setReason("");
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  if (!match) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Reconciliation", href: "/tenant/banking/reconciliation" }, { label: "…" }]} title="Reconciliation Match" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const currency = match.bankLines[0]?.bankTransaction?.currency || "AED";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Reconciliation", href: "/tenant/banking/reconciliation" }, { label: match.matchNumberDisplay || "Match" }]}
        title={match.matchNumberDisplay || "Reconciliation Match"}
        eyebrow={<ReconciliationStatusBadge status={match.status} />}
        description={match.source === "MANUAL" ? "Manually matched" : `System-suggested match${match.confidence ? ` · ${match.confidence.toLowerCase()} confidence` : ""}`}
        action={
          match.status === "CONFIRMED" && can("reconciliation.unmatch") ? (
            <Button variant="outline" onClick={() => setShowUnmatch(true)}>Unmatch</Button>
          ) : null
        }
      />
      <ErrorBanner message={error} />

      <div className="detail-layout">
        <div className="detail-main" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Bank Transaction(s)</h3>
            <table className="data-table">
              <thead><tr><th>Date</th><th>Description</th><th>Bank Account</th><th className="num">Amount Matched</th></tr></thead>
              <tbody>
                {match.bankLines.map((l) => (
                  <tr key={l.id}>
                    <td>{formatDate(l.bankTransaction.transactionDate)}</td>
                    <td><Link href={`/tenant/banking/reconciliation/${l.bankTransaction.id}`}>{l.bankTransaction.description || l.bankTransaction.reference || "—"}</Link></td>
                    <td>{l.bankTransaction.bankAccount?.accountName}</td>
                    <td className="num mono">{formatCurrency(l.amount, l.bankTransaction.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>Payment(s) / Purchase Payment(s)</h3>
            <table className="data-table">
              <thead><tr><th>Number</th><th>Party</th><th className="num">Amount Matched</th><th>Allocated Invoice/Bill</th></tr></thead>
              <tbody>
                {match.ledgerLines.map((l) => {
                  const isPayment = !!l.payment;
                  const row = l.payment || l.purchasePayment;
                  const allocations = isPayment ? row.allocations : row.allocations;
                  const href = isPayment ? `/tenant/payments/${row.id}` : `/tenant/purchase-payments/${row.id}`;
                  return (
                    <tr key={l.id}>
                      <td><Link href={href} className="mono">{row.paymentNumberDisplay}</Link></td>
                      <td>{isPayment ? row.customerName : row.vendorName}</td>
                      <td className="num mono">{formatCurrency(l.amount, currency)}</td>
                      <td>
                        {(allocations || []).length === 0
                          ? "Unallocated"
                          : allocations.map((a) => (isPayment ? a.invoice : a.purchaseBill)?.invoiceNumberDisplay || (isPayment ? a.invoice : a.purchaseBill)?.billNumberDisplay).filter(Boolean).join(", ")}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          <Card>
            <h3 style={{ marginTop: 0 }}>History / Audit</h3>
            <NoteActivityTimeline activities={match.activities} />
          </Card>
        </div>

        <div className="detail-rail" style={{ position: "sticky", top: 20 }}>
          <Card>
            <h3 style={{ marginTop: 0 }}>Totals</h3>
            <div className="review-list">
              <div className="review-row"><span className="review-label">Bank Amount</span><span className="review-value mono">{formatCurrency(match.totalBankAmount, currency)}</span></div>
              <div className="review-row"><span className="review-label">Matched Amount</span><span className="review-value mono">{formatCurrency(match.totalLedgerAmount, currency)}</span></div>
              <div className="review-row" style={{ fontWeight: 600 }}><span className="review-label">Difference</span><span className="review-value mono">{formatCurrency(match.difference, currency)}</span></div>
              {match.differenceType && (
                <div className="review-row"><span className="review-label">Classified As</span><span className="review-value">{match.differenceType.replace("_", " ")}</span></div>
              )}
              {match.matchedAt && <div className="review-row"><span className="review-label">Confirmed</span><span className="review-value">{formatDate(match.matchedAt)}</span></div>}
              {match.status === "UNMATCHED" && match.unmatchedAt && <div className="review-row"><span className="review-label">Unmatched</span><span className="review-value">{formatDate(match.unmatchedAt)}</span></div>}
            </div>
          </Card>
        </div>
      </div>

      {showUnmatch && (
        <div className="dialog-overlay" onClick={() => setShowUnmatch(false)}>
          <div className="dialog" role="alertdialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
            <h2>Unmatch this reconciliation?</h2>
            <p className="helptext">
              The bank transaction and payment(s) both return to their prior reconciliation status. Nothing is deleted - this match&rsquo;s full history stays visible below, and it can be re-confirmed later.
            </p>
            <textarea className="inline-input" rows={2} placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} style={{ width: "100%", marginBottom: 12 }} />
            <div className="dialog-actions">
              <button className="btn btn-outline" onClick={() => setShowUnmatch(false)} disabled={busy}>Cancel</button>
              <button className="btn btn-danger" onClick={handleUnmatch} disabled={busy}>{busy ? "Working…" : "Unmatch"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
