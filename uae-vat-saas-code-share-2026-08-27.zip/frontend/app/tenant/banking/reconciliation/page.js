"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import { usePermissions } from "../../../../hooks/usePermissions";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Pagination from "../../../../components/ui/Pagination";
import Button from "../../../../components/ui/Button";
import KpiCard from "../../../../components/ui/KpiCard";
import ActionMenu from "../../../../components/ui/ActionMenu";
import ReconciliationStatusBadge from "../../../../components/reconciliation/ReconciliationStatusBadge";
import ConfidenceBadge from "../../../../components/reconciliation/ConfidenceBadge";

const KPI_ORDER = ["UNMATCHED", "SUGGESTED", "PARTIALLY_RECONCILED", "RECONCILED", "IGNORED"];
const KPI_LABEL = { UNMATCHED: "Unmatched", SUGGESTED: "Suggested", PARTIALLY_RECONCILED: "Partially Reconciled", RECONCILED: "Reconciled", IGNORED: "Ignored" };

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// Central Reconciliation Hub (Phase 4, 2026-08-23) - "Banking > Reconciliation".
// Same server-side filtered/paginated shape as Bank Transactions (this table
// is designed to hold 100,000+ rows), plus a dashboard of clickable KPI
// cards (same pattern KpiCard already established on Invoices/Purchases) and
// a "Run Matching" action that processes one controlled batch of
// UNMATCHED/PARTIALLY_RECONCILED transactions per click (see
// reconciliationEngine.service.js's RUN_BATCH_SIZE) - re-clickable if
// `hasMore` comes back true, so a very large statement never needs the whole
// table matched in one request.
export default function ReconciliationHubPage() {
  const { allowed, loading: permLoading } = useRequirePermission("reconciliation.view");
  const { can } = usePermissions();
  const { showToast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [accounts, setAccounts] = useState([]);
  const [bankAccountId, setBankAccountId] = useState(searchParams.get("bankAccountId") || "");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [direction, setDirection] = useState("ALL");
  const [status, setStatus] = useState(searchParams.get("status") || "ALL");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const [result, setResult] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);
  const [ignoreTarget, setIgnoreTarget] = useState(null);
  const [ignoreReason, setIgnoreReason] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const token = tenantAuth.get();
    api.listBankAccounts(token).then(({ bankAccounts }) => setAccounts(bankAccounts)).catch(() => {});
  }, []);

  useEffect(() => {
    if (!allowed) return;
    loadDashboard();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed, bankAccountId]);

  useEffect(() => {
    if (!allowed) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed, bankAccountId, dateFrom, dateTo, direction, status, search, page, pageSize]);

  async function loadDashboard() {
    try {
      const token = tenantAuth.get();
      const res = await api.getReconciliationDashboard(token, { bankAccountId: bankAccountId || undefined });
      setDashboard(res);
    } catch (err) {
      // Dashboard is a secondary widget - a failure here shouldn't block the table.
    }
  }

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const res = await api.listReconciliation(token, {
        bankAccountId: bankAccountId || undefined,
        dateFrom: dateFrom || undefined,
        dateTo: dateTo || undefined,
        direction: direction !== "ALL" ? direction : undefined,
        reconciliationStatus: status !== "ALL" ? status : undefined,
        search: search || undefined,
        page,
        pageSize,
      });
      setResult(res);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  async function handleRunMatching() {
    setRunning(true);
    try {
      const token = tenantAuth.get();
      const res = await api.runReconciliationMatching(token, { bankAccountId: bankAccountId || undefined });
      showToast(res.suggested > 0 ? `${res.suggested} new suggestion(s) found${res.hasMore ? " - more transactions remain, run again to continue" : ""}.` : "No new suggestions found for the unmatched transactions scanned.");
      await Promise.all([load(), loadDashboard()]);
    } catch (err) {
      showToast(err.message);
    } finally {
      setRunning(false);
    }
  }

  async function handleIgnore() {
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.ignoreReconciliationTransaction(token, ignoreTarget.id, ignoreReason || undefined);
      showToast("Transaction set aside as ignored.");
      setIgnoreTarget(null);
      setIgnoreReason("");
      await Promise.all([load(), loadDashboard()]);
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  const transactions = result?.transactions || [];
  const total = result?.total || 0;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Reconciliation" }]}
        title="Reconciliation"
        description="Match imported bank transactions against Payments Received and Payments Made."
        action={
          can("reconciliation.match") && (
            <Button onClick={handleRunMatching} disabled={running}>
              {running ? "Finding matches…" : "Run Matching"}
            </Button>
          )
        }
      />

      <ErrorBanner message={error} />

      {dashboard && (
        <div className="kpi-card-grid" style={{ marginBottom: 20 }}>
          <KpiCard label="Total Bank Transactions" value={dashboard.totalCount} helptext={formatCurrency(dashboard.totalAmount, "AED")} />
          {KPI_ORDER.map((key) => (
            <KpiCard
              key={key}
              label={KPI_LABEL[key]}
              value={dashboard.byStatus[key]?.count ?? 0}
              helptext={formatCurrency(dashboard.byStatus[key]?.amount ?? 0, "AED")}
              active={status === key}
              onClick={() => {
                setStatus((prev) => (prev === key ? "ALL" : key));
                resetToPageOne();
              }}
            />
          ))}
        </div>
      )}

      <div className="table-block">
        <Toolbar
          title="Bank Transactions"
          searchValue={search}
          onSearchChange={(e) => {
            setSearch(e.target.value);
            resetToPageOne();
          }}
          searchPlaceholder="Search description or reference…"
          filters={
            <>
              <select className="select-filter" value={bankAccountId} onChange={(e) => { setBankAccountId(e.target.value); resetToPageOne(); }}>
                <option value="">All bank accounts</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>{a.accountName}</option>
                ))}
              </select>
              <input type="date" className="select-filter" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); resetToPageOne(); }} aria-label="Date from" />
              <input type="date" className="select-filter" value={dateTo} onChange={(e) => { setDateTo(e.target.value); resetToPageOne(); }} aria-label="Date to" />
              <select className="select-filter" value={direction} onChange={(e) => { setDirection(e.target.value); resetToPageOne(); }}>
                <option value="ALL">Incoming &amp; Outgoing</option>
                <option value="CREDIT">Incoming only</option>
                <option value="DEBIT">Outgoing only</option>
              </select>
              <select className="select-filter" value={status} onChange={(e) => { setStatus(e.target.value); resetToPageOne(); }}>
                <option value="ALL">All statuses</option>
                <option value="UNMATCHED">Unmatched</option>
                <option value="SUGGESTED">Suggested</option>
                <option value="PARTIALLY_RECONCILED">Partially Reconciled</option>
                <option value="RECONCILED">Reconciled</option>
                <option value="IGNORED">Ignored</option>
              </select>
            </>
          }
        />

        {result === null ? (
          <LoadingSkeleton columns={9} />
        ) : transactions.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <path d="M9 12l2 2 4-4" />
                <rect x="3.5" y="6" width="17" height="13" rx="1.5" />
              </svg>
            }
            title="Nothing to reconcile here"
            description="Import a bank statement, or try a different filter."
          />
        ) : (
          <>
            <TableScroll>
              <Table
                columns={[
                  { key: "transactionDate", header: "Date", render: (t) => formatDate(t.transactionDate) },
                  { key: "description", header: "Description", render: (t) => t.description || "—" },
                  { key: "reference", header: "Reference", render: (t) => t.reference || "—" },
                  { key: "bankAccount", header: "Bank Account", render: (t) => t.bankAccount?.accountName || "—" },
                  { key: "amount", header: "Amount", className: "num", render: (t) => formatCurrency(Math.abs(t.amount), t.currency) },
                  { key: "type", header: "Type", render: (t) => (t.amount >= 0 ? <span className="badge badge-success">Incoming</span> : <span className="badge badge-info">Outgoing</span>) },
                  {
                    key: "suggestedMatch",
                    header: "Suggested Match",
                    render: (t) => (t.suggestedMatch ? <span>{t.suggestedMatch.ledgerLabel || "—"}{t.suggestedMatch.partyLabel ? <span className="helptext" style={{ display: "block" }}>{t.suggestedMatch.partyLabel}</span> : null}</span> : "—"),
                  },
                  { key: "confidence", header: "Confidence", render: (t) => <ConfidenceBadge confidence={t.suggestedMatch?.confidence} /> },
                  { key: "status", header: "Status", render: (t) => <ReconciliationStatusBadge status={t.reconciliationStatus} /> },
                  {
                    key: "actions",
                    header: "",
                    className: "col-actions",
                    render: (t) => (
                      <ActionMenu
                        ariaLabel={`Actions for ${t.description || "transaction"}`}
                        items={[
                          { label: t.reconciliationStatus === "SUGGESTED" ? "Review Match" : "Find Match", onClick: () => router.push(`/tenant/banking/reconciliation/${t.id}`), disabled: !can("reconciliation.view") },
                          {
                            label: "Ignore",
                            onClick: () => setIgnoreTarget(t),
                            disabled: !can("reconciliation.ignore") || !["UNMATCHED", "SUGGESTED"].includes(t.reconciliationStatus),
                            disabledReason: "Only an Unmatched or Suggested transaction can be ignored",
                          },
                        ]}
                      />
                    ),
                  },
                ]}
                rows={transactions}
                rowKey={(t) => t.id}
                onRowClick={(t) => router.push(`/tenant/banking/reconciliation/${t.id}`)}
              />
            </TableScroll>
            <Pagination page={page} pageSize={pageSize} totalItems={total} onPageChange={setPage} onPageSizeChange={(n) => { setPageSize(n); resetToPageOne(); }} itemLabel="Transactions" />
          </>
        )}
      </div>

      <ConfirmIgnoreDialog target={ignoreTarget} reason={ignoreReason} setReason={setIgnoreReason} busy={busy} onConfirm={handleIgnore} onCancel={() => { setIgnoreTarget(null); setIgnoreReason(""); }} />
    </div>
  );
}

function ConfirmIgnoreDialog({ target, reason, setReason, busy, onConfirm, onCancel }) {
  if (!target) return null;
  return (
    <div className="dialog-overlay" onClick={onCancel}>
      <div className="dialog" role="alertdialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <h2>Ignore this transaction?</h2>
        <p className="helptext">
          No suitable Ledger transaction exists for {target.description || "this transaction"}. Ignoring stops it from being suggested again - it stays reversible from the transaction&rsquo;s own page.
        </p>
        <textarea className="inline-input" rows={2} placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} style={{ width: "100%", marginBottom: 12 }} />
        <div className="dialog-actions">
          <button className="btn btn-outline" onClick={onCancel} disabled={busy}>Cancel</button>
          <button className="btn btn-primary" onClick={onConfirm} disabled={busy}>{busy ? "Working…" : "Ignore Transaction"}</button>
        </div>
      </div>
    </div>
  );
}
