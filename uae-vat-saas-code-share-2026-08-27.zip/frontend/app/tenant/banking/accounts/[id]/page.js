"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../../lib/api";
import { tenantAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import { usePermissions } from "../../../../../hooks/usePermissions";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../components/ui/LoadingSkeleton";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import Tabs from "../../../../../components/ui/Tabs";
import Table from "../../../../../components/ui/Table";
import TableScroll from "../../../../../components/ui/TableScroll";
import EmptyState from "../../../../../components/ui/EmptyState";
import BankAccountFormModal from "../../../../../components/banking/BankAccountFormModal";
import NoteActivityTimeline from "../../../../../components/notes/NoteActivityTimeline";
import ImportStatusBadge, { IMPORT_TYPE_LABEL } from "../../../../../components/imports/ImportStatusBadge";

const ACCOUNT_TYPE_LABEL = { CURRENT: "Current", SAVINGS: "Savings", OTHER: "Other" };

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}
function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function BankAccountDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { showToast } = useToast();
  const { can } = usePermissions();

  const [account, setAccount] = useState(null);
  const [transactionCount, setTransactionCount] = useState(0);
  const [activities, setActivities] = useState([]);
  const [importBatches, setImportBatches] = useState(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("OVERVIEW");
  const [editOpen, setEditOpen] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { bankAccount, transactionCount, activities } = await api.getBankAccount(token, params.id);
      setAccount(bankAccount);
      setTransactionCount(transactionCount);
      setActivities(activities);
    } catch (err) {
      setError(err.message);
    }
  }

  async function loadImportHistory() {
    setImportBatches(null);
    const token = tenantAuth.get();
    const { batches } = await api.listImportBatches(token);
    setImportBatches(batches.filter((b) => b.bankAccountId === params.id));
  }

  function handleTabChange(key) {
    setTab(key);
    if (key === "HISTORY" && importBatches === null) loadImportHistory();
  }

  if (!account) {
    return (
      <div>
        <PageHeader breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Bank Accounts", href: "/tenant/banking/accounts" }, { label: "…" }]} title="Bank Account" />
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Bank Accounts", href: "/tenant/banking/accounts" }, { label: account.accountName }]}
        title={account.accountName}
        eyebrow={<span className={`badge ${account.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{account.status === "ACTIVE" ? "Active" : "Inactive"}</span>}
        description={`${account.bankName} · ${ACCOUNT_TYPE_LABEL[account.accountType] || account.accountType}`}
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {can("banking.edit_account") && (
              <Button variant="outline" onClick={() => setEditOpen(true)}>
                Edit
              </Button>
            )}
            {can("banking.import") && account.status === "ACTIVE" && (
              <Button onClick={() => router.push(`/tenant/banking/import?bankAccountId=${account.id}`)}>Import Statement</Button>
            )}
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="kpi-card-grid">
        <div className="card kpi-card">
          <span className="kpi-card-label">Account Number</span>
          <span className="kpi-card-value mono" style={{ fontSize: 18 }}>{account.accountNumber || "—"}</span>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Currency</span>
          <span className="kpi-card-value">{account.currency}</span>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Opening Balance</span>
          <span className="kpi-card-value">{formatCurrency(account.openingBalance, account.currency)}</span>
        </div>
        <div className="card kpi-card">
          <span className="kpi-card-label">Transactions</span>
          <span className="kpi-card-value">{transactionCount}</span>
        </div>
      </div>

      <Card>
        <Tabs
          tabs={[
            { key: "OVERVIEW", label: "Activity" },
            { key: "HISTORY", label: "Import History" },
          ]}
          activeKey={tab}
          onChange={handleTabChange}
        />

        <div style={{ marginTop: 16 }}>
          {tab === "OVERVIEW" && <NoteActivityTimeline activities={activities} />}

          {tab === "HISTORY" &&
            (importBatches === null ? (
              <LoadingSkeleton columns={4} />
            ) : importBatches.length === 0 ? (
              <EmptyState title="No statement imports yet" description="Every statement imported against this account will show up here." />
            ) : (
              <TableScroll>
                <Table
                  columns={[
                    { key: "batchNumber", header: "Import ID", render: (b) => <span className="mono">{b.batchNumber}</span> },
                    { key: "sourceFileName", header: "Source File" },
                    { key: "period", header: "Period", render: (b) => (b.periodFrom && b.periodTo ? `${formatDate(b.periodFrom)} – ${formatDate(b.periodTo)}` : "—") },
                    { key: "importedByName", header: "Started By" },
                    { key: "createdAt", header: "Started At", render: (b) => formatDateTime(b.createdAt) },
                    { key: "totalRecords", header: "Total", className: "num" },
                    { key: "successCount", header: "Imported", className: "num" },
                    { key: "failedCount", header: "Failed", className: "num" },
                    { key: "status", header: "Status", render: (b) => <ImportStatusBadge status={b.status} /> },
                  ]}
                  rows={importBatches}
                  onRowClick={(b) => router.push(`/tenant/imports/${b.id}`)}
                />
              </TableScroll>
            ))}
        </div>
      </Card>

      <BankAccountFormModal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editingAccount={account}
        onSuccess={(updated) => {
          showToast(`${updated.accountName} updated.`);
          setEditOpen(false);
          load();
        }}
      />
    </div>
  );
}
