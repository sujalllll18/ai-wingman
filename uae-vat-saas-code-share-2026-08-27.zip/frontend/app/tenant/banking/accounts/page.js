"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import Toolbar from "../../../../components/ui/Toolbar";
import Button from "../../../../components/ui/Button";
import ActionMenu from "../../../../components/ui/ActionMenu";
import BankAccountFormModal from "../../../../components/banking/BankAccountFormModal";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";
import { usePermissions } from "../../../../hooks/usePermissions";

const ACCOUNT_TYPE_LABEL = { CURRENT: "Current", SAVINGS: "Savings", OTHER: "Other" };

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}

export default function BankAccountsPage() {
  const router = useRouter();
  const { allowed, loading: permLoading } = useRequirePermission("banking.view");
  const { can } = usePermissions();
  const { showToast } = useToast();

  const [accounts, setAccounts] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = tenantAuth.get();
      const { bankAccounts } = await api.listBankAccounts(token);
      setAccounts(bankAccounts);
    } catch (err) {
      setError(err.message);
    }
  }

  const filtered = useMemo(() => {
    if (!accounts) return [];
    const q = search.trim().toLowerCase();
    return accounts.filter((a) => {
      const matchesSearch = !q || a.accountName.toLowerCase().includes(q) || a.bankName.toLowerCase().includes(q) || (a.accountNumber || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || a.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [accounts, search, statusFilter]);

  async function handleToggleStatus(account) {
    try {
      const token = tenantAuth.get();
      const { bankAccount } = await api.updateBankAccount(token, account.id, { status: account.status === "ACTIVE" ? "INACTIVE" : "ACTIVE" });
      showToast(`${bankAccount.accountName} is now ${bankAccount.status === "ACTIVE" ? "Active" : "Inactive"}.`);
      await load();
    } catch (err) {
      showToast(err.message);
    }
  }

  const COLUMNS = useMemo(
    () => [
      { key: "accountName", header: "Account Name", render: (a) => <span style={{ fontWeight: 600 }}>{a.accountName}</span> },
      { key: "bankName", header: "Bank" },
      { key: "accountType", header: "Type", render: (a) => ACCOUNT_TYPE_LABEL[a.accountType] || a.accountType },
      { key: "accountNumber", header: "Account #", render: (a) => <span className="mono">{a.accountNumber || "—"}</span> },
      { key: "currency", header: "Currency" },
      { key: "openingBalance", header: "Opening Balance", className: "num", render: (a) => formatCurrency(a.openingBalance, a.currency) },
      {
        key: "status",
        header: "Status",
        render: (a) => <span className={`badge ${a.status === "ACTIVE" ? "badge-success" : "badge-danger"}`}>{a.status === "ACTIVE" ? "Active" : "Inactive"}</span>,
      },
      {
        key: "actions",
        header: "",
        className: "num",
        render: (a) => (
          <ActionMenu
            ariaLabel={`Actions for ${a.accountName}`}
            items={[
              { label: "View", onClick: () => router.push(`/tenant/banking/accounts/${a.id}`) },
              { label: "Edit", onClick: () => { setEditingAccount(a); setModalOpen(true); }, disabled: !can("banking.edit_account") },
              { label: a.status === "ACTIVE" ? "Deactivate" : "Activate", onClick: () => handleToggleStatus(a), disabled: !can("banking.edit_account") },
              { label: "Import Statement", onClick: () => router.push(`/tenant/banking/import?bankAccountId=${a.id}`), disabled: !can("banking.import") || a.status !== "ACTIVE", disabledReason: a.status !== "ACTIVE" ? "Activate this account first." : "Not permitted." },
            ]}
          />
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [router, can]
  );

  if (permLoading || !allowed) return null;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Bank Accounts" }]}
        title="Bank Accounts"
        description="The bank accounts statements get imported against."
        action={can("banking.create_account") && <Button onClick={() => { setEditingAccount(null); setModalOpen(true); }}>+ New Bank Account</Button>}
      />

      <ErrorBanner message={error} />

      <div className="table-block">
        {accounts === null ? (
          <LoadingSkeleton columns={7} />
        ) : accounts.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24">
                <rect x="3.5" y="6" width="17" height="13" rx="1.5" />
                <path d="M3.5 10h17M7 14h4" />
              </svg>
            }
            title="No bank accounts yet"
            description="Add a bank account before importing a statement against it."
            action={can("banking.create_account") && <Button onClick={() => { setEditingAccount(null); setModalOpen(true); }}>+ New Bank Account</Button>}
          />
        ) : (
          <>
            <Toolbar
              title="Bank Accounts"
              searchValue={search}
              onSearchChange={(e) => setSearch(e.target.value)}
              searchPlaceholder="Search by account name, bank, or number…"
              filters={
                <select className="select-filter" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                  <option value="ALL">All statuses</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              }
            />
            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching bank accounts"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <TableScroll>
                <Table columns={COLUMNS} rows={filtered} onRowClick={(a) => router.push(`/tenant/banking/accounts/${a.id}`)} />
              </TableScroll>
            )}
          </>
        )}
      </div>

      <BankAccountFormModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        editingAccount={editingAccount}
        onSuccess={(account) => {
          showToast(`${account.accountName} ${editingAccount ? "updated" : "created"}.`);
          setModalOpen(false);
          load();
        }}
      />
    </div>
  );
}
