"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { tenantAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Card from "../../../../components/ui/Card";
import Field from "../../../../components/ui/Field";
import Select from "../../../../components/ui/Select";
import Button from "../../../../components/ui/Button";
import Table from "../../../../components/ui/Table";
import TableScroll from "../../../../components/ui/TableScroll";
import StepWizard from "../../../../components/ui/StepWizard";
import Tabs from "../../../../components/ui/Tabs";
import ImportUploadDropzone from "../../../../components/imports/ImportUploadDropzone";
import { useRequirePermission } from "../../../../hooks/useRequirePermission";

const STEPS = ["Select Bank Account", "Upload Statement", "Map Columns", "Validate & Preview"];

function formatCurrency(value, currency) {
  if (value === null || value === undefined) return "—";
  return `${currency || "AED"} ${Number(value).toFixed(2)}`;
}

function summarizeRow(normalized) {
  if (!normalized) return "—";
  const date = normalized.transactionDate ? new Date(normalized.transactionDate).toLocaleDateString() : "—";
  const dir = normalized.credit > 0 ? `+${normalized.credit}` : `-${normalized.debit}`;
  return `${date} · ${normalized.description || "—"} · ${dir}`;
}

export default function BankImportPage() {
  const { allowed, loading: permLoading } = useRequirePermission("banking.import");
  const router = useRouter();
  const searchParams = useSearchParams();
  const { showToast } = useToast();

  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [accounts, setAccounts] = useState(null);
  const [bankAccountId, setBankAccountId] = useState(searchParams.get("bankAccountId") || "");
  const [file, setFile] = useState(null);

  const [templateFields, setTemplateFields] = useState([]);
  const [batch, setBatch] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [mapping, setMapping] = useState({});

  const [previewTab, setPreviewTab] = useState("VALID");
  const [previewRows, setPreviewRows] = useState(null);
  const [financialSummary, setFinancialSummary] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const token = tenantAuth.get();
        const [{ bankAccounts }, { importTypes }] = await Promise.all([api.listBankAccounts(token), api.listImportTypes(token)]);
        setAccounts(bankAccounts);
        setTemplateFields(importTypes.find((t) => t.importType === "BANK_TRANSACTION")?.templateFields || []);
      } catch (err) {
        setError(err.message);
      }
    })();
  }, []);

  const selectedAccount = accounts?.find((a) => a.id === bankAccountId);

  function handleSelectAccount() {
    if (!bankAccountId) {
      setError("Select a bank account first.");
      return;
    }
    setError("");
    setStep(1);
  }

  async function handleUpload() {
    if (!file) {
      setError("Choose a file to upload first.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const { batch, headers, mapping } = await api.createImportBatch(token, { file, importType: "BANK_TRANSACTION", bankAccountId });
      setBatch(batch);
      setHeaders(headers);
      setMapping(mapping);
      setStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveMappingAndValidate() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      await api.setImportMapping(token, batch.id, mapping);
      const { batch: validated } = await api.validateImportBatch(token, batch.id);
      setBatch(validated);
      setStep(3);
      await loadPreview("VALID", token, validated.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function loadPreview(status, tokenArg, batchIdArg) {
    const token = tokenArg || tenantAuth.get();
    const { rows, financialSummary } = await api.previewImportBatch(token, batchIdArg || batch.id, { status });
    setPreviewTab(status);
    setPreviewRows(rows);
    if (financialSummary) setFinancialSummary(financialSummary);
  }

  async function handleCommit() {
    setError("");
    setBusy(true);
    try {
      const token = tenantAuth.get();
      const res = await api.commitImportBatch(token, batch.id);
      if (res.approvalRequest) {
        showToast(`Batch ${batch.batchNumber} submitted for approval.`);
      } else {
        showToast(`Import started - tracking progress on the next screen.`);
      }
      router.push(`/tenant/imports/${batch.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (permLoading || !allowed) return null;

  // Balance-consistency check (brief §17) - combines the adapter's
  // financialSummary (totalDebits/totalCredits/statementClosingBalance, no
  // opening balance context) with the selected Bank Account's own
  // openingBalance (already available here for display anyway) - computed
  // client-side rather than threading extra context through the backend's
  // generic summarizeFinancials hook, which no other adapter needs.
  let balanceCheck = null;
  if (financialSummary && selectedAccount && selectedAccount.openingBalance !== null && financialSummary.statementClosingBalance !== null) {
    const expected = selectedAccount.openingBalance + financialSummary.totalCredits - financialSummary.totalDebits;
    const mismatch = Math.abs(expected - financialSummary.statementClosingBalance) > 0.01;
    balanceCheck = { expected, mismatch };
  }

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Ledger" }, { label: "Banking" }, { label: "Import Statement" }]}
        title="Import Bank Statement"
        description="Select a Bank Account → Upload → Map → Validate → Preview → Commit. Nothing is created until you commit."
      />

      <ErrorBanner message={error} />

      <div style={{ marginBottom: 20 }}>
        <StepWizard steps={STEPS} currentStep={step} />
      </div>

      {step === 0 && (
        <Card>
          <h3 style={{ marginTop: 0 }}>Which bank account is this statement for?</h3>
          {accounts === null ? (
            <p className="helptext">Loading…</p>
          ) : accounts.length === 0 ? (
            <div>
              <p className="helptext">You don&rsquo;t have any bank accounts yet.</p>
              <Link href="/tenant/banking/accounts">
                <Button>+ New Bank Account</Button>
              </Link>
            </div>
          ) : (
            <>
              <div className="form-grid">
                <Field id="bankAccountId" label="Bank Account">
                  <Select value={bankAccountId} onChange={(e) => setBankAccountId(e.target.value)}>
                    <option value="">Select a bank account…</option>
                    {accounts.filter((a) => a.status === "ACTIVE").map((a) => (
                      <option key={a.id} value={a.id}>{a.accountName} ({a.bankName})</option>
                    ))}
                  </Select>
                </Field>
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 20 }}>
                <Button onClick={handleSelectAccount}>Continue</Button>
              </div>
            </>
          )}
        </Card>
      )}

      {step === 1 && (
        <Card>
          <h3 style={{ marginTop: 0 }}>Upload statement for {selectedAccount?.accountName}</h3>
          <p className="helptext" style={{ marginTop: -8 }}>Excel (.xlsx) or CSV.</p>
          <ImportUploadDropzone onFileSelected={setFile} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(0)} disabled={busy}>Back</Button>
            <Button onClick={handleUpload} disabled={busy || !file}>{busy ? "Uploading…" : "Upload & Continue"}</Button>
          </div>
        </Card>
      )}

      {step === 2 && batch && (
        <Card>
          <h3 style={{ marginTop: 0 }}>Map your columns</h3>
          <p className="helptext" style={{ marginTop: -8 }}>
            Ledger auto-detected the mapping below from your file&rsquo;s headers — review and correct anything that&rsquo;s wrong before validating.
          </p>

          <TableScroll>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Ledger Field</th>
                  <th>Your Column</th>
                </tr>
              </thead>
              <tbody>
                {templateFields.map((f) => (
                  <tr key={f.key}>
                    <td data-label="Ledger Field">
                      {f.label}
                      {f.required && <span className="required-asterisk"> *</span>}
                    </td>
                    <td data-label="Your Column">
                      <Select value={mapping[f.key] || ""} onChange={(e) => setMapping((m) => ({ ...m, [f.key]: e.target.value || null }))}>
                        <option value="">— Not mapped —</option>
                        {headers.map((h) => (
                          <option key={h} value={h}>{h}</option>
                        ))}
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableScroll>

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
            <Button variant="outline" onClick={() => setStep(1)} disabled={busy}>Back</Button>
            <Button onClick={handleSaveMappingAndValidate} disabled={busy}>{busy ? "Validating…" : "Save Mapping & Validate"}</Button>
          </div>
        </Card>
      )}

      {step === 3 && batch && (
        <>
          <div className="kpi-card-grid">
            <div className="card kpi-card">
              <span className="kpi-card-label">Total</span>
              <span className="kpi-card-value">{batch.totalRecords}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Ready</span>
              <span className="kpi-card-value">{batch.successCount}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Warnings</span>
              <span className="kpi-card-value">{batch.warningCount}</span>
            </div>
            <div className="card kpi-card">
              <span className="kpi-card-label">Errors</span>
              <span className="kpi-card-value">{batch.failedCount}</span>
            </div>
          </div>

          {financialSummary && (
            <Card>
              <h3 style={{ marginTop: 0 }}>Balance Check</h3>
              <div className="review-list">
                <div className="review-row"><span className="review-label">Opening Balance</span><span className="review-value mono">{formatCurrency(selectedAccount?.openingBalance, selectedAccount?.currency)}</span></div>
                <div className="review-row"><span className="review-label">Total Credits</span><span className="review-value mono">+{formatCurrency(financialSummary.totalCredits, selectedAccount?.currency)}</span></div>
                <div className="review-row"><span className="review-label">Total Debits</span><span className="review-value mono">-{formatCurrency(financialSummary.totalDebits, selectedAccount?.currency)}</span></div>
                <div className="review-row"><span className="review-label">Statement Closing Balance</span><span className="review-value mono">{formatCurrency(financialSummary.statementClosingBalance, selectedAccount?.currency)}</span></div>
              </div>
              {balanceCheck && (
                balanceCheck.mismatch ? (
                  <ErrorBanner message={`Balance mismatch: expected ${formatCurrency(balanceCheck.expected, selectedAccount?.currency)} but the statement's own closing balance is ${formatCurrency(financialSummary.statementClosingBalance, selectedAccount?.currency)}. Double-check the opening balance or the file before importing.`} />
                ) : (
                  <p className="helptext" style={{ marginTop: 8 }}>Opening balance + credits − debits matches the statement&rsquo;s own closing balance.</p>
                )
              )}
              {!financialSummary.statementClosingBalance && (
                <p className="helptext" style={{ marginTop: 8 }}>This statement has no Balance column, so no consistency check was run.</p>
              )}
            </Card>
          )}

          <Card>
            <h3 style={{ marginTop: 0 }}>
              {batch.totalRecords} record{batch.totalRecords === 1 ? "" : "s"} detected — {batch.successCount} ready, {batch.failedCount} need attention
            </h3>

            <Tabs
              tabs={[
                { key: "VALID", label: `Ready (${batch.successCount})` },
                { key: "INVALID", label: `Need Attention (${batch.failedCount})` },
              ]}
              activeKey={previewTab}
              onChange={(key) => loadPreview(key)}
            />

            <div style={{ marginTop: 16 }}>
              {previewRows === null ? (
                <p className="helptext">Loading…</p>
              ) : previewRows.length === 0 ? (
                <p className="helptext">Nothing here.</p>
              ) : (
                <TableScroll>
                  <Table
                    columns={[
                      { key: "rowNumber", header: "Row #" },
                      { key: "summary", header: "Date · Description · Amount", render: (r) => summarizeRow(r.normalized) },
                      ...(previewTab === "INVALID"
                        ? [{ key: "errors", header: "Issues", render: (r) => <span style={{ color: "var(--color-danger)" }}>{r.validationErrors.map((e) => e.message).join("; ")}</span> }]
                        : []),
                    ]}
                    rows={previewRows}
                    rowKey={(r) => r.id}
                  />
                </TableScroll>
              )}
            </div>

            {batch.failedCount > 0 && (
              <div style={{ marginTop: 16 }}>
                <Button variant="outline" onClick={() => api.downloadImportErrorReport(tenantAuth.get(), batch.id)}>Download Error Report</Button>
                <p className="helptext">Fix the flagged rows in your source file and start a new import for just those rows — Ready rows below can still be imported now.</p>
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 }}>
              <Button variant="outline" onClick={() => setStep(2)} disabled={busy}>Back</Button>
              <Button onClick={handleCommit} disabled={busy || batch.successCount === 0}>
                {busy ? "Starting…" : `Commit ${batch.successCount} Transaction${batch.successCount === 1 ? "" : "s"}`}
              </Button>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
