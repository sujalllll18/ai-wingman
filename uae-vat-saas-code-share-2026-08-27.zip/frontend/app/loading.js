// App-wide route-transition fallback (2026-08-11 route audit) - Next.js
// shows this while a route segment's own page.js chunk is being loaded, a
// different moment than each page's own in-page data-fetch loading state
// (which every page already renders itself once mounted, e.g. `<p>Loading…
// </p>` / <LoadingSkeleton /> - left untouched here, not duplicated). Same
// plain-text convention already used by most pages, just as a route-level
// safety net for the brief window before that.
export default function Loading() {
  return (
    <div style={{ padding: 40, textAlign: "center", color: "var(--color-ink-soft)" }}>
      Loading…
    </div>
  );
}
