"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import TableScroll from "../../../../components/ui/TableScroll";
import Button from "../../../../components/ui/Button";

function formatCurrency(value) {
  return value ? `AED ${Number(value).toLocaleString()}` : "Free";
}

function formatLimit(value) {
  return value === null || value === undefined ? "Unlimited" : Number(value).toLocaleString();
}

const LIMIT_ROWS = [
  { key: "maxUsers", label: "Maximum Users" },
  { key: "maxTeamMembers", label: "Team Members" },
  { key: "maxCustomers", label: "Maximum Customers" },
  { key: "maxProducts", label: "Maximum Products" },
  { key: "maxInvoicesPerMonth", label: "Maximum Invoices / Month" },
  { key: "maxPurchasesPerMonth", label: "Maximum Purchases / Month" },
  { key: "ocrCredits", label: "OCR Credits" },
  { key: "apiCallsPerMonth", label: "API Calls / Month" },
  { key: "storageGb", label: "Storage (GB)" },
  { key: "attachmentStorageGb", label: "Attachment Storage (GB)" },
  { key: "maxBranches", label: "Branches" },
];

// Plan Comparison (2026-08-07) - a transposed table (attributes as rows,
// plans as columns) rather than the entity-per-row shape DataTable is built
// for, so this is plain semantic markup reusing the same .data-table CSS
// (sticky header, borders, typography) instead of a new table component.
export default function PlanComparePage() {
  const [plans, setPlans] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const [{ plans }, { modules }] = await Promise.all([api.listPlans(token), api.getModuleCatalog(token)]);
      setPlans(plans.filter((p) => p.status !== "ARCHIVED" && p.currentVersion));
      setCatalog(modules);
    } catch (err) {
      setError(err.message);
    }
  }

  const groupedModules = useMemo(() => {
    const groups = {};
    for (const m of catalog) (groups[m.group] = groups[m.group] || []).push(m);
    return groups;
  }, [catalog]);

  return (
    <div>
      <PageHeader eyebrow="Platform Admin" title="Plan Comparison" description="Every active plan's pricing, limits, and module access, side by side." />
      <ErrorBanner message={error} />

      {plans === null ? (
        <div className="card">
          <LoadingSkeleton columns={5} />
        </div>
      ) : (
        <div className="card" style={{ padding: 0 }}>
          <TableScroll>
            <table className="data-table no-stack sticky-header">
              <thead>
                <tr>
                  <th>&nbsp;</th>
                  {plans.map((p) => (
                    <th key={p.id}>
                      {p.name}
                      <div style={{ marginTop: 6 }}>
                        <Link href={`/admin/plans/${p.id}`}>
                          <Button variant="outline" style={{ padding: "4px 10px", fontSize: 12 }}>
                            Open
                          </Button>
                        </Link>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ fontWeight: 600 }}>Monthly Price</td>
                  {plans.map((p) => (
                    <td key={p.id}>{formatCurrency(p.currentVersion.monthlyPrice)}</td>
                  ))}
                </tr>
                <tr>
                  <td style={{ fontWeight: 600 }}>Yearly Price</td>
                  {plans.map((p) => (
                    <td key={p.id}>{formatCurrency(p.currentVersion.yearlyPrice)}</td>
                  ))}
                </tr>
                <tr>
                  <td style={{ fontWeight: 600 }}>Trial Days</td>
                  {plans.map((p) => (
                    <td key={p.id}>{p.currentVersion.trialDays || "—"}</td>
                  ))}
                </tr>

                <tr>
                  <td colSpan={plans.length + 1} style={{ background: "var(--color-surface-sunken)", fontWeight: 600, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    Usage Limits
                  </td>
                </tr>
                {LIMIT_ROWS.map(({ key, label }) => (
                  <tr key={key}>
                    <td>{label}</td>
                    {plans.map((p) => (
                      <td key={p.id}>{formatLimit(p.currentVersion[key])}</td>
                    ))}
                  </tr>
                ))}

                {Object.entries(groupedModules).map(([groupName, modules]) => (
                  <Fragment key={groupName}>
                    <tr>
                      <td colSpan={plans.length + 1} style={{ background: "var(--color-surface-sunken)", fontWeight: 600, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.04em" }}>
                        {groupName}
                      </td>
                    </tr>
                    {modules.map((mod) => (
                      <tr key={mod.module}>
                        <td>{mod.label}</td>
                        {plans.map((p) => {
                          const access = p.currentVersion.moduleAccess?.[mod.module];
                          const enabled = !!access?.enabled;
                          const featureCount = access?.features ? Object.values(access.features).filter(Boolean).length : 0;
                          return (
                            <td key={p.id}>
                              {enabled ? (
                                <span className="badge badge-success">
                                  Included{featureCount > 0 ? ` (${featureCount}/${mod.actions.length})` : ""}
                                </span>
                              ) : (
                                <span style={{ color: "var(--color-ink-faint)" }}>—</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </TableScroll>
        </div>
      )}
    </div>
  );
}
