"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";
import { adminAuth } from "../../../lib/auth";
import { useToast } from "../../../hooks/useToast";
import { useLocalStorageState } from "../../../hooks/useLocalStorageState";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import DataTable from "../../../components/ui/DataTable";
import TableScroll from "../../../components/ui/TableScroll";
import ColumnSelector from "../../../components/ui/ColumnSelector";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import Pagination from "../../../components/ui/Pagination";
import KpiCard from "../../../components/ui/KpiCard";
import Modal from "../../../components/ui/Modal";
import Field from "../../../components/ui/Field";
import Input from "../../../components/ui/Input";
import PlanStatusBadge from "../../../components/PlanStatusBadge";

function formatCurrency(value) {
  return value ? `AED ${Number(value).toLocaleString()}` : "Free";
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

const KPI_ICONS = {
  total: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="3.5" width="17" height="17" rx="2" />
      <path d="M3.5 9.5h17" />
    </svg>
  ),
  active: (
    <svg viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  ),
  draft: (
    <svg viewBox="0 0 24 24">
      <path d="M14.5 4.5l5 5L8 21H3v-5z" />
    </svg>
  ),
  tenants: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="8" r="3" />
      <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
      <circle cx="17" cy="9" r="2.4" />
      <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
    </svg>
  ),
};

export default function PlansPage() {
  const router = useRouter();
  const { showToast } = useToast();

  const [plans, setPlans] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [archiveTarget, setArchiveTarget] = useState(null);
  const [cloneTarget, setCloneTarget] = useState(null);
  const [cloneForm, setCloneForm] = useState({ name: "", slug: "" });

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const { plans } = await api.listPlans(token);
      setPlans(plans);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  async function handleToggleActive(plan) {
    setBusy(true);
    try {
      const token = adminAuth.get();
      await api.setPlanStatus(token, plan.id, plan.status === "ACTIVE" ? "INACTIVE" : "ACTIVE");
      showToast(`${plan.name} ${plan.status === "ACTIVE" ? "deactivated" : "activated"}.`);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirmArchive() {
    if (!archiveTarget) return;
    setBusy(true);
    try {
      const token = adminAuth.get();
      await api.setPlanStatus(token, archiveTarget.id, "ARCHIVED");
      showToast(`${archiveTarget.name} archived.`);
      setArchiveTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  function openClonePrompt(plan) {
    setCloneTarget(plan);
    setCloneForm({ name: `${plan.name} Copy`, slug: `${plan.slug}_COPY` });
  }

  async function handleConfirmClone(e) {
    e.preventDefault();
    if (!cloneTarget) return;
    setBusy(true);
    try {
      const token = adminAuth.get();
      const { plan } = await api.clonePlan(token, cloneTarget.id, cloneForm);
      showToast(`Cloned as ${cloneForm.name}.`);
      setCloneTarget(null);
      router.push(`/admin/plans/${plan.id}`);
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  const COLUMN_DEFS = useMemo(
    () => [
      { key: "name", label: "Plan Name", alwaysVisible: true, sortable: true, render: (p) => <span style={{ fontWeight: 600 }}>{p.name}</span> },
      { key: "monthlyPrice", label: "Monthly Price", align: "right", render: (p) => formatCurrency(p.currentVersion?.monthlyPrice) },
      { key: "yearlyPrice", label: "Yearly Price", align: "right", render: (p) => formatCurrency(p.currentVersion?.yearlyPrice) },
      { key: "trialDays", label: "Trial Days", align: "right", render: (p) => p.currentVersion?.trialDays ?? 0 },
      { key: "activeTenants", label: "Active Tenants", align: "right", render: (p) => p.activeTenants },
      { key: "status", label: "Status", render: (p) => <PlanStatusBadge status={p.status} /> },
      {
        key: "version",
        label: "Version",
        render: (p) => (
          <span className="mono">
            v{p.currentVersion?.versionNumber ?? "—"} {p.currentVersion?.status === "DRAFT" && <span className="badge badge-premium" style={{ marginLeft: 4 }}>Draft</span>}
          </span>
        ),
      },
      { key: "updatedAt", label: "Last Updated", render: (p) => formatDate(p.updatedAt) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (p) => (
          <ActionMenu
            ariaLabel={`Actions for ${p.name}`}
            items={[
              { label: "View", onClick: () => router.push(`/admin/plans/${p.id}`) },
              { label: "Edit", onClick: () => router.push(`/admin/plans/${p.id}`) },
              { label: "Clone", onClick: () => openClonePrompt(p), disabled: busy },
              p.status === "ACTIVE"
                ? { label: "Deactivate", onClick: () => handleToggleActive(p), disabled: busy || p.isDefault, disabledReason: p.isDefault ? "The default plan can't be deactivated." : undefined }
                : { label: "Activate", onClick: () => handleToggleActive(p), disabled: busy || p.status === "ARCHIVED", disabledReason: p.status === "ARCHIVED" ? "Archived plans can't be reactivated." : undefined },
              { label: "Archive", danger: true, onClick: () => setArchiveTarget(p), disabled: busy || p.status === "ARCHIVED" || p.isDefault, disabledReason: p.isDefault ? "The default plan can't be archived." : undefined },
            ]}
          />
        ),
      },
    ],
    [router, busy]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_plan_list_column_order", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_plan_list_hidden_columns", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const stats = useMemo(() => {
    if (!plans) return null;
    return {
      total: plans.length,
      active: plans.filter((p) => p.status === "ACTIVE").length,
      draftVersions: plans.filter((p) => p.currentVersion?.status === "DRAFT").length,
      tenantsCovered: plans.reduce((sum, p) => sum + p.activeTenants, 0),
    };
  }, [plans]);

  const filtered = useMemo(() => {
    if (!plans) return [];
    const q = search.trim().toLowerCase();
    return plans.filter((p) => {
      const matchesSearch = !q || p.name.toLowerCase().includes(q) || p.slug.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [plans, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  return (
    <div>
      <PageHeader
        eyebrow="Platform Admin"
        title="Subscription Plans"
        description="Every plan tenants can be assigned to — Starter through Enterprise, plus your legacy Trial/Standard/Premium catalog."
        action={
          <div style={{ display: "flex", gap: 8 }}>
            <Link href="/admin/plans/compare">
              <Button variant="outline">Compare Plans</Button>
            </Link>
            <Link href="/admin/plans/new">
              <Button>+ New Plan</Button>
            </Link>
          </div>
        }
      />

      <ErrorBanner message={error} />

      {stats && (
        <div className="kpi-card-grid">
          <KpiCard label="Total Plans" value={stats.total} icon={KPI_ICONS.total} helptext="Every plan in the catalog" />
          <KpiCard label="Active Plans" value={stats.active} icon={KPI_ICONS.active} helptext="Available to assign" />
          <KpiCard label="Draft Versions" value={stats.draftVersions} icon={KPI_ICONS.draft} helptext="Not yet published" />
          <KpiCard label="Tenants Covered" value={stats.tenantsCovered} icon={KPI_ICONS.tenants} helptext="Across every plan" />
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        {plans === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={7} />
          </div>
        ) : plans.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <rect x="3.5" y="3.5" width="17" height="17" rx="2" />
                <path d="M3.5 9.5h17" />
              </svg>
            }
            title="No plans yet"
            description="Create your first subscription plan to get started."
            action={
              <Link href="/admin/plans/new">
                <Button>+ New Plan</Button>
              </Link>
            }
          />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search plans…"
                filters={
                  <>
                    <select
                      className="select-filter"
                      value={statusFilter}
                      onChange={(e) => {
                        setStatusFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All statuses</option>
                      <option value="ACTIVE">Active</option>
                      <option value="INACTIVE">Inactive</option>
                      <option value="ARCHIVED">Archived</option>
                    </select>
                    <ColumnSelector columns={COLUMN_DEFS} columnOrder={columnOrder} hiddenColumns={hiddenColumns} onToggle={handleToggleColumn} onReorder={setColumnOrder} />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching plans"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable columns={COLUMN_DEFS} rows={pageItems} columnOrder={columnOrder} hiddenColumns={hiddenColumns} stickyHeader zebra />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => {
                    setPageSize(n);
                    resetToPageOne();
                  }}
                  itemLabel="plans"
                />
              </>
            )}
          </>
        )}
      </div>

      <ConfirmationDialog
        open={!!archiveTarget}
        title="Archive this plan?"
        message={`"${archiveTarget?.name}" will no longer be assignable to tenants. Tenants already on this plan are unaffected. This can be reviewed later but not easily undone.`}
        confirmLabel="Archive"
        variant="danger"
        busy={busy}
        onConfirm={handleConfirmArchive}
        onCancel={() => setArchiveTarget(null)}
      />

      <Modal open={!!cloneTarget} onClose={() => setCloneTarget(null)} ariaLabel="Clone plan">
        <form onSubmit={handleConfirmClone}>
          <h2 style={{ marginBottom: 4 }}>Clone &ldquo;{cloneTarget?.name}&rdquo;</h2>
          <p className="form-section-desc">Creates a new, independent plan seeded from this plan's current configuration.</p>
          <Field id="clone-name" label="New plan name">
            <Input required value={cloneForm.name} onChange={(e) => setCloneForm((f) => ({ ...f, name: e.target.value }))} />
          </Field>
          <Field id="clone-slug" label="Slug" helptext="Unique identifier, letters/numbers/underscore only" style={{ marginBottom: 0 }}>
            <Input required className="mono" value={cloneForm.slug} onChange={(e) => setCloneForm((f) => ({ ...f, slug: e.target.value.toUpperCase() }))} />
          </Field>
          <div className="wizard-actions">
            <Button type="button" variant="outline" onClick={() => setCloneTarget(null)} disabled={busy}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy}>
              {busy ? "Cloning…" : "Clone Plan"}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
