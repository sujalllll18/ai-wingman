"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import PageHeader from "../../../../components/ui/PageHeader";
import Card from "../../../../components/ui/Card";
import Field from "../../../../components/ui/Field";
import Input from "../../../../components/ui/Input";
import Button from "../../../../components/ui/Button";
import ErrorBanner from "../../../../components/ui/ErrorBanner";

// Step one of creating a plan: just its identity. The rest (pricing,
// billing, modules/features, usage limits) is configured in the full Plan
// Builder at /admin/plans/[id] once the Plan + its first draft version
// actually exist to save against.
export default function NewPlanPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", slug: "", description: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.slug.trim()) {
      setError("Plan name and slug are required.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const token = adminAuth.get();
      const { plan } = await api.createPlan(token, form);
      router.push(`/admin/plans/${plan.id}`);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <div className="page-narrow">
      <PageHeader eyebrow="Platform Admin" title="New Plan" description="Name your plan — you'll configure pricing, modules, and limits next." />
      <ErrorBanner message={error} />
      <form onSubmit={handleSubmit}>
        <Card>
          <Field id="plan-name" label="Plan Name">
            <Input required value={form.name} onChange={update("name")} placeholder="e.g. Growth" />
          </Field>
          <Field id="plan-slug" label="Slug" helptext="Unique identifier, letters/numbers/underscore only">
            <Input required className="mono" value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value.toUpperCase() }))} placeholder="GROWTH" />
          </Field>
          <Field id="plan-description" label="Description" style={{ marginBottom: 0 }}>
            <textarea rows={2} value={form.description} onChange={update("description")} />
          </Field>
        </Card>
        <div className="wizard-actions">
          <Button type="button" variant="outline" onClick={() => router.push("/admin/plans")} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Creating…" : "Create & Continue"}
          </Button>
        </div>
      </form>
    </div>
  );
}
