"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import Tabs from "../../../../components/ui/Tabs";
import Button from "../../../../components/ui/Button";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import PlanStatusBadge from "../../../../components/PlanStatusBadge";
import GeneralTab from "../../../../components/plan-builder/GeneralTab";
import BillingTab from "../../../../components/plan-builder/BillingTab";
import ModulesFeaturesTab from "../../../../components/plan-builder/ModulesFeaturesTab";
import UsageLimitsTab from "../../../../components/plan-builder/UsageLimitsTab";
import VersionsTab from "../../../../components/plan-builder/VersionsTab";

const TABS = [
  { key: "general", label: "General" },
  { key: "billing", label: "Billing" },
  { key: "modules", label: "Modules & Features" },
  { key: "limits", label: "Usage Limits" },
  { key: "versions", label: "Versions" },
];

export default function PlanBuilderPage() {
  const { id } = useParams();
  const router = useRouter();
  const { showToast } = useToast();

  const [plan, setPlan] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [selectedVersionId, setSelectedVersionId] = useState(null);
  const [versionDraft, setVersionDraft] = useState(null);
  const [planMeta, setPlanMeta] = useState(null);
  const [activeTab, setActiveTab] = useState("general");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmPublish, setConfirmPublish] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const [{ plan }, { modules }] = await Promise.all([api.getPlan(token, id), api.getModuleCatalog(token)]);
      setPlan(plan);
      setCatalog(modules);
      const sorted = [...plan.versions].sort((a, b) => b.versionNumber - a.versionNumber);
      const draft = sorted.find((v) => v.status === "DRAFT");
      const initial = draft || sorted[0];
      setSelectedVersionId(initial.id);
      setVersionDraft(initial);
      setPlanMeta({ name: plan.name, description: plan.description, status: plan.status, isDefault: plan.isDefault });
    } catch (err) {
      setError(err.message);
    }
  }

  function selectVersion(versionId) {
    const v = plan.versions.find((x) => x.id === versionId);
    if (!v) return;
    setSelectedVersionId(versionId);
    setVersionDraft(v);
  }

  const isDraftSelected = versionDraft?.status === "DRAFT";

  async function handleSave() {
    setBusy(true);
    setError("");
    try {
      const token = adminAuth.get();
      await api.updatePlanMeta(token, id, planMeta);
      const { version } = await api.saveDraftPlanVersion(token, id, versionDraft);
      showToast("Saved.");
      await load();
      setSelectedVersionId(version.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Publishing is irreversible (a published version becomes permanently
  // read-only - see plan.service.js's publishVersion, which already
  // rejects re-publishing) - confirmed via ConfirmationDialog first, same
  // safety pattern already used for every other irreversible action in the
  // app (Invoice Send, Credit Note Issue, etc.), not previously present here.
  async function handlePublish() {
    setConfirmPublish(false);
    setBusy(true);
    setError("");
    try {
      const token = adminAuth.get();
      await api.updatePlanMeta(token, id, planMeta);
      const { version: saved } = await api.saveDraftPlanVersion(token, id, versionDraft);
      await api.publishPlanVersion(token, saved.id);
      showToast(`Version ${saved.versionNumber} published.`);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (error && !plan) {
    return (
      <div>
        <PageHeader title="Plan Builder" />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!plan || !versionDraft || !planMeta) return <p>Loading…</p>;

  return (
    <div className="content-narrow">
      <PageHeader
        eyebrow="Platform Admin"
        title={plan.name}
        description={`Slug: ${plan.slug}`}
        action={
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <PlanStatusBadge status={plan.status} />
            <span className="mono" style={{ fontSize: 12, color: "var(--color-ink-faint)" }}>
              Viewing v{versionDraft.versionNumber}
            </span>
          </div>
        }
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={setActiveTab} />

      <div role="tabpanel">
        {activeTab === "general" && (
          <GeneralTab planMeta={planMeta} onPlanMetaChange={setPlanMeta} version={versionDraft} onVersionChange={setVersionDraft} readOnly={!isDraftSelected} />
        )}
        {activeTab === "billing" && <BillingTab version={versionDraft} onVersionChange={setVersionDraft} readOnly={!isDraftSelected} />}
        {activeTab === "modules" && (
          <ModulesFeaturesTab
            catalog={catalog}
            moduleAccess={versionDraft.moduleAccess || {}}
            onChange={(moduleAccess) => setVersionDraft({ ...versionDraft, moduleAccess })}
            readOnly={!isDraftSelected}
          />
        )}
        {activeTab === "limits" && <UsageLimitsTab version={versionDraft} onVersionChange={setVersionDraft} readOnly={!isDraftSelected} />}
        {activeTab === "versions" && (
          <VersionsTab
            plan={plan}
            catalog={catalog}
            versions={[...plan.versions].sort((a, b) => b.versionNumber - a.versionNumber)}
            selectedVersionId={selectedVersionId}
            selectedVersion={versionDraft}
            onSelectVersion={selectVersion}
          />
        )}
      </div>

      {/* Visible on every tab, including Versions - previously hidden there,
          which meant the Publish CTA (the whole point of requirement #2)
          was invisible on the one tab an admin would naturally look for it.
          Reflects whichever version is currently selected either way. */}
      <div className="wizard-actions">
        <Button type="button" variant="outline" onClick={() => router.push("/admin/plans")} disabled={busy}>
          Back to Plans
        </Button>
        {isDraftSelected ? (
          <>
            <Button type="button" variant="outline" onClick={handleSave} disabled={busy}>
              {busy ? "Saving…" : "Save Changes"}
            </Button>
            <Button type="button" onClick={() => setConfirmPublish(true)} disabled={busy}>
              {busy ? "Publishing…" : `Publish v${versionDraft.versionNumber}`}
            </Button>
          </>
        ) : (
          <Button type="button" onClick={handleSave} disabled={busy}>
            {busy ? "Creating…" : "Create New Draft From This Version"}
          </Button>
        )}
      </div>

      <ConfirmationDialog
        open={confirmPublish}
        title={`Publish version ${versionDraft.versionNumber}?`}
        message="Once published, this version becomes permanently read-only - further edits create a new version instead. This can't be undone."
        confirmLabel={`Publish v${versionDraft.versionNumber}`}
        busy={busy}
        onConfirm={handlePublish}
        onCancel={() => setConfirmPublish(false)}
      />
    </div>
  );
}
