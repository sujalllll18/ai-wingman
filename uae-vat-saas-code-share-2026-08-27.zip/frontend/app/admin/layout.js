"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { adminAuth } from "../../lib/auth";
import AppShell from "../../components/ui/AppShell";

const NAV_ITEMS = [
  {
    href: "/admin/dashboard",
    label: "Dashboard",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
      </svg>
    ),
  },
  {
    href: "/admin/tenants",
    label: "Tenants",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M6 3.5h9l4.5 4.5V20a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1z" />
        <path d="M14.5 3.5V8h4.5" />
        <path d="M8 12.5h8M8 16h5.5" />
      </svg>
    ),
  },
  {
    href: "/admin/tenants/new",
    label: "New Tenant",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M12 5v14M5 12h14" />
      </svg>
    ),
  },
  {
    href: "/admin/plans",
    label: "Plans",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M4 6h16M4 12h10M4 18h13" />
        <circle cx="19" cy="12" r="1.6" />
        <circle cx="20" cy="18" r="1.6" />
      </svg>
    ),
  },
  {
    label: "Support Center",
    // Core ticketing (2026-08-07) - Dashboard + All Tickets are fully real;
    // Teams/Categories/SLA/Knowledge Base/Reports are deferred (see
    // FUTURE_ITEMS below), same "build the real thing, be honest about the
    // rest" split as every other phase in this app.
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 16v.01M12 8a2.5 2.5 0 0 1 2.5 2.5c0 1.5-1.5 2-2 2.5-.3.3-.5.7-.5 1" />
      </svg>
    ),
    children: [
      { href: "/admin/support/dashboard", label: "Dashboard" },
      { href: "/admin/support/tickets", label: "All Tickets" },
    ],
  },
];

const FUTURE_ITEMS = [
  {
    label: "Teams",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="8" r="3" />
        <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
        <circle cx="17" cy="9" r="2.4" />
        <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
      </svg>
    ),
  },
  {
    label: "Categories",
    icon: (
      <svg viewBox="0 0 24 24">
        <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
      </svg>
    ),
  },
  {
    label: "SLA",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7.5V12l3 2" />
      </svg>
    ),
  },
  {
    label: "Knowledge Base",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H19v16H6.5A2.5 2.5 0 0 0 4 21.5z" />
        <path d="M4 5.5v16" />
      </svg>
    ),
  },
  {
    label: "Reports",
    icon: (
      <svg viewBox="0 0 24 24">
        <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
      </svg>
    ),
  },
  {
    label: "Settings",
    icon: (
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 13a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V19a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H4a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H10a1.6 1.6 0 0 0 1-1.5V4a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V10a1.6 1.6 0 0 0 1.5 1H20a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z" />
      </svg>
    ),
  },
];

export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const isLoginPage = pathname === "/admin/login";
  const isWide =
    pathname === "/admin/dashboard" ||
    pathname === "/admin/tenants" ||
    pathname === "/admin/plans" ||
    pathname === "/admin/plans/compare" ||
    pathname === "/admin/support/dashboard" ||
    pathname === "/admin/support/tickets" ||
    /^\/admin\/support\/tickets\/[^/]+$/.test(pathname);

  useEffect(() => {
    if (isLoginPage) {
      setReady(true);
      return;
    }
    const token = adminAuth.get();
    if (!token) {
      router.replace("/login?role=admin");
      return;
    }
    setReady(true);
  }, [isLoginPage, router]);

  if (isLoginPage) return children;
  if (!ready) return null;

  function handleLogout() {
    adminAuth.clear();
    router.push("/admin/login");
  }

  return (
    <AppShell brand="Platform Admin" navItems={NAV_ITEMS} futureItems={FUTURE_ITEMS} onLogout={handleLogout} wide={isWide}>
      {children}
    </AppShell>
  );
}
