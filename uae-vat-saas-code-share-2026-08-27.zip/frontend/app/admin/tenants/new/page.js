"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import { isValidEmail, isValidPassword, isValidPhoneNumber, isValidTRN, PASSWORD_REQUIREMENT_MESSAGE } from "../../../../lib/validation";
import { DEFAULT_COUNTRY_ISO2, COUNTRIES, findCountry } from "../../../../lib/countries";
import { PLANS, getPlan, formatPlanPrice } from "../../../../lib/plans";
import PageHeader from "../../../../components/ui/PageHeader";
import Card from "../../../../components/ui/Card";
import Field from "../../../../components/ui/Field";
import Input from "../../../../components/ui/Input";
import Select from "../../../../components/ui/Select";
import Button from "../../../../components/ui/Button";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import StepWizard from "../../../../components/ui/StepWizard";
import PlanCard from "../../../../components/ui/PlanCard";
import PhoneInput from "../../../../components/PhoneInput";
import PasswordInput from "../../../../components/PasswordInput";
import ImportUploadDropzone from "../../../../components/imports/ImportUploadDropzone";
import { useToast } from "../../../../hooks/useToast";

// Single, consolidated "Add New Tenant" wizard (2026-08-06, Platform Admin
// Phase 1; stabilization fixes 2026-08-09). createTenant() accepts
// {name, trn, address, contactEmail, contactPhone, plan, owner:{name,
// email, password, forcePasswordChange}} - country/timezone/currency/
// billingCycle are collected for the Review step's display only and have
// no backend field yet, labeled as such rather than silently pretending to
// work. Owner Email is a plain unassisted field (autoComplete="off") -
// browsers must never suggest/prefill the signed-in Platform Admin's own
// saved email into it (see the 2026-08-09 fix notes below each field).
// Migration Setup inserted 2026-08-22, between Owner Account and Review &
// Create - optional (Start Fresh is the default), and deliberately does NOT
// block tenant creation: files staged here are only actually uploaded/
// validated/committed AFTER handleSubmit's createTenant() call succeeds
// (see the fire-and-forget block there), against the real new tenant's own
// id. The Platform Admin never waits for a migration to finish here.
const STEPS = ["Business Information", "Subscription Plan", "Owner Account", "Migration Setup", "Review & Create"];

const TIMEZONES = [
  { value: "Asia/Dubai", label: "Asia/Dubai (GST, UTC+4)" },
  { value: "Asia/Riyadh", label: "Asia/Riyadh (AST, UTC+3)" },
  { value: "Asia/Kolkata", label: "Asia/Kolkata (IST, UTC+5:30)" },
  { value: "Europe/London", label: "Europe/London (GMT/BST)" },
];

const CURRENCIES = ["AED", "USD", "EUR", "GBP", "SAR"];

const initial = {
  name: "",
  contactEmail: "",
  phoneCountryIso2: DEFAULT_COUNTRY_ISO2,
  phoneNumber: "",
  trn: "",
  address: "",
  country: DEFAULT_COUNTRY_ISO2,
  timezone: "Asia/Dubai",
  currency: "AED",
  billingCycle: "monthly",
  plan: "TRIAL",
  ownerName: "",
  ownerEmail: "",
  ownerPhoneCountryIso2: DEFAULT_COUNTRY_ISO2,
  ownerPhoneNumber: "",
  ownerPassword: "",
  forcePasswordChange: true,
  migrationMode: "fresh", // "fresh" | "migrate"
  confirmed: false,
};

// Fixed catalog rather than a fetched one - the same 3 real adapters exist
// regardless of which tenant this will become (SALES_INVOICE/PURCHASE_BILL/
// CUSTOMER, per importAdapters.js) and there's no tenant yet to fetch
// against during onboarding.
const MIGRATION_ENTITY_TYPES = [
  { importType: "CUSTOMER", label: "Customers" },
  { importType: "SALES_INVOICE", label: "Sales Invoices" },
  { importType: "PURCHASE_BILL", label: "Purchase Bills" },
];

const STEP_FIELDS = {
  0: ["name", "contactEmail", "phoneNumber", "address", "trn"],
  2: ["ownerName", "ownerEmail", "ownerPassword"],
};

function getBusinessErrors(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = "Business name is required.";
  if (!form.contactEmail.trim()) errors.contactEmail = "Business email is required.";
  else if (!isValidEmail(form.contactEmail)) errors.contactEmail = "Enter a valid email address.";
  if (!form.phoneNumber.trim()) errors.phoneNumber = "Phone number is required.";
  else if (!isValidPhoneNumber(form.phoneNumber, form.phoneCountryIso2))
    errors.phoneNumber = "Enter a valid phone number for the selected country.";
  if (!form.address.trim()) errors.address = "Address is required.";
  if (form.trn.trim() && !isValidTRN(form.trn)) errors.trn = "TRN must be exactly 15 digits.";
  return errors;
}

function getOwnerErrors(form) {
  const errors = {};
  if (!form.ownerName.trim()) errors.ownerName = "Full name is required.";
  if (!form.ownerEmail.trim()) errors.ownerEmail = "Email is required.";
  else if (!isValidEmail(form.ownerEmail)) errors.ownerEmail = "Enter a valid email address.";
  if (form.ownerPhoneNumber.trim() && !isValidPhoneNumber(form.ownerPhoneNumber, form.ownerPhoneCountryIso2))
    errors.ownerPhoneNumber = "Enter a valid phone number for the selected country.";
  if (!isValidPassword(form.ownerPassword)) errors.ownerPassword = PASSWORD_REQUIREMENT_MESSAGE;
  return errors;
}

function getStepErrors(step, form) {
  if (step === 0) return getBusinessErrors(form);
  if (step === 2) return getOwnerErrors(form);
  return {};
}

function getAllErrors(form) {
  return { ...getBusinessErrors(form), ...getOwnerErrors(form) };
}

function firstStepWithError(errors) {
  for (const [step, fields] of Object.entries(STEP_FIELDS)) {
    if (fields.some((f) => errors[f])) return Number(step);
  }
  return 0;
}

export default function NewTenantPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [form, setForm] = useState(initial);
  const [step, setStep] = useState(0);
  const [touched, setTouched] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [migrationFiles, setMigrationFiles] = useState([]); // [{file, importType}] - staged only, not uploaded until after the tenant exists

  const errors = getAllErrors(form);

  function update(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  }

  function updateLive(key) {
    return (e) => {
      const { value } = e.target;
      setForm((f) => ({ ...f, [key]: value }));
      markTouched(key);
    };
  }

  function markTouched(...keys) {
    setTouched((t) => {
      const next = { ...t };
      keys.forEach((k) => (next[k] = true));
      return next;
    });
  }

  function fieldError(key) {
    return touched[key] ? errors[key] : undefined;
  }

  function goNext() {
    const stepErrors = getStepErrors(step, form);
    if (Object.keys(stepErrors).length > 0) {
      markTouched(...(STEP_FIELDS[step] || []));
      return;
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  }

  function goBack() {
    setStep((s) => Math.max(s - 1, 0));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return;

    if (Object.keys(errors).length > 0) {
      markTouched(...Object.values(STEP_FIELDS).flat());
      setStep(firstStepWithError(errors));
      return;
    }
    if (!form.confirmed) return;

    setError("");
    setLoading(true);
    try {
      const token = adminAuth.get();
      const contactCountry = findCountry(form.phoneCountryIso2);
      const payload = {
        name: form.name.trim(),
        trn: form.trn.trim(),
        address: form.address.trim(),
        contactEmail: form.contactEmail.trim(),
        contactPhone: `+${contactCountry.dialCode}${form.phoneNumber.replace(/\D/g, "")}`,
        plan: form.plan,
        owner: {
          name: form.ownerName.trim(),
          email: form.ownerEmail.trim(),
          password: form.ownerPassword,
          forcePasswordChange: form.forcePasswordChange,
        },
      };
      const { tenant } = await api.createTenant(token, payload);

      if (form.migrationMode === "migrate" && migrationFiles.length > 0) {
        // Fire-and-forget (2026-08-22) - deliberately NOT awaited. The
        // Platform Admin must never wait for a migration to finish before
        // the tenant is considered created; this runs in the background
        // using the exact same admin migration API the "Migration" tab
        // itself uses (createTenantMigration -> per-file mapping/validate
        // -> commitTenantMigration), against the real new tenant.id.
        (async () => {
          try {
            const { migration, batches } = await api.createTenantMigration(token, tenant.id, {
              files: migrationFiles.map((f) => f.file),
              fileMeta: migrationFiles.map((f) => ({ importType: f.importType })),
            });
            for (const b of batches) {
              await api.setTenantMigrationBatchMapping(token, tenant.id, b.batch.id, b.mapping);
              await api.validateTenantMigrationBatch(token, tenant.id, b.batch.id);
            }
            await api.commitTenantMigration(token, tenant.id, migration.id);
          } catch (err) {
            // Nothing left listening for this by the time it can fail (the
            // admin has already moved on to the Tenant List) - the real
            // failure state is always visible on the tenant's own
            // Migration tab afterward, which is the honest source of truth
            // here, not a toast that might never be seen.
            console.error("Background onboarding migration failed:", err);
          }
        })();
        showToast(`Tenant created successfully. Migration has been queued.`);
      } else {
        showToast("Tenant created successfully.");
      }

      router.push(`/admin/tenants?created=${encodeURIComponent(form.name)}`);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  const selectedPlan = getPlan(form.plan);
  const estimatedPrice = form.billingCycle === "yearly" ? selectedPlan.yearlyPrice : selectedPlan.monthlyPrice;

  return (
    <div className="page-narrow tenant-wizard">
      <PageHeader
        eyebrow="Platform Admin"
        title="Add New Tenant"
        description="Onboard a business and create its mandatory Owner account."
      />

      <StepWizard steps={STEPS} currentStep={step} />

      <ErrorBanner message={error} />

      <form onSubmit={handleSubmit}>
        <Card>
          {step === 0 && (
            <>
              <h2 style={{ marginBottom: 4 }}>Business Information</h2>
              <p className="form-section-desc">Enter the primary business details for this tenant.</p>
              <Field
                id="name"
                label={<>Business Name<span className="required-asterisk">*</span></>}
                error={fieldError("name")}
              >
                <Input value={form.name} onChange={update("name")} onBlur={() => markTouched("name")} />
              </Field>
              <div className="form-grid">
                <Field
                  id="contactEmail"
                  label={<>Business Email<span className="required-asterisk">*</span></>}
                  error={fieldError("contactEmail")}
                >
                  <Input
                    type="email"
                    name="business-contact-email"
                    autoComplete="off"
                    value={form.contactEmail}
                    onChange={updateLive("contactEmail")}
                    onBlur={() => markTouched("contactEmail")}
                  />
                </Field>
                <div className="field">
                  <label htmlFor="contactPhone">
                    Phone<span className="required-asterisk">*</span>
                  </label>
                  <PhoneInput
                    id="contactPhone"
                    name="business-contact-phone"
                    countryIso2={form.phoneCountryIso2}
                    number={form.phoneNumber}
                    onCountryChange={(iso2) => {
                      setForm((f) => ({ ...f, phoneCountryIso2: iso2 }));
                      markTouched("phoneNumber");
                    }}
                    onNumberChange={(value) => {
                      setForm((f) => ({ ...f, phoneNumber: value }));
                      markTouched("phoneNumber");
                    }}
                    error={fieldError("phoneNumber")}
                  />
                  {fieldError("phoneNumber") && (
                    <p className="field-error" role="alert">{fieldError("phoneNumber")}</p>
                  )}
                </div>
              </div>
              <div className="form-grid">
                <Field id="trn" label="TRN" error={fieldError("trn")} helptext={!fieldError("trn") ? "Optional — exactly 15 digits if provided" : undefined}>
                  <Input
                    value={form.trn}
                    onChange={(e) => {
                      const digits = e.target.value.replace(/\D/g, "").slice(0, 15);
                      setForm((f) => ({ ...f, trn: digits }));
                      markTouched("trn");
                    }}
                    onBlur={() => markTouched("trn")}
                    className="mono"
                    placeholder="100000000000000"
                    inputMode="numeric"
                  />
                </Field>
                <Field id="address" label={<>Address<span className="required-asterisk">*</span></>} error={fieldError("address")}>
                  <Input value={form.address} onChange={update("address")} onBlur={() => markTouched("address")} />
                </Field>
              </div>
              <div className="form-grid">
                <Field id="country" label="Country">
                  <Select value={form.country} onChange={update("country")}>
                    {COUNTRIES.map((c) => (
                      <option key={c.iso2} value={c.iso2}>{c.name}</option>
                    ))}
                  </Select>
                </Field>
                <Field id="timezone" label="Timezone">
                  <Select value={form.timezone} onChange={update("timezone")}>
                    {TIMEZONES.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </Select>
                </Field>
                <Field id="currency" label="Currency" style={{ marginBottom: 0 }}>
                  <Select value={form.currency} onChange={update("currency")}>
                    {CURRENCIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </Select>
                </Field>
              </div>
            </>
          )}

          {step === 1 && (
            <>
              <h2 style={{ marginBottom: 4 }}>Subscription Plan</h2>
              <p className="form-section-desc">
                Select the plan for this tenant. Limits shown are Ledger&rsquo;s pricing catalog — not yet enforced by the backend.
              </p>
              <div className="segmented-control" role="radiogroup" aria-label="Billing cycle" style={{ marginBottom: 16, maxWidth: 240 }}>
                <button
                  type="button"
                  className={`segmented-option${form.billingCycle === "monthly" ? " selected" : ""}`}
                  aria-pressed={form.billingCycle === "monthly"}
                  onClick={() => setForm((f) => ({ ...f, billingCycle: "monthly" }))}
                >
                  Monthly
                </button>
                <button
                  type="button"
                  className={`segmented-option${form.billingCycle === "yearly" ? " selected" : ""}`}
                  aria-pressed={form.billingCycle === "yearly"}
                  onClick={() => setForm((f) => ({ ...f, billingCycle: "yearly" }))}
                >
                  Yearly
                </button>
              </div>
              <div className="plan-card-grid">
                {PLANS.map((p) => (
                  <PlanCard
                    key={p.value}
                    plan={p}
                    billingCycle={form.billingCycle}
                    selected={form.plan === p.value}
                    onSelect={() => setForm((f) => ({ ...f, plan: p.value }))}
                  />
                ))}
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h2 style={{ marginBottom: 4 }}>Owner Account</h2>
              <p className="form-section-desc">This will be the primary administrator account for the tenant.</p>
              <div className="form-grid">
                <Field id="ownerName" label={<>Full Name<span className="required-asterisk">*</span></>} error={fieldError("ownerName")}>
                  <Input value={form.ownerName} onChange={update("ownerName")} onBlur={() => markTouched("ownerName")} />
                </Field>
                <Field id="ownerEmail" label={<>Email<span className="required-asterisk">*</span></>} error={fieldError("ownerEmail")}>
                  {/* name + autoComplete="off" (2026-08-09 fix): this is the
                      TENANT OWNER's email, being typed by the Platform
                      Admin on someone else's behalf - it must never be
                      suggested/prefilled from the admin's own saved
                      credentials (previously unset name/autoComplete let
                      the browser's autofill heuristic bleed the admin's own
                      login email in here). */}
                  <Input
                    type="email"
                    name="owner-email"
                    autoComplete="off"
                    value={form.ownerEmail}
                    onChange={updateLive("ownerEmail")}
                    onBlur={() => markTouched("ownerEmail")}
                  />
                </Field>
              </div>
              <div className="field">
                <label htmlFor="ownerPhone">Phone</label>
                <PhoneInput
                  id="ownerPhone"
                  name="owner-phone"
                  countryIso2={form.ownerPhoneCountryIso2}
                  number={form.ownerPhoneNumber}
                  onCountryChange={(iso2) => setForm((f) => ({ ...f, ownerPhoneCountryIso2: iso2 }))}
                  onNumberChange={(value) => {
                    setForm((f) => ({ ...f, ownerPhoneNumber: value }));
                    markTouched("ownerPhoneNumber");
                  }}
                  error={fieldError("ownerPhoneNumber")}
                />
                {fieldError("ownerPhoneNumber") && <p className="field-error" role="alert">{fieldError("ownerPhoneNumber")}</p>}
              </div>
              <div className="field" style={{ marginBottom: 0 }}>
                <label htmlFor="ownerPassword">Temporary Password<span className="required-asterisk">*</span></label>
                <PasswordInput
                  id="ownerPassword"
                  name="owner-temporary-password"
                  value={form.ownerPassword}
                  onChange={updateLive("ownerPassword")}
                  onBlur={() => markTouched("ownerPassword")}
                  error={fieldError("ownerPassword")}
                />
                {fieldError("ownerPassword") ? (
                  <p className="field-error" role="alert">{fieldError("ownerPassword")}</p>
                ) : (
                  <p className="helptext">{PASSWORD_REQUIREMENT_MESSAGE}</p>
                )}
              </div>
              <label className="checkbox-row">
                <input
                  type="checkbox"
                  checked={form.forcePasswordChange}
                  onChange={(e) => setForm((f) => ({ ...f, forcePasswordChange: e.target.checked }))}
                />
                Force password change on first login
              </label>
            </>
          )}

          {step === 3 && (
            <>
              <h2 style={{ marginBottom: 4 }}>Migration Setup</h2>
              <p className="form-section-desc">
                Optional — bring in this tenant's historical data now, or start fresh and migrate later from its
                Migration tab.
              </p>

              <div className="segmented-control" role="radiogroup" aria-label="Migration setup" style={{ marginBottom: 16, maxWidth: 360 }}>
                <button
                  type="button"
                  className={`segmented-option${form.migrationMode === "fresh" ? " selected" : ""}`}
                  aria-pressed={form.migrationMode === "fresh"}
                  onClick={() => setForm((f) => ({ ...f, migrationMode: "fresh" }))}
                >
                  Start Fresh
                </button>
                <button
                  type="button"
                  className={`segmented-option${form.migrationMode === "migrate" ? " selected" : ""}`}
                  aria-pressed={form.migrationMode === "migrate"}
                  onClick={() => setForm((f) => ({ ...f, migrationMode: "migrate" }))}
                >
                  Migrate Existing Data
                </button>
              </div>

              {form.migrationMode === "migrate" && (
                <>
                  <p className="helptext" style={{ marginTop: -8 }}>
                    Add one file per entity type. Nothing is uploaded yet — these files are only sent once the tenant
                    has actually been created, and the migration runs in the background afterward (you won&rsquo;t
                    need to wait for it here).
                  </p>

                  {migrationFiles.length > 0 && (
                    <table className="data-table" style={{ marginBottom: 12 }}>
                      <thead>
                        <tr>
                          <th>File</th>
                          <th>Entity Type</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {migrationFiles.map((f, i) => (
                          <tr key={i}>
                            <td data-label="File">{f.file.name}</td>
                            <td data-label="Entity Type">
                              <Select
                                value={f.importType}
                                onChange={(e) =>
                                  setMigrationFiles((prev) => prev.map((mf, idx) => (idx === i ? { ...mf, importType: e.target.value } : mf)))
                                }
                              >
                                {MIGRATION_ENTITY_TYPES.map((t) => (
                                  <option key={t.importType} value={t.importType}>
                                    {t.label}
                                  </option>
                                ))}
                              </Select>
                            </td>
                            <td>
                              <Button variant="ghost" type="button" onClick={() => setMigrationFiles((prev) => prev.filter((_, idx) => idx !== i))}>
                                Remove
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  <ImportUploadDropzone onFileSelected={(file) => setMigrationFiles((prev) => [...prev, { file, importType: "CUSTOMER" }])} />
                </>
              )}
            </>
          )}

          {step === 4 && (
            <>
              <h2 style={{ marginBottom: 4 }}>Review &amp; Create</h2>
              <p className="form-section-desc">Confirm the details below before creating this tenant.</p>
              <div className="review-list">
                <div className="review-row">
                  <span className="review-label">Business name</span>
                  <span className="review-value">{form.name || "—"}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Contact</span>
                  <span className="review-value">
                    {form.contactEmail} · +{findCountry(form.phoneCountryIso2).dialCode} {form.phoneNumber}
                  </span>
                </div>
                <div className="review-row">
                  <span className="review-label">TRN</span>
                  <span className="review-value mono">{form.trn || "—"}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Address</span>
                  <span className="review-value">{form.address || "—"}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Country / Timezone / Currency</span>
                  <span className="review-value">
                    {findCountry(form.country).name} · {form.timezone} · {form.currency}
                  </span>
                </div>
                <div className="review-row">
                  <span className="review-label">Selected Plan</span>
                  <span className="review-value">{selectedPlan.name} ({form.billingCycle})</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Included Modules</span>
                  <span className="review-value">{selectedPlan.modules.join(", ")}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Limits</span>
                  <span className="review-value">
                    {selectedPlan.userLimit ? `${selectedPlan.userLimit} users` : "Unlimited users"} · {selectedPlan.storageLimitGb} GB ·{" "}
                    {selectedPlan.ocrCredits.toLocaleString()} OCR credits/mo · {selectedPlan.apiLimitPerMonth.toLocaleString()} API calls/mo
                  </span>
                </div>
                <div className="review-row">
                  <span className="review-label">Estimated Billing</span>
                  <span className="review-value">{formatPlanPrice(estimatedPrice)}{estimatedPrice ? ` / ${form.billingCycle === "yearly" ? "year" : "month"}` : ""}</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Owner</span>
                  <span className="review-value">{form.ownerName} ({form.ownerEmail})</span>
                </div>
                <div className="review-row">
                  <span className="review-label">Migration</span>
                  <span className="review-value">
                    {form.migrationMode === "migrate" && migrationFiles.length > 0
                      ? `${migrationFiles.length} file${migrationFiles.length === 1 ? "" : "s"} will be migrated after the tenant is created`
                      : "Start fresh — no data import"}
                  </span>
                </div>
              </div>
              <div className="checkbox-row">
                <input
                  type="checkbox"
                  id="confirmed"
                  checked={form.confirmed}
                  onChange={(e) => setForm((f) => ({ ...f, confirmed: e.target.checked }))}
                />
                <label htmlFor="confirmed">I confirm the above information is correct.</label>
              </div>
            </>
          )}
        </Card>

        <div className="wizard-actions">
          <Button type="button" variant="outline" onClick={goBack} disabled={step === 0 || loading}>
            Back
          </Button>
          {step < STEPS.length - 1 ? (
            <Button type="button" onClick={goNext}>
              Next Step
            </Button>
          ) : (
            <Button type="submit" disabled={loading || !form.confirmed}>
              {loading ? "Creating…" : "Create Tenant"}
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
