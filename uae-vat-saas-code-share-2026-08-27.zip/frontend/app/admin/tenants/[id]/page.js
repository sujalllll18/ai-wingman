"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import { useToast } from "../../../../hooks/useToast";
import StatusStamp from "../../../../components/StatusStamp";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import ConfirmationDialog from "../../../../components/ui/ConfirmationDialog";
import Tabs from "../../../../components/ui/Tabs";
import OverviewTab from "../../../../components/tenant-profile/OverviewTab";
import SubscriptionTab from "../../../../components/tenant-profile/SubscriptionTab";
import UsersTab from "../../../../components/tenant-profile/UsersTab";
import UsageTab from "../../../../components/tenant-profile/UsageTab";
import StorageTab from "../../../../components/tenant-profile/StorageTab";
import ModulesTab from "../../../../components/tenant-profile/ModulesTab";
import AuditLogsTab from "../../../../components/tenant-profile/AuditLogsTab";
import SupportTicketsTab from "../../../../components/tenant-profile/SupportTicketsTab";
import InvoicesTab from "../../../../components/tenant-profile/InvoicesTab";
import SettingsTab from "../../../../components/tenant-profile/SettingsTab";
import MigrationTab from "../../../../components/tenant-profile/MigrationTab";

// 2026-08-06, Platform Admin Phase 1 tab remap: target tab list is Overview,
// Subscription, Users, Usage, Storage, Modules, Audit Logs, Support
// Tickets, Invoices, Settings. The previous 9 tabs (Overview, Business, VAT
// & Compliance, Users, Subscription, Documents, Activity Timeline, Audit
// Logs, Support Notes) are remapped rather than dropped: Business + VAT &
// Compliance now live inside Settings (see SettingsTab.js), Activity
// Timeline's content moved into Overview, Documents folded into Settings'
// Business Information card, Support Notes became Support Tickets.
const TABS = [
  { key: "overview", label: "Overview" },
  { key: "subscription", label: "Subscription" },
  { key: "users", label: "Users" },
  { key: "usage", label: "Usage" },
  { key: "storage", label: "Storage" },
  { key: "modules", label: "Modules" },
  { key: "audit", label: "Audit Logs" },
  { key: "tickets", label: "Support Tickets" },
  { key: "invoices", label: "Invoices" },
  { key: "migration", label: "Migration" },
  { key: "settings", label: "Settings" },
];
const TAB_KEYS = new Set(TABS.map((t) => t.key));

export default function TenantDetailPage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const tenantName = searchParams.get("name") || "This Tenant";
  const requestedTab = searchParams.get("tab");
  const { showToast } = useToast();

  const [usage, setUsage] = useState(null);
  const [tenant, setTenant] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [activeTab, setActiveTab] = useState(TAB_KEYS.has(requestedTab) ? requestedTab : "overview");
  const [suspendConfirmOpen, setSuspendConfirmOpen] = useState(false);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const [usageData, { tenants }] = await Promise.all([api.getTenantUsage(token, id), api.listTenants(token)]);
      setUsage(usageData);
      // listTenants is the only endpoint that returns name/trn/createdAt today —
      // reused client-side (existing endpoint, filtered to this id) rather than
      // inventing a GET-tenant-by-id endpoint that doesn't exist.
      setTenant(tenants.find((t) => t.id === id) || { id, name: tenantName, trn: null, createdAt: null });
    } catch (err) {
      setError(err.message);
    }
  }

  function handleTabChange(key) {
    setActiveTab(key);
    const params = new URLSearchParams(searchParams.toString());
    params.set("tab", key);
    router.replace(`/admin/tenants/${id}?${params.toString()}`);
  }

  async function handleConfirmToggleStatus() {
    setBusy(true);
    setError("");
    try {
      const token = adminAuth.get();
      if (usage.status === "ACTIVE") {
        await api.suspendTenant(token, id);
        showToast("Tenant suspended.");
      } else {
        await api.reactivateTenant(token, id);
        showToast("Tenant reactivated.");
      }
      setSuspendConfirmOpen(false);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (error && !usage) {
    return (
      <div>
        <PageHeader title={tenantName} />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!usage || !tenant) return <p>Loading…</p>;

  const token = adminAuth.get();

  return (
    <div>
      <PageHeader
        eyebrow="Platform Admin"
        title={tenant.name || tenantName}
        description="Tenant Profile — the single source of truth for this business."
        action={<StatusStamp status={usage.status} />}
      />

      <ErrorBanner message={error} />

      <Tabs tabs={TABS} activeKey={activeTab} onChange={handleTabChange} />

      <div role="tabpanel" id={`tabpanel-${activeTab}`} aria-labelledby={`tab-${activeTab}`}>
        {activeTab === "overview" && (
          <OverviewTab tenant={tenant} usage={usage} busy={busy} onToggleStatus={() => setSuspendConfirmOpen(true)} onNavigateTab={handleTabChange} />
        )}
        {activeTab === "subscription" && (
          <SubscriptionTab usage={usage} tenant={tenant} token={token} tenantId={id} onPlanSaved={load} showToast={showToast} setError={setError} />
        )}
        {activeTab === "users" && <UsersTab token={token} tenantId={id} onStaffAdded={load} showToast={showToast} setError={setError} />}
        {activeTab === "usage" && <UsageTab usage={usage} />}
        {activeTab === "storage" && <StorageTab />}
        {activeTab === "modules" && <ModulesTab usage={usage} />}
        {activeTab === "audit" && <AuditLogsTab />}
        {activeTab === "tickets" && <SupportTicketsTab />}
        {activeTab === "invoices" && <InvoicesTab />}
        {activeTab === "migration" && <MigrationTab token={token} tenantId={id} tenantName={tenant.name || tenantName} />}
        {activeTab === "settings" && (
          <SettingsTab
            tenant={tenant}
            usage={usage}
            token={token}
            tenantId={id}
            onSaved={load}
            showToast={showToast}
            setError={setError}
            busy={busy}
            onToggleStatus={() => setSuspendConfirmOpen(true)}
          />
        )}
      </div>

      <ConfirmationDialog
        open={suspendConfirmOpen}
        title={usage.status === "ACTIVE" ? "Suspend this tenant?" : "Reactivate this tenant?"}
        message={
          usage.status === "ACTIVE"
            ? `"${tenant.name}" will be locked out of the platform immediately. You can reactivate it anytime.`
            : `"${tenant.name}" will regain access to the platform immediately.`
        }
        confirmLabel={usage.status === "ACTIVE" ? "Suspend" : "Reactivate"}
        variant={usage.status === "ACTIVE" ? "danger" : "primary"}
        busy={busy}
        onConfirm={handleConfirmToggleStatus}
        onCancel={() => setSuspendConfirmOpen(false)}
      />
    </div>
  );
}
