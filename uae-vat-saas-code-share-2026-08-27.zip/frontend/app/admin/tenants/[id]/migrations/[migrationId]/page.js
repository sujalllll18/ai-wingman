"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { api } from "../../../../../../lib/api";
import { adminAuth } from "../../../../../../lib/auth";
import { useToast } from "../../../../../../hooks/useToast";
import PageHeader from "../../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../../../components/ui/LoadingSkeleton";
import Button from "../../../../../../components/ui/Button";
import Table from "../../../../../../components/ui/Table";
import TableScroll from "../../../../../../components/ui/TableScroll";
import Modal from "../../../../../../components/ui/Modal";
import MigrationProgressPanel from "../../../../../../components/migrations/MigrationProgressPanel";
import MigrationFinalSummary from "../../../../../../components/migrations/MigrationFinalSummary";

const RUNNING_STATUSES = ["QUEUED", "PROCESSING"];
const TERMINAL_STATUSES = ["COMPLETED", "COMPLETED_WITH_ERRORS", "FAILED", "CANCELLED"];
const POLL_INTERVAL_MS = 2000;

// Platform Admin's version of /tenant/migrations/[id] - same shared
// MigrationProgressPanel/MigrationFinalSummary components, wired to the
// admin-scoped api.js functions. Pause/Resume/Cancel/Retry are all
// available to Platform Admin unconditionally (no RBAC concept on this
// side - see platformAdminMigration.controller.js).
export default function TenantMigrationDetailPage() {
  const { id: tenantId, migrationId } = useParams();
  const searchParams = useSearchParams();
  const tenantName = searchParams.get("name") || "This Tenant";
  const { showToast } = useToast();

  const [status, setStatus] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [failedRows, setFailedRows] = useState(null);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [migrationId]);

  useEffect(() => {
    if (!status || !RUNNING_STATUSES.includes(status.status)) return undefined;
    const timer = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [status?.status, migrationId]);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const data = await api.getTenantMigrationStatus(token, tenantId, migrationId);
      setStatus(data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function withBusy(fn, successMessage) {
    setError("");
    setBusy(true);
    try {
      await fn();
      if (successMessage) showToast(successMessage);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleViewFailed() {
    const token = adminAuth.get();
    const allFailed = [];
    for (const e of status.perEntity) {
      if (e.failed === 0) continue;
      const { records } = await api.getTenantMigrationBatchRecords(token, tenantId, e.batchId, { status: "INVALID,FAILED" });
      allFailed.push(...records.map((r) => ({ ...r, entityLabel: e.label })));
    }
    setFailedRows(allFailed);
  }

  if (!status) {
    return (
      <div>
        <ErrorBanner message={error} />
        {!error && <LoadingSkeleton columns={4} />}
      </div>
    );
  }

  const isRunning = RUNNING_STATUSES.includes(status.status);
  const isTerminal = TERMINAL_STATUSES.includes(status.status);
  const isPaused = status.status === "PAUSED";

  return (
    <div>
      <PageHeader
        breadcrumb={[
          { label: "Ledger" },
          { label: "Tenants", href: "/admin/tenants" },
          { label: tenantName, href: `/admin/tenants/${tenantId}?name=${encodeURIComponent(tenantName)}&tab=migration` },
          { label: status.migration?.migrationNumber || "Migration" },
        ]}
        title={`${status.migration?.migrationNumber || "Migration"} — ${tenantName}`}
        action={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {isRunning && (
              <Button variant="outline" onClick={() => withBusy(() => api.pauseTenantMigration(adminAuth.get(), tenantId, migrationId), "Pause requested.")} disabled={busy}>
                Pause
              </Button>
            )}
            {isPaused && (
              <Button onClick={() => withBusy(() => api.resumeTenantMigration(adminAuth.get(), tenantId, migrationId), "Resumed.")} disabled={busy}>
                Resume
              </Button>
            )}
            {(isRunning || isPaused) && (
              <Button
                variant="danger"
                onClick={() => {
                  if (window.confirm("Cancel this migration? Records already imported will not be undone.")) {
                    withBusy(() => api.cancelTenantMigration(adminAuth.get(), tenantId, migrationId), "Migration cancelled.");
                  }
                }}
                disabled={busy}
              >
                Cancel
              </Button>
            )}
          </div>
        }
      />

      <ErrorBanner message={error} />

      {(isRunning || isPaused) && <MigrationProgressPanel status={status} isRunning={isRunning} />}

      {isTerminal && (
        <MigrationFinalSummary
          status={status}
          canRetry
          onViewFailed={status.failedCount > 0 ? handleViewFailed : undefined}
          onDownloadErrorReport={status.failedCount > 0 ? () => api.downloadTenantMigrationErrorReport(adminAuth.get(), tenantId, migrationId) : undefined}
          onDownloadMigrationReport={() => api.downloadTenantMigrationErrorReport(adminAuth.get(), tenantId, migrationId)}
          onRetryFailed={() => withBusy(() => api.retryTenantMigrationRecords(adminAuth.get(), tenantId, migrationId), "Retrying failed records.")}
          goToTenantHref={`/admin/tenants/${tenantId}?name=${encodeURIComponent(tenantName)}`}
        />
      )}

      {failedRows && (
        <Modal open onClose={() => setFailedRows(null)} size="lg" ariaLabel="Failed records">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0 }}>Failed Records</h3>
            <Button variant="ghost" onClick={() => setFailedRows(null)}>
              Close
            </Button>
          </div>
          {failedRows.length === 0 ? (
            <p className="helptext">Nothing here.</p>
          ) : (
            <TableScroll>
              <Table
                columns={[
                  { key: "entityLabel", header: "Entity" },
                  { key: "rowNumber", header: "Row #" },
                  { key: "sourceIdentifier", header: "Record", render: (r) => r.sourceIdentifier || `Row ${r.rowNumber}` },
                  { key: "errorCode", header: "Error Code", render: (r) => r.errorCode || "—" },
                  {
                    key: "issues",
                    header: "Problem",
                    render: (r) => <span style={{ color: "var(--color-danger)" }}>{(r.validationErrors || []).map((e) => e.message).join("; ")}</span>,
                  },
                ]}
                rows={failedRows}
                rowKey={(r) => r.id}
              />
            </TableScroll>
          )}
        </Modal>
      )}
    </div>
  );
}
