"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../lib/api";
import { adminAuth } from "../../../lib/auth";
import { useLocalStorageState } from "../../../hooks/useLocalStorageState";
import { useToast } from "../../../hooks/useToast";
import StatusStamp from "../../../components/StatusStamp";
import PlanTag from "../../../components/PlanTag";
import PageHeader from "../../../components/ui/PageHeader";
import EmptyState from "../../../components/ui/EmptyState";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import DataTable from "../../../components/ui/DataTable";
import TableScroll from "../../../components/ui/TableScroll";
import ColumnSelector from "../../../components/ui/ColumnSelector";
import Toolbar from "../../../components/ui/Toolbar";
import Button from "../../../components/ui/Button";
import ActionMenu from "../../../components/ui/ActionMenu";
import ConfirmationDialog from "../../../components/ui/ConfirmationDialog";
import Pagination from "../../../components/ui/Pagination";
import KpiCard from "../../../components/ui/KpiCard";
import Tooltip from "../../../components/ui/Tooltip";

/* ---------- helpers ---------- */

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function formatRelativeTime(iso) {
  if (!iso) return null;
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

// Real, reusable calculation - returns null (not tracked) until a tenant
// actually carries a subscriptionEndsAt field from the backend.
function getDaysRemainingBadge(subscriptionEndsAt) {
  if (!subscriptionEndsAt) return null;
  const days = Math.ceil((new Date(subscriptionEndsAt).getTime() - Date.now()) / 86400000);
  if (days < 0) return { label: "Expired", variant: "danger" };
  if (days <= 30) return { label: `${days} days left`, variant: "warning" };
  return { label: `${days} days left`, variant: "success" };
}

function NotTracked({ label }) {
  return (
    <Tooltip label={label}>
      <span style={{ color: "var(--color-ink-faint)" }}>—</span>
    </Tooltip>
  );
}

function CopyButton({ text, message, showToast, ariaLabel }) {
  async function handleCopy(e) {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(text);
      showToast(message);
    } catch {
      showToast("Couldn't copy — try selecting the text manually.", "error");
    }
  }
  return (
    <button type="button" className="copy-btn" onClick={handleCopy} aria-label={ariaLabel}>
      <svg viewBox="0 0 24 24">
        <rect x="9" y="9" width="12" height="12" rx="2" />
        <path d="M5 15V5a2 2 0 0 1 2-2h10" />
      </svg>
    </button>
  );
}

function csvEscape(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function exportTenantsToCsv(list) {
  const rows = [
    ["Business", "Owner", "TRN", "Plan", "Status", "Users", "Created"],
    ...list.map((t) => [t.name, t.ownerName || "", t.trn || "", t.plan, t.status, t.userCount, t.createdAt ? formatDate(t.createdAt) : ""]),
  ];
  downloadCsv(`tenants-export-${new Date().toISOString().slice(0, 10)}.csv`, rows);
}

function sortTenants(list, mode) {
  const sorted = [...list];
  if (mode === "newest") sorted.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  else if (mode === "oldest") sorted.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  else if (mode === "name-asc") sorted.sort((a, b) => a.name.localeCompare(b.name));
  return sorted;
}

const KPI_ICONS = {
  total: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
    </svg>
  ),
  active: (
    <svg viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  ),
  trial: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3.5 2" />
    </svg>
  ),
  suspended: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9l5 5M14.5 9l-5 5" />
    </svg>
  ),
  expiring: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="4.5" width="17" height="16" rx="2" />
      <path d="M3.5 9.5h17M8 3v3M16 3v3" />
    </svg>
  ),
};

export default function TenantsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { showToast } = useToast();

  const [tenants, setTenants] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [planFilter, setPlanFilter] = useState("ALL");
  const [renewalFilter, setRenewalFilter] = useState("ALL");
  const [sortMode, setSortMode] = useState("newest");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [suspendTarget, setSuspendTarget] = useState(null);

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const created = searchParams.get("created");
    if (created) {
      showToast(`"${created}" was created successfully.`);
      router.replace("/admin/tenants");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const { tenants } = await api.listTenants(token);
      setTenants(tenants);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  async function handleConfirmSuspendToggle() {
    if (!suspendTarget) return;
    setBusy(true);
    try {
      const token = adminAuth.get();
      if (suspendTarget.status === "ACTIVE") {
        await api.suspendTenant(token, suspendTarget.id);
        showToast(`${suspendTarget.name} suspended.`);
      } else {
        await api.reactivateTenant(token, suspendTarget.id);
        showToast(`${suspendTarget.name} reactivated.`);
      }
      setSuspendTarget(null);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  const COLUMN_DEFS = useMemo(
    () => [
      { key: "business", label: "Business", alwaysVisible: true, sortable: true, render: (t) => t.name },
      {
        key: "owner",
        label: "Owner",
        render: (t) =>
          t.ownerName ? (
            <span>
              <span className="col-owner-name">{t.ownerName}</span>
              {t.ownerEmail && <span className="col-owner-email">{t.ownerEmail}</span>}
            </span>
          ) : (
            <NotTracked label="Owner details aren't returned by this list endpoint yet" />
          ),
      },
      {
        key: "trn",
        label: "TRN",
        render: (t) =>
          t.trn ? (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              <span className="mono">{t.trn}</span>
              <CopyButton text={t.trn} message="TRN copied" showToast={showToast} ariaLabel={`Copy TRN for ${t.name}`} />
            </span>
          ) : (
            "—"
          ),
      },
      { key: "plan", label: "Plan", render: (t) => <PlanTag plan={t.plan} /> },
      { key: "status", label: "Status", render: (t) => <StatusStamp status={t.status} /> },
      { key: "users", label: "Users", align: "right", render: (t) => t.userCount },
      {
        key: "storage",
        label: "Storage",
        render: () => <NotTracked label="Storage tracking doesn't exist in the backend schema yet" />,
      },
      {
        key: "subStart",
        label: "Subscription Start",
        render: (t) => (
          <Tooltip label="Derived from the Tenant's creation date — a distinct subscription-period start isn't tracked separately yet">
            <span>{formatDate(t.createdAt)}</span>
          </Tooltip>
        ),
      },
      {
        key: "subEnd",
        label: "Subscription End",
        render: (t) =>
          t.subscriptionEndsAt ? formatDate(t.subscriptionEndsAt) : <NotTracked label="Subscription end date isn't tracked in the current billing model yet" />,
      },
      {
        key: "daysRemaining",
        label: "Days Remaining",
        render: (t) => {
          const badge = getDaysRemainingBadge(t.subscriptionEndsAt);
          if (!badge) return <NotTracked label="Requires a tracked subscription end date (not available yet)" />;
          return <span className={`badge badge-${badge.variant}`}>{badge.label}</span>;
        },
      },
      {
        key: "lastActivity",
        label: "Last Activity",
        render: (t) => {
          const rel = formatRelativeTime(t.lastActivityAt);
          return rel || <NotTracked label="Not returned by this list endpoint yet" />;
        },
      },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (t) => (
          <ActionMenu
            ariaLabel={`Actions for ${t.name}`}
            items={[
              { label: "View", onClick: () => router.push(`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}`) },
              { label: "Edit", onClick: () => router.push(`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}&tab=settings`) },
              t.status === "ACTIVE"
                ? { label: "Suspend", danger: true, onClick: () => setSuspendTarget(t), disabled: busy }
                : { label: "Activate", onClick: () => setSuspendTarget(t), disabled: busy },
              { label: "Change Plan", onClick: () => router.push(`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}&tab=subscription`) },
              { label: "Migration", onClick: () => router.push(`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}&tab=migration`) },
              { label: "Reset Owner Password", disabled: true, disabledReason: "Not available yet — no reset-password endpoint exists on the backend" },
              { label: "Login as Tenant", disabled: true, disabledReason: "Not available yet — no impersonation endpoint exists on the backend" },
              { label: "View Audit Log", onClick: () => router.push(`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}&tab=audit`) },
              { label: "Archive", disabled: true, disabledReason: "Not available yet — no archive endpoint exists on the backend" },
              { label: "Delete", danger: true, disabled: true, disabledReason: "Not available yet — no delete endpoint exists on the backend" },
            ]}
          />
        ),
      },
    ],
    [showToast, router, busy]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_tenant_list_column_order_v2", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_tenant_list_hidden_columns_v2", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const stats = useMemo(() => {
    if (!tenants) return null;
    const trackedExpiring = tenants.filter((t) => t.subscriptionEndsAt);
    return {
      total: tenants.length,
      active: tenants.filter((t) => t.status === "ACTIVE").length,
      trial: tenants.filter((t) => t.plan === "TRIAL").length,
      suspended: tenants.filter((t) => t.status === "SUSPENDED").length,
      expiringSoon:
        trackedExpiring.length === 0
          ? null
          : trackedExpiring.filter((t) => {
              const badge = getDaysRemainingBadge(t.subscriptionEndsAt);
              return badge && badge.variant === "warning";
            }).length,
    };
  }, [tenants]);

  const filtered = useMemo(() => {
    if (!tenants) return [];
    const q = search.trim().toLowerCase();
    let list = tenants.filter((t) => {
      const matchesSearch =
        !q || t.name.toLowerCase().includes(q) || (t.trn || "").toLowerCase().includes(q) || (t.ownerName || "").toLowerCase().includes(q) || (t.ownerEmail || "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "ALL" || t.status === statusFilter;
      const matchesPlan = planFilter === "ALL" || t.plan === planFilter;
      const matchesRenewal = renewalFilter === "ALL" || (renewalFilter === "EXPIRING_SOON" && getDaysRemainingBadge(t.subscriptionEndsAt)?.variant === "warning");
      return matchesSearch && matchesStatus && matchesPlan && matchesRenewal;
    });
    return sortTenants(list, sortMode);
  }, [tenants, search, statusFilter, planFilter, renewalFilter, sortMode]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  function handleExport() {
    exportTenantsToCsv(filtered);
  }

  return (
    <div>
      <PageHeader
        eyebrow="Platform Admin"
        title="Tenants"
        description="Every business subscribed to the platform, at a glance."
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {tenants && tenants.length > 0 && (
              <Button variant="outline" onClick={handleExport}>
                Export
              </Button>
            )}
            <Link href="/admin/tenants/new">
              <Button>+ New Tenant</Button>
            </Link>
          </div>
        }
      />

      <ErrorBanner message={error} />

      {stats && (
        <div className="kpi-card-grid">
          <KpiCard
            label="Total Tenants"
            value={stats.total}
            icon={KPI_ICONS.total}
            active={statusFilter === "ALL" && planFilter === "ALL"}
            onClick={() => {
              setStatusFilter("ALL");
              setPlanFilter("ALL");
              resetToPageOne();
            }}
          />
          <KpiCard
            label="Active"
            value={stats.active}
            icon={KPI_ICONS.active}
            active={statusFilter === "ACTIVE"}
            onClick={() => {
              setStatusFilter("ACTIVE");
              resetToPageOne();
            }}
          />
          <KpiCard
            label="Trial"
            value={stats.trial}
            icon={KPI_ICONS.trial}
            active={planFilter === "TRIAL"}
            onClick={() => {
              setPlanFilter("TRIAL");
              resetToPageOne();
            }}
          />
          <KpiCard
            label="Suspended"
            value={stats.suspended}
            icon={KPI_ICONS.suspended}
            active={statusFilter === "SUSPENDED"}
            onClick={() => {
              setStatusFilter("SUSPENDED");
              resetToPageOne();
            }}
          />
          <KpiCard
            label="Expiring Soon"
            value={stats.expiringSoon}
            icon={KPI_ICONS.expiring}
            placeholder={stats.expiringSoon === null}
            placeholderTooltip="Requires subscription-period tracking (not available yet)"
            active={renewalFilter === "EXPIRING_SOON"}
            onClick={
              stats.expiringSoon === null
                ? undefined
                : () => {
                    setRenewalFilter("EXPIRING_SOON");
                    resetToPageOne();
                  }
            }
          />
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        {tenants === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={7} />
          </div>
        ) : tenants.length === 0 ? (
          <EmptyState
            icon={
              <svg viewBox="0 0 24 24" className="empty-illustration">
                <rect x="4" y="8" width="16" height="13" rx="1.5" />
                <path d="M8 8V6a4 4 0 0 1 8 0v2" />
                <rect x="10" y="12" width="4" height="4" rx="0.5" />
              </svg>
            }
            title="No Tenants yet"
            description="Onboard your first business and it will show up here for you to manage."
            action={
              <Link href="/admin/tenants/new">
                <Button>+ New Tenant</Button>
              </Link>
            }
          />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search by name, TRN, or owner…"
                filters={
                  <>
                    <select
                      className="select-filter"
                      value={statusFilter}
                      onChange={(e) => {
                        setStatusFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All statuses</option>
                      <option value="ACTIVE">Active</option>
                      <option value="SUSPENDED">Suspended</option>
                    </select>
                    <select
                      className="select-filter"
                      value={planFilter}
                      onChange={(e) => {
                        setPlanFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All plans</option>
                      <option value="TRIAL">Trial</option>
                      <option value="STANDARD">Standard</option>
                      <option value="PREMIUM">Premium</option>
                    </select>
                    <Tooltip label="Partner/reseller tracking doesn't exist in the backend yet">
                      <select className="select-filter" disabled>
                        <option>All partners</option>
                      </select>
                    </Tooltip>
                    <select
                      className="select-filter"
                      value={renewalFilter}
                      onChange={(e) => {
                        setRenewalFilter(e.target.value);
                        resetToPageOne();
                      }}
                    >
                      <option value="ALL">All renewals</option>
                      <option value="EXPIRING_SOON">Expiring soon</option>
                    </select>
                    <select className="select-filter" value={sortMode} onChange={(e) => setSortMode(e.target.value)}>
                      <option value="newest">Sort: Newest</option>
                      <option value="oldest">Sort: Oldest</option>
                      <option value="name-asc">Sort: Business A-Z</option>
                    </select>
                    <ColumnSelector columns={COLUMN_DEFS} columnOrder={columnOrder} hiddenColumns={hiddenColumns} onToggle={handleToggleColumn} onReorder={setColumnOrder} />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState
                icon={
                  <svg viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="7" />
                    <path d="M21 21l-4.3-4.3" />
                  </svg>
                }
                title="No matching Tenants"
                description="Try a different search term or clear the filters."
              />
            ) : (
              <>
                <TableScroll>
                  <DataTable columns={COLUMN_DEFS} rows={pageItems} columnOrder={columnOrder} hiddenColumns={hiddenColumns} stickyHeader zebra />
                </TableScroll>
                <Pagination page={currentPage} pageSize={pageSize} totalItems={filtered.length} onPageChange={setPage} onPageSizeChange={(n) => { setPageSize(n); resetToPageOne(); }} itemLabel="tenants" />
              </>
            )}
          </>
        )}
      </div>

      <ConfirmationDialog
        open={!!suspendTarget}
        title={suspendTarget?.status === "ACTIVE" ? "Suspend this tenant?" : "Reactivate this tenant?"}
        message={
          suspendTarget?.status === "ACTIVE"
            ? `"${suspendTarget?.name}" will be locked out of the platform immediately. You can reactivate it anytime.`
            : `"${suspendTarget?.name}" will regain access to the platform immediately.`
        }
        confirmLabel={suspendTarget?.status === "ACTIVE" ? "Suspend" : "Reactivate"}
        variant={suspendTarget?.status === "ACTIVE" ? "danger" : "primary"}
        busy={busy}
        onConfirm={handleConfirmSuspendToggle}
        onCancel={() => setSuspendTarget(null)}
      />
    </div>
  );
}
