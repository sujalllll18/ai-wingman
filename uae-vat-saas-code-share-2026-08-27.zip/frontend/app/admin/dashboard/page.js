"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ChartTooltip, PieChart, Pie, Cell, Legend, ResponsiveContainer } from "recharts";
import { api } from "../../../lib/api";
import { adminAuth } from "../../../lib/auth";
import { getPlan } from "../../../lib/plans";
import PageHeader from "../../../components/ui/PageHeader";
import ErrorBanner from "../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../components/ui/LoadingSkeleton";
import Card from "../../../components/ui/Card";
import Button from "../../../components/ui/Button";
import EmptyState from "../../../components/ui/EmptyState";
import Tooltip from "../../../components/ui/Tooltip";
import KpiCard from "../../../components/ui/KpiCard";
import StatusStamp from "../../../components/StatusStamp";
import PlanTag from "../../../components/PlanTag";

// Platform Dashboard (2026-08-06, Platform Admin Phase 1) - the real landing
// page after admin login. Previously /admin/dashboard *was* the tenant list;
// that page moved to /admin/tenants (see app/admin/tenants/page.js) and this
// route now holds an actual stats/analytics dashboard. Every number here is
// computed client-side from the one real endpoint (api.listTenants) - there
// is no dedicated analytics/stats endpoint on the backend yet, no billing
// history, and no platform-wide audit trail. Monthly Revenue is therefore a
// labeled *estimate* (plan catalog price x active tenants on that plan, see
// lib/plans.js), not a real billing figure, and anything with literally no
// derivable data (Storage Used, Support Tickets, platform-wide Approvals,
// System Health) renders an honest placeholder instead of invented numbers -
// same "not available yet" convention used throughout the rest of Ledger.

const COLOR_ACCENT = "#2563eb";
const COLOR_SUCCESS = "#15803d";
const COLOR_WARNING = "#b45309";
const COLOR_DANGER = "#dc2626";
const COLOR_INK_SOFT = "#6b7280";

const KPI_ICONS = {
  total: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
    </svg>
  ),
  active: (
    <svg viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  ),
  trial: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3.5 2" />
    </svg>
  ),
  suspended: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9l5 5M14.5 9l-5 5" />
    </svg>
  ),
  expiring: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="4.5" width="17" height="16" rx="2" />
      <path d="M3.5 9.5h17M8 3v3M16 3v3" />
    </svg>
  ),
  revenue: (
    <svg viewBox="0 0 24 24">
      <path d="M4 6h16M4 12h10M4 18h13" />
      <circle cx="19" cy="12" r="1.6" />
      <circle cx="20" cy="18" r="1.6" />
    </svg>
  ),
  users: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="8" r="3" />
      <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
      <circle cx="17" cy="9" r="2.4" />
      <path d="M15.3 14.2c2.6.3 4.7 2.5 4.7 5.8" />
    </svg>
  ),
  storage: (
    <svg viewBox="0 0 24 24">
      <ellipse cx="12" cy="6" rx="8" ry="3" />
      <path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6" />
      <path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" />
    </svg>
  ),
};

function formatRelativeTime(iso) {
  if (!iso) return "—";
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

function formatCurrency(value) {
  return `AED ${Number(value || 0).toLocaleString()}`;
}

function getDaysRemainingVariant(subscriptionEndsAt) {
  if (!subscriptionEndsAt) return null;
  const days = Math.ceil((new Date(subscriptionEndsAt).getTime() - Date.now()) / 86400000);
  if (days < 0) return "danger";
  if (days <= 30) return "warning";
  return null;
}

// Last 6 calendar months, oldest first - purely derived from each tenant's
// real createdAt, no invented data points.
function buildGrowthSeries(tenants) {
  const months = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ key: `${d.getFullYear()}-${d.getMonth()}`, label: d.toLocaleDateString(undefined, { month: "short" }), count: 0 });
  }
  tenants.forEach((t) => {
    if (!t.createdAt) return;
    const d = new Date(t.createdAt);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const bucket = months.find((m) => m.key === key);
    if (bucket) bucket.count += 1;
  });
  return months;
}

export default function PlatformDashboardPage() {
  const [tenants, setTenants] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const { tenants } = await api.listTenants(token);
      setTenants(tenants);
    } catch (err) {
      setError(err.message);
    }
  }

  const stats = useMemo(() => {
    if (!tenants) return null;
    const active = tenants.filter((t) => t.status === "ACTIVE");
    const trial = tenants.filter((t) => t.plan === "TRIAL");
    const suspended = tenants.filter((t) => t.status === "SUSPENDED");
    const trackedExpiring = tenants.filter((t) => t.subscriptionEndsAt);
    const monthlyRevenue = active.reduce((sum, t) => sum + (getPlan(t.plan).monthlyPrice || 0), 0);
    const activeUsers = active.reduce((sum, t) => sum + (t.userCount || 0), 0);
    return {
      total: tenants.length,
      active: active.length,
      trial: trial.length,
      suspended: suspended.length,
      expiringSoon: trackedExpiring.length === 0 ? null : trackedExpiring.filter((t) => getDaysRemainingVariant(t.subscriptionEndsAt) === "warning").length,
      monthlyRevenue,
      activeUsers,
    };
  }, [tenants]);

  const growthSeries = useMemo(() => (tenants ? buildGrowthSeries(tenants) : []), [tenants]);

  const planDistribution = useMemo(() => {
    if (!tenants) return [];
    const counts = { TRIAL: 0, STANDARD: 0, PREMIUM: 0 };
    tenants.forEach((t) => {
      if (counts[t.plan] !== undefined) counts[t.plan] += 1;
    });
    return [
      { name: "Trial", value: counts.TRIAL, color: COLOR_WARNING },
      { name: "Standard", value: counts.STANDARD, color: COLOR_INK_SOFT },
      { name: "Premium", value: counts.PREMIUM, color: COLOR_ACCENT },
    ].filter((d) => d.value > 0);
  }, [tenants]);

  const statusDistribution = useMemo(() => {
    if (!tenants) return [];
    const active = tenants.filter((t) => t.status === "ACTIVE").length;
    const suspended = tenants.filter((t) => t.status === "SUSPENDED").length;
    return [
      { name: "Active", value: active, color: COLOR_SUCCESS },
      { name: "Suspended", value: suspended, color: COLOR_DANGER },
    ].filter((d) => d.value > 0);
  }, [tenants]);

  const recentTenants = useMemo(() => {
    if (!tenants) return [];
    return [...tenants].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  }, [tenants]);

  return (
    <div>
      <PageHeader eyebrow="Platform Admin" title="Dashboard" description="Platform-wide overview across every tenant." />

      <ErrorBanner message={error} />

      {tenants === null ? (
        <LoadingSkeleton columns={4} />
      ) : (
        <>
          <div className="kpi-card-grid">
            <KpiCard label="Total Tenants" value={stats.total} icon={KPI_ICONS.total} helptext="Every business on the platform" />
            <KpiCard label="Active Tenants" value={stats.active} icon={KPI_ICONS.active} helptext="Currently able to log in" />
            <KpiCard label="Trial Tenants" value={stats.trial} icon={KPI_ICONS.trial} helptext="On the Trial plan" />
            <KpiCard label="Suspended Tenants" value={stats.suspended} icon={KPI_ICONS.suspended} helptext="Locked out of the platform" />
            <KpiCard
              label="Expiring in 30 Days"
              value={stats.expiringSoon}
              icon={KPI_ICONS.expiring}
              placeholder={stats.expiringSoon === null}
              placeholderTooltip="Requires subscription-period tracking (not available yet)"
              helptext={stats.expiringSoon === null ? undefined : "Subscriptions ending soon"}
            />
            <KpiCard
              label="Monthly Revenue"
              value={formatCurrency(stats.monthlyRevenue)}
              icon={KPI_ICONS.revenue}
              helptext="Estimate — plan price × active tenants, not real billing data"
            />
            <KpiCard label="Active Users" value={stats.activeUsers} icon={KPI_ICONS.users} helptext="Across all active tenants" />
            <KpiCard label="Storage Used" placeholder icon={KPI_ICONS.storage} placeholderTooltip="Storage tracking doesn't exist in the backend schema yet" />
          </div>

          <div className="detail-layout" style={{ marginTop: 8 }}>
            <div className="detail-main">
              <Card>
                <h2 style={{ marginBottom: 4 }}>Tenant Growth</h2>
                <p className="form-section-desc">New tenants created per month, last 6 months.</p>
                <div style={{ width: "100%", height: 260 }}>
                  <ResponsiveContainer>
                    <BarChart data={growthSeries} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--color-line)" vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 12, fill: COLOR_INK_SOFT }} axisLine={{ stroke: "var(--color-line)" }} tickLine={false} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: COLOR_INK_SOFT }} axisLine={false} tickLine={false} width={28} />
                      <ChartTooltip cursor={{ fill: "var(--color-surface-sunken)" }} />
                      <Bar dataKey="count" name="New tenants" fill={COLOR_ACCENT} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
                  <div>
                    <h2 style={{ marginBottom: 4 }}>Plan Distribution</h2>
                    <p className="form-section-desc">Tenants by subscription plan.</p>
                    {planDistribution.length === 0 ? (
                      <EmptyState title="No tenants yet" />
                    ) : (
                      <div style={{ width: "100%", height: 220 }}>
                        <ResponsiveContainer>
                          <PieChart>
                            <Pie data={planDistribution} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                              {planDistribution.map((d) => (
                                <Cell key={d.name} fill={d.color} />
                              ))}
                            </Pie>
                            <ChartTooltip />
                            <Legend verticalAlign="bottom" height={24} iconType="circle" />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </div>
                  <div>
                    <h2 style={{ marginBottom: 4 }}>Subscription Distribution</h2>
                    <p className="form-section-desc">Tenants by account status.</p>
                    {statusDistribution.length === 0 ? (
                      <EmptyState title="No tenants yet" />
                    ) : (
                      <div style={{ width: "100%", height: 220 }}>
                        <ResponsiveContainer>
                          <PieChart>
                            <Pie data={statusDistribution} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                              {statusDistribution.map((d) => (
                                <Cell key={d.name} fill={d.color} />
                              ))}
                            </Pie>
                            <ChartTooltip />
                            <Legend verticalAlign="bottom" height={24} iconType="circle" />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </div>
                </div>
              </Card>

              <Card>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                  <h2 style={{ marginBottom: 0 }}>Recent Tenants</h2>
                  <Link href="/admin/tenants" className="btn btn-outline btn-sm">
                    View all
                  </Link>
                </div>
                <p className="form-section-desc">The 5 most recently onboarded businesses.</p>
                {recentTenants.length === 0 ? (
                  <EmptyState title="No tenants yet" description="Onboard your first business to see it here." />
                ) : (
                  <div className="review-list">
                    {recentTenants.map((t) => (
                      <Link key={t.id} href={`/admin/tenants/${t.id}?name=${encodeURIComponent(t.name)}`} className="review-row" style={{ textDecoration: "none", color: "inherit" }}>
                        <span className="review-label">{t.name}</span>
                        <span className="review-value" style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                          <PlanTag plan={t.plan} />
                          <StatusStamp status={t.status} />
                          <span style={{ color: "var(--color-ink-faint)", fontSize: 12 }}>{formatRelativeTime(t.createdAt)}</span>
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
              </Card>

              <Card>
                <h2 style={{ marginBottom: 4 }}>Recent Activity</h2>
                <p className="form-section-desc">
                  Platform-wide audit logging isn&rsquo;t wired up yet — this only reflects tenant-creation events, the one thing currently tracked.
                </p>
                {recentTenants.length === 0 ? (
                  <EmptyState title="Nothing yet" />
                ) : (
                  <div className="review-list">
                    {recentTenants.map((t) => (
                      <div key={t.id} className="review-row">
                        <span className="review-label">{t.name} created</span>
                        <span className="review-value" style={{ color: "var(--color-ink-faint)", fontSize: 12 }}>
                          {formatRelativeTime(t.createdAt)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            </div>

            <div className="detail-rail">
              <Card>
                <h2 style={{ marginBottom: 12 }}>Quick Actions</h2>
                <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
                  <Link href="/admin/tenants/new">
                    <Button style={{ width: "100%", justifyContent: "center" }}>+ New Tenant</Button>
                  </Link>
                  <Link href="/admin/tenants">
                    <Button variant="outline" style={{ width: "100%", justifyContent: "center" }}>
                      View All Tenants
                    </Button>
                  </Link>
                </div>
              </Card>

              <Card>
                <h2 style={{ marginBottom: 4 }}>System Health</h2>
                <p className="form-section-desc">Static indicator — live infrastructure monitoring isn&rsquo;t wired up yet.</p>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span className="badge badge-success">Operational</span>
                </div>
              </Card>

              <Card>
                <h2 style={{ marginBottom: 4 }}>Recent Support Tickets</h2>
                <PlaceholderEmpty label="No backend model or endpoint exists for support tickets yet." />
              </Card>

              <Card>
                <h2 style={{ marginBottom: 4 }}>Recent Approvals</h2>
                <PlaceholderEmpty label="Maker-Checker approvals are tenant-scoped today — there's no platform-wide approvals concept to surface here yet." />
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function PlaceholderEmpty({ label }) {
  return (
    <Tooltip label={label}>
      <p className="helptext" style={{ marginBottom: 0 }}>
        Not available yet
      </p>
    </Tooltip>
  );
}
