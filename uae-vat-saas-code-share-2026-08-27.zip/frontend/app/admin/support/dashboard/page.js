"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import PageHeader from "../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import KpiCard from "../../../../components/ui/KpiCard";
import Card from "../../../../components/ui/Card";
import Button from "../../../../components/ui/Button";

const KPI_ICONS = {
  open: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
    </svg>
  ),
  assigned: (
    <svg viewBox="0 0 24 24">
      <circle cx="9" cy="8" r="3" />
      <path d="M3.5 20c0-3.6 2.5-6 5.5-6s5.5 2.4 5.5 6" />
    </svg>
  ),
  inProgress: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
  waiting: (
    <svg viewBox="0 0 24 24">
      <rect x="3.5" y="4.5" width="17" height="16" rx="2" />
      <path d="M3.5 9.5h17" />
    </svg>
  ),
  resolved: (
    <svg viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  ),
  closed: (
    <svg viewBox="0 0 24 24">
      <rect x="4" y="8" width="16" height="13" rx="1.5" />
      <path d="M8 8V6a4 4 0 0 1 8 0v2" />
    </svg>
  ),
  critical: (
    <svg viewBox="0 0 24 24">
      <path d="M12 3.5 22 20.5H2z" />
      <path d="M12 10v4.5M12 17.5v.01" />
    </svg>
  ),
  breached: (
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9l5 5M14.5 9l-5 5" />
    </svg>
  ),
};

export default function SupportDashboardPage() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const { stats } = await api.getSupportDashboard(token);
      setStats(stats);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div>
      <PageHeader eyebrow="Support Center" title="Dashboard" description="Ticket volume and SLA health across every tenant." />
      <ErrorBanner message={error} />

      {stats === null ? (
        <LoadingSkeleton columns={4} />
      ) : (
        <>
          <div className="kpi-card-grid">
            <KpiCard label="Open" value={stats.open} icon={KPI_ICONS.open} helptext="New, unassigned tickets" />
            <KpiCard label="Assigned" value={stats.assigned} icon={KPI_ICONS.assigned} helptext="Assigned, not yet started" />
            <KpiCard label="In Progress" value={stats.inProgress} icon={KPI_ICONS.inProgress} helptext="Being worked on" />
            <KpiCard label="Waiting for Customer" value={stats.waitingCustomer} icon={KPI_ICONS.waiting} helptext="Blocked on the tenant" />
            <KpiCard label="Resolved" value={stats.resolved} icon={KPI_ICONS.resolved} helptext="Awaiting customer confirmation" />
            <KpiCard label="Closed" value={stats.closed} icon={KPI_ICONS.closed} helptext="Fully done" />
            <KpiCard label="Critical" value={stats.critical} icon={KPI_ICONS.critical} helptext="Critical priority, still open" />
            <KpiCard label="SLA Breached" value={stats.slaBreached} icon={KPI_ICONS.breached} helptext="Past their resolution deadline" />
          </div>

          <Card>
            <h2 style={{ marginBottom: 4 }}>Charts</h2>
            <p className="form-section-desc" style={{ marginBottom: 0 }}>
              Tickets by Module, Tickets by Priority, Tickets by Status, and Resolution Time charts are planned for a follow-up
              phase — you already flagged these as &ldquo;later&rdquo; in the spec.
            </p>
          </Card>

          <Card>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <h2 style={{ marginBottom: 4 }}>All Tickets</h2>
                <p className="form-section-desc" style={{ marginBottom: 0 }}>Browse, filter, and manage every ticket.</p>
              </div>
              <Link href="/admin/support/tickets">
                <Button variant="outline">View All Tickets</Button>
              </Link>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
