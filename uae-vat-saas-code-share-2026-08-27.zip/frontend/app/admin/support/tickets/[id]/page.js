"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../../lib/api";
import { adminAuth } from "../../../../../lib/auth";
import { useToast } from "../../../../../hooks/useToast";
import PageHeader from "../../../../../components/ui/PageHeader";
import ErrorBanner from "../../../../../components/ui/ErrorBanner";
import Card from "../../../../../components/ui/Card";
import Button from "../../../../../components/ui/Button";
import Select from "../../../../../components/ui/Select";
import Field from "../../../../../components/ui/Field";
import Input from "../../../../../components/ui/Input";
import Tabs from "../../../../../components/ui/Tabs";
import Modal from "../../../../../components/ui/Modal";
import PriorityBadge from "../../../../../components/support/PriorityBadge";
import TicketStatusBadge from "../../../../../components/support/TicketStatusBadge";
import ConversationThread from "../../../../../components/support/ConversationThread";
import TicketActivityTimeline from "../../../../../components/support/TicketActivityTimeline";
import FileUploader from "../../../../../components/support/FileUploader";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "conversation", label: "Conversation" },
  { key: "notes", label: "Internal Notes" },
  { key: "timeline", label: "Activity Timeline" },
  { key: "attachments", label: "Attachments" },
  { key: "audit", label: "Audit Log" },
];
const TAB_KEYS = new Set(TABS.map((t) => t.key));

const STATUSES = ["NEW", "ASSIGNED", "IN_PROGRESS", "WAITING_CUSTOMER", "RESOLVED", "CLOSED", "REOPENED"];
const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];

function formatDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString();
}

export default function AdminTicketDetailPage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { showToast } = useToast();
  const requestedTab = searchParams.get("tab");

  const [data, setData] = useState(null);
  const [ticketList, setTicketList] = useState(null);
  const [admins, setAdmins] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [activeTab, setActiveTab] = useState(TAB_KEYS.has(requestedTab) ? requestedTab : "overview");
  const [newFiles, setNewFiles] = useState([]);
  const [mergeModalOpen, setMergeModalOpen] = useState(false);
  const [mergeTarget, setMergeTarget] = useState("");
  const [linkModalOpen, setLinkModalOpen] = useState(false);
  const [linkTarget, setLinkTarget] = useState("");
  const [watcherEmail, setWatcherEmail] = useState("");

  useEffect(() => {
    load();
    loadList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const [result, { admins }] = await Promise.all([api.getAdminTicket(token, id), api.listSupportAdmins(token)]);
      setData(result);
      setAdmins(admins);
    } catch (err) {
      setError(err.message);
    }
  }

  async function loadList() {
    try {
      const token = adminAuth.get();
      const { tickets } = await api.listAllTickets(token);
      setTicketList(tickets);
    } catch {
      setTicketList([]);
    }
  }

  function handleTabChange(key) {
    setActiveTab(key);
    router.replace(`/admin/support/tickets/${id}?tab=${key}`);
  }

  async function withBusy(fn) {
    setBusy(true);
    try {
      await fn();
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleReply(body, isInternal) {
    const token = adminAuth.get();
    await withBusy(() => api.addTicketComment(token, id, { body, isInternal }));
  }

  async function handleAssign(assignedToAdminId) {
    if (!assignedToAdminId) return;
    const token = adminAuth.get();
    const transfer = !!data.ticket.assignedToAdminId;
    await withBusy(() => api.assignTicket(token, id, { assignedToAdminId, transfer }));
    showToast(transfer ? "Ticket transferred." : "Ticket assigned.");
  }

  async function handlePriorityChange(priority) {
    const token = adminAuth.get();
    await withBusy(() => api.changeTicketPriority(token, id, priority));
  }

  async function handleStatusChange(status) {
    const token = adminAuth.get();
    await withBusy(() => api.changeTicketStatus(token, id, status));
  }

  async function handleAddWatcher(e) {
    e.preventDefault();
    if (!watcherEmail.trim()) return;
    const token = adminAuth.get();
    const match = admins.find((a) => a.email.toLowerCase() === watcherEmail.trim().toLowerCase());
    await withBusy(() => api.addTicketWatcher(token, id, { watcherType: "PLATFORM_ADMIN", watcherId: match?.id || watcherEmail.trim() }));
    setWatcherEmail("");
  }

  async function handleRemoveWatcher(watcherId) {
    const token = adminAuth.get();
    await withBusy(() => api.removeTicketWatcher(token, id, watcherId));
  }

  async function handleMerge(e) {
    e.preventDefault();
    if (!mergeTarget) return;
    const token = adminAuth.get();
    await withBusy(() => api.mergeTicket(token, id, mergeTarget));
    setMergeModalOpen(false);
    setMergeTarget("");
    showToast("Ticket merged.");
  }

  async function handleLink(e) {
    e.preventDefault();
    if (!linkTarget) return;
    const token = adminAuth.get();
    await withBusy(() => api.linkTicket(token, id, linkTarget));
    setLinkModalOpen(false);
    setLinkTarget("");
    showToast("Tickets linked.");
  }

  async function handleUploadFiles() {
    if (newFiles.length === 0) return;
    const token = adminAuth.get();
    setBusy(true);
    try {
      for (const file of newFiles) {
        await api.addAdminTicketAttachment(token, id, file, { isScreenshot: file.type?.startsWith("image/") });
      }
      setNewFiles([]);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setBusy(false);
    }
  }

  const otherTickets = useMemo(() => (ticketList || []).filter((t) => t.id !== id), [ticketList, id]);

  if (error && !data) {
    return (
      <div>
        <PageHeader title="Ticket" />
        <ErrorBanner message={error} />
      </div>
    );
  }

  if (!data) return <p>Loading…</p>;

  const { ticket, raisedBy, assignedToAdmin, comments, attachments, activities, watchers } = data;
  const publicComments = comments.filter((c) => !c.isInternal);
  const internalComments = comments.filter((c) => c.isInternal);

  return (
    <div>
      <PageHeader
        eyebrow="Support Center"
        title={ticket.ticketNumber}
        description={ticket.subject}
        action={
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <PriorityBadge priority={ticket.priority} />
            <TicketStatusBadge status={ticket.status} />
          </div>
        }
      />
      <ErrorBanner message={error} />

      <div className="workspace-layout">
        <div className="workspace-list card">
          <h3 style={{ margin: "0 0 8px", fontSize: 13, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--color-ink-faint)" }}>Ticket List</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {(ticketList || []).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => router.push(`/admin/support/tickets/${t.id}`)}
                className={`btn-outline`}
                style={{
                  textAlign: "left",
                  border: "none",
                  background: t.id === id ? "var(--color-accent-soft)" : "transparent",
                  borderRadius: "var(--radius)",
                  padding: "8px 10px",
                  cursor: "pointer",
                  fontSize: 12.5,
                }}
              >
                <div className="mono" style={{ fontWeight: 600 }}>{t.ticketNumber}</div>
                <div style={{ color: "var(--color-ink-soft)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.subject}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="workspace-main">
          <Tabs tabs={TABS} activeKey={activeTab} onChange={handleTabChange} />

          <div role="tabpanel">
            {activeTab === "overview" && (
              <Card>
                <h2 style={{ marginBottom: 4 }}>Overview</h2>
                <div className="review-list" style={{ marginTop: 12 }}>
                  <div className="review-row"><span className="review-label">Module</span><span className="review-value">{ticket.module || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Feature</span><span className="review-value">{ticket.feature || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Category</span><span className="review-value">{ticket.category?.name || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Description</span><span className="review-value" style={{ whiteSpace: "pre-wrap" }}>{ticket.description}</span></div>
                </div>
                <h2 style={{ margin: "20px 0 4px" }}>Automatically Captured</h2>
                <div className="review-list">
                  <div className="review-row"><span className="review-label">Page URL</span><span className="review-value mono" style={{ fontSize: 12, wordBreak: "break-all" }}>{ticket.currentUrl || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Browser</span><span className="review-value" style={{ fontSize: 12 }}>{ticket.browserInfo || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Device</span><span className="review-value">{ticket.deviceInfo || "—"}</span></div>
                  <div className="review-row"><span className="review-label">Screen Resolution</span><span className="review-value">{ticket.screenResolution || "—"}</span></div>
                  <div className="review-row"><span className="review-label">App Version</span><span className="review-value">{ticket.appVersion || "—"}</span></div>
                </div>
              </Card>
            )}

            {activeTab === "conversation" && (
              <Card>
                <h2 style={{ marginBottom: 12 }}>Conversation</h2>
                <ConversationThread
                  comments={publicComments}
                  currentUserType="PLATFORM_ADMIN"
                  onSubmitReply={(body) => handleReply(body, false)}
                  allowInternalNote={false}
                  busy={busy}
                  authorLabel={(type) => (type === "PLATFORM_ADMIN" ? "Support Team" : raisedBy?.name || "Customer")}
                  emptyLabel="No replies yet."
                />
              </Card>
            )}

            {activeTab === "notes" && (
              <Card>
                <h2 style={{ marginBottom: 4 }}>Internal Notes</h2>
                <p className="form-section-desc">Visible only to the support team — the customer never sees this tab.</p>
                <ConversationThread
                  comments={internalComments}
                  currentUserType="PLATFORM_ADMIN"
                  onSubmitReply={(body) => handleReply(body, true)}
                  allowInternalNote={false}
                  busy={busy}
                  authorLabel={() => "Support Team"}
                  emptyLabel="No internal notes yet."
                />
              </Card>
            )}

            {activeTab === "timeline" && (
              <Card>
                <h2 style={{ marginBottom: 12 }}>Activity Timeline</h2>
                <TicketActivityTimeline activities={activities} />
              </Card>
            )}

            {activeTab === "attachments" && (
              <Card>
                <h2 style={{ marginBottom: 4 }}>Attachments</h2>
                {attachments.length === 0 ? (
                  <p className="helptext">No attachments yet.</p>
                ) : (
                  <ul style={{ listStyle: "none", margin: "12px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
                    {attachments.map((a) => (
                      <li key={a.id}>
                        <a
                          href={`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000"}${a.fileUrl}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "var(--color-surface-sunken)", borderRadius: "var(--radius)", textDecoration: "none", color: "inherit" }}
                        >
                          <span>{a.isScreenshot ? "🖼️" : "📎"}</span>
                          <span style={{ flex: 1 }}>{a.fileName}</span>
                          <span className="helptext" style={{ margin: 0 }}>{formatDateTime(a.createdAt)}</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                )}
                <h2 style={{ margin: "20px 0 4px" }}>Add More</h2>
                <FileUploader onFilesSelected={setNewFiles} multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt" />
                <Button onClick={handleUploadFiles} disabled={busy || newFiles.length === 0} style={{ marginTop: 12 }}>
                  {busy ? "Uploading…" : "Upload"}
                </Button>
              </Card>
            )}

            {activeTab === "audit" && (
              <Card>
                <h2 style={{ marginBottom: 4 }}>Audit Log</h2>
                <p className="form-section-desc">Every action taken on this ticket — same event stream as Activity Timeline, framed for compliance review.</p>
                <TicketActivityTimeline activities={activities} />
              </Card>
            )}
          </div>
        </div>

        <div className="workspace-rail">
          <Card>
            <h3 style={{ marginBottom: 12, fontSize: 14 }}>Properties</h3>
            <div className="form-grid" style={{ marginBottom: 0 }}>
              <Field id="priority-select" label="Priority" style={{ marginBottom: 8 }}>
                <Select value={ticket.priority} onChange={(e) => handlePriorityChange(e.target.value)} disabled={busy}>
                  {PRIORITIES.map((p) => (
                    <option key={p} value={p}>{p.charAt(0) + p.slice(1).toLowerCase()}</option>
                  ))}
                </Select>
              </Field>
              <Field id="status-select" label="Status" style={{ marginBottom: 0 }}>
                <Select value={ticket.status} onChange={(e) => handleStatusChange(e.target.value)} disabled={busy}>
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>{s.replace(/_/g, " ")}</option>
                  ))}
                </Select>
              </Field>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginBottom: 12, fontSize: 14 }}>Customer</h3>
            <div className="review-list" style={{ marginBottom: 0 }}>
              <div className="review-row"><span className="review-label">Tenant</span><span className="review-value">{ticket.tenant?.name || "—"}</span></div>
              <div className="review-row"><span className="review-label">Plan</span><span className="review-value">{ticket.tenant?.plan || "—"}</span></div>
              <div className="review-row"><span className="review-label">Raised By</span><span className="review-value">{raisedBy?.name || "—"}</span></div>
              <div className="review-row"><span className="review-label">Email</span><span className="review-value" style={{ fontSize: 12 }}>{raisedBy?.email || "—"}</span></div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginBottom: 12, fontSize: 14 }}>Assignment</h3>
            <Field id="assign-select" label={ticket.assignedToAdminId ? "Transfer to" : "Assign to"} style={{ marginBottom: 0 }}>
              <Select value={ticket.assignedToAdminId || ""} onChange={(e) => handleAssign(e.target.value)} disabled={busy}>
                <option value="">Unassigned</option>
                {admins.map((a) => (
                  <option key={a.id} value={a.id}>{a.email}</option>
                ))}
              </Select>
            </Field>
            {assignedToAdmin && <p className="helptext" style={{ marginTop: 8 }}>Currently: {assignedToAdmin.email}</p>}
          </Card>

          <Card>
            <h3 style={{ marginBottom: 12, fontSize: 14 }}>SLA</h3>
            <div className="review-list" style={{ marginBottom: 0 }}>
              <div className="review-row"><span className="review-label">Response Due</span><span className="review-value" style={{ fontSize: 12 }}>{formatDateTime(ticket.slaResponseDueAt)}</span></div>
              <div className="review-row"><span className="review-label">Resolution Due</span><span className="review-value" style={{ fontSize: 12 }}>{formatDateTime(ticket.slaResolutionDueAt)}</span></div>
              <div className="review-row">
                <span className="review-label">Status</span>
                <span className={`badge ${ticket.slaStatus === "BREACHED" ? "badge-danger" : ticket.slaStatus === "ON_TRACK" ? "badge-success" : "badge-info"}`}>
                  {ticket.slaStatus === "BREACHED" ? "Breached" : ticket.slaStatus === "ON_TRACK" ? "On Track" : ticket.slaStatus === "MET" ? "Met" : "—"}
                </span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginBottom: 8, fontSize: 14 }}>Watchers</h3>
            {watchers.length === 0 ? (
              <p className="helptext" style={{ marginBottom: 8 }}>No watchers yet.</p>
            ) : (
              <ul style={{ listStyle: "none", margin: "0 0 8px", padding: 0, display: "flex", flexDirection: "column", gap: 4 }}>
                {watchers.map((w) => (
                  <li key={w.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5 }}>
                    <span>{admins.find((a) => a.id === w.watcherId)?.email || w.watcherId}</span>
                    <button type="button" className="btn btn-outline btn-sm" onClick={() => handleRemoveWatcher(w.id)}>Remove</button>
                  </li>
                ))}
              </ul>
            )}
            <form onSubmit={handleAddWatcher} style={{ display: "flex", gap: 6 }}>
              <Input value={watcherEmail} onChange={(e) => setWatcherEmail(e.target.value)} placeholder="admin@platform.local" style={{ flex: 1 }} />
              <Button type="submit" variant="outline" disabled={busy}>Add</Button>
            </form>
          </Card>

          <Card>
            <h3 style={{ marginBottom: 8, fontSize: 14 }}>Tags</h3>
            {ticket.tags.length === 0 ? <p className="helptext">No tags.</p> : (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {ticket.tags.map((tag) => (
                  <span key={tag} className="badge badge-info">{tag}</span>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <h3 style={{ marginBottom: 12, fontSize: 14 }}>Related</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <Button variant="outline" onClick={() => setMergeModalOpen(true)} disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
                Merge Ticket
              </Button>
              <Button variant="outline" onClick={() => setLinkModalOpen(true)} disabled={busy} style={{ width: "100%", justifyContent: "center" }}>
                Link Ticket
              </Button>
              {ticket.linkedTicketIds.length > 0 && (
                <div className="helptext">Linked: {ticket.linkedTicketIds.length} ticket(s)</div>
              )}
            </div>
          </Card>
        </div>
      </div>

      <Modal open={mergeModalOpen} onClose={() => setMergeModalOpen(false)} ariaLabel="Merge ticket">
        <form onSubmit={handleMerge}>
          <h2 style={{ marginBottom: 4 }}>Merge into another ticket</h2>
          <p className="form-section-desc">This ticket will be closed and marked as merged.</p>
          <Field id="merge-target" label="Merge into" style={{ marginBottom: 0 }}>
            <Select required value={mergeTarget} onChange={(e) => setMergeTarget(e.target.value)}>
              <option value="">Select a ticket</option>
              {otherTickets.map((t) => (
                <option key={t.id} value={t.id}>{t.ticketNumber} — {t.subject}</option>
              ))}
            </Select>
          </Field>
          <div className="wizard-actions">
            <Button type="button" variant="outline" onClick={() => setMergeModalOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={busy}>Merge</Button>
          </div>
        </form>
      </Modal>

      <Modal open={linkModalOpen} onClose={() => setLinkModalOpen(false)} ariaLabel="Link ticket">
        <form onSubmit={handleLink}>
          <h2 style={{ marginBottom: 4 }}>Link a related ticket</h2>
          <Field id="link-target" label="Link to" style={{ marginBottom: 0 }}>
            <Select required value={linkTarget} onChange={(e) => setLinkTarget(e.target.value)}>
              <option value="">Select a ticket</option>
              {otherTickets.map((t) => (
                <option key={t.id} value={t.id}>{t.ticketNumber} — {t.subject}</option>
              ))}
            </Select>
          </Field>
          <div className="wizard-actions">
            <Button type="button" variant="outline" onClick={() => setLinkModalOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={busy}>Link</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
