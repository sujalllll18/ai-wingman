"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "../../../../lib/api";
import { adminAuth } from "../../../../lib/auth";
import { useLocalStorageState } from "../../../../hooks/useLocalStorageState";
import PageHeader from "../../../../components/ui/PageHeader";
import EmptyState from "../../../../components/ui/EmptyState";
import ErrorBanner from "../../../../components/ui/ErrorBanner";
import LoadingSkeleton from "../../../../components/ui/LoadingSkeleton";
import DataTable from "../../../../components/ui/DataTable";
import TableScroll from "../../../../components/ui/TableScroll";
import ColumnSelector from "../../../../components/ui/ColumnSelector";
import Toolbar from "../../../../components/ui/Toolbar";
import ActionMenu from "../../../../components/ui/ActionMenu";
import Pagination from "../../../../components/ui/Pagination";
import PriorityBadge from "../../../../components/support/PriorityBadge";
import TicketStatusBadge from "../../../../components/support/TicketStatusBadge";
import Tooltip from "../../../../components/ui/Tooltip";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

const MODULES = ["Dashboard", "Business Profile", "Team", "Customers", "Products & Services", "Tax Master", "Invoices", "Purchases", "VAT Returns", "Approvals", "Other"];

const SLA_LABEL = {
  ON_TRACK: { label: "On Track", className: "badge-success" },
  BREACHED: { label: "Breached", className: "badge-danger" },
  MET: { label: "Met", className: "badge-info" },
  NONE: { label: "—", className: "badge-info" },
};

export default function AllTicketsPage() {
  const router = useRouter();

  const [tickets, setTickets] = useState(null);
  const [tenants, setTenants] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [tenantFilter, setTenantFilter] = useState("ALL");
  const [planFilter, setPlanFilter] = useState("ALL");
  const [moduleFilter, setModuleFilter] = useState("ALL");
  const [priorityFilter, setPriorityFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [assignedFilter, setAssignedFilter] = useState("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setError("");
    try {
      const token = adminAuth.get();
      const [{ tickets }, { tenants }, { admins }] = await Promise.all([api.listAllTickets(token), api.listTenants(token), api.listSupportAdmins(token)]);
      setTickets(tickets);
      setTenants(tenants);
      setAdmins(admins);
    } catch (err) {
      setError(err.message);
    }
  }

  function resetToPageOne() {
    setPage(1);
  }

  const COLUMN_DEFS = useMemo(
    () => [
      { key: "ticketNumber", label: "Ticket ID", alwaysVisible: true, sortable: true, render: (t) => <span className="mono" style={{ fontWeight: 600 }}>{t.ticketNumber}</span> },
      { key: "tenant", label: "Tenant", render: (t) => t.tenant?.name || "—" },
      { key: "subject", label: "Subject", alwaysVisible: true, render: (t) => t.subject },
      { key: "module", label: "Module", render: (t) => t.module || "—" },
      { key: "raisedBy", label: "Raised By", render: (t) => t.raisedBy?.name || <Tooltip label="Not returned by this list"><span style={{ color: "var(--color-ink-faint)" }}>—</span></Tooltip> },
      { key: "assignedTo", label: "Assigned To", render: (t) => t.assignedToAdmin?.email || <span style={{ color: "var(--color-ink-faint)" }}>Unassigned</span> },
      { key: "priority", label: "Priority", render: (t) => <PriorityBadge priority={t.priority} /> },
      { key: "status", label: "Status", render: (t) => <TicketStatusBadge status={t.status} /> },
      { key: "sla", label: "SLA", render: (t) => { const s = SLA_LABEL[t.slaStatus] || SLA_LABEL.NONE; return <span className={`badge ${s.className}`}>{s.label}</span>; } },
      { key: "createdAt", label: "Created On", sortable: true, render: (t) => formatDate(t.createdAt) },
      { key: "updatedAt", label: "Last Updated", render: (t) => formatDate(t.updatedAt) },
      {
        key: "actions",
        label: "",
        alwaysVisible: true,
        render: (t) => (
          <ActionMenu
            ariaLabel={`Actions for ${t.ticketNumber}`}
            items={[{ label: "Open", onClick: () => router.push(`/admin/support/tickets/${t.id}`) }]}
          />
        ),
      },
    ],
    [router]
  );

  const DEFAULT_ORDER = useMemo(() => COLUMN_DEFS.map((c) => c.key), [COLUMN_DEFS]);
  const [columnOrderRaw, setColumnOrder] = useLocalStorageState("ledger_admin_ticket_list_column_order", DEFAULT_ORDER);
  const [hiddenColumns, setHiddenColumns] = useLocalStorageState("ledger_admin_ticket_list_hidden_columns", []);
  const columnOrder = columnOrderRaw.length === DEFAULT_ORDER.length && DEFAULT_ORDER.every((k) => columnOrderRaw.includes(k)) ? columnOrderRaw : DEFAULT_ORDER;

  function handleToggleColumn(key) {
    setHiddenColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  const filtered = useMemo(() => {
    if (!tickets) return [];
    const q = search.trim().toLowerCase();
    return tickets.filter((t) => {
      const matchesSearch = !q || t.subject.toLowerCase().includes(q) || t.ticketNumber.toLowerCase().includes(q) || (t.tenant?.name || "").toLowerCase().includes(q);
      const matchesTenant = tenantFilter === "ALL" || t.tenantId === tenantFilter;
      const matchesPlan = planFilter === "ALL" || t.tenant?.plan === planFilter;
      const matchesModule = moduleFilter === "ALL" || t.module === moduleFilter;
      const matchesPriority = priorityFilter === "ALL" || t.priority === priorityFilter;
      const matchesStatus = statusFilter === "ALL" || t.status === statusFilter;
      const matchesAssigned = assignedFilter === "ALL" || t.assignedToAdminId === assignedFilter || (assignedFilter === "UNASSIGNED" && !t.assignedToAdminId);
      const createdTime = new Date(t.createdAt).getTime();
      const matchesFrom = !dateFrom || createdTime >= new Date(dateFrom).getTime();
      const matchesTo = !dateTo || createdTime <= new Date(dateTo).getTime() + 86399999;
      return matchesSearch && matchesTenant && matchesPlan && matchesModule && matchesPriority && matchesStatus && matchesAssigned && matchesFrom && matchesTo;
    });
  }, [tickets, search, tenantFilter, planFilter, moduleFilter, priorityFilter, statusFilter, assignedFilter, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageStart = (currentPage - 1) * pageSize;
  const pageItems = filtered.slice(pageStart, pageStart + pageSize);

  return (
    <div>
      <PageHeader eyebrow="Support Center" title="All Tickets" description="Every ticket raised across every tenant." />
      <ErrorBanner message={error} />

      <div className="card" style={{ padding: 0 }}>
        {tickets === null ? (
          <div style={{ padding: 20 }}>
            <LoadingSkeleton columns={8} />
          </div>
        ) : tickets.length === 0 ? (
          <EmptyState title="No tickets yet" description="Tickets raised by tenants will show up here." />
        ) : (
          <>
            <div className="list-toolbar">
              <Toolbar
                searchValue={search}
                onSearchChange={(e) => {
                  setSearch(e.target.value);
                  resetToPageOne();
                }}
                searchPlaceholder="Search by ticket #, subject, or tenant…"
                filters={
                  <>
                    <select className="select-filter" value={tenantFilter} onChange={(e) => { setTenantFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">All tenants</option>
                      {tenants.map((t) => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                    <select className="select-filter" value={planFilter} onChange={(e) => { setPlanFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">All plans</option>
                      <option value="TRIAL">Trial</option>
                      <option value="STANDARD">Standard</option>
                      <option value="PREMIUM">Premium</option>
                    </select>
                    <select className="select-filter" value={moduleFilter} onChange={(e) => { setModuleFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">All modules</option>
                      {MODULES.map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                    <select className="select-filter" value={priorityFilter} onChange={(e) => { setPriorityFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">All priorities</option>
                      <option value="LOW">Low</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="HIGH">High</option>
                      <option value="CRITICAL">Critical</option>
                    </select>
                    <select className="select-filter" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">All statuses</option>
                      <option value="NEW">New</option>
                      <option value="ASSIGNED">Assigned</option>
                      <option value="IN_PROGRESS">In Progress</option>
                      <option value="WAITING_CUSTOMER">Waiting for Customer</option>
                      <option value="RESOLVED">Resolved</option>
                      <option value="CLOSED">Closed</option>
                      <option value="REOPENED">Reopened</option>
                    </select>
                    <select className="select-filter" value={assignedFilter} onChange={(e) => { setAssignedFilter(e.target.value); resetToPageOne(); }}>
                      <option value="ALL">Anyone assigned</option>
                      <option value="UNASSIGNED">Unassigned</option>
                      {admins.map((a) => (
                        <option key={a.id} value={a.id}>{a.email}</option>
                      ))}
                    </select>
                    <input type="date" className="select-filter" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); resetToPageOne(); }} aria-label="Created from" />
                    <input type="date" className="select-filter" value={dateTo} onChange={(e) => { setDateTo(e.target.value); resetToPageOne(); }} aria-label="Created to" />
                    <ColumnSelector columns={COLUMN_DEFS} columnOrder={columnOrder} hiddenColumns={hiddenColumns} onToggle={handleToggleColumn} onReorder={setColumnOrder} />
                  </>
                }
              />
            </div>

            {filtered.length === 0 ? (
              <EmptyState title="No matching tickets" description="Try a different search term or clear the filters." />
            ) : (
              <>
                <TableScroll>
                  <DataTable columns={COLUMN_DEFS} rows={pageItems} columnOrder={columnOrder} hiddenColumns={hiddenColumns} stickyHeader zebra />
                </TableScroll>
                <Pagination
                  page={currentPage}
                  pageSize={pageSize}
                  totalItems={filtered.length}
                  onPageChange={setPage}
                  onPageSizeChange={(n) => { setPageSize(n); resetToPageOne(); }}
                  itemLabel="tickets"
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
