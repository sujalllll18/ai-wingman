"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { tenantAuth, adminAuth } from "../lib/auth";
import EmptyState from "../components/ui/EmptyState";
import Button from "../components/ui/Button";

// App-wide error boundary (2026-08-11 route audit) - Next.js renders this in
// place of any page.js under app/ that throws during render, anywhere in the
// tree (tenant, admin, or top-level). There was previously no error.js at
// all, so an uncaught exception (e.g. the admin plan-detail null-deref risk
// on a malformed `versions: []` response noted during the audit) fell
// through to Next's raw default error overlay instead of the app's own look.
// Deliberately does NOT display `error.message` to the user (unlike
// ErrorBanner elsewhere, which shows backend-authored messages meant to be
// read) - this catches unexpected *render* exceptions, not handled API
// errors, so the message is developer-facing, not something to show as if
// it were a real explanation. Logged to the console instead, same as
// Next.js's own default behavior.
export default function GlobalErrorBoundary({ error, reset }) {
  const [home, setHome] = useState({ href: "/login", label: "Go to Login" });

  useEffect(() => {
    console.error(error);
    if (tenantAuth.get()) setHome({ href: "/tenant/dashboard", label: "Go to Dashboard" });
    else if (adminAuth.get()) setHome({ href: "/admin/dashboard", label: "Go to Dashboard" });
  }, [error]);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ maxWidth: 420, width: "100%" }}>
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 8v5M12 16v.01" />
            </svg>
          }
          title="Something went wrong"
          description="An unexpected error occurred. You can try again, or head back to a working page."
          action={
            <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
              <Button variant="outline" onClick={() => reset()}>
                Try again
              </Button>
              <Link href={home.href}>
                <Button>{home.label}</Button>
              </Link>
            </div>
          }
        />
      </div>
    </div>
  );
}
