"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { tenantAuth, adminAuth } from "../lib/auth";
import EmptyState from "../components/ui/EmptyState";
import Button from "../components/ui/Button";

// App-wide 404 (2026-08-11 route audit) - Next.js's App Router renders this
// for any path with no matching page.js, anywhere in the app (tenant, admin,
// or top-level). There was previously no not-found.js at all, so an
// unmatched URL fell through to Next's unstyled default 404. Session lookup
// is client-side only (same localStorage/sessionStorage read every other
// auth-aware page already uses via lib/auth.js) so the "go back" link can
// point somewhere useful instead of a dead end.
export default function NotFound() {
  const [home, setHome] = useState({ href: "/login", label: "Go to Login" });

  useEffect(() => {
    if (tenantAuth.get()) setHome({ href: "/tenant/dashboard", label: "Go to Dashboard" });
    else if (adminAuth.get()) setHome({ href: "/admin/dashboard", label: "Go to Dashboard" });
  }, []);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ maxWidth: 420, width: "100%" }}>
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="9" />
              <path d="M9.5 9.5l5 5M14.5 9.5l-5 5" />
            </svg>
          }
          title="Page not found"
          description="The page you're looking for doesn't exist or may have been moved."
          action={
            <Link href={home.href}>
              <Button>{home.label}</Button>
            </Link>
          }
        />
      </div>
    </div>
  );
}
