import { Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import ToastProvider from "../components/ui/ToastProvider";

const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body-loaded",
});

const mono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono-loaded",
});

export const metadata = {
  title: "Ledger — UAE VAT Invoice & Management",
  description: "Multi-tenant UAE VAT invoicing and compliance platform.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${body.variable} ${mono.variable}`}>
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
