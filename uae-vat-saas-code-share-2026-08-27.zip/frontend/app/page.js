import LoginScreen from "../components/auth/LoginScreen";

// The old marketing-style landing page ("Home Page -> click through -> Login
// Page") was removed 2026-08-06 - it asked users to sign in twice for no
// reason. "/" now renders the same LoginScreen as "/login" directly, so
// there is exactly one authentication screen in the app.
export default function HomePage() {
  return <LoginScreen />;
}
