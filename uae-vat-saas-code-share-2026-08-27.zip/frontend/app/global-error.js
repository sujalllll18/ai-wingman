"use client";

// Last-resort error boundary (2026-08-11 route audit) - only fires if
// app/layout.js itself throws (app/error.js can't catch that, since it
// renders *inside* the root layout). Must render its own <html>/<body> since
// it fully replaces the root layout, and deliberately avoids importing any
// shared component/CSS - the whole point is to still render something if
// the rest of the app's own code is what's broken.
export default function GlobalError({ reset }) {
  return (
    <html lang="en">
      <body>
        <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "system-ui, sans-serif" }}>
          <div style={{ maxWidth: 420, textAlign: "center" }}>
            <h1 style={{ fontSize: 18, marginBottom: 8 }}>Something went wrong</h1>
            <p style={{ fontSize: 14, color: "#666", marginBottom: 20 }}>
              An unexpected error occurred. Please try again.
            </p>
            <button
              type="button"
              onClick={() => reset()}
              style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid #ccc", background: "#fff", cursor: "pointer" }}
            >
              Try again
            </button>
          </div>
        </div>
      </body>
    </html>
  );
}
