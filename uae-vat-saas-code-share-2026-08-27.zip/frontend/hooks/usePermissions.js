"use client";

import { useContext } from "react";
import { PermissionsContext } from "../components/rbac/PermissionsProvider";

export function usePermissions() {
  const context = useContext(PermissionsContext);
  if (!context) {
    throw new Error("usePermissions must be used within a PermissionsProvider");
  }
  return context; // { permissions, role, loading, error, can(key), refresh(), isPreviewing, previewLabel, startPreview(keys, label), exitPreview() }
}
