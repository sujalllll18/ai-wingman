"use client";

import { useContext } from "react";
import { BrandingContext } from "../components/tenant-profile/BrandingProvider";

export function useBranding() {
  const context = useContext(BrandingContext);
  if (!context) {
    throw new Error("useBranding must be used within a BrandingProvider");
  }
  return context; // { name, logoUrl, loading, refresh() }
}
