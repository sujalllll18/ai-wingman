"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { usePermissions } from "./usePermissions";

// Route-level guard (RBAC module Phase 6, 2026-08-06) - redirects away from
// a page the current identity (or an active Role Preview) can't view.
// Mirrors the same "no token -> redirect" useEffect shape tenant/layout.js
// already uses for authentication - this is the same idea one layer further
// in, for authorization. Waits for `loading` to resolve before deciding, so
// it never redirects during the brief permission-fetch window on page load.
export function useRequirePermission(key) {
  const { can, loading } = usePermissions();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!can(key)) router.replace("/tenant/dashboard");
  }, [loading, can, key, router]);

  return { allowed: !loading && can(key), loading };
}
