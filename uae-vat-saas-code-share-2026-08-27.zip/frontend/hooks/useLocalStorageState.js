"use client";

import { useEffect, useState } from "react";

// Generic useState synced to localStorage. Starts at `initial` on every
// render (server and first client render match, avoiding a hydration
// mismatch), then syncs from any stored value once mounted.
export function useLocalStorageState(key, initial) {
  const [value, setValue] = useState(initial);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(key);
      if (stored !== null) setValue(JSON.parse(stored));
    } catch {
      // ignore malformed/unavailable storage
    }
    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // ignore quota/unavailable storage
    }
  }, [key, value, hydrated]);

  return [value, setValue];
}
