# Ledger — Frontend (Module 0)

Next.js 14 (App Router) client for the Platform Admin console and the Tenant
portal. Talks to the Module 0 Express API you already have running.

## Setup

```bash
cd frontend
npm install
cp .env.local.example .env.local   # point NEXT_PUBLIC_API_URL at your backend
npm run dev                        # http://localhost:3000
```

Make sure the backend is running (default `http://localhost:4000`) and that
its CORS is enabled (it already is, via `cors()` in `src/app.js`).

## Routes

| Route                     | Who              | Purpose |
|----------------------------|------------------|---------|
| `/`                         | anyone           | Choose Platform Admin or Tenant sign-in |
| `/admin/login`              | Platform Admin   | Sign in |
| `/admin/dashboard`          | Platform Admin   | All Tenants: plan, status, user/invoice counts |
| `/admin/tenants/new`        | Platform Admin   | Onboard a Tenant + its mandatory Owner |
| `/admin/tenants/[id]`       | Platform Admin   | Usage, change plan, suspend/reactivate, add Staff |
| `/tenant/login`             | Tenant Owner/Staff | Sign in |
| `/tenant/team`              | Tenant Owner/Staff | View-only team list |

## How auth is handled

Two completely separate sessions, mirroring the backend's two JWT identity
spaces:

- **Platform Admin** token → `localStorage` key `uaevat_admin_token`
- **Tenant user** token + `{ user, tenant }` → `uaevat_tenant_token` /
  `uaevat_tenant_session`

Each section (`app/admin/layout.js`, `app/tenant/layout.js`) is a client
component that checks for its own token on mount and redirects to its own
login page if missing — so an admin session can never leak into the tenant
portal or vice versa, matching the backend's separation.

Since this is a real app running in your own browser (not a Claude
artifact), `localStorage` is fine here — the artifact sandbox restriction on
browser storage doesn't apply to a standalone Next.js project.

## Design notes

This is compliance software for business owners, not a marketing site, so
the direction is a **working ledger**: paper-white background, ink-navy
text, a muted ledger-green for primary actions, hairline rules on tables.
Type roles: Source Serif 4 for headings (the "official document" feel),
Inter for body copy, IBM Plex Mono for anything numeric — invoice counts,
TRNs, timestamps — set with tabular figures so columns of numbers actually
line up.

The one deliberate signature element is the **status stamp**: a Tenant's
ACTIVE/SUSPENDED state is rendered as a rotated, double-ringed ink stamp,
because that's an official determination, not just a UI state. Plan tier,
by contrast, is a flat rectangular tag — it's just a product label, so it
doesn't earn the same visual weight. The distinction is intentional, not
decorative.

## What's next

This only covers Module 0. As you build Module 1 (Business Profile,
Customers, Materials, VAT rate setting) on the backend, the natural next
frontend piece is a Tenant-side settings area under `/tenant/*` — happy to
build that next.
