import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { createEmptyProfile, type UserProfile } from '../types/profile'
import type {
  ConversationStage,
  DatePlan,
  DatePlanResponse,
  IntroStage,
  IntroState,
  ScheduledSlot,
} from '../types/journey'
import { MOCK_PEOPLE } from '../data/mockPeople'
import { SCREENS, type ScreenId } from './flow'

const HOUR = 60 * 60 * 1000

function initIntroStates(): Record<string, IntroState> {
  const now = Date.now()
  const states: Record<string, IntroState> = {}
  MOCK_PEOPLE.forEach((person, i) => {
    states[person.id] = {
      personId: person.id,
      stage: 'new',
      // First is unlocked immediately; the rest release one per hour —
      // the scarcity rule. (Screens also offer a "preview: unlock now"
      // shortcut so a reviewer isn't stuck actually waiting.)
      unlockAtMs: i === 0 ? now : now + i * HOUR,
    }
  })
  return states
}

interface OnboardingContextValue {
  profile: UserProfile
  updateProfile: (patch: Partial<UserProfile>) => void
  screen: ScreenId
  history: ScreenId[]
  goTo: (screen: ScreenId) => void
  goNext: () => void
  goBack: () => void
  canGoBack: boolean

  selectedPersonId: string | null
  setSelectedPersonId: (id: string | null) => void
  scheduledSlot: ScheduledSlot | null
  setScheduledSlot: (slot: ScheduledSlot | null) => void
  conversationStage: ConversationStage
  setConversationStage: (stage: ConversationStage) => void

  introStates: Record<string, IntroState>
  setIntroStage: (personId: string, stage: IntroStage) => void
  unlockIntroNow: (personId: string) => void

  datePlan: DatePlan | null
  setDatePlan: (plan: DatePlan | null) => void
  datePlanResponse: DatePlanResponse
  setDatePlanResponse: (r: DatePlanResponse) => void
}

const OnboardingContext = createContext<OnboardingContextValue | null>(null)

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile>(createEmptyProfile)
  const [history, setHistory] = useState<ScreenId[]>(['welcome'])
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null)
  const [scheduledSlot, setScheduledSlot] = useState<ScheduledSlot | null>(null)
  const [conversationStage, setConversationStage] = useState<ConversationStage>('first')
  const [introStates, setIntroStates] = useState<Record<string, IntroState>>(initIntroStates)
  const [datePlan, setDatePlan] = useState<DatePlan | null>(null)
  const [datePlanResponse, setDatePlanResponse] = useState<DatePlanResponse>(null)

  const screen = history[history.length - 1]

  const updateProfile = useCallback((patch: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...patch }))
  }, [])

  const goTo = useCallback((next: ScreenId) => {
    setHistory((prev) => [...prev, next])
  }, [])

  const goNext = useCallback(() => {
    setHistory((prev) => {
      const currentIndex = SCREENS.indexOf(prev[prev.length - 1])
      const next = SCREENS[currentIndex + 1]
      if (!next) return prev
      return [...prev, next]
    })
  }, [])

  const goBack = useCallback(() => {
    setHistory((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev))
  }, [])

  const setIntroStage = useCallback((personId: string, stage: IntroStage) => {
    setIntroStates((prev) => ({ ...prev, [personId]: { ...prev[personId], stage } }))
  }, [])

  const unlockIntroNow = useCallback((personId: string) => {
    setIntroStates((prev) => ({ ...prev, [personId]: { ...prev[personId], unlockAtMs: Date.now() } }))
  }, [])

  const value = useMemo(
    () => ({
      profile,
      updateProfile,
      screen,
      history,
      goTo,
      goNext,
      goBack,
      canGoBack: history.length > 1,
      selectedPersonId,
      setSelectedPersonId,
      scheduledSlot,
      setScheduledSlot,
      conversationStage,
      setConversationStage,
      introStates,
      setIntroStage,
      unlockIntroNow,
      datePlan,
      setDatePlan,
      datePlanResponse,
      setDatePlanResponse,
    }),
    [
      profile,
      updateProfile,
      screen,
      history,
      goTo,
      goNext,
      goBack,
      selectedPersonId,
      scheduledSlot,
      conversationStage,
      introStates,
      setIntroStage,
      unlockIntroNow,
      datePlan,
      datePlanResponse,
    ],
  )

  return <OnboardingContext.Provider value={value}>{children}</OnboardingContext.Provider>
}

export function useOnboarding() {
  const ctx = useContext(OnboardingContext)
  if (!ctx) throw new Error('useOnboarding must be used within OnboardingProvider')
  return ctx
}
