// Ordered list of every screen in the app. Kept separate from components so
// navigation (back/next) has one source of truth instead of being scattered
// across screens. Most transitions use explicit goTo() rather than relying
// on this order — the order mainly matters as a sane goNext() fallback and
// for the back-stack.

export const SCREENS = [
  'welcome',
  'signup',
  'phone',
  'otp',

  'wingmanIntro',

  // Vibe Profile (25 / 50 / 75 / 100)
  'vibeLevel1',
  'vibeLevel2',
  'yourStory',
  'compatibilityIntro',
  'compatibility',
  'wingmanAnalyzing',
  'profileReady',
  'verification',

  // Tab roots (bottom nav)
  'home',
  'explore',
  'connections',
  'profile',

  // Introduction -> conversation ladder
  'matchExplanation',
  'scheduling',
  'upcomingConversation',
  'chatRoom',
  'decision',
  'talkOnceMore',

  // Video call (scheduling reuses 'scheduling' with conversationStage='video')
  'videoCall',

  // Connection
  'connectionRequest',
  'connectionEstablished',
  'unlimitedChat',

  // Date planning
  'datePlannerIntro',
  'datePlanResult',
  'datePlanSent',
] as const

export type ScreenId = (typeof SCREENS)[number]

// Screens that show the persistent bottom tab bar.
export const TAB_ROOT_SCREENS: ScreenId[] = ['home', 'explore', 'connections', 'profile']

export function isTabRootScreen(screen: ScreenId): boolean {
  return TAB_ROOT_SCREENS.includes(screen)
}
