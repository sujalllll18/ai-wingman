// Domain model for the post-onboarding journey: recommendations, scheduling,
// the scheduled conversation, and everything from there through connection
// and date planning. Kept separate from screen components, same pattern as
// types/profile.ts.

export interface Person {
  id: string
  name: string
  age: number
  location: string
  profession: string
  gradientIndex: number // which PLACEHOLDER_GRADIENTS swatch stands in for their photo
  intent: string // relationship intention, shown plainly (e.g. "Dating")
  communicationStyle: string // shown plainly, e.g. "Deep conversations"
  commonInterests: string[]
  compatibilityPoint: string // "one meaningful compatibility point"
  difference: string // "one interesting difference"
  whyTalk: string // short reason shown on the recommendation card
  compatibility: {
    commonGround: string
    communication: string
    lifestyle: string
    potentialChemistry: string
  }
  bio: string
  openers: string[] // Wingman-suggested opening lines, specific to this person
  conversationTopics: string[] // Wingman "suggest a question" pool
  replySamples: string[] // mock replies used to simulate them chatting back
  dateInterests: string[] // shared interests the date planner can draw a reason from
}

// Which stage of the conversation ladder an introduction is at. Drives copy
// and duration on the shared Scheduling/UpcomingConversation/ChatRoom/Decision
// screens rather than forking them into near-duplicate components.
export type ConversationStage = 'first' | 'second' | 'video'

// Where one of the (max 3) active introductions currently sits.
export type IntroStage =
  | 'locked' // not yet unlocked by the hourly-release rule
  | 'new' // unlocked, not yet scheduled
  | 'scheduled_first'
  | 'talked_first'
  | 'scheduled_second'
  | 'talked_second'
  | 'scheduled_video'
  | 'video_done'
  | 'connection_requested'
  | 'connected'
  | 'ended'

export interface IntroState {
  personId: string
  stage: IntroStage
  unlockAtMs: number // Date.now()-comparable; <= now means unlocked
}

export interface ScheduledSlot {
  personId: string
  stage: ConversationStage
  day: 'Today' | 'Tomorrow'
  date: string // human label, e.g. "Fri, 28 Aug"
  time: string // e.g. "8:30 PM"
  endTime: string
  durationMinutes: number
}

export interface ChatMessage {
  id: string
  from: 'me' | 'them' | 'system'
  text: string
}

export type DecisionOutcome = 'continue' | 'unsure' | 'end'

export type PostSecondOutcome = 'continue' | 'video' | 'end'

// The user's picks for "this date" only — everything else (interests,
// lifestyle, communication style...) is already known from the Vibe
// Profile and deliberately isn't re-asked here. See mockDatePlanner.ts for
// how these turn into an actual plan.
export interface DateSelection {
  placeTypes: string[] // e.g. ['cafe', 'music']
  vibe: string // e.g. 'romantic'
  priorities: string[] // e.g. ['budget', 'rated'], at most 2
  day: 'today' | 'tomorrow' | 'weekend' | 'usual' | 'custom'
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night' | null
  customDate?: string
  customTime?: string
}

export interface DateItineraryStop {
  time: string // "6:30 PM"
  emoji: string
  label: string // "Coffee & conversation"
}

export interface DateOffer {
  label: string
}

export interface DatePlan extends DateSelection {
  personId: string
  dayLabel: string // "Saturday"
  timeLabel: string // "6:30 PM"
  venueEmoji: string
  venueTitle: string // "Blue Tokai — Bandra"
  venueSubtitle: string // "Coffee + conversation"
  musicTag: string
  walkTag: string
  priceTag: string
  ratingTag: string
  itinerary: DateItineraryStop[]
  reason: string
  offers: DateOffer[]
}

export type DatePlanResponse = 'accepted' | 'suggest_another' | 'declined' | null
