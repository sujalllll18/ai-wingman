// Business/domain model for the person going through onboarding and the
// "Vibe Profile" system. Deliberately separate from any screen component —
// screens read/write this shape via OnboardingContext, they never own the
// data themselves.

export type Gender = 'woman' | 'man' | 'non-binary' | 'self-describe'

export type InterestedIn = 'women' | 'men' | 'everyone'

export type RelationshipIntention = 'serious' | 'dating' | 'open' | 'not-sure'

export type CommunicationStyle =
  | 'deep-conversations'
  | 'fun-playful'
  | 'quiet-at-first'
  | 'talk-a-lot'
  | 'takes-time'

export type SocialStyle = 'one-on-one' | 'small-groups' | 'big-social' | 'depends'

export type CompatibilityAnswer = 'yes' | 'no' | 'depends'

export interface PromptAnswer {
  promptId: string
  answer: string
}

export interface AiImportField {
  label: string
  value: string
}

export type VibeCompletion = 0 | 25 | 50 | 75 | 100

export type VerificationStatus = 'not_started' | 'in_review' | 'verified'

export interface UserProfile {
  // Signup
  authMethod: 'google' | 'phone' | null
  phoneNumber: string
  phoneVerified: boolean

  // Vibe Profile — Level 1 (25%)
  name: string
  gender: Gender | null
  dateOfBirth: string // yyyy-mm-dd
  interestedIn: InterestedIn[]
  profession: string
  communicationStyle: CommunicationStyle | null
  photos: string[] // data URLs or placeholder ids, first is primary

  // Vibe Profile — Level 2 (50%)
  location: string
  relationshipIntention: RelationshipIntention | null
  interests: string[]
  socialStyle: SocialStyle | null
  lifestyle: string[]
  ageRangeMin: number | null
  ageRangeMax: number | null
  prompts: PromptAnswer[]

  // Vibe Profile — Level 3 (75%)
  story: string // the user's own words
  storyPolished: string | null // AI Rephrase output, if generated
  storyUsedPolished: boolean
  bio: string
  likes: string
  dislikes: string
  aiImportUsed: boolean
  aiImportFields: AiImportField[] // free-form extras from the ChatGPT import (values, green flags, etc.)

  // Vibe Profile — Level 4 (100%)
  compatibilityAnswers: Record<string, CompatibilityAnswer>

  vibeCompletion: VibeCompletion
  verificationStatus: VerificationStatus
  // How many times the user has dismissed the optional, non-blocking
  // "verify your profile" prompt on Home. There's no real backend clock in
  // this prototype, so this count doubles as the stand-in for "time has
  // passed" — 0 shows the initial invite, 1 shows the gentler "3 days
  // later" incentive copy, 2+ stops showing the proactive prompt entirely
  // (the status pill remains as a passive, always-available entry point).
  verificationPromptDismissCount: number
}

export const createEmptyProfile = (): UserProfile => ({
  authMethod: null,
  phoneNumber: '',
  phoneVerified: false,

  name: '',
  gender: null,
  dateOfBirth: '',
  interestedIn: [],
  profession: '',
  communicationStyle: null,
  photos: [],

  location: '',
  relationshipIntention: null,
  interests: [],
  socialStyle: null,
  lifestyle: [],
  ageRangeMin: null,
  ageRangeMax: null,
  prompts: [],

  story: '',
  storyPolished: null,
  storyUsedPolished: false,
  bio: '',
  likes: '',
  dislikes: '',
  aiImportUsed: false,
  aiImportFields: [],

  compatibilityAnswers: {},

  vibeCompletion: 0,
  verificationStatus: 'not_started',
  verificationPromptDismissCount: 0,
})
