import { WingmanCompanion } from '../components/WingmanCompanion'
import { useOnboarding } from '../state/OnboardingContext'

export function Welcome() {
  const { goNext } = useOnboarding()

  return (
    <div className="relative flex h-full min-h-screen flex-col overflow-hidden">
      {/* Ambient animated backdrop standing in for a full-bleed vibe video —
          layered moving gradient blobs rather than stock romantic imagery. */}
      <div className="absolute inset-0 bg-ink">
        <div
          className="absolute -left-24 -top-16 h-80 w-80 rounded-full opacity-70 blur-3xl"
          style={{ background: 'radial-gradient(circle, var(--color-primary), transparent 70%)', animation: 'vibe-float 7s ease-in-out infinite' }}
        />
        <div
          className="absolute -right-20 top-40 h-72 w-72 rounded-full opacity-60 blur-3xl"
          style={{ background: 'radial-gradient(circle, var(--color-secondary), transparent 70%)', animation: 'vibe-float 8.5s ease-in-out infinite reverse' }}
        />
        <div
          className="absolute bottom-0 left-1/4 h-96 w-96 rounded-full opacity-50 blur-3xl"
          style={{ background: 'radial-gradient(circle, var(--color-primary-light), transparent 70%)', animation: 'vibe-float 6s ease-in-out infinite' }}
        />
      </div>

      <div className="relative flex h-full min-h-screen flex-col justify-between px-6 pb-8 pt-16 text-white">
        <div className="flex items-center gap-2.5 animate-fade-in-up">
          <WingmanCompanion size={40} />
          <span className="text-h3 tracking-tight">WINGMAN</span>
        </div>

        <div className="animate-fade-in-up [animation-delay:100ms]">
          <h1 className="text-display">Meet someone worth talking to.</h1>
          <p className="mt-4 max-w-[300px] text-body text-white/75">
            No swiping. No feed. Just a structured chance to find out whether you actually enjoy
            talking to each other.
          </p>
        </div>

        <div className="space-y-3 animate-fade-in-up [animation-delay:200ms]">
          <button
            onClick={goNext}
            className="flex h-14 w-full items-center justify-center gap-3 rounded-full bg-white px-6 text-button text-ink shadow-pop transition-transform active:scale-[0.98]"
          >
            <GoogleIcon />
            Continue with Google
          </button>
          <p className="text-center text-caption text-white/55">
            By continuing, you agree to our Terms and Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M23.52 12.27c0-.85-.08-1.67-.22-2.45H12v4.64h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.88c2.27-2.09 3.57-5.17 3.57-8.82z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.96-1.07 7.95-2.91l-3.88-3c-1.08.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.26v3.11A11.99 11.99 0 0 0 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.28A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.28V6.61H1.26A11.99 11.99 0 0 0 0 12c0 1.94.46 3.77 1.26 5.39l4.01-3.11z"
      />
      <path
        fill="#EA4335"
        d="M12 4.77c1.76 0 3.34.6 4.58 1.79l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.69 1.26 6.61l4.01 3.11C6.22 6.88 8.87 4.77 12 4.77z"
      />
    </svg>
  )
}
