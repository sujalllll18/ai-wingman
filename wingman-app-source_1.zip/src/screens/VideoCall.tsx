import { useState, type ReactNode } from 'react'
import { SafetyMenu } from '../components/SafetyMenu'
import { WingmanCompanion } from '../components/WingmanCompanion'
import { getPersonById } from '../data/mockPeople'
import { PLACEHOLDER_GRADIENTS } from '../data/onboardingOptions'
import { useCountdown } from '../hooks/useCountdown'
import { useOnboarding } from '../state/OnboardingContext'

export function VideoCall() {
  const { selectedPersonId, scheduledSlot, setIntroStage, goNext } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const durationMinutes = scheduledSlot?.durationMinutes ?? 20

  const [muted, setMuted] = useState(false)
  const [cameraOff, setCameraOff] = useState(false)
  const [suggestion, setSuggestion] = useState<string | null>(null)

  const handleEndCall = () => {
    if (person) setIntroStage(person.id, 'video_done')
    goNext()
  }

  const { formatted, secondsLeft, finishNow } = useCountdown(durationMinutes * 60, { onComplete: handleEndCall })
  const lowTime = secondsLeft <= 60

  if (!person) return null

  const askWingman = () => {
    const pool = [...person.conversationTopics, ...person.openers]
    setSuggestion(pool[Math.floor(Math.random() * pool.length)])
  }

  return (
    <div className="relative flex h-full min-h-screen flex-col bg-ink text-white">
      {/* "Their" video feed */}
      <div
        className="relative flex-1"
        style={{ background: PLACEHOLDER_GRADIENTS[person.gradientIndex % PLACEHOLDER_GRADIENTS.length] }}
      >
        <div className="absolute inset-0 bg-ink/10" />

        <div className="absolute left-0 right-0 top-0 flex items-center justify-between px-5 pt-6">
          <div>
            <p className="text-h3 text-white drop-shadow">{person.name}</p>
            <p className="text-caption text-white/75 drop-shadow">Video call</p>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`rounded-full px-3 py-1.5 text-small font-semibold tabular-nums backdrop-blur ${
                lowTime ? 'bg-warning/25 text-white' : 'bg-black/25 text-white'
              }`}
            >
              {formatted}
            </span>
            <SafetyMenu personId={person.id} personName={person.name} afterActionScreen="explore" variant="dark" />
          </div>
        </div>

        {/* Self view */}
        <div className="absolute bottom-5 right-5 flex h-32 w-24 items-center justify-center overflow-hidden rounded-lg border border-white/20 bg-ink-secondary shadow-card">
          {cameraOff ? (
            <span className="text-caption text-white/60">Camera off</span>
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-primary/40 to-secondary/40" />
          )}
          <span className="absolute bottom-1.5 left-1.5 rounded-full bg-black/40 px-2 py-0.5 text-[10px] font-medium text-white">
            You
          </span>
        </div>

        {suggestion && (
          <div className="absolute left-5 right-5 top-24 flex items-start gap-3 rounded-md border border-white/15 bg-black/40 p-3 backdrop-blur animate-fade-in-up">
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white">
              <SparkleGlyph />
            </div>
            <div className="flex-1">
              <p className="text-small text-white">{suggestion}</p>
              <button onClick={() => setSuggestion(null)} className="mt-1.5 text-caption font-semibold text-white/70 underline">
                Dismiss
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-ink px-5 pb-8 pt-4">
        <div className="flex items-center justify-center gap-4">
          <ControlButton active={muted} onClick={() => setMuted((m) => !m)} label={muted ? 'Unmute' : 'Mute'}>
            {muted ? <MicOffIcon /> : <MicIcon />}
          </ControlButton>
          <ControlButton active={cameraOff} onClick={() => setCameraOff((c) => !c)} label={cameraOff ? 'Camera on' : 'Camera off'}>
            {cameraOff ? <CameraOffIcon /> : <CameraIcon />}
          </ControlButton>
          <ControlButton onClick={askWingman} label="Need help?" tone="primary">
            <WingmanCompanion size={28} />
          </ControlButton>
          <ControlButton onClick={finishNow} label="End" tone="danger">
            <EndCallIcon />
          </ControlButton>
        </div>
        <p className="mt-4 text-center text-caption text-white/40">Tap End to finish the call now (preview)</p>
      </div>
    </div>
  )
}

function ControlButton({
  children,
  onClick,
  label,
  active,
  tone,
}: {
  children: ReactNode
  onClick: () => void
  label: string
  active?: boolean
  tone?: 'primary' | 'danger'
}) {
  const bg =
    tone === 'danger'
      ? 'bg-error text-white'
      : tone === 'primary'
        ? 'bg-primary text-white'
        : active
          ? 'bg-white text-ink'
          : 'bg-white/10 text-white'
  return (
    <div className="flex flex-col items-center gap-1.5">
      <button
        onClick={onClick}
        aria-label={label}
        className={`flex items-center justify-center rounded-full transition-transform active:scale-90 ${bg}`}
        style={{ height: 52, width: 52 }}
      >
        {children}
      </button>
      <span className="text-[10px] text-white/50">{label}</span>
    </div>
  )
}

function SparkleGlyph() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
      <path d="M12 3c1.5 3 4 4.5 7 5-3 1-5.5 3.5-7 7-1.5-3.5-4-6-7-7 3-.5 5.5-2 7-5z" fill="currentColor" />
    </svg>
  )
}

function MicIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" strokeWidth="2" />
      <path d="M5 11a7 7 0 0014 0M12 18v3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function MicOffIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" strokeWidth="2" />
      <path d="M5 11a7 7 0 0014 0M12 18v3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M3 3l18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function CameraIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="6" width="13" height="12" rx="2.5" stroke="currentColor" strokeWidth="2" />
      <path d="M16 10l5-3v10l-5-3" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  )
}

function CameraOffIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="6" width="13" height="12" rx="2.5" stroke="currentColor" strokeWidth="2" />
      <path d="M16 10l5-3v10l-5-3" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M3 3l18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function EndCallIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path
        d="M3.5 14c5.5-4.5 11.5-4.5 17 0"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M9 14.5l1-2a5 5 0 014 0l1 2-2.5 2h-1L9 14.5z" fill="currentColor" />
    </svg>
  )
}
