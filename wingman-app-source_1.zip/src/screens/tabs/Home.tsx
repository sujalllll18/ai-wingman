import { BottomNav } from '../../components/BottomNav'
import { IntroSlot } from '../../components/IntroSlot'
import { VibeAvatar } from '../../components/VibeAvatar'
import { WingmanSpeech } from '../../components/WingmanSpeech'
import { MOCK_PEOPLE, getPersonById } from '../../data/mockPeople'
import { useOnboarding } from '../../state/OnboardingContext'

function verificationStatusLabel(status: string) {
  if (status === 'verified') return 'Verified'
  if (status === 'in_review') return 'Verification pending'
  return 'Not verified'
}

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

export function Home() {
  const { profile, updateProfile, introStates, scheduledSlot, goTo } = useOnboarding()

  const unlockedCount = MOCK_PEOPLE.filter((p) => introStates[p.id]?.unlockAtMs <= Date.now()).length
  const upcomingPerson = scheduledSlot ? getPersonById(scheduledSlot.personId) : undefined

  return (
    <div className="flex h-full min-h-screen flex-col">
      <div className="flex-1 overflow-y-auto px-5 pb-4 pt-6 no-scrollbar animate-fade-in-up">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-h2 text-ink">
              {greeting()}, {profile.name || 'there'}.
            </p>
          </div>
          <button onClick={() => goTo('profile')}>
            <VibeAvatar completion={profile.vibeCompletion} size={48} />
          </button>
        </div>

        <div className="mt-5">
          <WingmanSpeech
            lines={[
              unlockedCount > 0
                ? 'I found someone interesting for you.'
                : 'Your next introduction is on its way.',
            ]}
          />
        </div>

        <div className="mt-6 flex gap-3">
          <StatusPill label="Vibe Profile" value={`${profile.vibeCompletion}%`} />
          <button onClick={() => goTo('verification')} disabled={profile.verificationStatus === 'verified'} className="flex-1 text-left">
            <StatusPill label="Verification" value={verificationStatusLabel(profile.verificationStatus)} />
          </button>
        </div>

        {profile.verificationStatus !== 'verified' && profile.verificationPromptDismissCount === 0 && (
          <VerificationCard
            eyebrow="🛡️ Verify your profile"
            title="Show people you're real."
            body="Verification helps build trust and can unlock more conversation opportunities."
            primaryLabel="Get verified"
            onPrimary={() => goTo('verification')}
            onDismiss={() => updateProfile({ verificationPromptDismissCount: 1 })}
          />
        )}

        {profile.verificationStatus !== 'verified' && profile.verificationPromptDismissCount === 1 && (
          <VerificationCard
            eyebrow="✨ A little nudge"
            title="Want more conversation opportunities?"
            body="Verify your profile to build more trust and become eligible for greater conversation opportunities."
            primaryLabel="Verify now"
            onPrimary={() => goTo('verification')}
            onDismiss={() => updateProfile({ verificationPromptDismissCount: 2 })}
          />
        )}

        {upcomingPerson && (
          <button
            onClick={() => goTo('upcomingConversation')}
            className="mt-6 flex w-full items-center justify-between rounded-lg border border-primary/25 bg-primary-light/30 p-4 text-left"
          >
            <div>
              <p className="text-caption font-semibold uppercase tracking-wide text-primary">Upcoming conversation</p>
              <p className="mt-1 text-body font-medium text-ink">
                {upcomingPerson.name} · {scheduledSlot?.time}
              </p>
            </div>
            <span className="text-primary">→</span>
          </button>
        )}

        <div className="mt-7">
          <div className="mb-3 flex items-baseline justify-between">
            <p className="text-h3 text-ink">Today's introductions</p>
            <span className="text-caption text-ink-muted">{unlockedCount} available now</span>
          </div>
          <div className="space-y-3">
            {MOCK_PEOPLE.map((person) => (
              <IntroSlot key={person.id} person={person} state={introStates[person.id]} />
            ))}
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  )
}

function StatusPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex-1 rounded-md border border-border bg-surface px-3.5 py-2.5">
      <p className="text-caption text-ink-muted">{label}</p>
      <p className="text-small font-semibold text-ink">{value}</p>
    </div>
  )
}

// The non-blocking verification invite/incentive card. Always dismissible —
// "Maybe later" hides it (see the dismiss-count staging in Home()); it
// never prevents anything else on this screen from working.
function VerificationCard({
  eyebrow,
  title,
  body,
  primaryLabel,
  onPrimary,
  onDismiss,
}: {
  eyebrow: string
  title: string
  body: string
  primaryLabel: string
  onPrimary: () => void
  onDismiss: () => void
}) {
  return (
    <div className="mt-4 rounded-lg border border-primary/25 bg-primary-light/25 p-4 animate-fade-in-up">
      <p className="text-caption font-semibold uppercase tracking-wide text-primary-dark">{eyebrow}</p>
      <p className="mt-1 text-body font-semibold text-ink">{title}</p>
      <p className="mt-1 text-small text-ink-secondary">{body}</p>
      <div className="mt-3 flex items-center gap-4">
        <button
          onClick={onPrimary}
          className="rounded-full bg-primary px-4 py-2 text-caption font-semibold text-white active:scale-[0.98]"
        >
          {primaryLabel}
        </button>
        <button onClick={onDismiss} className="text-caption font-medium text-ink-muted">
          Maybe later
        </button>
      </div>
    </div>
  )
}
