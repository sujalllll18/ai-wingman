import type { ReactNode } from 'react'
import { BottomNav } from '../../components/BottomNav'
import { IntroSlot } from '../../components/IntroSlot'
import { MOCK_PEOPLE } from '../../data/mockPeople'
import { useOnboarding } from '../../state/OnboardingContext'
import type { IntroStage } from '../../types/journey'

const REQUEST_STAGES: IntroStage[] = ['connection_requested']
const UPCOMING_STAGES: IntroStage[] = ['scheduled_first', 'talked_first', 'scheduled_second', 'talked_second', 'scheduled_video', 'video_done']
const CONNECTED_STAGES: IntroStage[] = ['connected']

export function Connections() {
  const { introStates } = useOnboarding()

  const peopleIn = (stages: IntroStage[]) => MOCK_PEOPLE.filter((p) => stages.includes(introStates[p.id]?.stage))

  const requests = peopleIn(REQUEST_STAGES)
  const upcoming = peopleIn(UPCOMING_STAGES)
  const connected = peopleIn(CONNECTED_STAGES)

  const nothingYet = requests.length === 0 && upcoming.length === 0 && connected.length === 0

  return (
    <div className="flex h-full min-h-screen flex-col">
      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-6 no-scrollbar animate-fade-in-up">
        <h1 className="text-h1 text-ink">Connections</h1>

        {nothingYet && (
          <div className="mt-10 flex flex-col items-center text-center">
            <p className="text-body text-ink">No connections yet.</p>
            <p className="mt-1 max-w-[240px] text-small text-ink-secondary">
              Your next good conversation could be one introduction away.
            </p>
          </div>
        )}

        {requests.length > 0 && (
          <Section title="Connection requests">
            {requests.map((p) => (
              <IntroSlot key={p.id} person={p} state={introStates[p.id]} />
            ))}
          </Section>
        )}

        {upcoming.length > 0 && (
          <Section title="Upcoming conversations">
            {upcoming.map((p) => (
              <IntroSlot key={p.id} person={p} state={introStates[p.id]} />
            ))}
          </Section>
        )}

        {connected.length > 0 && (
          <Section title="Active connections">
            {connected.map((p) => (
              <IntroSlot key={p.id} person={p} state={introStates[p.id]} />
            ))}
          </Section>
        )}
      </div>
      <BottomNav />
    </div>
  )
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mt-7">
      <p className="mb-3 text-h3 text-ink">{title}</p>
      <div className="space-y-3">{children}</div>
    </div>
  )
}
