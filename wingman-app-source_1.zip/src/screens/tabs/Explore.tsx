import { useEffect, useState } from 'react'
import { BottomNav } from '../../components/BottomNav'
import { RecommendationCard } from '../../components/RecommendationCard'
import { MOCK_PEOPLE } from '../../data/mockPeople'
import { useOnboarding } from '../../state/OnboardingContext'

function useUnlockCountdown(unlockAtMs: number) {
  const [, setTick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 30000)
    return () => clearInterval(t)
  }, [])
  const msLeft = unlockAtMs - Date.now()
  if (msLeft <= 0) return null
  const mins = Math.ceil(msLeft / 60000)
  return mins < 60 ? `${mins} min` : `${Math.floor(mins / 60)}h ${mins % 60}m`
}

export function Explore() {
  const { introStates, setSelectedPersonId, goTo, unlockIntroNow } = useOnboarding()

  return (
    <div className="flex h-full min-h-screen flex-col">
      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-6 no-scrollbar">
        <div className="animate-fade-in-up">
          <h1 className="text-h1 text-ink">3 people worth meeting.</h1>
          <p className="mt-2 text-body text-ink-secondary">
            Your Wingman found these people based on what you told us. Only one introduction
            unlocks per hour, so every one gets your full attention.
          </p>
        </div>

        <div className="mt-6 space-y-5">
          {MOCK_PEOPLE.map((person) => {
            const state = introStates[person.id]
            return (
              <ExploreCard
                key={person.id}
                person={person}
                locked={state.unlockAtMs > Date.now()}
                unlockAtMs={state.unlockAtMs}
                onSeeWhy={() => {
                  setSelectedPersonId(person.id)
                  goTo('matchExplanation')
                }}
                onUnlockNow={() => unlockIntroNow(person.id)}
              />
            )
          })}
        </div>

        <p className="mt-6 text-center text-caption text-ink-muted">
          That's all for now — just 3 at a time, so every introduction matters.
        </p>
      </div>
      <BottomNav />
    </div>
  )
}

function ExploreCard({
  person,
  locked,
  unlockAtMs,
  onSeeWhy,
  onUnlockNow,
}: {
  person: (typeof MOCK_PEOPLE)[number]
  locked: boolean
  unlockAtMs: number
  onSeeWhy: () => void
  onUnlockNow: () => void
}) {
  const countdown = useUnlockCountdown(unlockAtMs)

  if (locked) {
    return (
      <div className="flex items-center gap-4 rounded-lg border border-dashed border-border bg-surface-alt/50 p-5">
        <div className="h-16 w-16 shrink-0 rounded-full bg-border/70" />
        <div className="flex-1">
          <p className="text-body font-medium text-ink-muted">Introduction locked</p>
          <p className="text-small text-ink-muted">{countdown ? `Unlocks in ${countdown}` : 'Unlocking soon'}</p>
          <button onClick={onUnlockNow} className="mt-1.5 text-caption font-semibold text-primary underline">
            Unlock now (preview)
          </button>
        </div>
      </div>
    )
  }

  return <RecommendationCard person={person} onSeeWhy={onSeeWhy} />
}
