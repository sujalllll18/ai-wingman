import { useState } from 'react'
import { BottomNav } from '../../components/BottomNav'
import { Modal } from '../../components/Modal'
import { VibeAvatar } from '../../components/VibeAvatar'
import { COMMUNICATION_STYLE_OPTIONS, SOCIAL_STYLE_OPTIONS } from '../../data/vibeOptions'
import { RELATIONSHIP_INTENTION_OPTIONS } from '../../data/onboardingOptions'
import { useOnboarding } from '../../state/OnboardingContext'

function verificationStatusLabel(status: string) {
  if (status === 'verified') return 'Verified'
  if (status === 'in_review') return 'Verification pending'
  return 'Not verified'
}

function calcAge(dob: string) {
  if (!dob) return null
  const d = new Date(dob)
  const today = new Date()
  let age = today.getFullYear() - d.getFullYear()
  const monthDiff = today.getMonth() - d.getMonth()
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < d.getDate())) age--
  return age
}

export function Profile() {
  const { profile, goTo } = useOnboarding()
  const [notifications, setNotifications] = useState(true)
  const [safetyOpen, setSafetyOpen] = useState(false)
  const age = calcAge(profile.dateOfBirth)

  const intentionLabel = RELATIONSHIP_INTENTION_OPTIONS.find((o) => o.value === profile.relationshipIntention)?.label
  const communicationLabel = COMMUNICATION_STYLE_OPTIONS.find((o) => o.value === profile.communicationStyle)?.label
  const socialLabel = SOCIAL_STYLE_OPTIONS.find((o) => o.value === profile.socialStyle)?.label

  return (
    <div className="relative flex h-full min-h-screen flex-col">
      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-6 no-scrollbar animate-fade-in-up">
        <div className="flex items-center gap-4">
          <VibeAvatar completion={profile.vibeCompletion} size={84} />
          <div>
            <p className="flex items-center gap-1.5 text-h2 text-ink">
              {profile.name || 'You'}
              {age !== null && <span className="font-normal">, {age}</span>}
              {profile.verificationStatus === 'verified' && <VerifiedBadge />}
            </p>
            <p className="text-small text-ink-secondary">{profile.location || 'Mumbai'}</p>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <div className="rounded-md border border-border bg-surface px-3.5 py-3">
            <p className="text-caption text-ink-muted">Vibe Profile</p>
            <p className="text-h3 text-ink">{profile.vibeCompletion}%</p>
          </div>
          {profile.verificationStatus === 'verified' ? (
            <div className="rounded-md border border-secondary/30 bg-secondary-light/40 px-3.5 py-3">
              <p className="text-caption text-secondary-dark">Verification</p>
              <p className="text-h3 text-secondary-dark">Verified</p>
            </div>
          ) : (
            <button onClick={() => goTo('verification')} className="rounded-md border border-border bg-surface px-3.5 py-3 text-left">
              <p className="text-caption text-ink-muted">Verification</p>
              <p className="text-h3 text-ink">{verificationStatusLabel(profile.verificationStatus)}</p>
              <p className="mt-0.5 text-caption font-medium text-primary">Get verified →</p>
            </button>
          )}
        </div>

        {profile.bio && (
          <div className="mt-6">
            <SectionLabel>About</SectionLabel>
            <p className="text-body text-ink">{profile.bio}</p>
          </div>
        )}

        {profile.interests.length > 0 && (
          <div className="mt-6">
            <SectionLabel>Interests</SectionLabel>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((i) => (
                <span key={i} className="rounded-full border border-border px-3 py-1.5 text-small text-ink-secondary">
                  {i}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6">
          <SectionLabel>Preferences</SectionLabel>
          <div className="space-y-2">
            <PreferenceRow label="Looking for" value={intentionLabel ?? 'Not set'} />
            <PreferenceRow label="Communication style" value={communicationLabel ?? 'Not set'} />
            <PreferenceRow label="Social style" value={socialLabel ?? 'Not set'} />
            <PreferenceRow
              label="Preferred age range"
              value={profile.ageRangeMin && profile.ageRangeMax ? `${profile.ageRangeMin}–${profile.ageRangeMax}` : 'Not set'}
            />
          </div>
        </div>

        <div className="mt-6">
          <SectionLabel>Settings</SectionLabel>
          <div className="overflow-hidden rounded-md border border-border">
            <button
              onClick={() => setNotifications((n) => !n)}
              className="flex w-full items-center justify-between border-b border-border bg-surface px-4 py-3.5"
            >
              <span className="text-body text-ink">Notifications</span>
              <span
                className={`flex h-6 w-11 items-center rounded-full px-0.5 transition-colors ${notifications ? 'bg-primary justify-end' : 'bg-border justify-start'}`}
              >
                <span className="h-5 w-5 rounded-full bg-white shadow" />
              </span>
            </button>
            <button onClick={() => setSafetyOpen(true)} className="flex w-full items-center justify-between border-b border-border bg-surface px-4 py-3.5">
              <span className="text-body text-ink">Safety Center</span>
              <span className="text-ink-muted">→</span>
            </button>
            <button className="flex w-full items-center justify-between border-b border-border bg-surface px-4 py-3.5">
              <span className="text-body text-ink">Privacy</span>
              <span className="text-ink-muted">→</span>
            </button>
            <button onClick={() => goTo('welcome')} className="flex w-full items-center justify-between bg-surface px-4 py-3.5">
              <span className="text-body text-error">Log out</span>
            </button>
          </div>
        </div>
      </div>

      <Modal open={safetyOpen} onClose={() => setSafetyOpen(false)} title="You're always in control">
        <div className="space-y-3 text-small text-ink-secondary">
          <p>Report or block anyone, any time — from their profile, a chat, or a video call.</p>
          <p>End a conversation or leave a video call whenever you want, no explanation needed.</p>
          <p>Cancel a scheduled conversation up until it starts.</p>
        </div>
      </Modal>

      <BottomNav />
    </div>
  )
}

function VerifiedBadge() {
  return (
    <span
      className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-secondary text-white"
      title="Verified"
      aria-label="Verified"
    >
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
        <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  )
}

function SectionLabel({ children }: { children: string }) {
  return <p className="mb-2.5 text-caption font-semibold uppercase tracking-wide text-ink-muted">{children}</p>
}

function PreferenceRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-border bg-surface px-4 py-3">
      <span className="text-small text-ink-secondary">{label}</span>
      <span className="text-small font-medium text-ink">{value}</span>
    </div>
  )
}
