import { useState, type ReactNode } from 'react'
import { Avatar } from '../components/Avatar'
import { Button, TextButton } from '../components/Button'
import { Chip } from '../components/Chip'
import { TopBar } from '../components/TopBar'
import {
  DAY_OPTIONS,
  generateDatePlan,
  PLACE_TYPES,
  PRIORITY_OPTIONS,
  recommendedPlaceTypeIds,
  recommendedVibeId,
  TIME_OF_DAY_OPTIONS,
  USUAL_AVAILABILITY,
  VIBE_OPTIONS,
} from '../data/mockDatePlanner'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'
import type { DateSelection } from '../types/journey'

const PRIORITY_LIMIT = 2

// Screen 1 of the 2-screen date planner. Wingman already knows the user's
// interests and communication style (Vibe Profile) and the connected
// person's shared interests (Person mock data) — so this screen only ever
// asks what the user feels like *for this date*, pre-filled with sensible
// defaults derived from data that already exists.
export function DatePlannerIntro() {
  const { profile, selectedPersonId, datePlan, setDatePlan, goBack, goNext } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const existing = datePlan && datePlan.personId === selectedPersonId ? datePlan : null

  const [placeTypes, setPlaceTypes] = useState<string[]>(() => existing?.placeTypes ?? recommendedPlaceTypeIds(profile))
  const [vibe, setVibe] = useState<string>(() => existing?.vibe ?? recommendedVibeId(profile))
  const [priorities, setPriorities] = useState<string[]>(() => existing?.priorities ?? [])
  const [day, setDay] = useState<DateSelection['day']>(() => existing?.day ?? 'usual')
  const [timeOfDay, setTimeOfDay] = useState<DateSelection['timeOfDay']>(
    () => existing?.timeOfDay ?? USUAL_AVAILABILITY.timeOfDay,
  )
  const [showCustom, setShowCustom] = useState(existing?.day === 'custom')
  const [customDate, setCustomDate] = useState(existing?.customDate ?? '')
  const [customTime, setCustomTime] = useState(existing?.customTime ?? '')

  if (!person) return null

  const togglePlaceType = (id: string) =>
    setPlaceTypes((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))

  const togglePriority = (id: string) =>
    setPriorities((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id)
      if (prev.length >= PRIORITY_LIMIT) return [...prev.slice(1), id]
      return [...prev, id]
    })

  const pickDay = (id: DateSelection['day']) => {
    setDay(id)
    setShowCustom(false)
  }

  const useUsualTime = () => {
    setDay(USUAL_AVAILABILITY.day)
    setTimeOfDay(USUAL_AVAILABILITY.timeOfDay)
    setShowCustom(false)
  }

  const buildSelection = (): DateSelection => ({
    placeTypes,
    vibe,
    priorities,
    day,
    timeOfDay: showCustom ? null : timeOfDay,
    customDate: showCustom ? customDate : undefined,
    customTime: showCustom ? customTime : undefined,
  })

  const handleGenerate = () => {
    const selection = buildSelection()
    setDatePlan(generateDatePlan(person, selection, 0))
    goNext()
  }

  const handleSurprise = () => {
    const selection: DateSelection = {
      placeTypes: ['surprise'],
      vibe: 'surprise',
      priorities: [],
      day: 'usual',
      timeOfDay: USUAL_AVAILABILITY.timeOfDay,
    }
    setDatePlan(generateDatePlan(person, selection, Math.floor(Math.random() * 5)))
    goNext()
  }

  const placeSummary = placeTypes
    .map((id) => PLACE_TYPES.find((t) => t.id === id))
    .filter(Boolean)
    .map((t) => `${t!.emoji} ${t!.label}`)
    .join(' + ')
  const vibeOption = VIBE_OPTIONS.find((v) => v.id === vibe)
  const topPriority = PRIORITY_OPTIONS.find((p) => p.id === priorities[0])
  const timeSummary = showCustom
    ? customDate && customTime
      ? `${customDate} · ${customTime}`
      : 'Pick a date & time'
    : `${DAY_OPTIONS.find((d) => d.id === day)?.label ?? 'Saturday'}${
        timeOfDay ? ` ${TIME_OF_DAY_OPTIONS.find((t) => t.id === timeOfDay)?.label.toLowerCase()}` : ''
      }`

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex-1 overflow-y-auto px-5 pb-4 no-scrollbar animate-fade-in-up">
        <h1 className="text-h1 text-ink">Let's plan your date.</h1>
        <p className="mt-2 text-body text-ink-secondary">
          Your Wingman already knows what you both enjoy. Just tell me what feels right today.
        </p>

        <div className="mt-4 flex items-center gap-2.5 rounded-full border border-border bg-surface py-1.5 pl-1.5 pr-4 w-fit">
          <Avatar gradientIndex={person.gradientIndex} size={28} />
          <span className="text-small font-medium text-ink">Planning with {person.name}</span>
        </div>

        <Section title="What kind of place do you feel like?">
          <div className="flex flex-wrap gap-2">
            {PLACE_TYPES.map((t) => (
              <Chip key={t.id} selected={placeTypes.includes(t.id)} onClick={() => togglePlaceType(t.id)}>
                {t.emoji} {t.label}
              </Chip>
            ))}
          </div>
        </Section>

        <Section title="What vibe are you looking for today?">
          <div className="flex flex-wrap gap-2">
            {VIBE_OPTIONS.map((v) => (
              <Chip key={v.id} selected={vibe === v.id} onClick={() => setVibe(v.id)}>
                {v.emoji} {v.label}
              </Chip>
            ))}
          </div>
        </Section>

        <Section title="What matters most?" hint={`Pick up to ${PRIORITY_LIMIT}`}>
          <div className="flex flex-wrap gap-2">
            {PRIORITY_OPTIONS.map((p) => (
              <Chip key={p.id} selected={priorities.includes(p.id)} onClick={() => togglePriority(p.id)}>
                {p.emoji} {p.label}
              </Chip>
            ))}
          </div>
        </Section>

        <Section title="When do you want to go?">
          <div className="flex flex-wrap gap-2">
            {DAY_OPTIONS.map((d) => (
              <Chip key={d.id} selected={!showCustom && day === d.id} onClick={() => pickDay(d.id)}>
                {d.label}
              </Chip>
            ))}
            <Chip selected={showCustom} onClick={() => setShowCustom(true)}>
              📅 Pick date &amp; time
            </Chip>
          </div>

          {!showCustom && (
            <div className="mt-2.5 flex flex-wrap gap-2">
              {TIME_OF_DAY_OPTIONS.map((t) => (
                <Chip key={t.id} selected={timeOfDay === t.id} onClick={() => setTimeOfDay(t.id)}>
                  {t.label}
                </Chip>
              ))}
            </div>
          )}

          {showCustom && (
            <div className="mt-2.5 flex gap-2.5">
              <input
                type="date"
                value={customDate}
                onChange={(e) => setCustomDate(e.target.value)}
                className="h-11 flex-1 rounded-md border border-border bg-surface px-3 text-small text-ink outline-none focus:border-primary"
              />
              <input
                type="time"
                value={customTime}
                onChange={(e) => setCustomTime(e.target.value)}
                className="h-11 flex-1 rounded-md border border-border bg-surface px-3 text-small text-ink outline-none focus:border-primary"
              />
            </div>
          )}

          <button
            onClick={useUsualTime}
            className="mt-3 flex w-full items-center justify-between rounded-md border border-dashed border-primary/30 bg-primary-light/20 px-3.5 py-2.5 text-left"
          >
            <span className="text-small text-ink-secondary">
              Your usual availability: <span className="font-medium text-ink">{USUAL_AVAILABILITY.label}</span>
            </span>
            <span className="shrink-0 text-caption font-semibold text-primary-dark">Use my usual time</span>
          </button>
        </Section>

        <div className="mt-6 rounded-lg border border-border bg-surface-alt/50 p-4">
          <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Planning with {person.name}</p>
          <div className="mt-2 space-y-1 text-small text-ink">
            {placeSummary && <p>{placeSummary}</p>}
            {vibeOption && (
              <p>
                {vibeOption.emoji} {vibeOption.label}
              </p>
            )}
            {topPriority && (
              <p>
                {topPriority.emoji} {topPriority.label}
              </p>
            )}
            <p>📅 {timeSummary}</p>
          </div>
        </div>
      </div>

      <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
        <Button onClick={handleGenerate}>Create my date plan ✨</Button>
        <TextButton fullWidth className="mt-1 justify-center" onClick={handleSurprise}>
          Let Wingman surprise us
        </TextButton>
      </div>
    </div>
  )
}

function Section({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="mt-6">
      <div className="mb-2.5 flex items-baseline justify-between">
        <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">{title}</p>
        {hint && <span className="text-caption text-ink-muted">{hint}</span>}
      </div>
      {children}
    </div>
  )
}
