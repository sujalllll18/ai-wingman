import { useEffect, useRef, useState } from 'react'
import { Avatar } from '../components/Avatar'
import { ChatBubble } from '../components/ChatBubble'
import { SafetyMenu } from '../components/SafetyMenu'
import { TopBar } from '../components/TopBar'
import { WingmanHelpSheet, type HelpKind } from '../components/WingmanHelpSheet'
import { FUN_PROMPTS, KEEP_GOING_TIPS } from '../data/mockWingmanTips'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'
import type { ChatMessage } from '../types/journey'

let idCounter = 0
const nextId = () => `uchat-${++idCounter}`

export function UnlimitedChat() {
  const { selectedPersonId, goBack, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [draft, setDraft] = useState('')
  const [helpOpen, setHelpOpen] = useState(false)
  const [suggestion, setSuggestion] = useState<{ kind: HelpKind; text: string } | null>(null)
  const [copied, setCopied] = useState(false)
  const replyIndexRef = useRef(1)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!person) return
    setMessages([
      { id: nextId(), from: 'system', text: `You and ${person.name} are connected. Chat as much as you'd like.` },
    ])
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [person?.id])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  if (!person) return null

  const sendMessage = (text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    setMessages((prev) => [...prev, { id: nextId(), from: 'me', text: trimmed }])
    setDraft('')
    setSuggestion(null)

    const reply = person.replySamples[replyIndexRef.current % person.replySamples.length]
    replyIndexRef.current += 1
    setTimeout(() => {
      setMessages((prev) => [...prev, { id: nextId(), from: 'them', text: reply }])
    }, 1100 + Math.random() * 600)
  }

  const handleHelpSelect = (kind: HelpKind) => {
    let text = ''
    if (kind === 'opener') text = person.openers[0]
    else if (kind === 'question') text = person.conversationTopics[Math.floor(Math.random() * person.conversationTopics.length)]
    else if (kind === 'keepGoing') text = KEEP_GOING_TIPS[Math.floor(Math.random() * KEEP_GOING_TIPS.length)]
    else text = FUN_PROMPTS[Math.floor(Math.random() * FUN_PROMPTS.length)]
    setSuggestion({ kind, text })
    setHelpOpen(false)
  }

  const shareProfile = () => {
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar
        onBack={goBack}
        right={
          <div className="flex items-center gap-2">
            <button onClick={shareProfile} aria-label="Share" className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface text-ink-secondary active:scale-95">
              <ShareIcon />
            </button>
            <SafetyMenu personId={person.id} personName={person.name} afterActionScreen="connections" />
          </div>
        }
      />
      <div className="flex items-center gap-3 px-5 pb-3">
        <Avatar gradientIndex={person.gradientIndex} size={40} />
        <div className="flex-1">
          <p className="text-h3 text-ink leading-tight">{person.name}</p>
          <span className="inline-flex items-center gap-1 text-caption text-success">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Connected
          </span>
        </div>
        <button
          onClick={() => goTo('datePlannerIntro')}
          className="rounded-full border border-primary/30 bg-primary-light/40 px-3.5 py-2 text-caption font-semibold text-primary-dark active:scale-95"
        >
          Plan a date
        </button>
      </div>

      {copied && (
        <div className="mx-5 mb-2 rounded-md bg-surface-alt px-3 py-2 text-center text-caption text-ink-secondary animate-fade-in">
          Profile link copied (preview)
        </div>
      )}

      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-5 py-4 no-scrollbar">
        {messages.map((m) => (
          <ChatBubble key={m.id} message={m} />
        ))}
      </div>

      {suggestion && (
        <div className="mx-5 mb-2 flex items-start gap-3 rounded-md border border-primary/25 bg-primary-light/40 p-3 animate-fade-in-up">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white">
            <WingmanMark />
          </div>
          <div className="flex-1">
            <p className="text-small text-ink">{suggestion.text}</p>
            <div className="mt-2 flex gap-3">
              <button onClick={() => setDraft(suggestion.text)} className="text-caption font-semibold text-primary-dark underline">
                Use this
              </button>
              <button onClick={() => setSuggestion(null)} className="text-caption font-semibold text-ink-muted underline">
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="border-t border-border/70 bg-bg/95 px-5 py-3 backdrop-blur">
        <div className="flex items-end gap-2">
          <button
            onClick={() => setHelpOpen(true)}
            className="flex h-11 shrink-0 items-center gap-1.5 rounded-full border border-primary/30 bg-primary-light/40 px-3.5 text-small font-medium text-primary-dark active:scale-95"
          >
            <WingmanMark />
            Need help?
          </button>
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage(draft)}
            placeholder="Message..."
            className="h-11 min-w-0 flex-1 rounded-full border border-border bg-surface px-4 text-body text-ink placeholder:text-ink-muted outline-none focus:border-primary"
          />
          <button
            onClick={() => sendMessage(draft)}
            disabled={!draft.trim()}
            aria-label="Send"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary text-white transition-opacity disabled:opacity-30"
          >
            <SendIcon />
          </button>
        </div>
      </div>

      <WingmanHelpSheet open={helpOpen} onClose={() => setHelpOpen(false)} onSelect={handleHelpSelect} />
    </div>
  )
}

function WingmanMark() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
      <path d="M12 3c1.5 3 4 4.5 7 5-3 1-5.5 3.5-7 7-1.5-3.5-4-6-7-7 3-.5 5.5-2 7-5z" fill="currentColor" />
    </svg>
  )
}

function SendIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M4 12l16-7-6 16-2.5-6.5L4 12z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  )
}

function ShareIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <circle cx="18" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="6" cy="12" r="2.5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="18" cy="19" r="2.5" stroke="currentColor" strokeWidth="1.8" />
      <path d="M8.2 10.7l7.6-4.4M8.2 13.3l7.6 4.4" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  )
}
