import { Avatar } from '../components/Avatar'
import { Button, TextButton } from '../components/Button'
import { CompatibilitySection } from '../components/CompatibilitySection'
import { TopBar } from '../components/TopBar'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

export function MatchExplanation() {
  const { selectedPersonId, goBack, goTo, goNext, setConversationStage } = useOnboarding()
  const person = getPersonById(selectedPersonId)

  if (!person) {
    return (
      <div className="flex h-full min-h-screen flex-col items-center justify-center px-6 text-center">
        <p className="text-body text-ink-secondary">We couldn't find that introduction.</p>
        <TextButton className="mt-3" onClick={() => goTo('explore')}>
          Back to Explore
        </TextButton>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar">
        <div className="flex items-center gap-3 animate-fade-in-up">
          <Avatar gradientIndex={person.gradientIndex} size={56} />
          <div>
            <h1 className="text-h1 text-ink">Why you two?</h1>
            <p className="text-small text-ink-secondary">
              {person.name}, {person.age} · {person.location}
            </p>
          </div>
        </div>

        <div className="mt-6 space-y-5">
          <CompatibilitySection label="Common ground" text={person.compatibility.commonGround} />
          <CompatibilitySection label="Communication" text={person.compatibility.communication} />
          <CompatibilitySection label="Lifestyle" text={person.compatibility.lifestyle} />
          <CompatibilitySection label="Potential chemistry" text={person.compatibility.potentialChemistry} />
        </div>

        <div className="mt-6 rounded-lg bg-surface-alt/70 p-4">
          <p className="text-body text-ink">I think 10 minutes is worth discovering.</p>
        </div>
      </div>

      <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
        <Button
          onClick={() => {
            setConversationStage('first')
            goNext()
          }}
        >
          Schedule 10-minute conversation
        </Button>
        <TextButton fullWidth className="mt-1 justify-center" onClick={() => goTo('explore')}>
          Explore someone else
        </TextButton>
      </div>
    </div>
  )
}
