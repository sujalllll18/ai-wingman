import { useState } from 'react'
import { Avatar } from '../components/Avatar'
import { Button, SecondaryButton } from '../components/Button'
import { ScheduleSlot } from '../components/ScheduleSlot'
import { TopBar } from '../components/TopBar'
import { getPersonById } from '../data/mockPeople'
import { SLOT_OPTIONS, STAGE_DURATIONS, buildScheduledSlot, type SlotOption } from '../data/mockSchedule'
import { useOnboarding } from '../state/OnboardingContext'

const STAGE_COPY = {
  first: {
    title: 'Find a time to talk.',
    subtitle: (name: string) => `Your Wingman found times when both you and ${name} are available.`,
    confirmTitle: 'Confirm your conversation.',
  },
  second: {
    title: 'Find a time to talk once more.',
    subtitle: () => "That's okay — take another slightly longer conversation to see where it goes.",
    confirmTitle: 'Confirm your second conversation.',
  },
  video: {
    title: 'Meet face-to-face.',
    subtitle: () =>
      'You can have a private video conversation before deciding whether you want to stay connected.',
    confirmTitle: 'Confirm your video call.',
  },
}

export function Scheduling() {
  const { selectedPersonId, conversationStage, setScheduledSlot, setIntroStage, goBack, goNext, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const [chosen, setChosen] = useState<SlotOption | null>(null)
  const copy = STAGE_COPY[conversationStage]
  const durationMinutes = STAGE_DURATIONS[conversationStage]

  if (!person) return null

  const grouped = {
    Today: SLOT_OPTIONS.filter((s) => s.day === 'Today'),
    Tomorrow: SLOT_OPTIONS.filter((s) => s.day === 'Tomorrow'),
  }

  const confirm = () => {
    if (!chosen) return
    const slot = buildScheduledSlot(person.id, chosen, conversationStage)
    setScheduledSlot(slot)
    setIntroStage(
      person.id,
      conversationStage === 'first' ? 'scheduled_first' : conversationStage === 'second' ? 'scheduled_second' : 'scheduled_video',
    )
    if (conversationStage === 'video') {
      goTo('videoCall')
    } else {
      goNext()
    }
  }

  if (chosen) {
    const slot = buildScheduledSlot(person.id, chosen, conversationStage)
    return (
      <div className="flex h-full min-h-screen flex-col">
        <TopBar onBack={() => setChosen(null)} />
        <div className="flex flex-1 flex-col px-5 pb-6">
          <div className="animate-fade-in-up">
            <h1 className="text-h1 text-ink">{copy.confirmTitle}</h1>
            <p className="mt-2 text-body text-ink-secondary">{durationMinutes}-minute {conversationStage === 'video' ? 'video call' : 'conversation'}</p>
          </div>

          <div className="mt-6 rounded-lg border border-border bg-surface p-5 shadow-card">
            <div className="flex items-center gap-3">
              <Avatar gradientIndex={person.gradientIndex} size={48} />
              <div>
                <p className="text-h3 text-ink">{person.name}</p>
                <p className="text-small text-ink-secondary">{person.location}</p>
              </div>
            </div>
            <div className="mt-4 border-t border-border pt-4">
              <p className="text-small text-ink-secondary">You and {person.name} are scheduled for</p>
              <p className="mt-1 text-h2 text-ink">
                {chosen.day}, {slot.date}
              </p>
              <p className="text-body text-ink-secondary">
                {slot.time} – {slot.endTime}
              </p>
            </div>
          </div>

          <div className="mt-auto space-y-3 pt-8">
            <Button onClick={confirm}>Confirm</Button>
            <SecondaryButton onClick={() => setChosen(null)}>Pick a different time</SecondaryButton>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar">
        <div className="animate-fade-in-up">
          <h1 className="text-h1 text-ink">{copy.title}</h1>
          <p className="mt-2 text-body text-ink-secondary">{copy.subtitle(person.name)}</p>
        </div>

        {(['Today', 'Tomorrow'] as const).map((day) => (
          <div key={day} className="mt-6">
            <p className="mb-3 text-small font-semibold text-ink-secondary">{day}</p>
            <div className="grid grid-cols-2 gap-3">
              {grouped[day].map((option) => (
                <ScheduleSlot key={option.time} time={option.time} selected={false} onClick={() => setChosen(option)} />
              ))}
            </div>
          </div>
        ))}

        <p className="mt-6 text-small text-ink-muted">
          Every {conversationStage === 'video' ? 'video call' : 'conversation'} is {durationMinutes} minutes.
        </p>
      </div>
    </div>
  )
}
