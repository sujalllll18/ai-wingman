import { useState } from 'react'
import { Avatar } from '../components/Avatar'
import { Button, SecondaryButton, TextButton } from '../components/Button'
import { Modal } from '../components/Modal'
import { TopBar } from '../components/TopBar'
import { WingmanSpeech } from '../components/WingmanSpeech'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

export function UpcomingConversation() {
  const { selectedPersonId, scheduledSlot, setScheduledSlot, setIntroStage, goBack, goTo, goNext } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const [showProfile, setShowProfile] = useState(false)
  const [showTips, setShowTips] = useState(false)
  const [showCancelConfirm, setShowCancelConfirm] = useState(false)

  if (!person || !scheduledSlot) return null

  const startsInCopy =
    scheduledSlot.day === 'Today' ? 'Starts in 24 minutes' : `Tomorrow · ${scheduledSlot.time}`

  const cancelConversation = () => {
    setScheduledSlot(null)
    setIntroStage(person.id, 'new')
    setShowCancelConfirm(false)
    goTo('explore')
  }

  return (
    <div className="relative flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex-1 px-5 pb-6">
        <div className="animate-fade-in-up">
          <h1 className="text-h1 text-ink">You're all set.</h1>
          <p className="mt-2 text-body text-ink-secondary">Your conversation is on the calendar.</p>
        </div>

        <div className="mt-6 overflow-hidden rounded-lg border border-border bg-surface shadow-card">
          <div className="flex items-center gap-3 p-5">
            <Avatar gradientIndex={person.gradientIndex} size={52} />
            <div className="flex-1">
              <p className="text-h3 text-ink">Conversation with {person.name}</p>
              <p className="text-small text-ink-secondary">
                {scheduledSlot.day} · {scheduledSlot.time} · {scheduledSlot.durationMinutes} minutes
              </p>
            </div>
          </div>
          <div className="border-t border-border bg-primary-light/40 px-5 py-3">
            <p className="text-small font-semibold text-primary-dark">{startsInCopy}</p>
          </div>
        </div>

        <div className="mt-5">
          <WingmanSpeech lines={["Don't overthink it. Just be yourself."]} size={44} />
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <SecondaryButton fullWidth={false} onClick={() => setShowProfile(true)}>
            View profile
          </SecondaryButton>
          <SecondaryButton fullWidth={false} onClick={() => setShowTips(true)}>
            Conversation tips
          </SecondaryButton>
          <SecondaryButton fullWidth={false} onClick={() => goTo('scheduling')}>
            Reschedule
          </SecondaryButton>
          <SecondaryButton fullWidth={false} className="!text-error !border-error/40" onClick={() => setShowCancelConfirm(true)}>
            Cancel
          </SecondaryButton>
        </div>

        <div className="mt-8">
          <Button onClick={goNext}>Start conversation</Button>
          <p className="mt-2 text-center text-caption text-ink-muted">
            Prototype note: skips the wait so you can preview the chat now.
          </p>
        </div>
      </div>

      <Modal open={showProfile} onClose={() => setShowProfile(false)} title={`${person.name}, ${person.age}`}>
        <p className="text-small text-ink-secondary">
          {person.location} · {person.profession}
        </p>
        <p className="mt-3 text-body text-ink">{person.bio}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {person.commonInterests.map((interest) => (
            <span key={interest} className="rounded-full border border-border px-3 py-1.5 text-small text-ink-secondary">
              {interest}
            </span>
          ))}
        </div>
        <Button className="mt-5" onClick={() => setShowProfile(false)}>
          Close
        </Button>
      </Modal>

      <Modal open={showTips} onClose={() => setShowTips(false)} title="A few conversation starters">
        <div className="space-y-3">
          {person.openers.map((opener) => (
            <p key={opener} className="rounded-md bg-surface-alt/70 p-3 text-small text-ink">
              {opener}
            </p>
          ))}
        </div>
        <TextButton fullWidth className="mt-4 justify-center" onClick={() => setShowTips(false)}>
          Got it
        </TextButton>
      </Modal>

      <Modal open={showCancelConfirm} onClose={() => setShowCancelConfirm(false)} title="Cancel this conversation?">
        <p className="text-small text-ink-secondary">
          {person.name} will be notified. You can always schedule again later.
        </p>
        <div className="mt-5 space-y-3">
          <SecondaryButton className="!text-error !border-error/40" onClick={cancelConversation}>
            Yes, cancel it
          </SecondaryButton>
          <Button onClick={() => setShowCancelConfirm(false)}>Keep the conversation</Button>
        </div>
      </Modal>
    </div>
  )
}
