import { Button, SecondaryButton } from '../components/Button'
import { WingmanSpeech } from '../components/WingmanSpeech'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

export function TalkOnceMore() {
  const { selectedPersonId, setConversationStage, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)

  if (!person) return null

  const talkAgain = () => {
    setConversationStage('second')
    goTo('scheduling')
  }

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-between px-6 pb-8 pt-24 text-center">
      <div className="flex flex-1 flex-col items-center justify-center animate-fade-in-up">
        <h1 className="text-display text-ink">That's okay.</h1>
        <p className="mt-3 max-w-[300px] text-body text-ink-secondary">
          You don't have to decide after one conversation. A slightly longer chat with {person.name} might make
          things clearer.
        </p>

        <div className="mt-8">
          <WingmanSpeech lines={['Take your time. Some of the best connections take a second conversation to click.']} size={48} />
        </div>
      </div>

      <div className="w-full max-w-[320px] space-y-3">
        <Button onClick={talkAgain}>Talk once more</Button>
        <SecondaryButton onClick={() => goTo('explore')}>Explore other introductions</SecondaryButton>
      </div>
    </div>
  )
}
