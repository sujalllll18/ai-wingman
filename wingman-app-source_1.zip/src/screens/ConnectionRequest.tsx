import { useEffect, useState } from 'react'
import { Avatar } from '../components/Avatar'
import { Button, SecondaryButton } from '../components/Button'
import { WingmanCompanion } from '../components/WingmanCompanion'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

type Step = 'ask' | 'waiting' | 'declined'

export function ConnectionRequest() {
  const { selectedPersonId, setIntroStage, goNext, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const [step, setStep] = useState<Step>('ask')

  useEffect(() => {
    if (step !== 'waiting' || !person) return
    setIntroStage(person.id, 'connection_requested')
    const t = setTimeout(() => {
      setIntroStage(person.id, 'connected')
      goNext()
    }, 1600)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, person?.id])

  if (!person) return null

  const notNow = () => {
    setIntroStage(person.id, 'ended')
    setStep('declined')
  }

  if (step === 'waiting') {
    return (
      <div className="flex h-full min-h-screen flex-col items-center justify-center px-6 text-center">
        <WingmanCompanion size={64} talking />
        <p className="mt-5 text-body text-ink-secondary">Letting {person.name} know you'd like to stay connected…</p>
      </div>
    )
  }

  if (step === 'declined') {
    return (
      <div className="flex h-full min-h-screen flex-col items-center justify-between px-6 pb-8 pt-24 text-center">
        <div className="flex flex-1 flex-col items-center justify-center animate-fade-in-up">
          <h1 className="text-display text-ink">No hard feelings.</h1>
          <p className="mt-3 max-w-[300px] text-body text-ink-secondary">
            Your Wingman will keep this in mind and keep looking for people worth your time.
          </p>
        </div>
        <div className="w-full max-w-[320px]">
          <Button onClick={() => goTo('explore')}>Explore other introductions</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-between px-6 pb-8 pt-24 text-center">
      <div className="flex flex-1 flex-col items-center justify-center animate-fade-in-up">
        <Avatar gradientIndex={person.gradientIndex} size={88} ring />
        <h1 className="mt-6 text-h1 text-ink">Stay connected with {person.name}?</h1>
        <p className="mt-3 max-w-[300px] text-body text-ink-secondary">
          If you both confirm, you'll unlock unlimited chat, video calls, and date planning together.
        </p>
      </div>
      <div className="w-full max-w-[320px] space-y-3">
        <Button onClick={() => setStep('waiting')}>I'd like to stay connected</Button>
        <SecondaryButton onClick={notNow}>Not now</SecondaryButton>
      </div>
    </div>
  )
}
