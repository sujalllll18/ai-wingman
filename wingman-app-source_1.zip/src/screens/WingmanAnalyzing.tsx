import { useEffect, useState } from 'react'
import { WingmanCompanion } from '../components/WingmanCompanion'
import { useOnboarding } from '../state/OnboardingContext'

const STEPS = ['Wrapping up your vibe profile', 'Preparing your Wingman', 'Almost there']

const STEP_DURATION = 650

export function WingmanAnalyzing() {
  const { goNext } = useOnboarding()
  const [completed, setCompleted] = useState(0)

  useEffect(() => {
    if (completed >= STEPS.length) {
      const t = setTimeout(goNext, 400)
      return () => clearTimeout(t)
    }
    const t = setTimeout(() => setCompleted((c) => c + 1), STEP_DURATION)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [completed])

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-center gap-8 px-8">
      <WingmanCompanion size={64} talking />
      <div className="w-full max-w-[280px] space-y-3">
        {STEPS.map((step, i) => (
          <div
            key={step}
            className={`flex items-center gap-3 transition-opacity duration-300 ${
              i <= completed ? 'opacity-100' : 'opacity-30'
            }`}
          >
            <span
              className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-caption transition-colors ${
                i < completed
                  ? 'border-primary bg-primary text-white'
                  : i === completed
                    ? 'border-primary text-primary'
                    : 'border-border text-transparent'
              }`}
            >
              {i < completed ? '✓' : ''}
            </span>
            <span className="text-small text-ink-secondary">{step}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
