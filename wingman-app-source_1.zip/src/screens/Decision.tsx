import { useState } from 'react'
import { Button, SecondaryButton } from '../components/Button'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'
import type { DecisionOutcome, PostSecondOutcome } from '../types/journey'

const FIRST_OPTIONS: { outcome: DecisionOutcome; emoji: string; label: string }[] = [
  { outcome: 'continue', emoji: '❤️', label: "I'd like to continue" },
  { outcome: 'unsure', emoji: '🤔', label: "I'm not sure yet" },
  { outcome: 'end', emoji: '👋', label: "I don't think it's a fit" },
]

const SECOND_OPTIONS: { outcome: PostSecondOutcome; emoji: string; label: string }[] = [
  { outcome: 'continue', emoji: '💬', label: "I'd like to continue" },
  { outcome: 'video', emoji: '🎥', label: 'Schedule a video call' },
  { outcome: 'end', emoji: '👋', label: "I don't think it's a fit" },
]

export function Decision() {
  const { selectedPersonId, conversationStage, setConversationStage, setIntroStage, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const [outcome, setOutcome] = useState<DecisionOutcome | PostSecondOutcome | null>(null)
  const isSecond = conversationStage === 'second'

  if (!person) return null

  const goToSecondScheduling = () => {
    setConversationStage('second')
    goTo('scheduling')
  }

  const goToVideoScheduling = () => {
    setConversationStage('video')
    goTo('scheduling')
  }

  const handleSelect = (value: DecisionOutcome | PostSecondOutcome) => {
    setOutcome(value)
    if (value === 'end') setIntroStage(person.id, 'ended')
  }

  // What the primary button on the outcome screen actually does, per outcome.
  const primaryAction = (() => {
    if (outcome === 'end') return { label: 'Explore other introductions', onClick: () => goTo('explore') }
    if (!isSecond && outcome === 'unsure') return { label: 'Talk once more', onClick: () => goTo('talkOnceMore') }
    if (!isSecond && outcome === 'continue') return { label: 'Schedule your next conversation', onClick: goToSecondScheduling }
    if (isSecond && (outcome === 'continue' || outcome === 'video')) {
      return { label: 'Schedule video call', onClick: goToVideoScheduling }
    }
    return { label: 'Continue', onClick: () => goTo('explore') }
  })()

  if (outcome) {
    return (
      <Outcome outcome={outcome} isSecond={isSecond} personName={person.name} primaryAction={primaryAction} onExploreAnother={() => goTo('explore')} />
    )
  }

  const options = isSecond ? SECOND_OPTIONS : FIRST_OPTIONS

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-center px-6 text-center">
      <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">
        Your conversation with {person.name} has ended
      </p>
      <h1 className="mt-2 text-h1 text-ink">{isSecond ? 'Want to take the next step?' : 'How did that feel?'}</h1>
      <p className="mt-2 max-w-[300px] text-body text-ink-secondary">
        There's no wrong answer here — take your time.
      </p>

      <div className="mt-8 w-full max-w-[320px] space-y-3">
        {options.map((option) => (
          <button
            key={option.outcome}
            onClick={() => handleSelect(option.outcome)}
            className="flex w-full items-center gap-4 rounded-md border border-border bg-surface px-4 py-4 text-left transition-colors hover:border-primary/40 active:scale-[0.99]"
          >
            <span className="text-2xl leading-none">{option.emoji}</span>
            <span className="text-body font-medium text-ink">{option.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

function Outcome({
  outcome,
  isSecond,
  personName,
  primaryAction,
  onExploreAnother,
}: {
  outcome: DecisionOutcome | PostSecondOutcome
  isSecond: boolean
  personName: string
  primaryAction: { label: string; onClick: () => void }
  onExploreAnother: () => void
}) {
  const copy = {
    continue: isSecond
      ? {
          title: "That's great to hear.",
          body: `You've let your Wingman know you'd like to keep talking to ${personName}. Next up: a private video call before deciding whether to stay connected.`,
          note: 'Video calls happen before any permanent connection — for everyone’s comfort and safety.',
        }
      : {
          title: "That's great to hear.",
          body: `You've let your Wingman know you'd like to keep talking to ${personName}. If they feel the same, you'll both move to a second, slightly longer conversation.`,
          note: 'Coming next: a second conversation, then a video call once you’re both ready.',
        },
    unsure: {
      title: "That's okay.",
      body: "You don't have to decide after one conversation. Some of the best connections take a little longer to find their footing.",
      note: 'Coming next: an easy way to schedule a second, slightly longer conversation.',
    },
    video: {
      title: 'Sounds good.',
      body: `Your Wingman will help you and ${personName} find a time for a private video call.`,
      note: 'Video calls happen before any permanent connection — for everyone’s comfort and safety.',
    },
    end: {
      title: 'No hard feelings.',
      body: `Thanks for giving it a shot. Your Wingman will keep this in mind and keep looking for people worth your time.`,
      note: 'You still have other active introductions to explore.',
    },
  }[outcome]

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-between px-6 pb-8 pt-24 text-center">
      <div className="flex flex-1 flex-col items-center justify-center animate-fade-in-up">
        <h1 className="text-display text-ink">{copy.title}</h1>
        <p className="mt-3 max-w-[300px] text-body text-ink-secondary">{copy.body}</p>

        <div className="mt-8 w-full max-w-[320px] rounded-lg border border-border bg-surface p-4 text-left shadow-card">
          <p className="text-caption font-semibold uppercase tracking-wide text-primary">What's next</p>
          <p className="mt-1.5 text-small text-ink-secondary">{copy.note}</p>
        </div>
      </div>

      <div className="w-full max-w-[320px] space-y-3">
        <Button onClick={primaryAction.onClick}>{primaryAction.label}</Button>
        {outcome !== 'end' && <SecondaryButton onClick={onExploreAnother}>Explore other introductions</SecondaryButton>}
      </div>
    </div>
  )
}
