import { useEffect, useState, type ReactNode } from 'react'
import { Button, TextButton } from '../components/Button'
import { TopBar } from '../components/TopBar'
import { useOnboarding } from '../state/OnboardingContext'

// Verification is now an optional, non-blocking side-quest reachable from
// Home/Profile — never a gate the user has to clear before using the
// product. This screen is entered via goTo('verification') from those
// cards, never from the automatic onboarding chain (see flow.ts: Compatibility
// Test -> WingmanAnalyzing -> ProfileReady -> Home, with Verification off
// to the side). It always hands the user back to Home when done, regardless
// of where they started from.

type Step = 'choose' | 'verifying' | 'done'

interface Method {
  id: string
  label: string
  helper: string
  icon: ReactNode
}

const METHODS: Method[] = [
  { id: 'linkedin', label: 'LinkedIn', helper: 'Verify with your professional profile', icon: <LinkedInIcon /> },
  { id: 'license', label: 'Driving Licence', helper: 'Government-issued licence', icon: <CardIcon /> },
  { id: 'passport', label: 'Passport', helper: 'Government-issued passport', icon: <PassportIcon /> },
  { id: 'other', label: 'Other supported ID', helper: 'Any other accepted government ID', icon: <CardIcon /> },
]

export function Verification() {
  const { updateProfile, goBack, goTo } = useOnboarding()
  const [step, setStep] = useState<Step>('choose')
  const [method, setMethod] = useState<Method | null>(null)

  useEffect(() => {
    if (step !== 'verifying') return
    // Simulated check only — no real document or identity verification
    // happens in this prototype.
    updateProfile({ verificationStatus: 'in_review' })
    const t = setTimeout(() => {
      updateProfile({ verificationStatus: 'verified' })
      setStep('done')
    }, 1400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step])

  const choose = (m: Method) => {
    setMethod(m)
    setStep('verifying')
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={step === 'choose' ? goBack : undefined} />

      {step === 'choose' && (
        <div className="flex-1 overflow-y-auto px-5 pb-6 pt-2 no-scrollbar animate-fade-in-up">
          <p className="text-caption font-semibold uppercase tracking-wide text-primary">Optional · takes under a minute</p>
          <h1 className="mt-1.5 text-h1 text-ink">Choose how you'd like to verify</h1>
          <p className="mt-2 text-body text-ink-secondary">
            Verification helps build trust and can unlock more conversation opportunities. You can always do this
            later.
          </p>

          <div className="mt-6 space-y-2.5">
            {METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => choose(m)}
                className="flex w-full items-center gap-4 rounded-lg border border-border bg-surface p-4 text-left transition-colors hover:border-primary/40 active:scale-[0.99]"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary-light/60 text-primary">
                  {m.icon}
                </span>
                <div className="flex-1">
                  <p className="text-body font-medium text-ink">{m.label}</p>
                  <p className="text-small text-ink-secondary">{m.helper}</p>
                </div>
                <span className="text-ink-muted">→</span>
              </button>
            ))}
          </div>

          <div className="mt-6 flex items-start gap-2.5 rounded-lg border border-border bg-surface-alt/50 p-4">
            <span className="mt-0.5 shrink-0 text-secondary">
              <ShieldIcon />
            </span>
            <div>
              <p className="text-small text-ink">Your document is used only to verify that you're a real person.</p>
              <p className="mt-1 text-small text-ink-secondary">We don't store your identity document.</p>
            </div>
          </div>
        </div>
      )}

      {step === 'verifying' && method && (
        <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center animate-fade-in-up">
          <span className="flex h-14 w-14 items-center justify-center rounded-full border border-border bg-surface shadow-card">
            <span className="h-6 w-6 animate-spin rounded-full border-2 border-ink/15 border-t-primary" />
          </span>
          <div>
            <p className="text-body font-medium text-ink">Verifying with {method.label}...</p>
            <p className="mt-1 text-small text-ink-secondary">Just a moment — this is a simulated check.</p>
          </div>
        </div>
      )}

      {step === 'done' && (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 px-8 text-center animate-fade-in-up">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary text-white shadow-pop animate-scale-in">
            <CheckIcon size={26} />
          </span>
          <h1 className="mt-2 text-h1 text-ink">You're verified ✓</h1>
          <p className="max-w-[280px] text-body text-ink-secondary">
            Your profile now has an extra layer of trust.
          </p>
        </div>
      )}

      <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
        {step === 'done' ? (
          <Button onClick={() => goTo('home')}>Continue</Button>
        ) : (
          <TextButton fullWidth onClick={() => goTo('home')} className="justify-center">
            I'll do this later
          </TextButton>
        )}
      </div>
    </div>
  )
}

function ShieldIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 3l7 3v5.5c0 4.5-3 8-7 9.5-4-1.5-7-5-7-9.5V6l7-3z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M9 12l2 2 4-4.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function CardIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="9" cy="11" r="2" stroke="currentColor" strokeWidth="1.7" />
      <path d="M6 16c0-1.5 1.3-2.5 3-2.5s3 1 3 2.5M14 10h4M14 14h3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function PassportIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="12" cy="10" r="2.6" stroke="currentColor" strokeWidth="1.7" />
      <path d="M8.5 16.5c0-1.8 1.6-3 3.5-3s3.5 1.2 3.5 3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function LinkedInIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="3" width="18" height="18" rx="3" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="8" cy="8.2" r="1.3" fill="currentColor" />
      <path d="M8 11v6M12 17v-3.5c0-1.4 1-2.5 2.3-2.5s2.2 1 2.2 2.5V17" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
