import { Button } from '../components/Button'
import { SparkleIcon, VibeAvatar } from '../components/VibeAvatar'
import { useOnboarding } from '../state/OnboardingContext'

// The positive completion moment right after the Compatibility Test —
// replaces the old flow where the very next screen forced ID verification.
// Verification is now entirely optional and lives inside Home/Profile
// instead (see Home.tsx's verification card and the rebuilt
// Verification.tsx). This screen's only job is to celebrate a finished
// Vibe Profile and hand the user straight into the product.
export function ProfileReady() {
  const { goTo } = useOnboarding()

  return (
    <div className="relative flex h-full min-h-screen flex-col items-center justify-center overflow-hidden bg-bg px-6 text-center">
      <div
        className="absolute inset-0 opacity-70"
        style={{
          background: 'radial-gradient(circle at 50% 28%, var(--color-primary-light), transparent 62%)',
        }}
      />
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background: 'radial-gradient(circle at 78% 68%, var(--color-secondary-light), transparent 55%)',
        }}
      />

      <div className="relative flex flex-col items-center">
        <div className="relative animate-scale-in">
          <VibeAvatar completion={100} size={172} />
          {CELEBRATION_SPARKLES.map((s, i) => (
            <div
              key={i}
              className="vibe-sparkle absolute text-primary"
              style={{ left: s.left, top: s.top, animationDelay: `${i * 0.35}s` }}
            >
              <SparkleIcon size={s.size} />
            </div>
          ))}
        </div>

        <h1 className="mt-7 max-w-[300px] text-h1 text-ink animate-fade-in-up">Your Vibe Profile is ready 🎉</h1>
        <p className="mt-3 max-w-[300px] text-body text-ink-secondary animate-fade-in-up">
          Your Wingman now understands your personality, interests and compatibility style.
        </p>

        <div className="mt-9 w-full max-w-[320px] animate-fade-in-up">
          <Button onClick={() => goTo('home')}>Meet people</Button>
        </div>
      </div>
    </div>
  )
}

const CELEBRATION_SPARKLES = [
  { left: '-6%', top: '10%', size: 20 },
  { left: '100%', top: '18%', size: 16 },
  { left: '-2%', top: '78%', size: 14 },
  { left: '98%', top: '74%', size: 20 },
]
