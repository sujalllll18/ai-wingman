import { useEffect, useState } from 'react'
import { Button, TextButton } from '../components/Button'
import { OTPInput } from '../components/OTPInput'
import { Toast } from '../components/Toast'
import { TopBar } from '../components/TopBar'
import { MOCK_OTP_CODE, mockSendOtp, mockVerifyOtp, type OtpChannel } from '../data/mockAuth'
import { useOnboarding } from '../state/OnboardingContext'

const RESEND_SECONDS = 30

export function OtpVerify() {
  const { profile, updateProfile, goNext, goBack } = useOnboarding()
  const [channel, setChannel] = useState<OtpChannel>('sms')
  const [code, setCode] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [error, setError] = useState(false)
  const [secondsLeft, setSecondsLeft] = useState(RESEND_SECONDS)
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (secondsLeft <= 0) return
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [secondsLeft])

  useEffect(() => {
    if (code.length === 4) handleVerify(code)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code])

  const showToast = (message: string) => {
    setToast(message)
    setTimeout(() => setToast(''), 2200)
  }

  const handleResend = async (nextChannel?: OtpChannel) => {
    const useChannel = nextChannel ?? channel
    setSecondsLeft(RESEND_SECONDS)
    setError(false)
    await mockSendOtp(profile.phoneNumber, useChannel)
    showToast(`Code sent via ${useChannel === 'sms' ? 'SMS' : 'WhatsApp'}`)
  }

  const handleVerify = async (value: string) => {
    setVerifying(true)
    setError(false)
    const result = await mockVerifyOtp(value)
    setVerifying(false)
    if (result.success) {
      updateProfile({ phoneVerified: true })
      goNext()
    } else {
      setError(true)
    }
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <Toast message={toast} visible={!!toast} />
      <div className="flex flex-1 flex-col px-6 pb-8 pt-4">
        <div className="animate-fade-in-up">
          <h1 className="text-h1 text-ink">Enter the code we sent you.</h1>
          <p className="mt-2 text-body text-ink-secondary">
            Sent to <span className="text-ink font-medium">+91 {profile.phoneNumber || '98765 43210'}</span>
          </p>
          <p className="mt-1 text-caption text-ink-muted">Prototype hint: the code is {MOCK_OTP_CODE}</p>
        </div>

        <div className="mt-8">
          <OTPInput value={code} onChange={setCode} error={error} />
          {error && <p className="mt-3 text-small text-error">That code didn't match. Try again.</p>}
        </div>

        <div className="mt-6 flex items-center gap-2 rounded-full bg-surface-alt p-1 w-fit">
          {(['sms', 'whatsapp'] as OtpChannel[]).map((c) => (
            <button
              key={c}
              onClick={() => {
                setChannel(c)
                handleResend(c)
              }}
              className={`rounded-full px-4 py-2 text-small font-medium transition-colors ${
                channel === c ? 'bg-surface text-ink shadow-card' : 'text-ink-secondary'
              }`}
            >
              {c === 'sms' ? 'Text me' : 'WhatsApp me'}
            </button>
          ))}
        </div>

        <div className="mt-auto pt-8">
          <div className="flex items-center justify-center gap-4">
            {secondsLeft > 0 ? (
              <p className="text-center text-small text-ink-muted">Resend OTP in 0:{String(secondsLeft).padStart(2, '0')}</p>
            ) : (
              <TextButton onClick={() => handleResend()}>Resend OTP</TextButton>
            )}
            <span className="text-border">·</span>
            <TextButton onClick={goBack}>Change number</TextButton>
          </div>
          <div className="mt-4">
            <Button onClick={() => handleVerify(code)} disabled={code.length < 4} loading={verifying}>
              Verify
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
