import { Avatar } from '../components/Avatar'
import { Button, SecondaryButton } from '../components/Button'
import { WingmanCompanion } from '../components/WingmanCompanion'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

export function ConnectionEstablished() {
  const { selectedPersonId, goNext, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)

  if (!person) return null

  return (
    <div className="relative flex h-full min-h-screen flex-col overflow-hidden bg-ink text-white">
      <div
        className="absolute inset-0 opacity-50"
        style={{ background: 'radial-gradient(circle at 50% 30%, var(--color-secondary), transparent 65%)' }}
      />

      <div className="relative flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div className="flex items-center animate-fade-in-up" style={{ gap: -8 }}>
          <Avatar gradientIndex={person.gradientIndex} size={80} ring />
          <div
            className="-ml-4 flex items-center justify-center rounded-full bg-primary shadow-pop"
            style={{ height: 80, width: 80 }}
          >
            <WingmanCompanion size={44} />
          </div>
        </div>

        <h1 className="mt-7 text-display text-white animate-fade-in-up">You're connected.</h1>
        <p className="mt-3 max-w-[300px] text-body text-white/75 animate-fade-in-up">
          You and {person.name} both confirmed. Unlimited chat, video calls, and date planning are open now — no
          more timers.
        </p>
      </div>

      <div className="relative px-6 pb-8 space-y-3">
        <Button onClick={goNext}>Start chatting</Button>
        <SecondaryButton className="!border-white/20 !text-white" onClick={() => goTo('connections')}>
          View my connections
        </SecondaryButton>
      </div>
    </div>
  )
}
