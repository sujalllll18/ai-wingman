import { Button, TextButton } from '../components/Button'
import { TopBar } from '../components/TopBar'
import { VibeAvatar } from '../components/VibeAvatar'
import { COMPATIBILITY_QUESTIONS } from '../data/compatibilityQuestions'
import { useOnboarding } from '../state/OnboardingContext'

// Transition screen shown right after "Your Story" and before the
// Compatibility Test. Purely a motivating stopover — it doesn't touch
// vibeCompletion itself, it just routes the user to either the existing
// Compatibility Test screen ('compatibility') or straight to the existing
// Verification screen ('verification'), skipping the test.
//
// The header shows the user's *actual* current profile completion (via
// VibeAvatar + profile.vibeCompletion) rather than a hardcoded "50%" —
// at this point in the flow that's 75%, since "Your Story" itself already
// advances the profile from 50% to 75% before handing off here. Using the
// live value keeps the avatar ring and the percentage label consistent
// with every other screen instead of contradicting them.
export function CompatibilityIntro() {
  const { profile, goBack, goTo } = useOnboarding()

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />

      <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar animate-fade-in-up">
        <div className="flex flex-col items-center pt-1 pb-5 text-center">
          <VibeAvatar completion={profile.vibeCompletion} size={128} />
          <p className="mt-4 text-caption font-semibold uppercase tracking-[0.14em] text-ink-muted">
            Your Vibe Profile
          </p>
          <p className="mt-1 text-h2 text-primary">{profile.vibeCompletion}% complete</p>
        </div>

        <h1 className="text-center text-h1 text-ink">One last thing before you're verified.</h1>
        <p className="mt-2.5 text-center text-body text-ink-secondary">
          Complete your Compatibility Test so your Wingman can understand your compatibility style and find
          better conversations for you.
        </p>

        {/* Main benefit — the fast path is visually the hero, the skip path
            is still fully welcoming, just quieter. */}
        <div className="mt-7 space-y-3">
          <div className="relative overflow-hidden rounded-lg border-2 border-primary bg-gradient-to-br from-primary-light/50 via-surface to-surface p-5 shadow-pop">
            <div
              className="absolute -right-8 -top-10 h-32 w-32 rounded-full opacity-40 blur-2xl"
              style={{ background: 'radial-gradient(circle, var(--color-primary), transparent 70%)' }}
            />
            <div className="relative flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-white shadow-card">
                <BoltIcon />
              </span>
              <div>
                <p className="text-caption font-bold uppercase tracking-wide text-primary-dark">
                  Complete Compatibility Test
                </p>
                <p className="mt-1 text-h3 text-ink">Verification in ~59 seconds</p>
                <p className="mt-1 text-small text-ink-secondary">
                  Fast-tracked review, straight to the front of the line.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 px-1">
            <span className="h-px flex-1 bg-border" />
            <span className="text-caption font-medium text-ink-muted">or</span>
            <span className="h-px flex-1 bg-border" />
          </div>

          <div className="rounded-lg border border-border bg-surface p-4">
            <p className="text-small font-semibold text-ink">Skip for now</p>
            <p className="mt-0.5 text-small text-ink-muted">Verification may take up to 3 working days.</p>
          </div>
        </div>

        {/* What the test actually is */}
        <div className="mt-6 rounded-lg border border-border bg-surface-alt/50 p-4">
          <p className="text-body font-semibold text-ink">15 quick questions.</p>
          <p className="mt-1 text-small text-ink-secondary">
            Your answers help your Wingman understand what matters to you in a connection.
          </p>
          <div className="mt-3.5 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-primary/30 bg-primary-light/40 px-3 py-1.5 text-caption font-semibold text-primary-dark">
              {COMPATIBILITY_QUESTIONS.length} questions
            </span>
            {['Yes', 'No', 'Depends'].map((label) => (
              <span key={label} className="rounded-full border border-border bg-surface px-3 py-1.5 text-caption font-medium text-ink-secondary">
                {label}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
        <Button onClick={() => goTo('compatibility')}>Complete Compatibility Test →</Button>
        <div className="mt-1 flex justify-center">
          <TextButton onClick={() => goTo('verification')}>I'll wait for verification</TextButton>
        </div>
      </div>
    </div>
  )
}

function BoltIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" fill="currentColor" />
    </svg>
  )
}
