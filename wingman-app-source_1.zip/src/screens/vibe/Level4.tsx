import { useState } from 'react'
import { LevelUpOverlay } from '../../components/LevelUpOverlay'
import { ProgressIndicator } from '../../components/ProgressIndicator'
import { TopBar } from '../../components/TopBar'
import { COMPATIBILITY_QUESTIONS } from '../../data/compatibilityQuestions'
import { useOnboarding } from '../../state/OnboardingContext'
import type { CompatibilityAnswer } from '../../types/profile'

const ANSWER_OPTIONS: { value: CompatibilityAnswer; label: string }[] = [
  { value: 'yes', label: 'Yes' },
  { value: 'no', label: 'No' },
  { value: 'depends', label: 'Depends' },
]

export function Level4() {
  const { profile, updateProfile, goBack, goNext } = useOnboarding()
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string, CompatibilityAnswer>>(profile.compatibilityAnswers)
  const [showLevelUp, setShowLevelUp] = useState(false)

  const question = COMPATIBILITY_QUESTIONS[index]
  const total = COMPATIBILITY_QUESTIONS.length

  const answer = (value: CompatibilityAnswer) => {
    const next = { ...answers, [question.id]: value }
    setAnswers(next)
    if (index + 1 < total) {
      setTimeout(() => setIndex(index + 1), 180)
    } else {
      updateProfile({ compatibilityAnswers: next, vibeCompletion: 100 })
      setTimeout(() => setShowLevelUp(true), 250)
    }
  }

  return (
    <div className="relative min-h-screen">
      <div className="flex h-full min-h-screen flex-col">
        <TopBar onBack={index === 0 ? goBack : () => setIndex((i) => Math.max(0, i - 1))} />
        <div className="px-5 pb-2">
          <ProgressIndicator step={index + 1} total={total} />
        </div>

        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">
            15 things your Wingman should know
          </p>
          <h1 key={question.id} className="mt-4 max-w-[300px] text-h1 text-ink animate-fade-in-up">
            {question.text}
          </h1>

          <div className="mt-8 flex w-full max-w-[300px] flex-col gap-3">
            {ANSWER_OPTIONS.map((option) => (
              <button
                key={option.value}
                onClick={() => answer(option.value)}
                className={`w-full rounded-full border px-6 py-3.5 text-body font-medium transition-colors active:scale-[0.98] ${
                  answers[question.id] === option.value
                    ? 'border-primary bg-primary text-white'
                    : 'border-border bg-surface text-ink hover:border-primary/40'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {showLevelUp && (
        <LevelUpOverlay
          toCompletion={100}
          wingmanLine="I know your vibe. Now let me find someone worth talking to."
          onDone={goNext}
          durationMs={2600}
        />
      )}
    </div>
  )
}
