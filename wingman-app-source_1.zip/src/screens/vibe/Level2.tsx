import { useState, type ReactNode } from 'react'
import { Button } from '../../components/Button'
import { Chip } from '../../components/Chip'
import { LevelUpOverlay } from '../../components/LevelUpOverlay'
import { TextInput } from '../../components/TextInput'
import { VibeLevelScreen } from '../../components/VibeLevelScreen'
import { INTEREST_OPTIONS, RELATIONSHIP_INTENTION_OPTIONS } from '../../data/onboardingOptions'
import { LIFESTYLE_OPTIONS, SOCIAL_STYLE_OPTIONS } from '../../data/vibeOptions'
import { useOnboarding } from '../../state/OnboardingContext'
import type { RelationshipIntention, SocialStyle } from '../../types/profile'

const MIN_INTERESTS = 3
const DEFAULT_MIN_AGE = 24
const DEFAULT_MAX_AGE = 34

export function Level2() {
  const { profile, updateProfile, goBack, goNext } = useOnboarding()

  const [location, setLocation] = useState(profile.location || 'Mumbai')
  const [intention, setIntention] = useState<RelationshipIntention | null>(profile.relationshipIntention)
  const [interests, setInterests] = useState<string[]>(profile.interests)
  const [socialStyle, setSocialStyle] = useState<SocialStyle | null>(profile.socialStyle)
  const [lifestyle, setLifestyle] = useState<string[]>(profile.lifestyle)
  const [minAge, setMinAge] = useState(profile.ageRangeMin ?? DEFAULT_MIN_AGE)
  const [maxAge, setMaxAge] = useState(profile.ageRangeMax ?? DEFAULT_MAX_AGE)
  const [showLevelUp, setShowLevelUp] = useState(false)

  const toggleInterest = (v: string) =>
    setInterests((prev) => (prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]))
  const toggleLifestyle = (v: string) =>
    setLifestyle((prev) => (prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]))

  const isValid =
    location.trim().length >= 2 && !!intention && interests.length >= MIN_INTERESTS && !!socialStyle && lifestyle.length >= 2

  const handleContinue = () => {
    updateProfile({
      location: location.trim(),
      relationshipIntention: intention,
      interests,
      socialStyle,
      lifestyle,
      ageRangeMin: minAge,
      ageRangeMax: maxAge,
      vibeCompletion: 50,
    })
    setShowLevelUp(true)
  }

  return (
    <div className="relative min-h-screen">
      <VibeLevelScreen
        completion={25}
        title="Let's understand your world."
        subtitle="A little more, so your Wingman can find people who actually fit."
        onBack={goBack}
        footer={
          <Button onClick={handleContinue} disabled={!isValid}>
            Continue
          </Button>
        }
      >
        <div className="space-y-7">
          <section>
            <SectionLabel>Location</SectionLabel>
            <TextInput id="location" value={location} onChange={(e) => setLocation(e.target.value)} />
          </section>

          <section>
            <SectionLabel>Preferred age range</SectionLabel>
            <div className="flex items-center gap-3">
              <Stepper value={minAge} onChange={(v) => setMinAge(Math.min(v, maxAge))} min={18} max={maxAge} />
              <span className="text-ink-muted">to</span>
              <Stepper value={maxAge} onChange={(v) => setMaxAge(Math.max(v, minAge))} min={minAge} max={60} />
            </div>
          </section>

          <section>
            <SectionLabel>Relationship intention</SectionLabel>
            <div className="flex flex-wrap gap-2">
              {RELATIONSHIP_INTENTION_OPTIONS.map((o) => (
                <Chip key={o.value} selected={intention === o.value} onClick={() => setIntention(o.value as RelationshipIntention)}>
                  {o.label}
                </Chip>
              ))}
            </div>
          </section>

          <section>
            <SectionLabel>Social style — how do you usually like to meet people?</SectionLabel>
            <div className="flex flex-wrap gap-2">
              {SOCIAL_STYLE_OPTIONS.map((o) => (
                <Chip key={o.value} selected={socialStyle === o.value} onClick={() => setSocialStyle(o.value)}>
                  {o.label}
                </Chip>
              ))}
            </div>
          </section>

          <section>
            <SectionLabel>Lifestyle — pick at least 2</SectionLabel>
            <div className="flex flex-wrap gap-2">
              {LIFESTYLE_OPTIONS.map((v) => (
                <Chip key={v} selected={lifestyle.includes(v)} onClick={() => toggleLifestyle(v)}>
                  {v}
                </Chip>
              ))}
            </div>
          </section>

          <section>
            <SectionLabel>Interests — pick at least {MIN_INTERESTS}</SectionLabel>
            <div className="flex flex-wrap gap-2">
              {INTEREST_OPTIONS.map((v) => (
                <Chip key={v} selected={interests.includes(v)} onClick={() => toggleInterest(v)}>
                  {v}
                </Chip>
              ))}
            </div>
          </section>
        </div>
      </VibeLevelScreen>

      {showLevelUp && (
        <LevelUpOverlay
          toCompletion={50}
          wingmanLine="Okay... I'm starting to get your vibe."
          onDone={goNext}
        />
      )}
    </div>
  )
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="mb-2.5 text-caption font-semibold uppercase tracking-wide text-ink-muted">{children}</p>
}

function Stepper({ value, onChange, min, max }: { value: number; onChange: (v: number) => void; min: number; max: number }) {
  return (
    <div className="flex h-12 flex-1 items-center justify-between rounded-md border border-border bg-surface px-3">
      <button
        type="button"
        onClick={() => onChange(Math.max(min, value - 1))}
        className="flex h-8 w-8 items-center justify-center rounded-full text-h3 text-ink-secondary active:scale-90"
      >
        −
      </button>
      <span className="text-body font-semibold text-ink tabular-nums">{value}</span>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, value + 1))}
        className="flex h-8 w-8 items-center justify-center rounded-full text-h3 text-ink-secondary active:scale-90"
      >
        +
      </button>
    </div>
  )
}
