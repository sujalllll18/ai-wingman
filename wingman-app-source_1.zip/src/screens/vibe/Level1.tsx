import { useMemo, useState, type ReactNode } from 'react'
import { Button } from '../../components/Button'
import { Chip } from '../../components/Chip'
import { LevelUpOverlay } from '../../components/LevelUpOverlay'
import { PhotoSlot } from '../../components/PhotoSlot'
import { TextInput } from '../../components/TextInput'
import { TopBar } from '../../components/TopBar'
import { VibeAvatar } from '../../components/VibeAvatar'
import { GENDER_OPTIONS, INTERESTED_IN_OPTIONS } from '../../data/onboardingOptions'
import { COMMUNICATION_STYLE_OPTIONS } from '../../data/vibeOptions'
import { useOnboarding } from '../../state/OnboardingContext'
import type { CommunicationStyle, Gender, InterestedIn } from '../../types/profile'

const PHOTO_SLOT_COUNT = 4
const STAGES = ['Basics', 'Your World', 'Your Story', 'Compatibility']

function parseDob(value: string) {
  if (!value) return { day: '', month: '', year: '' }
  const [year, month, day] = value.split('-')
  return { day: day ?? '', month: month ?? '', year: year ?? '' }
}

export function Level1() {
  const { profile, updateProfile, goBack, goNext } = useOnboarding()
  const initialDob = parseDob(profile.dateOfBirth)

  const initialPhotos = profile.photos.filter((p) => !p.startsWith('mock-selfie-'))
  const initialSelfie = profile.photos.find((p) => p.startsWith('mock-selfie-')) ?? null

  const [photos, setPhotos] = useState<(string | null)[]>(() => {
    const arr = Array.from({ length: PHOTO_SLOT_COUNT }, (_, i) => initialPhotos[i] ?? null)
    return arr
  })
  const [selfie, setSelfie] = useState<string | null>(initialSelfie)
  const [capturingSelfie, setCapturingSelfie] = useState(false)

  const [name, setName] = useState(profile.name)
  const [day, setDay] = useState(initialDob.day)
  const [month, setMonth] = useState(initialDob.month)
  const [year, setYear] = useState(initialDob.year)
  const [gender, setGender] = useState<Gender | null>(profile.gender)
  const [interestedIn, setInterestedIn] = useState<InterestedIn[]>(profile.interestedIn)
  const [profession, setProfession] = useState(profile.profession)
  const [communicationStyle, setCommunicationStyle] = useState<CommunicationStyle | null>(profile.communicationStyle)
  const [showLevelUp, setShowLevelUp] = useState(false)

  const [photosOpen, setPhotosOpen] = useState(true)
  const [infoOpen, setInfoOpen] = useState(false)

  const age = useMemo(() => {
    if (!day || !month || year.length !== 4) return null
    const dob = new Date(Number(year), Number(month) - 1, Number(day))
    if (Number.isNaN(dob.getTime())) return null
    const today = new Date()
    let a = today.getFullYear() - dob.getFullYear()
    const monthDiff = today.getMonth() - dob.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) a--
    return a
  }, [day, month, year])

  const dobValid = age !== null && age >= 18 && age < 100
  const toggleInterestedIn = (v: InterestedIn) =>
    setInterestedIn((prev) => (prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]))

  const photosFilledCount = photos.filter(Boolean).length
  const infoChecklist = [
    name.trim().length >= 2,
    dobValid,
    !!gender,
    interestedIn.length > 0,
    profession.trim().length >= 2,
    !!communicationStyle,
  ]
  const infoFilledCount = infoChecklist.filter(Boolean).length

  const TOTAL_ITEMS = PHOTO_SLOT_COUNT + 1 + infoChecklist.length // 4 photos + selfie + 6 info fields
  const filledItems = photosFilledCount + (selfie ? 1 : 0) + infoFilledCount
  const livePct = Math.round((filledItems / TOTAL_ITEMS) * 25)

  const isValid = photosFilledCount === PHOTO_SLOT_COUNT && !!selfie && infoFilledCount === infoChecklist.length

  const captureSelfie = () => {
    if (capturingSelfie || selfie) return
    setCapturingSelfie(true)
    setTimeout(() => {
      setSelfie(`mock-selfie-${Date.now()}`)
      setCapturingSelfie(false)
    }, 1100)
  }

  const handleContinue = () => {
    const finalPhotos = [...photos.filter((p): p is string => !!p), ...(selfie ? [selfie] : [])]
    updateProfile({
      photos: finalPhotos,
      name: name.trim(),
      dateOfBirth: `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`,
      gender,
      interestedIn,
      profession: profession.trim(),
      communicationStyle,
      vibeCompletion: 25,
    })
    setShowLevelUp(true)
  }

  return (
    <div className="relative min-h-screen">
      <div className="flex h-full min-h-screen flex-col">
        <TopBar onBack={goBack} />

        <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar animate-fade-in-up">
          {/* Vibe Profile hero — the character being built */}
          <div className="flex flex-col items-center pt-1 pb-5 text-center">
            <AvatarWithRing percent={livePct} stageMax={25} />
            <p className="mt-4 text-caption font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Your Vibe Profile
            </p>
            <p className="mt-1 text-display text-ink">{livePct}% complete</p>
            <p className="mt-1.5 max-w-[260px] text-small text-ink-secondary">
              You're building your character. Your Wingman is getting to know you as you go.
            </p>
          </div>

          {/* Four-stage progress */}
          <div className="mb-6 overflow-hidden rounded-lg border border-border bg-surface">
            {STAGES.map((stage, i) => {
              const stagePct = i === 0 ? livePct : Math.max(0, Math.min(25, profile.vibeCompletion - i * 25))
              const active = i === 0
              return (
                <div
                  key={stage}
                  className={`flex items-center justify-between px-4 py-3 text-small ${
                    active ? 'bg-primary-light/40' : ''
                  } ${i !== STAGES.length - 1 ? 'border-b border-border' : ''}`}
                >
                  <span className={`flex items-center gap-2 ${active ? 'font-semibold text-primary-dark' : 'text-ink-secondary'}`}>
                    <span
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${
                        active ? 'bg-primary text-white' : 'bg-surface-alt text-ink-muted'
                      }`}
                    >
                      {i + 1}
                    </span>
                    {stage}
                  </span>
                  <span className={active ? 'font-semibold text-primary-dark' : 'text-ink-muted'}>{stagePct}%</span>
                </div>
              )
            })}
          </div>

          {/* Photos section */}
          <CollapsibleSection
            title="Photos"
            subtitle="4 photos + a real-time selfie"
            open={photosOpen}
            onToggle={() => setPhotosOpen((o) => !o)}
            badge={`${photosFilledCount + (selfie ? 1 : 0)}/${PHOTO_SLOT_COUNT + 1}`}
          >
            <div className="grid grid-cols-3 gap-3">
              {photos.map((photo, i) => (
                <div key={i}>
                  <PhotoSlot
                    index={i}
                    filled={!!photo}
                    primary={i === 0 && !!photo}
                    onAdd={() =>
                      setPhotos((prev) => prev.map((p, idx) => (idx === i ? `mock-photo-${i}-${Date.now()}` : p)))
                    }
                    onRemove={() => setPhotos((prev) => prev.map((p, idx) => (idx === i ? null : p)))}
                  />
                  <p className="mt-1.5 text-center text-caption text-ink-muted">Photo {i + 1}</p>
                </div>
              ))}

              <div>
                <SelfieSlot captured={!!selfie} capturing={capturingSelfie} onCapture={captureSelfie} onRemove={() => setSelfie(null)} />
                <p className="mt-1.5 text-center text-caption font-medium text-secondary">Real-time selfie</p>
              </div>
            </div>

            <div className="mt-4 flex items-start gap-2.5 rounded-md bg-surface-alt/60 p-3">
              <ShieldIcon />
              <p className="text-caption leading-relaxed text-ink-muted">
                We use this to build authenticity and trust. Your photos are private and secure.
              </p>
            </div>
          </CollapsibleSection>

          {/* Information section */}
          <div className="mt-4">
            <CollapsibleSection
              title="Information"
              subtitle="The basics your Wingman starts with"
              open={infoOpen}
              onToggle={() => setInfoOpen((o) => !o)}
              badge={`${infoFilledCount}/${infoChecklist.length}`}
            >
              <div className="space-y-7">
                <section>
                  <SectionLabel>Name</SectionLabel>
                  <TextInput id="name" placeholder="Your first name" value={name} onChange={(e) => setName(e.target.value)} />
                </section>

                <section>
                  <SectionLabel>Birthday</SectionLabel>
                  <div className="flex gap-3">
                    <DateField label="DD" value={day} onChange={setDay} maxLength={2} />
                    <DateField label="MM" value={month} onChange={setMonth} maxLength={2} />
                    <DateField label="YYYY" value={year} onChange={setYear} maxLength={4} grow />
                  </div>
                  {day && month && year.length === 4 && !dobValid && (
                    <p className="mt-2 text-small text-error">You must be 18 or older to use Wingman.</p>
                  )}
                </section>

                <section>
                  <SectionLabel>Gender</SectionLabel>
                  <div className="flex flex-wrap gap-2">
                    {GENDER_OPTIONS.map((o) => (
                      <Chip key={o.value} selected={gender === o.value} onClick={() => setGender(o.value as Gender)}>
                        {o.label}
                      </Chip>
                    ))}
                  </div>
                </section>

                <section>
                  <SectionLabel>Interested in</SectionLabel>
                  <div className="flex flex-wrap gap-2">
                    {INTERESTED_IN_OPTIONS.map((o) => (
                      <Chip
                        key={o.value}
                        selected={interestedIn.includes(o.value as InterestedIn)}
                        onClick={() => toggleInterestedIn(o.value as InterestedIn)}
                      >
                        {o.label}
                      </Chip>
                    ))}
                  </div>
                </section>

                <section>
                  <SectionLabel>Profession</SectionLabel>
                  <TextInput
                    id="profession"
                    placeholder="What do you do?"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                  />
                </section>

                <section>
                  <SectionLabel>Communication style</SectionLabel>
                  <div className="flex flex-wrap gap-2">
                    {COMMUNICATION_STYLE_OPTIONS.map((o) => (
                      <Chip
                        key={o.value}
                        selected={communicationStyle === o.value}
                        onClick={() => setCommunicationStyle(o.value)}
                      >
                        {o.label}
                      </Chip>
                    ))}
                  </div>
                </section>
              </div>
            </CollapsibleSection>
          </div>
        </div>

        <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
          <Button onClick={handleContinue} disabled={!isValid}>
            Continue
          </Button>
        </div>
      </div>

      {showLevelUp && (
        <LevelUpOverlay toCompletion={25} wingmanLine="Nice start. I'm getting to know you." onDone={goNext} />
      )}
    </div>
  )
}

function AvatarWithRing({ percent, stageMax }: { percent: number; stageMax: number }) {
  const ringSize = 176
  const radius = 82
  const strokeWidth = 4.5
  const circumference = 2 * Math.PI * radius
  const fraction = Math.max(0, Math.min(1, percent / stageMax))
  const dashOffset = circumference * (1 - fraction)

  return (
    <div className="relative flex items-center justify-center" style={{ width: ringSize, height: ringSize }}>
      <svg width={ringSize} height={ringSize} className="absolute inset-0 -rotate-90">
        <circle cx={ringSize / 2} cy={ringSize / 2} r={radius} fill="none" stroke="var(--color-border)" strokeWidth={strokeWidth} opacity={0.5} />
        <circle
          cx={ringSize / 2}
          cy={ringSize / 2}
          r={radius}
          fill="none"
          stroke="var(--color-primary)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          style={{ transition: 'stroke-dashoffset 500ms ease-out' }}
        />
      </svg>
      <VibeAvatar completion={percent} size={144} />
    </div>
  )
}

function CollapsibleSection({
  title,
  subtitle,
  open,
  onToggle,
  badge,
  children,
}: {
  title: string
  subtitle?: string
  open: boolean
  onToggle: () => void
  badge?: string
  children: ReactNode
}) {
  return (
    <div className="overflow-hidden rounded-lg border border-border bg-surface shadow-card">
      <button type="button" onClick={onToggle} className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left">
        <div>
          <p className="text-h3 text-ink">{title}</p>
          {subtitle && <p className="mt-0.5 text-small text-ink-secondary">{subtitle}</p>}
        </div>
        <div className="flex shrink-0 items-center gap-2.5">
          {badge && (
            <span className="rounded-full bg-surface-alt px-2.5 py-1 text-caption font-semibold text-ink-secondary">{badge}</span>
          )}
          <span className={`text-ink-muted transition-transform duration-200 ${open ? 'rotate-180' : ''}`}>
            <ChevronDownIcon />
          </span>
        </div>
      </button>
      {open && <div className="border-t border-border px-5 py-5 animate-fade-in-up">{children}</div>}
    </div>
  )
}

function SelfieSlot({
  captured,
  capturing,
  onCapture,
  onRemove,
}: {
  captured: boolean
  capturing: boolean
  onCapture: () => void
  onRemove: () => void
}) {
  return (
    <div className="relative aspect-[3/4]">
      {captured ? (
        <div
          className="relative h-full w-full overflow-hidden rounded-md"
          style={{ background: 'linear-gradient(160deg, #3a6d5d 0%, #1c352c 100%)' }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <CheckCircleIcon />
          </div>
          <button
            onClick={onRemove}
            aria-label="Retake selfie"
            className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm active:scale-95"
          >
            ✕
          </button>
          <LiveBadge />
        </div>
      ) : (
        <button
          type="button"
          onClick={onCapture}
          disabled={capturing}
          className="flex h-full w-full flex-col items-center justify-center gap-1.5 rounded-md border-2 border-dashed border-secondary/50 bg-secondary/5 text-secondary transition-colors hover:border-secondary/80 active:scale-[0.98] disabled:active:scale-100"
        >
          {capturing ? (
            <>
              <span className="h-5 w-5 rounded-full border-2 border-secondary border-t-transparent animate-spin" />
              <span className="text-caption font-medium">Capturing...</span>
            </>
          ) : (
            <>
              <CameraIcon />
              <span className="px-1 text-center text-caption font-medium leading-tight">Tap to capture</span>
            </>
          )}
          <LiveBadge />
        </button>
      )}
    </div>
  )
}

function LiveBadge() {
  return (
    <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/40 px-2 py-1 text-[9px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
      <span className="h-1.5 w-1.5 rounded-full bg-error animate-pulse" />
      Live
    </span>
  )
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="mb-2.5 text-caption font-semibold uppercase tracking-wide text-ink-muted">{children}</p>
}

function DateField({
  label,
  value,
  onChange,
  maxLength,
  grow,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  maxLength: number
  grow?: boolean
}) {
  return (
    <label className={grow ? 'flex-1' : 'w-20'}>
      <span className="mb-1.5 block text-caption text-ink-muted">{label}</span>
      <input
        inputMode="numeric"
        placeholder={label}
        value={value}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value.replace(/\D/g, '').slice(0, maxLength))}
        className="h-12 w-full rounded-md border border-border bg-surface px-3 text-center text-body text-ink outline-none transition-colors focus:border-primary"
      />
    </label>
  )
}

function ChevronDownIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function CameraIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="7" width="18" height="13" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
      <path d="M8 7l1.5-2.5h5L16 7" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      <circle cx="12" cy="13.5" r="3.5" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  )
}

function CheckCircleIcon() {
  return (
    <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="1.6" opacity="0.85" />
      <path d="M7.5 12.5l3 3 6-6.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function ShieldIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="mt-0.5 shrink-0 text-ink-muted">
      <path
        d="M12 3l7 3v5.5c0 4.5-3 8-7 9.5-4-1.5-7-5-7-9.5V6l7-3z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M9 12l2 2 4-4.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
