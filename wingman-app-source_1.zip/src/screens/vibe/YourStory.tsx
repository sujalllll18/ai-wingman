import { useState } from 'react'
import { Button, SecondaryButton, TextButton } from '../../components/Button'
import { LevelUpOverlay } from '../../components/LevelUpOverlay'
import { Toast } from '../../components/Toast'
import { TopBar } from '../../components/TopBar'
import { VibeAvatar } from '../../components/VibeAvatar'
import {
  CHATGPT_IMPORT_PROMPT,
  mockParseChatGptResponse,
  mockRephrase,
  type ParsedImport,
} from '../../data/mockAiTools'
import { RELATIONSHIP_INTENTION_OPTIONS } from '../../data/onboardingOptions'
import {
  clampToWordLimit,
  countWords,
  MOCK_VOICE_TRANSCRIPT_FREEFORM,
  MOCK_VOICE_TRANSCRIPTS,
  PROMPT_WORD_LIMIT,
  STORY_PROMPTS,
} from '../../data/storyPrompts'
import { COMMUNICATION_STYLE_OPTIONS } from '../../data/vibeOptions'
import { useOnboarding } from '../../state/OnboardingContext'
import type { AiImportField, RelationshipIntention } from '../../types/profile'

type Tab = 'prompts' | 'freeform' | 'chatgpt'

const TABS: { id: Tab; label: string }[] = [
  { id: 'prompts', label: 'Answer Prompts' },
  { id: 'freeform', label: 'Tell Us Everything' },
  { id: 'chatgpt', label: 'Use ChatGPT' },
]

const FREEFORM_MIN_LENGTH = 15

export function YourStory() {
  const { profile, updateProfile, goBack, goNext } = useOnboarding()
  const [activeTab, setActiveTab] = useState<Tab>('prompts')
  const [showLevelUp, setShowLevelUp] = useState(false)

  const [promptAnswers, setPromptAnswers] = useState<string[]>(() =>
    STORY_PROMPTS.map((p) => profile.prompts.find((pa) => pa.promptId === p.id)?.answer ?? ''),
  )

  const [freeform, setFreeform] = useState(profile.story || profile.bio)
  const [freeformFinal, setFreeformFinal] = useState(
    profile.storyUsedPolished ? profile.storyPolished ?? '' : profile.story || profile.bio,
  )
  const [freeformUsedPolished, setFreeformUsedPolished] = useState(profile.storyUsedPolished)

  const [chatGptParsed, setChatGptParsed] = useState<ParsedImport | null>(null)

  const filledPromptCount = promptAnswers.filter((a) => a.trim()).length
  const freeformValid = freeform.trim().length >= FREEFORM_MIN_LENGTH
  const isValid = filledPromptCount >= 2 || freeformValid || !!chatGptParsed

  const handleContinue = () => {
    const filledPrompts = STORY_PROMPTS.map((p, i) => ({ promptId: p.id, answer: promptAnswers[i].trim() })).filter(
      (p) => p.answer,
    )

    let bio = profile.bio
    let story = profile.story
    let storyPolished = profile.storyPolished
    let storyUsedPolished = profile.storyUsedPolished
    let likes = profile.likes
    let dislikes = profile.dislikes
    let profession = profile.profession
    let communicationStyle = profile.communicationStyle
    let interests = profile.interests
    let relationshipIntention = profile.relationshipIntention
    let aiImportUsed = profile.aiImportUsed
    let aiImportFields = profile.aiImportFields
    let prompts = filledPrompts

    if (chatGptParsed) {
      bio = chatGptParsed.bio || bio
      communicationStyle = chatGptParsed.communicationStyle ?? communicationStyle
      interests = Array.from(new Set([...interests, ...chatGptParsed.interests]))
      likes = chatGptParsed.likes || likes
      dislikes = chatGptParsed.dislikes || dislikes
      profession = chatGptParsed.profession || profession
      relationshipIntention = chatGptParsed.relationshipIntention ?? relationshipIntention
      aiImportUsed = true
      const extraFields: AiImportField[] = [...chatGptParsed.extras]
      if (chatGptParsed.lifestyle) extraFields.push({ label: 'Lifestyle', value: chatGptParsed.lifestyle })
      if (chatGptParsed.values) extraFields.push({ label: 'Values', value: chatGptParsed.values })
      if (chatGptParsed.idealConnection) extraFields.push({ label: 'Ideal connection', value: chatGptParsed.idealConnection })
      if (chatGptParsed.conversationTopics)
        extraFields.push({ label: 'Conversation topics', value: chatGptParsed.conversationTopics })
      aiImportFields = extraFields
      if (chatGptParsed.promptAnswers.length && prompts.length === 0) {
        prompts = chatGptParsed.promptAnswers
      }
    } else if (freeform.trim()) {
      story = freeform.trim()
      storyPolished = freeformUsedPolished ? freeformFinal : null
      storyUsedPolished = freeformUsedPolished
      bio = freeformUsedPolished && freeformFinal ? freeformFinal : freeform.trim()
    }

    updateProfile({
      prompts,
      story,
      storyPolished,
      storyUsedPolished,
      bio,
      likes,
      dislikes,
      profession,
      communicationStyle,
      interests,
      relationshipIntention,
      aiImportUsed,
      aiImportFields,
      vibeCompletion: 75,
    })
    setShowLevelUp(true)
  }

  return (
    <div className="relative min-h-screen">
      <div className="flex h-full min-h-screen flex-col">
        <TopBar onBack={goBack} />

        <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar animate-fade-in-up">
          <div className="flex flex-col items-center pt-1 pb-4 text-center">
            <StoryAvatar />
            <p className="mt-3 text-caption font-semibold uppercase tracking-[0.14em] text-ink-muted">Your Vibe Profile</p>
            <p className="mt-0.5 text-h2 text-primary">50% complete</p>
          </div>

          <h1 className="text-h1 text-ink">Let's get to know the real you.</h1>
          <p className="mt-2 text-body text-ink-secondary">
            Your answers help your Wingman understand your personality, conversation style and what makes you, you.
          </p>

          <div className="mt-5 flex rounded-full bg-surface-alt p-1">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 rounded-full py-2 px-1 text-caption font-semibold transition-colors ${
                  activeTab === tab.id ? 'bg-surface text-ink shadow-card' : 'text-ink-secondary'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="mt-5">
            {activeTab === 'prompts' && (
              <div className="space-y-4">
                <p className="text-small text-ink-muted">Answer at least 2 — you don't have to do all 4.</p>
                {STORY_PROMPTS.map((prompt, i) => (
                  <PromptField
                    key={prompt.id}
                    index={i}
                    prompt={prompt}
                    value={promptAnswers[i]}
                    onChange={(v) => setPromptAnswers((prev) => prev.map((p, idx) => (idx === i ? v : p)))}
                  />
                ))}
              </div>
            )}

            {activeTab === 'freeform' && (
              <FreeformTab
                value={freeform}
                onChange={(v) => {
                  setFreeform(v)
                  setFreeformUsedPolished(false)
                }}
                usingPolished={freeformUsedPolished}
                finalText={freeformFinal}
                onUsePolished={(text) => {
                  setFreeformFinal(text)
                  setFreeformUsedPolished(true)
                  setFreeform(text)
                }}
              />
            )}

            {activeTab === 'chatgpt' && <ChatGptTab parsed={chatGptParsed} onConfirm={setChatGptParsed} />}
          </div>
        </div>

        <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">
          {!isValid && (
            <p className="mb-2 text-center text-caption text-ink-muted">
              Answer at least 2 prompts, tell us about yourself, or use ChatGPT to continue.
            </p>
          )}
          <Button onClick={handleContinue} disabled={!isValid}>
            Continue →
          </Button>
        </div>
      </div>

      {showLevelUp && (
        <LevelUpOverlay
          toCompletion={75}
          wingmanLine="Now I'm starting to understand your personality."
          onDone={goNext}
        />
      )}
    </div>
  )
}

function StoryAvatar() {
  const size = 128
  return (
    <div className="relative flex items-center justify-center" style={{ width: size + 24, height: size + 24 }}>
      <div
        className="vibe-orbit-ring vibe-orbit-ring--cw absolute rounded-full"
        style={{ inset: 4, border: '1.5px dashed var(--color-primary)', opacity: 0.35, animationDuration: '30s' }}
      />
      <VibeAvatar completion={50} size={size} />
    </div>
  )
}

function ModePill({
  active,
  onClick,
  children,
  disabled,
}: {
  active: boolean
  onClick: () => void
  children: string
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`flex-1 whitespace-nowrap rounded-full border px-2.5 py-2 text-caption font-semibold transition-colors disabled:opacity-40 ${
        active ? 'border-primary bg-primary text-white' : 'border-border bg-surface text-ink-secondary hover:border-primary/40'
      }`}
    >
      {children}
    </button>
  )
}

function PromptField({
  index,
  prompt,
  value,
  onChange,
}: {
  index: number
  prompt: { id: string; text: string }
  value: string
  onChange: (v: string) => void
}) {
  const [mode, setMode] = useState<'type' | 'talk'>('type')
  const [listening, setListening] = useState(false)
  const [suggestion, setSuggestion] = useState<string | null>(null)
  const [rephrasing, setRephrasing] = useState(false)
  const [variant, setVariant] = useState<0 | 1>(0)
  const words = countWords(value)

  const startTalk = () => {
    if (listening) return
    setMode('talk')
    setListening(true)
    setTimeout(() => {
      const transcript = MOCK_VOICE_TRANSCRIPTS[prompt.id] ?? ''
      onChange(clampToWordLimit(transcript, PROMPT_WORD_LIMIT))
      setListening(false)
    }, 1200)
  }

  const rephrase = (nextVariant: 0 | 1) => {
    if (!value.trim()) return
    setRephrasing(true)
    setTimeout(() => {
      setSuggestion(clampToWordLimit(mockRephrase(value, nextVariant), PROMPT_WORD_LIMIT))
      setVariant(nextVariant)
      setRephrasing(false)
    }, 650)
  }

  return (
    <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-white">
            {index + 1}
          </span>
          <p className="text-body font-semibold leading-snug text-ink">{prompt.text}</p>
        </div>
        <span className={`shrink-0 text-caption tabular-nums ${words >= PROMPT_WORD_LIMIT ? 'text-error' : 'text-ink-muted'}`}>
          {words} / {PROMPT_WORD_LIMIT} words
        </span>
      </div>

      <textarea
        value={value}
        onChange={(e) => {
          onChange(clampToWordLimit(e.target.value, PROMPT_WORD_LIMIT))
          setMode('type')
          setSuggestion(null)
        }}
        placeholder="Write your answer..."
        rows={2}
        className="mt-3 w-full resize-none rounded-md border border-border bg-surface-alt/40 px-3.5 py-2.5 text-small text-ink outline-none transition-colors focus:border-primary"
      />

      {suggestion && (
        <div className="mt-3 space-y-2.5 animate-fade-in-up">
          <div className="rounded-md border border-border bg-surface-alt/60 p-3">
            <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Original</p>
            <p className="mt-1 text-small text-ink-secondary">{value}</p>
          </div>
          <div className="rounded-md border border-primary/30 bg-primary-light/30 p-3">
            <p className="text-caption font-semibold uppercase tracking-wide text-primary">AI suggestion</p>
            <p className="mt-1 text-small text-ink">{suggestion}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              fullWidth={false}
              className="h-9 px-3.5 text-caption"
              onClick={() => {
                onChange(suggestion)
                setSuggestion(null)
              }}
            >
              Use this
            </Button>
            <SecondaryButton fullWidth={false} className="h-9 px-3.5 text-caption" onClick={() => rephrase(variant === 0 ? 1 : 0)}>
              Try again
            </SecondaryButton>
            <TextButton className="h-9 px-2 text-caption" onClick={() => setSuggestion(null)}>
              Keep mine
            </TextButton>
          </div>
        </div>
      )}

      <div className="mt-3 flex gap-2">
        <ModePill active={mode === 'type'} onClick={() => setMode('type')}>
          ⌨ Type
        </ModePill>
        <ModePill active={mode === 'talk'} onClick={startTalk}>
          {listening ? 'Listening…' : '🎙 Talk'}
        </ModePill>
        <ModePill active={false} disabled={!value.trim() || rephrasing} onClick={() => rephrase(0)}>
          {rephrasing ? 'Rephrasing…' : '✨ AI Rephrase'}
        </ModePill>
      </div>
    </div>
  )
}

function FreeformTab({
  value,
  onChange,
  usingPolished,
  finalText,
  onUsePolished,
}: {
  value: string
  onChange: (v: string) => void
  usingPolished: boolean
  finalText: string
  onUsePolished: (text: string) => void
}) {
  const [listening, setListening] = useState(false)
  const [suggestion, setSuggestion] = useState<string | null>(null)
  const [rephrasing, setRephrasing] = useState(false)
  const [variant, setVariant] = useState<0 | 1>(0)
  const wordCount = countWords(value)

  const startTalk = () => {
    if (listening) return
    setListening(true)
    setTimeout(() => {
      onChange(MOCK_VOICE_TRANSCRIPT_FREEFORM)
      setListening(false)
    }, 1400)
  }

  const rephrase = (nextVariant: 0 | 1) => {
    if (!value.trim()) return
    setRephrasing(true)
    setTimeout(() => {
      setSuggestion(mockRephrase(value, nextVariant))
      setVariant(nextVariant)
      setRephrasing(false)
    }, 700)
  }

  return (
    <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
      <div className="flex items-start gap-2.5">
        <span className="text-lg leading-none">📝</span>
        <div>
          <p className="text-body font-semibold text-ink">Tell us everything</p>
          <p className="mt-0.5 text-small text-ink-secondary">
            Don't know what to write? Just talk or write freely. We'll organize the important parts for you.
          </p>
        </div>
      </div>

      <textarea
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
          setSuggestion(null)
        }}
        placeholder="Write or talk freely about yourself. Your Wingman will understand the important details."
        rows={7}
        className="mt-3 w-full resize-none rounded-md border border-border bg-surface-alt/40 px-3.5 py-2.5 text-small text-ink outline-none transition-colors focus:border-primary"
      />
      <div className="mt-1.5 flex items-center justify-between">
        <span className="text-caption text-secondary">{wordCount} words</span>
        {usingPolished && !suggestion && <span className="text-caption text-secondary">✓ Using Wingman-polished version</span>}
      </div>

      {suggestion && (
        <div className="mt-3 space-y-2.5 animate-fade-in-up">
          <div className="rounded-md border border-border bg-surface-alt/60 p-3">
            <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Original</p>
            <p className="mt-1 text-small text-ink-secondary">{value}</p>
          </div>
          <div className="rounded-md border border-primary/30 bg-primary-light/30 p-3">
            <p className="text-caption font-semibold uppercase tracking-wide text-primary">AI suggestion</p>
            <p className="mt-1 text-small text-ink">{suggestion}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              fullWidth={false}
              className="h-9 px-3.5 text-caption"
              onClick={() => {
                onUsePolished(suggestion)
                setSuggestion(null)
              }}
            >
              Use this
            </Button>
            <SecondaryButton fullWidth={false} className="h-9 px-3.5 text-caption" onClick={() => rephrase(variant === 0 ? 1 : 0)}>
              Try again
            </SecondaryButton>
            <TextButton className="h-9 px-2 text-caption" onClick={() => setSuggestion(null)}>
              Keep mine
            </TextButton>
          </div>
        </div>
      )}

      <div className="mt-3 flex gap-2">
        <ModePill active={listening} onClick={startTalk}>
          {listening ? 'Listening…' : '🎙 Talk'}
        </ModePill>
        <ModePill active={false} disabled={!value.trim() || rephrasing} onClick={() => rephrase(0)}>
          {rephrasing ? 'Rephrasing…' : '✨ AI Rephrase'}
        </ModePill>
      </div>
      {finalText && null}
    </div>
  )
}

interface ReviewDraft {
  bio: string
  communicationStyleLabel: string
  interests: string
  lifestyle: string
  likes: string
  dislikes: string
  profession: string
  relationshipIntentionLabel: string
  values: string
  idealConnection: string
  conversationTopics: string
  extras: AiImportField[]
}

function draftFromParsed(p: ParsedImport): ReviewDraft {
  return {
    bio: p.bio,
    communicationStyleLabel: COMMUNICATION_STYLE_OPTIONS.find((o) => o.value === p.communicationStyle)?.label ?? '',
    interests: p.interests.join(', '),
    lifestyle: p.lifestyle,
    likes: p.likes,
    dislikes: p.dislikes,
    profession: p.profession,
    relationshipIntentionLabel: RELATIONSHIP_INTENTION_OPTIONS.find((o) => o.value === p.relationshipIntention)?.label ?? '',
    values: p.values,
    idealConnection: p.idealConnection,
    conversationTopics: p.conversationTopics,
    extras: p.extras,
  }
}

function ChatGptTab({ parsed, onConfirm }: { parsed: ParsedImport | null; onConfirm: (p: ParsedImport) => void }) {
  const [pasted, setPasted] = useState('')
  const [building, setBuilding] = useState(false)
  const [rawParsed, setRawParsed] = useState<ParsedImport | null>(parsed)
  const [draft, setDraft] = useState<ReviewDraft | null>(parsed ? draftFromParsed(parsed) : null)
  const [showAll, setShowAll] = useState(false)
  const [toast, setToast] = useState('')

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => setToast(''), 2000)
  }

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(CHATGPT_IMPORT_PROMPT)
      showToast('Prompt copied')
    } catch {
      showToast('Select the text below to copy')
    }
  }

  const build = () => {
    setBuilding(true)
    setTimeout(() => {
      const result = mockParseChatGptResponse(pasted)
      setRawParsed(result)
      setDraft(draftFromParsed(result))
      setBuilding(false)
    }, 900)
  }

  const confirm = () => {
    if (!draft || !rawParsed) return
    const finalParsed: ParsedImport = {
      bio: draft.bio,
      communicationStyle:
        COMMUNICATION_STYLE_OPTIONS.find((o) => o.label.toLowerCase() === draft.communicationStyleLabel.toLowerCase())?.value ??
        rawParsed.communicationStyle,
      interests: draft.interests.split(',').map((s) => s.trim()).filter(Boolean),
      likes: draft.likes,
      dislikes: draft.dislikes,
      profession: draft.profession,
      relationshipIntention:
        (RELATIONSHIP_INTENTION_OPTIONS.find((o) => o.label.toLowerCase() === draft.relationshipIntentionLabel.toLowerCase())
          ?.value as RelationshipIntention | undefined) ?? rawParsed.relationshipIntention,
      lifestyle: draft.lifestyle,
      values: draft.values,
      idealConnection: draft.idealConnection,
      conversationTopics: draft.conversationTopics,
      promptAnswers: rawParsed.promptAnswers,
      extras: draft.extras,
    }
    onConfirm(finalParsed)
    showToast('Saved — Continue when ready')
  }

  const updateDraft = (patch: Partial<ReviewDraft>) => setDraft((prev) => (prev ? { ...prev, ...patch } : prev))

  return (
    <div className="space-y-4">
      <Toast message={toast} visible={!!toast} />

      <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
        <div className="flex items-start gap-2.5">
          <span className="text-lg leading-none">🤖</span>
          <div>
            <p className="text-body font-semibold text-ink">Use ChatGPT</p>
            <p className="mt-0.5 text-small text-ink-secondary">
              Want help figuring yourself out? Give our questions to ChatGPT, have a conversation, then paste the
              response here.
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
        <p className="text-small font-semibold text-ink">1. Copy our prompt</p>
        <p className="mt-0.5 text-caption text-ink-muted">We'll give you questions to understand yourself better.</p>
        <details className="mt-2.5 text-caption text-ink-secondary">
          <summary className="cursor-pointer text-caption font-medium text-primary">Preview prompt</summary>
          <div className="mt-2 max-h-40 overflow-y-auto whitespace-pre-wrap rounded-md bg-surface-alt/60 p-3">{CHATGPT_IMPORT_PROMPT}</div>
        </details>
        <SecondaryButton className="mt-3 h-11" onClick={copyPrompt}>
          Copy Prompt
        </SecondaryButton>
      </div>

      <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
        <p className="text-small font-semibold text-ink">2. Paste your ChatGPT response</p>
        <textarea
          value={pasted}
          onChange={(e) => setPasted(e.target.value)}
          placeholder="Paste the response from ChatGPT here..."
          rows={5}
          className="mt-2.5 w-full resize-none rounded-md border border-border bg-surface-alt/40 px-3.5 py-2.5 text-small text-ink outline-none transition-colors focus:border-primary"
        />
        <Button className="mt-3 h-11" onClick={build} disabled={!pasted.trim()} loading={building}>
          Build my profile
        </Button>
      </div>

      {draft && (
        <div className="rounded-lg border border-primary/30 bg-primary-light/25 p-4 shadow-card animate-fade-in-up">
          <p className="text-body font-semibold text-ink">Here's what your Wingman understood</p>
          <p className="mt-0.5 text-small text-ink-secondary">Review and edit anything before confirming.</p>

          <div className="mt-3 space-y-3">
            <ReviewField icon="🙂" label="Personality" value={draft.bio} onChange={(v) => updateDraft({ bio: v })} />
            <ReviewField
              icon="💬"
              label="Communication style"
              value={draft.communicationStyleLabel}
              onChange={(v) => updateDraft({ communicationStyleLabel: v })}
            />
            <ReviewField icon="🏷️" label="Interests" value={draft.interests} onChange={(v) => updateDraft({ interests: v })} />
            <ReviewField icon="🌿" label="Lifestyle" value={draft.lifestyle} onChange={(v) => updateDraft({ lifestyle: v })} />

            {showAll && (
              <>
                <ReviewField icon="👍" label="Likes" value={draft.likes} onChange={(v) => updateDraft({ likes: v })} />
                <ReviewField icon="👎" label="Dislikes" value={draft.dislikes} onChange={(v) => updateDraft({ dislikes: v })} />
                <ReviewField icon="💼" label="Profession" value={draft.profession} onChange={(v) => updateDraft({ profession: v })} />
                <ReviewField
                  icon="❤️"
                  label="Relationship intention"
                  value={draft.relationshipIntentionLabel}
                  onChange={(v) => updateDraft({ relationshipIntentionLabel: v })}
                />
                <ReviewField icon="⭐" label="Values" value={draft.values} onChange={(v) => updateDraft({ values: v })} />
                <ReviewField icon="🤝" label="Ideal connection" value={draft.idealConnection} onChange={(v) => updateDraft({ idealConnection: v })} />
                <ReviewField
                  icon="🗨️"
                  label="Conversation topics"
                  value={draft.conversationTopics}
                  onChange={(v) => updateDraft({ conversationTopics: v })}
                />
                {draft.extras.map((field, i) => (
                  <ReviewField
                    key={field.label}
                    icon="✨"
                    label={field.label}
                    value={field.value}
                    onChange={(v) => {
                      const next = [...draft.extras]
                      next[i] = { ...next[i], value: v }
                      updateDraft({ extras: next })
                    }}
                  />
                ))}
              </>
            )}

            {!showAll && (
              <button onClick={() => setShowAll(true)} className="text-caption font-semibold text-primary-dark underline">
                Show all ({7 + draft.extras.length})
              </button>
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <SecondaryButton fullWidth={false} onClick={() => setShowAll(true)}>
              Edit more
            </SecondaryButton>
            <Button fullWidth={false} onClick={confirm}>
              Confirm &amp; Continue
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

function ReviewField({
  icon,
  label,
  value,
  onChange,
}: {
  icon: string
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="rounded-md border border-border bg-surface p-3">
      <div className="flex items-center gap-2">
        <span className="text-body leading-none">{icon}</span>
        <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">{label}</p>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={2}
        className="mt-1.5 w-full resize-none rounded-md border-0 bg-transparent px-0 text-small text-ink outline-none"
      />
    </div>
  )
}
