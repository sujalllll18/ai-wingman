import { useEffect, useRef, useState } from 'react'
import { Avatar } from '../components/Avatar'
import { ChatBubble } from '../components/ChatBubble'
import { SafetyMenu } from '../components/SafetyMenu'
import { WingmanHelpSheet, type HelpKind } from '../components/WingmanHelpSheet'
import { FUN_PROMPTS, KEEP_GOING_TIPS } from '../data/mockWingmanTips'
import { getPersonById } from '../data/mockPeople'
import { useCountdown } from '../hooks/useCountdown'
import { useOnboarding } from '../state/OnboardingContext'
import type { ChatMessage } from '../types/journey'

let idCounter = 0
const nextId = () => `msg-${++idCounter}`

export function ChatRoom() {
  const { selectedPersonId, scheduledSlot, conversationStage, setIntroStage, goNext } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const durationMinutes = scheduledSlot?.durationMinutes ?? 10

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [draft, setDraft] = useState('')
  const [helpOpen, setHelpOpen] = useState(false)
  const [suggestion, setSuggestion] = useState<{ kind: HelpKind; text: string } | null>(null)
  const replyIndexRef = useRef(1)
  const scrollRef = useRef<HTMLDivElement>(null)

  const handleComplete = () => {
    if (person) setIntroStage(person.id, conversationStage === 'second' ? 'talked_second' : 'talked_first')
    goNext()
  }

  const { formatted, secondsLeft, finishNow } = useCountdown(durationMinutes * 60, {
    onComplete: handleComplete,
  })
  const lowTime = secondsLeft <= 60

  useEffect(() => {
    if (!person) return
    setMessages([{ id: nextId(), from: 'system', text: `Your ${durationMinutes}-minute conversation with ${person.name} has started.` }])
    const t = setTimeout(() => {
      setMessages((prev) => [...prev, { id: nextId(), from: 'them', text: person.replySamples[0] }])
    }, 900)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [person?.id])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  if (!person) return null

  const sendMessage = (text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    setMessages((prev) => [...prev, { id: nextId(), from: 'me', text: trimmed }])
    setDraft('')
    setSuggestion(null)

    const reply = person.replySamples[replyIndexRef.current % person.replySamples.length]
    replyIndexRef.current += 1
    setTimeout(() => {
      setMessages((prev) => [...prev, { id: nextId(), from: 'them', text: reply }])
    }, 1100 + Math.random() * 600)
  }

  const handleHelpSelect = (kind: HelpKind) => {
    let text = ''
    if (kind === 'opener') text = person.openers[0]
    else if (kind === 'question') text = person.conversationTopics[Math.floor(Math.random() * person.conversationTopics.length)]
    else if (kind === 'keepGoing') text = KEEP_GOING_TIPS[Math.floor(Math.random() * KEEP_GOING_TIPS.length)]
    else text = FUN_PROMPTS[Math.floor(Math.random() * FUN_PROMPTS.length)]
    setSuggestion({ kind, text })
    setHelpOpen(false)
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <div className="sticky top-0 z-10 flex items-center gap-3 border-b border-border/70 bg-bg/95 px-5 py-3 backdrop-blur">
        <Avatar gradientIndex={person.gradientIndex} size={40} />
        <div className="flex-1">
          <p className="text-h3 text-ink leading-tight">{person.name}</p>
          <p className="text-caption text-ink-muted">{durationMinutes}-minute conversation</p>
        </div>
        <span
          className={`rounded-full px-3 py-1.5 text-small font-semibold tabular-nums ${
            lowTime ? 'bg-warning/15 text-warning' : 'bg-surface-alt text-ink-secondary'
          }`}
        >
          {formatted}
        </span>
        <SafetyMenu personId={person.id} personName={person.name} afterActionScreen="explore" />
      </div>

      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-5 py-4 no-scrollbar">
        {messages.map((m) => (
          <ChatBubble key={m.id} message={m} />
        ))}
      </div>

      {suggestion && (
        <div className="mx-5 mb-2 flex items-start gap-3 rounded-md border border-primary/25 bg-primary-light/40 p-3 animate-fade-in-up">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white">
            <WingmanMark />
          </div>
          <div className="flex-1">
            <p className="text-small text-ink">{suggestion.text}</p>
            <div className="mt-2 flex gap-3">
              <button
                onClick={() => setDraft(suggestion.text)}
                className="text-caption font-semibold text-primary-dark underline"
              >
                Use this
              </button>
              <button onClick={() => setSuggestion(null)} className="text-caption font-semibold text-ink-muted underline">
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="border-t border-border/70 bg-bg/95 px-5 py-3 backdrop-blur">
        <div className="flex items-end gap-2">
          <button
            onClick={() => setHelpOpen(true)}
            className="flex h-11 shrink-0 items-center gap-1.5 rounded-full border border-primary/30 bg-primary-light/40 px-3.5 text-small font-medium text-primary-dark active:scale-95"
          >
            <WingmanMark />
            Need help?
          </button>
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage(draft)}
            placeholder="Message..."
            className="h-11 min-w-0 flex-1 rounded-full border border-border bg-surface px-4 text-body text-ink placeholder:text-ink-muted outline-none focus:border-primary"
          />
          <button
            onClick={() => sendMessage(draft)}
            disabled={!draft.trim()}
            aria-label="Send"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary text-white transition-opacity disabled:opacity-30"
          >
            <SendIcon />
          </button>
        </div>
        <button onClick={finishNow} className="mt-2 w-full text-center text-caption text-ink-muted underline">
          End conversation now (preview)
        </button>
      </div>

      <WingmanHelpSheet open={helpOpen} onClose={() => setHelpOpen(false)} onSelect={handleHelpSelect} />
    </div>
  )
}

function WingmanMark() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 3c1.5 3 4 4.5 7 5-3 1-5.5 3.5-7 7-1.5-3.5-4-6-7-7 3-.5 5.5-2 7-5z"
        fill="currentColor"
      />
    </svg>
  )
}

function SendIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M4 12l16-7-6 16-2.5-6.5L4 12z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  )
}
