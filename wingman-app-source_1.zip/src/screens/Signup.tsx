import { useEffect } from 'react'
import { useOnboarding } from '../state/OnboardingContext'

export function Signup() {
  const { updateProfile, goNext } = useOnboarding()

  useEffect(() => {
    const t = setTimeout(() => {
      updateProfile({ authMethod: 'google' })
      goNext()
    }, 1100)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-center gap-5 px-6">
      <div className="flex h-14 w-14 items-center justify-center rounded-full border border-border bg-surface shadow-card">
        <span className="h-6 w-6 animate-spin rounded-full border-2 border-ink/15 border-t-primary" />
      </div>
      <p className="text-body text-ink-secondary animate-fade-in">Connecting to Google...</p>
    </div>
  )
}
