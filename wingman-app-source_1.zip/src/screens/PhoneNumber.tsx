import { useState } from 'react'
import { Button } from '../components/Button'
import { TopBar } from '../components/TopBar'
import { useOnboarding } from '../state/OnboardingContext'

export function PhoneNumber() {
  const { profile, updateProfile, goNext, goBack } = useOnboarding()
  const [digits, setDigits] = useState(profile.phoneNumber)

  const isValid = digits.replace(/\D/g, '').length === 10

  const handleContinue = () => {
    updateProfile({ phoneNumber: digits })
    goNext()
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex flex-1 flex-col justify-between px-6 pb-8 pt-4">
        <div className="animate-fade-in-up">
          <p className="text-small font-medium text-primary">One more step before we get started.</p>
          <h1 className="mt-1 text-h1 text-ink">What's your number?</h1>
          <p className="mt-2 text-body text-ink-secondary">
            We'll use your number to keep your account secure.
          </p>

          <div className="mt-8 flex items-center gap-3">
            <div className="flex h-14 items-center rounded-md border border-border bg-surface px-4 text-body text-ink">
              🇮🇳 +91
            </div>
            <input
              autoFocus
              inputMode="numeric"
              placeholder="98765 43210"
              value={digits}
              onChange={(e) => setDigits(e.target.value.replace(/\D/g, '').slice(0, 10))}
              className="h-14 flex-1 rounded-md border border-border bg-surface px-4 text-body text-ink placeholder:text-ink-muted outline-none transition-colors focus:border-primary"
            />
          </div>
        </div>

        <Button onClick={handleContinue} disabled={!isValid}>
          Send OTP
        </Button>
      </div>
    </div>
  )
}
