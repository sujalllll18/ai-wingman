import { useEffect, type ReactNode } from 'react'
import { Button, SecondaryButton } from '../components/Button'
import { WingmanCompanion } from '../components/WingmanCompanion'
import { generateDatePlan } from '../data/mockDatePlanner'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'
import type { DatePlanResponse } from '../types/journey'

export function DatePlanSent() {
  const { selectedPersonId, datePlan, setDatePlan, datePlanResponse, setDatePlanResponse, goTo } = useOnboarding()
  const person = getPersonById(selectedPersonId)

  useEffect(() => {
    setDatePlanResponse(null)
    const t = setTimeout(() => setDatePlanResponse('accepted'), 1800)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (!person || !datePlan) return null

  const resolve = (r: DatePlanResponse) => setDatePlanResponse(r)

  if (!datePlanResponse) {
    return (
      <div className="flex h-full min-h-screen flex-col items-center justify-center px-6 text-center">
        <WingmanCompanion size={64} talking />
        <h1 className="mt-5 text-h1 text-ink">Plan sent to {person.name} 💫</h1>
        <p className="mt-2 text-body text-ink-secondary">Let's see what she thinks.</p>

        <div className="mt-10 space-y-2">
          <p className="text-caption text-ink-muted">Preview: jump to a response</p>
          <div className="flex gap-2">
            <button onClick={() => resolve('accepted')} className="rounded-full border border-border px-3 py-1.5 text-caption text-ink-secondary">
              Accepted
            </button>
            <button onClick={() => resolve('suggest_another')} className="rounded-full border border-border px-3 py-1.5 text-caption text-ink-secondary">
              Suggested another
            </button>
            <button onClick={() => resolve('declined')} className="rounded-full border border-border px-3 py-1.5 text-caption text-ink-secondary">
              Declined
            </button>
          </div>
        </div>
      </div>
    )
  }

  if (datePlanResponse === 'accepted') {
    return (
      <Outcome title="It's a date." body={`${person.name} accepted the plan. Your Wingman will send you both a reminder.`}>
        <Button onClick={() => goTo('unlimitedChat')}>Back to chat</Button>
      </Outcome>
    )
  }

  if (datePlanResponse === 'suggest_another') {
    const alt = generateDatePlan(person, datePlan, (Math.random() * 5) | 0)
    return (
      <Outcome
        title={`${person.name} suggested something else.`}
        body={`How about ${alt.venueTitle} instead? ${alt.venueSubtitle}.`}
      >
        <Button
          onClick={() => {
            setDatePlan(alt)
            goTo('datePlanResult')
          }}
        >
          Review their idea
        </Button>
        <SecondaryButton onClick={() => goTo('unlimitedChat')}>Back to chat</SecondaryButton>
      </Outcome>
    )
  }

  return (
    <Outcome title="No worries." body={`${person.name} isn't up for it right now. You can always plan something else later.`}>
      <Button onClick={() => goTo('unlimitedChat')}>Back to chat</Button>
    </Outcome>
  )
}

function Outcome({ title, body, children }: { title: string; body: string; children: ReactNode }) {
  return (
    <div className="flex h-full min-h-screen flex-col items-center justify-between px-6 pb-8 pt-24 text-center">
      <div className="flex flex-1 flex-col items-center justify-center animate-fade-in-up">
        <h1 className="text-display text-ink">{title}</h1>
        <p className="mt-3 max-w-[300px] text-body text-ink-secondary">{body}</p>
      </div>
      <div className="w-full max-w-[320px] space-y-3">{children}</div>
    </div>
  )
}
