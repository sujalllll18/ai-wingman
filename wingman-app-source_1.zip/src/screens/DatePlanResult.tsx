import { useState } from 'react'
import { Button, SecondaryButton, TextButton } from '../components/Button'
import { TopBar } from '../components/TopBar'
import { generateDatePlan } from '../data/mockDatePlanner'
import { getPersonById } from '../data/mockPeople'
import { useOnboarding } from '../state/OnboardingContext'

// Screen 2 of the 2-screen date planner — the AI-generated plan itself.
// "Edit plan" returns to Screen 1 (DatePlannerIntro), which restores the
// selections straight from this same `datePlan` object. "Try another"
// regenerates in place without leaving this screen or losing selections.
export function DatePlanResult() {
  const { selectedPersonId, datePlan, setDatePlan, goBack, goTo, goNext } = useOnboarding()
  const person = getPersonById(selectedPersonId)
  const [variant, setVariant] = useState(0)
  const [copied, setCopied] = useState(false)

  if (!person || !datePlan) return null

  const tryAnother = () => {
    const nextVariant = variant + 1
    setVariant(nextVariant)
    setDatePlan(generateDatePlan(person, datePlan, nextVariant))
  }

  const share = () => {
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={goBack} />
      <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar">
        <div className="animate-fade-in-up">
          <h1 className="text-h1 text-ink">Here's your plan.</h1>
          <p className="mt-2 text-body text-ink-secondary">I found something that fits both of your vibes.</p>
        </div>

        <div className="mt-6 overflow-hidden rounded-lg border border-border bg-surface shadow-pop">
          <div
            className="relative flex h-32 items-end p-5"
            style={{ background: 'linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%)' }}
          >
            <span className="absolute right-4 top-4 text-3xl opacity-90">{datePlan.venueEmoji}</span>
            <p className="text-caption font-semibold uppercase tracking-wide text-white/85">
              {datePlan.dayLabel.toUpperCase()} · {datePlan.timeLabel}
            </p>
          </div>

          <div className="p-5">
            <p className="text-h2 text-ink">
              {datePlan.venueEmoji} {datePlan.venueTitle}
            </p>
            <p className="mt-1 text-body font-medium text-primary-dark">{datePlan.venueSubtitle}</p>

            <div className="mt-4 flex flex-wrap gap-2">
              <Tag>{datePlan.musicTag}</Tag>
              <Tag>{datePlan.walkTag}</Tag>
              <Tag>{datePlan.priceTag}</Tag>
              <Tag>{`⭐ ${datePlan.ratingTag}`}</Tag>
            </div>
          </div>

          <div className="border-t border-border px-5 py-4">
            <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">The evening</p>
            <div className="mt-3 space-y-3">
              {datePlan.itinerary.map((stop, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-[68px] shrink-0 text-caption font-semibold text-ink-secondary tabular-nums">
                    {stop.time}
                  </span>
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary-light/50 text-body">
                    {stop.emoji}
                  </span>
                  <span className="text-small text-ink">{stop.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-border bg-primary-light/40 px-5 py-3.5">
            <p className="text-caption font-semibold uppercase tracking-wide text-primary-dark">Why this plan?</p>
            <p className="mt-1 text-small text-ink-secondary">{datePlan.reason}</p>
          </div>

          {datePlan.offers.length > 0 && (
            <div className="border-t border-border px-5 py-3.5">
              <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Available offers</p>
              <div className="mt-2 space-y-1.5">
                {datePlan.offers.map((offer) => (
                  <p key={offer.label} className="flex items-center gap-1.5 text-small text-secondary-dark">
                    <span>🏷️</span> {offer.label}
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>

        {copied && (
          <div className="mt-3 rounded-md bg-surface-alt px-3 py-2 text-center text-caption text-ink-secondary animate-fade-in">
            Plan link copied (preview)
          </div>
        )}

        <div className="mt-6 space-y-3">
          <Button onClick={goNext}>Send plan to {person.name}</Button>
          <div className="grid grid-cols-3 gap-2.5">
            <SecondaryButton fullWidth={false} className="px-2 text-caption" onClick={() => goTo('datePlannerIntro')}>
              Edit plan
            </SecondaryButton>
            <SecondaryButton fullWidth={false} className="px-2 text-caption" onClick={tryAnother}>
              Try another
            </SecondaryButton>
            <SecondaryButton fullWidth={false} className="px-2 text-caption" onClick={share}>
              Share
            </SecondaryButton>
          </div>
          <TextButton fullWidth className="justify-center" onClick={goBack}>
            Cancel
          </TextButton>
        </div>
      </div>
    </div>
  )
}

function Tag({ children }: { children: string }) {
  return <span className="rounded-full border border-border px-3 py-1.5 text-small text-ink-secondary">{children}</span>
}
