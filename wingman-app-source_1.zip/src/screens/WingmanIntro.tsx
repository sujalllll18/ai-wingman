import { useEffect, useState } from 'react'
import { Button } from '../components/Button'
import { SparkleIcon } from '../components/VibeAvatar'
import { useOnboarding } from '../state/OnboardingContext'

const LINES = ["Hey! I'm your Wingman.", "Let's build an avatar that feels like you. Ready?"]

// This screen's hero visuals (the unfinished character bust + the Wingman
// companion portrait) are deliberately built as local, one-off SVG/CSS —
// not the shared VibeAvatar/WingmanCompanion components used on every other
// onboarding screen. Reusing those would have meant changing components
// other screens also render, which is out of scope here; everything below
// is scoped to this file only and reuses only *existing* global keyframes
// (vibe-orbit-cw, vibe-pulse-ring, vibe-twinkle, wingman-bob, vibe-float)
// plus one small local keyframe for the avatar's idle breathing.

export function WingmanIntro() {
  const { goNext } = useOnboarding()
  const [visibleLines, setVisibleLines] = useState(0)

  useEffect(() => {
    if (visibleLines >= LINES.length) return
    const t = setTimeout(() => setVisibleLines((v) => v + 1), 650)
    return () => clearTimeout(t)
  }, [visibleLines])

  return (
    <div className="relative flex h-full min-h-screen flex-col overflow-hidden bg-ink">
      <style>{`
        @keyframes avatarIntroBreathe {
          0%, 100% { transform: translate(-50%, -50%) scale(1); }
          50% { transform: translate(-50%, -50%) scale(1.035); }
        }
        @keyframes avatarIntroDrift {
          0%, 100% { opacity: 0.35; transform: translateY(0); }
          50% { opacity: 0.85; transform: translateY(-10px); }
        }
      `}</style>

      {/* Cinematic lobby backdrop — a slow drifting glow, not a static wash */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background: 'radial-gradient(circle at 50% 18%, var(--color-primary), transparent 60%)',
          animation: 'vibe-float 9s ease-in-out infinite',
        }}
      />
      <div
        className="absolute inset-0 opacity-25"
        style={{
          background: 'radial-gradient(circle at 78% 70%, var(--color-secondary), transparent 55%)',
          animation: 'vibe-float 11s ease-in-out infinite reverse',
        }}
      />
      {/* Ambient particles for the "character-creation lobby" atmosphere */}
      {AMBIENT_DOTS.map((d, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-primary-light"
          style={{
            left: d.left,
            top: d.top,
            width: d.size,
            height: d.size,
            opacity: 0.5,
            boxShadow: '0 0 6px var(--color-primary-light)',
            animation: `avatarIntroDrift ${d.duration}s ease-in-out infinite`,
            animationDelay: `${d.delay}s`,
          }}
        />
      ))}

      <div className="relative flex flex-1 flex-col items-center px-6 pt-14 text-center text-white">
        <p className="text-caption font-semibold uppercase tracking-[0.18em] text-primary-light animate-fade-in-up">
          Let's create your avatar
        </p>
        <h1 className="mt-2.5 text-h1 text-white animate-fade-in-up">Let's build your avatar</h1>
        <p className="mt-2.5 max-w-[280px] text-body text-white/70 animate-fade-in-up">
          I'll help you create an avatar that represents your vibe and personality.
        </p>

        <div className="mt-8 flex flex-1 flex-col items-center justify-center">
          {/* Hero avatar — a clearly human, intentionally unfinished 3D-style
              bust inside a glowing progress ring, staged like a character
              waiting to be customized in a game lobby. */}
          <div className="relative flex items-center justify-center" style={{ width: 228, height: 228 }}>
            <div
              className="absolute rounded-full opacity-60 blur-2xl"
              style={{ inset: 10, background: 'radial-gradient(circle, var(--color-primary) 0%, transparent 72%)' }}
            />
            <div
              className="vibe-orbit-ring vibe-orbit-ring--cw absolute rounded-full"
              style={{ inset: 2, border: '1.5px dashed var(--color-primary-light)', opacity: 0.4, animationDuration: '26s' }}
            />
            <div
              className="absolute rounded-full"
              style={{
                inset: 14,
                border: '2px solid var(--color-primary)',
                boxShadow: '0 0 22px 2px rgba(201,106,68,0.55), inset 0 0 18px rgba(201,106,68,0.25)',
              }}
            />
            <div className="vibe-pulse-ring absolute rounded-full" style={{ inset: 14, border: '1px solid var(--color-primary)' }} />
            <div
              className="vibe-pulse-ring absolute rounded-full"
              style={{ inset: 14, border: '1px solid var(--color-primary)', animationDelay: '1.2s' }}
            />

            {/* Dark "pod" the bust sits inside, so the cropped shoulders read
                intentionally rather than clipped */}
            <div
              className="absolute rounded-full"
              style={{ inset: 16, background: 'radial-gradient(circle at 42% 34%, #2a2622 0%, #16130f 72%)', overflow: 'hidden' }}
            >
              <UnfinishedAvatarBust />
            </div>

            {AVATAR_SPARKLES.map((s, i) => (
              <div
                key={i}
                className="vibe-sparkle absolute text-primary-light"
                style={{ left: s.left, top: s.top, animationDelay: `${i * 0.45}s` }}
              >
                <SparkleIcon size={s.size} />
              </div>
            ))}
          </div>

          {/* Progress indicator — signals the avatar will fill in over time */}
          <div className="mt-5 flex flex-col items-center gap-1.5 animate-fade-in-up">
            <div className="h-1 w-28 overflow-hidden rounded-full bg-white/10">
              <div className="h-full w-[6%] rounded-full bg-primary" />
            </div>
            <p className="text-caption text-white/45">Your avatar evolves as you go</p>
          </div>

          {/* Wingman + speech bubble, staged beneath the avatar like it's
              actively introducing itself rather than sitting as an icon */}
          <div className="mt-7 flex w-full max-w-[320px] items-end gap-3">
            <WingmanPortrait talking={visibleLines > 0} />
            <div className="min-h-[86px] flex-1 rounded-2xl rounded-bl-sm border border-white/10 bg-white/[0.06] px-4 py-3 text-left backdrop-blur-sm">
              <p className="text-caption font-semibold uppercase tracking-[0.14em] text-primary-light">Wingman</p>
              <div className="mt-1 space-y-1.5">
                {LINES.slice(0, visibleLines).map((line, i) => (
                  <p key={i} className="text-small leading-snug text-white/85 animate-fade-in-up">
                    {line}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="relative px-6 pb-8">
        <Button
          onClick={goNext}
          className={`transition-opacity duration-300 ${visibleLines < LINES.length ? 'opacity-0 pointer-events-none' : 'animate-fade-in-up'}`}
        >
          Let's build my avatar →
        </Button>
        <p className="mt-3 flex items-center justify-center gap-1.5 text-caption text-white/45">
          <LockIcon />
          You can change it anytime later
        </p>
      </div>
    </div>
  )
}

const AMBIENT_DOTS = [
  { left: '14%', top: '22%', size: 4, duration: 6.5, delay: 0 },
  { left: '82%', top: '30%', size: 3, duration: 7.5, delay: 0.8 },
  { left: '20%', top: '58%', size: 3, duration: 8, delay: 1.6 },
  { left: '86%', top: '62%', size: 4, duration: 6, delay: 0.4 },
  { left: '10%', top: '75%', size: 3, duration: 7, delay: 2 },
]

const AVATAR_SPARKLES = [
  { left: '2%', top: '18%', size: 14 },
  { left: '92%', top: '22%', size: 11 },
  { left: '4%', top: '78%', size: 11 },
  { left: '90%', top: '76%', size: 14 },
]

// A featureless, softly-lit head-and-shoulders bust — deliberately "not yet
// a person": no facial features, a single neutral material, cropped by the
// pod behind it. The sculpted top-swept silhouette reads as a hairstyle
// without being a specific one, so it feels like a character mid-creation.
function UnfinishedAvatarBust() {
  return (
    <svg
      viewBox="0 0 120 132"
      className="absolute left-1/2 top-1/2"
      style={{ width: '78%', height: '78%', animation: 'avatarIntroBreathe 5.5s ease-in-out infinite' }}
    >
      <defs>
        <linearGradient id="bustFill" x1="20" y1="0" x2="100" y2="132" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#9aa1ab" />
          <stop offset="55%" stopColor="#6d7480" />
          <stop offset="100%" stopColor="#3d424b" />
        </linearGradient>
        <linearGradient id="bustRim" x1="0" y1="0" x2="120" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0" />
          <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0.55" />
        </linearGradient>
      </defs>

      {/* Shoulders / torso */}
      <path
        d="M60 74c-19 0-34 8-34 24v34h68v-34c0-16-15-24-34-24Z"
        fill="url(#bustFill)"
      />
      <path
        d="M60 74c-19 0-34 8-34 24v34h6v-34c0-13 12-21 28-23Z"
        fill="url(#bustRim)"
        opacity="0.7"
      />

      {/* Neck */}
      <path d="M49 58h22v20c0 6-5 9-11 9s-11-3-11-9V58Z" fill="url(#bustFill)" />

      {/* Head */}
      <ellipse cx="60" cy="34" rx="23" ry="26" fill="url(#bustFill)" />
      {/* Swept hair-silhouette mass — same material, just an added form */}
      <path
        d="M38 30c-1-14 10-23 22-23s22 8 23 21c-4-5-11-8-16-6-2-6-9-9-15-7-6 2-9 8-8 13-3-1-5 0-6 2Z"
        fill="url(#bustFill)"
      />
      {/* Rim light along one edge to tie the figure into the warm glow */}
      <path
        d="M83 20c3 5 4 10 3 15-1 7-5 13-9 17"
        fill="none"
        stroke="var(--color-primary)"
        strokeWidth="2.5"
        strokeLinecap="round"
        opacity="0.5"
      />
    </svg>
  )
}

// The Wingman's own portrait — a friendly, faceted "companion" silhouette
// (rounded body + two calm eyes + a small antenna spark) rather than a
// literal human character, kept in the same abstract-premium language as
// the sparkle mark used as the Wingman brand icon everywhere else in the
// app, just far more present than a small icon-in-a-circle.
function WingmanPortrait({ talking }: { talking: boolean }) {
  const size = 96
  return (
    <div className="relative shrink-0" style={{ width: size, height: size + 14 }}>
      {talking && (
        <>
          <div className="vibe-pulse-ring absolute rounded-full border border-primary/50" style={{ inset: 0, bottom: 14 }} />
          <div
            className="vibe-pulse-ring absolute rounded-full border border-primary/50"
            style={{ inset: 0, bottom: 14, animationDelay: '0.8s' }}
          />
        </>
      )}
      {/* small rounded shoulders — gives the head a "character in frame"
          presence instead of reading as a plain icon */}
      <div
        className="absolute rounded-t-2xl"
        style={{
          left: '14%',
          right: '14%',
          bottom: 0,
          height: size * 0.38,
          background: 'linear-gradient(160deg, var(--color-primary-dark) 0%, #7a3f24 100%)',
          boxShadow: '0 2px 10px rgba(0,0,0,0.35)',
        }}
      />
      <div
        className="wingman-companion absolute rounded-full shadow-pop"
        style={{
          left: '7%',
          right: '7%',
          top: 0,
          height: size * 0.86,
          background: 'radial-gradient(circle at 34% 28%, var(--color-primary-light) 0%, var(--color-primary) 46%, var(--color-primary-dark) 100%)',
          border: '1.5px solid rgba(255,255,255,0.2)',
        }}
      >
        <svg viewBox="0 0 100 100" className="h-full w-full">
          {/* small spark antenna */}
          <g className="vibe-sparkle" style={{ transformOrigin: '76px 18px' }}>
            <path d="M76 10c1.5 3 4 5 7 6-3 1-5.5 3-7 6-1.5-3-4-5-7-6 3-1 5.5-3 7-6z" fill="#fff" opacity="0.9" />
          </g>
          {/* calm friendly eyes */}
          <ellipse cx="37" cy="48" rx="5.5" ry="7" fill="#221d18" opacity="0.85" />
          <ellipse cx="63" cy="48" rx="5.5" ry="7" fill="#221d18" opacity="0.85" />
          <ellipse cx="35.5" cy="45.5" rx="1.7" ry="2" fill="#fff" />
          <ellipse cx="61.5" cy="45.5" rx="1.7" ry="2" fill="#fff" />
          {/* small warm smile */}
          <path d="M40 63c4 3.5 16 3.5 20 0" stroke="#221d18" strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.85" />
        </svg>
      </div>
    </div>
  )
}

function LockIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="2" />
      <path d="M8 11V7a4 4 0 018 0v4" stroke="currentColor" strokeWidth="2" />
    </svg>
  )
}
