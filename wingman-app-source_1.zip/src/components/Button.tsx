import type { ButtonHTMLAttributes, ReactNode } from 'react'

interface BaseProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode
  fullWidth?: boolean
  loading?: boolean
}

const base =
  'inline-flex items-center justify-center gap-2 rounded-full text-button transition-all duration-150 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none select-none'

export function Button({ children, fullWidth = true, loading, className = '', disabled, ...rest }: BaseProps) {
  return (
    <button
      className={`${base} ${fullWidth ? 'w-full' : ''} h-14 px-6 bg-primary text-white shadow-card hover:bg-primary-dark ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <Spinner /> : children}
    </button>
  )
}

export function SecondaryButton({ children, fullWidth = true, loading, className = '', disabled, ...rest }: BaseProps) {
  return (
    <button
      className={`${base} ${fullWidth ? 'w-full' : ''} h-14 px-6 bg-transparent text-ink border border-border hover:bg-surface-alt ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <Spinner light={false} /> : children}
    </button>
  )
}

export function TextButton({ children, fullWidth = false, className = '', disabled, ...rest }: BaseProps) {
  return (
    <button
      className={`${base} ${fullWidth ? 'w-full' : ''} h-11 px-2 bg-transparent text-primary hover:text-primary-dark ${className}`}
      disabled={disabled}
      {...rest}
    >
      {children}
    </button>
  )
}

function Spinner({ light = true }: { light?: boolean }) {
  return (
    <span
      className={`h-4 w-4 rounded-full border-2 border-t-transparent animate-spin ${
        light ? 'border-white/60' : 'border-ink/40'
      }`}
    />
  )
}
