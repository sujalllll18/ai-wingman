import { PLACEHOLDER_GRADIENTS } from '../data/onboardingOptions'

interface PhotoSlotProps {
  index: number
  filled: boolean
  primary?: boolean
  onAdd: () => void
  onRemove?: () => void
}

export function PhotoSlot({ index, filled, primary, onAdd, onRemove }: PhotoSlotProps) {
  if (filled) {
    return (
      <div
        className="relative aspect-[3/4] rounded-md overflow-hidden"
        style={{ background: PLACEHOLDER_GRADIENTS[index % PLACEHOLDER_GRADIENTS.length] }}
      >
        {primary && (
          <span className="absolute left-2 top-2 rounded-full bg-black/35 px-2 py-1 text-caption font-semibold text-white backdrop-blur-sm">
            Main
          </span>
        )}
        <button
          onClick={onRemove}
          aria-label="Remove photo"
          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm active:scale-95"
        >
          ✕
        </button>
      </div>
    )
  }

  return (
    <button
      onClick={onAdd}
      className="flex aspect-[3/4] flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-border bg-surface-alt/60 text-ink-muted transition-colors hover:border-primary/50 active:scale-[0.98]"
    >
      <span className="text-xl leading-none">+</span>
      <span className="text-caption">Add photo</span>
    </button>
  )
}
