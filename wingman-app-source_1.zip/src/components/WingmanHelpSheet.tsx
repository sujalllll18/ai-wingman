import { Modal } from './Modal'

export type HelpKind = 'opener' | 'question' | 'keepGoing' | 'fun'

const OPTIONS: { kind: HelpKind; label: string }[] = [
  { kind: 'opener', label: 'Give me an opener' },
  { kind: 'question', label: 'Suggest a question' },
  { kind: 'keepGoing', label: 'Help me keep this going' },
  { kind: 'fun', label: 'Make it more playful' },
]

interface WingmanHelpSheetProps {
  open: boolean
  onClose: () => void
  onSelect: (kind: HelpKind) => void
}

export function WingmanHelpSheet({ open, onClose, onSelect }: WingmanHelpSheetProps) {
  return (
    <Modal open={open} onClose={onClose} title="Need help?">
      <div className="space-y-2.5">
        {OPTIONS.map((option) => (
          <button
            key={option.kind}
            onClick={() => onSelect(option.kind)}
            className="w-full rounded-md border border-border bg-surface px-4 py-3.5 text-left text-body text-ink transition-colors hover:border-primary/40 active:scale-[0.99]"
          >
            {option.label}
          </button>
        ))}
      </div>
    </Modal>
  )
}
