// Widened to accept any 0-100 value (not just the four milestone values) so
// screens can animate the avatar continuously as fields are filled in, not
// just jump at each level's end. Every existing caller still only ever
// passes 0/25/50/75/100, so this is purely additive — same render at those
// exact values, nothing about other screens changes.
export type VibeCompletion = number

interface VibeAvatarProps {
  completion: VibeCompletion
  size?: number
}

const RING_COLOR = 'var(--color-secondary)'
const RING_COLOR_ALT = 'var(--color-primary)'

// The user's evolving "character" — an abstract animated orb rather than a
// literal cartoon (no character art assets exist for this prototype, and a
// hand-coded human illustration would read as worse than an abstract one).
// It gains orbiting particles, sparkle accents, and glow as completion
// increases — the "gaming lobby" progress feel without a boring progress bar.
export function VibeAvatar({ completion, size = 160 }: VibeAvatarProps) {
  const blobSize = size * 0.62
  const glowBlur = 10 + completion * 0.35
  const glowSpread = completion * 0.06
  const saturation = 0.55 + (completion / 100) * 0.45

  const ringCount = completion >= 100 ? 3 : completion >= 75 ? 2 : completion >= 50 ? 1 : 0
  const sparkleCount = completion >= 100 ? 4 : completion >= 75 ? 2 : 0

  const rings = [
    { particles: 3, radius: blobSize * 0.62, duration: 16, dir: 'cw' as const, dot: 6, color: RING_COLOR },
    { particles: 4, radius: blobSize * 0.82, duration: 22, dir: 'ccw' as const, dot: 5, color: RING_COLOR_ALT },
    { particles: 6, radius: blobSize * 1.02, duration: 28, dir: 'cw' as const, dot: 4, color: RING_COLOR },
  ].slice(0, ringCount)

  const sparkleAngles = [20, 100, 200, 300].slice(0, sparkleCount)

  return (
    <div
      className="relative shrink-0"
      style={{ width: size, height: size }}
      role="img"
      aria-label={`Your vibe avatar, ${completion}% complete`}
    >
      {/* Ambient glow, intensifies with completion */}
      <div
        className="absolute rounded-full"
        style={{
          inset: size * 0.12,
          background: `radial-gradient(circle, var(--color-primary) 0%, transparent 70%)`,
          filter: `blur(${glowBlur}px)`,
          opacity: 0.25 + completion * 0.0035 + glowSpread,
        }}
      />

      {/* Orbit rings with particles */}
      {rings.map((ring, i) => (
        <div
          key={i}
          className={`vibe-orbit-ring ${ring.dir === 'cw' ? 'vibe-orbit-ring--cw' : 'vibe-orbit-ring--ccw'}`}
          style={{ animationDuration: `${ring.duration}s` }}
        >
          {Array.from({ length: ring.particles }).map((_, p) => (
            <div
              key={p}
              className="absolute inset-0"
              style={{ transform: `rotate(${(360 / ring.particles) * p}deg)` }}
            >
              <div
                className="vibe-particle"
                style={{
                  width: ring.dot,
                  height: ring.dot,
                  background: ring.color,
                  transform: `translate(-50%, -50%) translateX(${ring.radius}px)`,
                  boxShadow: `0 0 6px ${ring.color}`,
                }}
              />
            </div>
          ))}
        </div>
      ))}

      {/* Sparkle accents */}
      {sparkleAngles.map((angle, i) => {
        const rad = (angle * Math.PI) / 180
        const r = blobSize * 0.68
        const x = size / 2 + Math.cos(rad) * r
        const y = size / 2 + Math.sin(rad) * r
        return (
          <div
            key={angle}
            className="vibe-sparkle absolute text-primary"
            style={{ left: x, top: y, transform: 'translate(-50%, -50%)', animationDelay: `${i * 0.4}s` }}
          >
            <SparkleIcon size={size * 0.09} />
          </div>
        )
      })}

      {/* Core blob */}
      <div
        className="vibe-blob-shape absolute"
        style={{
          left: '50%',
          top: '50%',
          width: blobSize,
          height: blobSize,
          transform: 'translate(-50%, -50%)',
          background:
            completion === 0
              ? 'linear-gradient(135deg, var(--color-border), var(--color-surface-alt))'
              : `linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%)`,
          filter: `saturate(${saturation})`,
          opacity: completion === 0 ? 0.6 : 1,
        }}
      />

      {/* Completion ring at 100% — the "fully formed" signal */}
      {completion >= 100 && (
        <div
          className="vibe-orbit-ring vibe-orbit-ring--cw absolute rounded-full"
          style={{
            inset: size * 0.06,
            border: '1.5px dashed var(--color-primary)',
            opacity: 0.4,
            animationDuration: '40s',
          }}
        />
      )}
    </div>
  )
}

export function SparkleIcon({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
      <path
        d="M12 3c1.5 3 4 4.5 7 5-3 1-5.5 3.5-7 7-1.5-3.5-4-6-7-7 3-.5 5.5-2 7-5z"
        fill="currentColor"
      />
    </svg>
  )
}
