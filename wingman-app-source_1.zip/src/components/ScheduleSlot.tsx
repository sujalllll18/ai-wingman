interface ScheduleSlotProps {
  time: string
  selected?: boolean
  onClick: () => void
}

export function ScheduleSlot({ time, selected, onClick }: ScheduleSlotProps) {
  return (
    <button
      onClick={onClick}
      className={`rounded-md border px-4 py-3.5 text-center text-body font-medium transition-colors ${
        selected ? 'border-primary bg-primary text-white' : 'border-border bg-surface text-ink hover:border-primary/40'
      }`}
    >
      {time}
    </button>
  )
}
