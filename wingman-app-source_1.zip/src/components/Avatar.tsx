import { PLACEHOLDER_GRADIENTS } from '../data/onboardingOptions'

interface AvatarProps {
  gradientIndex: number
  size?: number
  ring?: boolean
}

// Stand-in for a real profile photo — a distinct gradient swatch per person,
// consistent with the placeholders used throughout onboarding.
export function Avatar({ gradientIndex, size = 44, ring }: AvatarProps) {
  return (
    <div
      className={`shrink-0 rounded-full ${ring ? 'ring-2 ring-primary ring-offset-2 ring-offset-bg' : ''}`}
      style={{
        width: size,
        height: size,
        background: PLACEHOLDER_GRADIENTS[gradientIndex % PLACEHOLDER_GRADIENTS.length],
      }}
    />
  )
}
