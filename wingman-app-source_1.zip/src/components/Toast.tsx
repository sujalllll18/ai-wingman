interface ToastProps {
  message: string
  visible: boolean
}

export function Toast({ message, visible }: ToastProps) {
  return (
    <div
      className={`pointer-events-none fixed left-1/2 top-6 z-50 -translate-x-1/2 rounded-full bg-ink px-4 py-2.5 text-small font-medium text-white shadow-pop transition-all duration-300 ${
        visible ? 'opacity-100 translate-y-0' : '-translate-y-3 opacity-0'
      }`}
    >
      {message}
    </div>
  )
}
