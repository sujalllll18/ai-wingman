import { useEffect, useState } from 'react'
import { Avatar } from './Avatar'
import { INTRO_STAGE_LABEL, routeForIntroStage } from '../data/introRouting'
import type { IntroState, Person } from '../types/journey'
import { useOnboarding } from '../state/OnboardingContext'

interface IntroSlotProps {
  person: Person
  state: IntroState
}

function useCountdownLabel(unlockAtMs: number) {
  const [, setTick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 30000)
    return () => clearInterval(t)
  }, [])
  const msLeft = unlockAtMs - Date.now()
  if (msLeft <= 0) return null
  const mins = Math.ceil(msLeft / 60000)
  if (mins < 60) return `Unlocks in ${mins} min`
  const hrs = Math.floor(mins / 60)
  const rem = mins % 60
  return `Unlocks in ${hrs}h ${rem}m`
}

export function IntroSlot({ person, state }: IntroSlotProps) {
  const { setSelectedPersonId, goTo, unlockIntroNow } = useOnboarding()
  const countdown = useCountdownLabel(state.unlockAtMs)
  const locked = countdown !== null

  if (locked) {
    return (
      <div className="flex items-center gap-3 rounded-lg border border-dashed border-border bg-surface-alt/50 p-3.5">
        <div className="h-12 w-12 shrink-0 rounded-full bg-border/70" />
        <div className="flex-1">
          <p className="text-small font-medium text-ink-muted">Next introduction</p>
          <p className="text-caption text-ink-muted">{countdown}</p>
        </div>
        <button
          onClick={() => unlockIntroNow(person.id)}
          className="whitespace-nowrap text-caption font-semibold text-primary underline"
        >
          Unlock now (preview)
        </button>
      </div>
    )
  }

  const target = routeForIntroStage(state.stage)
  const label = INTRO_STAGE_LABEL[state.stage]

  return (
    <button
      onClick={() => {
        if (!target) return
        setSelectedPersonId(person.id)
        goTo(target)
      }}
      disabled={!target}
      className="flex w-full items-center gap-3 rounded-lg border border-border bg-surface p-3.5 text-left shadow-card transition-colors hover:border-primary/40 disabled:opacity-60"
    >
      <Avatar gradientIndex={person.gradientIndex} size={48} />
      <div className="flex-1 min-w-0">
        <p className="truncate text-body font-semibold text-ink">{person.name}, {person.age}</p>
        <p className="truncate text-small text-ink-secondary">
          {state.stage === 'new' ? person.whyTalk : label}
        </p>
      </div>
      {state.stage === 'connected' && (
        <span className="shrink-0 rounded-full bg-secondary/15 px-2.5 py-1 text-caption font-semibold text-secondary">
          Connected
        </span>
      )}
    </button>
  )
}
