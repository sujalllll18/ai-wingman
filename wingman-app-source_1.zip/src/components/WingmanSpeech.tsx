import { WingmanCompanion } from './WingmanCompanion'

interface WingmanSpeechProps {
  lines: string[]
  size?: number
}

// Consistent "Wingman says..." presentation used across the lobby, vibe
// profile levels, and verification — companion character + speech bubble.
export function WingmanSpeech({ lines, size = 56 }: WingmanSpeechProps) {
  return (
    <div className="flex items-start gap-3">
      <WingmanCompanion size={size} talking />
      <div className="flex-1 space-y-1.5 rounded-lg rounded-tl-sm bg-surface-alt/80 px-4 py-3">
        {lines.map((line, i) => (
          <p key={i} className="text-body text-ink">
            {line}
          </p>
        ))}
      </div>
    </div>
  )
}
