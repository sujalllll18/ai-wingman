import { useEffect } from 'react'
import { VibeAvatar, type VibeCompletion } from './VibeAvatar'
import { WingmanCompanion } from './WingmanCompanion'

interface LevelUpOverlayProps {
  toCompletion: VibeCompletion
  wingmanLine: string
  onDone: () => void
  durationMs?: number
}

// Full-screen celebratory beat shown right after a Vibe Profile level is
// completed — the avatar's evolution is the reward, not a progress bar.
export function LevelUpOverlay({ toCompletion, wingmanLine, onDone, durationMs = 2200 }: LevelUpOverlayProps) {
  useEffect(() => {
    const t = setTimeout(onDone, durationMs)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-6 bg-ink px-6 text-center animate-fade-in">
      <div className="animate-scale-in">
        <VibeAvatar completion={toCompletion} size={172} />
      </div>
      <p className="text-display text-white">{toCompletion}%</p>
      <div className="flex items-center gap-3 animate-fade-in-up">
        <WingmanCompanion size={44} talking />
        <p className="max-w-[220px] text-left text-body text-white/85">{wingmanLine}</p>
      </div>
    </div>
  )
}
