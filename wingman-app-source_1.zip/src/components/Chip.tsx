import type { ButtonHTMLAttributes } from 'react'

interface ChipProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  selected?: boolean
}

export function Chip({ selected, className = '', children, ...rest }: ChipProps) {
  return (
    <button
      type="button"
      className={`rounded-full border px-4 py-2.5 text-small font-medium transition-colors active:scale-[0.97] ${
        selected
          ? 'border-primary bg-primary text-white'
          : 'border-border bg-surface text-ink-secondary hover:border-primary/40'
      } ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}
