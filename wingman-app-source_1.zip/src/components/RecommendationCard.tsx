import { PLACEHOLDER_GRADIENTS } from '../data/onboardingOptions'
import type { Person } from '../types/journey'
import { Button } from './Button'

interface RecommendationCardProps {
  person: Person
  onSeeWhy: () => void
}

export function RecommendationCard({ person, onSeeWhy }: RecommendationCardProps) {
  return (
    <div className="overflow-hidden rounded-lg border border-border bg-surface shadow-card animate-fade-in-up">
      <div
        className="relative aspect-[4/3] w-full"
        style={{ background: PLACEHOLDER_GRADIENTS[person.gradientIndex % PLACEHOLDER_GRADIENTS.length] }}
      >
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4 pt-10">
          <p className="text-h1 text-white">
            {person.name}, <span className="font-normal">{person.age}</span>
          </p>
          <p className="text-small text-white/85">
            {person.location} · {person.profession}
          </p>
        </div>
      </div>

      <div className="space-y-4 p-4">
        <div>
          <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">You both</p>
          <ul className="mt-1.5 space-y-1">
            {person.commonInterests.map((item) => (
              <li key={item} className="flex items-start gap-2 text-small text-ink">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-secondary" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Different</p>
          <p className="mt-1.5 text-small text-ink-secondary">"{person.difference}"</p>
        </div>

        <div className="rounded-md bg-surface-alt/70 p-3">
          <p className="text-caption font-semibold uppercase tracking-wide text-primary">
            Why I think you should talk
          </p>
          <p className="mt-1 text-small text-ink">{person.whyTalk}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-border px-3 py-1.5 text-caption font-medium text-ink-secondary">
            {person.intent}
          </span>
          <span className="rounded-full border border-border px-3 py-1.5 text-caption font-medium text-ink-secondary">
            {person.communicationStyle}
          </span>
        </div>

        <Button onClick={onSeeWhy}>Why you two?</Button>
      </div>
    </div>
  )
}
