import type { ReactElement } from 'react'
import type { ScreenId } from '../state/flow'
import { useOnboarding } from '../state/OnboardingContext'

const TABS: { screen: ScreenId; label: string; icon: (active: boolean) => ReactElement }[] = [
  { screen: 'home', label: 'Home', icon: (a) => <HomeIcon active={a} /> },
  { screen: 'explore', label: 'Explore', icon: (a) => <ExploreIcon active={a} /> },
  { screen: 'connections', label: 'Connections', icon: (a) => <ConnectionsIcon active={a} /> },
  { screen: 'profile', label: 'Profile', icon: (a) => <ProfileIcon active={a} /> },
]

export function BottomNav() {
  const { screen, goTo } = useOnboarding()

  return (
    <div className="sticky bottom-0 z-20 flex border-t border-border/70 bg-surface/95 px-2 pb-[max(env(safe-area-inset-bottom),8px)] pt-1.5 backdrop-blur">
      {TABS.map((tab) => {
        const active = screen === tab.screen
        return (
          <button
            key={tab.screen}
            onClick={() => goTo(tab.screen)}
            className="flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 transition-colors"
          >
            {tab.icon(active)}
            <span className={`text-caption font-medium ${active ? 'text-primary' : 'text-ink-muted'}`}>{tab.label}</span>
          </button>
        )
      })}
    </div>
  )
}

function HomeIcon({ active }: { active: boolean }) {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none">
      <path
        d="M4 11.5L12 4l8 7.5M6 10v9a1 1 0 001 1h3v-5h4v5h3a1 1 0 001-1v-9"
        stroke={active ? 'var(--color-primary)' : 'var(--color-text-muted)'}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function ExploreIcon({ active }: { active: boolean }) {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="8" stroke={active ? 'var(--color-primary)' : 'var(--color-text-muted)'} strokeWidth="1.8" />
      <path
        d="M15 9l-2 5-4 2 2-5 4-2z"
        fill={active ? 'var(--color-primary)' : 'var(--color-text-muted)'}
      />
    </svg>
  )
}

function ConnectionsIcon({ active }: { active: boolean }) {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none">
      <path
        d="M4 19v-1.2C4 15.7 6.6 14 9.5 14s5.5 1.7 5.5 3.8V19M9.5 11a3 3 0 100-6 3 3 0 000 6zM16 8.5a2.5 2.5 0 110-5M17 11.3c1.7.3 3 1.6 3 3.3V16"
        stroke={active ? 'var(--color-primary)' : 'var(--color-text-muted)'}
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function ProfileIcon({ active }: { active: boolean }) {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="3.4" stroke={active ? 'var(--color-primary)' : 'var(--color-text-muted)'} strokeWidth="1.8" />
      <path
        d="M5 20c0-3.3 3.1-6 7-6s7 2.7 7 6"
        stroke={active ? 'var(--color-primary)' : 'var(--color-text-muted)'}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  )
}
