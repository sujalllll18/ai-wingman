import type { ReactNode } from 'react'

interface ModalProps {
  open: boolean
  onClose: () => void
  children: ReactNode
  title?: string
}

// Bottom-sheet style modal — matches the app's rounded, warm visual language
// better than a centered dialog would on a mobile-first layout.
export function Modal({ open, onClose, children, title }: ModalProps) {
  if (!open) return null
  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative z-10 w-full max-w-app rounded-t-xl bg-surface p-5 pb-8 shadow-pop animate-fade-in-up">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-border" />
        {title && <h2 className="text-h3 text-ink">{title}</h2>}
        <div className={title ? 'mt-3' : ''}>{children}</div>
      </div>
    </div>
  )
}
