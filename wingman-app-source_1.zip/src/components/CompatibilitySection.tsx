interface CompatibilitySectionProps {
  label: string
  text: string
}

export function CompatibilitySection({ label, text }: CompatibilitySectionProps) {
  return (
    <div className="border-l-2 border-primary/30 pl-4">
      <p className="text-caption font-semibold uppercase tracking-wide text-primary">{label}</p>
      <p className="mt-1 text-body text-ink">{text}</p>
    </div>
  )
}
