import type { ReactNode } from 'react'

interface TopBarProps {
  onBack?: () => void
  right?: ReactNode
  progress?: ReactNode
}

export function TopBar({ onBack, right, progress }: TopBarProps) {
  return (
    <div className="sticky top-0 z-10 bg-bg/95 backdrop-blur px-5 pt-5 pb-3">
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={onBack}
          aria-label="Back"
          className={`flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface text-ink transition-opacity ${
            onBack ? 'opacity-100 active:scale-95' : 'pointer-events-none opacity-0'
          }`}
        >
          <ChevronLeft />
        </button>
        {progress && <div className="flex-1">{progress}</div>}
        <div className="flex h-10 min-w-10 items-center justify-end">{right}</div>
      </div>
    </div>
  )
}

function ChevronLeft() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
