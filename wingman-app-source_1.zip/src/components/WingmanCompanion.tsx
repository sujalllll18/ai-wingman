import { SparkleIcon } from './VibeAvatar'

interface WingmanCompanionProps {
  size?: number
  talking?: boolean
}

// The Wingman's own character in the lobby — deliberately a different shape
// language from the user's VibeAvatar (a faceted spark vs. a soft orb) so
// the two read as distinct characters sharing the same space. Reuses the
// sparkle mark established as the Wingman brand icon everywhere else.
export function WingmanCompanion({ size = 72, talking = false }: WingmanCompanionProps) {
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      {talking && (
        <>
          <div
            className="vibe-pulse-ring absolute rounded-full border border-primary/50"
            style={{ inset: 0 }}
          />
          <div
            className="vibe-pulse-ring absolute rounded-full border border-primary/50"
            style={{ inset: 0, animationDelay: '0.8s' }}
          />
        </>
      )}
      <div
        className="wingman-companion absolute flex items-center justify-center rounded-full bg-primary text-white shadow-pop"
        style={{ inset: size * 0.14 }}
      >
        <SparkleIcon size={size * 0.42} />
      </div>
    </div>
  )
}
