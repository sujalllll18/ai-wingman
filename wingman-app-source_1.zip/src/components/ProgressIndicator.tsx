interface ProgressIndicatorProps {
  step: number
  total: number
}

export function ProgressIndicator({ step, total }: ProgressIndicatorProps) {
  const pct = Math.min(100, Math.round((step / total) * 100))
  return (
    <div className="flex items-center gap-3">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-surface-alt">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="whitespace-nowrap text-caption text-ink-muted">
        {step}/{total}
      </span>
    </div>
  )
}
