import { useState } from 'react'
import { Button, SecondaryButton, TextButton } from './Button'
import { Modal } from './Modal'
import { useOnboarding } from '../state/OnboardingContext'
import type { ScreenId } from '../state/flow'

const REPORT_REASONS = [
  'Made me uncomfortable',
  'Inappropriate messages or behaviour',
  'Suspect this is a fake profile',
  'Something else',
]

interface SafetyMenuProps {
  personId: string
  personName: string
  /** Screen to land on after a block/leave is confirmed. Defaults to 'explore'. */
  afterActionScreen?: ScreenId
  variant?: 'light' | 'dark'
}

type Step = 'closed' | 'menu' | 'reportReasons' | 'reportDone' | 'blockConfirm' | 'blockDone'

export function SafetyMenu({ personId, personName, afterActionScreen = 'explore', variant = 'light' }: SafetyMenuProps) {
  const { setIntroStage, goTo } = useOnboarding()
  const [step, setStep] = useState<Step>('closed')

  const close = () => setStep('closed')

  const submitReport = () => setStep('reportDone')

  const confirmBlock = () => {
    setIntroStage(personId, 'ended')
    setStep('blockDone')
  }

  const finish = () => {
    close()
    goTo(afterActionScreen)
  }

  return (
    <>
      <button
        onClick={() => setStep('menu')}
        aria-label="Safety options"
        className={`flex h-10 w-10 items-center justify-center rounded-full active:scale-95 ${
          variant === 'dark' ? 'bg-black/25 text-white backdrop-blur' : 'border border-border bg-surface text-ink-secondary'
        }`}
      >
        <DotsIcon />
      </button>

      <Modal open={step === 'menu'} onClose={close} title="Safety">
        <div className="space-y-2.5">
          <button
            onClick={() => setStep('reportReasons')}
            className="w-full rounded-md border border-border bg-surface px-4 py-3.5 text-left text-body text-ink transition-colors hover:border-primary/40"
          >
            Report {personName}
          </button>
          <button
            onClick={() => setStep('blockConfirm')}
            className="w-full rounded-md border border-error/30 bg-surface px-4 py-3.5 text-left text-body text-error transition-colors hover:border-error/60"
          >
            Block {personName}
          </button>
        </div>
      </Modal>

      <Modal open={step === 'reportReasons'} onClose={close} title={`Report ${personName}`}>
        <p className="text-small text-ink-secondary">What's going on?</p>
        <div className="mt-3 space-y-2">
          {REPORT_REASONS.map((reason) => (
            <button
              key={reason}
              onClick={submitReport}
              className="w-full rounded-md border border-border bg-surface px-4 py-3 text-left text-small text-ink transition-colors hover:border-primary/40"
            >
              {reason}
            </button>
          ))}
        </div>
      </Modal>

      <Modal open={step === 'reportDone'} onClose={close} title="Thanks for letting us know">
        <p className="text-small text-ink-secondary">
          Our safety team will review this. {personName} won't be notified.
        </p>
        <TextButton fullWidth className="mt-4 justify-center" onClick={close}>
          Got it
        </TextButton>
      </Modal>

      <Modal open={step === 'blockConfirm'} onClose={close} title={`Block ${personName}?`}>
        <p className="text-small text-ink-secondary">
          You won't see each other, and any scheduled conversations will be cancelled. This can't be undone.
        </p>
        <div className="mt-5 space-y-3">
          <SecondaryButton className="!text-error !border-error/40" onClick={confirmBlock}>
            Yes, block {personName}
          </SecondaryButton>
          <Button onClick={close}>Cancel</Button>
        </div>
      </Modal>

      <Modal open={step === 'blockDone'} onClose={finish} title={`${personName} has been blocked`}>
        <p className="text-small text-ink-secondary">You won't hear from them again. Your Wingman will keep looking for people worth your time.</p>
        <TextButton fullWidth className="mt-4 justify-center" onClick={finish}>
          Done
        </TextButton>
      </Modal>
    </>
  )
}

function DotsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <circle cx="5" cy="12" r="1.8" />
      <circle cx="12" cy="12" r="1.8" />
      <circle cx="19" cy="12" r="1.8" />
    </svg>
  )
}
