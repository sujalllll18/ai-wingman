import type { ReactNode } from 'react'
import { TopBar } from './TopBar'
import { VibeAvatar, type VibeCompletion } from './VibeAvatar'

interface VibeLevelScreenProps {
  completion: VibeCompletion // current completion, shown small in the header
  title: string
  subtitle?: string
  children: ReactNode
  footer: ReactNode
  onBack?: () => void
}

export function VibeLevelScreen({ completion, title, subtitle, children, footer, onBack }: VibeLevelScreenProps) {
  return (
    <div className="flex h-full min-h-screen flex-col">
      <TopBar onBack={onBack} />
      <div className="flex items-center gap-3 px-5 pb-2">
        <VibeAvatar completion={completion} size={44} />
        <div>
          <p className="text-caption font-semibold uppercase tracking-wide text-ink-muted">Your Vibe Profile</p>
          <p className="text-small font-semibold text-primary">{completion}% complete</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-2 no-scrollbar animate-fade-in-up">
        <h1 className="text-h1 text-ink">{title}</h1>
        {subtitle && <p className="mt-2 text-body text-ink-secondary">{subtitle}</p>}
        <div className="mt-5">{children}</div>
      </div>

      <div className="border-t border-border/70 bg-bg/95 px-5 py-4 backdrop-blur">{footer}</div>
    </div>
  )
}
