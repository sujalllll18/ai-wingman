interface PromptCardProps {
  text: string
  answer?: string
  onClick?: () => void
  onRemove?: () => void
}

export function PromptCard({ text, answer, onClick, onRemove }: PromptCardProps) {
  if (answer) {
    return (
      <div className="rounded-lg border border-border bg-surface p-4 shadow-card">
        <div className="flex items-start justify-between gap-3">
          <p className="text-caption uppercase tracking-wide text-primary">{text}</p>
          <div className="flex gap-2 shrink-0">
            <button onClick={onClick} className="text-caption font-semibold text-ink-secondary underline">
              Edit
            </button>
            <button onClick={onRemove} className="text-caption font-semibold text-error underline">
              Remove
            </button>
          </div>
        </div>
        <p className="mt-1.5 text-h3 text-ink">{answer}</p>
      </div>
    )
  }

  return (
    <button
      onClick={onClick}
      className="w-full rounded-lg border border-dashed border-border bg-surface-alt/60 p-4 text-left transition-colors hover:border-primary/50"
    >
      <p className="text-body text-ink-secondary">{text}</p>
      <p className="mt-1 text-small font-medium text-primary">+ Add your answer</p>
    </button>
  )
}
