import { forwardRef, type InputHTMLAttributes, type TextareaHTMLAttributes } from 'react'

interface TextInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  helper?: string
  error?: string
}

export const TextInput = forwardRef<HTMLInputElement, TextInputProps>(function TextInput(
  { label, helper, error, className = '', id, ...rest },
  ref,
) {
  return (
    <label className="block" htmlFor={id}>
      {label && <span className="mb-2 block text-small font-medium text-ink-secondary">{label}</span>}
      <input
        ref={ref}
        id={id}
        className={`w-full h-14 rounded-md border bg-surface px-4 text-body text-ink placeholder:text-ink-muted outline-none transition-colors focus:border-primary ${
          error ? 'border-error' : 'border-border'
        } ${className}`}
        {...rest}
      />
      {error ? (
        <span className="mt-1.5 block text-small text-error">{error}</span>
      ) : helper ? (
        <span className="mt-1.5 block text-small text-ink-muted">{helper}</span>
      ) : null}
    </label>
  )
})

interface TextAreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  helper?: string
  maxLength?: number
}

export const TextArea = forwardRef<HTMLTextAreaElement, TextAreaProps>(function TextArea(
  { label, helper, maxLength, className = '', id, value, ...rest },
  ref,
) {
  const length = typeof value === 'string' ? value.length : 0
  return (
    <label className="block" htmlFor={id}>
      {label && <span className="mb-2 block text-small font-medium text-ink-secondary">{label}</span>}
      <textarea
        ref={ref}
        id={id}
        value={value}
        maxLength={maxLength}
        className={`w-full min-h-[104px] rounded-md border border-border bg-surface px-4 py-3 text-body text-ink placeholder:text-ink-muted outline-none transition-colors focus:border-primary resize-none ${className}`}
        {...rest}
      />
      <div className="mt-1.5 flex items-center justify-between">
        <span className="text-small text-ink-muted">{helper}</span>
        {maxLength && (
          <span className="text-caption text-ink-muted">
            {length}/{maxLength}
          </span>
        )}
      </div>
    </label>
  )
})
