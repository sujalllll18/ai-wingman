import type { ChatMessage } from '../types/journey'

export function ChatBubble({ message }: { message: ChatMessage }) {
  if (message.from === 'system') {
    return (
      <div className="my-2 flex justify-center">
        <span className="rounded-full bg-surface-alt px-3 py-1.5 text-caption text-ink-muted">{message.text}</span>
      </div>
    )
  }

  const mine = message.from === 'me'
  return (
    <div className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[78%] rounded-lg px-4 py-2.5 text-body animate-fade-in-up ${
          mine ? 'rounded-br-sm bg-primary text-white' : 'rounded-bl-sm bg-surface-alt text-ink'
        }`}
      >
        {message.text}
      </div>
    </div>
  )
}
