// Mock auth layer — simulates OTP delivery/verification with no real backend.
// Swap this module out for real API calls later; screens only depend on
// this function signature.

export const MOCK_OTP_CODE = '1234'

export type OtpChannel = 'sms' | 'whatsapp'

export function mockSendOtp(_phoneNumber: string, _channel: OtpChannel): Promise<{ success: true }> {
  return new Promise((resolve) => setTimeout(() => resolve({ success: true }), 700))
}

export function mockVerifyOtp(code: string): Promise<{ success: boolean }> {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ success: code === MOCK_OTP_CODE }), 600),
  )
}
