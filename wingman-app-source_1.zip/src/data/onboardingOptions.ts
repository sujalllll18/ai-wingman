// Static mock/reference data for onboarding screens. In a real backend this
// would come from a config endpoint — kept here as a simple typed layer so
// it's obvious what to swap out later.

export const GENDER_OPTIONS: { value: string; label: string }[] = [
  { value: 'woman', label: 'Woman' },
  { value: 'man', label: 'Man' },
  { value: 'non-binary', label: 'Non-binary' },
  { value: 'self-describe', label: 'Prefer to self-describe' },
]

export const INTERESTED_IN_OPTIONS: { value: string; label: string }[] = [
  { value: 'women', label: 'Women' },
  { value: 'men', label: 'Men' },
  { value: 'everyone', label: 'Everyone' },
]

export const RELATIONSHIP_INTENTION_OPTIONS: {
  value: string
  label: string
  helper: string
}[] = [
  {
    value: 'serious',
    label: 'A serious relationship',
    helper: 'Looking for something long-term',
  },
  {
    value: 'dating',
    label: 'Dating',
    helper: 'Getting to know people, staying open',
  },
  {
    value: 'open',
    label: 'Open to seeing where it goes',
    helper: 'No fixed expectations',
  },
  {
    value: 'not-sure',
    label: 'Not sure yet',
    helper: 'Still figuring it out — that’s fine too',
  },
]

export const INTEREST_OPTIONS: string[] = [
  'Travel',
  'Music',
  'Food',
  'Fitness',
  'Movies',
  'Books',
  'Startups',
  'Art',
  'Photography',
  'Sports',
  'Gaming',
  'Fashion',
  'Technology',
  'Nature',
  'Cooking',
  'Yoga',
  'Dancing',
  'Coffee',
  'Wine',
  'Writing',
]

export const PROMPT_OPTIONS: { id: string; text: string }[] = [
  { id: 'perfect-sunday', text: 'Perfect Sunday looks like...' },
  { id: 'talk-for-hours', text: 'Something I can talk about for hours...' },
  { id: 'ideal-first-date', text: 'My ideal first date...' },
  { id: 'surprised-to-learn', text: 'One thing people are surprised to learn about me...' },
  { id: 'green-flag', text: 'Green flag I appreciate...' },
  { id: 'unpopular-opinion', text: 'My unpopular opinion...' },
]

export const MIN_PROMPTS_REQUIRED = 2
export const MAX_PROMPTS_ALLOWED = 3

export const MIN_PHOTOS_REQUIRED = 4
export const MAX_PHOTOS_ALLOWED = 6

// Warm, distinct placeholder gradients so mock photo slots don't all look identical.
export const PLACEHOLDER_GRADIENTS = [
  'linear-gradient(135deg, #f0d9ca 0%, #c96a44 100%)',
  'linear-gradient(135deg, #dbe7e1 0%, #2f5d50 100%)',
  'linear-gradient(135deg, #f3ebe1 0%, #a8532e 100%)',
  'linear-gradient(135deg, #e7dcce 0%, #234539 100%)',
  'linear-gradient(135deg, #f0d9ca 0%, #6b6055 100%)',
  'linear-gradient(135deg, #dbe7e1 0%, #c96a44 100%)',
]
