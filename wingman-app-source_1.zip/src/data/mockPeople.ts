import type { Person } from '../types/journey'

// Curated mock introductions — deliberately exactly 3, never an infinite feed.
// In a real backend this is where the recommendation engine's output would
// land; here it's static, matching the "no advanced recommendation engine
// yet" scope for this stage.

export const MOCK_PEOPLE: Person[] = [
  {
    id: 'sarah',
    name: 'Sarah',
    age: 28,
    location: 'Bandra, Mumbai',
    profession: 'Product Designer',
    gradientIndex: 0,
    intent: 'Dating',
    communicationStyle: 'Deep conversations',
    commonInterests: ['Spontaneous travel', 'Live music', 'Deep conversations'],
    compatibilityPoint: 'You both prefer meaningful conversations over small talk.',
    difference: 'You plan everything. She travels spontaneously.',
    whyTalk:
      'You both lit up talking about travel and music in your profiles — and neither of you enjoys surface-level small talk.',
    compatibility: {
      commonGround: 'You both love spontaneous travel and can talk for hours about the last place that surprised you.',
      communication: 'You both prefer deeper conversations over small talk — neither of you enjoys forced chit-chat.',
      lifestyle: 'You both enjoy trying new places before anyone else recommends them.',
      potentialChemistry:
        'You are both social, but she is more spontaneous while you tend to plan ahead — that kind of contrast tends to make conversation easy.',
    },
    bio: 'Product designer who is happiest with a coffee and a good conversation. Always up for trying the place everyone is talking about.',
    openers: [
      'You both mentioned Japan — ask her which city she would return to tomorrow.',
      'Ask what the most spontaneous trip she has ever taken was.',
      'Tell her about the last live show that stuck with you and ask about hers.',
    ],
    conversationTopics: [
      'What is a trip you would take again tomorrow if you could?',
      'What is a conversation you would happily have for hours?',
      'What is one place in Mumbai you think is underrated?',
    ],
    replySamples: [
      "Ha, good question — probably Kyoto, I didn't want to leave.",
      'I love that. Okay wait, I have to ask you something too —',
      "That's such a good way to put it, honestly.",
      "I wasn't expecting that answer, I like it.",
    ],
    dateInterests: ['live music', 'a new neighbourhood to wander'],
  },
  {
    id: 'ananya',
    name: 'Ananya',
    age: 27,
    location: 'Powai, Mumbai',
    profession: 'Marketing Lead',
    gradientIndex: 1,
    intent: 'Open to seeing where it goes',
    communicationStyle: 'Takes time to open up',
    commonInterests: ['Books', 'Coffee', 'Weekend hikes'],
    compatibilityPoint: 'You both wind down the same way — a book and a slow morning.',
    difference: "She's up by 6am. You're a night person, most days.",
    whyTalk:
      "Your 'perfect Sunday' prompts are almost identical, right down to the coffee order.",
    compatibility: {
      commonGround: 'You both said your ideal weekend starts with a slow morning and a good book.',
      communication: 'You both write longer, more thoughtful prompt answers than most — a good sign for real conversation.',
      lifestyle: 'You both make time for a hike or a long walk most weekends, rain or not.',
      potentialChemistry:
        "She's an early riser and you're more of a night owl — different rhythms, but you both protect the same quiet mornings and evenings for yourselves.",
    },
    bio: 'Marketing lead by day, trail runner on weekends. Currently three chapters into a book I will probably finish next month.',
    openers: [
      'You both picked the same ideal Sunday — ask her what she is currently reading.',
      'Ask which weekend trail near Mumbai she keeps going back to.',
      'Tell her your actual coffee order and ask if she judges it.',
    ],
    conversationTopics: [
      'What is the last book you did not want to end?',
      'Coffee or chai person, and why is there even a debate?',
      'What does an ideal Saturday morning look like for you?',
    ],
    replySamples: [
      "Currently reading something I'm embarrassingly behind on, honestly.",
      'Okay that is a very specific coffee order, I respect it though.',
      "I go back and forth on that actually — ask me again in winter.",
      'Ha, same energy. What about you?',
    ],
    dateInterests: ['books', 'a slow coffee'],
  },
  {
    id: 'meera',
    name: 'Meera',
    age: 29,
    location: 'Andheri, Mumbai',
    profession: 'Physiotherapist',
    gradientIndex: 2,
    intent: 'A serious relationship',
    communicationStyle: 'Fun and playful',
    commonInterests: ['Cooking', 'Fitness', 'Sunday markets'],
    compatibilityPoint: "You're both the friend who plans the group dinner reservation two weeks out.",
    difference: 'She trains for half-marathons. You go to the gym to disappear for an hour.',
    whyTalk:
      'You both said food is how you show people you care — that usually means a good first conversation.',
    compatibility: {
      commonGround: 'You both cook for other people as a way of showing you care, not just for yourselves.',
      communication: 'You both answered the "green flag" prompt almost the same way — consistency over grand gestures.',
      lifestyle: 'You both build your week around a fitness routine you actually protect.',
      potentialChemistry:
        'She trains with a group and thrives on structure; you use fitness as quiet, solo time — worth comparing notes on.',
    },
    bio: "Physiotherapist who spends most weekends at Sunday markets or convincing friends to try a new recipe with me.",
    openers: [
      'Ask her what she is cooking this week.',
      'You both mentioned Sunday markets — ask which one is her regular spot.',
      'Ask if she is training for anything right now.',
    ],
    conversationTopics: [
      'What is a dish you make when you want to impress someone?',
      'Do you have a Sunday market you go to on repeat?',
      'What gets you moving on a day you really do not feel like it?',
    ],
    replySamples: [
      'Honestly probably something with too much garlic, per usual.',
      'Okay I need to know your answer to that too now.',
      "That's exactly it, yes. Glad someone else gets it.",
      'Good question — depends entirely on the weather, if I am honest.',
    ],
    dateInterests: ['a Sunday market', 'trying a new recipe together'],
  },
]

export function getPersonById(id: string | null): Person | undefined {
  return MOCK_PEOPLE.find((p) => p.id === id)
}
