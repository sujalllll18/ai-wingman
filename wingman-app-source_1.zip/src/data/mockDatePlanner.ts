import type { UserProfile } from '../types/profile'
import type { CommunicationStyle } from '../types/profile'
import type { DateItineraryStop, DateOffer, DatePlan, DateSelection, Person } from '../types/journey'

// ---------------------------------------------------------------------------
// The whole point of this file: Wingman already knows the user (Vibe
// Profile) and the connected person (Person mock data). The date planner
// only ever asks "what do you feel like today" — everything else here is
// either derived from existing profile data or filled in with realistic
// simulated content, never re-collected from the user.
// ---------------------------------------------------------------------------

export interface PlaceType {
  id: string
  label: string
  emoji: string
  // Vibe Profile interests that make this option "already relevant" —
  // used only to pre-select/recommend, never shown to the user as a form.
  relatedInterests: string[]
}

export const PLACE_TYPES: PlaceType[] = [
  { id: 'cafe', label: 'Café', emoji: '☕', relatedInterests: ['Coffee'] },
  { id: 'restaurant', label: 'Restaurant', emoji: '🍽', relatedInterests: ['Food', 'Cooking', 'Wine'] },
  { id: 'movies', label: 'Movies', emoji: '🎬', relatedInterests: ['Movies'] },
  { id: 'music', label: 'Live Music', emoji: '🎵', relatedInterests: ['Music', 'Dancing'] },
  { id: 'art', label: 'Art', emoji: '🎨', relatedInterests: ['Art', 'Photography', 'Writing'] },
  { id: 'outdoors', label: 'Outdoors', emoji: '🌳', relatedInterests: ['Nature', 'Travel'] },
  { id: 'walk', label: 'Walk', emoji: '🚶', relatedInterests: ['Nature', 'Fitness'] },
  { id: 'activity', label: 'Activity', emoji: '🎯', relatedInterests: ['Sports', 'Gaming', 'Yoga'] },
  { id: 'surprise', label: 'Surprise me', emoji: '✨', relatedInterests: [] },
]

export interface VibeOption {
  id: string
  label: string
  emoji: string
  // A soft default: if the user's Vibe Profile communication style matches,
  // this is pre-selected instead of asking again.
  matchesStyle?: CommunicationStyle
}

export const VIBE_OPTIONS: VibeOption[] = [
  { id: 'romantic', label: 'Romantic', emoji: '❤️' },
  { id: 'casual', label: 'Casual', emoji: '😊', matchesStyle: 'takes-time' },
  { id: 'playful', label: 'Fun & playful', emoji: '✨', matchesStyle: 'fun-playful' },
  { id: 'relaxed', label: 'Relaxed', emoji: '🌿', matchesStyle: 'quiet-at-first' },
  { id: 'adventurous', label: 'Adventurous', emoji: '🔥', matchesStyle: 'talk-a-lot' },
  { id: 'conversation', label: 'Conversation-first', emoji: '💬', matchesStyle: 'deep-conversations' },
  { id: 'surprise', label: 'Surprise me', emoji: '🎲' },
]

export interface PriorityOption {
  id: string
  label: string
  emoji: string
}

export const PRIORITY_OPTIONS: PriorityOption[] = [
  { id: 'budget', label: 'Budget-friendly', emoji: '₹' },
  { id: 'rated', label: 'Highly rated', emoji: '⭐' },
  { id: 'nearby', label: 'Nearby', emoji: '📍' },
  { id: 'quiet', label: 'Less crowded', emoji: '👥' },
  { id: 'trending', label: 'Trending', emoji: '🔥' },
  { id: 'photogenic', label: 'Instagram-worthy', emoji: '📸' },
]

export const DAY_OPTIONS: { id: DateSelection['day']; label: string }[] = [
  { id: 'today', label: 'Today' },
  { id: 'tomorrow', label: 'Tomorrow' },
  { id: 'weekend', label: 'This weekend' },
]

export const TIME_OF_DAY_OPTIONS: { id: NonNullable<DateSelection['timeOfDay']>; label: string }[] = [
  { id: 'morning', label: 'Morning' },
  { id: 'afternoon', label: 'Afternoon' },
  { id: 'evening', label: 'Evening' },
  { id: 'night', label: 'Night' },
]

// Mock "usual availability" — in a real product this would be learned from
// past scheduling behaviour. No such history exists in this prototype, so
// it's a realistic constant rather than an invented per-user computation.
export const USUAL_AVAILABILITY = { day: 'weekend' as const, timeOfDay: 'evening' as const, label: 'Saturday evening' }

// Which place-type chips are already relevant given the user's existing
// Vibe Profile interests — this is what lets the screen skip asking for
// interests again.
export function recommendedPlaceTypeIds(profile: UserProfile): string[] {
  const interests = new Set(profile.interests)
  const matched = PLACE_TYPES.filter((t) => t.relatedInterests.some((i) => interests.has(i))).map((t) => t.id)
  return matched.length > 0 ? matched.slice(0, 3) : ['cafe']
}

export function recommendedVibeId(profile: UserProfile): string {
  const match = VIBE_OPTIONS.find((v) => v.matchesStyle === profile.communicationStyle)
  return match?.id ?? 'casual'
}

function dayLabelFor(selection: DateSelection): string {
  if (selection.day === 'custom' && selection.customDate) return selection.customDate
  if (selection.day === 'today') return 'Today'
  if (selection.day === 'tomorrow') return 'Tomorrow'
  return 'Saturday' // 'weekend' and 'usual' both resolve to the nearest Saturday in this prototype
}

const TIME_START: Record<string, number> = { morning: 10 * 60, afternoon: 14 * 60, evening: 18.5 * 60, night: 20.5 * 60 }

function formatMinutes(mins: number): string {
  let h = Math.floor(mins / 60) % 24
  const m = Math.round(mins % 60)
  const period = h >= 12 ? 'PM' : 'AM'
  h = h % 12 || 12
  return `${h}:${m.toString().padStart(2, '0')} ${period}`
}

function timeSequenceFor(selection: DateSelection): string[] {
  if (selection.day === 'custom' && selection.customTime) {
    const [h, m] = selection.customTime.split(':').map(Number)
    const start = h * 60 + (m || 0)
    return [formatMinutes(start), formatMinutes(start + 60), formatMinutes(start + 150)]
  }
  const start = TIME_START[selection.timeOfDay ?? 'evening'] ?? TIME_START.evening
  return [formatMinutes(start), formatMinutes(start + 60), formatMinutes(start + 150)]
}

interface Venue {
  title: string
  price: string
  rating: string
}

const VENUES: Record<string, Venue[]> = {
  cafe: [
    { title: 'Blue Tokai — Bandra', price: '₹700–1,000 for two', rating: '4.5' },
    { title: 'Third Wave Coffee — Bandra', price: '₹500–800 for two', rating: '4.3' },
    { title: 'Kalmane Cafe — Khar', price: '₹600–900 for two', rating: '4.6' },
  ],
  restaurant: [
    { title: 'Bastian — Bandra', price: '₹3,000–4,000 for two', rating: '4.4' },
    { title: 'The Bombay Canteen — Lower Parel', price: '₹2,400–3,200 for two', rating: '4.6' },
    { title: 'O Pedro — BKC', price: '₹2,800–3,600 for two', rating: '4.5' },
  ],
  movies: [
    { title: 'PVR ICON — Bandra', price: '₹800–1,200 for two', rating: '4.2' },
    { title: 'Regal Cinema — Colaba', price: '₹600–900 for two', rating: '4.1' },
  ],
  music: [
    { title: 'antiSOCIAL — Khar', price: '₹1,000–1,500 for two', rating: '4.4' },
    { title: 'The Quarter — Colaba', price: '₹1,200–1,800 for two', rating: '4.5' },
  ],
  art: [
    { title: 'Chemould Prescott Road — Fort', price: 'Free entry', rating: '4.6' },
    { title: 'Method Studios — Bandra', price: 'Free entry', rating: '4.3' },
  ],
  outdoors: [
    { title: 'Bandra Bandstand promenade', price: 'Free', rating: '4.5' },
    { title: 'Carter Road promenade', price: 'Free', rating: '4.6' },
  ],
  walk: [
    { title: 'Carter Road promenade', price: 'Free', rating: '4.6' },
    { title: 'Bandra Fort walk', price: 'Free', rating: '4.4' },
  ],
  activity: [
    { title: 'Smaaash — Bandra', price: '₹1,200–1,600 for two', rating: '4.2' },
    { title: 'Pottery studio — Khar', price: '₹1,800–2,200 for two', rating: '4.7' },
  ],
  surprise: [
    { title: "Wingman's pick: rooftop café — Bandra", price: '₹800–1,200 for two', rating: '4.5' },
  ],
}

const PLACE_EMOJI: Record<string, string> = PLACE_TYPES.reduce(
  (acc, t) => ({ ...acc, [t.id]: t.emoji }),
  {} as Record<string, string>,
)

const SUBTITLES: Record<string, string> = {
  cafe: 'Coffee + conversation',
  restaurant: 'Dinner + easy conversation',
  movies: 'A film, then talk about it after',
  music: 'Live music + easy conversation',
  art: 'A gallery to react to together',
  outdoors: 'Fresh air, low pressure',
  walk: 'An easy evening walk',
  activity: 'Something playful and low-pressure',
  surprise: 'Something a little different — trust the process',
}

const OFFER_POOL: DateOffer[] = [
  { label: '10% off with Zomato Gold' },
  { label: 'Swiggy offer available' },
  { label: 'Happy hour pricing until 7 PM' },
]

function pick<T>(arr: T[], seed: number): T {
  return arr[((seed % arr.length) + arr.length) % arr.length]
}

export function generateDatePlan(person: Person, selection: DateSelection, variant = 0): DatePlan {
  const chosenTypes = selection.placeTypes.length > 0 ? selection.placeTypes : ['cafe']
  const primary = chosenTypes[0]
  const pool = VENUES[primary] ?? VENUES.cafe
  const venue = pick(pool, variant)

  const hasMusic = chosenTypes.includes('music') || person.commonInterests.some((i) => /music/i.test(i))
  const hasOutdoor = chosenTypes.includes('outdoors') || chosenTypes.includes('walk')

  const times = timeSequenceFor(selection)
  const itinerary: DateItineraryStop[] = [
    { time: times[0], emoji: PLACE_EMOJI[primary] ?? '☕', label: SUBTITLES[primary] ?? 'Time together' },
    hasMusic
      ? { time: times[1], emoji: '🎵', label: 'Live music nearby' }
      : hasOutdoor
        ? { time: times[1], emoji: '🚶', label: 'A relaxed walk nearby' }
        : { time: times[1], emoji: '🎨', label: 'Something to explore nearby' },
    { time: times[2], emoji: '🍨', label: 'Dessert / short walk' },
  ]

  const sharedInterest = person.dateInterests[variant % person.dateInterests.length] ?? person.commonInterests[0]
  const vibeOption = VIBE_OPTIONS.find((v) => v.id === selection.vibe)
  const dayLabel = dayLabelFor(selection)
  const timeLabel = times[0]
  const budgetFriendly = selection.priorities.includes('budget')

  const reasonParts = [
    `You both enjoy ${sharedInterest.toLowerCase()}${vibeOption && vibeOption.id !== 'surprise' ? ` and ${vibeOption.label.toLowerCase()} places` : ''}`,
    `and ${dayLabel} at ${times[0]} works well for both of you.`,
  ]

  return {
    ...selection,
    personId: person.id,
    dayLabel,
    timeLabel,
    venueEmoji: PLACE_EMOJI[primary] ?? '☕',
    venueTitle: venue.title,
    venueSubtitle: SUBTITLES[primary] ?? 'Time together',
    musicTag: hasMusic ? 'Live music nearby' : '8 min walk',
    walkTag: '8 min walk',
    priceTag: budgetFriendly && venue.price !== 'Free' ? `${venue.price} · budget-friendly` : venue.price,
    ratingTag: `${venue.rating} rating`,
    itinerary,
    reason: reasonParts.join(' '),
    offers: [pick(OFFER_POOL, variant), pick(OFFER_POOL, variant + 1)].filter(
      (o, i, arr) => arr.findIndex((x) => x.label === o.label) === i,
    ),
  }
}
