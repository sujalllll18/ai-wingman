import type { ConversationStage, ScheduledSlot } from '../types/journey'

export interface SlotOption {
  day: 'Today' | 'Tomorrow'
  time: string
}

// Mock "times when both of you are available" — a real backend would
// intersect two calendars; here it's a fixed, believable set.
export const SLOT_OPTIONS: SlotOption[] = [
  { day: 'Today', time: '8:30 PM' },
  { day: 'Today', time: '9:30 PM' },
  { day: 'Tomorrow', time: '7:00 PM' },
  { day: 'Tomorrow', time: '8:00 PM' },
  { day: 'Tomorrow', time: '9:30 PM' },
]

export const STAGE_DURATIONS: Record<ConversationStage, number> = {
  first: 10,
  second: 20,
  video: 20,
}

function formatDateLabel(day: 'Today' | 'Tomorrow'): string {
  const date = new Date()
  if (day === 'Tomorrow') date.setDate(date.getDate() + 1)
  return date.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
}

export function addMinutes(time: string, minutesToAdd: number): string {
  const match = time.match(/(\d+):(\d+)\s?(AM|PM)/i)
  if (!match) return time
  const [, hourStr, minuteStr, meridiemRaw] = match
  let hour = Number(hourStr)
  let meridiem = meridiemRaw.toUpperCase()
  let minute = Number(minuteStr) + minutesToAdd
  while (minute >= 60) {
    minute -= 60
    hour += 1
    if (hour === 12) meridiem = meridiem === 'AM' ? 'PM' : 'AM'
    if (hour > 12) hour = 1
  }
  return `${hour}:${String(minute).padStart(2, '0')} ${meridiem}`
}

export function buildScheduledSlot(personId: string, option: SlotOption, stage: ConversationStage): ScheduledSlot {
  const durationMinutes = STAGE_DURATIONS[stage]
  return {
    personId,
    stage,
    day: option.day,
    date: formatDateLabel(option.day),
    time: option.time,
    endTime: addMinutes(option.time, durationMinutes),
    durationMinutes,
  }
}
