// Sample prompts for the "Your Story" screen's Answer Prompts tab. Explicitly
// a placeholder set — the brief for this screen calls the final prompt list
// "not finalized" — kept here as its own small data module so swapping the
// list later doesn't touch the screen component.

export interface StoryPrompt {
  id: string
  text: string
}

export const STORY_PROMPTS: StoryPrompt[] = [
  { id: 'perfect-sunday', text: 'What does your perfect Sunday look like?' },
  { id: 'talk-for-hours', text: 'What is something you could talk about for hours?' },
  { id: 'brings-out-best', text: 'What kind of person brings out the best in you?' },
  { id: 'not-understood', text: "What is something people usually don't understand about you at first?" },
]

export const PROMPT_WORD_LIMIT = 50

export function countWords(text: string): number {
  const trimmed = text.trim()
  return trimmed ? trimmed.split(/\s+/).length : 0
}

// Truncates to at most `limit` words without disturbing text the user is
// still actively typing inside that limit — used to enforce the 50-word cap
// live, on every keystroke, rather than only at submit time.
export function clampToWordLimit(text: string, limit: number): string {
  const words = text.split(/\s+/).filter(Boolean)
  if (words.length <= limit) return text
  return words.slice(0, limit).join(' ')
}

// Mock "voice transcription" — the prototype has no real microphone/speech
// pipeline, so tapping Talk fills the box with a canned, on-topic transcript
// the user can then edit. Kept short enough to always sit under the 50-word
// prompt limit.
export const MOCK_VOICE_TRANSCRIPTS: Record<string, string> = {
  'perfect-sunday': 'Sleeping in a little, a slow coffee, maybe a long walk, and ending the day with people I actually like being around.',
  'talk-for-hours': 'Honestly, travel stories. Ask me about a trip and I will not stop talking.',
  'brings-out-best': 'Someone curious who actually listens and does not take themselves too seriously.',
  'not-understood': 'People assume I am quiet, but once I am comfortable I do not stop talking.',
}

export const MOCK_VOICE_TRANSCRIPT_FREEFORM =
  "I'm someone who values deep conversations, loyalty and personal growth. I love exploring new places, meeting new people, and trying new things. I'm ambitious but also believe in enjoying the little moments in life."
