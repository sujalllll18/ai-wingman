export interface CompatibilityQuestion {
  id: string
  text: string
}

// Sample set for the prototype — 15 questions, deliberately light in tone
// so Level 4 feels like a quick quiz rather than an exam.
export const COMPATIBILITY_QUESTIONS: CompatibilityQuestion[] = [
  { id: 'move-cities', text: 'Would you move cities for the right relationship?' },
  { id: 'talk-through-problems', text: 'Do you prefer talking through problems immediately?' },
  { id: 'quiet-night-vs-party', text: 'Would you rather have a quiet night together than go to a party?' },
  { id: 'career-ambition', text: 'Is career ambition important to you?' },
  { id: 'spontaneous-plans', text: 'Do you enjoy spontaneous plans?' },
  { id: 'need-alone-time', text: 'Do you need a lot of alone time to recharge?' },
  { id: 'meet-friends-early', text: 'Do you like meeting each other’s friends early on?' },
  { id: 'financially-independent', text: 'Is it important that you both stay financially independent?' },
  { id: 'public-affection', text: 'Are you comfortable with public displays of affection?' },
  { id: 'kids-someday', text: 'Do you see kids in your future, someday?' },
  { id: 'routine-over-adventure', text: 'Do you generally prefer routine over adventure?' },
  { id: 'discuss-money-early', text: 'Should money be a comfortable topic early in a relationship?' },
  { id: 'long-distance-ok', text: 'Would you try long distance for the right person?' },
  { id: 'plans-vs-flow', text: 'Do you like having the whole week planned out in advance?' },
  { id: 'pets-non-negotiable', text: 'Are pets a non-negotiable part of your life?' },
]
