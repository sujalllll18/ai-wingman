import type { IntroStage } from '../types/journey'
import type { ScreenId } from '../state/flow'

// Where tapping an introduction should take you, based on where that
// introduction currently sits in the conversation ladder. Centralized so
// Home, Explore and Connections all route the same way.
export function routeForIntroStage(stage: IntroStage): ScreenId | null {
  switch (stage) {
    case 'new':
      return 'matchExplanation'
    case 'scheduled_first':
    case 'scheduled_second':
      return 'upcomingConversation'
    case 'talked_first':
    case 'talked_second':
      return 'decision'
    case 'scheduled_video':
      return 'videoCall'
    case 'connection_requested':
      return 'connectionRequest'
    case 'connected':
      return 'unlimitedChat'
    case 'ended':
    case 'locked':
    default:
      return null
  }
}

export const INTRO_STAGE_LABEL: Record<IntroStage, string> = {
  locked: 'Locked',
  new: 'New introduction',
  scheduled_first: 'Conversation scheduled',
  talked_first: 'Awaiting your decision',
  scheduled_second: 'Second conversation scheduled',
  talked_second: 'Awaiting your decision',
  scheduled_video: 'Video call scheduled',
  video_done: 'Video call complete',
  connection_requested: 'Request sent',
  connected: 'Connected',
  ended: 'Ended',
}
