// Generic Wingman suggestions that aren't tied to a specific person — used
// for the "keep it going" and "something fun" chat-assist categories.

export const KEEP_GOING_TIPS: string[] = [
  'Ask a follow-up on whatever they just said — specific beats generic.',
  'Try: "wait, tell me more about that."',
  "If it's gone quiet, it's okay — ask what they're up to this weekend.",
]

export const FUN_PROMPTS: string[] = [
  'Two truths and a lie — you go first.',
  'Ask: what song would you want playing if you walked into a room right now?',
  'Would you rather: perfect weather every day, or one wildly unpredictable day a month?',
]
