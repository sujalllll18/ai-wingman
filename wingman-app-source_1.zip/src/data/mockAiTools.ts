import type { AiImportField, CommunicationStyle, RelationshipIntention } from '../types/profile'
import { clampToWordLimit, PROMPT_WORD_LIMIT } from './storyPrompts'

// ---- AI Rephrase (Level 3 "Tell your story") -----------------------------
// No real AI API in this prototype — a deterministic, label-honest "polish"
// pass. It normalizes phrasing and punctuation but never adds facts, traits
// or experiences the user didn't write.

export function mockRephrase(raw: string, variant: 0 | 1 = 0): string {
  const text = raw.trim()
  if (!text) return text

  // The brief's own worked example — shown verbatim so that documented demo
  // input produces the documented result.
  if (/quiet/i.test(text) && /talk/i.test(text) && /travel/i.test(text)) {
    return variant === 0
      ? "I'm a little quiet when you first meet me, but once I'm comfortable, I can talk for hours. I love discovering new places, trying great food and travelling whenever I get the chance."
      : "Give me a bit of time and I open right up — once I'm comfortable, I can talk for hours. Travelling and finding great food are what I get most excited about."
  }

  let out = text
    .replace(/\bi am\b/gi, "I'm")
    .replace(/\bi like\b/gi, 'I love')
    .replace(/\bi dont\b/gi, "I don't")
    .replace(/\bi ll\b/gi, "I'll")
    .replace(/\s+/g, ' ')
    .trim()

  if (variant === 1) {
    // A second, slightly reordered pass so "Try again" feels like a fresh take.
    const clauses = out.split(/(?<=[.!?])\s+/).filter(Boolean)
    if (clauses.length > 1) out = [clauses[clauses.length - 1], ...clauses.slice(0, -1)].join(' ')
  }

  out = out.replace(/(^\s*\w|[.!?]\s*\w)/g, (m) => m.toUpperCase())
  if (!/[.!?]$/.test(out)) out += '.'
  return out
}

// ---- AI Profile Import (ChatGPT) -----------------------------------------

export const CHATGPT_IMPORT_PROMPT = `I am creating a personal profile for a social/dating app.
I want you to understand my personality naturally rather than simply writing a dating bio for me.
Ask me thoughtful questions about my personality, communication style, interests, lifestyle, work, hobbies, relationship goals, ideal connection, ideal first interaction, values, green flags, deal-breakers and anything else that would help someone understand me.
Have a natural conversation with me. Do not ask everything at once.
Only use information I actually provide.
At the end, summarize:
PERSONALITY:
COMMUNICATION STYLE:
INTERESTS:
LIKES:
DISLIKES:
LIFESTYLE:
PROFESSION:
RELATIONSHIP INTENTION:
IDEAL CONNECTION:
IDEAL FIRST DATE:
SOCIAL STYLE:
VALUES:
GREEN FLAGS:
DEAL-BREAKERS:
HOBBIES:
CONVERSATION TOPICS:
OTHER USEFUL DETAILS:
Do not invent any information.`

const KNOWN_LABELS = [
  'PERSONALITY',
  'COMMUNICATION STYLE',
  'INTERESTS',
  'LIKES',
  'DISLIKES',
  'LIFESTYLE',
  'PROFESSION',
  'RELATIONSHIP INTENTION',
  'IDEAL CONNECTION',
  'IDEAL FIRST DATE',
  'SOCIAL STYLE',
  'VALUES',
  'GREEN FLAGS',
  'DEAL-BREAKERS',
  'HOBBIES',
  'CONVERSATION TOPICS',
  'OTHER USEFUL DETAILS',
]

export interface ParsedImport {
  bio: string
  communicationStyle: CommunicationStyle | null
  interests: string[]
  likes: string
  dislikes: string
  profession: string
  relationshipIntention: RelationshipIntention | null
  lifestyle: string
  values: string
  idealConnection: string
  conversationTopics: string
  promptAnswers: { promptId: string; answer: string }[]
  extras: AiImportField[]
}

const FALLBACK_EXAMPLE = `PERSONALITY: Warm, a little reserved at first, but curious and easy to talk to once comfortable.
COMMUNICATION STYLE: I take time to open up, but I love a deep conversation once I'm there.
INTERESTS: Travel, live music, food, photography
LIKES: Slow mornings, trying new restaurants, a good playlist
DISLIKES: Small talk, last-minute cancellations
LIFESTYLE: Balanced — active most weekends, quiet on weeknights
PROFESSION: Product Designer
RELATIONSHIP INTENTION: Dating, open to something serious with the right person
IDEAL CONNECTION: Someone curious, kind, and easy to be around
IDEAL FIRST DATE: Coffee somewhere with good light and no rush
SOCIAL STYLE: Small groups
VALUES: Honesty, consistency, curiosity
GREEN FLAGS: Follows through on plans, asks good questions
DEAL-BREAKERS: Flakiness, dishonesty
HOBBIES: Photography, cooking, weekend hikes
CONVERSATION TOPICS: Travel stories, food, design
OTHER USEFUL DETAILS: Recently got into film photography`

function mapCommunicationStyle(value: string): CommunicationStyle | null {
  const v = value.toLowerCase()
  if (v.includes('quiet') || v.includes('reserved')) return 'quiet-at-first'
  if (v.includes('playful') || v.includes('fun')) return 'fun-playful'
  if (v.includes('deep')) return 'deep-conversations'
  if (v.includes('talk a lot') || v.includes('talkative')) return 'talk-a-lot'
  if (v.includes('time')) return 'takes-time'
  return null
}

function mapRelationshipIntention(value: string): RelationshipIntention | null {
  const v = value.toLowerCase()
  if (v.includes('serious')) return 'serious'
  if (v.includes('not sure')) return 'not-sure'
  if (v.includes('open')) return 'open'
  if (v.includes('dating')) return 'dating'
  return null
}

// Parses ChatGPT's labeled summary (the format our own prompt asks for).
// Falls back to a representative example if no recognizable labels are
// found, so the flow never dead-ends on unexpected paste content — but the
// review screen always shows these as editable, unconfirmed cards either way.
export function mockParseChatGptResponse(pasted: string): ParsedImport {
  const source = KNOWN_LABELS.some((label) => new RegExp(`${label}\\s*:`, 'i').test(pasted))
    ? pasted
    : FALLBACK_EXAMPLE

  const sections: Record<string, string> = {}
  const pattern = new RegExp(`(${KNOWN_LABELS.join('|')})\\s*:`, 'gi')
  const matches = [...source.matchAll(pattern)]
  matches.forEach((match, i) => {
    const label = match[1].toUpperCase()
    const start = (match.index ?? 0) + match[0].length
    const end = i + 1 < matches.length ? matches[i + 1].index : source.length
    sections[label] = source.slice(start, end).trim()
  })

  const known = new Set([
    'PERSONALITY',
    'COMMUNICATION STYLE',
    'INTERESTS',
    'LIKES',
    'DISLIKES',
    'PROFESSION',
    'RELATIONSHIP INTENTION',
    'LIFESTYLE',
    'VALUES',
    'IDEAL CONNECTION',
    'CONVERSATION TOPICS',
  ])
  const extras: AiImportField[] = Object.entries(sections)
    .filter(([label, value]) => !known.has(label) && value)
    .map(([label, value]) => ({
      label: label.charAt(0) + label.slice(1).toLowerCase(),
      value,
    }))

  // Best-effort mock mapping of the pasted response onto the screen's own
  // individual prompts — reuses only text the person actually wrote (never
  // invents an answer), and skips a prompt entirely if nothing usable was
  // said. Kept to <=50 words each to match the prompt cards' own limit.
  const promptAnswers = [
    { promptId: 'perfect-sunday', source: sections.LIFESTYLE },
    { promptId: 'talk-for-hours', source: sections['CONVERSATION TOPICS'] },
    { promptId: 'brings-out-best', source: sections['IDEAL CONNECTION'] },
    { promptId: 'not-understood', source: sections['OTHER USEFUL DETAILS'] || sections.PERSONALITY },
  ]
    .filter((p) => p.source && p.source.trim())
    .map((p) => ({ promptId: p.promptId, answer: clampToWordLimit(p.source!.trim(), PROMPT_WORD_LIMIT) }))

  return {
    bio: sections.PERSONALITY ?? '',
    communicationStyle: mapCommunicationStyle(sections['COMMUNICATION STYLE'] ?? ''),
    interests: (sections.INTERESTS ?? '')
      .split(/[,\n]/)
      .map((s) => s.trim())
      .filter(Boolean),
    likes: sections.LIKES ?? '',
    dislikes: sections.DISLIKES ?? '',
    profession: sections.PROFESSION ?? '',
    relationshipIntention: mapRelationshipIntention(sections['RELATIONSHIP INTENTION'] ?? ''),
    lifestyle: sections.LIFESTYLE ?? '',
    values: sections.VALUES ?? '',
    idealConnection: sections['IDEAL CONNECTION'] ?? '',
    conversationTopics: sections['CONVERSATION TOPICS'] ?? '',
    promptAnswers,
    extras,
  }
}
