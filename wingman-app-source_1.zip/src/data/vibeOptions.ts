import type { CommunicationStyle, SocialStyle } from '../types/profile'

export const COMMUNICATION_STYLE_OPTIONS: { value: CommunicationStyle; label: string }[] = [
  { value: 'deep-conversations', label: 'I love deep conversations' },
  { value: 'fun-playful', label: 'Fun and playful' },
  { value: 'quiet-at-first', label: 'Quiet at first' },
  { value: 'talk-a-lot', label: 'I talk a lot' },
  { value: 'takes-time', label: 'I take time to open up' },
]

export const SOCIAL_STYLE_OPTIONS: { value: SocialStyle; label: string; helper: string }[] = [
  { value: 'one-on-one', label: 'One-on-one', helper: 'I connect best with just one other person' },
  { value: 'small-groups', label: 'Small groups', helper: 'A handful of close people, low pressure' },
  { value: 'big-social', label: 'Big social settings', helper: 'The more energy in the room, the better' },
  { value: 'depends', label: 'Depends on the vibe', helper: 'It really varies for me' },
]

export const LIFESTYLE_OPTIONS: string[] = [
  'Early riser',
  'Night owl',
  'Homebody',
  'Always out',
  'Fitness-focused',
  'Foodie',
  'Outdoorsy',
  'Loves hosting',
  'Minimalist',
  'Plant parent',
  'Pet person',
  'Big on routine',
]
