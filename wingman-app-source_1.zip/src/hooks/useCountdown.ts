import { useEffect, useRef, useState } from 'react'

interface UseCountdownOptions {
  onComplete?: () => void
}

// Simple real-time (1s = 1s) countdown used by the scheduled conversation
// screens. Exposes secondsLeft plus a formatted mm:ss string, and a
// `finishNow` escape hatch so a reviewer clicking through the prototype
// doesn't have to sit through the full 10 minutes to see the end state.
export function useCountdown(totalSeconds: number, { onComplete }: UseCountdownOptions = {}) {
  const [secondsLeft, setSecondsLeft] = useState(totalSeconds)
  const onCompleteRef = useRef(onComplete)
  onCompleteRef.current = onComplete

  useEffect(() => {
    if (secondsLeft <= 0) {
      onCompleteRef.current?.()
      return
    }
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [secondsLeft])

  const minutes = Math.floor(secondsLeft / 60)
  const seconds = secondsLeft % 60
  const formatted = `${minutes}:${String(seconds).padStart(2, '0')}`

  return {
    secondsLeft,
    formatted,
    finishNow: () => setSecondsLeft(0),
    pctElapsed: Math.round(((totalSeconds - secondsLeft) / totalSeconds) * 100),
  }
}
