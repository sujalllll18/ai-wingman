import { OnboardingProvider, useOnboarding } from './state/OnboardingContext'
import { Welcome } from './screens/Welcome'
import { Signup } from './screens/Signup'
import { PhoneNumber } from './screens/PhoneNumber'
import { OtpVerify } from './screens/OtpVerify'
import { WingmanIntro } from './screens/WingmanIntro'
import { Level1 } from './screens/vibe/Level1'
import { Level2 } from './screens/vibe/Level2'
import { YourStory } from './screens/vibe/YourStory'
import { CompatibilityIntro } from './screens/CompatibilityIntro'
import { ProfileReady } from './screens/ProfileReady'
import { Level4 } from './screens/vibe/Level4'
import { WingmanAnalyzing } from './screens/WingmanAnalyzing'
import { Verification } from './screens/Verification'
import { Home } from './screens/tabs/Home'
import { Explore } from './screens/tabs/Explore'
import { Connections } from './screens/tabs/Connections'
import { Profile } from './screens/tabs/Profile'
import { MatchExplanation } from './screens/MatchExplanation'
import { Scheduling } from './screens/Scheduling'
import { UpcomingConversation } from './screens/UpcomingConversation'
import { ChatRoom } from './screens/ChatRoom'
import { Decision } from './screens/Decision'
import { TalkOnceMore } from './screens/TalkOnceMore'
import { VideoCall } from './screens/VideoCall'
import { ConnectionRequest } from './screens/ConnectionRequest'
import { ConnectionEstablished } from './screens/ConnectionEstablished'
import { UnlimitedChat } from './screens/UnlimitedChat'
import { DatePlannerIntro } from './screens/DatePlannerIntro'
import { DatePlanResult } from './screens/DatePlanResult'
import { DatePlanSent } from './screens/DatePlanSent'
import type { ScreenId } from './state/flow'

const SCREEN_COMPONENTS: Record<ScreenId, React.ComponentType> = {
  welcome: Welcome,
  signup: Signup,
  phone: PhoneNumber,
  otp: OtpVerify,

  wingmanIntro: WingmanIntro,

  vibeLevel1: Level1,
  vibeLevel2: Level2,
  yourStory: YourStory,
  compatibilityIntro: CompatibilityIntro,
  compatibility: Level4,
  wingmanAnalyzing: WingmanAnalyzing,
  profileReady: ProfileReady,
  verification: Verification,

  home: Home,
  explore: Explore,
  connections: Connections,
  profile: Profile,

  matchExplanation: MatchExplanation,
  scheduling: Scheduling,
  upcomingConversation: UpcomingConversation,
  chatRoom: ChatRoom,
  decision: Decision,
  talkOnceMore: TalkOnceMore,

  videoCall: VideoCall,

  connectionRequest: ConnectionRequest,
  connectionEstablished: ConnectionEstablished,
  unlimitedChat: UnlimitedChat,

  datePlannerIntro: DatePlannerIntro,
  datePlanResult: DatePlanResult,
  datePlanSent: DatePlanSent,
}

function ScreenRouter() {
  const { screen } = useOnboarding()
  const Screen = SCREEN_COMPONENTS[screen]
  return (
    <div key={screen} className="flex min-h-screen flex-1 flex-col">
      <Screen />
    </div>
  )
}

export default function App() {
  return (
    <div className="app-shell">
      <OnboardingProvider>
        <ScreenRouter />
      </OnboardingProvider>
    </div>
  )
}
